// $Id : $
function readfr()
{
	var len = parent.frames.length;
	var len1 = parent.parent.frames.length;
	headlink = window.document.getElementById('header');
	if(len == 1 && len1 == 3)
	{
		headlink.style.display = 'none';
		parent.document.getElementById('pane').style.height = 0;
	}
	else if(len == 3 && len1 == 3)
	{
		headlink.style.display = 'block';
		parent.document.getElementById('pane').style.height = 56;
	}
	else if(len == 1 && len1 == 1)
	{
		headlink.style.display = 'block';
		parent.document.getElementById('pane').style.height = 56;
	}
}	

