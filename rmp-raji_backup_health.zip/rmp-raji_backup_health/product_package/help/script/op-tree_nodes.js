/*$Id : $*/
//ignorei18n_start

var TREE_NODES = [
	['Welcome to RecoveryManager Plus', "introduction/introduction.html", "MAIN"
	/*	['Contact ZOHO Corp.',"introduction/contact-zohocorp.html", "MAIN",
		], */
	],
	['Getting Started', "getting-started/getting-started.html", "MAIN",
		['System Requirements', "getting-started/system-requirements.html", "MAIN"
		],
		['Installing RecoveryManager Plus', "getting-started/setting-up-rmp.html", "MAIN"
		],
		['Working with RecoveryManager Plus', "getting-started/Working-with-RecoveryManager-Plus.html", "MAIN"
		],
		['Licensing', "getting-started/licensing.html", "MAIN"
		]
	],
	['Dashboard View', "home/dashboard-view.html", "MAIN"
	],
	['Active Directory', "backup-recovery/backup-and-recovery.html", "MAIN",
     	['Active Directory', "backup-recovery/active-directory.html", "MAIN",

		['Backup Summary', "backup-recovery/backup-explorer.html", "MAIN"
		],
		['Restore', "backup-recovery/restore.html", "MAIN"
		],
		['Rollback', "backup-recovery/rollback.html", "MAIN"
		],
		['Recycle Bin', "backup-recovery/recycle-bin.html", "MAIN"
		],
        ],


     	['Windows Server', "windows-server/windows-server.html", "MAIN",
			['Backup configuration', "windows-server/backup-configuration.html", "MAIN"
			],
			['Backup Summary', "windows-server/backup-summary.html", "MAIN"
			],
			['Restore', "windows-server/restore.html", "MAIN"
			],
            ['Repository', "windows-server/repository.html", "MAIN"
			],
            ['License management', "windows-server/license-management.html", "MAIN"
			]
		],


        ['Settings', "settings/settings.html", "MAIN",
		['Domain Settings', "settings/domain-settings.html", "MAIN"
		],
		['Backup Settings', "settings/backup-settings.html", "MAIN"
		],
		['Recovery Settings', "settings/recovery-settings.html", "MAIN"
		],
		['Custom attributes', "settings/custom-attributes.html", "MAIN"
		]
	   ]
	],
    ['Virtual Environment', "virtual-environment/virtual-environment.html", "MAIN",
         ['VMware', "virtual-environment/vmware/vmware.html", "MAIN",

            ['Configuration', "virtual-environment/vmware/vmware-configuration.html", "MAIN"
            ],
            ['Backup', "virtual-environment/vmware/vmware-backup.html", "MAIN"
            ],
            ['Restore', "virtual-environment/vmware/vmware-restore.html", "MAIN",
                ['File level restoration', "virtual-environment/vmware/file-level-restoration.html", "MAIN"
                ],
                ['Easy restoration', "virtual-environment/vmware/easy-restoration.html", "MAIN"
                ],
                ['Full restoration', "virtual-environment/vmware/full-restoration.html", "MAIN"
                ],
                ['Disk restoration', "virtual-environment/vmware/disk-restoration.html", "MAIN"
                ],
                ['Revert VMware virtual machines', "virtual-environment/vmware/revert-vmware-virtual-machines.html", "MAIN"
                ],
                ['Live migration', "virtual-environment/vmware/live-migration.html", "MAIN"
                ]
            ],
           ['Instant recovery', "virtual-environment/vmware/instant-recovery.html", "MAIN"
            ]
        ],
        ['Hyper-V', "virtual-environment/hyper/hyper.html", "MAIN",

            ['Configuration', "virtual-environment/hyper/hyper-configuration.html", "MAIN"
            ],
            ['Backup', "virtual-environment/hyper/hyper-backup.html", "MAIN"
            ],
            ['Restore', "virtual-environment/hyper/hyper-restore.html", "MAIN",

                ['File level restoration', "virtual-environment/hyper/file-level-restoration.html", "MAIN"
                ],
                ['Easy restoration', "virtual-environment/hyper/easy-restoration.html", "MAIN"
                ],
                ['Full restoration', "virtual-environment/hyper/full-restoration.html", "MAIN"
                ],
                ['Disk restoration', "virtual-environment/hyper/disk-restoration.html", "MAIN"
                ],
                ['Live migration', "virtual-environment/hyper/live-migration.html", "MAIN"
                ]
            ]
        ],
      ['Repository', "virtual-environment/repository/repository.html", "MAIN",
            ['Local', "virtual-environment/repository/local-repository.html", "MAIN"
            ],
            ['Shared', "virtual-environment/repository/shared-repository.html", "MAIN"
            ],
            ['Proxy', "virtual-environment/repository/proxy.html", "MAIN"
            ]
        ],
        ['License Management', "virtual-environment/license-management.html", "MAIN"

        ]


	],
	['Admin', "admin/admin.html", "MAIN",
		['NT Service', "admin/nt-service.html", "MAIN"
		],
		['Mail Server', "admin/mail-server.html", "MAIN"
		],
		['Connection', "admin/connection.html", "MAIN"
		],
		['Notification', "admin/notification.html", "MAIN"
		],
		['Technician', "admin/technician.html", "MAIN"
		],
        ['Database Backup', "admin/database-backup.html", "MAIN"
		]
	],
	['Database Change', "database/change-to-mssql.html", "MAIN"
	],
	['Support', "support/support.html", "MAIN"
	],
    ['Troubleshooting Tips', "ts/ts.html", "MAIN",
        ['Active Directory', "ts/ad-troubleshooting.html", "MAIN"
		],
		['Hyper-V', "ts/hyper-troubleshooting.html", "MAIN"
		]
	]


];

//ignorei18n_end