using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Security;
using System.Text;
using System.Web;
using System.IO;
using System.Management.Automation.Remoting;
using System.Management;
using System.Threading;

namespace PowershellManager
{
    public class Logger
    {
        private static String logFile;
        private static Object lockThis = new Object();
        public static void log(string message)
        {
            try
            {
                logFile = @"..\logs\rmp_powershellcs_" + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
                lock (lockThis)
                {
                    if (!File.Exists(logFile))
                    {
                        File.Create(logFile);
                    }
                    File.AppendAllText(logFile, DateTime.Now.ToString() + " | " + Thread.CurrentThread.ManagedThreadId + " | " + message + Environment.NewLine);
                }
            }
            catch (Exception e)
            {
                //Console.WriteLine("CS Logger : " + e.Message + e.StackTrace);
            }
        }
    }

    public class PowershellHandler
    {
        private PSCredential creds = null;
        private Collection<PSObject> psResult = new Collection<PSObject>();
        private Collection<String> psError = new Collection<String>();
        private Hashtable runSpaceHash;
        private String domainName = "";
        private String userName = "";
        private String password = "";
        private String serverName = "";
        private String returnResult = "";
        private bool storingResult = false;
        private bool isCrossForest = false;
        private bool useRemoteShell = false;
        private bool isRunspaceLoaded = false;
        private PSCommand rmcommand;
        private PowerShell powershell;
        private Runspace powerShellRunspace;
        private int errorCode;
        /* Changes for HyperV */
        StringBuilder sb = new StringBuilder();
        private bool isHyperVSCVMM = false;
        private bool thisisimportVMcommand = false;
        private String hvcheckpointoperation = "";
        String hypervnewVMid="-";
        int globalErrorCode = 0;


        public PowershellHandler(string domainName, string dcName, string userName, string password)
        {
            Init(domainName, dcName, userName, password, true);
        }

        public PowershellHandler(string domainName, string dcName, string userName, string password, bool isCrossForest)
        {
            Init(domainName, dcName, userName, password, isCrossForest);
        }

        /* Changes for HyperV */
        public PowershellHandler(string dcName, string userName, string password, bool isCrossForest, bool isHyperVSCVMM)
        {
            Logger.log("Hyper-V PowershellHandler c# Constructor started");
            this.isHyperVSCVMM = true;
            if (userName != null && !(userName.Equals("-")))
            {
                Logger.log("Hyper-V PowershellHandler c# Constructor username not null.");
                if(userName.Contains("\\"))
                {
                    Logger.log("Hyper-V PowershellHandler c# Constructor split userName credential");
                    string[] domainuserName = userName.Split('\\');
                    string domainName = domainuserName[0];
                    string userString = domainuserName[1];
                    Init(domainName, dcName, userString, password, isCrossForest);
                }
                else
                {
                    Logger.log("Hyper-V PowershellHandler c# Constructor Wrong userName credential");
                    throw new Exception("Wrong userName credential");   
                }
            }
            else
            {
                Logger.log("Hyper-V PowershellHandler Credentials are NULL!!!");
                string domainName = "";
                string userString = "";
                Init(domainName, dcName, userString, password, isCrossForest);
            }
            Logger.log("Hyper-V PowershellHandler c# Constructor ended");
        }

        public PowershellHandler(string dcName, string userName, string password, bool isCrossForest, string hvcheckpointoperation)
        {
            Logger.log("Hyper-V PowershellHandler performhvcheckpointbackup c# Constructor started for operation - " + hvcheckpointoperation);
            this.hvcheckpointoperation = hvcheckpointoperation;
            if (userName != null && !(userName.Equals("-")))
            {
                Logger.log("Hyper-V performhvcheckpointbackup PowershellHandler c# Constructor username not null");

                string[] domainuserName = userName.Split('\\');

                string domainName = domainuserName[0];
                string userString = domainuserName[1];


                Init(domainName, dcName, userString, password, isCrossForest);
            }
            else
            {
                Logger.log("Hyper-V performhvcheckpointbackup PowershellHandler Credentials are NULL!!!");
                string domainName = "";
                string userString = "";
                Init(domainName, dcName, userString, password, isCrossForest);
            }
            Logger.log("Hyper-V performhvcheckpointbackup PowershellHandler c# Constructor ended");
        }


        public int getError(){
            return this.errorCode;
        }

        private void Init(string domainName, string dcName, string userName, string password, bool isCrossForest)
        {
            try
            {
                Logger.log("PowershellHandler c# Constructor . . .");
                rmcommand = new PSCommand();
                this.domainName = domainName;
                this.userName = userName;
                this.password = password;
                this.serverName = dcName;
                this.isCrossForest = isCrossForest;
                this.errorCode = 0;
                Logger.log("domainName : " + domainName);
                Logger.log("isCrossForest : " + isCrossForest);
                Logger.log("userName : " + userName);
                Logger.log("serverName : " + serverName);
                runSpaceHash = RunSpaceCache.getRunspaceHash(serverName);
                if (runSpaceHash == null )//|| this.hvcheckpointoperation.Equals("MoveVM"))
                {
                    Initialize();
                }
                else
                {
                    Logger.log("Loading Cached Runspace :" + serverName);
                    powerShellRunspace = (Runspace)runSpaceHash["runspace"];
                    if (powerShellRunspace != null)
                    {
                        isRunspaceLoaded = true;
                    }
                    this.useRemoteShell = (bool)runSpaceHash["isRemoteShell"];
                    String cachedUserName = (String)runSpaceHash["userName"];
                    DateTime cachedTime = (DateTime)runSpaceHash["cachedTime"];
                    this.powershell = (PowerShell)runSpaceHash["powershell"];
                    if (this.useRemoteShell)
                    {
                        if (this.userName != cachedUserName)
                        {
                            Logger.log("Different user.Reloading runspace...");
                            ReloadRunspace();
                        }
                    }
                    else if (!cachedUserName.Equals(userName) || (DateTime.Now - cachedTime).TotalDays > 1)
                    {
                        //  Reload is called when UserName is changed and last tired and failed is more a day before
                        ReloadRunspace();
                    }
                    if(this.hvcheckpointoperation.Equals("MoveVM"))
                    {
                        Logger.log("Init Going to call RegisterandCreatePsSession()");
                        RegisterandCreatePsSession();
                    }
                }
            }
            catch (Exception e)
            {
                Logger.log("Exception in c# constructor : " + e.Message + e.StackTrace);
            }
        }

        private void Initialize()
        {
            try
            {
                if (userName != "")
                {
                    SecureString securePassword = StringToSecureString(password);
                    String credName;
                    if (userName.Contains("\\") || userName.Contains("@"))
                    {
                        credName = userName;
                    }
                    else
                    {
                        credName = domainName + "\\" + userName;
                    }
                    this.creds = new PSCredential(credName, securePassword);
                }
                Logger.log("Initializing Remote Runspace");
                InitializeRemoteRunspace();
            }
            catch (Exception e)
            {
                Logger.log("Remote Exception Initialize() - " + e.Message);
            }
            if (!isRunspaceLoaded)
            {
                // For Later
                //if (!isCrossForest)
                //{
                //    InitializeRunspace();
                //}
                //else
                //{
                Logger.log(" Cannot try local runspace for across Forest mB ");
                //}
            }
        }

        private void CreatePowershell()
        {
            InitialSessionState iss = InitialSessionState.CreateDefault();
            iss.AuthorizationManager = new AuthorizationManager("MyShellId");
            powerShellRunspace = RunspaceFactory.CreateRunspace(iss);
            powerShellRunspace.Open();
            powershell = PowerShell.Create();
            powershell.Runspace = powerShellRunspace;
        }

        private string RunCmdletAsAdmin(string cmdlet)//Uac Issue
        {
            return "Start-Process Powershell -WindowStyle Hidden -Wait -verb runAs -ArgumentList {" + cmdlet + "}";
        }

        private void InitializeRemoteRunspace()
        {
            try
            {
                CreatePowershell();

                CreatePsSession();

                rmcommand.AddCommand("Set-ExecutionPolicy");
                rmcommand.AddArgument("RemoteSigned");
                rmcommand.AddParameter("Force");
                rmcommand.AddParameter("Scope", "process");
                ExecuteRemoteCommand(false);
                Logger.log("Set Execution Policy");

                /* Changes for HyperV */
                if (this.isHyperVSCVMM && !this.hvcheckpointoperation.Equals("MoveVM"))
                {
                    Logger.log("RemotePowershell: LOADING HYPER-V VIRTUALMACHINEMANAGER MODULE...");
                    rmcommand.AddScript("Invoke-Command -Session $session -Script {Import-Module VirtualMachineManager}");
                }else if(this.hvcheckpointoperation.Equals("vmware_fs_nfs_service")){
                    Logger.log("RemotePowershell: Ignoring module loads for VMware createNFSShare");
                }
                else if(this.hvcheckpointoperation!=null && !this.hvcheckpointoperation.Equals("") && !this.hvcheckpointoperation.Equals("MoveVM"))
                {
                    ExecuteRemoteCommand(false);
                    Logger.log("RemotePowershell: EXPORTING HYPER-V 2016 BACKUP and RESTORE MODULE to remote server...");
                    rmcommand.AddScript("Invoke-Command -Session $session -FilePath .\\hypervcheckpoint.ps1");
                    Logger.log("RemotePowershell: LOADED HYPER-V 2016 BACKUP and RESTORE MODULE...");
                }
                else
                {
                    Logger.log("RemotePowershell: LOADING GroupPolicy MODULE...");
                    rmcommand.AddScript("Invoke-Command -Session $session -Script {Import-Module GroupPolicy}");
                }

                if(this.hvcheckpointoperation.Equals("MoveVM"))
                {
                    //ExecuteRemoteCommand(false);
                    Logger.log("RemotePowershell: LOADING HYPER-V MODULE...");
                    rmcommand.AddScript("Invoke-Command -Session $session -Script {Import-Module hyper-v}");
                }


                int commandResult = ExecuteRemoteCommand(false);
                if (this.isHyperVSCVMM)
                {
                    Logger.log("Imported VIRTUALMACHINEMANAGER Module");
                }
                else if(this.hvcheckpointoperation!=null && !this.hvcheckpointoperation.Equals("") && !this.hvcheckpointoperation.Equals("MoveVM"))
                {
                    Logger.log("Imported HVCHECKPOINT Module");
                }
                else if(this.hvcheckpointoperation.Equals("MoveVM"))
                {
                    if(commandResult == 13)
                    {
                        Logger.log("HYPER-V Module not found");
                    }
                    else
                    {
                        Logger.log("Imported HYPER-V Module");
                    }
                }
                else
                {
                    Logger.log("Imported GroupPolicy Module");
                }

                isRunspaceLoaded = true;
                useRemoteShell = true;

                runSpaceHash = new Hashtable();
                runSpaceHash.Add("isRemoteShell", true);
                runSpaceHash.Add("runspace", powerShellRunspace);
                runSpaceHash.Add("powershell", powershell);
                runSpaceHash.Add("cachedTime", DateTime.Now);

                if (userName != "")
                {
                    runSpaceHash.Add("userName", userName);
                }
                RunSpaceCache.addRunSpaceHash(serverName, runSpaceHash);
                Logger.log("Initialized Remote Runspace");

                if(this.hvcheckpointoperation.Equals("MoveVM"))
                {
                    Logger.log("InitializeRemoteRunspace Going to call RegisterandCreatePsSession()");
                    RegisterandCreatePsSession();
                }

            }
            catch (CmdletInvocationException ex)
            {
                Logger.log("RemotePowershell: CmdletInvocationException  - " + ex.ErrorRecord.FullyQualifiedErrorId + ex.Message);
            }
            catch (ParseException ex)
            {
                Logger.log("RemotePowershell: ParseException  -   " + ex.ErrorRecord.FullyQualifiedErrorId + ex.Message);
            }
            catch (ParameterBindingException ex)
            {
                Logger.log("RemotePowershell: ParameterBindingException  -   " + ex.ErrorRecord.FullyQualifiedErrorId + ex.Message);
            }
            catch (CommandNotFoundException ex)
            {
                Logger.log("RemotePowershell: CommandNotFoundException  -   " + ex.ErrorRecord.FullyQualifiedErrorId + ex.Message);
            }
            catch (PSArgumentException ex)
            {
                Logger.log("RemotePowershell: PSArgumentException  -   " + ex.ErrorRecord.FullyQualifiedErrorId + ex.Message);
            }
            catch (Exception e)
            {
                Logger.log("RemotePowershell: Exception  -   " + e.Message);
                Logger.log(e.ToString());
            }
        }

        private void CreatePsSession()
        {
            rmcommand.AddCommand("New-PSSession");
            rmcommand.AddParameter("Computer", serverName);
            if (creds != null)
            {
                rmcommand.AddParameter("Credential", creds);
            }
            PSSessionOption sessionOption = new PSSessionOption();
            sessionOption.SkipCACheck = true;
            sessionOption.SkipCNCheck = true;
            sessionOption.SkipRevocationCheck = true;
            sessionOption.IdleTimeout = new TimeSpan(23, 23, 59, 59, 0);
            rmcommand.AddParameter("SessionOption", sessionOption);
            powershell.Commands = rmcommand;
            bool isSuccess = CreatePsSession(false);
            if (!isSuccess) {
                rmcommand.AddParameter("UseSSL");
                powershell.Commands = rmcommand;
                CreatePsSession(true);
            }   
        }

        private void RegisterandCreatePsSession()
        {
            int errorCode = 0;
            Logger.log("RegisterandCreatePsSession Method Called. ");
            String user,pass;
            if(userName.Contains("\\"))
            {
                user = userName;
            }
            else
            {
                user = domainName + "\\" + userName;
            }
            pass = password;
            rmcommand.AddScript("Invoke-Command -Session $session -Script {$user = '" + user + "'; $pass = '" + pass + "' | ConvertTo-SecureString -AsPlainText -Force}");
            errorCode = PsCmdletExec();
            if(errorCode != 0)
            {
                Logger.log("RegisterandCreatePsSession Method session is closed or broken. Creating session again ");
                CreatePsSession();
                rmcommand.AddScript("Invoke-Command -Session $session -Script {$user = '" + user + "'; $pass = '" + pass + "' | ConvertTo-SecureString -AsPlainText -Force}");
                errorCode = PsCmdletExec();
            }

            rmcommand.AddScript("Invoke-Command -Session $session -Script {$creds = New-Object -typename System.Management.Automation.PSCredential -argumentlist $user, $pass}");
            errorCode = PsCmdletExec();

            TimeSpan t = DateTime.UtcNow - new DateTime(1970, 1, 1);
            double millisecondsSinceEpoch = (double)t.TotalMilliseconds;

            String registerName = "registeredName"+millisecondsSinceEpoch.ToString();
            rmcommand.AddScript("Invoke-Command -Session $session -Script {Register-PSSessionConfiguration -Name '"+registerName+"' -SessionType DefaultRemoteShell -AccessMode Remote -RunAsCredential $creds -Force}");
            errorCode = PsCmdletExec();

            rmcommand.AddScript("Remove-PSSession $session");
            errorCode = PsCmdletExec();

            if (userName != "")
            {
                SecureString securePassword = StringToSecureString(password);
                String credName;
                if (userName.Contains("\\") || userName.Contains("@"))
                {
                    credName = userName;
                }
                else
                {
                    credName = domainName + "\\" + userName;
                }
                this.creds = new PSCredential(credName, securePassword);
            }

            rmcommand.Clear();

            Logger.log("RegisterandCreatePsSession creating another session. ");
            rmcommand.AddCommand("New-PSSession");
            rmcommand.AddParameter("Computer", serverName);
            if (creds != null)
            {
                rmcommand.AddParameter("Credential", creds);
            }
            PSSessionOption sessionOption = new PSSessionOption();
            sessionOption.SkipCACheck = true;
            sessionOption.SkipCNCheck = true;
            sessionOption.SkipRevocationCheck = true;
            sessionOption.IdleTimeout = new TimeSpan(11, 59, 59);
            rmcommand.AddParameter("SessionOption", sessionOption);
            rmcommand.AddParameter("ConfigurationName", registerName);
            powershell.Commands = rmcommand;
            bool isSuccess = CreatePsSession(false);
            if (!isSuccess) {
                rmcommand.AddParameter("UseSSL");
                powershell.Commands = rmcommand;
                CreatePsSession(true);
            }

            rmcommand.AddCommand("Set-ExecutionPolicy");
            rmcommand.AddArgument("RemoteSigned");
            rmcommand.AddParameter("Force");
            rmcommand.AddParameter("Scope", "process");
            ExecuteRemoteCommand(false);

            /*isRunspaceLoaded = true;
            useRemoteShell = true;

            runSpaceHash = new Hashtable();
            runSpaceHash.Add("isRemoteShell", true);
            runSpaceHash.Add("runspace", powerShellRunspace);
            runSpaceHash.Add("powershell", powershell);
            runSpaceHash.Add("cachedTime", DateTime.Now);

            if (userName != "")
            {
                runSpaceHash.Add("userName", userName);
            }
            RunSpaceCache.addRunSpaceHash(serverName, runSpaceHash);
            Logger.log("Initialized Remote Runspace");*/
        }



        private bool CreatePsSession(bool throwEx)
        {
            Collection<PSSession> result = powershell.Invoke<PSSession>();
            Logger.log("Remote Powershell Count: " + result.Count);
            if (result.Count != 1)
            {
                int exitCode = CollectResult();
                this.errorCode = exitCode;
                if (throwEx)
                {
                    Logger.log("Remote Powershell cannot be configured using https " + exitCode);
                    if (exitCode == 4)
                    {
                        throw new Exception("NoPrivileges");
                    }
                    throw new Exception("Unexpected number of Remote Runspace connections returned.");
                }
                else
                {
                    Logger.log("Remote Powershell cannot be configured using http " + exitCode);
                    return false;
                }
            }
            rmcommand.Clear();
            rmcommand.AddCommand("Set-Variable");
            rmcommand.AddParameter("Name", "session");
            rmcommand.AddParameter("Value", result[0]);
            ExecuteRemoteCommand(false);
            return true;
        }

        private SecureString StringToSecureString(String password)
        {
            SecureString remotePassword = new SecureString();
            for (int i = 0; i < password.Length; i++)
                remotePassword.AppendChar(password[i]);
            return remotePassword;
        }

        private void ReloadRunspace()
        {
            Logger.log("Reload Runspace..");
            DisposeRunspace();
            Logger.log("Initializing Runspace again...");
            Initialize();
        }

        private int ExecuteRemoteCommand()
        {
            return ExecuteRemoteCommand(true);
        }

        private int ExecuteRemoteCommand(bool checkRunspaceHash)
        {
            int status = ExecuteRemoteCommand(rmcommand, true, checkRunspaceHash);
            rmcommand.Clear();
            return status;
        }

        private int ExecuteRemoteCommand(PSCommand psCommand, bool retryOnSessionExpiry, bool checkRunspaceHash)
        {
            try
            {
                if (checkRunspaceHash && runSpaceHash == null)
                {
                    InitializeRemoteRunspace();
                }
                if (!this.isHyperVSCVMM && !this.thisisimportVMcommand)// && !this.addOutString)
                {
                    Logger.log("ExecuteRemoteCommand Adding out-string");
                    psCommand.Commands.Add("Out-String");                
                }
                else
                {
                    Logger.log("ExecuteRemoteCommand NOT Adding out-string");                    
                }

                powershell.Commands = psCommand;
                psResult = powershell.Invoke();
                if(storingResult){
                    foreach (PSObject obj in psResult){
                        Logger.log("info:"+obj.ToString());
                        returnResult = obj.ToString();
                    }
                }
                int exitCode = CollectResult();
                return exitCode;
            }
            catch (CmdletInvocationException ex)
            {
                Logger.log("RemotePowershell: CmdletInvocationException  -   " + psCommand + "  -   " + ex.Message);
                return 5;
            }
            catch (ParseException ex)
            {
                Logger.log("RemotePowershell: ParseException  -   " + psCommand + "  -   " + ex.Message);
                return 6;
            }
            catch (ParameterBindingException ex)
            {
                Logger.log("RemotePowershell: ParameterBindingException  -   " + psCommand + "  -   " + ex.Message);
                return 7;
            }
            catch (CommandNotFoundException ex)
            {
                Logger.log("RemotePowershell: CommandNotFoundException  -   " + psCommand + "  -   " + ex.Message);
                return 8;
            }
            catch (PSArgumentException ex)
            {
                Logger.log("RemotePowershell: PSArgumentException  -   " + psCommand + "  -   " + ex.Message);
                return 9;
            }
            catch (FileNotFoundException ex)
            {
                Logger.log("RemotePowershell: FileNotFoundException  -   " + psCommand + "  -   " + ex.Message);
                return 13;
            }
            catch (Exception e)
            {
                if (checkRunspaceHash)
                {
                    if (e.Message.Equals("Unexpected number of Remote Runspace connections returned."))
                    {
                        Logger.log("remoteShell cannot be established");
                        return 10;
                    }
                    else if (e.Message.Equals("NoPrivileges"))
                    {
                        Logger.log("The user which we gave in Organization page doesn't have a Privileges to run command");
                        return 4;
                    }
                    //ToDo: change to else if
                    else if ((e.Message.Contains("PromptForCredential") || e.Message.Equals("No valid sessions were specified") || e.Message.Equals("The session state is Broken") || e.Message.Equals("Connection lost")) && retryOnSessionExpiry)
                    {
                        Logger.log(e.Message + "\n Session Expired reinitializing runspace");
                        try
                        {
                            rmcommand.Clear();
                            ReloadRunspace();
                            Logger.log("Session Expired runspace reinitialized");
                            return ExecuteRemoteCommand(psCommand, false, true);
                        }
                        catch (Exception ex)
                        {
                            if (ex.Message.Equals("Unexpected number of Remote Runspace connections returned."))
                            {
                                Logger.log("Session Expired: remoteShell cannot be established - " + psCommand + "  -   " + ex.Message);
                                DisposeRunspace();
                                return 10;
                            }
                        }
                    }
                    Logger.log("RemotePowershell: Exception  -   " + psCommand + "  -   " + e.Message);
                    return 11;
                }
                else
                {
                    Logger.log("Local CmdLet: Exception  -   " + psCommand + "  -   " + e.Message);
                    return 12;
                }
            }
        }

        public int CollectResult()
        {
            int exitCode = 0;
            psError.Clear();
            Collection<ErrorRecord> errors = powershell.Streams.Error.ReadAll();
            bool errorSetHyperv = false;
            if (errors != null && errors.Count > 0)
            {
                String errorString = String.Empty;
                foreach (ErrorRecord er in errors)
                {
                    errorString = er.Exception.ToString();
                    psError.Add(errorString);
                    exitCode = errorCodes(errorString);
                    Logger.log("Execute Remote Command Error : " + er.FullyQualifiedErrorId + " -- " + errorString);
                    if(errorString.Contains("The operation failed because a virtual machine with the same identifier already exists")){
                         globalErrorCode = 852;
                    }else if(errorString.Contains("General access denied error")) {
                        globalErrorCode = 456;
                    }
                    else if(errorString.Contains("Could not find Ethernet switch") && this.hvcheckpointoperation.Equals("MoveVM"))
                    {
                        globalErrorCode = 858;
                    }
                    else if(errorString.Contains("Virtual Hard Disk file not found") && this.hvcheckpointoperation.Equals("MoveVM"))
                    {
                        globalErrorCode = 859;
                    }
                    else if(errorString.Contains("Failed to create planned Virtual Machine at migration destination") && this.hvcheckpointoperation.Equals("MoveVM"))
                    {
                        globalErrorCode = 860;
                    }
                    else if(errorString.Contains("Cannot validate argument on parameter 'VM'. The argument is null or empty.") && this.hvcheckpointoperation.Equals("MoveVM"))
                    {
                        globalErrorCode = 862;
                    }
                    else if(errorString.Contains("Migration did not succeed. Not enough disk space") && this.hvcheckpointoperation.Equals("MoveVM"))
                    {
                        globalErrorCode = 864;
                    }
                }
                if (this.isHyperVSCVMM)
                {
                    Logger.log("Error in excuting remote command for Hyper-V. Forming JSON object for error");
                    sb = new StringBuilder();

                    sb.Append("[{");
                    sb.Append(" \"error\" ");
                    sb.Append(":");
                    sb.Append("connection_failed");
                    sb.Append("}]");
                    errorSetHyperv = true;
                    //Logger.log("PsResult: " + sb.ToString());
                }
                powershell.Streams.Error.Clear();
            }
            powershell.Streams.Warning.Clear();

            /* Changes for HyperV */
            if (psResult != null && psResult.Count > 0)
            {
                Logger.log("psResult is not null");
                if(this.isHyperVSCVMM){
                    Logger.log("clearing string builder for hyper-v");
                    sb = new StringBuilder();
                }
                foreach (PSObject obj in psResult)
                {
                    if (this.isHyperVSCVMM)
                    {
                         //sb = new StringBuilder();

                        foreach (PSPropertyInfo property in obj.Properties)
                        {
                            Logger.log("Property name: " + property.Name);
                            if (property.Name.Equals("ComputerName"))
                            {
                                sb.Append(obj.Members[property.Name].Value + ";");
                            }
                        }
                    }

                    else
                    {
                        sb.Append(obj.ToString());
                        foreach (PSPropertyInfo property in obj.Properties)
                        {
                            //Logger.log("Else part Property name: " + property.Name);
                            if (property.Name.Equals("VMId") && !(this.hvcheckpointoperation.Equals("")))
                            {
                                hypervnewVMid = obj.Members[property.Name].Value.ToString();
                                Logger.log("GOT NEW HYPER-V VMID -> " + hypervnewVMid);
                            }
                        }

                    }
                }
                //Logger.log("PsResult: " + sb.ToString());
            }
            else
            {
                Logger.log("psResult is null");
                if (this.isHyperVSCVMM && (!errorSetHyperv))
                {
                    Logger.log("No Hyper-V servers available. Forming JSON object for error");
                    sb = new StringBuilder();
                    sb.Append("[{");
                    sb.Append(" \"error\" ");
                    sb.Append(":");
                    sb.Append("servers count zero");
                    sb.Append("}]");
                }
            }

            if(sb != null)
            {
                Logger.log("PsResult: " + sb.ToString());
            }
            else
            {
                Logger.log("PsResult: null");
            }

            return exitCode;
        }

        public int errorCodes(string errorString)
        {
            if (errorString.Contains("InvalidRunspaceStateException"))
            {
                return 1;
            }
            else if (errorString.Contains("PSInvalidOperationException"))
            {
                return 2;
            }
            else if (errorString.Contains("RuntimeException") && (errorString.Contains("reconnection attempt failed")))
            {
                return 3;
            }
            else if (errorString.Contains("PSRemotingTransportException"))//(errorString.Contains("isn't assigned to any management roles"))
            {
                return 4;
            }
            else if (errorString.Contains("RemoteException") && (errorString.Contains("no valid module file was found in any module directory")))
            {
                return 13;
            }
            else if (errorString.Contains("RemoteException") && (errorString.Contains("A GPO with ID")) && (errorString.Contains("was not found"))){
                return 20;
            }
            else if (errorString.Contains("RemoteException") && (errorString.Contains("Object reference not set to an instance of an object"))){
                return 21;
            }
            else if (errorString.Contains("RemoteException") && (errorString.Contains("The system cannot open the device or file specified"))){
                return 22;
            }
            else if (errorString.Contains("RemoteException") && (errorString.Contains("Error HRESULT E_FAIL has been returned from a call to a COM component"))){
                return 23;
            }
            else if (errorString.Contains("RemoteException") && (errorString.Contains("The library, drive, or media pool is empty"))){
                return 24;
            }
            else if (errorString.Contains("RemoteException") && (errorString.Contains("The specified directory service attribute or value does not exist"))){
                return 25;
            }
            else if (errorString.Contains("RemoteException") && (errorString.Contains("The system cannot find the path specified"))){
                return 26;
            }
            else if (errorString.Contains("RemoteException") && (errorString.Contains("The data is invalid"))){
                return 27;
            }
            else if (errorString.Contains("RemoteException") && (errorString.Contains("The specified module 'servermanager' was not loaded"))){
                return 28;
            }
            return 2048;
        }


        public void DisposeRunspace()
        {
            Logger.log("Disposing Runspace....");
            try
            {
                bool isRemoteShell = (bool)runSpaceHash["isRemoteShell"];
                if (isRemoteShell)// Should only use script to remoteSession only  
                {
                    RemoveSession();
                    powerShellRunspace.Dispose();
                }
                else
                {
                    powerShellRunspace.Dispose();
                }

                isRunspaceLoaded = false;
                powerShellRunspace = null;
                runSpaceHash = null;
                RunSpaceCache.removeRunSpaceHash(serverName);
            }
            catch (Exception e)
            {
                Logger.log("Dispose Exception -" + e.Message);
                Logger.log(e.ToString());
            }
        }

        public void RemoveSession()
        {
            try
            {
                rmcommand.AddScript("Remove-PSSession $session");
                ExecuteRemoteCommand(false);
                powershell.Dispose();
            }
            catch (Exception e)
            {
                Logger.log("Remove Session Er : " + e.Message + e.StackTrace);
            }
            finally
            {
                powershell = null;
            }
        }

        private int PsCmdletExec()
        {
            return ExecuteRemoteCommand();
        }

        public int backupGpo(String path, String gpoId)
        {
            Logger.log("Backup gpoId : " + gpoId);
            Logger.log("Gpo Path : " + path);
            rmcommand.AddScript("Invoke-Command -Session $session -Script {Backup-GPO -Guid " + gpoId + " -Path " + path + " -Server " + serverName + "}");
            return PsCmdletExec();
        }

        public int restoreGpo(String path, String gpoId)
        {
            Logger.log(" Restore gpoId : " + gpoId);
            Logger.log("Gpo Path : " + path);
            rmcommand.AddScript("Invoke-Command -Session $session -Script {Restore-GPO -BackupId " + gpoId + " -Path " + path + " -Server " + serverName + "}");
            return PsCmdletExec();
        }

        public int deleteGpo(String path, String gpoId)
        {
            Logger.log("gpoId : " + gpoId);
            Logger.log("Gpo Path : " + path);
            rmcommand.AddScript("Invoke-Command -Session $session -Script {Remove-GPO -Guid " + gpoId + " -Server " + serverName+ "}");
            return PsCmdletExec();
        }

        public int runRemotePowershellCmdlet(String cmdlet)
        {
            Logger.log("runRemotePowershellCmdlet Method Called . .");
            rmcommand.AddScript("Invoke-Command -Session $session -Script {" + cmdlet + "}");
            return PsCmdletExec();
        }

        /* Changes for HyperV */
        public string runRemotePowershellCmdletandreturnResults(String cmdlet)
        {
            Logger.log("runRemotePowershellCmdletandreturnResults Method Called. Commandlet -> " + cmdlet);
            rmcommand.AddScript("Invoke-Command -Session $session -Script {" + cmdlet + "}");
            PsCmdletExec();
            if(sb.ToString().Contains("connection_failed"))
            {
                String scriptfor2008r2 = "       Add-PSSnapin Microsoft.SystemCenter.VirtualMachineManager            \n" + cmdlet;
                rmcommand.AddScript("Invoke-Command -Session $session -Script {" + scriptfor2008r2 + "}");
                Logger.log("runRemotePowershellCmdletandreturnResults failed. Trying Systemcenter 2008 r2 Commandlet -> " + scriptfor2008r2);
                PsCmdletExec();
            }
            return sb.ToString();
        }

        public string runRemotePowershellCmdletandreturnResultsForVMware(String cmdlet)
        {
            Logger.log("runRemotePowershellCmdletandreturnResultsForVMware Method Called. Commandlet -> " + cmdlet);
            rmcommand.AddScript("Invoke-Command -Session $session -Script {" + cmdlet + "}");
            storingResult = true;
            PsCmdletExec();
            if(sb.ToString().Contains("connection_failed"))
            {
                String scriptfor2008r2 = "       Add-PSSnapin Microsoft.SystemCenter.VirtualMachineManager            \n" + cmdlet;
                rmcommand.AddScript("Invoke-Command -Session $session -Script {" + scriptfor2008r2 + "}");
                Logger.log("runRemotePowershellCmdletandreturnResults failed. Trying Systemcenter 2008 r2 Commandlet -> " + scriptfor2008r2);
                PsCmdletExec();
            }
            return returnResult;
        }

         public int dohvcheckpointbackupinCS(String vmName, String repositoryPath, String backupName, String backupIdentifier, String previousbackupIdentifier,
            String repositoryUser, String repositoryPassword)
        {
            Logger.log("dohvcheckpointbackupinCS Method Called. vmName -> " + vmName + ". repositoryPath-> " + repositoryPath + ". repositoryUser-> " + repositoryUser);
            Logger.log("dohvcheckpointbackupinCS Method Called. backupIdentifier -> " + backupIdentifier + ". previousbackupIdentifier-> " + previousbackupIdentifier);
            repositoryPath = repositoryPath.Replace("`", "``"); // in powershell  backtick(`) character is an escaping character.
            //Connect to repository
            Logger.log("dohvcheckpointbackupinCS Calling connecttoNetworkPath");
            bool isConnected = connecttoNetworkPath(repositoryPath, repositoryUser, repositoryPassword);
            Logger.log("dohvcheckpointbackupinCS connecttoNetworkPath Returned -> " + isConnected);

            //New-VmBackupCheckpoint
            Logger.log("dohvcheckpointbackupinCS Going to call New-VmBackupCheckpoint");
            rmcommand.AddScript("Invoke-Command -Session $session -Script {$createdcheckPoint = New-VmBackupCheckpoint -VmName '"+vmName+"' -ConsistencyLevel CrashConsistent}");            
            int errorCode = PsCmdletExec();
            Logger.log("New-VmBackupCheckpoint Error code -> " + errorCode);
            Logger.log("New-VmBackupCheckpoint Return String -> " + sb.ToString());
            if(errorCode!=0)
            {
                Logger.log("New-VmBackupCheckpoint Returning Error code: "+ errorCode);
                //Disconnect from repository
                Logger.log("dohvcheckpointbackupinCS Calling disconnectNetworkPath");
                bool isDisconnected = disconnectNetworkPath(repositoryPath);
                Logger.log("dohvcheckpointbackupinCS disconnectNetworkPath Returned -> " + isDisconnected);
                return 451;
            }

            //export-vmbackupcheckpoint
            Logger.log("dohvcheckpointbackupinCS Going to call Export-VmBackupCheckpoint");
            if(previousbackupIdentifier!=null && !previousbackupIdentifier.Equals("-") && this.hvcheckpointoperation.Equals("IncrBackup"))
            {
                //incr backup
                Logger.log("dohvcheckpointbackupinCS this is an incremental backup. Constructing Reference point. previousbackupIdentifier -> " + previousbackupIdentifier);

                //Constructing previous reference point
                bool isrefPointConstructed = false;
                String previousreferencepointxmlFile = ".\\hyper-v_reference_points\\hvreferencepoint_" + backupName + "_" + previousbackupIdentifier + "_" + vmName + ".xml";
                Logger.log("dohvcheckpointbackupinCS previousreferencepointxmlFile -> " + previousreferencepointxmlFile);
                rmcommand.AddScript("$ref = Import-Clixml '"+previousreferencepointxmlFile+"'");            
                errorCode = PsCmdletExec();
                if(errorCode==0)
                {
                    Logger.log("Import-CliXML Success");
                    rmcommand.AddScript("Invoke-Command -Session $session -Script {Set-Variable -Name constructedreferencePoint -Value $($args[0])} -ArgumentList $ref");            
                    errorCode = PsCmdletExec();
                    if(errorCode==0)
                    {
                        Logger.log("Exporting Obeject SUCCESS..!");
                        isrefPointConstructed=true;
                    }
                    else
                    {
                        Logger.log("Exporting Obeject Returning Error code: "+ errorCode);
                        Logger.log("Exporting Obeject Returning Error string: "+ sb.ToString());
                    }
                }
                else
                {
                    Logger.log("Import-CliXML Returning Error code: "+ errorCode);
                    Logger.log("Import-CliXML Returning Error string: "+ sb.ToString());
                }

                //Constructing Export commandlet
                if(!isrefPointConstructed)
                {
                    //todo
                    Logger.log("Import-CliXML isrefPointConstructed is False. Returning Error code: "+ errorCode+". Returning 455");  
                    //Disconnect from repository
                    Logger.log("dohvcheckpointbackupinCS Calling disconnectNetworkPath");
                    bool isDisconnected = disconnectNetworkPath(repositoryPath);
                    Logger.log("dohvcheckpointbackupinCS disconnectNetworkPath Returned -> " + isDisconnected);
                    return 455;                 
                }
                else
                {
                    Logger.log("Import-CliXML SUCCESS. Taking incremental backup."); 
                    rmcommand.AddScript("Invoke-Command -Session $session -Script {Export-VmBackupCheckpoint -VmName '"+vmName+"' -DestinationPath \""+repositoryPath+"\" -BackupCheckPoint $createdcheckPoint -ReferencePoint $constructedreferencePoint.__PATH}");
                }
            }
            else
            {
                //Full backup
                Logger.log("dohvcheckpointbackupinCS this is a full backup. Hence NOT Constructing Reference point. ");
                rmcommand.AddScript("Invoke-Command -Session $session -Script {Export-VmBackupCheckpoint -VmName '"+vmName+"' -DestinationPath \""+repositoryPath+"\" -BackupCheckPoint $createdcheckPoint}");
            }

            errorCode = PsCmdletExec();
            Logger.log("Export-VmBackupCheckpoint Error code -> " + errorCode);
            Logger.log("Export-VmBackupCheckpoint Return String -> " + sb.ToString());
            if(errorCode!=0)
            {
                Logger.log("Export-VmBackupCheckpoint Returning Error code: "+ errorCode);
                //Disconnect from repository
                Logger.log("dohvcheckpointbackupinCS Calling disconnectNetworkPath");
                bool isDisconnected = disconnectNetworkPath(repositoryPath);
                Logger.log("dohvcheckpointbackupinCS disconnectNetworkPath Returned -> " + isDisconnected);
                if(globalErrorCode == 456){
                    globalErrorCode = 0;
                    return 456;
                }
                return 452;
            }
            
            //Convert-VmBackupCheckpoint
            Logger.log("dohvcheckpointbackupinCS Going to call Convert-VmBackupCheckpoint");
            rmcommand.AddScript("Invoke-Command -Session $session -Script {$referencePoint = Convert-VmBackupCheckpoint -BackupCheckpoint $createdcheckPoint}");            
            errorCode = PsCmdletExec();
            Logger.log("Convert-VmBackupCheckpoint Error code -> " + errorCode);
            Logger.log("Convert-VmBackupCheckpoint Return String -> " + sb.ToString());
            if(errorCode!=0)
            {
                Logger.log("Convert-VmBackupCheckpoint Returning Error code: "+ errorCode);
                //Disconnect from repository
                Logger.log("dohvcheckpointbackupinCS Calling disconnectNetworkPath");
                bool isDisconnected = disconnectNetworkPath(repositoryPath);
                Logger.log("dohvcheckpointbackupinCS disconnectNetworkPath Returned -> " + isDisconnected);
                return 453;
            } 

            //Save reference point to xml file
            String referencepointxmlFile = ".\\hyper-v_reference_points\\hvreferencepoint_" + backupName + "_" + backupIdentifier + "_" + vmName + ".xml";
            Logger.log("dohvcheckpointbackupinCS Going to call Export-CliXML. referencepointxmlFile -> " + referencepointxmlFile);
            rmcommand.AddScript("Invoke-Command -Session $session -Script {$referencePoint} | Export-Clixml '"+referencepointxmlFile+"'");            
            errorCode = PsCmdletExec();
            Logger.log("Export-CliXML Error code -> " + errorCode);
            Logger.log("Export-CliXML Return String -> " + sb.ToString());
            if(errorCode!=0)
            {
                Logger.log("Export-CliXML Returning Error code: "+ errorCode);
                //Disconnect from repository
                Logger.log("dohvcheckpointbackupinCS Calling disconnectNetworkPath");
                bool isDisconnected = disconnectNetworkPath(repositoryPath);
                Logger.log("dohvcheckpointbackupinCS disconnectNetworkPath Returned -> " + isDisconnected);
                return 454;
            }   

            //Disconnect from repository
            Logger.log("dohvcheckpointbackupinCS Calling disconnectNetworkPath");
            bool isDisconnect = disconnectNetworkPath(repositoryPath);
            Logger.log("dohvcheckpointbackupinCS disconnectNetworkPath Returned -> " + isDisconnect);
            return errorCode;
        }

        public int dohvcheckpointrestoreinCS(String serverName, String vmName, String repositoryPath, String restoreType, String vhdDestinationPath, String defaultVHDlocationindestinationHVserver,
         String previousbackuprepositoryPaths, String ischangeVMName, String newVMName, String isPowerOn, String currentrestorerepositoryPathUser, String currentrestorerepositoryPathPassword)
        {
            Logger.log("dohvcheckpointrestoreinCS Method Called. vmName -> " + vmName + ". repositoryPath-> " + repositoryPath);

            
            String vmcxfilePath = repositoryPath + "\\" + vmName + "\\Virtual Machines\\" + vmName + ".vmcx";
            Logger.log("dohvcheckpointrestoreinCS repositoryPath -> " + repositoryPath);
            Logger.log("dohvcheckpointrestoreinCS vmName -> " + vmName);
            Logger.log("dohvcheckpointrestoreinCS vmcxfilePath -> " + vmcxfilePath);
            Logger.log("dohvcheckpointrestoreinCS vhdDestinationPath -> " + vhdDestinationPath);
            Logger.log("dohvcheckpointrestoreinCS restoreType -> " + restoreType);
            Logger.log("dohvcheckpointrestoreinCS defaultVHDlocationindestinationHVserver -> " + defaultVHDlocationindestinationHVserver);
            Logger.log("dohvcheckpointrestoreinCS previousbackuprepositoryPaths -> " + previousbackuprepositoryPaths);
            Logger.log("dohvcheckpointrestoreinCS ischangeVMName -> " + ischangeVMName);
            Logger.log("dohvcheckpointrestoreinCS newVMName -> " + newVMName);
            Logger.log("dohvcheckpointrestoreinCS isPowerOn -> " + isPowerOn);
            Logger.log("dohvcheckpointrestoreinCS currentrestorerepositoryPathUser -> " + currentrestorerepositoryPathUser);
            Logger.log("dohvcheckpointrestoreinCS Going to call Import-VM");

            //Connect to repository
            Logger.log("dohvcheckpointrestoreinCS Calling connecttoNetworkPath");
            bool isConnected = connecttoNetworkPath(repositoryPath, currentrestorerepositoryPathUser, currentrestorerepositoryPathPassword);
            Logger.log("dohvcheckpointrestoreinCS connecttoNetworkPath Returned -> " + isConnected);

            String importCommand="";

            //Import-VM
            int restoreFormat = Convert.ToInt32(restoreType);
            Logger.log("dohvcheckpointrestoreinCS restoreFormat -> " + restoreFormat);
            String finaldestinationPath = "-";
            if(vhdDestinationPath.Equals("-"))//default location. 
            {
                finaldestinationPath = defaultVHDlocationindestinationHVserver;
            }
            else
            {
                finaldestinationPath = vhdDestinationPath;
            }
            if(!finaldestinationPath.EndsWith("\\"))
            {
                finaldestinationPath = finaldestinationPath + "\\";
            }
            TimeSpan t = DateTime.UtcNow - new DateTime(1970, 1, 1);
            double millisecondsSinceEpoch = (double)t.TotalMilliseconds;
            finaldestinationPath = finaldestinationPath + millisecondsSinceEpoch.ToString();
            /*check if finaldestinationPath ends with \. If not, add \ at the end. Then add some unique folder. In copyfiles method, convert it to admin share format*/

            Logger.log("dohvcheckpointrestoreinCS finaldestinationPath -> " + finaldestinationPath); 
            String finaldestinationadminsharePath = "-";
            int copyStatus = -1;
            switch(restoreFormat)
            {
                case 1: //Full restore from full backup
                //Turn oFF VM
                Logger.log("dohvcheckpointrestoreinCS Full restore from full backup Going to turn off old virtual machine with Id -> " + vmName);
                turnoffHVvirtualmachine(vmName);             

                //Delete old VM
                Logger.log("dohvcheckpointrestoreinCS Full restore from full backup Going to delete old virtual machine with Id -> " + vmName);
                deleteHVvirtualmachine(vmName);

                importCommand = "Invoke-Command -Session $session -Script {Import-VM -Path '" + vmcxfilePath + "' -Copy -VhdDestinationPath '" + finaldestinationPath + "'}";
                break;
                
                

                case 2: //Full restore from incr backup
                //Turn oFF VM
                Logger.log("dohvcheckpointrestoreinCS Full restore from full backup Going to turn off old virtual machine with Id -> " + vmName);
                turnoffHVvirtualmachine(vmName);
                
                //Delete old VM
                Logger.log("dohvcheckpointrestoreinCS Full restore from incr backup Going to delete old virtual machine with Id -> " + vmName);
                deleteHVvirtualmachine(vmName);                          
                             

                //Copy VHD files from previous backups
                Logger.log("dohvcheckpointrestoreinCS Calling copyVHDfilesfrompreviousbackups!");
                finaldestinationadminsharePath = convertlocaltoadminsharePath(finaldestinationPath, serverName);
                Logger.log("dohvcheckpointrestoreinCS finaldestinationadminsharePath -> " + finaldestinationadminsharePath);
                copyStatus = copyVHDfilesfrompreviousbackups(previousbackuprepositoryPaths, finaldestinationadminsharePath);
                Logger.log("dohvcheckpointrestoreinCS Finished calling copyVHDfilesfrompreviousbackups!");
                if(copyStatus!=0)
                {
                    Logger.log("dohvcheckpointrestoreinCS ERROR in copyVHDfilesfrompreviousbackups. Returning error code and exiting -> " + copyStatus);
                    return 855;
                }

                //Perform the final incremental backup
                importCommand = "Invoke-Command -Session $session -Script {Import-VM -Path '" + vmcxfilePath + "' -Copy -VhdDestinationPath '" + finaldestinationPath + "'}";
                break;
                
                

                case 3: //Disk restore from full backup
                break;
               
               

                case 4: //Disk restore from incr backup
                break;
               
               

                case 5: //New VM restore from full backup
                importCommand = "Invoke-Command -Session $session -Script {Import-VM -Path '" + vmcxfilePath + "' -Copy -GenerateNewId -VhdDestinationPath '" + finaldestinationPath + "'}";
                break;
               
                

                case 6: //New VM restore from incr backup
                //Copy VHD files from previous backups
                Logger.log("dohvcheckpointrestoreinCS New VM restore from incr backup Calling copyVHDfilesfrompreviousbackups!");   
                finaldestinationadminsharePath = convertlocaltoadminsharePath(finaldestinationPath, serverName);
                Logger.log("dohvcheckpointrestoreinCS finaldestinationadminsharePath -> " + finaldestinationadminsharePath);             
                copyStatus = copyVHDfilesfrompreviousbackups(previousbackuprepositoryPaths, finaldestinationadminsharePath);
                Logger.log("dohvcheckpointrestoreinCS Finished calling copyVHDfilesfrompreviousbackups!");
                if(copyStatus!=0)
                {
                    Logger.log("dohvcheckpointrestoreinCS ERROR in copyVHDfilesfrompreviousbackups. Returning error code and exiting -> " + copyStatus);
                     //Disconnect from repository
                    Logger.log("dohvcheckpointrestoreinCS Calling disconnectNetworkPath");
                    bool isDisconnected = disconnectNetworkPath(repositoryPath);
                    Logger.log("dohvcheckpointrestoreinCS disconnectNetworkPath Returned -> " + isDisconnected);
                    return 855;
                }

                //Perform final incr restore
                importCommand = "Invoke-Command -Session $session -Script {Import-VM -Path '" + vmcxfilePath + "' -Copy -GenerateNewId -VhdDestinationPath '" + finaldestinationPath + "'}";                
                break;

                case 7: //live VM migration
                Logger.log("dohvcheckpointrestoreinCS Live VM Migration");
                importCommand = "Invoke-Command -Session $session -Script {Import-VM -Path '" + vmcxfilePath + "' -Register}";
                break;
               
                default: Logger.log("dohvcheckpointrestoreinCS Invalid restore type.");
                return 850;
            }

            Logger.log("dohvcheckpointrestoreinCS importCommand -> " + importCommand);
            rmcommand.AddScript(importCommand);    

            this.thisisimportVMcommand=true;
            int errorCode = PsCmdletExec();
            this.thisisimportVMcommand=false;
            Logger.log("Import-VM Error code -> " + errorCode);
            Logger.log("Import-VM Return String -> " + sb.ToString());
            if(errorCode!=0)
            {
                Logger.log("Import-VM Returning Error code: "+ errorCode);
                 //Disconnect from repository
                Logger.log("dohvcheckpointrestoreinCS Calling disconnectNetworkPath");
                bool isDisconnected = disconnectNetworkPath(repositoryPath);
                Logger.log("dohvcheckpointrestoreinCS disconnectNetworkPath Returned -> " + isDisconnected);
                Logger.log(" restoreFormat " + restoreFormat + " liveMigrationErr " + globalErrorCode );
                if(restoreFormat == 7 && globalErrorCode == 852){
                    Logger.log("live migration to the same host error encounted ...");
                    globalErrorCode = 0;
                    return 852;
                }
                return 851;
            }     

            //Change VM name
            String newVMId = hypervnewVMid;
            Logger.log("dohvcheckpointrestoreinCS returned newID -> " + newVMId);
            if(ischangeVMName!=null && ischangeVMName.Equals("true") && !newVMId.Equals("-"))
            {
                Logger.log("dohvcheckpointrestoreinCS Going to change VM name.");
                renameHVvirtualmachine(newVMId, newVMName);
            }  

            //Start VM
            if(isPowerOn!=null && isPowerOn.Equals("true") && !newVMId.Equals("-"))
            {
                Logger.log("dohvcheckpointrestoreinCS Going to start VM.");
                startHVvirtualmachine(newVMId);
            }     

             //Disconnect from repository
            Logger.log("dohvcheckpointrestoreinCS Calling disconnectNetworkPath");
            bool isDisconnect = disconnectNetworkPath(repositoryPath);
            Logger.log("dohvcheckpointrestoreinCS disconnectNetworkPath Returned -> " + isDisconnect);
            return errorCode;
        }

        public int dohvmovevminCS(String hvVMId, String newVMName, String destinationHost, String destinationPath, String powerOn)
        {
        	Logger.log("dohvmovevminCS Method Called. hvVMId -> " + hvVMId + ".");

        	int errorCode;
        	globalErrorCode = 0;

            rmcommand.AddScript("Invoke-Command -Session $session -Script {$vm = Get-VM -Id '"+hvVMId+"'}");
            errorCode = PsCmdletExec();

            Logger.log("dohvmovevminCS Going to call Checkpoint-VM");
        	rmcommand.AddScript("Invoke-Command -Session $session -Script {Checkpoint-VM -VM $vm}");
        	errorCode = PsCmdletExec();
        	if(errorCode!=0)
        	{
        		Logger.log("Checkpoint-VM Returning Error code: "+ errorCode);
        		if(globalErrorCode == 862)
        		{
        		    return 862;
        		}
        		else
        		{
        		    return 451;
        		}
        	}

        	String user,pass;
            if(userName.Contains("\\"))
            {
                user = userName;
            }
            else
            {
                user = domainName + "\\" + userName;
            }
            pass = password;
            rmcommand.AddScript("Invoke-Command -Session $session -Script {$user = '" + user + "'; $pass = '" + pass + "' | ConvertTo-SecureString -AsPlainText -Force}");
            errorCode = PsCmdletExec();

            rmcommand.AddScript("Invoke-Command -Session $session -Script {$creds = New-Object -typename System.Management.Automation.PSCredential -argumentlist $user, $pass}");
            errorCode = PsCmdletExec();


            Logger.log("dohvmovevminCS Going to call Get-WmiObject");
        	rmcommand.AddScript("Invoke-Command -Session $session -Script {$info = Get-WmiObject -ComputerName '" +destinationHost+ "' -Credential $creds -Namespace 'root\\cimv2' -Class Win32_ComputerSystem}");
            errorCode = PsCmdletExec();

            if(!destinationPath.EndsWith("\\"))
            {
                destinationPath = destinationPath + "\\";
            }
            TimeSpan t = DateTime.UtcNow - new DateTime(1970, 1, 1);
            double millisecondsSinceEpoch = (double)t.TotalMilliseconds;
            destinationPath = destinationPath + millisecondsSinceEpoch.ToString();

            Logger.log("dohvmovevminCS Going to call $info.PSComputerName");

            rmcommand.AddScript("Invoke-Command -Session $session -Script {$info.PSComputerName}");
            errorCode = PsCmdletExec();

        	Logger.log("dohvmovevminCS Going to call Move-VM -VM $vm -DestinationHost '"+destinationHost+"' -DestinationStoragePath '"+destinationPath+"' -RetainVhdCopiesOnSource");

        	rmcommand.AddScript("Invoke-Command -Session $session -Script {Move-VM -VM $vm -DestinationHost $info.PSComputerName -DestinationStoragePath '"+destinationPath+"' -RetainVhdCopiesOnSource}");
        	errorCode = PsCmdletExec();
        	if(errorCode!=0)
        	{
        		Logger.log("Move-VM Returning Error code: "+ errorCode);
        		Logger.log("Execute Remote Command Error : "  + globalErrorCode);

        		if(globalErrorCode == 858 || globalErrorCode == 859 || globalErrorCode == 860 || globalErrorCode == 864)
        		{
        		    //RemoveSession();
        		    return globalErrorCode;
                }
                else
                {
                    //RemoveSession();
                    return errorCode;
                }
        	}
        	Logger.log("dohvmovevmincs going to rename vm ");
            rmcommand.AddScript("Invoke-Command -Session $session -Script {Get-VM -Id '"+hvVMId+"' -ComputerName $info.PSComputerName | Rename-VM -NewName '"+ newVMName +"'}");
            PsCmdletExec();

        	if(powerOn!=null && powerOn.Equals("TRUE"))
        	{
        		Logger.log("dohvmovevminCS Going to call Start-VM");
        		rmcommand.AddScript("Invoke-Command -Session $session -Script {Get-VM -Id '"+hvVMId+"' -ComputerName $info.PSComputerName | Start-VM }");
        		errorCode = PsCmdletExec();
        		if(errorCode!=0)
        		{
        		    //RemoveSession();
        			Logger.log("Start-VM Returning Error code: "+ errorCode);
        			Logger.log("Execute Remote Command Error : "  + globalErrorCode);
        			return 828;
        		}
        	}


        	return errorCode;
        }

        public void renameHVvirtualmachine(String vmId, String newName)    
        {
            Logger.log("PowershellHandler.cs renameHVvirtualmachine VMid -> " + vmId);
            try
            {
               Logger.log("dohvcheckpointrestoreinCS Going to rename VM.");
               rmcommand.AddScript("Invoke-Command -Session $session -Script {Get-VM -Id '" + vmId + "' | Rename-VM -NewName '" + newName + "'}");            
               int errorCode = PsCmdletExec();
               Logger.log("Rename-VM Error code -> " + errorCode);
               Logger.log("Rename-VM Return String -> " + sb.ToString());
               if(errorCode!=0)
               {
                    Logger.log("Unable to Rename VM. Rename-VM Returned Error code: "+ errorCode);    
                    Logger.log("Not critical error. hence resetting to success");
                    errorCode =0;
                }                
            }
            catch(Exception ex)
            {
                Logger.log("renameHVvirtualmachine Ex : " + ex);                
            }
        } 

        public void startHVvirtualmachine(String vmId)    
        {
            Logger.log("PowershellHandler.cs startHVvirtualmachine VMid -> " + vmId);
            try
            {
               Logger.log("dohvcheckpointrestoreinCS Going to start VM.");
               rmcommand.AddScript("Invoke-Command -Session $session -Script {Get-VM -Id '" + vmId + "' | Start-VM }");            
               int errorCode = PsCmdletExec();
               Logger.log("Start-VM Error code -> " + errorCode);
               Logger.log("Start-VM Return String -> " + sb.ToString());
               if(errorCode!=0)
               {
                    Logger.log("Unable to Start VM. Start-VM Returned Error code: "+ errorCode);    
                    Logger.log("Not critical error. hence resetting to success");
                    errorCode =0;
                }                
            }
            catch(Exception ex)
            {
                Logger.log("startHVvirtualmachine Ex : " + ex);                
            }
        } 

        public void turnoffHVvirtualmachine(String vmId)    
        {
            Logger.log("PowershellHandler.cs turnoffHVvirtualmachine VMid -> " + vmId);
            try
            {
               Logger.log("dohvcheckpointrestoreinCS Going to turn off VM.");
               rmcommand.AddScript("Invoke-Command -Session $session -Script {Get-VM -Id '" + vmId + "' | Stop-VM -Force }");            
               int errorCode = PsCmdletExec();
               Logger.log("Stop-VM Error code -> " + errorCode);
               Logger.log("Stop-VM Return String -> " + sb.ToString());
               if(errorCode!=0)
               {
                    Logger.log("Unable to stop VM. Stop-VM Returned Error code: "+ errorCode);    
                    Logger.log("Not critical error. hence resetting to success");
                    errorCode =0;
                }                
            }
            catch(Exception ex)
            {
                Logger.log("turnoffHVvirtualmachine Ex : " + ex);                
            }
        }


        public void deleteHVvirtualmachine(String vmId)
        {
            Logger.log("PowershellHandler.cs deleteHVvirtualmachine VMid -> " + vmId);
            try
            {
                Logger.log("deleteHVvirtualmachine Going to call Remove-VM");
                rmcommand.AddScript("Invoke-Command -Session $session -Script {Get-VM -Id '" + vmId + "' | Remove-VM -Force}");            
                int errorCode = PsCmdletExec();
                Logger.log("deleteHVvirtualmachine Error code -> " + errorCode);
                Logger.log("deleteHVvirtualmachine Return String -> " + sb.ToString());
                if(errorCode!=0)
                {
                    Logger.log("deleteHVvirtualmachine Returning Failed..!");
                    Logger.log("Not critical error. hence resetting to success");
                    errorCode =0;                    
                }                    
            }
            catch(Exception ex)
            {
                Logger.log("deleteHVvirtualmachine Ex : " + ex);                
            }
        }

        public int copyVHDfilesfrompreviousbackups(string previousbackuprepositoryPaths, string destinationPath)
        {
            Logger.log("PowershellHandler.cs copyVHDfilesfrompreviousbackups previousbackuprepositoryPaths -> " + previousbackuprepositoryPaths + "destinationPath -> " + destinationPath);
            try
            {
                if(previousbackuprepositoryPaths.EndsWith(";"))
                {
                    previousbackuprepositoryPaths = previousbackuprepositoryPaths.Substring(0,(previousbackuprepositoryPaths.Length - 1));
                }
                if (previousbackuprepositoryPaths != null && !(previousbackuprepositoryPaths.Equals("-")))
                {
                    Logger.log("copyVHDfilesfrompreviousbackups Going to split previousbackuprepositoryPaths.");

                    string[] allrepositoryPaths = previousbackuprepositoryPaths.Split(';');
                    foreach(string currentrepositoryPath in allrepositoryPaths)
                    {
                        Logger.log("copyVHDfilesfrompreviousbackups Going to copy from repositoryPath -> " + currentrepositoryPath);
                        Copyallfilesindirectory(currentrepositoryPath, destinationPath);
                        Logger.log("copyVHDfilesfrompreviousbackups Finished calling Copyallfilesindirectory");
                    }                    
                }
                return 0;
            }
            catch(Exception ex)
            {
                Logger.log("copyVHDfilesfrompreviousbackups Ex : " + ex);
                return -1;
            }
        }

        public void Copyallfilesindirectory(string sourceDir, string targetDir)
        {
            Directory.CreateDirectory(targetDir);

            foreach (String file in Directory.GetFiles(sourceDir))
            {
                if(!(Path.GetFileName(file).Contains("_compress")))
                { //don't copy compressed files
                    File.Copy(file, Path.Combine(targetDir, Path.GetFileName(file)), true);
                }
            }

            foreach (String directory in Directory.GetDirectories(sourceDir))
                Copyallfilesindirectory(directory, Path.Combine(targetDir, Path.GetFileName(directory)));
        }

        public String convertlocaltoadminsharePath(String finaldestinationPath, String serverName)
        {
            Logger.log("convertlocaltoadminsharePath started. finaldestinationPath -> " + finaldestinationPath);
            Logger.log("convertlocaltoadminsharePath started. serverName -> " + serverName);
            String adminsharePath = "-";
            try
            {
                adminsharePath = "\\\\" + serverName + "\\";
                int pos = finaldestinationPath.IndexOf("\\");
                adminsharePath = adminsharePath + finaldestinationPath.Substring(0, pos-1) + "$\\" + finaldestinationPath.Substring(pos + 1);
                Logger.log("convertlocaltoadminsharePath  adminsharePath -> " + adminsharePath);
            }
            catch(Exception ex)
            {
                Logger.log("convertlocaltoadminsharePath Ex : " + ex);
                return "-";
            }
            Logger.log("convertlocaltoadminsharePath Returning adminsharePath -> " + adminsharePath);
            return adminsharePath;
        }

        public bool connecttoNetworkPath(String networkPath, String domainUser, String networkpassword)
        {
            Logger.log("connecttoNetworkPath started." );
            bool isConnected = true;
            try
            {
                rmcommand.AddScript("Invoke-Command -Session $session -Script {net use \""+networkPath+"\" /user:'"+domainUser+"' '"+networkpassword+"'}");
                int errorCode = PsCmdletExec();
                Logger.log("connecttoNetworkPath Error code -> " + errorCode);
                Logger.log("connecttoNetworkPath Return String -> " + sb.ToString());
                if(errorCode!=0)
                {
                    Logger.log("connecttoNetworkPath Returning Failed..!");
                    isConnected = false;                  
                }  
            }
            catch(Exception ex)
            {
                Logger.log("connecttoNetworkPath Ex : " + ex);
                isConnected = false;
            }
            Logger.log("connecttoNetworkPath ended." );
            return isConnected;
        }

        public bool disconnectNetworkPath(String networkPath)
        {
            Logger.log("disconnectNetworkPath started." );
            bool isDisconnected = true;
            try
            {
                rmcommand.AddScript("Invoke-Command -Session $session -Script {net use /delete \""+networkPath+"\"}");
                int errorCode = PsCmdletExec();
                Logger.log("disconnectNetworkPath Error code -> " + errorCode);
                Logger.log("disconnectNetworkPath Return String -> " + sb.ToString());
                if(errorCode!=0)
                {
                    Logger.log("disconnectNetworkPath Returning Failed..!");
                    isDisconnected = false;                  
                }  
            }
            catch(Exception ex)
            {
                Logger.log("disconnectNetworkPath Ex : " + ex);
                isDisconnected = false;
            }
            Logger.log("disconnectNetworkPath ended." );
            return isDisconnected;
        }

    }

    public static class RunSpaceCache
    {
        private static Hashtable serverRunSpaceHash;
        private static Object obj = new Object();

        public static Hashtable getRunspaceHash(String serverName)
        {
            lock (obj)
            {
                if (serverRunSpaceHash == null)
                    serverRunSpaceHash = new Hashtable();
                Hashtable runSpaceHash = (Hashtable)serverRunSpaceHash[serverName];
                return runSpaceHash;
            }
        }
        public static void addRunSpaceHash(String serverName, Hashtable runSpaceHash)
        {
            lock (obj)
            {
                if(serverRunSpaceHash.ContainsKey(serverName))
                {
                    serverRunSpaceHash.Remove(serverName);
                }
                serverRunSpaceHash.Add(serverName, runSpaceHash);
            }
        }
        public static void removeRunSpaceHash(String serverName)
        {
            lock (obj)
            {
                try
                {
                    serverRunSpaceHash.Remove(serverName);
                }
                catch (Exception e)
                {
                    Logger.log("removeRunSpaceHash Ex : " + e);
                }
            }
        }
    }
}
