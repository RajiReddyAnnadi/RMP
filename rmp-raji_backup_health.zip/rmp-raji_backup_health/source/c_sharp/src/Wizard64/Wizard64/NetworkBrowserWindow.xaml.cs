﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Collections;
using System.Drawing;
using DWORD = System.UInt32;
using System.Runtime.InteropServices;
using System.Security.AccessControl;

namespace Wizard64
{
    public partial class NetworkBrowserWindow : Window
    {
        [DllImport("mpr.dll")]
        static extern UInt32 WNetAddConnection2(ref NETRESOURCE lpNetResource, string lpPassword, string lpUsername, uint dwFlags);

        [DllImport("mpr.dll")]
        static extern int WNetCancelConnection2(string lpName, uint dwFlags, bool bForce);

        [DllImport("netapi32.dll")]
        private extern static int NetApiBufferFree(IntPtr buf);

        [DllImport("Netapi32")]
        private static extern int NetServerEnum(
        string servername,
        int level,
        out IntPtr bufptr,
        int prefmaxlen,
        out int entriesread,
        out int totalentries,
        uint servertype,
        [MarshalAs(UnmanagedType.LPWStr)]
            string domain,
        IntPtr resume_handle);

        [DllImport("netapi32", CharSet = CharSet.Unicode)]
        protected static extern int NetShareEnum(string lpServerName, int dwLevel,
            out IntPtr lpBuffer, int dwPrefMaxLen, out int entriesRead,
            out int totalEntries, ref int hResume);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct SHARE_INFO_1
        {
            [MarshalAs(UnmanagedType.LPWStr)]
            public string NetName;
            DWORD shi1_type;
            [MarshalAs(UnmanagedType.LPWStr)]
            public string Remark;
        }

        public struct NETRESOURCE
        {
            public uint dwScope;
            public uint dwType;
            public uint dwDisplayType;
            public uint dwUsage;
            public string lpLocalName;
            public string lpRemoteName;
            public string lpComment;
            public string lpProvider;
        }

        public enum ServerType : uint
        {
            SV_TYPE_WORKSTATION = 0x00000001,
            SV_TYPE_SERVER = 0x00000002,
            SV_TYPE_DOMAIN_ENUM = 0x80000000
        }

        [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct SERVER_INFO_101
        {
            public int sv101_platform_id;
            public string sv101_name;
            public int sv101_version_major;
            public int sv101_version_minor;
            public int sv101_type;
            public string sv101_comment;
        }

        private object dummyNode = null;

        private Dictionary<string, ArrayList> credentialsDictionary = new Dictionary<string, ArrayList>();

        public string finalSelectedPath = null;
        public string finalUsername = null;
        public string finalPassword = null;

        const int NO_ERROR = 0;

        public NetworkBrowserWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                ArrayList list = new ArrayList();
                Dictionary<int, ArrayList> tempDic = GetNetworkComputers(ServerType.SV_TYPE_DOMAIN_ENUM, null);
                int result = 1;

                if (tempDic.Count == 0)
                {
                    System.Windows.Forms.MessageBox.Show("Error retrieving the network devices. Please enter the path manually !!");
                    folderBrowserWindow.Close();
                }
                else
                {
                    foreach (KeyValuePair<int, ArrayList> kvp in tempDic)
                    {
                        result = kvp.Key;
                        list = kvp.Value;
                    }

                    if (result == 0)
                    {
                        foreach (string i in list)
                        {
                            TreeViewItem item = new TreeViewItem();
                            item.Header = i;
                            item.Tag = "Domain";
                            item.FontWeight = FontWeights.Normal;
                            item.Items.Add(dummyNode);
                            item.Expanded += new RoutedEventHandler(GetMembers);
                            foldersItem.Items.Add(item);
                        }
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Error retrieving the network devices. Please enter the path manually !!");
                        folderBrowserWindow.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Error retrieving the network devices. Please enter the path manually !!");
                folderBrowserWindow.Close();
            }

        }

        void GetMembers(object sender, RoutedEventArgs e)
        {
            TreeViewItem item = (TreeViewItem)sender;
            string theTag = item.Tag.ToString();

            if (item.Items.Count == 1 && item.Items[0] == dummyNode)
            {
                item.Items.Clear();

                try
                {
                    switch (theTag)
                    {
                        case "Domain":

                            ArrayList list = new ArrayList();
                            Dictionary<int, ArrayList> tempDic = GetNetworkComputers(ServerType.SV_TYPE_WORKSTATION, item.Header.ToString());
                            int result = 1;

                            if (tempDic.Count == 0)
                            {
                                System.Windows.Forms.MessageBox.Show("Error retrieving the computers. Please try again !! If the error still persists, please enter the path manually.");
                                item.Items.Add(dummyNode);
                                item.IsExpanded = false;
                                break;
                            }
                            else
                            {
                                foreach (KeyValuePair<int, ArrayList> kvp in tempDic)
                                {
                                    result = kvp.Key;
                                    list = kvp.Value;
                                }

                                if (result == 0)
                                {
                                    foreach (string i in list)
                                    {
                                        TreeViewItem subitem = new TreeViewItem();
                                        subitem.Header = i;
                                        subitem.Tag = "Computer";
                                        subitem.FontWeight = FontWeights.Normal;
                                        subitem.Items.Add(dummyNode);
                                        subitem.Expanded += new RoutedEventHandler(GetMembers);
                                        item.Items.Add(subitem);
                                    }
                                }
                                else
                                {
                                    System.Windows.Forms.MessageBox.Show("Error retrieving the computers. Please try again !! If the error still persists, please enter the path manually.");
                                    item.Items.Add(dummyNode);
                                    item.IsExpanded = false;
                                    break;
                                }
                            }

                            break;

                        case "Computer":
                            Wizard64.CredentialsWindow credWindow = new Wizard64.CredentialsWindow();
                            credWindow.ShowDialog();

                            if (!credWindow.IsCanceled)
                            {
                                NETRESOURCE nr = new NETRESOURCE();
                                DWORD dwFlags;
                                uint returncode = 0;

                                nr.dwType = 0;
                                nr.lpLocalName = null;
                                nr.lpRemoteName = "\\\\" + item.Header.ToString();
                                nr.lpProvider = null;
                                dwFlags = 1;

                                returncode = WNetAddConnection2(ref nr, credWindow.password, credWindow.username, dwFlags);

                                if (returncode != 0)
                                {
                                    if (returncode == 5)
                                        System.Windows.MessageBox.Show("Error : Access Denied");
                                    else if (returncode == 53)
                                        System.Windows.MessageBox.Show("Error : Network path was not found");
                                    else if (returncode == 67)
                                        System.Windows.MessageBox.Show("Error : Network name cannot be found");
                                    else if (returncode == 86)
                                        System.Windows.MessageBox.Show("Error : Specified network password is not correct");
                                    else if (returncode == 1203)
                                        System.Windows.MessageBox.Show("Error : Network path was either typed incorrectly or does not exist.Please try again.");
                                    else if (returncode == 1326 || returncode == 1312)
                                        System.Windows.MessageBox.Show("Error : The user name or password is incorrect.");
                                    else if (returncode == 2202)
                                        System.Windows.MessageBox.Show("Error : Specified username is invalid.");
                                    else
                                        System.Windows.MessageBox.Show("Error : Could not access the location due to some error.Please try again.");

                                    item.Items.Add(dummyNode);
                                    item.IsExpanded = false;
                                    break;
                                }
                                else
                                {

                                    // Get the domainName of this computer
                                    String domainName = (GetSelectedTreeViewItemParent(item) as TreeViewItem).Header.ToString();
                                    String currentUsername = null;


                                    if (credWindow.username.Contains("\\"))
                                    {
                                        currentUsername = credWindow.username.Substring(credWindow.username.IndexOf('\\', 2) + 1, credWindow.username.Length - 1 - domainName.Length);
                                    }

                                    Impersonator impersonator = new Impersonator();
                                    impersonator.Impersonate(currentUsername, domainName, credWindow.password);

                                    ArrayList credList = new ArrayList();
                                    credList.Add(credWindow.username);
                                    credList.Add(credWindow.password);
                                    credentialsDictionary.Add(item.Header.ToString(), credList);

                                    ArrayList sharedList = GetNetworkShares(item.Header.ToString());

                                    foreach (string NetName in sharedList)
                                    {
                                        TreeViewItem subitem = new TreeViewItem();
                                        subitem.Header = NetName;
                                        subitem.Tag = "Folder";
                                        subitem.FontWeight = FontWeights.Normal;
                                        subitem.Items.Add(dummyNode);
                                        subitem.Expanded += new RoutedEventHandler(GetMembers);
                                        item.Items.Add(subitem);
                                    }
                                }
                            }
                            else
                            {
                                item.Items.Add(dummyNode);
                                item.IsExpanded = false;
                            }

                            break;

                        case "Folder":

                            string MyValue = GetFullPath(item);

                            try
                            {
                                DirectoryInfo dirInfo = new DirectoryInfo(MyValue);

                                DirectoryInfo[] Flds = dirInfo.GetDirectories();
                                for (int i = 0; i < Flds.Length; i++)
                                {
                                    TreeViewItem subitem = new TreeViewItem();
                                    subitem.Header = Flds[i].Name;
                                    subitem.Tag = "Folder";
                                    subitem.FontWeight = FontWeights.Normal;
                                    subitem.Items.Add(dummyNode);
                                    subitem.Expanded += new RoutedEventHandler(GetMembers);
                                    item.Items.Add(subitem);
                                }

                                FileInfo[] Fils = dirInfo.GetFiles();
                                for (int i = 0; i < Fils.Length; i++)
                                {
                                    TreeViewItem subitem = new TreeViewItem();
                                    subitem.Header = Fils[i].Name;
                                    subitem.Tag = "File";
                                    subitem.FontWeight = FontWeights.Normal;
                                    item.Items.Add(subitem);
                                }

                            }
                            catch (Exception ex)
                            {
                                System.Windows.Forms.MessageBox.Show("Sorry, could not search for directories in this share. Error :\n\n" + ex.Message);
                                item.Items.Add(dummyNode);
                                item.IsExpanded = false;
                            }
                            break;

                    }
                }
                catch (Exception)
                {
                    item.Items.Add(dummyNode);
                    item.IsExpanded = false;
                }
            }

        }
        private string GetFullPath(TreeViewItem aNode)
        {
            TreeViewItem walkingNode = aNode;
            string retVal = "";
            while (walkingNode.Tag.ToString() == "Folder")
            {
                string folderName = walkingNode.Header.ToString();

                retVal = folderName + "\\" + retVal;
                ItemsControl parent = GetSelectedTreeViewItemParent(walkingNode);
                walkingNode = parent as TreeViewItem;
            }
            return ("\\\\" + walkingNode.Header.ToString() + "\\" + retVal);
        }
        public ItemsControl GetSelectedTreeViewItemParent(TreeViewItem item)
        {
            DependencyObject parent = VisualTreeHelper.GetParent(item);
            while (!(parent is TreeViewItem || parent is System.Windows.Controls.TreeView))
            {
                parent = VisualTreeHelper.GetParent(parent);
            }

            return parent as ItemsControl;
        }

        public static Dictionary<int, ArrayList> GetNetworkComputers(ServerType server, string domainName)
        {
            uint serverType = UInt32.Parse(Enum.Format(typeof(ServerType), server, "x"), System.Globalization.NumberStyles.HexNumber);

            Dictionary<int, ArrayList> returnDic = new Dictionary<int, ArrayList>();

            int entriesread = 0;
            int totalentries;
            int result = 123;

            IntPtr pBuf = IntPtr.Zero;
            Type svType = typeof(SERVER_INFO_101);
            SERVER_INFO_101 si;

            ArrayList serversList = new ArrayList();

            int retryCount = 0;

            try
            {
                while (result != 0 && retryCount < 5)
                {

                    retryCount++;
                    result = NetServerEnum(
                    null,
                    101,
                    out pBuf,
                    -1,
                    out entriesread,
                    out totalentries,
                    serverType,
                    domainName,
                    IntPtr.Zero);
                }

                if (result == 0)
                {
                    Int64 tmp = (Int64)pBuf;

                    for (int i = 0; i < entriesread; i++)
                    {
                        si = (SERVER_INFO_101)Marshal.PtrToStructure((IntPtr)tmp, svType);
                        serversList.Add(si.sv101_name);
                        tmp += Marshal.SizeOf(svType);
                    }
                }

                returnDic.Add(result, serversList);
            }
            catch (Exception ex)
            {
            }
            finally
            {
                NetApiBufferFree(pBuf);
                pBuf = IntPtr.Zero;
            }

            return returnDic;
        }


        public static ArrayList GetNetworkShares(string server)
        {
            int level = 1;
            int entriesRead, totalEntries, nRet, hResume = 0;
            IntPtr pBuffer = IntPtr.Zero;

            ArrayList sharedList = new ArrayList();

            try
            {
                nRet = NetShareEnum(server, level, out pBuffer, -1,
                    out entriesRead, out totalEntries, ref hResume);

                if (NO_ERROR == nRet && entriesRead > 0)
                {
                    Int64 tmp = (Int64)pBuffer;
                    for (int i = 0; i < entriesRead; i++)
                    {
                        SHARE_INFO_1 si = (SHARE_INFO_1)Marshal.PtrToStructure((IntPtr)tmp, typeof(SHARE_INFO_1));
                        sharedList.Add(si.NetName);
                        tmp += Marshal.SizeOf(typeof(SHARE_INFO_1));
                    }
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {
                if (IntPtr.Zero != pBuffer)
                    NetApiBufferFree(pBuffer);
            }

            return sharedList;
        }

        private void foldersItem_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            System.Windows.Controls.TreeView tree = (System.Windows.Controls.TreeView)sender;

            TreeViewItem walkingNode = ((TreeViewItem)tree.SelectedItem);

            string selectedPath = GetFullPath(walkingNode);

            if (walkingNode.Tag.ToString() == "Folder")
            {
                selectFolderBtn.IsEnabled = true;
            }
            else
            {
                selectFolderBtn.IsEnabled = false;
            }

            finalSelectedPath = selectedPath.Substring(0, selectedPath.Length - 1);

        }

        private void selectFolder(object sender, RoutedEventArgs e)
        {
            string machineSelected = finalSelectedPath.Substring(2, finalSelectedPath.IndexOf('\\', 2) - 2);
            ArrayList tempCredList = new ArrayList();
            bool gotResult = credentialsDictionary.TryGetValue(machineSelected, out tempCredList);

            if (gotResult)
            {
                finalUsername = (string)tempCredList[0];
                finalPassword = (string)tempCredList[1];
            }

            foreach (string key in credentialsDictionary.Keys)
            {
                WNetCancelConnection2("\\\\" + key, 1, true);
            }
            folderBrowserWindow.DialogResult = true;
            folderBrowserWindow.Close();
        }

        private void closeWindow(object sender, RoutedEventArgs e)
        {
            folderBrowserWindow.DialogResult = false;
            folderBrowserWindow.Close();
        }
    }
}
