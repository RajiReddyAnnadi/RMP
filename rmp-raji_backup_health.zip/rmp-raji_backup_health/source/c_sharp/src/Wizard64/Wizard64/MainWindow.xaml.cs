using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Timers;
using System.Runtime.InteropServices;
using DWORD = System.UInt32;
using LPWSTR = System.String;
using NET_API_STATUS = System.UInt32;
using System.IO;

namespace Wizard64
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        [StructLayout(LayoutKind.Sequential)]
        public struct NETRESOURCE
        {
            public uint dwScope;
            public uint dwType;
            public uint dwDisplayType;
            public uint dwUsage;
            public string lpLocalName;
            public string lpRemoteName;
            public string lpComment;
            public string lpProvider;
        }
        [DllImport("mpr.dll")]
        static extern UInt32 WNetAddConnection2(ref NETRESOURCE lpNetResource, string lpPassword, string lpUsername, uint dwFlags);
        [DllImport("mpr.dll")]
        static extern int WNetCancelConnection2(string lpName, uint dwFlags, bool bForce);


        private Thread FRthread;
        private Thread IRthread;
        uint returncode = 0;
        int diskCnt = 1;
        string[] FRArray;
        string[] IRArray;
        string[] IRArray1;
        string[] HDArray;
        string[] HDArray1;
        List<int> statusArray = new List<int>();
        bool op;
        bool summaryCheck = false;
        bool isFRSuccess = true;
        string finalPath = null;
        bool isEncrypted = false;
        string secretKey = "";
        int isOldBackup;
        int oldPartitionNo = 0, oldDiskNo = 0;
        [DllImport("X:\\Windows\\System32\\DriveImage64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern UInt64 get_Progress();
        [DllImport("X:\\Windows\\System32\\DriveImage64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern UInt64 getIRProgress();
        [DllImport("X:\\Windows\\System32\\DriveImage64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int get_Status(int i);
        [DllImport("X:\\Windows\\System32\\DriveImage64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int get_DiskStatus(int i);
        [DllImport("X:\\Windows\\System32\\DriveImage64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int callRestore(bool op, int cnt, int isOldBackup, [MarshalAs(UnmanagedType.LPWStr)]string drivePath, bool isEncrypted, [MarshalAs(UnmanagedType.LPWStr)]string secretKey, [MarshalAs(UnmanagedType.LPWStr)]string backupLoc);
        [DllImport("X:\\Windows\\System32\\DriveImage64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int get_EntireProcessStatus();
        [DllImport("X:\\Windows\\System32\\DriveImage64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int get_Disk();
        [DllImport("X:\\Windows\\System32\\DriveImage64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int getVolumeCnt(int i);
        [DllImport("X:\\Windows\\System32\\DriveImage64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int getPartitionInProgress();
        [DllImport("X:\\Windows\\System32\\DriveImage64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int getProcessFormatStatus();
        [DllImport("X:\\Windows\\System32\\DriveImage64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int compareHash([MarshalAs(UnmanagedType.LPStr)]string secretKey, [MarshalAs(UnmanagedType.LPWStr)]string backupLoc);

        private System.Timers.Timer FRtimer = null;
        private System.Timers.Timer IRtimer = null;
        public MainWindow()
        {
            InitializeComponent();
        }
        public class RSummary
        {
            public int Id { get; set; }

            public string Partition { get; set; }

            public string Status { get; set; }
        }
        private void OnChange(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(Storage.Text) || string.IsNullOrWhiteSpace(Storage.Text))
            {
                if (BackupStorage.IsVisible)
                    BackupStorage.CanSelectNextPage = false;
                else if (IBackupStorage.IsVisible)
                    IBackupStorage.CanSelectNextPage = false;
            }
            else
            {
                if (BackupStorage.IsVisible)
                    BackupStorage.CanSelectNextPage = true;
                else if (IBackupStorage.IsVisible)
                    IBackupStorage.CanSelectNextPage = true;
            }
        }
        private void OnFRProgress(object sender, RoutedEventArgs e)
        {
            bool isValidBackup = false;
            bool isBootloaderExists = false;

            try
            {
                op = true;
                HDArray = Directory.GetDirectories(finalPath).Where(s => s.Contains("Harddisk")).ToArray();

                if (HDArray.Length == 0)
                {
                    isOldBackup = 1;
                    diskCnt = 1;

                    if (Directory.GetFiles(finalPath, "*.img", SearchOption.TopDirectoryOnly).Length > 0)
                    {
                        isValidBackup = true;
                    }

                    if (File.Exists(finalPath + "\\bootloader.mbr")) {
                        isBootloaderExists = true;
                    }
                }
                else
                {
                    diskCnt = HDArray.Length;
                    isOldBackup = 0;
                    isBootloaderExists = true;

                    if (Directory.GetFiles(finalPath, "*.img", SearchOption.AllDirectories).Length > 0)
                    {
                        isValidBackup = true;
                    }
                    else
                    {
                        isValidBackup = false;
                    }
                }
                FRArray = Directory.GetFiles(finalPath, "*.img", SearchOption.AllDirectories);

                if (isValidBackup && isBootloaderExists)
                {
                    ProgressTxt.Content = "Formatting partition 1 of disk 1...";
                    this.Progress.NextPage = IRestore;
                    this.Progress.CanSelectNextPage = false;

                    FRthread = new Thread(executeCode);
                    FRthread.Start();
                    FRtimer = new System.Timers.Timer();
                    this.FRtimer.Interval = 5000;
                    this.FRtimer.Elapsed += new System.Timers.ElapsedEventHandler(this.FullRestore);
                    FRtimer.Start();
                }
                else if(!isValidBackup)
                {
                    ProgressTxt.Content = "Restore failed (No .img files found)";
                    this.Progress.NextPage = StorageSelection;
                    this.Progress.CanSelectNextPage = true;
                }
                else if (!isBootloaderExists)
                {
                    ProgressTxt.Content = "Restore failed (Please select a Bare Metal Backup to continue)";
                    this.Progress.NextPage = StorageSelection;
                    this.Progress.CanSelectNextPage = true;
                }
            }
            catch (Exception ex)
            {
                ProgressTxt.Content = "Restore failed (Invalid storage path or credentials)";
                this.Progress.NextPage = StorageSelection;
                this.Progress.CanSelectNextPage = true;
            }
        }
        private void FullRestore(object sender, ElapsedEventArgs e)
        {
            Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, (Action)(() =>
            {
                if (get_EntireProcessStatus() == 0)
                {
                    int diskNo = get_Disk();
                    int diskStatus = get_DiskStatus(diskNo);
                    if (diskStatus == 0)
                    {
                        int partitionNo = getPartitionInProgress();
                        if (oldPartitionNo != partitionNo || oldDiskNo != diskNo)
                        {
                            pb.Value = 0;
                        }
                        oldPartitionNo = partitionNo;
                        oldDiskNo = diskNo;
                        if (getProcessFormatStatus() == 0)
                        {
                            ProgressTxt.Content = "Formatting partition " + (partitionNo + 1) + " of disk " + (diskNo + 1) + "...";
                            pb.Maximum = 500;
                            pb.Value += 1;
                        }
                        else
                        {
                            ProgressTxt.Content = "Restoring partition " + (partitionNo + 1) + " of disk " + (diskNo + 1) + "...";
                            FileInfo f = new FileInfo(FRArray[partitionNo]);
                            pb.Maximum = f.Length * 4;
                            UInt64 val = get_Progress();
                            pb.Value += val;
                        }
                    }
                }
                else
                {
                    pb.Value = pb.Maximum;
                    ProgressTxt.Content = "Restore of all partitions completed";
                    FRtimer.Stop();
                    int cnt = 0;
                    for (int loop = 0; loop < diskCnt; loop++)
                    {
                        if (get_DiskStatus(loop) == 0)
                        {
                            int volCnt = getVolumeCnt(loop);
                            for (int loop1 = 0; loop1 < volCnt; loop1++)
                            {
                                statusArray.Add(get_Status(cnt++));
                            }
                        }
                        else if (get_DiskStatus(loop) == 9999)
                        { }
                        else
                        {
                            isFRSuccess = false;
                        }
                    }
                    if (isFRSuccess)
                    {
                        foreach (int status in statusArray)
                        {
                            if (status != 0)
                            {
                                isFRSuccess = false;
                                break;
                            }
                        }
                    }
                    if (!isFRSuccess)
                    {
                        loadSummaryTable();
                        this.Progress.NextPage = Summary;
                    }
                    this.Progress.CanSelectNextPage = true;
                }
            }));
        }

        private void OnIRProgress(object sender, RoutedEventArgs e)
        {
            try
            {
                op = false;
                HDArray1 = Directory.GetDirectories(finalPath).Where(s => s.Contains("Harddisk")).ToArray();
                if (HDArray1.Length == 0)
                {
                    IRArray = Directory.GetDirectories(finalPath).Where(s => !s.StartsWith("restore")).ToArray();
                    isOldBackup = 1;
                    diskCnt = 1;
                }
                else
                {
                    IRArray = Directory.GetDirectories(HDArray1[0]);
                    diskCnt = HDArray1.Length;
                    isOldBackup = 0;
                }
                statusArray.Clear();

                if (IRArray.Length > 0 && File.Exists(finalPath + "\\BackupDetails.txt"))
                {
                    IRArray1 = Directory.GetFiles(IRArray[0], "*.*", SearchOption.AllDirectories);
                    IProgressTxt.Content = "Restoring partition 1 of disk 1...";
                    this.IProgress.NextPage = Summary;
                    this.IProgress.CanSelectNextPage = false;
                    IRthread = new Thread(executeCode);
                    IRthread.Start();
                    IRtimer = new System.Timers.Timer();
                    this.IRtimer.Interval = 5000;
                    this.IRtimer.Elapsed += new System.Timers.ElapsedEventHandler(this.IncrementalRestore);
                    IRtimer.Start();
                }
                else
                {
                    IProgressTxt.Content = "Restore failed (Please provide valid storage path/credentials)";
                    this.IProgress.NextPage = IStorageSelection;
                    this.IProgress.NextPage.Content = StorageSelection.Content;
                    this.IProgress.CanSelectNextPage = true;
                }
            }
            catch (Exception ex)
            {
                IProgressTxt.Content = "Restore failed (Invalid storage path or credentials)";
                this.IProgress.NextPage = IStorageSelection;
                this.IProgress.NextPage.Content = StorageSelection.Content;
                // this.IProgress.CanSelectNextPage = true;
            }
        }

        private void IncrementalRestore(object sender, ElapsedEventArgs e)
        {
            Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, (Action)(() =>
            {
                if (get_EntireProcessStatus() == 0)
                {
                    int diskNo = get_Disk();
                    int partitionNo = getPartitionInProgress();
                    if (oldPartitionNo != partitionNo || oldDiskNo != diskNo)
                    {
                        pb1.Value = 0;
                        if (oldDiskNo != diskNo)
                        {
                            Array.Clear(IRArray, 0, IRArray.Length);
                            IRArray = Directory.GetDirectories(HDArray1[diskNo]);
                        }
                        IRArray1 = Directory.GetFiles(IRArray[partitionNo], "*.*", SearchOption.AllDirectories);
                    }
                    oldPartitionNo = partitionNo;
                    oldDiskNo = diskNo;
                    IProgressTxt.Content = "Restoring partition " + (partitionNo + 1) + " of disk " + (diskNo + 1) + "...";
                    pb1.Maximum = IRArray1.Length;
                    UInt64 val = getIRProgress();
                    pb1.Value += val;
                }
                else
                {
                    pb1.Value = pb1.Maximum;
                    IProgressTxt.Content = "Restore of all partitions completed";
                    IRtimer.Stop();
                    int cnt = 0;
                    for (int loop = 0; loop < diskCnt; loop++)
                    {
                        if (get_DiskStatus(loop) == 0)
                        {
                            int volCnt = getVolumeCnt(loop);
                            for (int loop1 = 0; loop1 < volCnt; loop1++)
                            {
                                statusArray.Add(get_Status(cnt++));
                            }
                        }
                    }
                    foreach (int status in statusArray)
                    {
                        if (status != 0)
                        {
                            isFRSuccess = false;
                            break;
                        }
                    }
                    this.IProgress.CanSelectNextPage = true;
                }
            }));
        }

        private void executeCode()
        {
            string backupPath = finalPath;
            string finalBackupPath = null;

            if (backupPath.Contains(":"))
            {
                finalBackupPath = "\\\\.\\" + backupPath.Substring(backupPath.IndexOf(":") - 1, 2);
            }

            int retval = callRestore(op, diskCnt, isOldBackup, finalBackupPath, isEncrypted, secretKey, finalPath);
        }

        private void OnCheck(object sender, RoutedEventArgs e)
        {
            UserTxt.Visibility = Visibility.Visible;
            User.Visibility = Visibility.Visible;
            PwdTxt.Visibility = Visibility.Visible;
            Pwd.Visibility = Visibility.Visible;
            Keyboard.Focus(User);
        }

        private void OnUncheck(object sender, RoutedEventArgs e)
        {
            UserTxt.Visibility = Visibility.Collapsed;
            User.Visibility = Visibility.Collapsed;
            PwdTxt.Visibility = Visibility.Collapsed;
            Pwd.Visibility = Visibility.Collapsed;
        }

        private void OnWelcomeLeave(object sender, RoutedEventArgs e)
        {
            Keyboard.Focus(Storage);
        }

        private void onFinish(object sender, RoutedEventArgs e)
        {
            Process p = new Process();
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.CreateNoWindow = true;
            p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            p.StartInfo.FileName = "wpeutil";
            p.StartInfo.Arguments = "reboot";
            p.Start();
        }

        private void loadSummaryTable()
        {
            try
            {
                int num = 0;
                if (summaryCheck)
                {
                    Summary.CanSelectPreviousPage = false;
                }
                else
                {
                    if (!isFRSuccess)
                        Summary.CanSelectPreviousPage = false;
                }
                List<RSummary> summary = new List<RSummary>();
                string status, type;
                int cnt = 0;
                for (int loop = 0; loop < diskCnt; loop++)
                {

                    if (get_DiskStatus(loop) == 0)
                    {
                        int volCnt = getVolumeCnt(loop);
                        for (int loop1 = 0; loop1 < volCnt; loop1++)
                        {
                            int val = statusArray[cnt++];
                            type = "Disk " + (loop + 1) + " - Partition " + (loop1 + 1);
                            if (val == 0)
                                status = "Success";
                            else if (val == 3)
                                status = "Failed ( Insufficient space ; Try restoring to a larger machine )";
                            else if (val == 5)
                                status = "Failed ( Disk unavailable)";
                            else
                                status = "Failed";
                            summary.Add(new RSummary() { Id = num++, Partition = type, Status = status });
                        }
                    }
                    else if (get_DiskStatus(loop) == 9999)
                    {
                        type = "Disk " + (loop + 1) + " - All Partitions";
                        status = "Skipped";
                        summary.Add(new RSummary() { Id = num++, Partition = type, Status = status });
                    }
                    else
                    {
                        type = "Disk " + (loop + 1) + " - All Partitions";
                        if (get_DiskStatus(loop) == 3)
                            status = "Failed ( Insufficient space ; Try restoring to a larger machine )";
                        else if (get_DiskStatus(loop) == 5)
                            status = "Failed ( Disk unavailable)";
                        else
                            status = "Failed";
                        summary.Add(new RSummary() { Id = num++, Partition = type, Status = status });
                    }
                }
                SummaryTable.ItemsSource = summary;
            }
            catch (Exception ex)
            { Console.WriteLine(ex.ToString()); }

        }

        private void Check(object sender, Xceed.Wpf.Toolkit.Core.CancelRoutedEventArgs e)
        {
            if ((BackupStorage.IsVisible) || (IBackupStorage.IsVisible))
            {
                LPWSTR user = null;
                LPWSTR pwd = null;
                bool check = true;
                if (Authentication.IsChecked == true)
                {
                    if (string.IsNullOrEmpty(User.Text) || string.IsNullOrWhiteSpace(User.Text))
                    {
                        MessageBox.Show("Please enter user name to proceed");
                        e.Cancel = true;
                        check = false;
                    }
                    else if (string.IsNullOrEmpty(Pwd.Password) || string.IsNullOrWhiteSpace(Pwd.Password))
                    {
                        MessageBox.Show("Please enter password to proceed");
                        e.Cancel = true;
                        check = false;
                    }
                    else
                    {
                        user = User.Text;
                        pwd = Pwd.Password;
                        check = true;
                    }
                }
                if (check && Storage.Text.StartsWith("\\"))
                {
                    //Removing mapping to Z:
                    //WNetCancelConnection2("z:", 0, true);
                    NETRESOURCE nr = new NETRESOURCE();
                    DWORD dwFlags;
                    nr.dwType = 0;
                    //nr.lpLocalName = "Z:";
                    nr.lpRemoteName = Storage.Text;
                    nr.lpProvider = null;
                    dwFlags = 4;
                    returncode = WNetAddConnection2(ref nr, pwd, user, dwFlags);
                    if (returncode != 0 && returncode != 1219)
                    {
                        if (returncode == 5)
                            MessageBox.Show("Error : Access Denied");
                        else if (returncode == 53)
                            MessageBox.Show("Error : Network path was not found");
                        else if (returncode == 67)
                            MessageBox.Show("Error : Network name cannot be found");
                        else if (returncode == 86)
                            MessageBox.Show("Error : Specified network password is not correct");
                        else if (returncode == 1203)
                            MessageBox.Show("Error : Network path was either typed incorrectly or does not exist.Please try again.");
                        else if (returncode == 1326)
                            MessageBox.Show("Error : The user name or password is incorrect.");
                        else if (returncode == 2202)
                            MessageBox.Show("Error : Specified username is invalid.");
                        else
                            MessageBox.Show("Error : Could not access the location due to some error.Please try again.");
                        e.Cancel = true;
                    }
                    else
                    {
                        e.Cancel = false;
                        if (BackupStorage.IsVisible)
                        {
                            string encryptFile = Storage.Text + "\\encryptBackup.txt";
                            if (File.Exists(encryptFile))
                            {
                                BackupStorage.NextPage = Decryption;
                                Decryption.PreviousPage = BackupStorage;
                            }
                            else
                            {
                                BackupStorage.NextPage = Confirm;
                                Confirm.PreviousPage = BackupStorage;
                                isEncrypted = false;
                                secretKey = "";
                            }
                        }
                    }
                }
            }
            else if (Confirm.IsVisible)
            {
                if (no.IsChecked == true)
                {
                    Confirm.NextPage = FinalWithoutRestore;
                    // Confirm.NextPage = IRestore;
                }
                else
                {
                    Confirm.NextPage = Progress;
                }
            }
            else if (IRestore.IsVisible)
            {
                if (Iyes.IsChecked == true)
                {
                    localStorageRadioBtn.IsChecked = true;
                    backupLocationTextBox.Clear();
                    Storage.Clear();
                    User.Clear();
                    Pwd.Clear();
                    IRestore.NextPage = IStorageSelection;
                    IRestore.NextPage.Content = StorageSelection.Content;
                    // IRestore.NextPage = IBackupStorage;
                    // IRestore.NextPage.Content = BackupStorage.Content;
                }
                else if (Ino.IsChecked == true)
                {
                    loadSummaryTable();
                    IRestore.NextPage = Summary;
                }
            }
            else if (IConfirm.IsVisible)
            {
                if (Ino1.IsChecked == true)
                {
                    IConfirm.NextPage = Final;
                }
            }
            else if (IProgress.IsVisible)
            {
                summaryCheck = true;
                loadSummaryTable();
            }
            else if (Summary.IsVisible)
            {
                if (!isFRSuccess)
                {
                    Summary.NextPage = FailedFinal;
                }
            }
            else if (StorageSelection.IsVisible)
            {
                if (networkStorageRadioBtn.IsChecked == true)
                {
                    StorageSelection.NextPage = BackupStorage;
                    BackupStorage.PreviousPage = StorageSelection;
                    Confirm.PreviousPage = BackupStorage;
                }
                else if (localStorageRadioBtn.IsChecked == true)
                {
                    //Removing mapping to Z:
                    /*if (!(backupLocationTextBox.Text.StartsWith("\\")))
                    {
                        ProcessStartInfo processInfo = new ProcessStartInfo();
                        processInfo.WindowStyle = ProcessWindowStyle.Hidden;
                        processInfo.FileName = "cmd.exe";
                        processInfo.Arguments = "/c subst /d Z:";
                        Process.Start(processInfo);

                        ProcessStartInfo processInfo1 = new ProcessStartInfo();
                        processInfo1.WindowStyle = ProcessWindowStyle.Hidden;
                        processInfo1.FileName = "cmd.exe";
                        processInfo1.Arguments = "/c subst Z: \"" + backupLocationTextBox.Text + "\"";
                        Process.Start(processInfo1);

                    }*/
                    string encryptFile = backupLocationTextBox.Text + "\\encryptBackup.txt";
                    if (File.Exists(encryptFile))
                    {
                        StorageSelection.NextPage = Decryption;
                        Decryption.PreviousPage = StorageSelection;
                    }
                    else
                    {
                        StorageSelection.NextPage = Confirm;
                        Confirm.PreviousPage = StorageSelection;
                        isEncrypted = false;
                        secretKey = "";
                    }
                }
            }
            else if (Decryption.IsVisible)
            {
                string path = "";
                if (string.IsNullOrEmpty(backupLocationTextBox.Text) || string.IsNullOrWhiteSpace(backupLocationTextBox.Text))
                {
                    path = Storage.Text;
                }
                else
                {
                    path = backupLocationTextBox.Text;
                }
                int retval = compareHash(DecryptionPwd.Password, path);
                if (retval == 0)
                {
                    Decryption.NextPage = Confirm;
                    Confirm.PreviousPage = Decryption;
                    isEncrypted = true;
                    secretKey = DecryptionPwd.Password;
                }
                else
                {
                    e.Cancel = true;
                    MessageBox.Show("The password provided is incorrect. Please enter the correct password.");
                }
            }
            else if (IStorageSelection.IsVisible)
            {
                if (networkStorageRadioBtn.IsChecked == true)
                {
                    IStorageSelection.NextPage = IBackupStorage;
                    IBackupStorage.PreviousPage = IStorageSelection;
                    IStorageSelection.NextPage.Content = BackupStorage.Content;
                    IConfirm.PreviousPage = IBackupStorage;
                }
                else if (localStorageRadioBtn.IsChecked == true)
                {
                    //Removing mapping to Z:
                    /*if (!(backupLocationTextBox.Text.StartsWith("\\")))
                    {
                        ProcessStartInfo processInfo = new ProcessStartInfo();
                        processInfo.WindowStyle = ProcessWindowStyle.Hidden;
                        processInfo.FileName = "cmd.exe";
                        processInfo.Arguments = "/c subst /d Z:";
                        Process.Start(processInfo);

                        ProcessStartInfo processInfo1 = new ProcessStartInfo();
                        processInfo1.WindowStyle = ProcessWindowStyle.Hidden;
                        processInfo1.FileName = "cmd.exe";
                        processInfo1.Arguments = "/c subst Z: \"" + backupLocationTextBox.Text + "\"";
                        Process.Start(processInfo1);

                    }*/

                    IStorageSelection.NextPage = IConfirm;
                    IConfirm.PreviousPage = IStorageSelection;
                }
            }
        }

        private void localBrowse(object sender, RoutedEventArgs e)
        {
            FolderBrowser dialog = new FolderBrowser();

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                System.Windows.MessageBox.Show("Disks other than current selected disk will be restored !!");
                backupLocationTextBox.Text = dialog.DirectoryPath;
            }

        }
        private void OnLocalChange(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(backupLocationTextBox.Text) || string.IsNullOrWhiteSpace(backupLocationTextBox.Text))
            {
                if (StorageSelection.IsVisible)
                    StorageSelection.CanSelectNextPage = false;
                else if (IStorageSelection.IsVisible)
                    IStorageSelection.CanSelectNextPage = false;
            }
            else
            {
                if (StorageSelection.IsVisible)
                    StorageSelection.CanSelectNextPage = true;
                else if (IStorageSelection.IsVisible)
                    IStorageSelection.CanSelectNextPage = true;
            }
        }

        private void networkStorageRadioBtnChecked(object sender, RoutedEventArgs e)
        {
            if (StorageSelection.IsVisible)
            {
                backupLocationTextBox.Text = "";
                StorageSelection.CanSelectNextPage = true;
                localBrowseButton.IsEnabled = false;
            }
            else if (IStorageSelection.IsVisible)
            {
                backupLocationTextBox.Text = "";
                IStorageSelection.CanSelectNextPage = true;
                localBrowseButton.IsEnabled = false;
            }
        }

        private void networkStorageRadioBtnUnchecked(object sender, RoutedEventArgs e)
        {
            localBrowseButton.IsEnabled = true;
            if (!(string.IsNullOrEmpty(backupLocationTextBox.Text) && string.IsNullOrWhiteSpace(backupLocationTextBox.Text)))
            {
                if (StorageSelection.IsVisible)
                    StorageSelection.CanSelectNextPage = true;
                else if (IStorageSelection.IsVisible)
                    IStorageSelection.CanSelectNextPage = true;
            }
            else
            {
                if (StorageSelection.IsVisible)
                    StorageSelection.CanSelectNextPage = false;
                else if (IStorageSelection.IsVisible)
                    IStorageSelection.CanSelectNextPage = false;
            }

            Storage.Text = "";
            Authentication.IsChecked = false;
            UserTxt.Visibility = Visibility.Hidden;
            User.Visibility = Visibility.Hidden;
            PwdTxt.Visibility = Visibility.Hidden;
            Pwd.Visibility = Visibility.Hidden;
            User.Text = "";
            Pwd.Password = "";
        }

        private void assignPath(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(backupLocationTextBox.Text) || string.IsNullOrWhiteSpace(backupLocationTextBox.Text))
            {
                finalPath = Storage.Text;
            }
            else
            {
                finalPath = backupLocationTextBox.Text;
            }
        }

        private void networkBrowse(object sender, RoutedEventArgs e)
        {
            NetworkBrowserWindow networkBrowser = new NetworkBrowserWindow() { Owner = this };

            if ((bool)networkBrowser.ShowDialog())
            {
                if (networkBrowser.finalSelectedPath != null)
                {
                    Storage.Text = networkBrowser.finalSelectedPath;
                    Authentication.IsChecked = true;
                    User.Text = networkBrowser.finalUsername;
                    Pwd.Password = networkBrowser.finalPassword;
                }
            }
        }
    }
}
