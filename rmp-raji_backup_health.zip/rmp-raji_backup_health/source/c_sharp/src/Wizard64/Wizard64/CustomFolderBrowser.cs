﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Windows.Forms;

namespace Wizard64
{
    internal class Win32API
    {
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown),
           Guid("00000002-0000-0000-C000-000000000046")]
        public interface IMalloc
        {
            [PreserveSig]
            IntPtr Alloc([In] int cb);
            [PreserveSig]
            IntPtr Realloc([In] IntPtr pv, [In] int cb);
            [PreserveSig]
            void Free([In] IntPtr pv);
            [PreserveSig]
            int GetSize([In] IntPtr pv);
            [PreserveSig]
            int DidAlloc(IntPtr pv);
            [PreserveSig]
            void HeapMinimize();
        }

        [DllImport("User32.DLL")]
        public static extern IntPtr GetActiveWindow();

        public class Shell32
        {
            [Flags]
            public enum BffStyles
            {
                RestrictToFilesystem = 0x0001,
                RestrictToDomain = 0x0002,
                RestrictToSubfolders = 0x0008,
                ShowTextBox = 0x0010,
                ValidateSelection = 0x0020,
                NewDialogStyle = 0x0040,
                BrowseForComputer = 0x1000,
                BrowseForPrinter = 0x2000,
                BrowseForEverything = 0x4000,
            }

            public delegate int BFFCALLBACK(IntPtr hwnd, uint uMsg, IntPtr lParam, IntPtr lpData);

            [StructLayout(LayoutKind.Sequential, Pack = 8)]
            public struct BROWSEINFO
            {
                public IntPtr hwndOwner;
                public IntPtr pidlRoot;
                public IntPtr pszDisplayName;
                [MarshalAs(UnmanagedType.LPTStr)]
                public string lpszTitle;
                public int ulFlags;
                [MarshalAs(UnmanagedType.FunctionPtr)]
                public BFFCALLBACK lpfn;
                public IntPtr lParam;
                public int iImage;
            }

            [DllImport("Shell32.DLL")]
            public static extern int SHGetMalloc(out IMalloc ppMalloc);

            [DllImport("Shell32.DLL")]
            public static extern Int64 SHGetSpecialFolderLocation(
                        IntPtr hwndOwner, int nFolder, out IntPtr ppidl);

            [DllImport("Shell32.DLL")]
            public static extern int SHGetPathFromIDList(
                        IntPtr pidl, StringBuilder Path);

            [DllImport("Shell32.DLL", CharSet = CharSet.Auto)]
            public static extern IntPtr SHBrowseForFolder(ref BROWSEINFO browseInfo);
        }
    }

    public sealed class FolderBrowser : Component
    {
        private static readonly int MAX_PATH = 260;

        private FolderID startLocation = FolderID.MyComputer;

        private int publicOptions = (int)Win32API.Shell32.BffStyles.RestrictToFilesystem |
             (int)Win32API.Shell32.BffStyles.RestrictToDomain;
        private int privateOptions = (int)Win32API.Shell32.BffStyles.NewDialogStyle;

        private string descriptionText = "Please select a folder below:";

        private string directoryPath = String.Empty;

        private void SetOptionField(int mask, bool turnOn)
        {
            if (turnOn)
                publicOptions |= mask;
            else
                publicOptions &= ~mask;
        }

        public bool OnlyFilesystem
        {
            get
            {
                return (publicOptions & (int)Win32API.Shell32.BffStyles.RestrictToFilesystem) != 0;
            }
            set
            {
                SetOptionField((int)Win32API.Shell32.BffStyles.RestrictToFilesystem, value);
            }
        }

        public FolderID StartLocation
        {
            get
            {
                return startLocation;
            }
            set
            {
                new UIPermission(UIPermissionWindow.AllWindows).Demand();
                startLocation = value;
            }
        }

        public string DirectoryPath
        {
            get
            {
                return directoryPath;
            }
        }


        public enum FolderID
        {
            Desktop = 0x0000,
            Printers = 0x0004,
            MyDocuments = 0x0005,
            Favorites = 0x0006,
            Recent = 0x0008,
            SendTo = 0x0009,
            StartMenu = 0x000b,
            MyComputer = 0x0011,
            NetworkNeighborhood = 0x0012,
            Templates = 0x0015,
            MyPictures = 0x0027,
            NetAndDialUpConnections = 0x0031,
        }

        private static Win32API.IMalloc GetSHMalloc()
        {
            Win32API.IMalloc malloc;
            Win32API.Shell32.SHGetMalloc(out malloc);
            return malloc;
        }

        public DialogResult ShowDialog()
        {
            return ShowDialog(null);
        }

        public DialogResult ShowDialog(IWin32Window owner)
        {
            IntPtr resultPtr = IntPtr.Zero;

            IntPtr ownerPtr;

            if (owner != null)
            {
                ownerPtr = owner.Handle;
            }
            else
            {
                ownerPtr = Win32API.GetActiveWindow();
            }

            Int64 res = Win32API.Shell32.SHGetSpecialFolderLocation(ownerPtr, (int)startLocation, out resultPtr);

            if (resultPtr == IntPtr.Zero)
            {
                return DialogResult.Cancel;
            }

            int mergedOptions = (int)publicOptions | (int)privateOptions;

            if ((mergedOptions & (int)Win32API.Shell32.BffStyles.NewDialogStyle) != 0)
            {
                if (System.Threading.ApartmentState.MTA == Application.OleRequired())
                    mergedOptions = mergedOptions & (~(int)Win32API.Shell32.BffStyles.NewDialogStyle);
            }

            IntPtr retPtr = IntPtr.Zero;

            try
            {
                Win32API.Shell32.BROWSEINFO browseInfo = new Win32API.Shell32.BROWSEINFO();
                IntPtr buffer = Marshal.AllocHGlobal(MAX_PATH);

                browseInfo.pidlRoot = resultPtr;
                browseInfo.hwndOwner = ownerPtr;
                browseInfo.pszDisplayName = buffer;
                browseInfo.lpszTitle = descriptionText;
                browseInfo.ulFlags = 0;

                retPtr = Win32API.Shell32.SHBrowseForFolder(ref browseInfo);

                Marshal.FreeHGlobal(buffer);

                if (retPtr == IntPtr.Zero)
                {
                    return DialogResult.Cancel;
                }

                StringBuilder sb = new StringBuilder(MAX_PATH);
                if (0 == Win32API.Shell32.SHGetPathFromIDList(retPtr, sb))
                {
                    return DialogResult.Cancel;
                }

                directoryPath = sb.ToString();
            }
            finally
            {
                Win32API.IMalloc malloc = GetSHMalloc();
                malloc.Free(resultPtr);

                if (retPtr != IntPtr.Zero)
                {
                    malloc.Free(retPtr);
                }
            }

            return DialogResult.OK;
        }

    }

}
