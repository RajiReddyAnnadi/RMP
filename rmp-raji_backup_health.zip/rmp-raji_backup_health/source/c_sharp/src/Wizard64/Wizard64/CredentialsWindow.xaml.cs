﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wizard64
{
    /// <summary>
    /// Interaction logic for CredentialsWindow.xaml
    /// </summary>
    public partial class CredentialsWindow : Window
    {
        public string username = "";
        public string password = "";
        public bool IsCanceled = true;

        public CredentialsWindow()
        {
            InitializeComponent();
        }

        private void OnUserNameChange(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(UsernameTB.Text) || string.IsNullOrWhiteSpace(UsernameTB.Text) || string.IsNullOrEmpty(Password.Password) || string.IsNullOrWhiteSpace(Password.Password))
            {
                CredOK.IsEnabled = false;
            }
            else
            {
                CredOK.IsEnabled = true;
            }
        }

        private void OnPasswordChange(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(UsernameTB.Text) || string.IsNullOrWhiteSpace(UsernameTB.Text) || string.IsNullOrEmpty(Password.Password) || string.IsNullOrWhiteSpace(Password.Password))
            {
                CredOK.IsEnabled = false;
            }
            else
            {
                CredOK.IsEnabled = true;
            }
        }

        private void CredOK_Click(object sender, RoutedEventArgs e)
        {
            IsCanceled = false;
            username = UsernameTB.Text.Trim();
            password = Password.Password.Trim();
            CredWindow.Close();
        }

        private void CredCancel_Click(object sender, RoutedEventArgs e)
        {
            IsCanceled = true;
            username = "";
            password = "";
            CredWindow.Close();
        }
    }
}
