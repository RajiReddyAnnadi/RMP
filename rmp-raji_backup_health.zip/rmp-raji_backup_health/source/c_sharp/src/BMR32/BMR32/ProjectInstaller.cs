﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;


namespace BMR32
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();
        }
        void serviceInstaller1_AfterInstall(object sender, InstallEventArgs e)
        {
            System.ServiceProcess.ServiceController controller = new System.ServiceProcess.ServiceController(serviceInstaller1.ServiceName);
            controller.Start();
        }
    }
}
