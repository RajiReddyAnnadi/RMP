﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Net;
using System.IO;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using BOOL = System.Boolean;
using DWORD = System.UInt32;
using LPWSTR = System.String;
using NET_API_STATUS = System.UInt32;

namespace BMR32
{
    public partial class BMR32Service : ServiceBase
    {
        private Thread thread;
        Process p1 = new Process();
        [DllImport("RPCTest.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void call_start();
        [DllImport("RPCTest.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void call_stop();

        public BMR32Service()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            thread = new Thread(executeCode);
            thread.Start();
            Library.WriteErrorLog("Service started");
        }

        private void executeCode()
        {
            try
            {
               call_start();
            }            
            catch (Exception e)
            {
                Library.WriteErrorLog(e.ToString());
            }
        }


        protected override void OnStop()
        {
            //serversocket.Stop();
            try
            {
               call_stop();
                Library.WriteErrorLog("Service stopped");
            }
            catch (Exception e)
            {
                Library.WriteErrorLog(e.ToString());
            }
        }
    }
}
