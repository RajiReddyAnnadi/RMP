//$Id: PowershellHandler.h,v 1.0 2015/10/14 12:07:09 lucky.k Exp $
#include <iostream>
#include <fstream>
#include <ctime>
#include <string>
#include <windows.h>
#include <string.h>
#include <stdlib.h>
#include <jni/com_manageengine_rmp_jni_RMPManagedNative.h>
//#include <jni/JNIUtil.h>

#using "PowershellHandler.netmodule"
using namespace System;
using namespace PowershellManager;
using namespace std;
using namespace System::IO;
using namespace System::Runtime::InteropServices;


extern jclass gClLogger;
extern jmethodID gMtdFine;
extern jclass gClWinAccessProvider;
extern jclass LogClass;
extern jmethodID LogID;
