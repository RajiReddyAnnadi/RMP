#include <jni.h>
#include <msclr\marshal.h>
#include <vector>
#include <list>

using namespace System;
using namespace msclr::interop;
using namespace System::Collections::Generic;
using namespace System::IO;
using namespace System::Management;
using namespace System::Runtime::InteropServices;
using namespace System::Threading;
using namespace std;
using namespace Newtonsoft::Json;

#define BUFSIZE 16777216
#define MD5LEN 16

public ref class backupDetails
{
public:
    String^ backupPath;
    String^ backupType;
    String^ backupIdentifier;
};

public ref class healthCheckParameters
{
public:
    String^ backupId;
    String^ vmId;
    String^ isEncrypted;
};

JNIEnv* jniEnv;

jclass longclass;
jclass hvBackupServerCls;
jmethodID longclasscons;
jmethodID updateHcBackupTypeofVM;
jmethodID updateCorrutedBackupPoints;


jboolean InitializeHealthCheckJNIIDs(JNIEnv* jniEnv);