#include <jni.h>

/* Header for class com_manageengine_rmp_virtual_HVManagedNative */

#ifndef _Included_com_manageengine_rmp_virtual_HVManagedNative
#define _Included_com_manageengine_rmp_virtual_HVManagedNative
#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT void JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_jNIHVInitializeClassIDs
  (JNIEnv *, jclass);

  JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_getallHypervVMs(JNIEnv *env, jobject, jstring jhypervHostName, jstring juserName, jstring jpassword, jstring isServeradd);

  JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_getVHDpathofVM(JNIEnv *env, jobject, jstring jhypervHostName, jstring juserName, jstring jpassword, jstring vmId);

  JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_getRegistryDetails(JNIEnv *env, jobject, jstring jSysFilePath);

  JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_getVMIPAddress(JNIEnv *env, jobject, jstring jHVVMID, jstring jhypervHostName, jstring juserName, jstring jpassword);

  JNIEXPORT jint JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_generateHashforBackupFiles(JNIEnv *env, jobject, jstring repositoryPath, jstring backupIdentifier, jstring backupType, jstring isEncrypt);

  JNIEXPORT jint JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_jNIHyperVHealthCheck2016(JNIEnv *env, jobject, jstring healthCheckParametersJson, jstring vmBackupDetailsJson);

#ifdef __cplusplus
}
#endif
#endif
