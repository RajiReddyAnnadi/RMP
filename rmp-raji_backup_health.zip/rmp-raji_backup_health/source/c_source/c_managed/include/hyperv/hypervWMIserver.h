#include <jni.h>
#include <msclr\marshal.h>

using namespace System;
using namespace Microsoft::Win32;
using namespace msclr::interop;
using namespace System::Collections::Generic;
using namespace System::IO;
using namespace System::Management;
using namespace System::Xml;
using namespace System::Runtime::InteropServices; 
using namespace System::Threading;
using namespace std;

String^ getOSversion(String^ hvHostName, String^ hvuserName, String^ hvpassword);
jboolean InitializeJNIIDs(JNIEnv* jniEnv);
void logger(JNIEnv *env, int level,const char* message, ...);
String^ ConvertJStringToCSString(jstring input, JNIEnv *env);
ManagementScope^ InitializeWMICredentials(String^ hvHostName, String^ hvuserName, String^ hvpassword);
jobject PutJNIHashValue(jobject pfHT, String^ value, String^ keyvalue, JNIEnv *env);
List<String^>^ GetlistofResources(ManagementObject^ settingData, UInt16 resourceType, String^ resourceSubType, String^ storageclassName, String^ osVersion);
Dictionary<String^, String^>^ getListofVHDpathsandSize(ManagementObject^ vm, String^ osVersion, ManagementScope^ scope, bool isSizerequired, String^ isServeraddString);
double findusedsize(ManagementScope^ scope, String^ VHDpath, double usedSize);
double findusedsize2008(ManagementScope^ scope, String^ VHDpath, double usedSize, String^ isServeraddString);
void HVLog(String^ message);
String^ ConvertjsontoXMLstring(String^ jsonString);
bool validateCreds(jstring machineName, jstring userName, jstring password);