//$Id: JNIUtil.h,v 1.0 2015/10/14 12:07:09 lucky.k Exp $
#include <windows.h>
#include <jni/com_manageengine_rmp_jni_RMPManagedNative.h>
/*-----For GlobalReference-------------*/
//jclass    propClass=0;
//jmethodID propConID=0;
//jmethodID propPutID=0;
//jmethodID propGetPropertyID=0;
//jmethodID propGetID=0;
//jmethodID containsKeyID=0;

//jclass    longClass=0;
//jmethodID longValueID=0;

jclass    intClass=0;
jmethodID intConID=0;
jmethodID intValueID=0;
		
//jclass    listClass=0;
//jmethodID listGetID=0;
//jmethodID listSizeID=0;
//jmethodID listConID=0;
//jmethodID listSizeConID=0;
//jmethodID listAddID=0;
//jmethodID listRemoveID=0;
//jmethodID listAddIndexID=0;

//jclass    ListenerClass=0;  	 
//jmethodID listenerAddRowID=0;
//jmethodID listenerIsCompletedID=0; 	

//jclass    NativeErrClass=0;
//jmethodID SetErrListID=0;

jclass    gClLogger=0;
jclass    LogClass=0;
jmethodID LogID=0;
jmethodID gMtdFine=0;		
jclass    gClWinAccessProvider=0;


/*------------------------------------*/
