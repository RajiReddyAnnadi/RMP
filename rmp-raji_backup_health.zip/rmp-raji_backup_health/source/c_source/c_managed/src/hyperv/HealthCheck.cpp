#include <hyperv/com_manageengine_rmp_virtual_HVManagedNative.h>
#include <hyperv/HealthCheck.h>
#include <hyperv/hypervWMIserver.h>

jboolean InitializeHealthCheckJNIIDs(JNIEnv* env)
{
	HVLog("HealthCheck.cpp Going to  InitializeJNIIDs");
    jclass longClassRef = env->FindClass("java/lang/Long");
    longclass = (jclass)env->NewGlobalRef(longClassRef);
    longclasscons = env->GetMethodID(longclass,"<init>","(J)V");

	jclass hvBackupServerRef = (jclass)env->FindClass("com/manageengine/rmp/virtual/backup/HVBackupServer");
    hvBackupServerCls = (jclass)env->NewGlobalRef(hvBackupServerRef);
    updateHcBackupTypeofVM = env->GetStaticMethodID(hvBackupServerCls, "updateHcBackupTypeofVM", "(Ljava/lang/String;Ljava/lang/String;I)V");
    updateCorrutedBackupPoints = env->GetStaticMethodID(hvBackupServerCls, "updateCorrutedBackupPoints", "(Ljava/lang/String;Ljava/lang/String;)V");

	jniEnv = env;
	HVLog("HealthCheck.cpp Finished InitializeJNIIDs");
	return JNI_TRUE;
}

String^ ConvertWcharToCSString(wchar_t* input)
{
	String^ retVal = nullptr;
	marshal_context ^ context = gcnew marshal_context();
	retVal = context->marshal_as<String^>(input);
	if(context != nullptr)
	{
		delete context;
	}
	return retVal;
}

int generateHashforFile(LPWSTR backupFolder, LPWSTR sourceFilePath, LPWSTR backupIdentifier, LPWSTR hashType)
{
	HVLog("HealthCheck.cpp generateHashForFile started for File->" + ConvertWcharToCSString(sourceFilePath));
	DWORD bytesread = 0, cbHash = 0;
    HCRYPTPROV hProv = 0;
    HCRYPTHASH hHash = 0;
	BOOL result = FALSE;
    HANDLE hFile = NULL;
    FILE * hashFile;
    BYTE * buffer;
    buffer = new BYTE[BUFSIZE];
    BYTE rgbHash[MD5LEN];
    CHAR rgbDigits[] = "0123456789abcdef";

    wchar_t* wtextSource = new wchar_t[wcslen(sourceFilePath) + 1];
    wcscpy(wtextSource, sourceFilePath);
    wcscat(wtextSource, L"\0");

	wchar_t* wtextDest = new wchar_t[wcslen(backupFolder) + wcslen(hashType) + wcslen(L"_single_") + wcslen(backupIdentifier) + wcslen(L".txt") + 2];
	wcscpy(wtextDest, backupFolder);
    wcscat(wtextDest, L"\\");
	wcscat(wtextDest, hashType);
    wcscat(wtextDest, L"_single_");
    wcscat(wtextDest, backupIdentifier);
    wcscat(wtextDest, L".txt");
    wcscat(wtextDest, L"\0");

    _wfopen_s(&hashFile, wtextDest, L"a");

	hFile = CreateFile(wtextSource, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	if (INVALID_HANDLE_VALUE == hFile) {
		HVLog("HealthCheck.cpp  Opening file Error: " + GetLastError());
		return 458;
	}

    // Get handle to the crypto provider
	if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
        if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
            while (result = ReadFile(hFile, buffer, BUFSIZE, &bytesread, NULL)) {
                if(bytesread == 0) {
                    break;
                }else {
                    if(!CryptHashData(hHash, buffer, bytesread, 0)) {
                        HVLog("HealthCheck.cpp CryptHashData failed Error: " + GetLastError());
                        if(hHash){
                            CryptDestroyHash(hHash);
                        }
                        if(hProv) {
                            CryptReleaseContext(hProv, 0);
                        }
                        if (hashFile) {
                            fclose(hashFile);
                        }
                        if(hFile) {
                            CloseHandle(hFile);
                        }
                        return 457;
                    }
                }
            }
            if(!result) {
                HVLog("HealthCheck.cpp Read file failed error: " + GetLastError());
                if(hHash){
                    CryptDestroyHash(hHash);
                }
                if(hProv) {
                    CryptReleaseContext(hProv, 0);
                }
                if (hashFile) {
                    fclose(hashFile);
                }
                if(hFile) {
                    CloseHandle(hFile);
                }
                return 459;
            }
            cbHash = MD5LEN;
            if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0)) {
                fwprintf_s(hashFile, L"%ws\t", wtextSource);
                for (DWORD i = 0; i < cbHash; i++) {
                    fwprintf_s(hashFile, L"%c%c", rgbDigits[rgbHash[i] >> 4], rgbDigits[rgbHash[i] & 0xf]);
                }
                fwprintf(hashFile ,L"\t");
            }else {
                HVLog("HealthCheck.cpp CryptGetHashParam failed Error: " + GetLastError());
                if(hHash){
                    CryptDestroyHash(hHash);
                }
                if(hProv) {
                    CryptReleaseContext(hProv, 0);
                }
                if (hashFile) {
                    fclose(hashFile);
                }
                if(hFile) {
                    CloseHandle(hFile);
                }
                return 457;
            }
        }else {
            HVLog("HealthCheck.cpp CryptCreateHash failed Error: " + GetLastError());
            if(hProv) {
            	CryptReleaseContext(hProv, 0);
            }
        	if (hashFile) {
        		fclose(hashFile);
        	}
            if(hFile) {
                CloseHandle(hFile);
            }
            return 457;
        }
	}else {
		HVLog("HealthCheck.cpp CryptAcquireContext failed Error: " + GetLastError());
        if (hashFile) {
            fclose(hashFile);
        }
        if(hFile) {
            CloseHandle(hFile);
        }
		return 457;
	}
    if (hashFile) {
        fclose(hashFile);
    }
    if(hFile) {
        CloseHandle(hFile);
    }
	HVLog("HealthCheck.cpp generateHashForFile Ended...");
	return 0;
}

int generateHashforDirectory(LPWSTR repositoryPath, LPWSTR backupType, LPWSTR backupIdentifier, LPWSTR isEncrypt, LPWSTR hashType)
{
	int retVal = 0;
	wchar_t* backupFolder = new wchar_t[wcslen(repositoryPath) + wcslen(L"Virtual Hard Disks") + 2];
	wcscpy(backupFolder, repositoryPath);
	wcscat(backupFolder, L"\\");
	wcscat(backupFolder, L"Virtual Hard Disks");
	wcscat(backupFolder, L"\0");
	HVLog("HealthCheck.cpp Backup Directory for generate Hash -> " +  ConvertWcharToCSString(backupFolder));
	String^ backupFolderS = gcnew String(backupFolder, 0, wcslen(backupFolder));
    DirectoryInfo^ dir = gcnew DirectoryInfo(backupFolderS);
    if (!dir->Exists) {
        HVLog("HealthCheck.cpp Backup Directory not found..\n");
        throw gcnew DirectoryNotFoundException("HealthCheck.cpp Backup Directory not found");
    }else {
        if (Directory::GetFiles(backupFolderS)->Length == 0) {
            HVLog("HealthCheck.cpp Backup Directory found but folder was empty!..\n");
            throw gcnew DirectoryNotFoundException("HealthCheck.cpp Backup Directory found but folder was empty!");
        }
    }
	array<String^> ^ backupFiles;
	if (wcscmp(backupType, L"FullBackup") == 0 && wcscmp(isEncrypt, L"true") == 0) {
		backupFiles = Directory::GetFiles(backupFolderS, "*vhdx_compress_secure");
	}
	else {
		backupFiles = Directory::GetFiles(backupFolderS, "*vhdx_compress");
	}
	for each(String^ backupFile in backupFiles)
	{
		IntPtr ip = Marshal::StringToBSTR(backupFile);
		BSTR sourceFilePath = static_cast<BSTR>(ip.ToPointer());
		retVal = generateHashforFile(backupFolder, sourceFilePath, backupIdentifier, hashType);
		if (retVal) {
			return retVal;
		}
	}
	HVLog("generateHashforDirectory Ended...\n");
	return retVal;
}

int checkHash(LPWSTR destFilesDir, LPWSTR backupIdentifier)
{
	HVLog("HealthCheck.cpp checkHash started for Directory : " + ConvertWcharToCSString(destFilesDir));
	FILE * backuphashsingle;
	FILE * healthcheckhashsingle;
	int size = 1024, pos, c;
	DWORD retVal = 0;
	char *fileName;
	char *hashVal;
	std::vector<std::vector<char *>> hashDetailList;
	wchar_t* wtexthealthcheckhashsingle = new wchar_t[wcslen(destFilesDir) + wcslen(L"\\Virtual Hard Disks\\") + wcslen(L"healthcheckhash_single_") + wcslen(backupIdentifier) + wcslen(L".txt") + 1];
	wcscpy(wtexthealthcheckhashsingle, destFilesDir);
	wcscat(wtexthealthcheckhashsingle, L"\\Virtual Hard Disks\\");
	wcscat(wtexthealthcheckhashsingle, L"healthcheckhash_single_");
	wcscat(wtexthealthcheckhashsingle, backupIdentifier);
	wcscat(wtexthealthcheckhashsingle, L".txt");
	wcscat(wtexthealthcheckhashsingle, L"\0");
	_wfopen_s(&healthcheckhashsingle, wtexthealthcheckhashsingle, L"rb");
	if (healthcheckhashsingle) {
		while (1)
		{
			fileName = (char *)malloc(size);
			fileName[0] = '\0';
			hashVal = (char *)malloc((MD5LEN * 2) + 1);
			pos = 0;
			do
			{
				c = fgetc(healthcheckhashsingle);
				if (c != EOF && c != '\n' && c != '\t')
				{
					fileName[pos++] = (char)c;
				}
				if (pos >= size - 1)
				{
					size += 1024;
					fileName = (char*)realloc(fileName, size);
				}
				if (c == EOF){
					break;
				}
			} while (c != '\t');
			if (pos != 0)
			{
				fileName[pos++] = '\0';
			}
			pos = 0;
			do
			{
				c = fgetc(healthcheckhashsingle);
				if (c != EOF && c != '\n' && c != '\t')
				{
					hashVal[pos++] = (char)c;
				}
				if (pos >= size - 1)
				{
					size += 32;
					hashVal = (char*)realloc(hashVal, size);
				}
				if (c == EOF){
					break;
				}
			} while (c != '\t');
			if (pos != 0)
			{
				hashVal[pos++] = '\0';
			}
			if (strcmp(fileName, "\0") == 0){
				break;
			}
			std::vector<char *> hashDetail;
			hashDetail.push_back(fileName);
			hashDetail.push_back(hashVal);
			hashDetailList.push_back(hashDetail);
			//HVLog("HealthCheck.cpp healthcheckhashSingle Info...FileName:" + fileNameS + " HashVal:" + hashValS);
			c = fgetc(healthcheckhashsingle);
			if (c == EOF)
			{
				break;
			}
			else
			{
				fseek(healthcheckhashsingle, -1, SEEK_CUR);
			}
		}
	}
	else {
		HVLog("HealthCheck.cpp unable open healthcheckhash File error: " + GetLastError());
		return 461;
	}
	if (healthcheckhashsingle) {
		fclose(healthcheckhashsingle);
	}
	wchar_t* wtextbackuphashsingle = new wchar_t[wcslen(destFilesDir) + wcslen(L"\\Virtual Hard Disks\\") + wcslen(L"backuphash_single_") + wcslen(backupIdentifier) + wcslen(L".txt") + 1];
	wcscpy(wtextbackuphashsingle, destFilesDir);
	wcscat(wtextbackuphashsingle, L"\\Virtual Hard Disks\\");
	wcscat(wtextbackuphashsingle, L"backuphash_single_");
	wcscat(wtextbackuphashsingle, backupIdentifier);
	wcscat(wtextbackuphashsingle, L".txt");
	wcscat(wtextbackuphashsingle, L"\0");
	_wfopen_s(&backuphashsingle, wtextbackuphashsingle, L"rb");
	if (backuphashsingle) {
		while (1)
		{
			fileName = (char *)malloc(size);
			fileName[0] = '\0';
			hashVal = (char *)malloc((MD5LEN * 2) + 1);
			pos = 0;
			do
			{
				c = fgetc(backuphashsingle);
				if (c != EOF && c != '\n' && c != '\t')
				{
					fileName[pos++] = (char)c;
				}
				if (pos >= size - 1)
				{
					size += 1024;
					fileName = (char*)realloc(fileName, size);
				}
				if (c == EOF){
					break;
				}
			} while (c != '\t');
			if (pos != 0)
			{
				fileName[pos++] = '\0';
			}
			pos = 0;
			do
			{
				c = fgetc(backuphashsingle);
				if (c != EOF && c != '\n' && c != '\t')
				{
					hashVal[pos++] = (char)c;
				}
				if (pos >= size - 1)
				{
					size += 32;
					hashVal = (char*)realloc(hashVal, size);
				}
				if (c == EOF){
					break;
				}
			} while (c != '\t');
			if (pos != 0)
			{
				hashVal[pos++] = '\0';
			}
			if (strcmp(fileName, "\0") == 0){
				break;
			}
			//HVLog("HealthCheck.cpp backuphashSingle Info...FileName:" + fileNameS + " HashVal:" + hashValS);
			if (hashDetailList.empty())
			{
				HVLog("HealthCheck.cpp Missing of File: ");// + fileName);
				if (backuphashsingle) {
					fclose(backuphashsingle);
				}
				return 1;
			}
			for (int i = 0; i < hashDetailList.size(); i++) {
				if (strcmp(hashDetailList[i][0], fileName) == 0) {
					if (strcmp(hashDetailList[i][1], hashVal) == 0) {
						hashDetailList.erase(hashDetailList.begin() + i);
						break;
					} else{
						HVLog("HealthCheck.cpp Couruption in File: ");// + fileName);
						if (backuphashsingle) {
							fclose(backuphashsingle);
						}
						return 1;
					}
				}else {
					if (hashDetailList.size() - 1 == i) {
						HVLog("HealthCheck.cpp Missing of File: ");// + fileName);
						if (backuphashsingle) {
							fclose(backuphashsingle);
						}
						return 1;
					}
				}
			}
			c = fgetc(backuphashsingle);
			if (c == EOF)
			{
				break;
			}
			else
			{
				fseek(backuphashsingle, -1, SEEK_CUR);
			}
		}
	}
	else {
		HVLog("HealthCheck.cpp unable read backuphash File: %d" + GetLastError());
		return 461;
	}
	if (backuphashsingle) {
		fclose(backuphashsingle);
	}
	HVLog("HealthCheck.cpp checkHash ended....");
	return retVal;
}

int performHealthCheck(List<backupDetails^>^ backupDetailsList, LPWSTR backupId, LPWSTR vmId, LPWSTR isEncrypted)
{
    HVLog("HealthCheck.cpp performHealthCheck started...");
    int hcBkupType = 0, returnVal = 0;
    try {
        for each(backupDetails^ backupDetail in backupDetailsList) {
            marshal_context ^ context = gcnew marshal_context();
            String^ vmbackupPathString = backupDetail->backupPath;
            const __wchar_t* vmbackupPathCW = context->marshal_as<const __wchar_t*>(vmbackupPathString);
            wchar_t* vmbackupPath = const_cast< wchar_t* >(vmbackupPathCW);

            String^ backupTypeString = backupDetail->backupType;
            const __wchar_t* backupTypeCW = context->marshal_as<const __wchar_t*>(backupTypeString);
            wchar_t* backupType = const_cast< wchar_t* >(backupTypeCW);

            String^ backupIdentifierString = backupDetail->backupIdentifier;
            const __wchar_t* backupIdentifierCW = context->marshal_as<const __wchar_t*>(backupIdentifierString);
            wchar_t* backupIdentifier = const_cast< wchar_t* >(backupIdentifierCW);

            returnVal = generateHashforDirectory(vmbackupPath, backupType, backupIdentifier, isEncrypted, L"healthcheckhash");
            HVLog("HealthCheck.cpp  generateHashforDirectory for BackupFiles. return value :" + returnVal);
            if (returnVal)
            {
                return returnVal;
            }
            returnVal = checkHash(vmbackupPath, backupIdentifier);
            HVLog("HealthCheck.cpp  checkHash for BackupFiles. return value :" + returnVal);
            if (returnVal) {
                if (returnVal == 1) {
                    jstring jbackupIdentifier = jniEnv->NewString((jchar*)backupIdentifier,wcslen(backupIdentifier));
                    jstring jvmId = jniEnv->NewString((jchar*)vmId,wcslen(vmId));
                    jniEnv->CallStaticVoidMethod(hvBackupServerCls, updateCorrutedBackupPoints, jbackupIdentifier, jvmId);
                    if(wcscmp(backupType, L"FullBackup") == 0) {
                        hcBkupType = 1;
                    } else {
                        hcBkupType = 2;
                    }
                    returnVal = 0;
                    break;
                }
                return returnVal;
            }
        }
        jstring jbackupId = jniEnv->NewString((jchar*)backupId,wcslen(backupId));
        jstring jvmId = jniEnv->NewString((jchar*)vmId,wcslen(vmId));
        jniEnv->CallStaticVoidMethod(hvBackupServerCls, updateHcBackupTypeofVM, jbackupId, jvmId, hcBkupType);
    }catch (Exception^ e) {
        HVLog("HealthCheck.cpp performHealthCheck Exception message: " + e->Message);
        return 460;
    }
    return returnVal;
}


extern "C"
{
    int PerformHyperVHealthCheck(jstring healthCheckParametersJson, jstring vmBackupDetailsJson)
    {
        HVLog("HealthCheck.cpp PerformHyperVHealthCheck");
        int returnVal = 0;
        try {
            healthCheckParameters^ parameters;
            try {
                String^ healthCheckParametersString = ConvertJStringToCSString(healthCheckParametersJson, jniEnv);
                healthCheckParametersString = healthCheckParametersString->Replace("###", "\"");
                HVLog("HealthCheck.cpp PerformHyperVHealthCheck Going to parse healthCheckParameters JSON string...");
                parameters = Newtonsoft::Json::JsonConvert::DeserializeObject <healthCheckParameters^> (healthCheckParametersString);
                HVLog("HealthCheck.cpp PerformHyperVHealthCheck Done parsing healthCheckParameters JSON string...");
            } catch (Exception ^ ex) {
                HVLog("exception caught while parsing healthCheckParameters - >" + ex->Message);
            }

            marshal_context ^ context = gcnew marshal_context();
            String^ backupIdString = parameters->backupId;
            const __wchar_t* backupIdCW = context->marshal_as<const __wchar_t*>(backupIdString);
            wchar_t* backupId = const_cast< wchar_t* >(backupIdCW);

            String^ vmIdString = parameters->vmId;
            const __wchar_t* vmIdCW = context->marshal_as<const __wchar_t*>(vmIdString);
            wchar_t* vmId = const_cast< wchar_t* >(vmIdCW);

            String^ isEncryptedString = parameters->isEncrypted;
            const __wchar_t* isEncryptedCW = context->marshal_as<const __wchar_t*>(isEncryptedString);
            wchar_t* isEncrypted = const_cast< wchar_t* >(isEncryptedCW);

            List<backupDetails^>^ backupDetailsList;
            try {
                String^ backupDetailsString = ConvertJStringToCSString(vmBackupDetailsJson, jniEnv);
                backupDetailsString = backupDetailsString->Replace("###", "\"");
                HVLog("HealthCheck.cpp PerformHyperVHealthCheck Going to parse backupDetails JSON string...");
                backupDetailsList = Newtonsoft::Json::JsonConvert::DeserializeObject<List<backupDetails^>^>(backupDetailsString);
                HVLog("HealthCheck.cpp PerformHyperVHealthCheck Done parsing backupDetails JSON string...");
            } catch (Exception ^ ex) {
                HVLog("HealthCheck.cpp PerformHyperVHealthCheck Exception caught while parsing backupDetails -> " + ex->Message);
            }

            returnVal = performHealthCheck(backupDetailsList, backupId, vmId, isEncrypted);

            HVLog("HealthCheck.cpp  PerformHyperVHealthCheck ended...!!! ");
        }catch (Exception^ e) {
            HVLog("HealthCheck.cpp PerformHyperVHealthCheck Exception message: " + e->Message);
            return 460;
    	}
        return returnVal;

    }
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_generateHashforBackupFiles(JNIEnv *env, jobject, jstring repositoryPath, jstring backupIdentifier, jstring backupType, jstring isEncrypt)
{
    HVLog("HealthCheck.cpp generateHashforBackupFiles started....");
//    InitializeJNIIDs(env);
    LPWSTR LrepositoryPath = NULL, LbackupType = NULL, LisEncrypt = NULL, LbackupIdentifier = NULL;
    LrepositoryPath = (LPWSTR)env->GetStringChars(repositoryPath, NULL);
    LbackupIdentifier = (LPWSTR)env->GetStringChars(backupIdentifier, NULL);
    LbackupType = (LPWSTR)env->GetStringChars(backupType, NULL);
    LisEncrypt = (LPWSTR)env->GetStringChars(isEncrypt, NULL);
    try {
        int result = generateHashforDirectory(LrepositoryPath, LbackupType, LbackupIdentifier, LisEncrypt, L"backuphash");
        HVLog("HealthCheck.cpp generateHashforDirectory return value : " + result);
        return result;
    }catch (Exception ^ ex) {
        HVLog("Exception -> " + ex->Message);
        return 457;
    }
}


JNIEXPORT jint JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_jNIHyperVHealthCheck2016(JNIEnv *env, jobject, jstring healthCheckParametersJson, jstring vmBackupDetailsJson)
{
    HVLog("HealthCheck.cpp jNIHyperVHealthCheck2016");
    InitializeHealthCheckJNIIDs(env);
    try {
        return PerformHyperVHealthCheck(healthCheckParametersJson, vmBackupDetailsJson);
    }catch (Exception ^ ex) {
        HVLog("Exception -> " + ex->Message);
        return 460;
    }
}