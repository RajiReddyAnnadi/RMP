#include <hyperv/JNIHVUtil.h>
#include <fstream>
#include <iostream>
#include <hyperv/com_manageengine_rmp_virtual_HVManagedNative.h>
using namespace std;

JNIEXPORT void JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_jNIHVInitializeClassIDs
  (JNIEnv *env, jclass obj)
{	
	try
	{
	//jclass LRefpropClass = env->FindClass("java/util/Properties"); 
	//propClass = (jclass)env->NewGlobalRef(LRefpropClass);
	//propConID = env->GetMethodID(propClass, "<init>", "()V");
	//propPutID = env->GetMethodID(propClass, "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
	//propGetPropertyID = env->GetMethodID(propClass, "getProperty", "(Ljava/lang/String;)Ljava/lang/String;");
	//propGetID = env->GetMethodID(propClass, "get", "(Ljava/lang/Object;)Ljava/lang/Object;");
	//containsKeyID =env->GetMethodID(propClass, "containsKey", "(Ljava/lang/Object;)Z");

	//jclass LReflongClass = env->FindClass("java/lang/Long"); 
	//longClass = (jclass)env->NewGlobalRef(LReflongClass); 
	//longValueID = env->GetMethodID(longClass, "longValue", "()J");

		jclass LRefintClass = env->FindClass("java/lang/Integer"); 
		intClass = (jclass)env->NewGlobalRef(LRefintClass);  
		intConID = env->GetMethodID(intClass, "<init>", "(I)V");
		intValueID = env->GetMethodID(intClass, "intValue", "()I");

	//jclass LReflistClass = env->FindClass("java/util/ArrayList"); 
	//listClass = (jclass)env->NewGlobalRef(LReflistClass);   
	//listSizeID = env->GetMethodID(listClass, "size", "()I");
	//listGetID = env->GetMethodID(listClass, "get", "(I)Ljava/lang/Object;");
	//listConID = env->GetMethodID(listClass, "<init>", "()V");
	//listSizeConID = env->GetMethodID(listClass, "<init>", "(I)V");
	//listAddID = env->GetMethodID(listClass, "add", "(Ljava/lang/Object;)Z");
	//listAddIndexID = env->GetMethodID(listClass, "add", "(ILjava/lang/Object;)V");
	//listRemoveID = env->GetMethodID(listClass, "remove", "(I)Ljava/lang/Object;");

	//jclass LRefNativeErrClass = env->FindClass("com/manageengine/rmp/jni/RMPErrorHandler");
	//NativeErrClass = (jclass)env->NewGlobalRef(LRefNativeErrClass);   
	//SetErrListID = env->GetMethodID(NativeErrClass, "setErrorList", "(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V");

		jclass LRefgClLogger = env->FindClass("java/util/logging/Logger");
		gClLogger = (jclass)env->NewGlobalRef(LRefgClLogger);   
		if (gClLogger == NULL)
		{
			printf("Could not find class java.util.logging.Logger!\n");
		}

		jclass LRefLogClass = env->FindClass("com/manageengine/rmp/jni/NativeLogger");
		LogClass = (jclass)(env)->NewGlobalRef(LRefLogClass);
		if (LogClass == NULL)
		{
			printf("Could not find class LogClass!\n");		
		}
		LogID = env->GetStaticMethodID(LogClass, "log", "(ILjava/lang/String;)V");
		gMtdFine = env->GetMethodID(gClLogger, "info", "(Ljava/lang/String;)V");
		if (gMtdFine == NULL)
		{
			printf("Could not find method 'void fine(String)' method in java.util.logging.Logger!\n");
		}

		jclass LRefgClWinAccessProvider = env->FindClass("com/manageengine/rmp/jni/RMPManagedNative");
		gClWinAccessProvider = (jclass)env->NewGlobalRef(LRefgClWinAccessProvider);   
		if (gClWinAccessProvider == NULL)
		{
			printf("Could not find class com/manageengine/rmp/jni/RMPManagedNative!\n");
		}
	}
	catch(exception& e)
	{
		printf("EXCEPTION!!!!!!!!!!!!!!!!!!!!!!!!!");
	}
}


