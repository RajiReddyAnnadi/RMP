#include <hyperv/com_manageengine_rmp_virtual_HVManagedNative.h>
#include <hyperv/hypervWMIserver.h>

jclass LReflistClass;
jclass jClHashtable;
jclass virtualMachineUtilClass;
jmethodID listConID;
jmethodID listAddID;
jmethodID jConHashtable;
jmethodID jMtdPutHashtable;
jmethodID jMtdGetHashtable;
jmethodID jsontoxmlMethodID;

JNIEnv* jniEnvironment;

jboolean InitializeJNIIDs(JNIEnv* jniEnv)
{
	HVLog(L"hypervwmiserver.cpp Going to  InitializeJNIIDs");
	LReflistClass = jniEnv->FindClass("java/util/ArrayList"); 
	listConID = jniEnv->GetMethodID(LReflistClass, "<init>", "()V");
	listAddID = jniEnv->GetMethodID(LReflistClass, "add", "(Ljava/lang/Object;)Z");
	jclass LRefHashClass = jniEnv->FindClass("java/util/Hashtable");
	jClHashtable = (jclass)jniEnv->NewGlobalRef(LRefHashClass);
	jConHashtable = jniEnv->GetMethodID(jClHashtable,"<init>","()V");
	jMtdPutHashtable = jniEnv->GetMethodID(jClHashtable,"put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
	jMtdGetHashtable = jniEnv->GetMethodID(jClHashtable,"get", "(Ljava/lang/Object;)Ljava/lang/Object;");
	jclass LRefvmClass = jniEnv->FindClass("com/manageengine/rmp/virtual/VirtualMachineUtil"); 
	if (LRefvmClass == NULL)
	{
		HVLog(L"hypervwmiserver.cpp Cannot find VMUtil class");
	}
	virtualMachineUtilClass = (jclass)jniEnv->NewGlobalRef(LRefvmClass);  
	if (virtualMachineUtilClass == NULL)
	{
		HVLog(L"hypervwmiserver.cpp Cannot find LRefvmClass class");
	}
	jsontoxmlMethodID = jniEnv->GetStaticMethodID(virtualMachineUtilClass, "convertjsonstringtoXMLstring", "(Ljava/lang/String;)Ljava/lang/String;");
	if (LRefvmClass == NULL)
	{
		HVLog(L"hypervwmiserver.cpp Cannot find convertjsonstringtoXMLstring method");
	}
	else
	{
		HVLog(L"hypervwmiserver.cpp found convertjsonstringtoXMLstring method");
	}
	jniEnvironment = jniEnv;
	HVLog(L"hypervwmiserver.cpp Finished InitializeJNIIDs");
	return JNI_TRUE;
}

String^ ConvertjsontoXMLstring(String^ jsonString)
{
	HVLog(L"hypervwmiserver.cpp ConvertjsontoXMLstring started..!");
	if(jsonString == nullptr)
	{
		HVLog(L"hypervwmiserver.cpp ConvertjsontoXMLstring jsonString is nullptr..!");
		return "-";
	}
	String^ xmlString = "-";
	try
	{
		marshal_context ^ context = gcnew marshal_context();
		const __wchar_t* Str = context->marshal_as<const __wchar_t*>(jsonString);
		jstring jjsonString = jniEnvironment->NewString((jchar*)(Str), wcslen(Str));
		jstring jXMLstring = (jstring)jniEnvironment->CallStaticObjectMethod(virtualMachineUtilClass,jsontoxmlMethodID,jjsonString);
		xmlString = ConvertJStringToCSString(jXMLstring, jniEnvironment);
		if(context != nullptr)
		{
			delete context;
		}
	}
	catch(Exception^ ex)
	{
		HVLog(L"hypervwmiserver.cpp ConvertjsontoXMLstring thrown " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
	}
	return xmlString;
}

void HVLog(String^ message)
{
	try
	{
		String^ path = "..\\logs\\rmp_hyperv_" + DateTime::Now.ToString("yyyy-MM-dd") + ".txt";
		//lock(lockThis)
		//{
		if (!File::Exists(path))
		{
			StreamWriter^ sw = File::CreateText(path);
			sw->Close();
		}
		StreamWriter^ sw = File::AppendText(path);
		try
		{
			sw->Write(DateTime::Now + " : " + Thread::CurrentThread->ManagedThreadId + " -> " + message + Environment::NewLine);
		}
		finally
		{
			sw->Flush();
			sw->Close();
		}
		//}
	}
	catch (Exception^ e)
	{
		//Console.WriteLine("CS Logger : " + e.Message + e.StackTrace);
	}
}


String^ ConvertJStringToCSString(jstring input, JNIEnv *env)
{
	String^ retVal = nullptr;
	marshal_context ^ context = gcnew marshal_context();
	LPWSTR cInput = (LPWSTR)env->GetStringChars((jstring)input, NULL);
	retVal = context->marshal_as<String^>(cInput);
	env->ReleaseStringChars((jstring)input, (jchar*)cInput);
	if(context != nullptr)
	{
		delete context;
	}
	return retVal;
}

jobject PutJNIHashValue(jobject pfHT, String^ value, String^ keyvalue, JNIEnv *env) 
{
	if(value == nullptr)
	{
		value = "-";
	}
	marshal_context ^ context = gcnew marshal_context();
	const char * key = context->marshal_as<const char *>(keyvalue);
	jstring jKey = env->NewStringUTF(key);
	const __wchar_t* Str = context->marshal_as<const __wchar_t*>(value);
	jstring jStr = env->NewString((jchar*)(Str), wcslen(Str));
	env->CallObjectMethod(pfHT, jMtdPutHashtable, jKey, jStr);
	if(jStr != NULL)
	{
		env->DeleteLocalRef(jStr);
	}
	if(jKey != NULL)
	{
		env->DeleteLocalRef(jKey);
	}
	if(context != nullptr)
	{
		delete context;
	}
	return pfHT;	
}

bool validateCreds(jstring machineName, jstring userName, jstring password)
{
	HVLog("validateCreds started..");
	String^ hvHostName=ConvertJStringToCSString(machineName, jniEnvironment);
	String^ hvuserName=ConvertJStringToCSString(userName, jniEnvironment);
	HVLog("validateCreds Details..machineName -> " + hvHostName + " username -> " + hvuserName);
	try
	{
		if(hvuserName == nullptr || hvuserName->Equals("-"))
		{
			HVLog("validateCreds userName is - ..Returning true");
			return true;
		}
		array<String^>^ userdomain = hvuserName->Split(L'\\');
		HVLog("validateCreds Details DomainName -> " + userdomain[0]);
		HVLog("validateCreds Details User -> " + userdomain[1]);

		marshal_context ^ context = gcnew marshal_context();
		String^ usertemp = userdomain[0];
		String^ passtemp = userdomain[1];
		const wchar_t* temp1 = context->marshal_as<const wchar_t*>(usertemp);
		jstring domain = jniEnvironment->NewString((jchar*)(temp1), wcslen(temp1));
		const wchar_t* temp2 = context->marshal_as<const wchar_t*>(passtemp);
		jstring user = jniEnvironment->NewString((jchar*)(temp2), wcslen(temp2));

		LPWSTR ldomainName= (LPWSTR)jniEnvironment->GetStringChars(domain, NULL);
		LPWSTR luserName= (LPWSTR)jniEnvironment->GetStringChars(user, NULL);
		LPWSTR lpassword= (LPWSTR)jniEnvironment->GetStringChars(password, NULL);
		
		HANDLE lTokenHandle = NULL; 
		BOOL ret = LogonUser(luserName, ldomainName, lpassword, LOGON32_LOGON_NETWORK, LOGON32_PROVIDER_DEFAULT, &lTokenHandle);
        if(ret)
        {
        	HVLog("validateCreds returned TRUE..!");
        }
        else
        {
        	HVLog("validateCreds returned FALSE..!");
        }
        return ret;
    }
    catch (Exception^ ex)
    {
    	HVLog("validateCreds Exception.." + ex->Message);
    	return false;
    }
}

String^ getOSversion(jstring jhvHostName, jstring jhvuserName, jstring jhvpassword)
{
	String^ osVersion = "-";
	String^ hvHostName=ConvertJStringToCSString(jhvHostName, jniEnvironment);
	String^ hvuserName=ConvertJStringToCSString(jhvuserName, jniEnvironment);
	String^ hvpassword=ConvertJStringToCSString(jhvpassword, jniEnvironment);
	try
	{	

		ManagementScope^ scope;

		ConnectionOptions^ co = gcnew ConnectionOptions();
		co->Username = hvuserName;
		co->Password = hvpassword;
		co->EnablePrivileges = true;

		String^ managementPath = "\\\\"+hvHostName+"\\root\\cimv2";	
		HVLog(L"HyperV getOSversion HostName: " + hvHostName + "\nPath: " + managementPath);
		if(hvuserName->Equals("-"))
		{
			HVLog(L"getOSversion Using NULL credentials to create scope");
			scope = gcnew ManagementScope(managementPath);
		}
		else
		{
			HVLog(L"getOSversion Using EXPLICIT credentials to create scope");
			scope = gcnew ManagementScope(managementPath, co);		
		}

		String^ query = "select * from Win32_OperatingSystem";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ instances = searcher->Get();
		for each (ManagementObject^ mo in instances)
		{
			HVLog("OSVersion-> " + mo["Version"]->ToString());
			osVersion = mo["Version"]->ToString();
		}
	}
	catch (Exception^ ex)
	{
		HVLog(L"hypervwmiserver.cpp Exception1 thrown getOSversion: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
		try
		{
			HVLog(L"hypervwmiserver getOSversion Checking if provided credentials are valid");
			if(ex->Message->Contains("User credentials cannot be used for local connections"))
			{
				HVLog(L"hypervwmiserver.cpp Trying LogonUser");
				bool isValidCreds = validateCreds(jhvHostName, jhvuserName, jhvpassword);
				HVLog(L"hypervwmiserver getOSversion validateCreds returned -> " + isValidCreds);
				if(!isValidCreds)
				{
					HVLog(L"hypervwmiserver getOSversion Since credentials invalid, returning - as OSversion..");
					return "-";
				}
				HVLog(L"hypervwmiserver.cpp Trying with local credentials");
				String^ managementPath = "\\\\"+hvHostName+"\\root\\cimv2";
				ManagementScope^ scope = gcnew ManagementScope(managementPath);
				String^ query = "select * from Win32_OperatingSystem";
				ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(scope, gcnew ObjectQuery(query));
				ManagementObjectCollection^ instances = searcher->Get();
				for each (ManagementObject^ mo in instances)
				{
					HVLog("OSVersion-> " + mo["Version"]->ToString());
					osVersion = mo["Version"]->ToString();
				}
			}
			else
			{
				HVLog(L"hypervwmiserver.cpp getOSversion Exception. Not local credentials exception..");
			}
		}
		catch (Exception^ ex)
		{
			HVLog(L"hypervwmiserver.cpp Exception2 thrown getOSversion: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
		}
	}
	return osVersion;
	
}


ManagementScope^ InitializeWMICredentials(jstring jhvHostName, jstring jhvuserName, jstring jhvpassword)
{
	ManagementScope^ scope;
	String^ managementPath;
	try
	{
		String^ hvHostName=ConvertJStringToCSString(jhvHostName, jniEnvironment);
		String^ hvuserName=ConvertJStringToCSString(jhvuserName, jniEnvironment);
		String^ hvpassword=ConvertJStringToCSString(jhvpassword, jniEnvironment);

		ConnectionOptions^ co = gcnew ConnectionOptions();
		co->Username = hvuserName;
		co->Password = hvpassword;
		co->EnablePrivileges = true;

		String^ osVersion = getOSversion(jhvHostName, jhvuserName, jhvpassword);
		
		if(osVersion->Equals("-"))
		{
			HVLog(L"Not able to get oS version assuming host has a virtualization\V2 namespace");
			managementPath = "\\\\"+hvHostName+"\\root\\virtualization\\v2";
		}
		else
		{
			if(osVersion->StartsWith("6.1") || osVersion->StartsWith("6.0"))
			{
				managementPath = "\\\\"+hvHostName+"\\root\\virtualization";				
			}
			else if(osVersion->StartsWith("6.2") || osVersion->StartsWith("6.3") || osVersion->StartsWith("10.0"))
			{
				managementPath = "\\\\"+hvHostName+"\\root\\virtualization\\v2";
			}
		}

		HVLog(L"HyperV HostName: " + hvHostName + "\nPath: " + managementPath);
		if(hvuserName->Equals("-"))
		{
			HVLog(L"InitializeWMICredentials Using NULL credentials to create scope");
			scope = gcnew ManagementScope(managementPath);
		}
		else
		{
			HVLog(L"InitializeWMICredentials Using EXPLICIT credentials to create scope");
			scope = gcnew ManagementScope(managementPath, co);		
		}
		String^ query = "select * from Win32_OperatingSystem";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(scope, gcnew ObjectQuery(query));		
		ManagementObjectCollection^ instances = searcher->Get();
	}
	catch (Exception^ ex)
	{
		HVLog(L"hypervwmiserver InitializeWMICredentials Exception1 thrown: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
		scope=nullptr;
		if(ex->Message->Contains("User credentials cannot be used for local connections"))
		{
			HVLog(L"hypervwmiserver InitializeWMICredentials Checking if provided credentials are valid");
			bool isValidCreds = validateCreds(jhvHostName, jhvuserName, jhvpassword);
			HVLog(L"hypervwmiserver InitializeWMICredentials validateCreds returned -> " + isValidCreds);
			if(!isValidCreds)
			{
				HVLog(L"hypervwmiserver InitializeWMICredentials Since credentials invalid, returning nullptr as scope..");
				return nullptr;
			}
			try
			{
				HVLog(L"hypervwmiserver.cpp InitializeWMICredentials Trying with local credentials");
				scope = gcnew ManagementScope(managementPath);			
			}
			catch (Exception^ ex)
			{
				HVLog(L"hypervwmiserver.cpp InitializeWMICredentials Exception2 thrown : " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
				scope=nullptr;
			}
		}
		else
		{
			HVLog(L"hypervwmiserver InitializeWMICredentials Not expected exception..");
			return nullptr;
		}
	}
	return scope;

}

List<String^>^ GetlistofResources(ManagementObject^ settingData, UInt16 resourceType, String^ resourceSubType, String^ storageclassName, String^ osVersion)
{
	List<String^>^ VHDlist = gcnew List<String^>();

	try
	{
		ManagementObjectCollection^ RASDs = settingData->GetRelated(storageclassName); 
		for each(ManagementObject^ rasdInstance in RASDs)
		{
			if (Convert::ToUInt16(rasdInstance["ResourceType"]) == resourceType) 
			{
				if (rasdInstance["ResourceSubType"]->ToString()->Equals(resourceSubType))
				{
					array<String^>^ VHDarray = gcnew array<String^>(10);
					if(osVersion->StartsWith("5") || osVersion->StartsWith("6.0") || osVersion->StartsWith("6.1"))
					{
						VHDarray = (array<String^>^)rasdInstance["Connection"];
					}
					else
					{
						VHDarray = (array<String^>^)rasdInstance["HostResource"];
					}
					for each(String^ VHD in VHDarray)
					{
						HVLog("VHD Path" + VHD);
						VHDlist->Add(VHD);
					}
				}
			}

		}
	}
	catch (Exception^ ex)
	{
		HVLog(L"Exception thrown GetListofResources: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
	}
	return VHDlist;

}

double findusedsize(ManagementScope^ scope, String^ VHDpath, double usedSize)
{
	try
	{
		String^ query = "select * from Msvm_ImageManagementService";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ vms = searcher->Get();
		ManagementObject^ vmImageManagementService = gcnew ManagementObject();

		for each (ManagementObject^ vm in vms)
		{
			vmImageManagementService = vm;
		}

		ManagementBaseObject^ inParams = vmImageManagementService->GetMethodParameters("GetVirtualHardDiskSettingData");
		inParams["Path"] = VHDpath;
		ManagementBaseObject^ outParams = vmImageManagementService->InvokeMethod("GetVirtualHardDiskSettingData", inParams, nullptr);
		String^ vhdsettingxmlString = outParams["SettingData"]->ToString();
		XmlDocument^ doc = gcnew XmlDocument();
		try
		{
			doc->LoadXml(vhdsettingxmlString);
		}
		catch(Exception^ e)
		{
			HVLog(L"Exception thrown LoadXml: " + e->Message + "\n Stacktrace: " + e->StackTrace);
			if(e->Message->Contains("Data at the root level is invalid"))
			{
				HVLog(L"vhdsettingxmlString Before ConvertjsontoXMLstring -> " + vhdsettingxmlString);
				vhdsettingxmlString = ConvertjsontoXMLstring(vhdsettingxmlString);
				HVLog(L"vhdsettingxmlString After ConvertjsontoXMLstring -> " + vhdsettingxmlString);
				doc->LoadXml(vhdsettingxmlString);
			}
			else
			{
				throw e;
			}
		}
		XmlNodeList^ nodelist = doc->SelectNodes("//PROPERTY[@NAME = 'ParentPath']/VALUE/child::text()");
		if (nodelist->Count != 1)
		{
			HVLog(L"No nodes found at first attempt1");
			nodelist = doc->SelectNodes("/root/ParentPath");
		}

		if (nodelist->Count != 1)
		{
		//Used size
			inParams = vmImageManagementService->GetMethodParameters("GetVirtualHardDiskState");
			inParams["Path"] = VHDpath;
			outParams = vmImageManagementService->InvokeMethod("GetVirtualHardDiskState", inParams, nullptr);
			vhdsettingxmlString = outParams["State"]->ToString();
			doc = gcnew XmlDocument();
			try
			{
				doc->LoadXml(vhdsettingxmlString);
			}
			catch(Exception^ e)
			{
				HVLog(L"Exception thrown LoadXml: " + e->Message + "\n Stacktrace: " + e->StackTrace);
				if(e->Message->Contains("Data at the root level is invalid"))
				{
					HVLog(L"vhdsettingxmlString Before ConvertjsontoXMLstring -> " + vhdsettingxmlString);
					vhdsettingxmlString = ConvertjsontoXMLstring(vhdsettingxmlString);
					HVLog(L"vhdsettingxmlString After ConvertjsontoXMLstring -> " + vhdsettingxmlString);
					doc->LoadXml(vhdsettingxmlString);
				}
				else
				{
					throw e;
				}
			}
			nodelist = doc->SelectNodes("//PROPERTY[@NAME = 'FileSize']/VALUE/child::text()");
			if (nodelist->Count != 1)
			{
				HVLog(L"No nodes found at first attempt2");
				nodelist = doc->SelectNodes("/root/FileSize");
			}
			if (nodelist->Count != 1)
			{
				HVLog("Some error when finding FileSize");
			}
			else
			{
				for each(XmlNode^ xn in nodelist)
				{
					usedSize = usedSize + Convert::ToDouble(xn->InnerText);
				}
			}
            HVLog("VHDpath for used size calculation -> " + VHDpath);
            HVLog("It's used size -> " + Convert::ToString(usedSize));
			return usedSize;
		}
		else
		{
            HVLog("We have an AVHD..!");
			double thisSize = 0.0;
			String^ path = "-";
			for each(XmlNode^ xn in nodelist)
			{
				path = xn->InnerText;
			}

			inParams = vmImageManagementService->GetMethodParameters("GetVirtualHardDiskState");
			inParams["Path"] = VHDpath;
			outParams = vmImageManagementService->InvokeMethod("GetVirtualHardDiskState", inParams, nullptr);
			vhdsettingxmlString = outParams["State"]->ToString();
			doc = gcnew XmlDocument();
			try
			{
				doc->LoadXml(vhdsettingxmlString);
			}
			catch(Exception^ e)
			{
				HVLog(L"Exception thrown LoadXml: " + e->Message + "\n Stacktrace: " + e->StackTrace);
				if(e->Message->Contains("Data at the root level is invalid"))
				{
					HVLog(L"vhdsettingxmlString Before ConvertjsontoXMLstring -> " + vhdsettingxmlString);
					vhdsettingxmlString = ConvertjsontoXMLstring(vhdsettingxmlString);
					HVLog(L"vhdsettingxmlString After ConvertjsontoXMLstring -> " + vhdsettingxmlString);
					doc->LoadXml(vhdsettingxmlString);
				}
				else
				{
					throw e;
				}
			}
			nodelist = doc->SelectNodes("//PROPERTY[@NAME = 'FileSize']/VALUE/child::text()");
			if (nodelist->Count != 1)
			{
				HVLog(L"No nodes found at first attempt3");
				nodelist = doc->SelectNodes("/root/FileSize");
			}
			if (nodelist->Count != 1)
			{
				HVLog("Some error when finding  FileSize");
			}
			else
			{
				for each(XmlNode^ xn in nodelist)
				{
					thisSize = Convert::ToDouble(xn->InnerText);
				}
			}		
			HVLog("AVHD name -> " + Convert::ToString(thisSize));
			HVLog("thisSize 2008 of AVHD -> " + VHDpath);
			HVLog("It's parent path -> " + path);
			usedSize = thisSize + findusedsize(scope, path, usedSize);
		}
	}
	catch (Exception^ ex)
	{
		HVLog(L"Exception thrown findusedsize: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
	}
	return usedSize;
	
}

double findusedsize2008(ManagementScope^ scope, String^ VHDpath, double usedSize, String^ isServeraddString)
{
	try
	{
		String^ query = "select * from Msvm_ImageManagementService";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ vms = searcher->Get();
		ManagementObject^ vmImageManagementService = gcnew ManagementObject();

		for each (ManagementObject^ vm in vms)
		{
			vmImageManagementService = vm;
		}

		ManagementBaseObject^ inParams = vmImageManagementService->GetMethodParameters("GetVirtualHardDiskInfo");
		inParams["Path"] = VHDpath;
		ManagementBaseObject^ outParams = vmImageManagementService->InvokeMethod("GetVirtualHardDiskInfo", inParams, nullptr);
		String^ vhdsettingxmlString = outParams["Info"]->ToString();
		XmlDocument^ doc = gcnew XmlDocument();
		try
		{
			doc->LoadXml(vhdsettingxmlString);
		}
		catch(Exception^ e)
		{
			HVLog(L"Exception thrown LoadXml: " + e->Message + "\n Stacktrace: " + e->StackTrace);
			if(e->Message->Contains("Data at the root level is invalid") && isServeraddString!=nullptr && isServeraddString->Equals("true"))
			{
				HVLog(L"vhdsettingxmlString Before ConvertjsontoXMLstring -> " + vhdsettingxmlString);
				vhdsettingxmlString = ConvertjsontoXMLstring(vhdsettingxmlString);
				HVLog(L"vhdsettingxmlString After ConvertjsontoXMLstring -> " + vhdsettingxmlString);
				doc->LoadXml(vhdsettingxmlString);
			}
			else
			{				
				HVLog(L"vhdsettingxmlStringfindusedsize2008 not gathering size for refresh..!");
				throw e;
			}
		}
		XmlNodeList^ nodelist = doc->SelectNodes("//PROPERTY[@NAME = 'ParentPath']/VALUE/child::text()");
		if (nodelist->Count != 1)
		{
			HVLog(L"No nodes found at first attempt4");
			nodelist = doc->SelectNodes("/root/ParentPath");
		}

		if (nodelist->Count != 1)
		{
		//Used size
			inParams = vmImageManagementService->GetMethodParameters("GetVirtualHardDiskInfo");
			inParams["Path"] = VHDpath;
			outParams = vmImageManagementService->InvokeMethod("GetVirtualHardDiskInfo", inParams, nullptr);
			vhdsettingxmlString = outParams["Info"]->ToString();
			doc = gcnew XmlDocument();
			try
			{
				doc->LoadXml(vhdsettingxmlString);
			}
			catch(Exception^ e)
			{
				HVLog(L"Exception thrown LoadXml: " + e->Message + "\n Stacktrace: " + e->StackTrace);
				if(e->Message->Contains("Data at the root level is invalid") && isServeraddString!=nullptr && isServeraddString->Equals("true"))
				{
					HVLog(L"vhdsettingxmlString Before ConvertjsontoXMLstring -> " + vhdsettingxmlString);
					vhdsettingxmlString = ConvertjsontoXMLstring(vhdsettingxmlString);
					HVLog(L"vhdsettingxmlString After ConvertjsontoXMLstring -> " + vhdsettingxmlString);
					doc->LoadXml(vhdsettingxmlString);
				}
				else
				{
					HVLog(L"vhdsettingxmlStringfindusedsize2008 not gathering size for refresh..!");
					throw e;
				}
			}
			nodelist = doc->SelectNodes("//PROPERTY[@NAME = 'FileSize']/VALUE/child::text()");
			if (nodelist->Count != 1)
			{
				HVLog(L"No nodes found at first attempt5");
				nodelist = doc->SelectNodes("/root/FileSize");
			}
			if (nodelist->Count != 1)
			{
				HVLog("Some error when finding FileSize");
			}
			else
			{
				for each(XmlNode^ xn in nodelist)
				{
					usedSize = usedSize + Convert::ToDouble(xn->InnerText);
				}
			}
            HVLog("VHDpath 2008 for used size calculation -> " + VHDpath);
            HVLog("It's used size -> " + Convert::ToString(usedSize));
			return usedSize;
		}
		else
		{
		    HVLog("We have an AVHD");
			double thisSize = 0.0;
			String^ path = "-";
			for each(XmlNode^ xn in nodelist)
			{
				path = xn->InnerText;
			}

			inParams = vmImageManagementService->GetMethodParameters("GetVirtualHardDiskInfo");
			inParams["Path"] = VHDpath;
			outParams = vmImageManagementService->InvokeMethod("GetVirtualHardDiskInfo", inParams, nullptr);
			vhdsettingxmlString = outParams["Info"]->ToString();
			doc = gcnew XmlDocument();
			try
			{
				doc->LoadXml(vhdsettingxmlString);
			}
			catch(Exception^ e)
			{
				HVLog(L"Exception thrown LoadXml: " + e->Message + "\n Stacktrace: " + e->StackTrace);
				if(e->Message->Contains("Data at the root level is invalid") && isServeraddString!=nullptr && isServeraddString->Equals("true"))
				{
					HVLog(L"vhdsettingxmlString Before ConvertjsontoXMLstring -> " + vhdsettingxmlString);
					vhdsettingxmlString = ConvertjsontoXMLstring(vhdsettingxmlString);
					HVLog(L"vhdsettingxmlString After ConvertjsontoXMLstring -> " + vhdsettingxmlString);
					doc->LoadXml(vhdsettingxmlString);
				}
				else
				{
					HVLog(L"vhdsettingxmlStringfindusedsize2008 not gathering size for refresh..!");
					throw e;
				}
			}
			nodelist = doc->SelectNodes("//PROPERTY[@NAME = 'FileSize']/VALUE/child::text()");
			if (nodelist->Count != 1)
			{
				HVLog(L"No nodes found at first attempt6");
				nodelist = doc->SelectNodes("/root/FileSize");
			}
			if (nodelist->Count != 1)
			{
				HVLog("Some error when finding  FileSize");
			}
			else
			{
				for each(XmlNode^ xn in nodelist)
				{
					thisSize = Convert::ToDouble(xn->InnerText);
				}
			}
			HVLog("AVHD name -> " + Convert::ToString(thisSize));
			HVLog("thisSize 2008 of AVHD -> " + VHDpath);
			HVLog("It's parent path -> " + path);
			usedSize = thisSize + findusedsize2008(scope, path, usedSize, isServeraddString);
		}
	}
	catch (Exception^ ex)
	{
		HVLog(L"Exception thrown findusedsize2008: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
	}
	return usedSize;

}


Dictionary<String^, String^>^ getListofVHDpathsandSize(ManagementObject^ vm, String^ osVersion, ManagementScope^ scope, bool isSizerequired, String^ isServeraddString)
{
	HVLog(L"Started getListofVHDpathsandSize...");
	Dictionary<String^, String^>^ vhdDetails = gcnew Dictionary<String^, String^>();
	String^ allVHDPaths = "";

	double usedSize = 0.0;
	double provisionedSize = 0.0;

	try
	{
		String^ query = "select * from Msvm_ImageManagementService";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ vms = searcher->Get();
		ManagementObject^ vmImageManagementService = gcnew ManagementObject();

		for each (ManagementObject^ vm in vms)
		{
			vmImageManagementService = vm;
		}

		ManagementObjectCollection^ settingsCollection = vm->GetRelated("Msvm_VirtualSystemSettingData", "Msvm_SettingsDefineState", nullptr, nullptr, nullptr, nullptr, false, nullptr);
		ManagementObject^ virtualMachineSettings;
		if (settingsCollection->Count == 0)
		{
			HVLog(L"NO Settings object found for the VM");
		}
		else
		{
			for each(ManagementObject^ managementObject in settingsCollection)
			{
				virtualMachineSettings = managementObject;
			}

			List<String^>^ VHDlist;
			if (osVersion->StartsWith("5") || osVersion->StartsWith("6.0") || osVersion->StartsWith("6.1"))
			{
				VHDlist = GetlistofResources(virtualMachineSettings, Convert::ToUInt16(21), "Microsoft Virtual Hard Disk", "Msvm_ResourceAllocationSettingData", osVersion); //Get all VHDs
			}
			else
			{
				VHDlist = GetlistofResources(virtualMachineSettings, Convert::ToUInt16(31), "Microsoft:Hyper-V:Virtual Hard Disk", "Msvm_StorageAllocationSettingData", osVersion); //Get all VHDs

			}

			if (VHDlist != nullptr && VHDlist->Count > 0)
			{
				for each(String^ VHDpath in VHDlist)
				{
					allVHDPaths = allVHDPaths + VHDpath + ";";

					if(isSizerequired)
					{
						HVLog(L"Gathering provisioned size and used size for this VHD.." + VHDpath);
						if (osVersion->StartsWith("5") || osVersion->StartsWith("6.0") || osVersion->StartsWith("6.1"))
						{
						//Provisioned size
							ManagementBaseObject^ inParams = vmImageManagementService->GetMethodParameters("GetVirtualHardDiskInfo");
							inParams["Path"] = VHDpath;
							ManagementBaseObject^ outParams = vmImageManagementService->InvokeMethod("GetVirtualHardDiskInfo", inParams, nullptr);
							String^ vhdsettingxmlString = outParams["Info"]->ToString();


							XmlDocument^ doc = gcnew XmlDocument();
							try
							{
								doc->LoadXml(vhdsettingxmlString);
							}
							catch(Exception^ e)
							{
								HVLog(L"Exception thrown LoadXml: " + e->Message + "\n Stacktrace: " + e->StackTrace);
								if(e->Message->Contains("Data at the root level is invalid") && isServeraddString!=nullptr && isServeraddString->Equals("true"))
								{
									HVLog(L"vhdsettingxmlString Before ConvertjsontoXMLstring -> " + vhdsettingxmlString);
									vhdsettingxmlString = ConvertjsontoXMLstring(vhdsettingxmlString);
									HVLog(L"vhdsettingxmlString After ConvertjsontoXMLstring -> " + vhdsettingxmlString);
									doc->LoadXml(vhdsettingxmlString);
								}
								else
								{
									HVLog(L"vhdsettingxmlString Not gathering size for Refresh..");
									throw e;
								}
							}
							XmlNodeList^ nodelist = doc->SelectNodes("//PROPERTY[@NAME = 'MaxInternalSize']/VALUE/child::text()");
							if (nodelist->Count != 1)
							{
								HVLog(L"No nodes found at first attempt7");
								nodelist = doc->SelectNodes("//MaxInternalSize");
							}
							if (nodelist->Count != 1)
							{
								HVLog("Some error when finding max memory");
							}
							else
							{
								for each(XmlNode^ xn in nodelist)
								{
									provisionedSize = provisionedSize + Convert::ToDouble(xn->InnerText);
								}
							}

						//Used size
							double zeroSize = 0.0;
                            usedSize = usedSize + findusedsize2008(scope, VHDpath, zeroSize, isServeraddString);

						}
						else
						{
						//Provisioned size
							ManagementBaseObject^ inParams = vmImageManagementService->GetMethodParameters("GetVirtualHardDiskSettingData");
							inParams["Path"] = VHDpath;
							ManagementBaseObject^ outParams = vmImageManagementService->InvokeMethod("GetVirtualHardDiskSettingData", inParams, nullptr);
							String^ vhdsettingxmlString = outParams["SettingData"]->ToString();
							XmlDocument^ doc = gcnew XmlDocument();
							try
							{
								doc->LoadXml(vhdsettingxmlString);
							}
							catch(Exception^ e)
							{
								HVLog(L"Exception thrown LoadXml: " + e->Message + "\n Stacktrace: " + e->StackTrace);
								if(e->Message->Contains("Data at the root level is invalid"))
								{
									HVLog(L"vhdsettingxmlString Before ConvertjsontoXMLstring -> " + vhdsettingxmlString);
									vhdsettingxmlString = ConvertjsontoXMLstring(vhdsettingxmlString);
									HVLog(L"vhdsettingxmlString After ConvertjsontoXMLstring -> " + vhdsettingxmlString);
									doc->LoadXml(vhdsettingxmlString);
								}
								else
								{
									throw e;
								}
							}
							XmlNodeList^ nodelist = doc->SelectNodes("//PROPERTY[@NAME = 'MaxInternalSize']/VALUE/child::text()");
							if (nodelist->Count != 1)
							{
								HVLog(L"No nodes found at first attempt8");
								nodelist = doc->SelectNodes("//MaxInternalSize");
							}
							if (nodelist->Count != 1)
							{
								HVLog("Some error when finding maximum memory");
							}
							else
							{
								for each(XmlNode^ xn in nodelist)
								{
									provisionedSize = provisionedSize + Convert::ToDouble(xn->InnerText);
								}
							}
							double zeroSize = 0.0;
							usedSize = usedSize + findusedsize(scope, VHDpath, zeroSize);
						}
					}
					else
					{
						HVLog(L"Size gathering NOT REQUIRED..!");
					}
				}
			}
		}
	}
	catch (Exception^ ex)
	{
		HVLog(L"Exception in getListofVHDpathsandSize : " + ex->Message);
	}

	vhdDetails->Add("vhdPaths", allVHDPaths);
	if(isSizerequired)
	{
		vhdDetails->Add("provisionedSize", Convert::ToString(provisionedSize));
		vhdDetails->Add("usedSize", Convert::ToString(usedSize));
	}
	return vhdDetails;
}

String^ getdefaultVHDLocation(ManagementScope^ scope)
{
	String^ VHDdefaultLocation = "-";
	try
	{
		String^ query = "select * from Msvm_VirtualSystemManagementServiceSettingData";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ collection = searcher->Get();
		ManagementObject^ returnObject = gcnew ManagementObject();

		for each (ManagementObject^ mo in collection)
		{
			returnObject = mo;
		}

		VHDdefaultLocation = (String^)returnObject["DefaultVirtualHardDiskPath"];
	}
	catch (Exception^ ex)
	{	
		HVLog("getdefaultVHDLocation Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace);
	}
	return VHDdefaultLocation;
}


JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_getallHypervVMs(JNIEnv *env, jobject, jstring jhypervHostName, jstring juserName, jstring jpassword, jstring isServeradd)
{
	HVLog("Java_com_manageengine_rmp_virtual_HVManagedNative_getallHypervVMs started...!");
	InitializeJNIIDs(env);
	jobject allVMDetails = env->NewObject(LReflistClass, listConID); 
	try
	{		

		ManagementScope^ scope = InitializeWMICredentials(jhypervHostName,juserName,jpassword);
		String^ osVersion = getOSversion(jhypervHostName, juserName, jpassword);
		String^ VHDdefaultLocation = getdefaultVHDLocation(scope);

		//Set Host details in the first hashtable
		jobject hostHT = env->NewObject(jClHashtable, jConHashtable);

		HVLog(L"OS Version to insert in hastable: " + osVersion);
		HVLog(L"VHDdefaultLocation: " + VHDdefaultLocation);
		hostHT=PutJNIHashValue(hostHT, osVersion, "osVersion", env);
		hostHT=PutJNIHashValue(hostHT, VHDdefaultLocation, "VHDdefaultLocation", env);

		jboolean jboolean = env->CallBooleanMethod(allVMDetails, listAddID, hostHT);
		if(hostHT!=NULL)
		{
			env->DeleteLocalRef(hostHT);
		}

		String^ query = "select * from Msvm_ComputerSystem";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ vms = searcher->Get();
		for each (ManagementObject^ vm in vms)
		{
			jobject vmHT = env->NewObject(jClHashtable, jConHashtable);

			//Name
			String^ vmName = "-";
			if(vm["ElementName"]!=NULL)
			{
				vmName = vm["ElementName"]->ToString();				
			}
			HVLog(L"ElementName: " + vmName);
			vmHT=PutJNIHashValue(vmHT, vmName, "vmName", env);

			//ID
			String^ vmID = "-";
			if(vm["Name"]!=NULL)
			{
				vmID = vm["Name"]->ToString();				
			}
			HVLog(L"GUID: " + vmID);
			vmHT=PutJNIHashValue(vmHT, vmID, "vmID", env);

			//EnabledState
			String^ EnabledState = "-";
			if(vm["EnabledState"]!=NULL)
			{
				EnabledState = vm["EnabledState"]->ToString();				
			}
			HVLog(L"EnabledState: " + EnabledState);
			vmHT=PutJNIHashValue(vmHT, EnabledState, "EnabledState", env);	

			Dictionary<String^, String^>^ vhdDetails = gcnew Dictionary<String^, String^>();
			bool isSizerequired = true;
			String^ isServeraddString=ConvertJStringToCSString(isServeradd, env);
			vhdDetails = getListofVHDpathsandSize(vm, osVersion, scope, isSizerequired, isServeraddString);

			String^ VHDPaths = "-";
			vhdDetails->TryGetValue("vhdPaths", VHDPaths);
			if(VHDPaths->Equals(""))
			{
				VHDPaths = "-";
			}
			HVLog(L"VHDPaths: " + VHDPaths);
			vmHT=PutJNIHashValue(vmHT, VHDPaths, "VHDPaths", env);		

			String^ provisionedSize = "-";
			vhdDetails->TryGetValue("provisionedSize", provisionedSize);
			if(provisionedSize->Equals(""))
			{
				provisionedSize = "-";
			}
			HVLog(L"provisionedSize: " + provisionedSize);
			vmHT=PutJNIHashValue(vmHT, provisionedSize, "provisionedSize", env);		

			String^ usedSize = "-";
			vhdDetails->TryGetValue("usedSize", usedSize);
			if(usedSize->Equals(""))
			{
				usedSize = "-";
			}
			HVLog(L"usedSize: " + usedSize);
			vmHT=PutJNIHashValue(vmHT, usedSize, "usedSize", env);		
			
			jboolean = env->CallBooleanMethod(allVMDetails, listAddID, vmHT);
			if(vmHT!=NULL)
			{
				env->DeleteLocalRef(vmHT);
			}
			HVLog(L"Going to parse next VM");
		}
	}
	catch(Exception^ e)
	{
		HVLog("Java_com_manageengine_rmp_virtual_HVManagedNative_getallHypervVMs Exception -> " + e->Message);
		//logger(env, 1, "hypervWMIServer GetallVMDetails exception message:" + e->Message);		
	}	
	HVLog("Java_com_manageengine_rmp_virtual_HVManagedNative_getallHypervVMs Returning...!");
	return allVMDetails;
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_getVHDpathofVM(JNIEnv *env, jobject, jstring jhypervHostName, jstring juserName, jstring jpassword, jstring vmId)
{
	HVLog("Java_com_manageengine_rmp_virtual_HVManagedNative_getVHDpathofVM started..!");
	InitializeJNIIDs(env);
	String^ VHDPaths = "-";
	try
	{		
		String^ vmIdString=ConvertJStringToCSString(vmId, env);

		ManagementScope^ scope = InitializeWMICredentials(jhypervHostName,juserName,jpassword);
		String^ osVersion = getOSversion(jhypervHostName, juserName, jpassword);

		HVLog(L"OS Version-> " + osVersion);
		
		String^ query = "select * from Msvm_ComputerSystem where Name = '" + vmIdString + "'";
		HVLog("Query -> " + query);
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ vms = searcher->Get();
		for each (ManagementObject^ vm in vms)
		{
			Dictionary<String^, String^>^ vhdDetails = gcnew Dictionary<String^, String^>();
			bool isSizerequired = false;
			vhdDetails = getListofVHDpathsandSize(vm, osVersion, scope, isSizerequired, "false");
			
			vhdDetails->TryGetValue("vhdPaths", VHDPaths);
			if(VHDPaths->Equals(""))
			{
				VHDPaths = "-";
			}
			HVLog(L"VHDPaths: " + VHDPaths);
		}
		
	}
	catch(Exception^ e)
	{
		HVLog("Java_com_manageengine_rmp_virtual_HVManagedNative_getVHDpathofVM Exception -> " + e->Message);
		//logger(env, 1, "hypervWMIServer GetallVMDetails exception message:" + e->Message);		
	}
	marshal_context ^ context = gcnew marshal_context();
	const char * temp = context->marshal_as<const char *>(VHDPaths);
	jstring jVHDPaths = env->NewStringUTF(temp);
	HVLog("Java_com_manageengine_rmp_virtual_HVManagedNative_getVHDpathofVM Returning...!");
	return jVHDPaths;
}

BOOL SetPrivilege(

	HANDLE hToken,              // access token handle
	LPCWSTR nameOfPrivilege,   // name of privilege to enable/disable
	BOOL bEnablePrivilege     // to enable or disable privilege
	)
{
	TOKEN_PRIVILEGES tp;
	LUID luid;

	if (!LookupPrivilegeValue(
		NULL,               // lookup privilege on local system
		nameOfPrivilege,   // privilege to lookup
		&luid))           // receives LUID of privilege
	{
		printf("LookupPrivilegeValue error: %u\n", GetLastError());
		return FALSE;
	}

	tp.PrivilegeCount = 1;
	tp.Privileges[0].Luid = luid;
	if (bEnablePrivilege)
		tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	else
		tp.Privileges[0].Attributes = 0;

	// Enable the privilege or disable all privileges.

	if (!AdjustTokenPrivileges(
		hToken,
		FALSE,
		&tp,
		sizeof(TOKEN_PRIVILEGES),
		(PTOKEN_PRIVILEGES)NULL,
		(PDWORD)NULL))
	{
		printf("AdjustTokenPrivileges error: %u\n", GetLastError());
		return FALSE;
	}

	if (GetLastError() == ERROR_NOT_ALL_ASSIGNED)

	{
		printf("The token does not have the specified privilege. \n");
		return FALSE;
	}

	return TRUE;
}

String^ registryQuery(String^ sSubKeyName, JNIEnv *env)
{
    String^ driveSignatureList = L"";
	try{
		RegistryKey^ hKLM_S = Registry::LocalMachine->OpenSubKey(sSubKeyName);
		if (hKLM_S != nullptr)
		{
			RegistryKey^ hKLM_S_MD = hKLM_S->OpenSubKey(L"MountedDevices");
			if (hKLM_S_MD != nullptr)
			{
				for each(String^ value in hKLM_S_MD->GetValueNames())
				{
					if (value->Contains("DosDevice")){
						array<unsigned char>^ machineID = (array<unsigned char>^)Registry::GetValue("HKEY_LOCAL_MACHINE\\" + sSubKeyName + "\\MountedDevices", value, NULL);
						if (machineID != nullptr)
						{
							String^ str = BitConverter::ToString(machineID);
							int strLen = str->Length;
							if (strLen <= 73){
								String^ driveLetter = value->Substring(value->LastIndexOf("\\") + 1);
								HVLog(driveLetter + "\t" + str);
								driveSignatureList += str + L"=" + driveLetter + L",";
							}
						}
						else{
							HVLog(L"\tmachineID was null");
						}
					}
				}
				hKLM_S_MD->Close();
			}
			else{
				HVLog(L"\thKLM_S_MD was null");
			}
			hKLM_S->Close();
		}
		else{
			HVLog(L"\thKLM_S was null");
		}
	}
	catch (Exception^ e){
		HVLog(L"\tException while querying..." + e->ToString());
	}
	return driveSignatureList;
}

JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_getRegistryDetails(JNIEnv *env, jobject, jstring jSysFilePath)
{
    HVLog("Java_com_manageengine_rmp_virtual_HVManagedNative_getRegistryDetails started...!");
	InitializeJNIIDs(env);
	jobject registryArrayList = env->NewObject(LReflistClass, listConID);
	try{
        jobject vmRHT = env->NewObject(jClHashtable, jConHashtable);
        jboolean  jbool;
        HANDLE proccessHandle = GetCurrentProcess();
        DWORD typeOfAccess = TOKEN_ADJUST_PRIVILEGES;
        HANDLE tokenHandle;

        HKEY hKey = HKEY_LOCAL_MACHINE;
        LPCWSTR pHive = (LPWSTR)env->GetStringChars( jSysFilePath, NULL);
        try{
            if (OpenProcessToken(proccessHandle, typeOfAccess, &tokenHandle))
            {
                // Enabling RESTORE and BACKUP privileges
                SetPrivilege(tokenHandle, SE_RESTORE_NAME, TRUE);
                SetPrivilege(tokenHandle, SE_BACKUP_NAME, TRUE);
            }
            else
            {
                HVLog(L"Error getting the access token.\n");
            }

            LONG loadKey = RegLoadKeyW(hKey, L"RMPFLRSys", pHive);

            if (loadKey != ERROR_SUCCESS)
            {
                HVLog(L"Error loading the key. Code:" + loadKey);
            }
            else{
                HVLog(L"Going to obtain drive signature of vm from RMPFLRSys Hive");
                vmRHT = PutJNIHashValue(vmRHT, registryQuery(L"RMPFLRSys", env), "RMPFLRSysDetails", env);
            }
            HVLog(L"Going to obtain drive signature from SYSTEM Hive");
            vmRHT = PutJNIHashValue(vmRHT, registryQuery(L"SYSTEM", env), "SYSTEMDetails", env);
            jbool= env->CallBooleanMethod(registryArrayList, listAddID, vmRHT);
            if(vmRHT!=NULL)
            {
                env->DeleteLocalRef(vmRHT);
            }
        }catch (Exception^ e){
            HVLog(L"\tException while Loading Registry..." + e->ToString());
        }

         HVLog(L"Going to unLoad registry hive.");
         RegUnLoadKey(HKEY_LOCAL_MACHINE, L"RMPFLRSys");
	}
	catch(Exception^ e)
    {
        HVLog("Java_com_manageengine_rmp_virtual_HVManagedNative_getRegistryDetails Exception -> " + e->Message);
        //logger(env, 1, "hypervWMIServer GetallVMDetails exception message:" + e->Message);
    }
    HVLog("Java_com_manageengine_rmp_virtual_HVManagedNative_getRegistryDetails Returning...!");
    return registryArrayList;
}

String^ getVMIPFromVirtualization(ManagementObject^ vm){//function for obtaining ip-address for systems without virtualization\v2 namespace
    HVLog(L"getVMIPFromVirtualization() called...");
    String^ vmIPAddress = "-";
    try{
        if(String::Compare(vm["EnabledState"]->ToString(), "2") == 0) {
            ManagementObjectCollection^ vssd = vm->GetRelated("Msvm_KvpExchangeComponent");
            for each(ManagementObject^ vhd in vssd)
            {
                array<String^>^ vminfo = (array<String^>^) vhd->GetPropertyValue("GuestIntrinsicExchangeItems");
                if (vminfo->Length > 0) {
                    for (int i = 0; i < vminfo->Length; i++)
                    {
                        if (vminfo[i]->Contains("NetworkAddressIPv4"))
                        {
                            XmlDocument^ xmlDoc;
                            try{
                                xmlDoc->LoadXml(vminfo[i]);
                                XmlNode^ xmlNode = xmlDoc->DocumentElement->ChildNodes[1]->ChildNodes[0]->FirstChild;
                                HVLog("IP Address:" + xmlNode->InnerText);
                            }
							catch(Exception^ e)
							{
								HVLog(L"Exception thrown LoadXml... ");
								vmIPAddress = vminfo[i];
								throw e;
							}
                        }
                    }
                }
            }
        }
        else{
            vmIPAddress = "Switched OFF";
        }
    }
    catch (Exception^ ex)
    {
        HVLog(L"Exception in getListofVHDpathsandSize : " + ex->Message);
    }
    return vmIPAddress;
}

String^ getVMIPFromV2(ManagementObject^ vm){//function for obtaining ip-address for systems with virtualization\v2 namespace
    HVLog(L"getVMIPFromV2() called...");
    String^ vmIPAddress = "-";
    try{
        if (String::Compare(vm["EnabledState"]->ToString(), "2") == 0) {
            ManagementObjectCollection ^vssd = vm->GetRelated("Msvm_VirtualSystemSettingData");
            for each(ManagementObject ^vhd in vssd)
            {
                ManagementObjectCollection ^vmSEPSDs = vhd->GetRelated("Msvm_SyntheticEthernetPortSettingData");
                for each(ManagementObject ^vmSEPSD in vmSEPSDs) {
                    ManagementObjectCollection ^gNACs = vmSEPSD->GetRelated("Msvm_GuestNetworkAdapterConfiguration");
                    for each(ManagementObject ^gNAC in gNACs) {
                        array<String^>^ ips = (array<String^>^) gNAC["IPAddresses"];
                        vmIPAddress = (ips->Length > 0)? ips[0] : "-";
                    }
                }
            }
        }
        else{
            vmIPAddress = "Switched OFF";
        }
    }
    catch (Exception^ ex)
    {
        HVLog(L"Exception in getListofVHDpathsandSize : " + ex->Message);
    }
    return vmIPAddress;
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_HVManagedNative_getVMIPAddress(JNIEnv *env, jobject, jstring jHVVMID, jstring jhypervHostName, jstring juserName, jstring jpassword){
    HVLog("Java_com_manageengine_rmp_virtual_HVManagedNative_getVMIPAddress started...!");
	InitializeJNIIDs(env);
	String^ ipAddress = "-";
	try{
		String^ vmIdString=ConvertJStringToCSString(jHVVMID, env);

		ManagementScope^ scope = InitializeWMICredentials(jhypervHostName,juserName,jpassword);
		String^ osVersion = getOSversion(jhypervHostName, juserName, jpassword);
		HVLog(L"OS Version-> " + osVersion);
		String^ query = "select * from Msvm_ComputerSystem where Name = '" + vmIdString + "'";
		HVLog("Query -> " + query);
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ vms = searcher->Get();
		for each (ManagementObject^ vm in vms)
		{
		    if(vm["EnabledState"]!=NULL)
            {
                if(osVersion->StartsWith("6.1") || osVersion->StartsWith("6.0"))
                {
                    ipAddress =getVMIPFromVirtualization(vm);
                }
                else
                {
                    ipAddress = getVMIPFromV2(vm);
                }
            }
		}
	}
	catch(Exception^ e)
    {
        HVLog("Java_com_manageengine_rmp_virtual_HVManagedNative_getVMIPAddress Exception -> " + e->Message);
    }
	marshal_context ^ context = gcnew marshal_context();
	const char * temp = context->marshal_as<const char *>(ipAddress);
	jstring jIPAddress = env->NewStringUTF(temp);
    HVLog("Java_com_manageengine_rmp_virtual_HVManagedNative_getVMIPAddress Returning...!");
    return jIPAddress;
}