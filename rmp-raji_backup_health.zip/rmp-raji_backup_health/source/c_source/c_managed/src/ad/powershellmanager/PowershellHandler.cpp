//$Id: PowershellHandler.cpp,v 1.0 2015/10/14 12:07:09 lucky.k Exp $
#include <ad/powershellmanager/PowershellHandler.h>
//#include "zlib.h"
//#include <fcntl.h>
//#include <sys/types.h>
//#include <sys/stat.h>
#include <io.h>  
#include <stdio.h>

/*#define ENCRYPT_BLOCK_SIZE 16
#define KEYLENGTH  0x00800000
#define ENCRYPT_ALGORITHM CALG_AES_128 */


void log(JNIEnv *env, int level,const char* message, ...)
{
	va_list args;
	int len;
	jint jlevel=(jint)level;
	char * buffer;
	va_start(args, message);
	len = _vscprintf(message, args)	+ 1;
	buffer = (char*)malloc(len * sizeof(char));
	vsprintf(buffer, message, args);
	jstring jsMessage = env->NewStringUTF(buffer);
	env->CallStaticVoidMethod(LogClass,LogID,jlevel,jsMessage); 
	free(buffer);
	env->DeleteLocalRef(jsMessage);

}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPManagedNative_GroupPolicy(JNIEnv *env, jclass obj, jstring domainName, jstring dcName, jstring userName, jstring password, jstring gpoId, jstring backupPath, jint cmdletType)
{
	int isSuccess = -1;
        try {
		log(env, 1, "Java_com_manageengine_rmp_jni_RMPManagedNative_GroupPolicy called . . .");
		const jchar* utfDomainName=env->GetStringChars(domainName, 0);
		const jchar* utfDcName=env->GetStringChars(dcName, 0);
		const jchar* utfUserName=env->GetStringChars(userName, 0);
		const jchar* utfPassword=env->GetStringChars(password, 0);
		const jchar* utfGpoId=env->GetStringChars(gpoId, 0);
		const jchar* utfBackupPath=env->GetStringChars(backupPath, 0);
		char buffer [2];
		log(env, 1, "Request Type: ");
		log(env, 1, itoa((int)cmdletType, buffer, 10));
                PowershellHandler __gc *psObject;
                psObject = new PowershellHandler((LPWSTR) utfDomainName, (LPWSTR) utfDcName, (LPWSTR) utfUserName, (LPWSTR) utfPassword, true);
                if(psObject->getError() != 0){
                        return psObject->getError();
                }
		switch((int)cmdletType)
		{
			case 1 : isSuccess = psObject->backupGpo((LPWSTR) utfBackupPath, (LPWSTR) utfGpoId);
				break;
			case 2 : isSuccess = psObject->restoreGpo((LPWSTR) utfBackupPath, (LPWSTR) utfGpoId);
				break;
			case 3 : isSuccess = psObject->deleteGpo((LPWSTR) utfBackupPath, (LPWSTR) utfGpoId);
				break;
		}
		log(env, 1, "GroupPolicy : ReleaseStringChars");
		env->ReleaseStringChars(domainName, utfDomainName);
		env->ReleaseStringChars(dcName, utfDcName);
		env->ReleaseStringChars(userName, utfUserName);
		env->ReleaseStringChars(password, utfPassword);
		env->ReleaseStringChars(gpoId, utfGpoId);
		env->ReleaseStringChars(backupPath, utfBackupPath);
		log(env, 1, "GroupPolicy : ReleasedStringChars");
    } catch (FileNotFoundException *fe) {
        log(env, 1, "File Not Found Exception ");
		isSuccess = -2;
    } catch (Exception *e) {
        log(env, 1, "Exception occurred");
		isSuccess = -3;
    }
    return isSuccess;
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPManagedNative_RunRemotePsCmdlet(JNIEnv *env, jclass obj, jstring domainName, jstring dcName, jstring userName, jstring password, jstring cmdlet)
{
	int isSuccess = -1;
        try {
		log(env, 1, "Java_com_manageengine_rmp_jni_RMPManagedNative_RunRemotePsCmdlet called . . .");
		const jchar* utfDomainName=env->GetStringChars(domainName, 0);
		const jchar* utfDcName=env->GetStringChars(dcName, 0);
		const jchar* utfUserName=env->GetStringChars(userName, 0);
		const jchar* utfPassword=env->GetStringChars(password, 0);
		const jchar* utfCmdlet=env->GetStringChars(cmdlet, 0);
		log(env, 1, "Request Type: ");
        
		PowershellHandler __gc *psObject;
        psObject = new PowershellHandler((LPWSTR) utfDomainName, (LPWSTR) utfDcName, (LPWSTR) utfUserName, (LPWSTR) utfPassword, true);
		isSuccess = psObject->runRemotePowershellCmdlet((LPWSTR) cmdlet);
		
		log(env, 1, "Powershell Cmdlet : ReleaseStringChars");
		env->ReleaseStringChars(domainName, utfDomainName);
		env->ReleaseStringChars(dcName, utfDcName);
		env->ReleaseStringChars(userName, utfUserName);
		env->ReleaseStringChars(password, utfPassword);
		env->ReleaseStringChars(cmdlet, utfCmdlet);
		log(env, 1, "Powershell Cmdlet : ReleasedStringChars");
    } catch (FileNotFoundException *fe) {
        log(env, 1, "File Not Found Exception ");
		isSuccess = -2;
    } catch (Exception *e) {
        log(env, 1, "Exception occurred");
		isSuccess = -3;
    }
    return isSuccess;
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_jni_RMPManagedNative_runRemotePsCmdletAndReturnResults(JNIEnv *env, jclass obj, jstring serverName, jstring userName, jstring password, jstring cmdlet,jstring moduleName){
	System::String __gc *managedStr;
	int exitCode=0;
	char *temp=(char *)env->GetStringUTFChars(moduleName, 0);
	try {
		log(env, 1, "Java_com_manageengine_rmp_jni_RMPManagedNative_RunRemotePsCmdletAndReturnResults called . . .");
		const jchar* utfDcName = env->GetStringChars(serverName, 0);
		const jchar* utfUserName = env->GetStringChars(userName, 0);
		const jchar* utfPassword = env->GetStringChars(password, 0);
		const jchar* utfCmdlet = env->GetStringChars(cmdlet, 0);
		const jchar* utfmodule = env->GetStringChars(moduleName, 0);


		PowershellHandler __gc *psObject;
		psObject = new PowershellHandler((LPWSTR)utfDcName, (LPWSTR)utfUserName, (LPWSTR)utfPassword, true, utfmodule);


        if (strcmp(temp, "hyperv") == 0) {
            managedStr = psObject->runRemotePowershellCmdletandreturnResults((LPWSTR)utfCmdlet);
        }
        else if(strcmp(temp, "vmware") == 0){
            log(env, 1, "Came by VMWare. . .");
            managedStr = psObject->runRemotePowershellCmdletandreturnResultsForVMware((LPWSTR)utfCmdlet);
        }
        else{
            exitCode = psObject->runRemotePowershellCmdlet((LPWSTR)utfCmdlet);
        }

            log(env, 1, "Powershell Cmdlet : Release StringChars");
            env->ReleaseStringChars(serverName, utfDcName);
            env->ReleaseStringChars(userName, utfUserName);
            env->ReleaseStringChars(password, utfPassword);
            env->ReleaseStringChars(cmdlet, utfCmdlet);
            env->ReleaseStringChars(moduleName, utfmodule);

            log(env, 1, "Powershell Cmdlet : Released StringChars");
	}
	catch (FileNotFoundException *fe) {
		log(env, 1, "File Not Found Exception ");
		jstring jvalue = env->NewStringUTF("");
		return jvalue;
	}
	catch (Exception *e) {
		log(env, 1, "Exception occurred");
		jstring jvalue = env->NewStringUTF("");
		return jvalue;
	}
    jstring jvalue;
    if (strcmp(temp, "hyperv") == 0 || strcmp(temp, "vmware") == 0) {
	    const wchar_t* sw = (const wchar_t*)(Marshal::StringToHGlobalUni(managedStr)).ToPointer();
        jvalue = env->NewString((jchar*)sw, wcslen(sw));
        Marshal::FreeHGlobal(IntPtr((void*)sw));
	}else{
        jvalue=(jstring)exitCode;
	}
	return jvalue;
}


//hv2016 methods
JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPManagedNative_performhvcheckpointbackup(JNIEnv *env, jclass obj, jstring serverName, jstring userName, jstring password, 
	jstring vmName, jstring backupType, jstring repositoryPath, jstring backupName, jstring backupIdentifier, jstring previousbackupIdentifier, jstring isEncrypt, jstring encryptPassword,
	jstring repositoryUser, jstring repositoryPassword)
{
	int returnValue = -1;
	try {
		log(env, 1, "Java_com_manageengine_rmp_jni_RMPManagedNative_performhvcheckpointbackup called . . .");
		const jchar* utfDcName = env->GetStringChars(serverName, 0);
		const jchar* utfUserName = env->GetStringChars(userName, 0);
		const jchar* utfPassword = env->GetStringChars(password, 0);
		const jchar* utfvmName = env->GetStringChars(vmName, 0);
		const jchar* utfbackupType = env->GetStringChars(backupType, 0);
		const jchar* utfrepositoryPath = env->GetStringChars(repositoryPath, 0);
		const jchar* utfbackupName = env->GetStringChars(backupName, 0);
		const jchar* utfbackupIdentifier = env->GetStringChars(backupIdentifier, 0);
		const jchar* utfpreviousbackupIdentifier = env->GetStringChars(previousbackupIdentifier, 0);
		const jchar* utfisEncrypt = env->GetStringChars(isEncrypt, 0);
		const jchar* utfencryptPassword = env->GetStringChars(encryptPassword, 0);
		const jchar* utfrepositoryUser = env->GetStringChars(repositoryUser, 0);
		const jchar* utfrepositoryPassword = env->GetStringChars(repositoryPassword, 0);

		log(env, 1, "performhvcheckpointbackup Calling constructor..");
		PowershellHandler __gc *psObject;
		psObject = new PowershellHandler((LPWSTR)utfDcName, (LPWSTR)utfUserName, (LPWSTR)utfPassword, true, (LPWSTR)utfbackupType);
		log(env, 1, "performhvcheckpointbackup Finished Calling constructor..Calling dohvcheckpointbackupinCS method");

		log(env, 1, "performhvcheckpointbackup Calling dohvcheckpointbackupinCS method");
		returnValue = psObject->dohvcheckpointbackupinCS((LPWSTR)utfvmName, (LPWSTR)utfrepositoryPath, (LPWSTR)utfbackupName, (LPWSTR)utfbackupIdentifier, (LPWSTR)utfpreviousbackupIdentifier,
			(LPWSTR)utfrepositoryUser, (LPWSTR)utfrepositoryPassword);
		log(env, 1, "performhvcheckpointbackup Finished Calling dohvcheckpointbackupinCS method");

		/*log(env, 1, "performhvcheckpointbackup Calling compressFiles method");
		bool isCompressed = compressFiles(env, (LPWSTR)utfvmName, (LPWSTR)utfrepositoryPath, (LPWSTR)utfisEncrypt, (LPWSTR)utfencryptPassword, (LPWSTR)utfbackupType);
		if(isCompressed)
		{
			log(env, 1, "performhvcheckpointbacku Compression successful!");
		}
		else
		{
			log(env, 1, "performhvcheckpointbacku Compression failure!");
		}*/

		log(env, 1, "performhvcheckpointbackup Powershell Cmdlet : Release StringChars");
		env->ReleaseStringChars(serverName, utfDcName);
		env->ReleaseStringChars(userName, utfUserName);
		env->ReleaseStringChars(password, utfPassword);
		env->ReleaseStringChars(vmName, utfvmName);
		env->ReleaseStringChars(backupType, utfbackupType);
		env->ReleaseStringChars(backupName, utfbackupName);
		env->ReleaseStringChars(backupIdentifier, utfbackupIdentifier);
		env->ReleaseStringChars(previousbackupIdentifier, utfpreviousbackupIdentifier);
		env->ReleaseStringChars(repositoryPath, utfrepositoryPath);
		env->ReleaseStringChars(isEncrypt, utfisEncrypt);
		env->ReleaseStringChars(encryptPassword, utfencryptPassword);
		env->ReleaseStringChars(repositoryUser, utfrepositoryUser);
		env->ReleaseStringChars(repositoryPassword, utfrepositoryPassword);
		log(env, 1, "performhvcheckpointbackup Powershell Cmdlet : Released StringChars");
	}
	catch (FileNotFoundException *fe) {
		log(env, 1, "performhvcheckpointbackup File Not Found Exception ");
	}
	catch (Exception *e) {
		log(env, 1, "performhvcheckpointbackup Exception occurred");
	}

	return returnValue;
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPManagedNative_performhvcheckpointrestore(JNIEnv *env, jclass obj, jstring serverName, jstring userName, jstring password, jstring vmName,
 jstring restoreType, jstring repositoryPath, jstring vhdDestinationPath, jstring defaultVHDlocationindestinationHVserver, jstring previousbackuprepositoryPaths, jstring ischangeVMName, 
 jstring newVMName, jstring isPowerOn, jstring isEncrypt, jstring encryptPassword, jstring currentrestorerepositoryPathUser, jstring currentrestorerepositoryPathPassword)
{
	int returnValue = -1;
	try {
		log(env, 1, "Java_com_manageengine_rmp_jni_RMPManagedNative_performhvcheckpointrestore called . . .");
		const jchar* utfDcName = env->GetStringChars(serverName, 0);
		const jchar* utfUserName = env->GetStringChars(userName, 0);
		const jchar* utfPassword = env->GetStringChars(password, 0);
		const jchar* utfvmName = env->GetStringChars(vmName, 0);
		const jchar* utfrestoreType = env->GetStringChars(restoreType, 0);
		const jchar* utfrepositoryPath = env->GetStringChars(repositoryPath, 0); //repositoryPath -> repositoryPath\\backupid\\backupidentifier
		const jchar* utfvhdDestinationPath = env->GetStringChars(vhdDestinationPath, 0);
		const jchar* utfdefaultVHDlocationindestinationHVserver = env->GetStringChars(defaultVHDlocationindestinationHVserver, 0);
		const jchar* utfpreviousbackuprepositoryPaths = env->GetStringChars(previousbackuprepositoryPaths, 0);
		const jchar* utfischangeVMName = env->GetStringChars(ischangeVMName, 0);
		const jchar* utfnewVMName = env->GetStringChars(newVMName, 0);
		const jchar* utfisPowerOn = env->GetStringChars(isPowerOn, 0);
		const jchar* utfisEncrypt = env->GetStringChars(isEncrypt, 0);
		const jchar* utfencryptPassword = env->GetStringChars(encryptPassword, 0);
		const jchar* utfcurrentrestorerepositoryPathUser = env->GetStringChars(currentrestorerepositoryPathUser, 0);
		const jchar* utfcurrentrestorerepositoryPathPassword = env->GetStringChars(currentrestorerepositoryPathPassword, 0);

		log(env, 1, "performhvcheckpointrestore Calling constructor..");
		PowershellHandler __gc *psObject;
		psObject = new PowershellHandler((LPWSTR)utfDcName, (LPWSTR)utfUserName, (LPWSTR)utfPassword, true, (LPWSTR)utfrestoreType);
		log(env, 1, "performhvcheckpointrestore Finished Calling constructor..Calling dohvcheckpointbackupinCS method");

		/*log(env, 1, "performhvcheckpointrestore Calling decompressFiles method");
		bool isDecompressed = decompressordeleteFiles(env, (LPWSTR)utfvmName, (LPWSTR)utfrepositoryPath, L"false", L"decompress", (LPWSTR)utfisEncrypt, (LPWSTR)utfencryptPassword);
		if(isDecompressed)
		{
			log(env, 1, "performhvcheckpointbacku DeCompression successful!");
			wchar_t *vmbackupPathswstring = new wchar_t[wcslen((LPWSTR)utfpreviousbackuprepositoryPaths) + 1];
			wcscpy(vmbackupPathswstring, (LPWSTR)utfpreviousbackuprepositoryPaths);

			if(wcscmp(vmbackupPathswstring, L"-")!=0)
			{
				wchar_t *backupPath = NULL;
				wchar_t *nextbackupPath = NULL;
				backupPath = wcstok_s(vmbackupPathswstring, L";", &nextbackupPath);
				while (backupPath != NULL)
				{
					log(env, 1, "performhvcheckpointrestore previous backup path ->  %ws", backupPath);
					isDecompressed = decompressordeleteFiles(env, (LPWSTR)utfvmName, (LPWSTR)backupPath, L"true", L"decompress", (LPWSTR)utfisEncrypt, (LPWSTR)utfencryptPassword);
					if(!isDecompressed)
					{
						log(env, 1, "performhvcheckpointbacku DeCompression previous backup path failure!");
						return 856;
					}
					backupPath = wcstok_s(NULL, L";", &nextbackupPath);
				}				
			}

		}
		else
		{
			log(env, 1, "performhvcheckpointbacku DeCompression failure!");
			return 856;
		}*/

		log(env, 1, "performhvcheckpointrestore Calling dohvcheckpointrestoreinCS method");
		returnValue = psObject->dohvcheckpointrestoreinCS((LPWSTR)utfDcName, (LPWSTR)utfvmName, (LPWSTR)utfrepositoryPath, (LPWSTR)utfrestoreType, (LPWSTR)utfvhdDestinationPath, 
			(LPWSTR)utfdefaultVHDlocationindestinationHVserver, (LPWSTR)utfpreviousbackuprepositoryPaths, (LPWSTR)utfischangeVMName, (LPWSTR)utfnewVMName, (LPWSTR)utfisPowerOn,
			(LPWSTR)utfcurrentrestorerepositoryPathUser, (LPWSTR)utfcurrentrestorerepositoryPathPassword);
		log(env, 1, "performhvcheckpointrestore Finished Calling dohvcheckpointrestoreinCS method");

		/*if(wcscmp((LPWSTR)utfrestoreType, L"7") == 0)
		{
			//this is live vm migration. don't delete decompressed files.
			log(env, 1, "performhvcheckpointbacku this is live vm migration. don't delete decompressed files.");
		}
		else
		{
			log(env, 1, "performhvcheckpointrestore Calling deletedecompressedFiles method");
			bool isDeleted = decompressordeleteFiles(env, (LPWSTR)utfvmName, (LPWSTR)utfrepositoryPath, L"false", L"delete", (LPWSTR)utfisEncrypt, (LPWSTR)utfencryptPassword);

			wchar_t *vmbackupPathswstring = new wchar_t[wcslen((LPWSTR)utfpreviousbackuprepositoryPaths) + 1];
			wcscpy(vmbackupPathswstring, (LPWSTR)utfpreviousbackuprepositoryPaths);

			if(wcscmp(vmbackupPathswstring, L"-")!=0)
			{
				wchar_t *backupPath = NULL;
				wchar_t *nextbackupPath = NULL;
				backupPath = wcstok_s(vmbackupPathswstring, L";", &nextbackupPath);
				while (backupPath != NULL)
				{
					log(env, 1, "performhvcheckpointrestore previous backup path to delete->  %ws", backupPath);
					isDecompressed = decompressordeleteFiles(env, (LPWSTR)utfvmName, (LPWSTR)backupPath, L"true", L"delete", (LPWSTR)utfisEncrypt, (LPWSTR)utfencryptPassword);

					backupPath = wcstok_s(NULL, L";", &nextbackupPath);
				}				
			}
		}*/

		log(env, 1, "performhvcheckpointrestore Powershell Cmdlet : Release StringChars");
		env->ReleaseStringChars(serverName, utfDcName);
		env->ReleaseStringChars(userName, utfUserName);
		env->ReleaseStringChars(password, utfPassword);
		env->ReleaseStringChars(vmName, utfvmName);
		env->ReleaseStringChars(restoreType, utfrestoreType);
		env->ReleaseStringChars(vhdDestinationPath, utfvhdDestinationPath);
		env->ReleaseStringChars(defaultVHDlocationindestinationHVserver, utfdefaultVHDlocationindestinationHVserver);
		env->ReleaseStringChars(previousbackuprepositoryPaths, utfpreviousbackuprepositoryPaths);
		env->ReleaseStringChars(repositoryPath, utfrepositoryPath);
		env->ReleaseStringChars(ischangeVMName, utfischangeVMName);
		env->ReleaseStringChars(newVMName, utfnewVMName);
		env->ReleaseStringChars(isPowerOn, utfisPowerOn);
		env->ReleaseStringChars(isEncrypt, utfisEncrypt);
		env->ReleaseStringChars(encryptPassword, utfencryptPassword);
		env->ReleaseStringChars(currentrestorerepositoryPathUser, utfcurrentrestorerepositoryPathUser);
		env->ReleaseStringChars(currentrestorerepositoryPathPassword, utfcurrentrestorerepositoryPathPassword);

		log(env, 1, "performhvcheckpointrestore Powershell Cmdlet : Released StringChars");
	}
	catch (FileNotFoundException *fe) {
		log(env, 1, "performhvcheckpointrestore File Not Found Exception ");
	}
	catch (Exception *e) {
		log(env, 1, "performhvcheckpointrestore Exception occurred");
	}

	return returnValue;
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPManagedNative_performhvmovevm(JNIEnv *env, jclass obj, jstring serverName, jstring userName, jstring password,
	jstring hvVMId, jstring newVMName, jstring destinationHost, jstring destinationPath, jstring isPowerOn)
{
	int returnValue = -1;

	try {
		log(env, 1, "Java_com_manageengine_rmp_jni_RMPManagedNative_performhvmovevm called . . .");
		const jchar* utfDcName = env->GetStringChars(serverName, 0);
		const jchar* utfUserName = env->GetStringChars(userName, 0);
		const jchar* utfPassword = env->GetStringChars(password, 0);
		const jchar* utfhvVMId = env->GetStringChars(hvVMId, 0);
		const jchar* utfnewVMName = env->GetStringChars(newVMName, 0);
		const jchar* utfisPowerOn = env->GetStringChars(isPowerOn, 0);
		const jchar* utfdestinationHost = env->GetStringChars(destinationHost, 0);
		const jchar* utfdestinationPath = env->GetStringChars(destinationPath, 0);


		log(env, 1, "performhvmovevm Calling constructor..");
		PowershellHandler __gc *psObject;
		psObject = new PowershellHandler((LPWSTR)utfDcName, (LPWSTR)utfUserName, (LPWSTR)utfPassword, true, "MoveVM");
		log(env, 1, "performhvmovevm Finished Calling constructor..Calling dohvmovevminCS method");
		if(psObject->getError() == 4)
		{
            return 861;
        }
        else if(psObject->getError() == 13)
        {
            return 863;
        }
        else if(psObject->getError() == 2048)
        {
            return 865;
        }


		log(env, 1, "performhvmovevm Calling dohvmovevminCS method");
		returnValue = psObject->dohvmovevminCS((LPWSTR)utfhvVMId, (LPWSTR)utfnewVMName, (LPWSTR)utfdestinationHost, (LPWSTR)utfdestinationPath, (LPWSTR)utfisPowerOn);
		log(env, 1, "performhvmovevm Finished Calling dohvmovevminCS method");

		log(env, 1, "performhvmovevm Powershell Cmdlet : Release StringChars");
		env->ReleaseStringChars(serverName, utfDcName);
		env->ReleaseStringChars(userName, utfUserName);
		env->ReleaseStringChars(password, utfPassword);
		env->ReleaseStringChars(hvVMId, utfhvVMId);
		env->ReleaseStringChars(newVMName, utfnewVMName);
		env->ReleaseStringChars(isPowerOn, utfisPowerOn);
		env->ReleaseStringChars(destinationHost, utfdestinationHost);
		env->ReleaseStringChars(destinationPath, utfdestinationPath);

		log(env, 1, "performhvmovevm Powershell Cmdlet : Released StringChars");
	}
	catch (FileNotFoundException *fe) {
		log(env, 1, "performhvmovevm File Not Found Exception ");
	}
	catch (Exception *e) {
		log(env, 1, "performhvmovevm Exception occurred");
	}

	return returnValue;
}


JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPManagedNative_runRemotePsScriptAndReturnResults(JNIEnv *env, jclass obj, jstring serverName, jstring userName, jstring password, jobjectArray scriptArray,jstring moduleName){
	System::String __gc *managedStr;
	int exitCode=0;
	char *temp=(char *)env->GetStringUTFChars(moduleName, 0);
	try {
		log(env, 1, "Java_com_manageengine_rmp_jni_RMPManagedNative_runRemotePsScriptAndReturnResults called . . .");
		const jchar* utfDcName = env->GetStringChars(serverName, 0);
		const jchar* utfUserName = env->GetStringChars(userName, 0);
		const jchar* utfPassword = env->GetStringChars(password, 0);
		const jchar* utfmodule = env->GetStringChars(moduleName, 0);

		PowershellHandler __gc *psObject;
		psObject = new PowershellHandler((LPWSTR)utfDcName, (LPWSTR)utfUserName, (LPWSTR)utfPassword, true, (LPWSTR)utfmodule);
        int stringCount = env->GetArrayLength(scriptArray);
        for (int i=0; i<stringCount; i++) {
            jstring cmdlet = (jstring) (env->GetObjectArrayElement(scriptArray, i));
            const jchar* utfCmdlet = env->GetStringChars(cmdlet, 0);
            exitCode = psObject->runRemotePowershellCmdlet((LPWSTR)utfCmdlet);
            env->ReleaseStringChars(cmdlet, utfCmdlet);
            if(exitCode!=0){
                break;
            }
        }


        log(env, 1, "Powershell Cmdlet : Releasing StringChars");
        env->ReleaseStringChars(serverName, utfDcName);
        env->ReleaseStringChars(userName, utfUserName);
        env->ReleaseStringChars(password, utfPassword);
        env->ReleaseStringChars(moduleName, utfmodule);

        log(env, 1, "Powershell Cmdlet : Released StringChars");
	}
	catch (FileNotFoundException *fe) {
		exitCode = -2;
		log(env, 1, "File Not Found Exception ");
	}
	catch (Exception *e) {
		exitCode = -3;
		log(env, 1, "Exception occurred");
	}
    /*
       last exitCode
    */
	return exitCode;
}