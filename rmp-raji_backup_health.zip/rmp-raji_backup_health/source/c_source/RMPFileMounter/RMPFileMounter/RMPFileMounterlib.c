/*++

Module Name:

RMPFileMounterLib.c

Abstract:
This contains library support routines for RMPFileMounter

Environment:

Kernel mode

--*/

#include "RMPFileMounterKern.h"
#include <stdio.h>

#ifdef ALLOC_PRAGMA

#pragma alloc_text(PAGE, RMPFileMounterStreamHandleContextCleanupCallback)
#pragma alloc_text(PAGE, RMPFileMounterInstanceContextCleanupCallback)

#pragma alloc_text(PAGE, RMPFileMounterAllocateContext)
#pragma alloc_text(PAGE, RMPFileMounterGetOrSetContext)
#pragma alloc_text(PAGE, RMPFileMounterGetContext)
#pragma alloc_text(PAGE, RMPFileMounterSetContext)

/*#pragma alloc_text(PAGE, RMPFileMounterPreCreateCallback)
#pragma alloc_text(PAGE, RMPFileMounterPostCreateCallback)
#pragma alloc_text(PAGE, RMPFileMounterPreSetInfoCallback)
#pragma alloc_text(PAGE, RMPFileMounterPostSetInfoCallback)
#pragma alloc_text(PAGE, RMPFileMounterPreReadCallback)
#pragma alloc_text(PAGE, RMPFileMounterPostReadCallback)*/
#pragma alloc_text(PAGE, RMPFileMounterPreWriteCallback)
/*#pragma alloc_text(PAGE, RMPFileMounterPostWriteCallback)
#pragma alloc_text(PAGE, RMPFileMounterPreSetSecurityCallback)
#pragma alloc_text(PAGE, RMPFileMounterPostSetSecurityCallback)
#pragma alloc_text(PAGE, RMPFileMounterPreCleanupCallback)
#pragma alloc_text(PAGE, RMPFileMounterPostCleanupCallback)*/

#pragma alloc_text(PAGE, InitEventNotification)
#pragma alloc_text(PAGE, RMPFileMounterSetFileNameFromPreOpData)
#pragma alloc_text(PAGE, SendPostOperationData)

#endif

//---------------------------------------------------------------------------//
//  			VolumeInstanceSetupCallback.			     //
//---------------------------------------------------------------------------//


/*
*	Instance Callback
*	-----------------
*
InstanceSetupCallback to handle volume attach for USB drivers.

FltObjects [in]
Pointer to an FLT_RELATED_OBJECTS structure that contains opaque pointers for the objects related to the current operation.

Flags [in]
Bitmask of flags that indicate why the instance is being attached. One or more of the following:
Flag	->	Meaning
FLTFL_INSTANCE_SETUP_AUTOMATIC_ATTACHMENT -> The instance is being attached automatically. Either the minifilter driver was just loaded and is being attached to all existing volumes, or it is being attached to a newly mounted volume.
FLTFL_INSTANCE_SETUP_MANUAL_ATTACHMENT -> The instance is being attached manually because a user-mode application has called FilterAttach or FilterAttachAtAltitude or because a kernel-mode component has called FltAttachVolume or FltAttachVolumeAtAltitude.
FLTFL_INSTANCE_SETUP_NEWLY_MOUNTED_VOLUME -> The instance is being attached automatically to a newly mounted volume.
FLTFL_INSTANCE_SETUP_DETACHED_VOLUME -> The instance is being attached to a detached volume. It is possible, on some filesystems (such as FAT and CDFS), to reattach a volume after it has detached. A volume is detached if it has no associated storage stack. A volume in this state is usually a dismounted volume that still has open files.
typedef ULONG FLT_INSTANCE_SETUP_FLAGS;

//
//  If set, this is an automatic instance attachment notification.  These
//  occur when the filter is first loaded for all existing volumes, and
//  when a new volume is mounted.
//

#define FLTFL_INSTANCE_SETUP_AUTOMATIC_ATTACHMENT   0x00000001

//
//  If set, this is a manual instance attachment request via FilterAttach
//  (user mode) or FltAttachVolume.
//

#define FLTFL_INSTANCE_SETUP_MANUAL_ATTACHMENT      0x00000002

//
//  If set, this is an automatic instance notification for a volume that
//  has just been mounted in the system.
//

#define FLTFL_INSTANCE_SETUP_NEWLY_MOUNTED_VOLUME   0x00000004

#if FLT_MGR_LONGHORN
//
//  If set, this volume is not currently attached to a storage stack.
//  This usually means the volume is dismounted but it does not always
//  mean that.  There are scnearios with certain file systems (fat & cdfs
//  being some) where a volume can become reattached after it has detached.
//  This flag is only set in Longhorn or later.
//

#define FLTFL_INSTANCE_SETUP_DETACHED_VOLUME        0x00000008

#endif // FLT_MGR_LONGHORN

VolumeDeviceType [in]
Device type of the file system volume. Must be one of the following:
FILE_DEVICE_CD_ROM_FILE_SYSTEM
FILE_DEVICE_DISK_FILE_SYSTEM
FILE_DEVICE_NETWORK_FILE_SYSTEM

#define FILE_DEVICE_CD_ROM_FILE_SYSTEM  0x00000003
#define FILE_DEVICE_DISK_FILE_SYSTEM    0x00000008
#define FILE_DEVICE_NETWORK_FILE_SYSTEM 0x00000014

VolumeFilesystemType [in]
File system type of the volume. The possible values are listed in FLT_FILESYSTEM_TYPE.
*/

NTSTATUS VolumeInstanceSetupCallback(
	__in  PCFLT_RELATED_OBJECTS FltObjects,
	__in  FLT_INSTANCE_SETUP_FLAGS Flags,
	__in  DEVICE_TYPE VolumeDeviceType,
	__in  FLT_FILESYSTEM_TYPE VolumeFilesystemType
	)
{
	NTSTATUS returnStatus = STATUS_FLT_DO_NOT_ATTACH;
	NTSTATUS volumePropStatus;
	PFLT_VOLUME_PROPERTIES VolumeProperties = NULL;
	ULONG LengthReturned = 0;
	ULONG bufferSize;
	NTSTATUS status = STATUS_SUCCESS;
	unsigned int i = 0;
	BOOLEAN isWritable = FALSE;

	DbgPrint("\nInside VolumeInstanceSetupCallback()");
	volumePropStatus = FltGetVolumeProperties(FltObjects->Volume, VolumeProperties, 0, &LengthReturned);

	VolumeProperties = (PFLT_VOLUME_PROPERTIES)ExAllocatePoolWithTag(NonPagedPool, LengthReturned, RMPFileMounter_VOLUME_PROP_POOL_TAG);
	if (VolumeProperties == NULL)
	{
		DbgPrint("\nMemory Allocation Failed for VolumeProperties");
		return returnStatus;
	}
	bufferSize = LengthReturned;
	//Get VolumeProperties 
	volumePropStatus = FltGetVolumeProperties(FltObjects->Volume, VolumeProperties, bufferSize, &LengthReturned);
	if (volumePropStatus != STATUS_SUCCESS)
	{
		DbgPrint("\nFltGetVolumeProperties Failed");
	}
	//	DbgPrint( "\n--->RealDeviceName = ");	
	DbgPrint("\nFlags = 0x%X,", Flags);
	DbgPrint("\tDeviceObjectFlags = 0x%X", VolumeProperties->DeviceObjectFlags);
	DbgPrint("\nDeviceType = 0x%X,", VolumeProperties->DeviceType);
	DbgPrint("\tDeviceCharacteristics = 0x%X", VolumeProperties->DeviceCharacteristics);// Identify Removable storage From this flag...
	DbgPrint("\nRealDeviceName = %wZ", &VolumeProperties->RealDeviceName);

	// Newly mounted volumes are attached automatically.
	status = FltIsVolumeWritable(FltObjects->Volume, &isWritable);
	if (!NT_SUCCESS(status))
	{
		isWritable = FALSE;
	}
	if ((Flags & FLTFL_INSTANCE_SETUP_MANUAL_ATTACHMENT) == FLTFL_INSTANCE_SETUP_MANUAL_ATTACHMENT)
		// || ((Flags & FLTFL_INSTANCE_SETUP_NEWLY_MOUNTED_VOLUME) == FLTFL_INSTANCE_SETUP_NEWLY_MOUNTED_VOLUME && isWritable))
		returnStatus = STATUS_SUCCESS;

	if (VolumeProperties != NULL) ExFreePoolWithTag((PVOID)VolumeProperties, RMPFileMounter_VOLUME_PROP_POOL_TAG);
	return returnStatus;
}

//---------------------------------------------------------------------------------------------//

VOID
RMPFileMounterInstanceContextCleanupCallback(
__in PRMPFileMounter_INSTANCE_CONTEXT InstanceContext,
__in FLT_CONTEXT_TYPE ContextType
)
/*++

Routine Description:

This routine cleans up an instance context, which consists on freeing
pool used by the volume GUID name string.

Arguments:

InstanceContext - Pointer to RMPFileMounter_INSTANCE_CONTEXT to be cleaned up.

ContextType - Type of InstanceContext. Must be FLT_INSTANCE_CONTEXT.

--*/
{
	UNREFERENCED_PARAMETER(ContextType);

	PAGED_CODE();

	ASSERT(ContextType == FLT_INSTANCE_CONTEXT);

	//DfFreeUnicodeString( &InstanceContext->VolumeGuidName );
}

//---------------------------------------------------------------------------------------------//

VOID
RMPFileMounterStreamHandleContextCleanupCallback(
__in PRMPFileMounter_STREAMHANDLE_CONTEXT StreamContext,
__in FLT_CONTEXT_TYPE ContextType
)
/*++

Routine Description:

This routine cleans up a stream context. The only cleanup necessary is
releasing the FLT_FILE_NAME_INFORMATION object of the NameInfo field.

Arguments:

StreamContext - Pointer to RMPFileMounter_STREAMHANDLE_CONTEXT to be cleaned up.

ContextType   - Type of StreamContext. Must be FLT_STREAM_CONTEXT.

--*/
{
	UNREFERENCED_PARAMETER(ContextType);

	PAGED_CODE();

	ASSERT(ContextType == FLT_STREAM_CONTEXT || ContextType == FLT_STREAMHANDLE_CONTEXT);

	//
	//  Release NameInfo if present.
	//

	if (StreamContext->NameInfo != NULL) {
		/*if(ContextType == FLT_STREAM_CONTEXT)
		{
		DbgPrint("\n->StreamContext - > CleanupCallback for [%wZ]", &StreamContext->NameInfo->Name);
		} else
		{
		DbgPrint("\nStreamHandleContext - > CleanupCallback for [%wZ]", &StreamContext->NameInfo->Name);
		}*/
		FltReleaseFileNameInformation(StreamContext->NameInfo);
		StreamContext->NameInfo = NULL;
	}
}



//---------------------------------------------------------------------------------------------//

FLT_PREOP_CALLBACK_STATUS
RMPFileMounterPreWriteCallback(
__inout PFLT_CALLBACK_DATA Data,
__in PCFLT_RELATED_OBJECTS FltObjects,
__out  PCHANGE_NOTIFICATION notification
)
/*++

Routine Description:

This routine is the pre-operation completion routine for
IRP_MJ_SET_SECURITY in this miniFilter.


Arguments:

Data - Pointer to the filter callbackData that is passed to us.

FltObjects - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance, its associated volume and
file object.

CompletionContext - The context for the completion routine for this
operation.

Return Value:

FLT_PREOP_SYNCHRONIZE -

FLT_PREOP_SUCCESS_NO_CALLBACK -

--*/
{
	NTSTATUS status;
	PRMPFileMounter_STREAMHANDLE_CONTEXT streamContext = NULL;
	BOOLEAN race;

	UNREFERENCED_PARAMETER(FltObjects);

	PAGED_CODE();

	status = RMPFileMounterGetOrSetContext(FltObjects,
		Data->Iopb->TargetFileObject,
		&streamContext,
		FLT_STREAMHANDLE_CONTEXT);

	if (!NT_SUCCESS(status)) {
		return FLT_PREOP_SUCCESS_NO_CALLBACK;
	}

	notification->Context = (PVOID)streamContext;

	return FLT_PREOP_SUCCESS_WITH_CALLBACK;
}

//////////////////////////////////////////////////////////////////////////////
//  Context manipulation functions starts here				    //
//////////////////////////////////////////////////////////////////////////////


//---------------------------------------------------------------------------------------------//

NTSTATUS
RMPFileMounterAllocateContext(
__in FLT_CONTEXT_TYPE ContextType,
__out PFLT_CONTEXT *Context
)
/*++

Routine Description:

This routine allocates and initializes a context of given type.

Arguments:

ContextType   - Type of context to be allocated/initialized.

Context       - Pointer to a context pointer.

Return Value:

Returns a status forwarded from FltAllocateContext.

--*/
{
	NTSTATUS status;
	//PDF_TRANSACTION_CONTEXT transactionContext;

	PAGED_CODE();

	switch (ContextType) {

	case FLT_STREAMHANDLE_CONTEXT:

		status = FltAllocateContext(RMPFileMounterData.Filter,
			FLT_STREAMHANDLE_CONTEXT,
			sizeof(RMPFileMounter_STREAMHANDLE_CONTEXT),
			DF_CONTEXT_POOL_TYPE,
			Context);

		if (NT_SUCCESS(status)) {
			RtlZeroMemory(*Context, sizeof(RMPFileMounter_STREAMHANDLE_CONTEXT));
		}

		return status;

	case FLT_STREAM_CONTEXT:

		status = FltAllocateContext(RMPFileMounterData.Filter,
			FLT_STREAM_CONTEXT,
			sizeof(RMPFileMounter_STREAMHANDLE_CONTEXT),
			DF_CONTEXT_POOL_TYPE,
			Context);

		if (NT_SUCCESS(status)) {
			RtlZeroMemory(*Context, sizeof(RMPFileMounter_STREAMHANDLE_CONTEXT));
		}

		return status;
		/*
		case FLT_TRANSACTION_CONTEXT:

		status = FltAllocateContext( RMPFileMounterData.Filter,
		FLT_TRANSACTION_CONTEXT,
		sizeof(DF_TRANSACTION_CONTEXT),
		DF_CONTEXT_POOL_TYPE,
		Context );

		if (NT_SUCCESS( status )) {
		RtlZeroMemory( *Context, sizeof(DF_TRANSACTION_CONTEXT) );

		transactionContext = *Context;

		InitializeListHead( &transactionContext->DeleteNotifyList );

		transactionContext->Resource = ExAllocatePoolWithTag( NonPagedPool,
		sizeof(ERESOURCE),
		DF_ERESOURCE_POOL_TAG );
		//DbgPrint("--> RMPFileMounterAllocateContextv for FLT_TRANSACTION_CONTEXT!\n" );
		if (NULL == transactionContext->Resource) {
		FltReleaseContext( transactionContext );
		return STATUS_INSUFFICIENT_RESOURCES;
		}
		ExInitializeResourceLite( transactionContext->Resource );
		}

		return status;
		*/
	case FLT_INSTANCE_CONTEXT:

		status = FltAllocateContext(RMPFileMounterData.Filter,
			FLT_INSTANCE_CONTEXT,
			sizeof(RMPFileMounter_INSTANCE_CONTEXT),
			DF_CONTEXT_POOL_TYPE,
			Context);

		if (NT_SUCCESS(status)) {
			RtlZeroMemory(*Context, sizeof(RMPFileMounter_INSTANCE_CONTEXT));
		}

		return status;

	default:

		return STATUS_INVALID_PARAMETER;
	}
}

//---------------------------------------------------------------------------------------------//

NTSTATUS
RMPFileMounterGetOrSetContext(
__in PCFLT_RELATED_OBJECTS FltObjects,
__in_opt PVOID Target,//_When_(ContextType==FLT_INSTANCE_CONTEXT, _In_opt_) _When_(ContextType!=FLT_INSTANCE_CONTEXT, _In_)
__out PFLT_CONTEXT *Context,
__in FLT_CONTEXT_TYPE ContextType
)
/*++

Routine Description:

This routine obtains a context of type ContextType that is attached to
Target.

If a context is already attached to Target, it will be returned in
*Context. If a context is already attached, but *Context points to
another context, *Context will be released.

If no context is attached, and *Context points to a previously allocated
context, *Context will be attached to the Target.

Finally, if no previously allocated context is passed to this routine
(*Context is a NULL pointer), a new Context is created and then attached
to Target.

In case of race conditions (or the presence of a previously allocated
context at *Context), the existing attached context is returned via
*Context.

In case of a transaction context, this function will also enlist in the
transaction.

Arguments:

FltObjects    - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance and its associated volume.

Target        - Pointer to the target to which we want to attach the
context. It will actually be either a FILE_OBJECT or
a KTRANSACTION.  It is NULL for an Instance context.

Context       - Pointer to a pointer to a context. Used both for
returning an allocated/attached context or for receiving
a context to attach to the Target.

ContextType   - Type of context to get/allocate/attach. Also used to
disambiguate the target/context type as this minifilter
only has one type of context per target.

Return Value:

Returns a status forwarded from Flt(((Get|Set)Xxx)|Allocate)Context or
FltEnlistInTransaction.

--*/
{
	NTSTATUS status;
	PFLT_CONTEXT newContext;
	PFLT_CONTEXT oldContext;

	PAGED_CODE();

	ASSERT(NULL != Context);

	newContext = *Context;

	//
	//  Is there already a context attached to the target?
	//

	status = RMPFileMounterGetContext(FltObjects,
		Target,
		ContextType,
		&oldContext);

	if (STATUS_NOT_FOUND == status) {

		//
		//  There is no attached context. This means we have to either attach the
		//  one provided by the caller or allocate a new one and attach it.
		//

		if (NULL == newContext) {

			//
			//  No provided context. Allocate one.
			//

			status = RMPFileMounterAllocateContext(ContextType, &newContext);

			if (!NT_SUCCESS(status)) {

				//
				//  We failed to allocate.
				//

				return status;
			}
		}

	}
	else if (!NT_SUCCESS(status)) {

		//
		//  We failed trying to get a context from the target.
		//

		// Possible Leak
		if (NULL != newContext) {
			DbgPrint("\n\n Critical!!! \n\n");
			FltReleaseContext(newContext);
		}

		return status;

	}
	else {

		//
		//  There is already a context attached to the target, so return
		//  that context.
		//
		//  If a context was provided by the caller, release it if it's not
		//  the one attached to the target.
		//  

		//
		//  The caller is not allowed to set the same context on the target
		//  twice.
		//
		ASSERT(newContext != oldContext);

		if (NULL != newContext) {

			FltReleaseContext(newContext);
		}

		*Context = oldContext;
		return status;
	}

	//
	//  At this point we should have a context to set on the target (newContext).
	//

	status = RMPFileMounterSetContext(FltObjects,
		Target,
		ContextType,
		newContext,
		&oldContext);

	if (!NT_SUCCESS(status)) {

		//
		//  FltSetStreamContext failed so we must release the new context.
		//

		FltReleaseContext(newContext);

		if (STATUS_FLT_CONTEXT_ALREADY_DEFINED == status) {

			//
			//  We're racing with some other call which managed to set the
			//  context before us. We will return that context instead, which
			//  will be in oldContext.
			//

			*Context = oldContext;
			return STATUS_SUCCESS;

		}
		else {

			//
			//  Failed to set the context. Return NULL.
			//

			*Context = NULL;
			return status;
		}
	}

	//
	//  If this is setting a transaction context, we want to enlist in the
	//  transaction as well.
	//

	/*#if OS_VERSION_GREATER_THAN_VISTA

	if (FLT_TRANSACTION_CONTEXT == ContextType) {

	status = FltEnlistInTransaction( FltObjects->Instance,
	(PKTRANSACTION)Target,
	newContext,
	DF_NOTIFICATION_MASK );

	}

	#endif    */
	//
	//  Setting the context was successful so just return newContext.
	//

	*Context = newContext;
	return status;
}

//---------------------------------------------------------------------------------------------//

NTSTATUS
RMPFileMounterGetContext(
__in PCFLT_RELATED_OBJECTS FltObjects,
__in_opt PVOID Target,// _When_(ContextType==FLT_INSTANCE_CONTEXT, _In_opt_) _When_(ContextType!=FLT_INSTANCE_CONTEXT, _In_)
__in FLT_CONTEXT_TYPE ContextType,
__out PFLT_CONTEXT *Context
)
/*++

Routine Description:

This routine gets the given context from the target.

Arguments:

FltObjects    - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance and its associated volume.

Target        - Pointer to the target from which we want to obtain the
context. It will actually be either a FILE_OBJECT or
a KTRANSACTION. For instance contexts, it's ignored, as
the target is the FLT_INSTANCE itself, obtained from
Data->Iopb->TargetInstance.

ContextType   - Type of context to get. Also used to disambiguate
the target/context type as this minifilter
only has one type of context per target.

Context       - Pointer returning a pointer to the attached context.

Return Value:

Returns a status forwarded from FltSetXxxContext.

--*/
{
	PAGED_CODE();

	switch (ContextType) {

	case FLT_STREAMHANDLE_CONTEXT:

		return FltGetStreamHandleContext(FltObjects->Instance,
			(PFILE_OBJECT)Target,
			Context);

	case FLT_STREAM_CONTEXT:

		return FltGetStreamContext(FltObjects->Instance,
			(PFILE_OBJECT)Target,
			Context);
		/*#if OS_VERSION_GREATER_THAN_VISTA

		case FLT_TRANSACTION_CONTEXT:

		return FltGetTransactionContext( FltObjects->Instance,
		(PKTRANSACTION)Target,
		Context );

		#endif	    */
	case FLT_INSTANCE_CONTEXT:

		return FltGetInstanceContext(FltObjects->Instance,
			Context);

	default:

		return STATUS_INVALID_PARAMETER;
	}
}


//---------------------------------------------------------------------------------------------//

NTSTATUS
RMPFileMounterSetContext(
__in PCFLT_RELATED_OBJECTS FltObjects,
__in_opt PVOID Target,//_When_(ContextType==FLT_INSTANCE_CONTEXT, _In_opt_) _When_(ContextType!=FLT_INSTANCE_CONTEXT, _In_)
__in FLT_CONTEXT_TYPE ContextType,
__in PFLT_CONTEXT NewContext,
__out_opt PFLT_CONTEXT *OldContext
)
/*++

Routine Description:

This routine sets the given context to the target.

Arguments:

FltObjects    - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance and its associated volume.

Target        - Pointer to the target to which we want to attach the
context. It will actually be either a FILE_OBJECT or
a KTRANSACTION. For instance contexts, it's ignored, as
the target is the FLT_INSTANCE itself, obtained from
Data->Iopb->TargetInstance.

ContextType   - Type of context to get/allocate/attach. Also used to
disambiguate the target/context type as this minifilter
only has one type of context per target.

NewContext    - Pointer to the context the caller wants to attach.

OldContext    - Returns the context already attached to the target, if
that is the case.

Return Value:

Returns a status forwarded from FltSetXxxContext.

--*/
{
	PAGED_CODE();

	switch (ContextType) {

	case FLT_STREAMHANDLE_CONTEXT:

		return FltSetStreamHandleContext(FltObjects->Instance,
			(PFILE_OBJECT)Target,
			FLT_SET_CONTEXT_KEEP_IF_EXISTS,
			NewContext,
			OldContext);

	case FLT_STREAM_CONTEXT:

		return FltSetStreamContext(FltObjects->Instance,
			(PFILE_OBJECT)Target,
			FLT_SET_CONTEXT_KEEP_IF_EXISTS,
			NewContext,
			OldContext);

		/*#if OS_VERSION_GREATER_THAN_VISTA

		case FLT_TRANSACTION_CONTEXT:

		return FltSetTransactionContext( FltObjects->Instance,
		(PKTRANSACTION)Target,
		FLT_SET_CONTEXT_KEEP_IF_EXISTS,
		NewContext,
		OldContext );
		#endif*/

	case FLT_INSTANCE_CONTEXT:

		return FltSetInstanceContext(FltObjects->Instance,
			FLT_SET_CONTEXT_KEEP_IF_EXISTS,
			NewContext,
			OldContext);

	default:

		ASSERT(!"Unexpected context type!\n");

		return STATUS_INVALID_PARAMETER;
	}
}


//---------------------------------------------------------------------------------------------//

//////////////////////////////////////////////////////////////////////////////
//  			Miscellaneous Functions		                    //
//////////////////////////////////////////////////////////////////////////////

//---------------------------------------------------------------------------------------------//


//---------------------------------------------------------------------------------------------//

VOID
InitEventNotification(
__in PFLT_CALLBACK_DATA Data,
__in PCFLT_RELATED_OBJECTS FltObjects,
__inout PCHANGE_NOTIFICATION notification
)
{

	PAGED_CODE();

	notification->RMPFileMounterFlags = 0;
	notification->AccessType = 0;
	notification->AccessMask = 0;
	notification->FileAttributes = 0;
	notification->Context = NULL;

	notification->UserSID[0] = UNICODE_NULL;
	notification->TokenSource[0] = UNICODE_NULL;
	notification->ImageFileName[0] = UNICODE_NULL;
	notification->NewFileName[0] = UNICODE_NULL;

	notification->CallbackMajorId = Data->Iopb->MajorFunction;
	notification->CallbackMinorId = Data->Iopb->MinorFunction;
	notification->IrpFlags = Data->Iopb->IrpFlags;
	notification->Flags = Data->Flags;

	notification->ProcessId = (FILE_ID)PsGetCurrentProcessId();
	notification->ThreadId = (FILE_ID)PsGetCurrentThreadId();

	notification->CreationTime.QuadPart = 0;
	notification->LastAccessTime.QuadPart = 0;
	notification->LastWriteTime.QuadPart = 0;

	KeQuerySystemTime(&notification->OriginatingTime);
}

VOID
RMPFileMounterSetFileNameFromPreOpData(
__in PFLT_CALLBACK_DATA Data,
__in PCFLT_RELATED_OBJECTS FltObjects,
__inout PCHANGE_NOTIFICATION notification
)
/*--

Routine Description:

This helper tries to find file name from PreOpData and sets file name in notification

Arguments:

Data - Contains information about the given operation.

notification - Structure used to send infomation to post operation.

--*/
{
	PFLT_FILE_NAME_INFORMATION nameInfo = NULL;
	UNICODE_STRING defaultName;
	PUNICODE_STRING nameToUse;
	NTSTATUS status;

#if OS_VERSION_GREATER_THAN_W2K
	WCHAR name[MAXX_PATH];
#endif
	PAGED_CODE();


	ResetBitOnFlag(notification->RMPFileMounterFlags, RMPFileMounter_FILENAME_AVAILABLE);
	//
	//  We got a log record, if there is a file object, get its name.
	//
	//  NOTE: By default, we use the query method
	//  FLT_FILE_NAME_QUERY_ALWAYS_ALLOW_CACHE_LOOKUP
	//  because FsMonitor would like to get the name as much as possible, but
	//  can cope if we can't retrieve a name.  For a debugging type filter,
	//  like Minispy, this is reasonable, but for most production filters
	//  who need names reliably, they should query the name at times when it
	//  is known to be safe and use the query method
	//  FLT_FILE_NAME_QUERY_DEFAULT.
	//

	if (FltObjects->FileObject != NULL) {

		status = FltGetFileNameInformation(Data,
			FLT_FILE_NAME_NORMALIZED |
			FLT_FILE_NAME_QUERY_DEFAULT,
			&nameInfo);

	}
	else {

		//
		//  Can't get a name when there's no file object
		//
		status = STATUS_UNSUCCESSFUL;
	}

	//
	//  Use the name if we got it else use a default name
	//

	if (NT_SUCCESS(status)) {

		nameToUse = &nameInfo->Name;
		SetBitOnFlag(notification->RMPFileMounterFlags, RMPFileMounter_FILENAME_AVAILABLE);
		//
		//  Parse the name if requested
		//

		if (FlagOn(RMPFileMounterData.DebugFlags, SPY_DEBUG_PARSE_NAMES)) {

#ifdef DBG
			ASSERT(NT_SUCCESS(FltParseFileNameInformation(nameInfo)));
#else
			FltParseFileNameInformation(nameInfo);
#endif
		}

	}
	else {


#if OS_VERSION_GREATER_THAN_W2K
		NTSTATUS lstatus;
		PFLT_FILE_NAME_INFORMATION lnameInfo;

		//
		//  If we couldn't get the "normalized" name try and get the
		//  "opened" name
		//
		//DbgPrint( "1) Name Unsuccess-> 0x%X", status);
		if (FltObjects->FileObject != NULL) {

			//
			//  Get the opened name
			//

			lstatus = FltGetFileNameInformation(Data,
				FLT_FILE_NAME_OPENED |
				FLT_FILE_NAME_QUERY_DEFAULT,
				&lnameInfo);


			if (NT_SUCCESS(lstatus)) {

#pragma prefast(suppress:__WARNING_BANNED_API_USAGE, "reviewed and safe usage")
				(VOID)_snwprintf(name,
					sizeof(name) / sizeof(WCHAR),
					L"<%08x> %wZ",
					status,
					&lnameInfo->Name);

				SetBitOnFlag(notification->RMPFileMounterFlags, RMPFileMounter_FILENAME_AVAILABLE);
				FltReleaseFileNameInformation(lnameInfo);

			}
			else {

				//
				//  If that failed report both NORMALIZED status and
				//  OPENED status
				//

#pragma prefast(suppress:__WARNING_BANNED_API_USAGE, "reviewed and safe usage")
				(VOID)_snwprintf(name,
					sizeof(name) / sizeof(WCHAR),
					L"<NO NAME: NormalizeStatus=%08x OpenedStatus=%08x>",
					status,
					lstatus);
			}

		}
		else {

#pragma prefast(suppress:__WARNING_BANNED_API_USAGE, "reviewed and safe usage")
			(VOID)_snwprintf(name,
				sizeof(name) / sizeof(WCHAR),
				L"<NO NAME>");

		}

		//
		//  Name was initialized by _snwprintf() so it may not be null terminated
		//  if the buffer is insufficient. We will ignore this error and truncate
		//  the file name. 
		//

		name[(sizeof(name) / sizeof(WCHAR)) - 1] = L'\0';

		RtlInitUnicodeString(&defaultName, name);
		nameToUse = &defaultName;
#else
		//
		//  We were unable to get the String safe routine to work on W2K
		//  Do it the old safe way
		//

		RtlInitUnicodeString(&defaultName, L"<NO NAME>");
		nameToUse = &defaultName;
#endif 
	}

	SetFileName(nameToUse, notification);

	//  Release the name information structure (if defined)

	if (NULL != nameInfo) {
		FltReleaseFileNameInformation(nameInfo);
	}
}

VOID
SetFileName(
__in PUNICODE_STRING fileName,
__inout PCHANGE_NOTIFICATION notification
)
{

	int len = (MAXX_PATH - 1) * sizeof(WCHAR);

	PAGED_CODE();

	notification->OldFileName[0] = UNICODE_NULL;

	try {
		if (fileName != NULL)
		{
			if (fileName->Length < len) len = fileName->Length;
			RtlCopyBytes(notification->OldFileName, fileName->Buffer, len);
			notification->OldFileName[len / sizeof(WCHAR)] = UNICODE_NULL;
		}
	} except(EXCEPTION_EXECUTE_HANDLER) {
		//
		//  Error accessing buffer. Complete i/o with failure
		//
		notification->OldFileName[0] = UNICODE_NULL;
		DbgPrint("\n!!! Exception in RtlCopyMemory");
	}
}

VOID SendPostOperationData(
	__in PFLT_CALLBACK_DATA Data,
	__inout PCHANGE_NOTIFICATION notification
	)
	/*++

	Routine Description:

	This is called from the post-operation callback routine to copy the
	necessary information into the log record.

	NOTE:  This code must be NON-PAGED because it can be called on the
	paging path or at DPC level.

	Arguments:

	Data - The Data structure that contains the information we want to record.

	RecordList - Where we want to save the data

	Return Value:

	None.

	--*/
{
	ULONG replyLength;
	NTSTATUS status = STATUS_SUCCESS;
	BOOLEAN safe = TRUE;
	FILE_ID PID, TID;
	LARGE_INTEGER timeout = { 0 };

	PAGED_CODE();

	try
	{
		//DbgPrint( "[%d] Send Message [%d]",PsGetCurrentProcessId(), KeGetCurrentIrql());
		if (notification == NULL)
		{
			DbgPrint("\n!!! Notification Memory allocated failed");
		}
		else
		{
			//
			//  Send message to user mode to indicate it should scan the buffer.
			//  We don't have to synchronize between the send and close of the handle
			//  as FltSendMessage takes care of that.
			//
			timeout.QuadPart = -((LONGLONG)100) * (LONGLONG)1000 * (LONGLONG)10000; // 10s


			for (int loop = 0; loop < portCnt; loop++){
			    replyLength = sizeof(CHANGE_NOTIFICATION_REPLY);
				status = FltSendMessage(RMPFileMounterData.Filter,
				&RMPFileMounterData.ClientPortArray[loop],
				notification,
				sizeof(CHANGE_NOTIFICATION),
				notification,
				&replyLength,
				NULL);

			if (STATUS_SUCCESS == status) {
				DbgPrint("Success %s", ((PCHANGE_NOTIFICATION_REPLY)notification)->replyBuffer);
				DbgPrint("Success %d", ((PCHANGE_NOTIFICATION_REPLY)notification)->Reply);
			}
			else {

				//
				//  Couldn't send message. This sample will let the i/o through.
				//

				DbgPrint("\n!!! scanner.sys --- couldn't send message to user-mode to scan file, status %d", status);
			}
		}
		}

	} except(EXCEPTION_EXECUTE_HANDLER) {
		DbgPrint("\n!!! Exception in RtlCopyBytes while copying NewFileName");
	}

}


//---------------------------------------------------------------------------------------------//

