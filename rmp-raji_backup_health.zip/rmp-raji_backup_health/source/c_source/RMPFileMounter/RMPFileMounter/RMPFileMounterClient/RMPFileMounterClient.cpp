/*++

Module Name:

RMPFileMounterClient.c

Abstract:

This file contains the implementation for the main function of the
user application piece of MiniSpy.  This function is responsible for
controlling the command mode available to the user to control the
kernel mode driver.

Environment:

User mode

--*/

#include <DriverSpecs.h>
__user_code

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <iostream>
#include <fstream>
#include <wchar.h>
#include <windows.h>
#include <assert.h>
#include "zlib.h"
#include <io.h>
#include <map>
#include <vector>
#include <fcntl.h>
#include <string>
#include "RMPFileMounterClient.h"
#include <time.h>
#include <strsafe.h>
#include <algorithm>
#include <Shlwapi.h>
#include <sys/types.h>
#include <sys/stat.h>
using namespace std;

#define SUCCESS              	0
#define USAGE_ERROR          	1
#define FILTER_NAME         	L"RMPFileMounter"

//
//  Main uses a loop which has an assignment in the while
//  conditional statement. Suppress the compiler's warning.
//

#define SPAN 10485760L       /* desired distance between access points */
#define WINSIZE 32768U      /* sliding window size */
#define CHUNK 65536         /* file input buffer size */

/* access point entry */
struct point {
	__int64 out;          /* corresponding offset in uncompressed data */
	__int64 in;           /* offset in input file of first full byte */
	int bits;           /* number of bits (1-7) from byte at in - 1, or 0 */
	unsigned char window[WINSIZE];  /* preceding 32K of uncompressed data */
};

/* access point list */
struct access {
	int have;           /* number of list entries filled in */
	int size;           /* number of list entries allocated */
	struct point *list; /* allocated list */
};

boolean vmwareInc = false;
char *compressedFile;
char *indexFile;
char *sparseFileName;
gzFile ifile;
struct access *index = NULL;
FILE *in;
int moduleNumber = 0; // 0-BMR 1-VMware 2-HYPER-V
boolean isBMREncrypted = false;
wstring BMRsecretKeyW = L"";

#define ENCRYPT_BLOCK_SIZE 16
#define KEYLENGTH  0x00800000
#define ENCRYPT_ALGORITHM CALG_AES_128

typedef struct {
	UINT64 LENGTH;
	UINT64 OFFSET;
	UINT64 SEEKLENGTH;
	int FILENAME;
}incrementalList;

incrementalList* pointer;
int incListCount;
gzFile* fileList;
std::map<int, FileStructure*> indexToFileStructMap;

/* Deallocate an index built by build_index() */
void free_index(struct access *index)
{
	if (index != NULL) {
		free(index->list);
		free(index);
	}
}

static uint32_t read_uint32(gzFile gz)
{
	uint32_t v;
	gzread(gz, &v, sizeof(v));
	return v;
}

HCRYPTKEY generateHashKey(LPTSTR pszPassword) {
	HCRYPTPROV hCryptProv = NULL;
	HCRYPTKEY hKey = NULL;
	HCRYPTHASH hHash = NULL;
	bool CryptAcquireContextStatus = false;
	if (CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, 0)) {
		CryptAcquireContextStatus = true;
	}
	else {
		printf("\n CryptAcquireContext failed");
		if (CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, CRYPT_NEWKEYSET)) {
			CryptAcquireContextStatus = true;
		}
		else {
			return -1;
		}
	}
	if (CryptAcquireContextStatus) {
		if (CryptCreateHash(hCryptProv, CALG_MD5, 0, 0, &hHash)) {
			if (CryptHashData(hHash, (BYTE *)pszPassword, lstrlen(pszPassword), 0)) {
				if (CryptDeriveKey(hCryptProv, ENCRYPT_ALGORITHM, hHash, KEYLENGTH, &hKey)) {
					return hKey;
				}
				else {
					printf("\n CryptDeriveKey failed");
					return -1;
				}
			}
			else {
				printf("\n CryptHashData failed");
				return -1;
			}
		}
		else {
			printf("\n CryptCreateHash failed");
			return -1;
		}
	}
}

unsigned decryptBuffer(HCRYPTKEY hKey, PBYTE pbBuffer, DWORD dwCount, bool fEOF)
{
	if (pbBuffer != NULL) {
		if (CryptDecrypt(hKey, NULL, fEOF, 0, pbBuffer, &dwCount)) {
			return dwCount;//return encrypted buffer
		}
		else {
			DWORD dw = GetLastError();
		}
	}
}

int extractDecrypt(FILE *in, struct access *index, __int64 offset, unsigned char *buf, int len, LPTSTR secretKey)
{
	int ret, skip;
	z_stream strm;
	struct point *here;
	unsigned char input[CHUNK];
	unsigned char discard[WINSIZE];
	HCRYPTKEY hKey = generateHashKey(secretKey);

	/* proceed only if something reasonable to do */
	if (len < 0)
		return 0;

	/* find where in stream to start */
	here = index->list;
	ret = index->have;

	while (--ret && here[1].out <= offset) {
		here++;
	}

	/* initialize file and inflate state to start there */
	strm.zalloc = Z_NULL;
	strm.zfree = Z_NULL;
	strm.opaque = Z_NULL;
	strm.avail_in = 0;
	strm.next_in = Z_NULL;
	ret = inflateInit2(&strm, -MAX_WBITS);// -15);         /* raw inflate */
	if (ret != Z_OK) {
		printf("\n\nZ_OK failed");
		return ret;
	}
	int remainder = (here->in - (here->bits ? 1 : 0)) % CHUNK;
	__int64 seekValue = (here->in - (here->bits ? 1 : 0)) / CHUNK * CHUNK;
	if (here->in < CHUNK) {
		seekValue = 0;
		remainder = here->in - (here->bits ? 1 : 0);
	}
	ret = _fseeki64(in, seekValue, SEEK_SET);//replace this after decryption

	if (ret == -1) {

		goto extract_ret;
	}

	/* skip uncompressed bytes until offset reached, then satisfy request */
	offset -= here->out;
	strm.avail_in = 0;
	skip = 1;                               /* while skipping to offset */
	boolean alreadyMoved = false;

	boolean tempBuf = false;
	do {
		/* define where to put uncompressed data, and how much */
		if (offset == 0 && skip) {          /* at offset now */
			strm.avail_out = len;
			strm.next_out = buf;
			skip = 0;                       /* only do this once */
		}
		if (offset > WINSIZE) {             /* skip WINSIZE bytes */
			strm.avail_out = WINSIZE;
			strm.next_out = discard;
			offset -= WINSIZE;
		}
		else if (offset != 0) {             /* last skip */
			strm.avail_out = (unsigned)offset;
			strm.next_out = discard;
			offset = 0;
		}


		/* uncompress until avail_out filled, or end of stream */
		unsigned char tempBuffer[CHUNK];
		do {
			if (strm.avail_in == 0) {
				//to handle the next decryption
				/*if (!tempBuf && seekValue != 0) {
				fseek(in, -CHUNK, SEEK_CUR);
				int test = fread(tempBuffer, 1, CHUNK, in);
				tempBuf = true;
				bool fEOF = FALSE;
				if (test < CHUNK) {
				fEOF = TRUE;
				}
				test = decryptBuffer(hKey, tempBuffer, test, fEOF);
				}*/

				strm.avail_in = fread(input, 1, CHUNK, in);
				if (ferror(in)) {
					ret = Z_ERRNO;
					printf("\n\nZ_ERRNO failed");
					goto extract_ret;
				}
				if (strm.avail_in == 0) {
					ret = Z_DATA_ERROR;
					printf("\n\nZ_DATA_ERROR failed");
					goto extract_ret;
				}
				strm.next_in = input;

				//decrypt logic
				DWORD dwBlockLen;
				DWORD dwBufferLen;
				dwBlockLen = strm.avail_in;
				dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
				bool fEOF = FALSE;
				if (dwBlockLen < CHUNK) {
					fEOF = TRUE;
				}

				strm.avail_in = decryptBuffer(hKey, input, dwBlockLen, fEOF);

				strm.next_in = input;

				//remove bits before inflate
				int moverCount = remainder;//here->in - (here->bits ? 1 : 0);

				for (int testMove = 0; testMove < moverCount && !alreadyMoved; testMove++) {
					strm.next_in++;
					strm.avail_in--;
				}

				int getcValue = 0;
				if (here->bits && !alreadyMoved) {//getc logic
					getcValue = strm.next_in[0];
					strm.next_in++;
					strm.avail_in--;
				}


				//logic for bits inflate prime
				if (!alreadyMoved) {
					uInt avail_in_temp = strm.avail_in;
					z_const Bytef *next_in_temp = strm.next_in;
					if (here->bits) {
						ret = getcValue;//need to add logic for this code
						if (ret == -1) {
							ret = ferror(in) ? Z_ERRNO : Z_DATA_ERROR;
							printf("\n ferror");
							goto extract_ret;
						}
						(void)inflatePrime(&strm, here->bits, ret >> (8 - here->bits));
					}
					int resultofInflateSetDictionary = inflateSetDictionary(&strm, here->window, WINSIZE);
					strm.next_in = next_in_temp;
					strm.avail_in = avail_in_temp;
				}
				alreadyMoved = true;
			}

			ret = inflate(&strm, Z_NO_FLUSH);       /* normal inflate */
			if (ret == Z_NEED_DICT) {
				printf("\n Z_NEED_DICT");
				ret = Z_DATA_ERROR;
			}
			if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR) {

				printf("\n Z_MEM_ERROR || Z_DATA_ERROR\n error message %s \n", strm.msg);
				goto extract_ret;
			}
			if (ret == Z_STREAM_END)
				break;
		} while (strm.avail_out != 0);

		/* if reach end of stream, then don't keep trying to get more */
		if (ret == Z_STREAM_END)
			break;

		/* do until offset reached and requested data read, or stream ends */
	} while (skip);

	/* compute number of uncompressed bytes read after offset */
	ret = skip ? 0 : len - strm.avail_out;

	/* clean up and return bytes read or error */
extract_ret:
	(void)inflateEnd(&strm);
	return ret;
}

/* Use the index to read len bytes from offset into buf, return bytes read or
negative for error (Z_DATA_ERROR or Z_MEM_ERROR).  If data is requested past
the end of the uncompressed data, then extract() will return a value less
than len, indicating how much as actually read into buf.  This function
should not return a data error unless the file was modified since the index
was generated.  extract() may also return Z_ERRNO if there is an error on
reading or seeking the input file. */
int extract(FILE *in, struct access *index, __int64 offset,
	unsigned char *buf, int len)
{
	int ret, skip;
	z_stream strm;
	struct point *here;
	unsigned char input[CHUNK];
	unsigned char discard[WINSIZE];

	clock_t t1, t2;
	/* proceed only if something reasonable to do */
	if (len < 0)
		return 0;

	/* find where in stream to start */
	here = index->list;
	ret = index->have;

	t1 = clock();
	while (--ret && here[1].out <= offset) {
		here++;
	}
	t2 = clock();
	long timediff = ((long)t2 - (long)t1);
	long seconds = timediff;

	/* initialize file and inflate state to start there */
	strm.zalloc = Z_NULL;
	strm.zfree = Z_NULL;
	strm.opaque = Z_NULL;
	strm.avail_in = 0;
	strm.next_in = Z_NULL;
	ret = inflateInit2(&strm, -15);         /* raw inflate */
	if (ret != Z_OK)
		return ret;
	ret = _fseeki64(in, here->in - (here->bits ? 1 : 0), SEEK_SET);
	if (ret == -1) {
		printf("error at [LINE %d]\n", __LINE__);
		goto extract_ret;
	}
	if (here->bits) {
		ret = fgetc(in);
		if (ret == -1) {
			printf("[errno : %d] [at %d]\n", errno, __LINE__);
			ret = ferror(in) ? Z_ERRNO : Z_DATA_ERROR;
			printf("[errno : %d] [at %d]\n", errno, __LINE__);
			goto extract_ret;
		}
		(void)inflatePrime(&strm, here->bits, ret >> (8 - here->bits));
	}
	(void)inflateSetDictionary(&strm, here->window, WINSIZE);

	/* skip uncompressed bytes until offset reached, then satisfy request */
	offset -= here->out;
	strm.avail_in = 0;
	skip = 1;                               /* while skipping to offset */
	do {
		/* define where to put uncompressed data, and how much */
		if (offset == 0 && skip) {          /* at offset now */
			strm.avail_out = len;
			strm.next_out = buf;
			skip = 0;                       /* only do this once */
		}
		if (offset > WINSIZE) {             /* skip WINSIZE bytes */
			strm.avail_out = WINSIZE;
			strm.next_out = discard;
			offset -= WINSIZE;
		}
		else if (offset != 0) {             /* last skip */
			strm.avail_out = (unsigned)offset;
			strm.next_out = discard;
			offset = 0;
		}

		/* uncompress until avail_out filled, or end of stream */
		do {
			if (strm.avail_in == 0) {
				strm.avail_in = fread(input, 1, CHUNK, in);
				if (ferror(in)) {
					printf("error at [LINE %d]\n", __LINE__);
					ret = Z_ERRNO;
					goto extract_ret;
				}
				if (strm.avail_in == 0) {
					ret = Z_DATA_ERROR;
					goto extract_ret;
				}
				strm.next_in = input;
			}
			ret = inflate(&strm, Z_NO_FLUSH);       /* normal inflate */
			if (ret == Z_NEED_DICT)
				ret = Z_DATA_ERROR;
			if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
				goto extract_ret;
			if (ret == Z_STREAM_END)
				break;
		} while (strm.avail_out != 0);

		/* if reach end of stream, then don't keep trying to get more */
		if (ret == Z_STREAM_END)
			break;

		/* do until offset reached and requested data read, or stream ends */
	} while (skip);

	/* compute number of uncompressed bytes read after offset */
	ret = skip ? 0 : len - strm.avail_out;

	/* clean up and return bytes read or error */
extract_ret:
	(void)inflateEnd(&strm);
	return ret;
}

/*reopens a file that was closed to continue satisfying the request*/
FILE* reopenFile(int fileIndex) {
	auto keyValue = indexToFileStructMap.find(fileIndex);

	FileStructure* fileStruct = (FileStructure *)keyValue->second;
	fclose(fileStruct->filepointer);
	printf("\nbefore _wopen filePath %ws\n", fileStruct->filePath);
	int fd = _wopen(fileStruct->filePath, _O_RDONLY | _O_BINARY);
	printf("reopen filePath %ws\n", fileStruct->filePath);
	if (fd == -1) {
		int errsv = errno;
		printf("ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS %d \n", errsv);
		fflush(stdout);
		return NULL;
	}
	else {
		printf("reopenFile _wopen done\n");
	}
	FILE* InfileHandle = _fdopen(fd, "rb");
	if (InfileHandle == NULL) {
		printf("ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_FDOPEN\n");
		fflush(stdout);
		return NULL;
	}
	else {
		printf("InfileHandle marshalled\n");
	}
	fileStruct->filepointer = InfileHandle;
	indexToFileStructMap.erase(fileIndex);
	indexToFileStructMap.insert(pair<int, FileStructure*>(fileIndex, fileStruct));
	fflush(stdout);
	return InfileHandle;
}
/* Add an entry to the access point list.  If out of memory, deallocate the
existing list and return NULL. */
struct access *addpoint(struct access *index, int bits,
	__int64 in, __int64 out, unsigned left, unsigned char *window) {
	struct point *next;

	/* if list is empty, create it (start with eight points) */
	if (index == NULL) {
		index = (struct access*) malloc(sizeof(struct access));
		if (index == NULL) return NULL;
		index->list = (point*)malloc(sizeof(struct point) << 3);
		if (index->list == NULL) {
			free(index);
			return NULL;
		}
		index->size = 8;
		index->have = 0;
	}/* if list is full, make it bigger */
	else if (index->have == index->size) {
		index->size <<= 1;
		next = (point*)realloc(index->list, sizeof(struct point) * index->size);
		if (next == NULL) {
			free_index(index);
			return NULL;
		}
		index->list = next;
	}

	/* fill in entry and increment how many we have */
	next = index->list + index->have;
	next->bits = bits;
	next->in = in;
	next->out = out;
	if (left)
		memcpy(next->window, window + WINSIZE - left, left);
	if (left < WINSIZE)
		memcpy(next->window + left, window, WINSIZE - left);
	index->have++;

	/* return list, possibly reallocated */
	return index;
}

int build_indexForEncryptedFile(FILE *in, __int64 span, struct access **built, LPTSTR pszPassword)
{
	HCRYPTKEY hKey = generateHashKey(pszPassword);
	int ret;
	__int64 totin, totout;        /* our own total counters to avoid 4GB limit */
	__int64 last;                 /* totout value of last access point */
	struct access *index;       /* access points being generated */
	z_stream strm;
	unsigned char input[CHUNK];
	unsigned char window[WINSIZE];

	/* initialize inflate */
	strm.zalloc = Z_NULL;
	strm.zfree = Z_NULL;
	strm.opaque = Z_NULL;
	strm.avail_in = 0;
	strm.next_in = Z_NULL;
	ret = inflateInit2(&strm, 47);      /* automatic zlib or gzip decoding */
	if (ret != Z_OK)
		return ret;

	/* inflate the input, maintain a sliding window, and build an index -- this
	also validates the integrity of the compressed data using the check
	information at the end of the gzip or zlib stream */
	totin = totout = last = 0;
	index = NULL;               /* will be allocated by first addpoint() */
	strm.avail_out = 0;
	do {
		//printf("in build_index\n");
		/* get some compressed data from input file */
		strm.avail_in = fread(input, 1, CHUNK, in);
		if (ferror(in)) {
			ret = Z_ERRNO;
			goto build_index_error;
		}
		if (strm.avail_in == 0) {
			ret = Z_DATA_ERROR;
			goto build_index_error;
		}

		//decrypt logic
		DWORD dwBlockLen;
		DWORD dwBufferLen;
		dwBlockLen = strm.avail_in;
		dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
		bool fEOF = FALSE;
		if (dwBlockLen < CHUNK) {
			fEOF = TRUE;
		}
		strm.avail_in = decryptBuffer(hKey, input, dwBlockLen, fEOF);

		strm.next_in = input;

		/* process all of that, or until end of stream */
		do {
			/* reset sliding window if necessary */
			if (strm.avail_out == 0) {
				strm.avail_out = WINSIZE;
				strm.next_out = window;
			}

			/* inflate until out of input, output, or at end of block --
			update the total input and output counters */
			totin += strm.avail_in;
			totout += strm.avail_out;
			ret = inflate(&strm, Z_BLOCK);      /* return at end of block */
			totin -= strm.avail_in;
			totout -= strm.avail_out;
			if (ret == Z_NEED_DICT)
				ret = Z_DATA_ERROR;
			if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
				goto build_index_error;
			if (ret == Z_STREAM_END)
				break;

			/* if at end of block, consider adding an index entry (note that if
			data_type indicates an end-of-block, then all of the
			uncompressed data from that block has been delivered, and none
			of the compressed data after that block has been consumed,
			except for up to seven bits) -- the totout == 0 provides an
			entry point after the zlib or gzip header, and assures that the
			index always has at least one access point; we avoid creating an
			access point after the last block by checking bit 6 of data_type
			*/
			if ((strm.data_type & 128) && !(strm.data_type & 64) &&
				(totout == 0 || totout - last > span)) {
				index = addpoint(index, strm.data_type & 7, totin,
					totout, strm.avail_out, window);
				if (index == NULL) {
					ret = Z_MEM_ERROR;
					goto build_index_error;
				}
				last = totout;
			}
		} while (strm.avail_in != 0);
	} while (ret != Z_STREAM_END);

	/* clean up and return index (release unused entries in list) */
	(void)inflateEnd(&strm);
	index->list = (point*)realloc(index->list, sizeof(struct point) * index->have);
	index->size = index->have;
	*built = index;
	return index->size;

	/* return error */
build_index_error:
	(void)inflateEnd(&strm);
	if (index != NULL)
		free_index(index);
	return ret;
}

/* Make one entire pass through the compressed stream and build an index, with
access points about every span bytes of uncompressed output -- span is
chosen to balance the speed of random access against the memory requirements
of the list, about 32K bytes per access point.  Note that data after the end
of the first zlib or gzip stream in the file is ignored.  build_index()
returns the number of access points on success (>= 1), Z_MEM_ERROR for out
of memory, Z_DATA_ERROR for an error in the input file, or Z_ERRNO for a
file read error.  On success, *built points to the resulting index. */
int build_index(FILE *in, __int64 span, struct access **built) {
	int ret;
	__int64 totin, totout; /* our own total counters to avoid 4GB limit */
	__int64 last; /* totout value of last access point */
	struct access *index; /* access points being generated */
	z_stream strm;
	unsigned char input[CHUNK];
	unsigned char window[WINSIZE];

	/* initialize inflate */
	strm.zalloc = Z_NULL;
	strm.zfree = Z_NULL;
	strm.opaque = Z_NULL;
	strm.avail_in = 0;
	strm.next_in = Z_NULL;
	ret = inflateInit2(&strm, 47); /* automatic zlib or gzip decoding */
	if (ret != Z_OK)
		return ret;

	/* inflate the input, maintain a sliding window, and build an index -- this
	also validates the integrity of the compressed data using the check
	information at the end of the gzip or zlib stream */
	totin = totout = last = 0;
	index = NULL; /* will be allocated by first addpoint() */
	strm.avail_out = 0;
	do {
		/* get some compressed data from input file */
		strm.avail_in = fread(input, 1, CHUNK, in);
		if (ferror(in)) {
			ret = Z_ERRNO;
			goto build_index_error;
		}
		if (strm.avail_in == 0) {
			ret = Z_DATA_ERROR;
			goto build_index_error;
		}
		strm.next_in = input;

		/* process all of that, or until end of stream */
		do {
			/* reset sliding window if necessary */
			if (strm.avail_out == 0) {
				strm.avail_out = WINSIZE;
				strm.next_out = window;
			}

			/* inflate until out of input, output, or at end of block --
			update the total input and output counters */
			totin += strm.avail_in;
			totout += strm.avail_out;
			ret = inflate(&strm, Z_BLOCK); /* return at end of block */
			totin -= strm.avail_in;
			totout -= strm.avail_out;
			if (ret == Z_NEED_DICT)
				ret = Z_DATA_ERROR;
			if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
				goto build_index_error;
			if (ret == Z_STREAM_END)
				break;

			/* if at end of block, consider adding an index entry (note that if
			data_type indicates an end-of-block, then all of the
			uncompressed data from that block has been delivered, and none
			of the compressed data after that block has been consumed,
			except for up to seven bits) -- the totout == 0 provides an
			entry point after the zlib or gzip header, and assures that the
			index always has at least one access point; we avoid creating an
			access point after the last block by checking bit 6 of data_type
			*/
			if ((strm.data_type & 128) && !(strm.data_type & 64) &&
				(totout == 0 || totout - last > span)) {
				index = addpoint(index, strm.data_type & 7, totin,
					totout, strm.avail_out, window);
				if (index == NULL) {
					ret = Z_MEM_ERROR;
					goto build_index_error;
				}
				last = totout;
			}
		} while (strm.avail_in != 0);
	} while (ret != Z_STREAM_END);

	/* clean up and return index (release unused entries in list) */
	(void)inflateEnd(&strm);
	index->list = (point*)realloc(index->list, sizeof(struct point) * index->have);
	index->size = index->have;
	*built = index;
	return index->size;

	/* return error */
build_index_error:
	(void)inflateEnd(&strm);
	if (index != NULL)
		free_index(index);
	return ret;
}

int write_uint32(gzFile gz, uint32_t v) {
	return gzwrite(gz, &v, sizeof(v));
}

int indexCreation(wstring backupFile, boolean isEncrypted, LPWSTR secretKey) {
	size_t pos = backupFile.rfind(L".");
	wstring indexName = backupFile.substr(0, pos) + L".idx";
	//string fileName(backupFile.begin(), backupFile.end());
	//string indexFile(indexName.begin(), indexName.end());
	int len;
	__int64 offset;
	FILE *in;
	struct access *index = NULL;
	unsigned char buf[CHUNK];

	//in = fopen(fileName.c_str(), "rb");
	int fd = _wopen(backupFile.c_str(), _O_RDONLY | _O_BINARY);
	if (fd == -1) {
		int errsv = errno;
		printf("index file: %ws could not open for reading : %d\n", backupFile.c_str(), errsv);
		fflush(stdout);
		return 1;
	}
	else {
		printf("index file : fd ok\n");
	}
	in = _fdopen(fd, "rb");
	if (in == NULL) {
		printf("\nzran: could not open %ws for reading\n", backupFile.c_str());
		return 1;
	}

	/* build index */
	if (isEncrypted) {
		len = build_indexForEncryptedFile(in, SPAN, &index, secretKey);
	}
	else {
		len = build_index(in, SPAN, &index);
	}

	if (len < 0) {
		fclose(in);
		switch (len) {
		case Z_MEM_ERROR:
			printf("zran: out of memory\n");
			break;
		case Z_DATA_ERROR:
			printf("zran: compressed data error in %ws\n", backupFile.c_str());
			break;
		case Z_ERRNO:
			printf("zran: read error on %ws\n", backupFile.c_str());
			break;
		default:
			printf("zran: error %d while building index\n", len);
		}
		return 1;
	}
	printf("zran: built index with %d access points\n", len);
	fclose(in);

	int fileDescriptor = _wopen(indexName.c_str(), _O_CREAT | _O_WRONLY | _O_BINARY, _S_IWRITE);
	if (fileDescriptor == -1) {
		int errsv = errno;
		printf("\n_wopen error : %d\n", errsv);
		//tmpStream.open(tmpFile, ios::out);
		//tmpStream.close();
		return 1;
	}
	else {
		printf("\n_wopen done 1\n");
	}
	gzFile gz = gzdopen(fileDescriptor, "wb");
	//gzFile gz = gzopen(indexFile.c_str(), "wb");
	if (gz == NULL) {
		printf("gz null\n");
	}

	// Write a header.
	write_uint32(gz, (uint32_t)index->have);

	// Write out entry points.
	for (int i = 0; i < index->have; ++i) {
		gzwrite(gz, &index->list[i].out, sizeof(__int64));
		gzwrite(gz, &index->list[i].in, sizeof(__int64));
		gzwrite(gz, &index->list[i].bits, sizeof(int));
		gzwrite(gz, index->list[i].window, WINSIZE);
	}

	if (gz != NULL) {
		gzclose(gz);
	}
	if (index != NULL) {
		free_index(index);
	}
	return 0;
}

int main(int argc, char* argv[])
/*++

Routine Description:

Main routine for minispy

Arguments:

getEventListener - function pointer of callback method to notify change to C#

Return Value:

--*/
{
	HANDLE port = INVALID_HANDLE_VALUE, completion = NULL;
	HRESULT hResult = S_OK, hr;
	ULONG threadId;
	DWORD threadCount = DEFAULT_THREAD_COUNT;

	char *tmpFile;
	ofstream tmpStream;
	unsigned int i = 0;
	bool isOS10OrAbove = false;
	tmpFile = argv[3];

	if (strcmp(argv[1], "HYPERV") == 0 || strcmp(argv[1], "VMWARE") == 0) {
		printf("\ninside virtual parser usermode");
		//printf("argv[2] : %s", argv[2]);
		string files = argv[2];


		std::vector<string> filesList;
		size_t pos, innerpos;
		string filesTemp, delimiter = "<**>";
		filesTemp.assign(files.begin(), files.end());
		printf("\nbefore inc");

		incListCount = stoi(filesTemp.substr(0, filesTemp.find("<??>")));
		if (strcmp(argv[1], "HYPERV") == 0) {
			moduleNumber = 2;
			if (incListCount == -1) {
				isOS10OrAbove = true;
			}
		}
		if (incListCount > 0) {
			printf("\Inc list processing");
			ifstream infile(argv[4]);
			pointer = new incrementalList[incListCount];
			incrementalList row;
			int rowCount = 0;
			while (infile >> row.OFFSET >> row.LENGTH >> row.SEEKLENGTH >> row.FILENAME)
			{
				pointer[rowCount].OFFSET = row.OFFSET;
				pointer[rowCount].LENGTH = row.LENGTH;
				pointer[rowCount].SEEKLENGTH = row.SEEKLENGTH;
				pointer[rowCount].FILENAME = row.FILENAME;
				rowCount++;
			}
			if (argc > 4) {
				sparseFileName = argv[5];
				printf("\nsparseFileName %s\n", sparseFileName);
			}
		}
		else {
			if (incListCount == 0 && argv[5] != NULL) {
				sparseFileName = argv[5];
				printf("\nsparseFileName inc 0 %s\n", sparseFileName);
			}
			else if (argc > 3) {
				sparseFileName = argv[4];
				printf("\nsparseFileName %s\n", sparseFileName);
			}

		}

		//{
		//	WCHAR stringTobeProcessed[MAX_PATH];
		//	DWORD dwRead, dwWritten;
		//	HANDLE hStdin;
		//	BOOL bSuccess;
		//	hStdin = GetStdHandle(STD_INPUT_HANDLE);
		//	if (hStdin == INVALID_HANDLE_VALUE)
		//		printf("\nhStdin == INVALID_HANDLE_VALUE\n");
		//	//ExitProcess(1);

		//	for (;;)
		//	{
		//		// Read from standard input and stop on error or no data.
		//		bSuccess = ReadFile(hStdin, stringTobeProcessed, MAX_PATH, &dwRead, NULL);
		//		if (!bSuccess || dwRead == 0)
		//			break;
		//		printf("\nstringTobeProcessed : %ws\n", stringTobeProcessed);

		//	}
		//}


		filesTemp.erase(0, filesTemp.find("<??>") + 4);
		//filesTemp = filesTemp.substr(filesTemp.find("?") + 1);

		/*size_t posit = files.find("?");
		string incString = filesTemp.substr(posit + 1);
		incListCount = stoi(incString);*/
		printf("\nInc list size = %d", incListCount);
		//filesTemp.erase(0, posit + 1);
		printf("\nparse begin");
		while ((pos = filesTemp.find(delimiter)) != string::npos) {

			filesList.push_back(filesTemp.substr(0, pos));
			filesTemp.erase(0, pos + 4);
		}
		printf("\nparse end");
		int incPathCount = 0;
		fileList = new gzFile();
		for (vector<string>::iterator loop = filesList.begin(); loop != filesList.end(); ++loop) {
			printf("\niterator initiated");
			string obtainedFile = *loop;
			string obtainedFileTemp(obtainedFile.begin(), obtainedFile.end());

			FileStructure* fileStructure = (FileStructure*)malloc(sizeof(FileStructure));

			if (fileStructure == NULL) {
				printf("ERROR_COULD_NOT_ALLOCATE_MEMORY");
				tmpStream.open(tmpFile, ios::out);
				tmpStream.close();
				return 1;
			}
			printf("\nAcquiring temporary file location and encryption information");
			int innerPosition = obtainedFileTemp.find("<??>");
			int fileIndex = stoi(obtainedFileTemp.substr(0, innerPosition));
			obtainedFileTemp.erase(0, innerPosition + 4);
			innerPosition = obtainedFileTemp.find("<??>");
			string isEncrypted = obtainedFileTemp.substr(0, innerPosition);
			obtainedFileTemp.erase(0, innerPosition + 4);
			innerPosition = obtainedFileTemp.find("<??>");
			string secretKey = obtainedFileTemp.substr(0, innerPosition);
			wstring secretKeyW(secretKey.begin(), secretKey.end());
			obtainedFileTemp.erase(0, innerPosition + 4);
			printf("\nAcquired temporary file location and encryption information");
			boolean isEncryptedB = false;
			if (isEncrypted.compare("true") == 0) {
				printf("\n Backup is encrypted");
				isEncryptedB = true;
				fileStructure->isencrypted = true;

				const wchar_t *wcstr = secretKeyW.c_str();
				fileStructure->encryptionkey = new wchar_t[secretKeyW.length() + 1];
				wcscpy(fileStructure->encryptionkey, secretKeyW.c_str());

				//fileStructure->encryptionkey = (LPWSTR)secretKeyW.c_str();
			}
			else {
				fileStructure->isencrypted = false;
				fileStructure->encryptionkey = L"";
			}
			//printf("\nEncryption key : %ws", secretKeyW.c_str());

			innerPosition = obtainedFileTemp.find("<??>");
			string filePath = obtainedFileTemp.substr(0, innerPosition);
			wstring filePathW(filePath.begin(), filePath.end());
			size_t position = filePathW.rfind(L".");
			int fd = 0;
			if (isEncryptedB || isOS10OrAbove) {
				wstring indexFile;
				if (strcmp(argv[1], "HYPERV") != 0) {
					wstring indexName = filePathW.substr(0, position) + L".vmdk_secure";
					indexFile = wstring(indexName.begin(), indexName.end());
					if (fileIndex == 0) {
						const char *cstr = filePath.c_str();
						compressedFile = new char[filePath.length() + 1];
						strcpy(compressedFile, filePath.c_str());

						fileStructure->filePath = new wchar_t[indexFile.length() + 1];
						wcscpy(fileStructure->filePath, indexFile.c_str());
					}
				}
				else {
					size_t position = (isOS10OrAbove) ? filePathW.rfind(L"_compress") : filePathW.rfind(L"_");
					wstring indexName = filePathW.substr(0, position);
					string sIndexName = string(indexName.begin(), indexName.end());
					indexFile = wstring(filePathW.begin(), filePathW.end());
					if (fileIndex == 0) {
						const char *cstr = sIndexName.c_str();
						compressedFile = new char[indexName.length() + 1];
						strcpy(compressedFile, sIndexName.c_str());
					}
				}

				fd = _wopen(indexFile.c_str(), _O_RDONLY | _O_BINARY);

				if (fd == -1) {
					int errsv = errno;
					printf("ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS %d\n", errsv);
					break;
				}
				else {
					printf("fd ok inside encrypted\n");
				}
			}
			else {
				wstring backupFileName = filePathW.substr(0, position) + L".vmdk";
				wstring backupFile;
				if (strcmp(argv[1], "HYPERV") == 0) {
					backupFile = wstring(filePathW.begin(), filePathW.end());
				}
				else {
					backupFile = wstring(backupFileName.begin(), backupFileName.end());
				}

				if (fileIndex == 0) {
					const char *cstr = filePath.c_str();
					compressedFile = new char[filePath.length() + 1];
					strcpy(compressedFile, filePath.c_str());
				}
				else if (strcmp(argv[1], "HYPERV") == 0) {
					int fileDescriptor = _wopen((wchar_t*)backupFile.c_str(), _O_RDONLY | _O_BINARY);
					if (fileDescriptor == -1) {
						int errsv = errno;
						printf("\n_wopen error : %d", errsv);
						tmpStream.open(tmpFile, ios::out);
						tmpStream.close();
						continue; //return 1;
					}
					else {
						printf("\n_wopen done 1");
					}
					cout << "incPathCount " << incPathCount << " fileDescriptor " << fileDescriptor;
					fileList[incPathCount] = gzdopen(fileDescriptor, "rb");
					incPathCount++;
					continue;
				}
				//fileStructure->filePath = new WCHAR[wcslen(backupFile.c_str()) + 1];
				//wcscpy(fileStructure->filePath, backupFile.c_str());

				const wchar_t *wfptr = backupFile.c_str();
				fileStructure->filePath = new wchar_t[backupFile.length() + 1];
				wcscpy(fileStructure->filePath, backupFile.c_str());

				printf("\nfileStruture->filePath %ws\n", fileStructure->filePath);
				fflush(stdout);
				fd = _wopen(backupFile.c_str(), _O_RDONLY | _O_BINARY);

				if (fd == -1) {
					int errsv = errno;
					printf("ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS %d \n", errsv);
					break;
				}
				else {
					printf("fd ok for backup file\n");
				}
			}

			FILE* InfileHandle = _fdopen(fd, "rb");
			if (!InfileHandle) {
				printf("ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_FDOPEN");
				break;
			}
			fileStructure->filepointer = InfileHandle;


			size_t pos = filePathW.rfind(L".");
			wstring indexName = filePathW.substr(0, pos) + L".idx";
			wstring indexFile(indexName.begin(), indexName.end());

			int indexCreationResult = 0;
			if (PathFileExists(indexFile.c_str()) != 1) {
				printf("\nindex file not present, creating index");
				if (isEncryptedB) {
					int indexCreationResult = 0;
					if (strcmp(argv[1], "HYPERV") != 0) {
						printf("inside encrypted indexCreationResult vmware");
						size_t position = filePathW.rfind(L".");
						wstring filePathWSecure = filePathW.substr(0, position) + L".vmdk_secure";
						indexCreationResult = indexCreation(filePathWSecure, true, fileStructure->encryptionkey);
					}
					else {
						indexCreationResult = indexCreation(filePathW, true, fileStructure->encryptionkey);
					}
					printf("indexCreationResult : %d", indexCreationResult);
				}
				else {
					indexCreationResult = indexCreation(filePathW, false, fileStructure->encryptionkey);
					printf("indexCreationResult : %d", indexCreationResult);
				}
				if (indexCreationResult != 0) {
					printf("\nindex file could not be created");
					break;
				}
			}
			else {
				printf("\nindex file present");
			}

			fd = _wopen(indexFile.c_str(), _O_RDONLY | _O_BINARY);
			if (fd == -1) {
				int errsv = errno;
				printf("ERROR_COULD_NOT_LOAD_INDEX\n");
				break;
			}
			else {
				printf("fd ok index load\n");
			}
			gzFile gz = gzdopen(fd, "rb");

			//gzFile gz = gzopen(indexFile.c_str(), "rb");
			if (gz == NULL) {
				printf("ERROR_COULD_NOT_LOAD_INDEX");
				break;
			}

			// Allocate a seekgzip_t instance.``
			fileStructure->index = (struct access*)malloc(sizeof(struct access));
			if (fileStructure->index == NULL) {
				printf("Index null.out of memory");
				break;
			}
			memset(fileStructure->index, 0, sizeof(*fileStructure->index));

			// Read the number of entry points.
			fileStructure->index->have = fileStructure->index->size = read_uint32(gz);

			// Allocate an array for entry points.
			fileStructure->index->list = (struct point*)malloc(sizeof(struct point) * fileStructure->index->have);
			if (fileStructure->index->list == NULL) {
				printf("Index->list empty");
			}
			printf("Index size : %d", fileStructure->index->have);
			// Read entry points.
			for (int m = 0; m < fileStructure->index->have; ++m) {
				gzread(gz, &fileStructure->index->list[m].out, sizeof(__int64));
				gzread(gz, &fileStructure->index->list[m].in, sizeof(__int64));
				gzread(gz, &fileStructure->index->list[m].bits, sizeof(int));
				gzread(gz, fileStructure->index->list[m].window, WINSIZE);
			}
			if (gz != NULL) {
				gzclose(gz);
			}
			//printf("\nbefore adding to map");
			indexToFileStructMap.insert(pair<int, FileStructure*>(fileIndex, fileStructure));
			//printf("\nafter adding to map");

		}
		printf("\nend of virtual parser loop");
		fflush(stdout);


	}
	else {
		printf("\ninside bmr usermode");
		int len, fd = 0;
		string params = argv[1];

		size_t pos = params.find("<??>");
		string encryptionStatus = params.substr(0, pos);
		if (encryptionStatus.compare("true") == 0) {
			isBMREncrypted = true;
		}
		params.erase(0, pos + 4);
		pos = params.find("<??>");

		string BMRsecretKey = params.substr(0, pos);
		wstring secretKeyW(BMRsecretKey.begin(), BMRsecretKey.end());
		BMRsecretKeyW = secretKeyW;
		params.erase(0, pos + 4);
		pos = params.find("<??>");
		string compressedFileS = params.substr(0, pos);
		wstring compressedFileW(compressedFileS.begin(), compressedFileS.end());

		compressedFile = new char[compressedFileS.length() + 1];
		strcpy(compressedFile, compressedFileS.c_str());

		indexFile = argv[2];
		string indexFileS = argv[2];
		wstring indexFileW(indexFileS.begin(), indexFileS.end());
		printf("compressedFile %s", compressedFile);
		fd = _wopen(compressedFileW.c_str(), _O_RDONLY | _O_BINARY);
		if (fd == -1) {
			int errsv = errno;
			printf("compressedFile file: could not open for reading : %d\n", errsv);
			tmpStream.open(tmpFile, ios::out);
			tmpStream.close();
			return 1;
		}
		else {
			printf("compressedFile file : fd ok\n");
		}
		in = _fdopen(fd, "rb");
		if (in == NULL) {
			printf("zran: could not open %ws for reading\n", compressedFileW.c_str());
			tmpStream.open(tmpFile, ios::out);
			tmpStream.close();
			return 1;
		}
		//in = fopen(compressedFile, "rb");

		//create index if not present
		int fileLength = strlen(indexFile);
		wchar_t *indexFilePath = new wchar_t[fileLength * sizeof(WCHAR)];
		mbstowcs(indexFilePath, indexFile, fileLength * sizeof(WCHAR) + 1);
		printf("indexFilePath : %ws\n", indexFilePath);
		fileLength = strlen(compressedFile);
		wchar_t *compressedFilePath = new wchar_t[fileLength * sizeof(WCHAR)];
		mbstowcs(compressedFilePath, compressedFile, fileLength * sizeof(WCHAR) + 1);
		printf("compressedFilePath : %ws\n", compressedFilePath);
		if (PathFileExists(indexFilePath) != 1) {
			printf("\nindex file not present, creating index");
			int indexCreationResult = indexCreation(compressedFilePath, false, L"");
			printf("indexCreationResult : %d", indexCreationResult);
		}
		else {
			printf("\nindex file present");
		}
		//index creation completed
		fd = _wopen(indexFileW.c_str(), _O_RDONLY | _O_BINARY);
		if (fd == -1) {
			int errsv = errno;
			printf("ERROR_COULD_NOT_LOAD_INDEX %d\n", errsv);
		}
		else {
			printf("fd ok index load");
		}
		gzFile gz = gzdopen(fd, "rb");
		//gzFile gz = gzopen(indexFile.c_str(), "rb");
		if (gz == NULL) {
			printf("gz is null\n");
		}

		// Allocate a seekgzip_t instance.
		index = (struct access*)malloc(sizeof(struct access));
		if (index == NULL) {
			printf("index null.out of memory\n");
		}
		memset(index, 0, sizeof(*index));

		// Read the number of entry points.
		index->have = index->size = read_uint32(gz);

		// Allocate an array for entry points.
		index->list = (struct point*)malloc(sizeof(struct point) * index->have);
		if (index->list == NULL) {
			printf("index->list empty\n");
		}

		// Read entry points.
		for (i = 0; i < index->have; ++i) {
			gzread(gz, &index->list[i].out, sizeof(__int64));
			gzread(gz, &index->list[i].in, sizeof(__int64));
			gzread(gz, &index->list[i].bits, sizeof(int));
			gzread(gz, index->list[i].window, WINSIZE);
		}
		if (gz != NULL) {
			gzclose(gz);
		}
	}

	printf("after memory load\n");
	tmpStream.open(tmpFile, ios::out);
	tmpStream.close();
	//uncomment

	//
	//  Initialize handle in case of error
	//
	evtReceiverContext.IsInitialized = FALSE;
	evtReceiverContext.Port = port;
	evtReceiverContext.Completion = completion;
	evtReceiverContext.CleaningUp = FALSE;
	//evtReceiverContext.GetEventListener = getEventListener;
	//
	//  Open the port that is used to talk to
	//  MiniSpy.
	//

	printf("Connecting to filter's port...\n");

	hResult = FilterConnectCommunicationPort(RMP_PORT_NAME,
		0,
		NULL,
		0,
		NULL,
		&port);

	if (IS_ERROR(hResult)) {

		printf("Could not connect to filter: 0x%08x\n", hResult);
		//DisplayError(hResult);
		goto Main_Exit;
	}

	//---------------------------------------------------------------------------------------
	//
	//  Create a completion port to associate with this handle.
	//

	completion = CreateIoCompletionPort(port,
		NULL,
		0,
		threadCount);

	if (completion == NULL) {

		printf("ERROR: Creating completion port: %d\n", GetLastError());
		CloseHandle(port);
		goto Main_Exit;
	}

	printf("Scanner: Port = 0x%p Completion = 0x%p\n", port, completion);

	evtReceiverContext.Port = port;
	evtReceiverContext.Completion = completion;
	// Close Handle When exiting
	printf("\nbefore create thread");
	mythread = CreateThread(NULL,
		0,
		(LPTHREAD_START_ROUTINE)RetrieveEventFromKernelMode,
		NULL,
		0,
		&threadId);
	printf("\nafter create thread");
	if (mythread == NULL) {

		//
		//  Couldn't create thread.
		//

		hr = GetLastError();
		printf("ERROR: Couldn't create thread: %d\n", hr);
		goto Main_Exit;
	}
	else {
		printf("\nthread creation successful");
	}
	fflush(stdout);
	evtReceiverContext.IsInitialized = TRUE;
	printf("Cleaning Threads..Waiting for Threads to Close\n");
	WaitForSingleObject(mythread, INFINITE);
	//WaitForMultipleObjectsEx(DEFAULT_THREAD_COUNT, threads, TRUE, INFINITE, FALSE);
	printf("Wait Complete\n");
	fflush(stdout);

Main_Exit:

	for (i = 0; i < DEFAULT_THREAD_COUNT; i++)
	{
		if (threads[i]) {
			CloseHandle(threads[i]);
		}
	}
	if (evtReceiverContext.IsInitialized == FALSE)
	{
		printf("Closing Handles\n");

		if (INVALID_HANDLE_VALUE != evtReceiverContext.Port) {
			CloseHandle(evtReceiverContext.Port);
		}

		if (evtReceiverContext.Completion) {
			CloseHandle(evtReceiverContext.Completion); // Check for Failure case
		}
	}
	printf("ShutDown Complete\n");
	if (index) {
		free_index(index);
	}
	else {
		printf("\nindex null");
	}
	if (in) {
		fclose(in);
	}
	else {
		printf("\nin file null");
	}

	for (int i = 0; i < indexToFileStructMap.size(); i++) {
		printf("\ncame in : %d ", i);
		auto keyValue = indexToFileStructMap.find(i);
		FileStructure* fileStruct = (FileStructure *)keyValue->second;
		FILE* fileToBeClosed = fileStruct->filepointer;
		if (fileStruct->filepointer != NULL) {
			fclose(fileToBeClosed);
			printf("\ncame in close file : %d ", i);
		}

	}
	if (pointer) {
		delete[] pointer;
		printf("deleted pointer");
	}
	//todo null pointer check
	for (int i = 0; i < indexToFileStructMap.size(); i++) {
		auto keyValue = indexToFileStructMap.find(i);
		FileStructure* fileStruct = (FileStructure *)keyValue->second;
		if (fileStruct->index != NULL)
		{
			if (fileStruct->index->list != NULL) {
				delete fileStruct->index->list;
			}
			delete fileStruct->index;
		}
		if (fileStruct->filePath != NULL) {
			delete fileStruct->filePath;
		}
		delete fileStruct;
	}
	fflush(stdout);
	return 0;
}

unsigned char dataTemp[65536];
int dataTempLength = 0;
bool sendData(int indexpoint, LONGLONG readOffset, ULONG readLength) {//, PVOID origBuff, int count){
	DATA_BUFFER buf = { 0 };
	ULONG bytesReturned = 0;
	gzFile origFile;

	unsigned char dat[65536] = "";
	z_off_t pointer = readOffset;
	z_off_t bytes_seeked;
	if (indexpoint != 0 && moduleNumber == 2) {
		origFile = fileList[indexpoint - 1];
		bytes_seeked = gzseek(origFile, pointer, SEEK_SET);
		size_t bytes_read = 0;
		bytes_read = gzread(origFile, dat, readLength);
		if (bytes_read <= 0) {
			fprintf(stderr, "Error has occured in gzread\n");
			return false;
		}
		if (bytes_read < readLength) {
			if (!gzeof(origFile)) {
				fprintf(stderr, "Error has occured in gzread bytes_read < bufSize\n");
				int err;
				const char *error_string;
				error_string = gzerror(origFile, &err);
				if (err)
				{
					fprintf(stderr, "gzread : gzerror [%s] at [%d]", error_string, __LINE__);
				}
			}
			return false;
		}
	}
	else {
		auto keyValue = indexToFileStructMap.find(indexpoint);
		FileStructure* fileStruct = (FileStructure *)keyValue->second;
		if (fileStruct->isencrypted) {
			int len = extractDecrypt(fileStruct->filepointer, fileStruct->index, readOffset, dat, readLength, fileStruct->encryptionkey);
			if (len < 0) {
				printf("fileStruct->readOffset %lld\n", readOffset);
				printf("fileStruct->readLength %lld\n", readLength);
				printf("len %d\n", len);

				printf("zran: extraction failed: %s error\n",
					len == Z_MEM_ERROR ? "out of memory" : "input corrupted");
				return false;
			}
			else {
				fprintf(stderr, "zran: extracted %d bytes at %llu\n", len, readOffset);
			}
		}
		else {
			int len = extract(fileStruct->filepointer, fileStruct->index, readOffset, dat, readLength);
			if (len < 0) {
				printf("zran: extraction failed: %s error\n",
					len == Z_MEM_ERROR ? "out of memory" : "input corrupted");
				return false;
			}
			else {
				fprintf(stderr, "zran: extracted %d bytes at %llu\n", len, readOffset);
			}
		}
	}

	memcpy((char *)(dataTemp + dataTempLength), (char *)dat, readLength);
	dataTempLength += readLength;
	return true;
}

void finalSendData(LONGLONG readOffset, ULONG readLength, PVOID origBuff, int count)
{
	DATA_BUFFER buf = { 0 };
	ULONG bytesReturned = 0;
	HRESULT hr;
	buf.bufSize = readLength;
	buf.origBufTemp = origBuff;
	buf.count = count;
	memcpy((char *)buf.data, (char *)dataTemp, readLength);
	hr = FilterSendMessage(evtReceiverContext.Port,
		&buf,
		sizeof(DATA_BUFFER),
		NULL,
		0,
		&bytesReturned);
	if (!SUCCEEDED(hr)) {
		printf("FilterSendMsg: 0x%08x\n", hr);
	}
}

//INCREMENTAL MAPPER MODULE
bool readSatisfier(LONGLONG readOffset, ULONG readLength, incrementalList* incrementalList, int size) {//, PVOID origBufff, int count){
	int first = 0;
	int last = 0;
	int middle = 0;
	UINT64 chunkValue = 0;
	last = size - 1;
	middle = (first + last) / 2;
	int initialPointer = 0;
	//for full backup
	if (incListCount <= 0) {
		if (!sendData(0, readOffset, readLength)) {// , origBufff, count);//sending data
			if (reopenFile(0) == NULL) {
				printf("reopen failed at %d \n", __LINE__);
				return false;
			}
			if (!sendData(0, readOffset, readLength)) {// , origBufff, count);//sending data
				return false;
			}
			return true;
		}
		return true;
	}


	//binary search to find the initial pointer
	UINT64 lowerBound = 0;
	UINT64 upperBound = 0;
	UINT64 seekValue = 0;
	while (first <= last) {
		lowerBound = incrementalList[middle].OFFSET;
		upperBound = lowerBound + incrementalList[middle].LENGTH;
		if (lowerBound <= readOffset) {
			if (readOffset < upperBound) {
				initialPointer = middle;
				break;
			}
			else {
				first = middle + 1;
			}
		}
		else {
			last = middle - 1;
		}
		middle = (first + last) / 2;
	}
	boolean readSatisfied = false;
	initialPointer = middle;
	if ((first > last) && (middle < (incListCount - 1))) {//full backup is enough to satisfy the read request
		if (lowerBound <= readOffset) {
			if (upperBound < readOffset) {
				chunkValue = incrementalList[initialPointer + 1].OFFSET - readOffset;
				if (chunkValue >= readLength) {
					if (!sendData(0, readOffset, readLength)) {// , origBufff, count);//sending data
						if (reopenFile(0) == NULL) {
							printf("reopen failed at %d \n", __LINE__);
							return false;
						}
						if (!sendData(0, readOffset, readLength)) {// , origBufff, count);//sending data
							return false;
						}
					}
					readSatisfied = true;
				}
				else {
					if (!sendData(0, readOffset, chunkValue)) {// , origBufff, count);//sending data
						if (reopenFile(0) == NULL) {
							printf("reopen failed at %d \n", __LINE__);
							return false;
						}
						if (!sendData(0, readOffset, readLength)) {// , origBufff, count);//sending data
							return false;
						}
					}
					readLength = readLength - chunkValue;
					readOffset = incrementalList[initialPointer + 1].OFFSET;
					initialPointer++;
				}

			}
			else if (upperBound >= (readLength + readOffset)) {
				seekValue = incrementalList[initialPointer].SEEKLENGTH + (readOffset - lowerBound);
				if (!sendData(incrementalList[initialPointer].FILENAME, (LONGLONG)seekValue, readLength)) {//, origBufff, count);//sending data
					if (reopenFile(incrementalList[initialPointer].FILENAME) == NULL) {
						printf("reopen failed at %d \n", __LINE__);
						return false;
					}
					if (!sendData(incrementalList[initialPointer].FILENAME, (LONGLONG)seekValue, readLength)) {// , origBufff, count);//sending data
						return false;
					}
				}
				readSatisfied = true;
			}
			else if (upperBound > readOffset) {
				chunkValue = upperBound - readOffset;
				if (!sendData(incrementalList[initialPointer].FILENAME, readOffset, chunkValue))//, origBufff, count);//sending data
				{
					if (reopenFile(incrementalList[initialPointer].FILENAME) == NULL) {
						printf("reopen failed at %d \n", __LINE__);
						return false;
					}					if (!sendData(incrementalList[initialPointer].FILENAME, readOffset, chunkValue)) {// , origBufff, count);//sending data
						return false;
					}
				}
				readLength = readLength - chunkValue;
				readOffset = incrementalList[initialPointer].OFFSET;
				initialPointer++;
			}
		}
	}
	//start reading data linearly until readSatisfied
	while (!readSatisfied) {
		lowerBound = incrementalList[initialPointer].OFFSET;
		upperBound = lowerBound + incrementalList[initialPointer].LENGTH;
		if (lowerBound <= readOffset) {
			if (readOffset < upperBound) {//readOffset is between the lowerBound and upperBound
										  //hence partial or full requested data can be satisfied
				seekValue = incrementalList[initialPointer].SEEKLENGTH;
				LONGLONG toReadOffset = seekValue + (readOffset - lowerBound);
				UINT64 satisfiableLength = 0L;
				if (readLength <= upperBound - readOffset) {
					satisfiableLength = readLength;
				}
				else {
					satisfiableLength = upperBound - readOffset;
				}

				if (!sendData(incrementalList[initialPointer].FILENAME, toReadOffset, satisfiableLength))//, origBufff, count);//sending data
				{
					if (reopenFile(incrementalList[initialPointer].FILENAME) == NULL) {
						printf("reopen failed at %d \n", __LINE__);
						return false;
					}
					if (!sendData(incrementalList[initialPointer].FILENAME, toReadOffset, satisfiableLength)) {// , origBufff, count);//sending data
						return false;
					}
				}
				if (satisfiableLength == readLength) {//partial read check
													  //read fully satisfied
					readSatisfied = true;
					break;
				}
				else {
					//read partially satisfied hence locating remaing data
					readOffset = readOffset + satisfiableLength;
					readLength = readLength - satisfiableLength;
				}
			}
			else {
				if (!sendData(0, readOffset, readLength))//, origBufff, count);//sending data
				{
					if (reopenFile(0) == NULL) {
						printf("reopen failed at %d \n", __LINE__);
						return false;
					}
					if (!sendData(0, readOffset, readLength)) {// , origBufff, count);//sending data
						return false;
					}
				}
				readSatisfied = true;
				initialPointer++;
				break;
			}
			initialPointer++;
			if (initialPointer >= size) {
				if (!sendData(0, readOffset, readLength))//, origBufff, count);//sending data
				{
					if (reopenFile(0) == NULL) {
						printf("reopen failed at %d \n", __LINE__);
						return false;
					}
					if (!sendData(0, readOffset, readLength)) {// , origBufff, count);//sending data
						return false;
					}
				}
				readSatisfied = true;
			}
		}
		else {//read from full backup
			chunkValue = lowerBound - readOffset;
			if (readLength <= chunkValue) {
				if (!sendData(0, readOffset, readLength))//, origBufff, count);
				{
					if (reopenFile(0) == NULL) {
						printf("reopen failed at %d \n", __LINE__);
						return false;
					}
					if (!sendData(0, readOffset, readLength)) {// , origBufff, count);//sending data
						return false;
					}
				}
				readSatisfied = true;
				break;
			}
			else
			{
				if (!sendData(0, readOffset, chunkValue))//, origBufff, count);//sending data
				{
					if (reopenFile(0) == NULL) {
						printf("reopen failed at %d \n", __LINE__);
						return false;
					}
					if (!sendData(0, readOffset, readLength)) {// , origBufff, count);//sending data
						return false;
					}
				}
				readLength = readLength - chunkValue;
				readOffset = lowerBound;
			}
		}
	}
	return true;
}
/*
*
* Event Receiver Client Thread
*
*/
DWORD
RetrieveEventFromKernelMode(
	__in LPVOID ThreadContext
)
/*++

Routine Description

This is a worker thread that


Arguments

Context  - This thread context has a pointer to the port handle we use to send/receive messages,
and a completion port handle that was already associated with the comm. port by the caller

Return Value

HRESULT indicating the status of thread exit.

--*/
{
	PEVENT_THREAD_CONTEXT Context = (PEVENT_THREAD_CONTEXT)ThreadContext;
	PCHANGE_NOTIFICATION notification;
	CHANGE_NOTIFICATION_REPLY_MESSAGE replyMessage;
	PCHANGE_NOTIFICATION_MESSAGE message, msg;
	LPOVERLAPPED pOvlp;
	BOOL result;
	DWORD outSize;
	HRESULT hr;
	ULONG_PTR key;
	LONGLONG readLen, holdVal;
	DWORD processID;
	DWORD nbytesReadTemp;
	ULONG    bytesReturned = 0;
	DATA_BUFFER buf = { 0 };
	clock_t t1, t2;
	__int64 reqdOffset;
	DWORD dwRead;
	bool val;
	processID = GetCurrentProcessId();
	printf("\n-->Entering Thread");
#pragma warning(push)
#pragma warning(disable:4127) // conditional expression is constant

	while (TRUE) {


#pragma warning(pop)

		message = NULL;
		if (evtReceiverContext.CleaningUp) {

			break;
		}
		msg = (PCHANGE_NOTIFICATION_MESSAGE)malloc(sizeof(CHANGE_NOTIFICATION_MESSAGE));

		if (msg == NULL) {

			hr = ERROR_NOT_ENOUGH_MEMORY;
			break;
		}


		memset(&msg->Ovlp, 0, sizeof(OVERLAPPED));

		//
		//  Request messages from the filter driver.
		//


		hr = FilterGetMessage(evtReceiverContext.Port,
			&msg->MessageHeader,
			sizeof(CHANGE_NOTIFICATION_MESSAGE),
			//                                   FIELD_OFFSET( CHANGE_NOTIFICATION_MESSAGE, Ovlp ),
			&msg->Ovlp);



		if (hr != HRESULT_FROM_WIN32(ERROR_IO_PENDING)) {
			printf("\n-->Break 1");
			free(msg);
			break;
		}

		//
		//  Poll for messages from the filter component to scan.
		//

		result = GetQueuedCompletionStatus(evtReceiverContext.Completion, &outSize, &key, &pOvlp, INFINITE);

		//
		//  Obtain the message: note that the message we sent down via FltGetMessage() may NOT be
		//  the one dequeued off the completion queue: this is solely because there are multiple
		//  threads per single port handle. Any of the FilterGetMessage() issued messages can be
		//  completed in random order - and we will just dequeue a random one.


		if (!result) {

			//
			//  An error occured.
			//
			printf("errocode : %d", (int)GetLastError());
			printf("\n-->Break 2 [%d][%d][%d][%d]", outSize, sizeof(CHANGE_NOTIFICATION_MESSAGE), sizeof(CHANGE_NOTIFICATION), sizeof(OVERLAPPED));
			hr = HRESULT_FROM_WIN32(GetLastError());
			break;
		}

		message = CONTAINING_RECORD(pOvlp, CHANGE_NOTIFICATION_MESSAGE, Ovlp);
		notification = &message->Notification;
		readLen = notification->hvWriteLength;


		if (processID != (DWORD)notification->ProcessId)
		{
			if (wcsstr(notification->OldFileName, L".rmp_IR") != NULL)
			{


				bool readSatisfied = true;
				string sparseFileName_string = sparseFileName;
				wstring wsparseFileName_string(sparseFileName_string.begin(), sparseFileName_string.end());
				wstring oldName = notification->OldFileName;
				if (oldName.find(wsparseFileName_string) != string::npos)
				{


					reqdOffset = notification->hvByteOffsetQuadPart;
					buf.count = 0;
					while (readLen > 0)
					{


						if (readLen > 65536)
						{
							holdVal = 65536;
							buf.movePtr = 1;
						}
						else
						{
							holdVal = readLen;
							buf.movePtr = 0;
						}
						t1 = clock();


						strcpy((char *)dataTemp, "");
						dataTempLength = 0;
						readSatisfied = readSatisfier(reqdOffset, holdVal, pointer, incListCount);
						finalSendData(reqdOffset, holdVal, notification->origBufTemp, buf.count);
						if (!readSatisfied) {
							hr = ERROR_BAD_COMPRESSION_BUFFER;
							printf("read could not be satisfied. Exiting client\n");
							break;
						}


						t2 = clock();
						long timediff = ((long)t2 - (long)t1);
						long seconds = timediff;

						readLen -= holdVal;
						buf.count++;
						reqdOffset += holdVal;
					}
					if (!readSatisfied) {


						break;
					}
				}
			}
			else if (wcsstr(notification->OldFileName, L".rmp_BMR") != NULL)
			{
				int len = 0;
				string bmrFile = compressedFile;
				size_t pos = bmrFile.rfind("\\");
				bmrFile = bmrFile.substr(pos);
				pos = bmrFile.rfind(".");
				bmrFile = bmrFile.substr(0, pos);
				wstring bmrFileW(bmrFile.begin(), bmrFile.end());
				bmrFileW += L".rmp_BMR";
				wstring oldName = notification->OldFileName;
				if (oldName.find(bmrFileW) != string::npos) {
					reqdOffset = notification->hvByteOffsetQuadPart;
					buf.count = 0;
					while (readLen > 0) {
						if (readLen > 65536) {
							holdVal = 65536;
							buf.movePtr = 1;
						}
						else {
							holdVal = readLen;
							buf.movePtr = 0;
						}
						t1 = clock();

						if (isBMREncrypted) {
							len = extractDecrypt(in, index, reqdOffset, buf.data, holdVal, &BMRsecretKeyW[0]);
						}
						else {
							len = extract(in, index, reqdOffset, buf.data, holdVal);
						}

						t2 = clock();
						long timediff = ((long)t2 - (long)t1);
						long seconds = timediff;
						if (len < 0)
							fprintf(stderr, "zran: extraction failed: %s error\n",
								len == Z_MEM_ERROR ? "out of memory" : "input corrupted");
						else {
							fprintf(stderr, "zran: extracted %d bytes at %llu\n", len, reqdOffset);
						}

						buf.bufSize = (ULONG)holdVal;

						buf.origBufTemp = notification->origBufTemp;

						hr = FilterSendMessage(evtReceiverContext.Port,
							&buf,
							sizeof(DATA_BUFFER),
							NULL,
							0,
							&bytesReturned);
						if (!SUCCEEDED(hr)) {
							printf("FilterSendMsg: 0x%08x\n", hr);
						}
						readLen -= holdVal;
						buf.count++;
						reqdOffset += holdVal;
					}
				}
			}
			else if (wcsstr(notification->OldFileName, L".rmp_VMWARE") != NULL)
			{
				string bmrFile = compressedFile;
				size_t pos = bmrFile.rfind("\\");
				bmrFile = bmrFile.substr(pos);
				pos = bmrFile.rfind(".");
				bmrFile = bmrFile.substr(0, pos);
				wstring bmrFileW(bmrFile.begin(), bmrFile.end());
				bmrFileW += L".rmp_VMWARE";
				wstring oldName = notification->OldFileName;
				if (oldName.find(bmrFileW) != string::npos) {
					reqdOffset = notification->hvByteOffsetQuadPart;
					buf.count = 0;
					while (readLen > 0) {
						if (readLen > 65536) {
							holdVal = 65536;
							buf.movePtr = 1;
						}
						else {
							holdVal = readLen;
							buf.movePtr = 0;
						}
						t1 = clock();

						strcpy((char *)dataTemp, "");
						dataTempLength = 0;
						readSatisfier(reqdOffset, holdVal, pointer, incListCount);
						finalSendData(reqdOffset, holdVal, notification->origBufTemp, buf.count);

						t2 = clock();
						long timediff = ((long)t2 - (long)t1);
						long seconds = timediff;

						readLen -= holdVal;
						buf.count++;
						reqdOffset += holdVal;
					}
				}
			}
			else if (wcsstr(notification->OldFileName, L"temp\\wsm_rmp_hv") != NULL)
			{
				string bmrFile = compressedFile;
				size_t pos = bmrFile.rfind("\\");
				bmrFile = bmrFile.substr(pos);
				wstring bmrFileW(bmrFile.begin(), bmrFile.end());
				wstring oldName = notification->OldFileName;
				if (oldName.find(bmrFileW) != string::npos) {
					reqdOffset = notification->hvByteOffsetQuadPart;
					buf.count = 0;
					while (readLen > 0) {
						if (readLen > 65536) {
							holdVal = 65536;
							buf.movePtr = 1;
						}
						else {
							holdVal = readLen;
							buf.movePtr = 0;
						}
						t1 = clock();

						strcpy((char *)dataTemp, "");
						dataTempLength = 0;
						readSatisfier(reqdOffset, holdVal, pointer, incListCount);
						finalSendData(reqdOffset, holdVal, notification->origBufTemp, buf.count);

						t2 = clock();
						long timediff = ((long)t2 - (long)t1);
						long seconds = timediff;

						readLen -= holdVal;
						buf.count++;
						reqdOffset += holdVal;
					}
				}
			}
			else {
				printf("Request not for BMR/VMWARE module\n");
			}
		}


		replyMessage.ReplyHeader.Status = 0;
		replyMessage.ReplyHeader.MessageId = message->MessageHeader.MessageId;

		replyMessage.replyStruct.Reply = 3;
		replyMessage.replyStruct.replyBuffer = (char *)malloc(10);
		strcpy(replyMessage.replyStruct.replyBuffer, "hello");
		hr = FilterReplyMessage(evtReceiverContext.Port,
			(PFILTER_REPLY_HEADER)&replyMessage,
			sizeof(replyMessage));


		if (!SUCCEEDED(hr)) {

			printf("Scanner: Error replying message. Error = 0x%X\n", hr);
			break;
		}


		if (message != NULL)
		{
			free(message);
			message = NULL;
		}
	}


	if (!SUCCEEDED(hr)) {


		if (hr == HRESULT_FROM_WIN32(ERROR_INVALID_HANDLE)) {

			//
			//  Scanner port disconncted.
			//


			printf("Scanner: Port is disconnected, probably due to scanner filter unloading.\n");

		}
		else {


			printf("Scanner: Unknown error occured. Error = 0x%X\n", hr);
		}
	}
	if (message != NULL)
	{
		free(message);
		message = NULL;
	}
	printf("Thread Exit\n");
	return hr;
}

VOID _cdecl shutdownClientThreads(VOID)
{
	evtReceiverContext.CleaningUp = TRUE;
	printf("ShutDown Invoked\n");

	if (INVALID_HANDLE_VALUE != evtReceiverContext.Port) {
		CloseHandle(evtReceiverContext.Port);
	}

	if (evtReceiverContext.Completion) {
		CloseHandle(evtReceiverContext.Completion); // Check for Failure case
	}

}
