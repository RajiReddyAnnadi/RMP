/*++

Module Name:

    RegistrationData.c

Abstract:

    This filters registration information.  Note that this is in a unique file
    so it could be set into the INIT section.

Environment:

    Kernel mode

--*/

#include "RMPFileMounterKern.h"



//
//  Tells the compiler to define all following DATA and CONSTANT DATA to
//  be placed in the INIT segment.
//

#ifdef ALLOC_DATA_PRAGMA
    #pragma data_seg("INIT")
    #pragma const_seg("INIT")
#endif


//---------------------------------------------------------------------------
//  Registration information for FLTMGR.
//---------------------------------------------------------------------------

CONST FLT_OPERATION_REGISTRATION Callbacks[] = {   

	{ IRP_MJ_READ,
      0,
	  RMPFileMounterPreOperationCallback,
	  RMPFileMounterPostOperationCallback },

    { IRP_MJ_QUERY_INFORMATION,
        0,
        RMPFileMounterPreOperationCallback,
        RMPFileMounterPostOperationCallback },

	{ IRP_MJ_MDL_READ,
	  0,
	  RMPFileMounterPreOperationCallback,
	  NULL },
    { IRP_MJ_OPERATION_END }
};

const FLT_CONTEXT_REGISTRATION Contexts[] = {

    { FLT_INSTANCE_CONTEXT,
      0,
      RMPFileMounterInstanceContextCleanupCallback,
      sizeof(RMPFileMounter_INSTANCE_CONTEXT),
      RMPFileMounter_INSTANCE_CONTEXT_POOL_TAG,
      NULL,
      NULL,
      NULL },

    { FLT_STREAMHANDLE_CONTEXT,
      0,
      RMPFileMounterStreamHandleContextCleanupCallback,
      sizeof(RMPFileMounter_STREAMHANDLE_CONTEXT),
      RMPFileMounter_STREAMHANDLE_CONTEXT_POOL_TAG,
      NULL,
      NULL,
      NULL },

	{ FLT_STREAM_CONTEXT,
      0,
      RMPFileMounterStreamHandleContextCleanupCallback,
      sizeof(RMPFileMounter_STREAMHANDLE_CONTEXT),
      RMPFileMounter_STREAM_CONTEXT_POOL_TAG,
      NULL,
      NULL,
      NULL },

    { FLT_CONTEXT_END }
	
};

//
//  This defines what we want to filter with FltMgr
//

CONST FLT_REGISTRATION FilterRegistration = {

    sizeof(FLT_REGISTRATION),               //  Size
    FLT_REGISTRATION_VERSION,               //  Version
    0,                                      //  Flags

    Contexts,                               //  Context
    Callbacks,                              //  Operation callbacks

	RMPFileMounterFilterUnload,                        //  FilterUnload

    VolumeInstanceSetupCallback,            //  InstanceSetupCallback()
	RMPFileMounterQueryTeardown,                       //  InstanceQueryTeardown
    NULL,                                   //  InstanceTeardownStart
    NULL,                                   //  InstanceTeardownComplete

    NULL,                                   //  GenerateFileName
    NULL,                                   //  GenerateDestinationFileName
    NULL                                    //  NormalizeNameComponent

#if OS_VERSION_GREATER_THAN_VISTA

    ,
    NULL,
    NULL,            			    //  KTM notification callback

#endif 

};


//
//  Tells the compiler to restore the given section types back to their previous
//  section definition.
//

#ifdef ALLOC_DATA_PRAGMA
    #pragma data_seg()
    #pragma const_seg()
#endif

