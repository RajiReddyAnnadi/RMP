/*++

Module Name:

RMPFileMounter.c

Abstract:

This is the main module for the RMPFileMounter mini-filter.

Environment:

Kernel mode

--*/

#include "RMPFileMounterKern.h"
#include <stdio.h>
#define MILLISECOND 10000             // 100 nanosecs * 10,000 = 1 ms
#define RELATIVE_MILLISECOND (-MILLISECOND)     // minus means relative time
#define BUFFER_SIZE 4096
//
//  Global variables
//


RMPFileMounter_DATA RMPFileMounterData;

//---------------------------------------------------------------------------
//  Function prototypes
//---------------------------------------------------------------------------
DRIVER_INITIALIZE DriverEntry;

NTSTATUS
DriverEntry(
__in PDRIVER_OBJECT DriverObject,
__in PUNICODE_STRING RegistryPath
);

NTSTATUS
RMPFileMounterMessage(
__in PVOID ConnectionCookie,
__in_bcount_opt(InputBufferSize) PVOID InputBuffer,
__in ULONG InputBufferSize,
__out_bcount_part_opt(OutputBufferSize, *ReturnOutputBufferLength) PVOID OutputBuffer,
__in ULONG OutputBufferSize,
__out PULONG ReturnOutputBufferLength
);

NTSTATUS
RMPFileMounterConnect(
__in PFLT_PORT ClientPort,
__in PVOID ServerPortCookie,
__in_bcount(SizeOfContext) PVOID ConnectionContext,
__in ULONG SizeOfContext,
__deref_out_opt PVOID *ConnectionCookie
);

VOID
RMPFileMounterDisconnect(
__in_opt PVOID ConnectionCookie
);

//---------------------------------------------------------------------------//
//  Assign text sections for each routine.				     //
//---------------------------------------------------------------------------//

#ifdef ALLOC_PRAGMA
#pragma alloc_text(INIT, DriverEntry)
#pragma alloc_text(PAGE, RMPFileMounterFilterUnload)
#pragma alloc_text(PAGE, RMPFileMounterQueryTeardown)
#pragma alloc_text(PAGE, RMPFileMounterConnect)
#pragma alloc_text(PAGE, RMPFileMounterDisconnect)
#pragma alloc_text(PAGE, RMPFileMounterMessage)
#endif

//---------------------------------------------------------------------------//
//                      ROUTINES					     //
//---------------------------------------------------------------------------//

NTSTATUS
DriverEntry(
__in PDRIVER_OBJECT DriverObject,
__in PUNICODE_STRING RegistryPath
)
/*++

Routine Description:

This routine is called when a driver first loads.  Its purpose is to
initialize global state and then register with FltMgr to start filtering.

Arguments:

DriverObject - Pointer to driver object created by the system to
represent this driver.
RegistryPath - Unicode string identifying where the parameters for this
driver are located in the registry.

Return Value:

Status of the operation.

--*/
{
	PSECURITY_DESCRIPTOR sd;
	OBJECT_ATTRIBUTES oa;
	UNICODE_STRING uniString, uni1;
	NTSTATUS status = STATUS_SUCCESS;
	PFLT_VOLUME vol;
	try {

		//
		// Initialize global data structures.
		//
		DbgPrint("In Driverentry\n");
		portCnt = 0;
		RMPFileMounterData.DriverObject = DriverObject;

		//
		//  Now that our global configuration is complete, register with FltMgr.
		//

		status = FltRegisterFilter(DriverObject,
			&FilterRegistration,
			&RMPFileMounterData.Filter);

		if (!NT_SUCCESS(status)) {

			return status;
		}
		DbgPrint("After register filter\n");

		status = FltBuildDefaultSecurityDescriptor(&sd,
			FLT_PORT_ALL_ACCESS);

		if (!NT_SUCCESS(status)) {
			return status;
		}

		RtlInitUnicodeString(&uniString, RMP_PORT_NAME);

		InitializeObjectAttributes(&oa,
			&uniString,
			OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE,
			NULL,
			sd);

		status = FltCreateCommunicationPort(RMPFileMounterData.Filter,
			&RMPFileMounterData.ServerPort,
			&oa,
			NULL,
			(PFLT_CONNECT_NOTIFY)RMPFileMounterConnect,
			(PFLT_DISCONNECT_NOTIFY)RMPFileMounterDisconnect,
			(PFLT_MESSAGE_NOTIFY)RMPFileMounterMessage,
			15);  //Hardcoded maxconnections to 15

		FltFreeSecurityDescriptor(sd);

		if (!NT_SUCCESS(status)) {
			return status;
		}

		//
		//  We are now ready to start filtering
		//

		status = FltStartFiltering(RMPFileMounterData.Filter);
		DbgPrint("After start filtering\n");
	}
	finally {
		if (!NT_SUCCESS(status)) {
			if (NULL != RMPFileMounterData.ServerPort) {
				FltCloseCommunicationPort(RMPFileMounterData.ServerPort);
			}

			if (NULL != RMPFileMounterData.Filter) {
				FltUnregisterFilter(RMPFileMounterData.Filter);
			}
		}
	}

	return status;
}

NTSTATUS
RMPFileMounterConnect(
__in PFLT_PORT ClientPort,
__in PVOID ServerPortCookie,
__in_bcount(SizeOfContext) PVOID ConnectionContext,
__in ULONG SizeOfContext,
__deref_out_opt PVOID *ConnectionCookie
)
/*++

Routine Description

This is called when user-mode connects to the server
port - to establish a connection

Arguments

ClientPort - This is the pointer to the client port that
will be used to send messages from the filter.
ServerPortCookie - unused
ConnectionContext - unused
SizeofContext   - unused
ConnectionCookie - unused

Return Value

STATUS_SUCCESS - to accept the connection
--*/
{

	PAGED_CODE();

	UNREFERENCED_PARAMETER(ServerPortCookie);
	UNREFERENCED_PARAMETER(ConnectionContext);
	UNREFERENCED_PARAMETER(SizeOfContext);
	UNREFERENCED_PARAMETER(ConnectionCookie);

	//ASSERT(RMPFileMounterData.ClientPort == NULL);
	RMPFileMounterData.ClientPortArray[portCnt++] = ClientPort;
	return STATUS_SUCCESS;
}


VOID
RMPFileMounterDisconnect(
__in_opt PVOID ConnectionCookie
)
/*++

Routine Description

This is called when the connection is torn-down. We use it to close our handle to the connection

Arguments

ConnectionCookie - unused

Return value

None
--*/
{

	PAGED_CODE();

	UNREFERENCED_PARAMETER(ConnectionCookie);

	//
	//  Close our handle
	//
	for (int loop = 0; loop < portCnt; loop++){
		//FltCloseClientPort(RMPFileMounterData.Filter, &RMPFileMounterData.ClientPortArray[loop]);
	}
}

NTSTATUS
RMPFileMounterFilterUnload(
__in FLT_FILTER_UNLOAD_FLAGS Flags
)
/*++

Routine Description:

This is called when a request has been made to unload the filter.  Unload
requests from the Operation System (ex: "sc stop minispy" can not be
failed.  Other unload requests may be failed.

You can disallow OS unload request by setting the
FLTREGFL_DO_NOT_SUPPORT_SERVICE_STOP flag in the FLT_REGISTARTION
structure.

Arguments:

Flags - Flags pertinent to this operation


Return Value:

Always success

--*/
{
	UNREFERENCED_PARAMETER(Flags);

	PAGED_CODE();

	//
	//  Close the server port. This will stop new connections.
	//
	for (int loop = 0; loop < portCnt; loop++){
		FltCloseClientPort(RMPFileMounterData.Filter, &RMPFileMounterData.ClientPortArray[loop]);
	}
	FltCloseCommunicationPort(RMPFileMounterData.ServerPort);
	FltUnregisterFilter(RMPFileMounterData.Filter);

	return STATUS_SUCCESS;
}


NTSTATUS
RMPFileMounterQueryTeardown(
__in PCFLT_RELATED_OBJECTS FltObjects,
__in FLT_INSTANCE_QUERY_TEARDOWN_FLAGS Flags
)
/*++

Routine Description:

This allows our filter to be manually detached from a volume.

Arguments:

FltObjects - Contains pointer to relevant objects for this operation.
Note that the FileObject field will always be NULL.

Flags - Flags pertinent to this operation

Return Value:

--*/
{
	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(Flags);
	PAGED_CODE();
	return STATUS_SUCCESS;
}


NTSTATUS
RMPFileMounterMessage(
__in PVOID ConnectionCookie,
__in_bcount_opt(InputBufferSize) PVOID InputBuffer,
__in ULONG InputBufferSize,
__out_bcount_part_opt(OutputBufferSize, *ReturnOutputBufferLength) PVOID OutputBuffer,
__in ULONG OutputBufferSize,
__out PULONG ReturnOutputBufferLength
)
/*++

Routine Description:

This is called whenever a user mode application wishes to communicate
with this minifilter.

Arguments:

ConnectionCookie - unused

OperationCode - An identifier describing what type of message this
is.  These codes are defined by the MiniFilter.
InputBuffer - A buffer containing input data, can be NULL if there
is no input data.
InputBufferSize - The size in bytes of the InputBuffer.
OutputBuffer - A buffer provided by the application that originated
the communication in which to store data to be returned to this
application.
OutputBufferSize - The size in bytes of the OutputBuffer.
ReturnOutputBufferSize - The size in bytes of meaningful data
returned in the OutputBuffer.

Return Value:

Returns the status of processing the message.

--*/
{

	LARGE_INTEGER timeout;

	timeout.QuadPart = RELATIVE_MILLISECOND;
	timeout.QuadPart *= 1000;
	DbgPrint("Received data %s %ld %d", ((PDATA_BUFFER)InputBuffer)->data, ((PDATA_BUFFER)InputBuffer)->bufSize, ((PDATA_BUFFER)InputBuffer)->movePtr);
	PVOID origBufInMsg = ((PDATA_BUFFER)InputBuffer)->origBufTemp;
	//DbgPrint("name in int ->%d<->%s", ((PDATA_BUFFER)InputBuffer)->count, origBufInMsg);
	if (MmIsAddressValid(origBufInMsg)){
	(unsigned char *)origBufInMsg += (((PDATA_BUFFER)InputBuffer)->count * 65536);

	try{
		RtlCopyMemory(origBufInMsg, ((PDATA_BUFFER)InputBuffer)->data, ((PDATA_BUFFER)InputBuffer)->bufSize);
		DbgPrint("after copy");
	}except(EXCEPTION_EXECUTE_HANDLER){
		DbgPrint("\n RtlCopyMemory exception caught");
	}
	}
	else{
		DbgPrint("MmIsAddressValid failed\n");
	}
	return STATUS_SUCCESS;
}


//---------------------------------------------------------------------------//
//              Operation filtering routines				     //
//---------------------------------------------------------------------------//


FLT_PREOP_CALLBACK_STATUS
RMPFileMounterPreOperationCallback(
__inout PFLT_CALLBACK_DATA Data,
__in PCFLT_RELATED_OBJECTS FltObjects,
__deref_out_opt PVOID *CompletionContext
)
/*++

Routine Description:

This routine receives ALL pre-operation callbacks for this filter.  It then
tries to log information about the given operation.  If we are able
to log information then we will call our post-operation callback  routine.

NOTE:  This routine must be NON-PAGED because it can be called on the
paging path.

Arguments:

Data - Contains information about the given operation.

FltObjects - Contains pointers to the various objects that are pertinent
to this operation.

CompletionContext - This receives the address of our log buffer for this
operation.  Our completion routine then receives this buffer address.

Return Value:

Identifies how processing should continue for this operation

--*/
{
	FLT_PREOP_CALLBACK_STATUS returnStatus = FLT_PREOP_SUCCESS_WITH_CALLBACK; //assume we are NOT going to call our completion routine
	NTSTATUS status;
	PCHANGE_NOTIFICATION notification = NULL;

	//	if (Data->Iopb->TargetFileObject->FileName.Buffer != NULL && wcsstr(Data->Iopb->TargetFileObject->FileName.Buffer, L".rmp_BMR") != NULL)
	//	{
	//		if (FlagOn(Data->Flags, FLTFL_CALLBACK_DATA_FAST_IO_OPERATION)) {
	//			DbgPrint("\n*****Returning FLT_PREOP_DISALLOW_FASTIO from RMPFileMounterPreOperationCallback****");
	//			return FLT_PREOP_DISALLOW_FASTIO;
	//		}
	//	}
	//	else
	//	{
	//		DbgPrint("\n Returning with FLT_PREOP_SUCCESS_NO_CALLBACK");
	//		return FLT_PREOP_SUCCESS_NO_CALLBACK;
	//	}

	*CompletionContext = NULL;

	// Allocate Memory for Event Notification Message
	notification = (PCHANGE_NOTIFICATION)ExAllocatePoolWithTag(NonPagedPool, sizeof(CHANGE_NOTIFICATION), RMPFileMounter_PREOP_DATA_POOL_TAG);

	if (notification == NULL)
	{
		DbgPrint("\n!!! Notification Memory allocated failed RMPFileMounter");
		return FLT_PREOP_SUCCESS_NO_CALLBACK; // Do not call Post callback
	}
	DbgPrint("Kernel QuadPart in Preoperation %lld\n", Data->Iopb->Parameters.Read.ByteOffset.QuadPart);
	InitEventNotification(Data, FltObjects, notification);
	RMPFileMounterSetFileNameFromPreOpData(Data, FltObjects, notification);

	//changed
	if (notification->OldFileName != NULL)
	{
		try{
			DbgPrint("delay file name : %ws", notification->OldFileName);
			if ((wcsstr(notification->OldFileName, L".rmp_IR") != NULL) || (wcsstr(notification->OldFileName, L".rmp_BMR") != NULL) || ((wcsstr(notification->OldFileName, L".rmp_VMWARE") != NULL)) || ((wcsstr(notification->OldFileName, L"temp\\wsm_rmp_hv\\") != NULL))){
				if (FlagOn(Data->Flags, FLTFL_CALLBACK_DATA_FAST_IO_OPERATION)) {
					DbgPrint("\n*****Returning FLT_PREOP_DISALLOW_FASTIO from RMPFileMounterPreOperationCallback****");
					returnStatus = FLT_PREOP_DISALLOW_FASTIO;
				}
			}
			else{
				DbgPrint("%ws", notification->OldFileName);
				DbgPrint("\n Returning with FLT_PREOP_SUCCESS_NO_CALLBACK");
				returnStatus = FLT_PREOP_SUCCESS_NO_CALLBACK;
			}
		} except(EXCEPTION_EXECUTE_HANDLER){
			DbgPrint("\n exception caught");
			returnStatus = FLT_PREOP_SUCCESS_NO_CALLBACK;
		}

	}
	else
	{
		DbgPrint("\n Returning with FLT_PREOP_SUCCESS_NO_CALLBACK");
		returnStatus = FLT_PREOP_SUCCESS_NO_CALLBACK;
	}
	//changed
	if (returnStatus == FLT_PREOP_SUCCESS_NO_CALLBACK || returnStatus == FLT_PREOP_DISALLOW_FASTIO)
	{
		if (notification != NULL)
		{
			ExFreePoolWithTag(notification, RMPFileMounter_PREOP_DATA_POOL_TAG);
		}
	}
	else
	{
		*CompletionContext = notification;
	}
	//    DbgPrint("Pre END -> PID = [%d] IRQL = [%d], ThreadID = [%d]",PsGetCurrentProcessId(), KeGetCurrentIrql(), PsGetCurrentThreadId());
	return returnStatus;
}


FLT_POSTOP_CALLBACK_STATUS
SafePostCallback(
_Inout_ PFLT_CALLBACK_DATA Data,
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_ PVOID CompletionContext,
_In_ FLT_POST_OPERATION_FLAGS Flags
)
{
	PVOID origBuf = NULL;
	PFLT_IO_PARAMETER_BLOCK iopb = Data->Iopb;
	NTSTATUS status;
	PMDL newmdl = NULL;

	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(Flags);
	FLT_ASSERT(Data->IoStatus.Information != 0);
	PCHANGE_NOTIFICATION notification = NULL;
	notification = (PCHANGE_NOTIFICATION)CompletionContext;
	notification->hvWriteLength = Data->Iopb->Parameters.Read.Length;
	notification->hvByteOffsetHighPart = Data->Iopb->Parameters.Read.ByteOffset.HighPart;
	notification->hvByteOffsetLowPart = Data->Iopb->Parameters.Read.ByteOffset.LowPart;
	notification->hvByteOffsetQuadPart = Data->Iopb->Parameters.Read.ByteOffset.QuadPart;
	DbgPrint("Kernel QuadPart %lld\n", notification->hvByteOffsetQuadPart);
	DbgPrint("Kernel QuadPart %ws\n", notification->OldFileName);
	DbgPrint("Read len %ld\n", Data->Iopb->Parameters.Read.Length);
	//
	//  This is some sort of user buffer without a MDL, lock the user buffer
	//  so we can access it.  This will create a MDL for it.
	//

	if (Data->Iopb->Parameters.Read.ReadBuffer == NULL)
	{
		DbgPrint("Readbuffer null\n");
		DbgPrint("##########################################################\n");
	}

	if (notification->OldFileName != NULL)
	{
		if ((wcsstr(notification->OldFileName, L".rmp_IR") != NULL) || (wcsstr(notification->OldFileName, L"rmp_BMR") != NULL)){
			newmdl = IoAllocateMdl(Data->Iopb->Parameters.Read.ReadBuffer, Data->Iopb->Parameters.Read.Length, FALSE, FALSE, NULL);

			if (newmdl == NULL){
				DbgPrint("newMdl null\n");
				Data->IoStatus.Status = STATUS_INSUFFICIENT_RESOURCES;
				Data->IoStatus.Information = 0;
				return FLT_POSTOP_FINISHED_PROCESSING;
			}

			MmBuildMdlForNonPagedPool(newmdl);
			origBuf = MmGetSystemAddressForMdlSafe(newmdl, NormalPagePriority | MdlMappingNoExecute);
		}
		else if ((wcsstr(notification->OldFileName, L".rmp_VMWARE") != NULL) || ((wcsstr(notification->OldFileName, L"temp\\wsm_rmp_hv\\") != NULL))){
			Data->Iopb->Parameters.Read.MdlAddress = IoAllocateMdl(Data->Iopb->Parameters.Read.ReadBuffer, Data->Iopb->Parameters.Read.Length, FALSE, FALSE, NULL);

			if (Data->Iopb->Parameters.Read.MdlAddress == NULL){
				DbgPrint("MdlAddress null\n");
				Data->IoStatus.Status = STATUS_INSUFFICIENT_RESOURCES;
				Data->IoStatus.Information = 0;
				return FLT_POSTOP_FINISHED_PROCESSING;
			}
			try
			{
				//
				// Probe and lock the pages of this buffer in physical memory.
				// You can specify IoReadAccess, IoWriteAccess or IoModifyAccess
				// Always perform this operation in a try except block. 
				//  MmProbeAndLockPages will raise an exception if it fails.
				//
				if (Data->Iopb->Parameters.Read.MdlAddress){
					MmProbeAndLockPages(Data->Iopb->Parameters.Read.MdlAddress, Data->RequestorMode, IoReadAccess);
				}
				else{
					DbgPrint("In else\n");
				}
			}
			except(EXCEPTION_EXECUTE_HANDLER)
			{
				DbgPrint("in mmprobe catch\n");
				Data->IoStatus.Status = GetExceptionCode();
				Data->IoStatus.Information = 0;
				return FLT_POSTOP_FINISHED_PROCESSING;
			}
			origBuf = MmGetSystemAddressForMdlSafe(Data->Iopb->Parameters.Read.MdlAddress, NormalPagePriority | MdlMappingNoExecute);
		}
	}

	if (origBuf == NULL) {

		DbgPrint("Get system address failed\n");
		Data->IoStatus.Status = STATUS_INSUFFICIENT_RESOURCES;
		Data->IoStatus.Information = 0;
	}
	else {		
		notification->origBufTemp = origBuf;
		SendPostOperationData(Data, notification);
		DbgPrint("After SendPostOperationData");
	}
	if (notification != NULL)
	{
		if (notification->Context != NULL)
		{
			FltReleaseContext(notification->Context);
		}
		ExFreePoolWithTag(notification, RMPFileMounter_PREOP_DATA_POOL_TAG);
	}
        if (newmdl){
		IoFreeMdl(newmdl);
	}
	return FLT_POSTOP_FINISHED_PROCESSING;
}

FLT_POSTOP_CALLBACK_STATUS
SafePostCallbackNew(
_Inout_ PFLT_CALLBACK_DATA Data,
_In_ PCFLT_RELATED_OBJECTS FltObjects,
_In_ PVOID CompletionContext,
_In_ FLT_POST_OPERATION_FLAGS Flags
)
{

	PVOID origBuf;
	PFLT_IO_PARAMETER_BLOCK iopb = Data->Iopb;
	NTSTATUS status;

	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(Flags);
	FLT_ASSERT(Data->IoStatus.Information != 0);
	PCHANGE_NOTIFICATION notification = NULL;
	notification = (PCHANGE_NOTIFICATION)CompletionContext;
	notification->hvWriteLength = Data->Iopb->Parameters.Read.Length;
	notification->hvByteOffsetHighPart = Data->Iopb->Parameters.Read.ByteOffset.HighPart;
	notification->hvByteOffsetLowPart = Data->Iopb->Parameters.Read.ByteOffset.LowPart;
	notification->hvByteOffsetQuadPart = Data->Iopb->Parameters.Read.ByteOffset.QuadPart;
	DbgPrint("Kernel QuadPart %lld", notification->hvByteOffsetQuadPart);
	DbgPrint("Kernel QuadPart %ws", notification->OldFileName);
	DbgPrint("B4 case 1 timeout\n");
	//
	//  This is some sort of user buffer without a MDL, lock the user buffer
	//  so we can access it.  This will create a MDL for it.
	//



	//
	//  Get a system address for this buffer.
	//

	origBuf = MmGetSystemAddressForMdlSafe(iopb->Parameters.Read.MdlAddress,
		NormalPagePriority | MdlMappingNoExecute);

	if (origBuf == NULL) {

		DbgPrint("Get system address failed\n");
		Data->IoStatus.Status = STATUS_INSUFFICIENT_RESOURCES;
		Data->IoStatus.Information = 0;
	}
	else {
		notification->origBufTemp = origBuf;
		SendPostOperationData(Data, notification);
		DbgPrint("After timeout");

	}
	if (notification != NULL)
	{
		if (notification->Context != NULL)
		{
			FltReleaseContext(notification->Context);
		}
		ExFreePoolWithTag(notification, RMPFileMounter_PREOP_DATA_POOL_TAG);
	}
	return FLT_POSTOP_FINISHED_PROCESSING;
}



FLT_POSTOP_CALLBACK_STATUS
RMPFileMounterPostOperationCallback(
__inout PFLT_CALLBACK_DATA Data,
__in PCFLT_RELATED_OBJECTS FltObjects,
__in PVOID CompletionContext,
__in FLT_POST_OPERATION_FLAGS Flags
)
/*++

Routine Description:

This routine receives ALL post-operation callbacks.  This will take
the log record passed in the context parameter and update it with
the completion information.  It will then insert it on a list to be
sent to the usermode component.

NOTE:  This routine must be NON-PAGED because it can be called at DPC level

Arguments:

Data - Contains information about the given operation.

FltObjects - Contains pointers to the various objects that are pertinent
to this operation.

CompletionContext - Pointer to the RECORD_LIST structure in which we
store the information we are logging.  This was passed from the
pre-operation callback

Flags - Contains information as to why this routine was called.

Return Value:

Identifies how processing should continue for this operation

--*/
{
	DbgPrint("In Postcallback\n");
	BOOLEAN bRet;
	BOOLEAN cleanupAllocatedBuffer = TRUE;
	PCHANGE_NOTIFICATION notification = NULL;
	notification = (PCHANGE_NOTIFICATION)CompletionContext;
	FLT_POSTOP_CALLBACK_STATUS retValue = FLT_POSTOP_FINISHED_PROCESSING;
	if (KeGetCurrentIrql() <= DISPATCH_LEVEL)
	{
		if (Data->Iopb->MajorFunction == IRP_MJ_READ)
		{
			DbgPrint("Oldname %ws\n", notification->OldFileName);
			if ((wcsstr(notification->OldFileName, L".rmp_IR") != NULL) ||(wcsstr(notification->OldFileName, L".rmp_BMR") != NULL) || ((wcsstr(notification->OldFileName, L".rmp_VMWARE") != NULL)) || ((wcsstr(notification->OldFileName, L"temp\\wsm_rmp_hv\\") != NULL)))
			{
				try
				{
					DbgPrint("File name %wZ\n", Data->Iopb->TargetFileObject->FileName);
					DbgPrint("Read length %d\n", Data->Iopb->Parameters.Read.Length);
					DbgPrint("Offset %lld\n", Data->Iopb->Parameters.Read.ByteOffset.QuadPart);

					if (FlagOn(Flags, FLTFL_POST_OPERATION_DRAINING))
					{
						DbgPrint("Draining bit set.");
						goto PostOperationCallbackExit;
					}

					bRet = FLT_IS_IRP_OPERATION(Data);
					if (FALSE == bRet)
					{
						DbgPrint("NOT IRP based...");
						goto PostOperationCallbackExit;
					}

					if (FlagOn(Data->Iopb->IrpFlags, IRP_PAGING_IO))
					{
						DbgPrint("Paging IO...");
						goto PostOperationCallbackExit;
					}

					if (Data->Iopb->Parameters.Read.MdlAddress != NULL) {
						DbgPrint("In case 1\n");
						bRet = FltDoCompletionProcessingWhenSafe(Data,
							FltObjects,
							notification,
							Flags,
							SafePostCallbackNew,
							&retValue);
						DbgPrint("After FltDoCompletionProcessingWhenSafe %d", bRet);
						if (bRet){
							goto PostOperationCallbackExitWithoutCleanup;
						}
						else{
							DbgPrint("In FltDoCompletionProcessingWhenSafe else");
							Data->IoStatus.Status = STATUS_UNSUCCESSFUL;
							Data->IoStatus.Information = 0;
							goto PostOperationCallbackExit;
						}
					}
					else if (FlagOn(Data->Flags, FLTFL_CALLBACK_DATA_SYSTEM_BUFFER) ||
						FlagOn(Data->Flags, FLTFL_CALLBACK_DATA_FAST_IO_OPERATION)) {
						DbgPrint("In case 2\n");
						goto PostOperationCallbackExit;
					}
					else if (Data->Iopb->Parameters.Read.MdlAddress == NULL && Data->Iopb->Parameters.Read.Length > 0){
						DbgPrint("In case 3\n");
						bRet = FltDoCompletionProcessingWhenSafe(Data,
							FltObjects,
							notification,
							Flags,
							SafePostCallback,
							&retValue);
						DbgPrint("After FltDoCompletionProcessingWhenSafe %d", bRet);
						if (bRet){
							goto PostOperationCallbackExitWithoutCleanup;
						}
						else{
							DbgPrint("In FltDoCompletionProcessingWhenSafe else");
							Data->IoStatus.Status = STATUS_UNSUCCESSFUL;
							Data->IoStatus.Information = 0;
							goto PostOperationCallbackExit;
						}

					}
					else{
						DbgPrint("In else case\n");
						//KeDelayExecutionThread(KernelMode, FALSE, &timeout);
						goto PostOperationCallbackExit;
					}
				}except(EXCEPTION_EXECUTE_HANDLER)
				{
					DbgPrint("\n!!! Exception in MyFilterDelayedPostOpCB ");
				}
			}
		}
		else if (Data->Iopb->MajorFunction == IRP_MJ_QUERY_INFORMATION && Data->Iopb->TargetFileObject->FileName.Buffer != NULL)
        {
            DbgPrint("inside irp_mj_query_information");
            if (wcsstr(notification->OldFileName, L"temp\\wsm_rmp_hv\\") != NULL && wcsstr(notification->OldFileName, L"vhd") != NULL)
            {
                try
                {
                    DbgPrint("Requestor mode %d\n", Data->Iopb->Parameters.QueryFileInformation.FileInformationClass);
                    if (Data->Iopb->Parameters.QueryFileInformation.FileInformationClass == FileBasicInformation){
                        DbgPrint("*********query for ALL Information requested\n");
                        PFILE_BASIC_INFORMATION file_basicInfo = Data->Iopb->Parameters.QueryFileInformation.InfoBuffer;
                        file_basicInfo->FileAttributes = FILE_ATTRIBUTE_NORMAL;
                    }
                }except(EXCEPTION_EXECUTE_HANDLER)
                {
                    DbgPrint("\n!!! Exception in queryFileInformationHandling ");
                }
            }
        }
	}
PostOperationCallbackExit:
	if (notification != NULL)
	{
		if (notification->Context != NULL)
		{
			FltReleaseContext(notification->Context);
		}
		ExFreePoolWithTag(notification, RMPFileMounter_PREOP_DATA_POOL_TAG);
	}
PostOperationCallbackExitWithoutCleanup:
	return retValue;
}

//-----------------------------------------------------------------------------------------------------------//

