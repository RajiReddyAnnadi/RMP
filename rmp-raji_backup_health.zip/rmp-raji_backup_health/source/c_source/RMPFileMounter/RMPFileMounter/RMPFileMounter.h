/*++

Module Name:

    RMPFileMounter.h

Abstract:

    Header file which contains the structures, type definitions,
    and constants that are shared between the kernel mode driver,
    RMPFileMounter.sys, and the user mode executable, RMPFileMounter.exe.

Environment:

    Kernel and user mode

--*/

#define MAXX_PATH 512
#define MINN_PATH 256


/*
 * Access Type definition should be synced with
 * definition in C#
 */

#define ACCESS_TYPE_FILE_CREATED 		1
#define ACCESS_TYPE_FILE_WRITE 			2
#define ACCESS_TYPE_FILE_SHIFT_DELETE 		3
#define ACCESS_TYPE_FILE_MOVED_OR_RENAMED 	4
#define ACCESS_TYPE_FILE_READ 			5
#define ACCESS_TYPE_FILE_OVERWRITTEN 		6
#define ACCESS_TYPE_FILE_PERMISSION_CHANGED 	7
#define ACCESS_TYPE_FILE_OWNER_CHANGED 		8
#define ACCESS_TYPE_FILE_SACL_CHANGED 		9
#define ACCESS_TYPE_FILE_READ_FAILED 		11
#define ACCESS_TYPE_FILE_WRITE_FAILED 		12
#define ACCESS_TYPE_FILE_DELETE_FAILED 		13

#define RMPFileMounter_CREATE 		0x00000001L
#define RMPFileMounter_WRITE 		0x00000002L
#define RMPFileMounter_DELETE 		0x00000004L
#define RMPFileMounter_MOVE_OR_RENAME 	0x00000008L
#define RMPFileMounter_READ 		0x00000010L
#define RMPFileMounter_OVERWRITTE 		0x00000020L
#define RMPFileMounter_PERMISSION_CHANGE 	0x00000040L
#define RMPFileMounter_OWNER_CHANGE	0x00000080L
#define RMPFileMounter_SACL_CHANGE 	0x00000100L
#define RMPFileMounter_READ_DENY 		0x00000200L
#define RMPFileMounter_WRITE_DENY	 	0x00000400L
#define RMPFileMounter_DELETE_DENY		0x00000800L

#define RMPFileMounter_SUCCESS_EVENT		0x00000001L
#define RMPFileMounter_FILENAME_AVAILABLE 		0x00000002L
#define RMPFileMounter_VALID_EVENT 		0x00000004L
#define RMPFileMounter_RENAME_EVENT 		0x00000008L
#define RMPFileMounter_POSSIBLE_DELETE_EVENT	0x00000010L
#define RMPFileMounter_TRANSACTION			0x00000040L

/*
 * Access Type definition ends here 
 */


#define FILE_ACCESS_EVENT_SUCCESS TRUE
#define FILE_ACCESS_EVENT_FAILURE FALSE


#ifndef __RMPFileMounter_H__
#define __RMPFileMounter_H__


//
//  FltMgr's IRP major codes
//

#define IRP_MJ_ACQUIRE_FOR_SECTION_SYNCHRONIZATION  ((UCHAR)-1)
#define IRP_MJ_RELEASE_FOR_SECTION_SYNCHRONIZATION  ((UCHAR)-2)
#define IRP_MJ_ACQUIRE_FOR_MOD_WRITE                ((UCHAR)-3)
#define IRP_MJ_RELEASE_FOR_MOD_WRITE                ((UCHAR)-4)
#define IRP_MJ_ACQUIRE_FOR_CC_FLUSH                 ((UCHAR)-5)
#define IRP_MJ_RELEASE_FOR_CC_FLUSH                 ((UCHAR)-6)
#define IRP_MJ_NOTIFY_STREAM_FO_CREATION            ((UCHAR)-7)

#define IRP_MJ_FAST_IO_CHECK_IF_POSSIBLE            ((UCHAR)-13)
#define IRP_MJ_NETWORK_QUERY_OPEN                   ((UCHAR)-14)
#define IRP_MJ_MDL_READ                             ((UCHAR)-15)
#define IRP_MJ_MDL_READ_COMPLETE                    ((UCHAR)-16)
#define IRP_MJ_PREPARE_MDL_WRITE                    ((UCHAR)-17)
#define IRP_MJ_MDL_WRITE_COMPLETE                   ((UCHAR)-18)
#define IRP_MJ_VOLUME_MOUNT                         ((UCHAR)-19)
#define IRP_MJ_VOLUME_DISMOUNT                      ((UCHAR)-20)

//
//  My own definition for transaction notify command
//

#define IRP_MJ_TRANSACTION_NOTIFY                   ((UCHAR)-40)
int portCnt;

//
//  Version definition
//

#define MINISPY_MAJ_VERSION 2
#define MINISPY_MIN_VERSION 0

typedef struct _MINISPYVER {

    USHORT Major;
    USHORT Minor;

} MINISPYVER, *PMINISPYVER;

//
//  Name of RMPFileMounter's communication server port
//

#define RMP_PORT_NAME                   L"\\RmpPort"

//
//  Local definitions for passing parameters between the filter and user mode
//

typedef ULONG_PTR FILE_ID;
typedef __success(return >= 0) LONG NTSTATUS;

//
//  The maximum size of a record that can be passed from the filter
//

#define RECORD_SIZE     512

//
//  This defines the type of record buffer this is along with certain flags.
//

#define RECORD_TYPE_NORMAL                       0x00000000
#define RECORD_TYPE_FILETAG                      0x00000004

#define RECORD_TYPE_FLAG_STATIC                  0x80000000
#define RECORD_TYPE_FLAG_EXCEED_MEMORY_ALLOWANCE 0x20000000
#define RECORD_TYPE_FLAG_OUT_OF_MEMORY           0x10000000
#define RECORD_TYPE_FLAG_MASK                    0xffff0000



//
//  Defines the commands between the utility and the filter
//

typedef enum _MINISPY_COMMAND {

    GetMiniSpyLog,
    GetMiniSpyVersion

} MINISPY_COMMAND;


//
//  Defines the command structure between the utility and the filter.
//

#pragma warning(push)
#pragma warning(disable:4200) // disable warnings for structures with zero length arrays.

typedef struct _COMMAND_MESSAGE {
    MINISPY_COMMAND Command;
    ULONG Reserved;  // Alignment on IA64
    UCHAR Data[];
} COMMAND_MESSAGE, *PCOMMAND_MESSAGE;

#pragma warning(pop)

//
//  Macros available in kernel mode which are not available in user mode
//

#ifndef Add2Ptr
#define Add2Ptr(P,I) ((PVOID)((PUCHAR)(P) + (I)))
#endif

#ifndef FlagOn
#define FlagOn(_F,_SF)        ((_F) & (_SF))
#endif

#endif /* __RMPFileMounter_H__ */


/*
 * A common stucture for client server communication is 
 * defined below.
 *
 */

#ifndef __COMMUNICATOR_H__

	#define __COMMUNICATOR_H__
	#define READ_BUFFER_SIZE   8

	typedef struct _CHANGE_NOTIFICATION 
	{
	    WCHAR UserSID[MAXX_PATH]; 	    
	    WCHAR NewFileName[MAXX_PATH];
	    WCHAR OldFileName[MAXX_PATH];
	    WCHAR ImageFileName[MAXX_PATH];
   	    FILE_ID ProcessId;
	    FILE_ID ThreadId;

	    ULONG AccessMask;
	    ULONG CreateOptions;
	    
	    ULONG AccessType;
	    ULONG SecurityInformation;
	    

	    ULONG IrpFlags; 	   
	    ULONG Flags; 
	    ULONG_PTR Information;
	    ULONG RMPFileMounterFlags;
	    ULONG FileAttributes; 
	    

    	    NTSTATUS Status;
		
	    LARGE_INTEGER CreationTime;
	    LARGE_INTEGER LastAccessTime;
	    LARGE_INTEGER LastWriteTime;

	    LARGE_INTEGER OriginatingTime;
	    LARGE_INTEGER CompletionTime;

	    UCHAR CallbackMajorId;
	    UCHAR CallbackMinorId;

	    CHAR TokenSource[TOKEN_SOURCE_LENGTH+1];
	    
	    BOOLEAN IsSuccessEvent; //No need
	    BOOLEAN IsDirectory; //No need
	    BOOLEAN IsTransaction;
	    PVOID Context;


		ULONG hvWriteLength;
		ULONG hvByteOffsetLowPart;
		LONG hvByteOffsetHighPart;
		LONGLONG hvByteOffsetQuadPart;

		PVOID origBufTemp;		
	} CHANGE_NOTIFICATION, *PCHANGE_NOTIFICATION;

	typedef struct _CHANGE_NOTIFICATION_REPLY 
	{
		CHAR *replyBuffer;
		int Reply;

	} CHANGE_NOTIFICATION_REPLY, *PCHANGE_NOTIFICATION_REPLY;

	typedef struct _DATA_BUFFER
	{
		unsigned char data[65536];
		ULONG bufSize;
		int movePtr;
		int count;
		PVOID origBufTemp;					
	}DATA_BUFFER, *PDATA_BUFFER;

#endif //  __COMMUNICATOR_H__


