#include <Windows.h>
#include <WinIoCtl.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <zlib.h>
#include <tchar.h> 
#include <string>
#include <map>
#include <vector>
using namespace std;


void show_record(USN_RECORD * record);
wstring findfilename(HANDLE hvol, DWORDLONG num);
LONGLONG QueryJournal(wstring letter, wstring locname);
int BackupFile(_In_ wstring& source, _In_ wstring& destination);
int EncryptBackupFile(_In_ wstring& source, _In_ wstring& destination, wstring secretKey);
int BackupFolder(_In_ const wstring& source, _In_ const wstring& destination, bool isEncrypted, wstring secretKey);
int FileLevelBackup(wstring src, wstring dest, string driveLetter, wstring location, std::map <string, vector<string>> &fileList, ofstream& buDetailsFile, bool isEncrypted, wstring secretKey);
void findnextrecord();
void setLogger(wstring locname);
int BackupDirectoryTree(string sour, wstring destin, wstring device, string val, std::vector<string> &volumeList, bool isFLR, ofstream& buDetailsFile, bool isEncrypted, wstring secretKey);
bool isSelectedFile(string file, string letter, std::vector<string> &volumeList);
void RenameFiles(wstring src, wstring dest);
void DeleteFiles(wstring src, wstring dest);
int RestoreFile(_In_ wstring& source, _In_ wstring& destination);
int RestoreDirectoryTree(wstring source, wstring destination, bool isEncrypted, wstring secretKey);
HRESULT ModifyPrivilege(IN LPCTSTR szPrivilege, IN BOOL fEnable);
int RestoreEncryptedFile(_In_ wstring& source, _In_ wstring& destination, wstring secretKey);
int compressEncrypt(wstring source, wstring destination, wstring secretKey);