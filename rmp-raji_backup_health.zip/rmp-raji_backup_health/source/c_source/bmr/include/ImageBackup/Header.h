#ifndef Thread_HEADER
#define Thread_HEADER
#include <Windows.h>
#include <process.h>



class Thread
{

public:
	Thread(DWORD dwCreationFlags = 0)
	{
		Threadhan = Create(ThreadProc, this, dwCreationFlags, NULL, 0, &m_dwThreadId);
	}

	DWORD Resume()
	{

		return ResumeThread(Threadhan);
	}

	BOOL Terminate(DWORD dwExitCode = 0)
	{

		return TerminateThread(Threadhan, dwExitCode);
	}


	virtual ~Thread()
	{
		if ( Threadhan != NULL )
			CloseHandle(Threadhan);
	}

	HANDLE GetHandle() 
	{
		return Threadhan;
	}
	virtual DWORD Execute() = 0;



protected:
	HANDLE Threadhan;
	DWORD m_dwThreadId;

private:

	static HANDLE Create(unsigned (__stdcall *pThreadProc )( void * ), LPVOID pParam = NULL,
		DWORD dwCreationFlags = 0, LPSECURITY_ATTRIBUTES pSecurityAttr = NULL,
		DWORD dwStackSize = 0, DWORD* pdwThreadId = NULL)
	{
		DWORD dwThreadId = 0;
		HANDLE hThread = (HANDLE) _beginthreadex(pSecurityAttr, dwStackSize,
			pThreadProc, pParam, dwCreationFlags, (unsigned*) &dwThreadId);

		if (pdwThreadId != NULL)
			*pdwThreadId = dwThreadId;
		return hThread;
	}

	static unsigned __stdcall ThreadProc( void *p )
	{
		Thread* pThreadObj = (Thread*) p;
		return pThreadObj->Execute();
	}
};
#endif