#ifndef Read_HEADER
#define Read_HEADER
#include <stdio.h>
#include <Windows.h>
#include <iostream>
#include <string>
#include <zlib.h>
#include "Header.h"
#include "Bitmap.h"

using namespace std;
class Queuecode;

class Read : public Thread
{
public:
	Read(Queuecode *inputQueue,  Queuecode *outputQueue,HANDLE drivehan,HANDLE filehan,unsigned __int64 partsize,unsigned int pos,unsigned clustersize,int val,unsigned __int64 offset,wstring name,wstring src);
	virtual DWORD Execute();
	Queuecode *inpQueue;
	Queuecode *outQueue;
	HANDLE dhan;
	HANDLE fhan;
        //HANDLE bhan;
	int check;
        int rError;
        wstring src;
        gzFile ifile;
	unsigned __int64 ptnsize;
	unsigned int position;
	unsigned clusterSize;
	unsigned __int64 off;
	DWORD ReadData();
        DWORD ReadBackupData();
	DWORD  Readusedonly();
	DWORD FileRead(void * buffer, unsigned nLength, unsigned *nbytesRead);
        DWORD DecompressAndRead(void * buffer, unsigned nLength, unsigned *nbytesRead);
        DWORD ReadEncryptedData();
}; 
#endif
