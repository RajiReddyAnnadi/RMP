#ifndef Info_HEADER
#define Info_HEADER
#include <stdio.h>
#include <iostream>
#include <string> 
#include <Windows.h>
#include <vector>
#include <zlib.h>
#include <map>
#include "Queue.h"
#include "Header.h"
#include "Vss.h"
using namespace std;

class Info {
public:
    Info(wstring& dpName, wstring& dvName, wstring& mPoint, bool isDisk);
    wstring displayName, deviceName, mountPoint, guid;
    __int64 bytes, sectors;
    int bytesPerSector, sectorsPerTrack;
    DWORD clusterSize;
    int containedVolumes; // number of volumes contained in a physical disk
    bool isMounted; // true if volume is mounted false if not mounted
    Info* parent; // parent object e.g. hard disk of a partition

};

#define SIZE 512
using namespace std;
int index;
unsigned partitioncount;
unsigned __int64 disksize;
unsigned __int64 partitionsize;
HANDLE fileHandle;
HANDLE driveHandle;
HANDLE metaHandle;
BYTE* Buffer;
DRIVE_LAYOUT_INFORMATION_EX *dl;
BYTE bootloader[SIZE];
const GUID magicGUID = {0x1a4b7c73, 0xfa03, 0x40e3,
    { 0xb1, 0x92, 0x53, 0x64, 0xd5, 0xf6, 0x7, 0xe8}};
wstring diskMode;
wstring fileMode;
wstring diskName;
vector<Info*> driveList;
unsigned int position = 0;
int volumecount;
BYTE Type;
bool mounted;
bool locked;
unsigned bytesPerSector;
unsigned bytesPerCluster = 0;
int vssindex;
Queuecode *initialReader;
Queuecode *finalReader;

typedef struct {
    GUID guid; // UUID to identify file format
    WORD versionMajor; // major version of file format
    WORD versionMinor; // minor version of file format
    DWORD partitionCount; // number of partition entries in file
    unsigned __int64 diskExtent; // size of disk
    DWORD bootLoaderOffset; // offset in file where boot loader is located
    DWORD bootLoaderLength; // length of boot loader in bytes
    DWORD partInfoOffset; // offset in file where partion information is located
    DWORD partInfoLength; // length of partition information in bytes
} MBRFileHeader;

typedef struct {
    GUID guid; // UUID to identify file format
    WORD versionMajor; // major version of file format
    WORD versionMinor;
    unsigned __int64 volumeBitmapOffset; // file offset where run length encoded volume bitmap is stored
    unsigned __int64 volumeBitmapLength;
    unsigned __int64 dataOffset;
} IMGFileHeader;

typedef enum {
    PROGRESS,
    DONEWITHSTRUCTURE,
    UNKNOWN2,
    UNKNOWN3,
    UNKNOWN4,
    UNKNOWN5,
    INSUFFICIENTRIGHTS,
    UNKNOWN7,
    UNKNOWN8,
    UNKNOWN9,
    UNKNOWNA,
    DONE,
    UNKNOWNC,
    UNKNOWND,
    OUTPUT,
    STRUCTUREPROGRESS
  } CALLBACKCOMMAND;
  
  typedef struct {
	  DWORD Lines;
	  PCHAR Output;
  } TEXTOUTPUT, *PTEXTOUTPUT;
  static BOOL	sError;

bool FormatDrive(LPCWSTR drive, LPCWSTR label, BOOL quickFormat = FALSE);

typedef BOOLEAN(__stdcall *PFMIFSCALLBACK)(CALLBACKCOMMAND Command, DWORD SubAction, PVOID ActionInfo);
typedef VOID(__stdcall *PFORMATEX)(LPCWSTR DriveRoot,
        DWORD MediaFlag,
        LPCWSTR Format,
        LPCWSTR Label,
        BOOL QuickFormat,
        DWORD ClusterSize,
        PFMIFSCALLBACK Callback);
HMODULE fLib;
PFORMATEX fFormatEx;
static BOOLEAN __stdcall FormatExCallback(CALLBACKCOMMAND Command, DWORD Modifier, PVOID Argument);

extern "C" {
    __declspec(dllexport) int Add(wchar_t *storageLoc, wchar_t *logLoc, wchar_t *code, wchar_t *files, int isEncrypted, wchar_t *secretKey);
}
extern "C" {
    __declspec(dllexport) int getDiskCount();
}extern "C" {
    __declspec(dllexport) int volumeLevelRestore(wchar_t *storageLoc, wchar_t *logLoc, wchar_t *files, int type, wchar_t *mergePath, wchar_t *user, wchar_t *pwd, wchar_t *restoreLogFile, int isEncrypted, wchar_t *secretKey);
}
 
int operation(wstring op, wstring files, bool isEncrypted, wstring secretKey);
int performRestore(int type, wstring files, wstring merge, wstring user, wstring pwd, bool isEncrypted, wstring secretKey);
int DriveBackup(wstring src, wstring dest,int dskNo, bool isEncrypted, wstring secretKey);
int VolumeBackup(wstring src, wstring dest, std::vector<string> &volumeList, bool isEncrypted, wstring secretKey);
int IncrVolumeBackup(wstring src, wstring dest, std::vector<string> &volumeList, bool isEncrypted, wstring secretKey);
int FileBackup(wstring src, wstring dest, map <string, vector<string> > &fileList, bool isEncrypted, wstring secretKey);
int IncrFileBackup(wstring src, wstring dest, map <string, vector<string> > &fileList, bool isEncrypted, wstring secretKey);
int RestoreDrive(wstring src, wstring dest, std::vector<string> &volumeList, wstring mergePath, wstring user, wstring pwd, bool isEncrypted, wstring secretKey);
int IncrBackup(wstring src, wstring dest, int dskNo, bool isEncrypted, wstring secretKey);
int IncrRestore(wstring src, wstring dest);
void Creatembrfilename(wstring &name);
int ReadDriveInfo(wstring source);
void WriteDriveInfo(wstring driveName);
int WriteToFile(wstring fileName);
void ReadFromFile(wstring fileName);
void WriteHeader();
void ReadHeader();
int BackupandRestorePartitions(int index, wstring driveName, wstring fileName, unsigned clustersize, wstring operation, wstring origName, int isEncrypted, wstring secretKey);
int Opentargetfile(wstring name, wstring mode);
int Opendisk(wstring name, wstring mode);
long OpenAPI(HANDLE* hFile, LPCWSTR FileName, ACCESS_MASK DesiredAccess, ULONG FileAttributes, ULONG ShareAccess, ULONG CreateDisposition, ULONG CreateOptions);
void GenerateFileNameForEntireDiskBackup(wstring &volumeFileName, wstring name, wstring partitionDeviceName);
int GetVolumes(const Info* driveInfo, Info** pVolumes, int volumeCount);
void WaitForDriveReady(int index, unsigned partitionCount, const wstring& targetDiskDeviceName);
int ListDrives();
unsigned GetThreadCount();
bool GetThreadHandles(HANDLE* handles, unsigned size);
void Terminate();
bool TestIsMBR(wstring &fileName);
void Lockvolumes(wstring rootName, int containedVolumes);
void OpenAndLockVolume(wstring volName, int index);
void CloseAndUnlockVolume(int index);
void GenerateDeviceNameForVolume(wstring& volumeFileName, unsigned diskNo, unsigned volumeNo);
int MakeSnapshot(int driveIndex);
void getFBSize(wstring loc);
void getIBSize(wstring loc);
//void GenerateFileNameForCompressDiskBackup(wstring &volumeFileName, wstring name, wstring partitionDeviceName);
void GenerateFileNameForMetadata(wstring &volumeFileName, wstring name, wstring partitionDeviceName);
void loadFmifs();
void releaseFmifs();
int writePasswordHash(wstring destination, wstring secretKey);
#endif