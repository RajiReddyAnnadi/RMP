#ifndef Logger_H_INCLUDED
#define Logger_H_INCLUDED
#include <sys/timeb.h>
#include <tchar.h>
#include <stdio.h>
#include <windows.h>

#define		NORMAL	L"NORMAL"
#define		DEBUG	L"DEBUG"

class Logger
{
private:
	FILE*		logFile;
	LPWSTR		level;
	void log(LPWSTR writeLevel, const wchar_t* message, va_list* args);
	void checkLogFile(LPWSTR logFileName);

public:
	Logger(LPWSTR logFile, LPWSTR loglevel);
	void log(LPWSTR writeLevel, const wchar_t* message, ...);
	~Logger(void);
};

#endif