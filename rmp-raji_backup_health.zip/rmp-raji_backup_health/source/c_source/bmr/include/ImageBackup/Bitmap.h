#ifndef Bitmap_HEADER
#define Bitmap_HEADER
#include <Windows.h>
#include <iostream>
#include <stdio.h>
using namespace std;


unsigned __int64 GetVolumeBitmap(HANDLE fileHandle,HANDLE driveHandle,unsigned __int64 partitionsize,unsigned bytesPerCluster,wstring name);
void InitWriter();
void InitReader(unsigned __int64 seekPos, DWORD length,HANDLE fileHandle);
void AddBuffer(void* buffer, unsigned length,HANDLE fileHandle);
void LoadBuffer(void *bits, unsigned bitCount);
bool GetBit(unsigned index);
unsigned GetRunLength(unsigned index,bool val);
void Flush(HANDLE fileHandle);
void EnhanceLastRunLength(unsigned __int64 runLength,HANDLE fileHandle);
void EncodeAndStoreRunLength(unsigned __int64 runLength,HANDLE fileHandle);
void WriteBuffer(HANDLE fileHandle);
unsigned __int64 GetNextRunLength(HANDLE fileHandle);
void ReadNextRunLength(HANDLE fileHandle);
void ReloadBuffer(HANDLE fileHandle);
void GetValues(DWORD& Pos,bool& ValueAvailable,unsigned& LastIndex);
#endif