
#include <stdio.h> 
#include <tchar.h> 
#include <string> 
#include <wbemcli.h> 
#include <iostream> 
#include<Windows.h>
#include<fstream>
#include <stdlib.h>
using namespace std;
#define READ 700                //required block length
#define RS_CHAR_OFFSET 5

unsigned int weak_sum(void const *p, int len)
{
        int i;
        unsigned        s1, s2;
        unsigned char const    *buf = (unsigned char const *) p;

        s1 = s2 = 0;
        for (i = 0; i < (len - 4); i += 4) {
                s2 += 4 * (s1 + buf[i]) + 3 * buf[i + 1] +
                        2 * buf[i + 2] + buf[i + 3] + 10 * RS_CHAR_OFFSET;
                s1 += (buf[i + 0] + buf[i + 1] + buf[i + 2] + buf[i + 3] +
                       4 * RS_CHAR_OFFSET);
        }
        for (; i < len; i++) {
                s1 += (buf[i] + RS_CHAR_OFFSET);
                s2 += s1;
        }
        return (s1 & 0xffff) + (s2 << 16);
}

string removeSubstrs(string s,string p)
{	
	  string::size_type n = p.length();
	  string::size_type i = s.find(p);
    if(i != string::npos)     
      s.erase(i,n);	 	
	return s;
}
int hashcalc(const wchar_t *p,wstring p1,wstring p2)
{
	ifstream file;
	int size;
  file.open(p, ios::in|ios::binary );
	  file.seekg(0, ios::end); 
	size=  file.tellg() ;
	cout<<"size"<<size<<endl;
	file.seekg(0, ios::beg);
wstring p4=p1;
p4+='\\';
p4+=L"sign_";
p4+=p2;
int hash_int,count1=0,check=0;
bool val;
char block[READ+1],hash_char[15];
	
	 ofstream hash;
	 hash.open(p4, ios::out | ios::app|ios::binary);

	while(count1<size)
{	  
	file.read(block,READ);
check++;
count1+=READ;
block[READ]='\0';
cout<<block<<endl;
hash_int=weak_sum(block,READ);
cout<<hash_int<<endl;
			
	itoa(hash_int,hash_char,10);		
	hash.write(hash_char,strlen(hash_char));	
	hash<<endl;
	memset(block,'\0',strlen(block));	
	memset(hash_char,'\0',strlen(hash_char));
	}
	hash.close();
	return check;
}

 void deltacalc(const wchar_t *p,wstring p1,wstring p2,int check)
{ 
	ifstream file;
	int size;
  file.open(p, ios::in|ios::binary );
	  file.seekg(0, ios::end); 
	size=  file.tellg() ;
	cout<<"size"<<size<<endl;
	file.seekg(0, ios::beg);
wstring p3=p1;
p3+='\\';
p3+=L"delta_";
p3+=p2;
wstring p4=p1;
p4+='\\';
p4+=L"sign_";
p4+=p2;
	 ofstream delta;
 delta.open(p3,ios::out |ios::binary);
	 
char block[READ+1],hash_char[15];
char* diff=new char[size];
char* toread=new char[size-READ+1];
char* buf=new char[size-READ+1];
char* toskip=new char[];
char delim1[]="--";
char delim2[]="**";
string* temp=new string[size-READ+1];
string* tempo=new string[size-READ+1];
string* ftrim=new string[size-READ+1];
string* btrim=new string[size-READ+1];
bool* status=new bool[size-READ+1];
string d,h,t;
int test,hash_int,result=0,count=0,count1=0,co1=0,del=0,i=0,co=0,loop=0;

bool val;
ifstream hash;
	 hash.open(p4, ios::in |ios::binary);	
	 int l=0;
	 while (getline(hash,tempo[l]))
	 {
		 cout<<tempo[l]<<endl;
         l++;
     }
while(count1<size)
{	
	cout<<"check"<<check<<endl;
	file.read(block,READ);
  block[READ]='\0';
cout<<block<<endl;
hash_int=weak_sum(block,READ);
cout<<hash_int<<endl;
	test=count;
	temp[count].assign(block,READ);
	ftrim[count].assign(temp[count],1,READ-1);
	cout<<endl;
	cout<<endl;	
	btrim[count].assign(block,READ-1);	
		memset(block,'\0',sizeof(block));	
	memset(hash_char,'\0',sizeof(hash_char));
for(loop=0;loop<l;loop++)
{
	if(tempo[loop]==itoa(hash_int,hash_char,10))
	{
		val=true;
		break;
	}
	else
		val=false;
}

if(val)
{	
	file.seekg(0, ios::cur);
	status[count]=true;	
	count1+=READ;
	cout<<"count1"<<count1<<endl;
	co1++;
	co++;
	for(i;i<check;i++)
	{
		if(itoa(hash_int,buf,10)==tempo[i])
		{
			i++;
			break;
		}
	}
	cout<<"co1"<<co1<<endl;
	cout<<"i"<<i<<endl;
	memset(toread,'\0',sizeof(toread));
	memset(diff,'\0',sizeof(diff));
	if(i>=co1)
	{		
		itoa (((i-co1-del)*READ),toskip,10);
		del+=(i-co1-del);
	}	

	if((test!=0)&&(status[test-1]==false))
	{		
	while((test!=0)&&(status[test-1]==false))
	{				
		d=removeSubstrs(temp[test-1],btrim[test]);
		t.insert(0,d);		
		test--;
	}	
	cout<<"1st t"<<t<<endl;
	if((test!=0)&&(status[test-1]==true))
	{	
		co--;
itoa((co)*READ,toread,10);	
d.clear();
}
	else
	{
		cout<<"t"<<"\t"<<t<<endl;		
		itoa(0,toread,10);
	}	
	h=t;
		strcpy(diff,h.c_str());	
	
cout<<"diff"<<diff<<endl;
if(!h.empty())
{
	 delta.write(toread,strlen(toread));
     delta.write(delim1,strlen(delim1));
	 delta.write(diff,strlen(diff));
	 delta.write(delim1,strlen(delim1));
	 delta.write(toskip,strlen(toskip));
	 delta.write(delim2,strlen(delim2));	
}
t.clear();
	h.clear();
	}
	memset(diff,'\0',sizeof(diff));	
	
	if((count==0)&&(i>co1))
	{		
	 delta.write(toread,strlen(toread));
     delta.write(delim1,strlen(delim1));
	 delta.write(diff,strlen(diff));
	 delta.write(delim1,strlen(delim1));
     delta.write(toskip,strlen(toskip));
     delta.write(delim2,strlen(delim2));
	}
}
else
{	
	if((int)file.tellg()==size)
		count1+=READ;
	else
		count1++;
	file.seekg(-(READ-1), ios::cur);
	
	cout<<"count1"<<count1<<endl;
	status[count]=false;
	if(count1>=size)
	{		
		test=count;
		if(status[count]==false)
		{			
			h.clear();
		do
	{
d=removeSubstrs(temp[test],ftrim[test-1]);
h.insert(0,d);
	 test--;
}while((status[test]!=true)&&(test!=0));

	cout<<"test"<<test<<endl;
	if(test==0)
h.insert(0,temp[0]);
		
		strcpy(diff,h.c_str());
			cout<<"diff"<<diff<<endl;
			h.clear();

	itoa((co)*READ,toread,10);
    delta.write(toread,strlen(toread));
    delta.write(delim1,strlen(delim1));
    delta.write(diff,strlen(diff));
	delta.write(delim1,strlen(delim1));
	        cout<<diff;		
	itoa(((check-co1-del)*READ),toskip,10);
	delta.write(toskip,strlen(toskip));
	delta.write(delim2,strlen(delim2));	
			h.clear();
		}		
		del++;
}		
	}

count++;
}

	cout<<"check"<<check<<endl;
	cout<<"co1"<<co1<<endl;
	cout<<"del"<<del<<endl;
if((check>(co1+del)))
	{
		memset(diff,'\0',sizeof(diff));
		memset(toread,'\0',sizeof(toread));
		memset(toskip,'\0',sizeof(toskip));
		itoa (((check-co1-del)*READ),toskip,10);
		itoa ((count1),toread,10);
	delta.write(toread,strlen(toread));
    delta.write(delim1,strlen(delim1));
	delta.write(diff,strlen(diff));
	delta.write(delim1,strlen(delim1));
	delta.write(toskip,strlen(toskip));
    delta.write(delim2,strlen(delim2));
	}
file.close();
delta.close();
}


HRESULT Backufile(_In_ const wstring& source, _In_ const wstring& destination,_In_ const wstring& destination1,_In_ const wstring& destination2) 
{
    HANDLE hSourceFile = ::CreateFile(
                        source.c_str(), 
                        GENERIC_READ,
                        FILE_SHARE_READ,
                        NULL,
                        OPEN_EXISTING,
                        FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_BACKUP_SEMANTICS,
                        NULL);
    if (hSourceFile == INVALID_HANDLE_VALUE) 
    {
        wcout << L"CreateFile(" << " failed with error " << GetLastError() << endl;
        return HRESULT_FROM_WIN32(GetLastError());
    }
    
    const DWORD DEFAULT_BUFFER_SIZE = 4086;  
    DWORD bytesRead = 0, bytesWritten = 0;
    BYTE buffer[DEFAULT_BUFFER_SIZE];
    LPVOID context = NULL;
    HRESULT hr = S_OK;
	int check=0;
	DWORD  dwAttrs;
	dwAttrs = GetFileAttributes(source.c_str());
	bool isArchive=((dwAttrs & FILE_ATTRIBUTE_ARCHIVE)==FILE_ATTRIBUTE_ARCHIVE);
            // check whether a file has archive attribute                 
            if (isArchive)
            {								
				check=hashcalc(destination.c_str(),destination1,destination2);
				cout<<"success 1"<<endl;
				deltacalc(source.c_str(),destination1,destination2,check);
				cout<<"success 2"<<endl;
				
			}  
    CloseHandle(hSourceFile);
	}
   
void BackupDirectoryTree(_In_ const wstring& source, _In_ const wstring& destination) 
{ 
    HRESULT hr = S_OK;     
    if (!::CreateDirectory(destination.c_str(), NULL)) 
    { 
        DWORD error = GetLastError(); 
        if (error != ERROR_ALREADY_EXISTS) 
        { 
            wcout << L"CreateDirectory(" << destination << L") failed with error " << GetLastError() << endl; 
            hr =  HRESULT_FROM_WIN32(error); 
        } 
    }      
 
    WIN32_FIND_DATA findData; 
    wstring pattern = source; 
    pattern += L"\\*"; 
    HANDLE hFind = FindFirstFile(pattern.c_str(), &findData); 
    if (hFind != INVALID_HANDLE_VALUE) 
    { 
        do  
        { 
            if (findData.cFileName[0] != '.') 
            { 				
                wstring newSource = source; 
                newSource += '\\'; 
                newSource += findData.cFileName; 
                wstring newDestination = destination; 
                newDestination += '\\'; 				
                newDestination += findData.cFileName; 
               wstring newDestination1=findData.cFileName;
                if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)  
                {                   
                    BackupDirectoryTree(newSource, newDestination); 
                } 
                else  
                {                     
					hr = Backufile(newSource, newDestination,destination,newDestination1); 
                    if (FAILED(hr)) 
                    {                         
                        wcout << L"Backufile failed, hr = 0x" << hex << hr << endl; 
                    } 
                } 
            } 
        } while (FindNextFile(hFind, &findData)); 
 
        FindClose(hFind); 
    } 
} 
/*int main()
{
	BackupDirectoryTree(L"D:\\source",L"E:\\origi");
    getchar();
	return 0;
}*/






