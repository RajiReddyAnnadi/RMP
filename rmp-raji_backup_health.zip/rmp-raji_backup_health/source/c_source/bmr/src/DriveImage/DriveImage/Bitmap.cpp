#include "stdafx.h"
#include "Bitmap.h"
#include "Logger.h"
const int BITSPERUNIT = 8;
const unsigned LongestLen = 33;
static const unsigned Len = 65536;
bool  Value;
BYTE *BitmapBuffer;
BYTE *BufferPos;
BYTE *BufferEndPos;
BYTE *Array=NULL;
unsigned  ArraySize=0;
BYTE* Header;
LPWSTR levelbit=NORMAL;
LPWSTR bitloc;
Logger *logbit;
DWORD Pos;
bool ValueAvailable;
unsigned LastIndex;
unsigned __int64 RunLength[4]; 
unsigned __int64 LastRunLength;    
unsigned __int64 SetBits;     
unsigned __int64 ClearedBits; 

bool fEof;
unsigned __int64 StreamPos;
DWORD StreamBytesConsumed;
DWORD StreamLength;

unsigned __int64 GetVolumeBitmap(HANDLE fileHandle,HANDLE driveHandle,unsigned __int64 partitionsize,unsigned bytesPerCluster)
{
	unsigned int chunkSize= 2 * 1024 * 1024;
	unsigned nBitmapBytes;
	VOLUME_BITMAP_BUFFER *volumeBitmap;
	unsigned __int64 startCluster, stopCluster;
	unsigned noClustersPerChunk, noClusters;
	DWORD nBytesReturned;
	unsigned __int64 bitmapSize, startOffset;
	LARGE_INTEGER newPos, curPos;
	BOOL ok;


	InitWriter();
	newPos.QuadPart = 0LL;
	ok = SetFilePointerEx(fileHandle, newPos, &curPos, FILE_END);
	startOffset = curPos.QuadPart;

	noClustersPerChunk = chunkSize * 8;
	noClusters = (unsigned) (partitionsize / bytesPerCluster);
	unsigned noIterations = (unsigned) (noClusters + noClustersPerChunk - 1)/ noClustersPerChunk;

	// Determine the number of clusters in a chunk, and the number of cluster bitmap bytes that are taken by a chunk.
	nBitmapBytes = (noClustersPerChunk + 7) / 8;
	volumeBitmap = (VOLUME_BITMAP_BUFFER *)malloc(sizeof(VOLUME_BITMAP_BUFFER) + nBitmapBytes - 1);
	memset(volumeBitmap, 0, sizeof(VOLUME_BITMAP_BUFFER));
	startCluster = stopCluster = 0;

	for (unsigned i=0; i<noIterations; i++ ) 
	{
		stopCluster = startCluster + noClustersPerChunk;
		int ret = DeviceIoControl(driveHandle, FSCTL_GET_VOLUME_BITMAP, &startCluster, sizeof(startCluster), volumeBitmap, sizeof(VOLUME_BITMAP_BUFFER) + nBitmapBytes - 1, &nBytesReturned, NULL);
		if (ret == 0 && GetLastError() != ERROR_MORE_DATA)
			logbit->log(NORMAL,L"Insufficient buffer to read bitmap data\n");

		if (volumeBitmap->StartingLcn.QuadPart != startCluster)
			logbit->log(NORMAL,L"Start lcn mismatch error\n");

		startCluster += noClustersPerChunk;
		AddBuffer(&(volumeBitmap->Buffer[0]), (nBytesReturned - sizeof(VOLUME_BITMAP_BUFFER) + 1) * 8,fileHandle);
	}
	Flush(fileHandle);
	free(volumeBitmap);
	ok = SetFilePointerEx(fileHandle, newPos, &curPos, FILE_END);

	bitmapSize = curPos.QuadPart - startOffset;
	InitReader(startOffset, (DWORD) bitmapSize,fileHandle);
	return bitmapSize;
}


void GetValues(DWORD& Posi,bool& Val,unsigned& LstInd)
{
	Posi=Pos;
	Val=ValueAvailable;
	LstInd=LastIndex;
}

void InitWriter()
{
	Value = true;
	BitmapBuffer = new BYTE [Len];
	BufferPos = BitmapBuffer;
	BufferEndPos = BitmapBuffer + Len;
	Pos = 3;
	Header = BufferPos;
	(*Header) = 0;
	LastRunLength = 0; 
	SetBits = 0;
	ClearedBits = 0;
}

void AddBuffer(void* buffer, unsigned length,HANDLE fileHandle)
{
	unsigned __int64 runLength = 0;

	LoadBuffer(buffer, length);
	bool newBitValue = GetBit(0);

	// if it is the first block and this starts with 0 add a zero run length because we always
	// start with a run length of 1
	if (LastRunLength == 0 && !newBitValue)
		EncodeAndStoreRunLength(0,fileHandle);

	// check if we need to enhance the last run length or a bit value change occured
	if (newBitValue == Value && LastRunLength != 0)
	{
		// add new run length to current run length
		runLength = GetRunLength((unsigned) 0, Value);
		EnhanceLastRunLength(runLength,fileHandle);
		Value = !Value;
	} else
	{
		Value = newBitValue;
	} 

	for (unsigned __int64 i=runLength; i < length; )
	{
		runLength = GetRunLength((unsigned) i, Value);
		EncodeAndStoreRunLength(runLength,fileHandle);
		Value = !Value;
		i+=runLength;
	}
	// save last values:
	Value = !Value;
	LastRunLength = runLength;
}

void LoadBuffer(void *bits, unsigned bitCount)
{
	unsigned nBufferBytes = (bitCount + 7) / 8;
	unsigned nNewMemSize = (bitCount + BITSPERUNIT - 1) / BITSPERUNIT * sizeof(BYTE);
	//BYTE nMask;

	if (Array)
		free(Array);
	Array = (BYTE*)malloc(nNewMemSize);
	memcpy(Array, bits, nBufferBytes);
	ArraySize = bitCount;

}

bool GetBit(unsigned index) 
{
	BYTE b = Array[index/BITSPERUNIT];
	BYTE mask = 0x1; // 0000 0001;
	bool value;
	mask = mask << index % BITSPERUNIT;
	value = (b & mask) != 0;
	return value;
}

unsigned GetRunLength(unsigned index,bool val)
{
	unsigned nArraySize = ArraySize / BITSPERUNIT;
	unsigned start = (index+BITSPERUNIT-1) / BITSPERUNIT;
	int nBit=start*BITSPERUNIT;
	unsigned n;

	// from index to first byte boundary
	for (n = index; n < start*BITSPERUNIT; n++)
	{
		if(val)
		{
			if (!GetBit(n))
				return n-index;
		}
		else
		{
			if (GetBit(n))
				return n-index;
		}
	}
	// all bytes that are complete
	if(val)
	{
		for (n = start; n < nArraySize; n++)
			if (Array[n] != 255)
			{
				nBit = n * sizeof(BYTE) * BITSPERUNIT;
				while (GetBit(nBit++))
					;
				return nBit-index-1;
			}
	}
	else
	{
		for (n = start; n < nArraySize; n++)
			if (Array[n]) {
				nBit = n * sizeof(BYTE) * BITSPERUNIT;
				while (!GetBit(nBit++))
					;
				return nBit-index-1;
			}
	}

	// from last byte boundary until end of bit field
	for (n = nBit; n < ArraySize; n++)
	{
		if(val)
		{
			if (!GetBit(n))
				return n-index;
		}
		else
		{
			if (GetBit(n))
				return n-index;
		}
	}

	return ArraySize-index;
}

void InitReader(unsigned __int64 seekPos, DWORD length,HANDLE fileHandle)
{
	BitmapBuffer = new BYTE[Len];
	BufferPos = BufferEndPos = BitmapBuffer;
	fEof = false;
	StreamPos = seekPos;
	StreamLength = length;
	StreamBytesConsumed = 0;
	Pos = 4;
	LastIndex = 3;
	ValueAvailable = true;
	ReloadBuffer(fileHandle);
}
void Flush(HANDLE fileHandle)
{
	for (int i=Pos+1; i<4; i++) {
		EncodeAndStoreRunLength(0,fileHandle);
	}
	//  BufferPos--; // next header byte is already assigned
	WriteBuffer(fileHandle);
}

void EnhanceLastRunLength(unsigned __int64 runLength,HANDLE fileHandle)
{  
	BYTE fieldWidthTag = (*Header) & 0xC0 ;
	// reset pointer of output buffer before the last token
	if (fieldWidthTag == 0xC0)
	{ // 11000000
		BufferPos -= 8;
	} else if (fieldWidthTag == 0x80) 
	{ // 10000000
		BufferPos -= 4;
	} else if (fieldWidthTag == 0x40)
	{ // 01000000
		BufferPos -= 2;
	} else
	{ // 00000000
		BufferPos -= 1;
	}

	runLength += LastRunLength;
	(*Header) <<= 2;
	--Pos;
	if ((Pos & 1) == 0)
		ClearedBits -= LastRunLength;
	else
		SetBits -= LastRunLength;
	return EncodeAndStoreRunLength(runLength,fileHandle);
}

void EncodeAndStoreRunLength(unsigned __int64 runLength,HANDLE fileHandle)
{
	if ((Pos & 1) == 0)
		ClearedBits += runLength;
	else
		SetBits+=runLength;

	++Pos;
	if (Pos == 4)
	{
		if (BufferPos + LongestLen > BufferEndPos)
		{
			WriteBuffer(fileHandle);
			Pos = 0;
			*Header = 0;
		}

		Pos = 0;
		Header = BufferPos++;
		(*Header) = 0;
	}

	(*Header) >>= 2;
	if (runLength & 0xFFFFFFFF00000000) 
	{ // requires 64 bit to store
		memcpy(BufferPos, &runLength, 8);
		BufferPos += 8;
		(*Header) |= 0xC0; // set highest 2 bits to 11
	} else if (runLength & 0x00000000FFFF0000)
	{ // requires 32 bit to store
		memcpy(BufferPos, (DWORD*)(&runLength), 4);
		BufferPos += 4;
		(*Header) |= 0x80; // set highest 2 bits to 10
	} else if (runLength & 0x000000000000FF00)
	{ // requires 16 bit to store
		memcpy(BufferPos, (WORD*)(&runLength), 2);
		BufferPos += 2;
		(*Header) |= 0x40; // set highest 2 bits to 01
	} else 
	{ // if (runLength & 0x00000000000000FF) { // requires 8 bit to store
		*BufferPos = (BYTE) runLength;
		BufferPos += 1;
		// obsolete (*Header) |= 0x00; // set highest 2 bits to 00
	}

}

void WriteBuffer(HANDLE fileHandle)
{
	DWORD sizeWritten;
	DWORD len = (DWORD)(BufferPos - BitmapBuffer);
	BOOL ok;

	ok = WriteFile(fileHandle, BitmapBuffer, len, &sizeWritten, NULL);

	BufferPos = BitmapBuffer;
	BufferEndPos = BufferPos + Len;
}

unsigned __int64 GetNextRunLength(HANDLE fHandle)
{
	HANDLE fileHandle=fHandle;
	if (3<Pos && LastIndex == 3)
		ReadNextRunLength(fileHandle);
	return RunLength[Pos++];
}

// read next four values from stream  
void ReadNextRunLength(HANDLE fileHandle)
{  
	unsigned byteLen[4];

	if (BufferPos + LongestLen > BufferEndPos && !fEof) 
		ReloadBuffer(fileHandle);

	Pos = 0;
	BYTE b = *BufferPos++;
	byteLen[0] = b & 3;          // 00000011
	byteLen[1] = (b & 12) >> 2;  // 00001100
	byteLen[2] = (b & 48) >> 4;  // 00110000
	byteLen[3] = (b & 192) >> 6; // 11000000

	for (int i=0; i<4; i++)
	{
		if (byteLen[i] == 0) 
		{         // 0 means 1 byte length
			RunLength[i] = (unsigned __int64) (*(BYTE*) BufferPos);
			++BufferPos;
		} else if (byteLen[i] == 1)
		{  // 1 means 2 byte length
			RunLength[i] = (unsigned __int64) (*(WORD*) BufferPos);
			BufferPos += 2;
		} else if (byteLen[i] == 2) 
		{  // 2 means 4 byte length
			RunLength[i] = (unsigned __int64) (*(DWORD*) BufferPos);
			BufferPos += 4;
		} else if (byteLen[i] == 3) 
		{  // 3 means 8 byte length
			RunLength[i] = (unsigned __int64) (*(unsigned __int64*) BufferPos);
			BufferPos += 8;
		}
	}

	// When last block is read eliminate padded zero run lengths at the end
	if (fEof && BufferPos >= BufferEndPos)
	{
		while (RunLength[LastIndex] == 0)
			LastIndex--;
		ValueAvailable = false;
	}
}


void ReloadBuffer(HANDLE fileHandle)
{
	DWORD len = (DWORD)(BufferEndPos - BufferPos);
	DWORD sizeRead, sizeToRead;
	BOOL ok;
	LARGE_INTEGER wantedStreamPos, newStreamPos;

	// save current file pointer:
	LARGE_INTEGER beforePos;
	wantedStreamPos.QuadPart = 0LL;
	ok = SetFilePointerEx(fileHandle, wantedStreamPos, &beforePos, FILE_CURRENT);

	// reload buffer
	memcpy(BitmapBuffer, BufferPos, len);

	BYTE* readPos = BitmapBuffer + len;
	sizeToRead = Len - len;
	if (StreamBytesConsumed + sizeToRead > StreamLength)
	{
		fEof = true;
		sizeToRead = StreamLength - StreamBytesConsumed;
	}
	wantedStreamPos.QuadPart = StreamPos + StreamBytesConsumed;
	ok = SetFilePointerEx(fileHandle, wantedStreamPos , &newStreamPos, FILE_BEGIN);
	ok = ReadFile(fileHandle, readPos, sizeToRead, &sizeRead, NULL);
	StreamBytesConsumed += sizeRead;
	BufferEndPos = readPos + sizeRead;
	BufferPos = BitmapBuffer;

	// restore previous file pointer
	ok = SetFilePointerEx(fileHandle, beforePos, NULL, FILE_BEGIN);
}

