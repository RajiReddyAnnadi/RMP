#include "stdafx.h"
#include <Windows.h>
#include <WinIoCtl.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <tchar.h> 
#include <string>
#include <map>
#include "zlib.h"
using namespace std;

void setLogger(wstring locname);
void show_record (USN_RECORD * record);
wstring findfilename(HANDLE hvol,DWORDLONG num);
int QueryJournal(wstring letter);
HRESULT BackupFile(_In_ const wstring& source, _In_ const wstring& destination);
void findnextrecord();
int BackupDirectoryTree(wstring sour,wstring destin,wstring device,string val) ;
void RenameFiles(wstring src,wstring dest);
void DeleteFiles(wstring src,wstring dest);
HRESULT RestoreFile(_In_ wstring& source, _In_ wstring& destination);
HRESULT RestoreEncryptedFile(_In_ wstring& source, _In_ wstring& destination, wstring secretKey);
HRESULT RestoreFileRetry(_In_ const wstring& source, _In_ const wstring& destination);
int RestoreDirectoryTree(wstring source, wstring destination, bool isEncrypted, wstring secretKey);
HRESULT ModifyPrivilege(IN LPCTSTR szPrivilege, IN BOOL fEnable);
extern "C"
{
__declspec(dllexport) ULONGLONG __cdecl getIRProgress();
}