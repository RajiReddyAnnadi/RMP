#ifndef Info_VSS
#define Info_VSS
#include <vss.h>
#include <vswriter.h>
#include <vsbackup.h>
#include <stdio.h>
#include <iostream>
#include <atlbase.h>
#include <vector>
#include <comdef.h>
using namespace std;

class WriterComp
{
public:
	wstring compPath;
	wstring compName; 
	WriterComp* compParent;
	bool isSelectable; 
	VSS_COMPONENT_TYPE compType; 
	int writer; 
	WriterComp::WriterComp()
	{
		compParent = NULL; 
	}
	bool isAncestorSelectable(void)
	{
		if (compParent == NULL)
		{
			return false; 
		}

		if (compParent->isSelectable)
		{
			return true; 
		}

		return compParent->isAncestorSelectable(); 
	}

	bool IsParentOf(WriterComp& potentialParent)
	{
		// The other component is our parent if our logical path is equal to 
		// their logical path plus their name. 
		wstring pathToCompare = potentialParent.compPath; 

		if (pathToCompare.length() > 0)
		{
			pathToCompare.append(TEXT("\\")); 
		}

		pathToCompare.append(potentialParent.compName); 

		return compPath.compare(pathToCompare) == 0; 
	}
};


class WriterClass
{
public:
	vector<WriterComp> components;
	vector <bool> includedComp;
	GUID instanceId;
	wstring compName; 
	GUID writerId; 
	void ComputeComponentTree(void)
	{
		includedComp.resize(components.size(), false);

		for (unsigned int iComponent = 0; iComponent < components.size(); ++iComponent)
		{
			WriterComp& current = components[iComponent];

			for (unsigned int iComponentParent = 0; iComponentParent < components.size(); ++iComponentParent)
			{
				if (iComponentParent == iComponent)
				{
					continue; 
				}

				WriterComp& potentialParent = components[iComponentParent]; 
				if (potentialParent.IsParentOf(current))
				{
					current.compParent=&potentialParent; 
					break; 
				}
			}
		}
	}
};


bool ShouldAddComponent(WriterComp& component);
const wchar_t* GetSnapshotDeviceName(int driveIndex);
int PrepareSnapshot(const wchar_t** volumeNames, int volumeCount);
int  InitVss();
void CloseVss();
bool VssSupport();
bool Is32BitProcessRunningInWow64();

void ReleaseSnapshot(bool wasAborted);
void ReportBackupResultsToWriters(bool successful);
void Cleanup();
#endif