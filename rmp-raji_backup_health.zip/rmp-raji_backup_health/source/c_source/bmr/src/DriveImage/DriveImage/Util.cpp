//Util.cpp
#include "stdafx.h"
#include <iostream>
#include "Util.h"
#include "Logger.h"
#include <strsafe.h>
typedef long NTSTATUS;

#define ENCRYPT_BLOCK_SIZE 16
#define KEYLENGTH  0x00800000
#define ENCRYPT_ALGORITHM CALG_AES_128

LPWSTR levelutil=NORMAL;
LPWSTR utilloc;
Logger *logutil;


static NtOpenDirectoryObject_t     NtOpenDirectoryObject     = NULL;
static NtQueryInformationFile_t    NtQueryInformationFile    = NULL;
static NtQueryDirectoryObject_t    NtQueryDirectoryObject    = NULL;
static NtOpenSymbolicLinkObject_t  NtOpenSymbolicLinkObject  = NULL;
static NtQuerySymbolicLinkObject_t NtQuerySymbolicLinkObject = NULL;
static RtlInitUnicodeString_t      RtlInitUnicodeString      = NULL;
static NtCreateFile_t              NtCreateFile              = NULL;
static GetVolumeNameForVolumeMountPointW_t GetVolumeNameForMountPointW = NULL;


void Initialize(wstring name) 
{
	HMODULE ntdll;
	HMODULE kernel32dll;
	OSVERSIONINFO Version;
    utilloc=(LPWSTR)name.c_str();
	logutil= new Logger(utilloc,(LPWSTR)levelutil);

	// We used to just depend on the pressence of ntdll.dll to tell if this is running on an NT-based system
	// but things like SysInternal's NTFS for Windows 98 adds this DLL, so now we actually do the official version
	// test and go from there.  This will also filter out Windows NT 4.0, which probably wouldn't work either.
	Version.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&Version);
	if (Version.dwMajorVersion >= 5 && Version.dwPlatformId == VER_PLATFORM_WIN32_NT) 
	{
		ntdll = GetModuleHandle(L"ntdll.dll");
		kernel32dll = GetModuleHandle(L"kernel32.dll");
		if (ntdll && kernel32dll)
		{
			NtOpenDirectoryObject     = (NtOpenDirectoryObject_t)    GetProcAddress(ntdll, "NtOpenDirectoryObject");
			NtQueryDirectoryObject    = (NtQueryDirectoryObject_t)   GetProcAddress(ntdll, "NtQueryDirectoryObject");
			NtOpenSymbolicLinkObject  = (NtOpenSymbolicLinkObject_t) GetProcAddress(ntdll, "NtOpenSymbolicLinkObject");
			NtQuerySymbolicLinkObject = (NtQuerySymbolicLinkObject_t)GetProcAddress(ntdll, "NtQuerySymbolicLinkObject");
			NtQueryInformationFile    = (NtQueryInformationFile_t)GetProcAddress(ntdll, "NtQueryInformationFile");
			NtCreateFile              = (NtCreateFile_t)             GetProcAddress(ntdll, "NtCreateFile");
			RtlInitUnicodeString      = (RtlInitUnicodeString_t)     GetProcAddress(ntdll, "RtlInitUnicodeString");
			GetVolumeNameForMountPointW= (GetVolumeNameForVolumeMountPointW_t)GetProcAddress(kernel32dll, "GetVolumeNameForVolumeMountPointW");


		}  // if (ntdll)
	}  // if (Version.dwMajorVersion >= 5)
}  // void __fastcall InitializeUtilityFunctions(void)

bool GetNTLinkDestination(LPCWSTR Source, wstring& linkDest)
{
	UNICODE_STRING usName;
	OBJECT_ATTRIBUTES oa;
	NTSTATUS nStatus;
	HANDLE hLink;
	wchar_t *buffer;
	bool retval = false;

	RtlInitUnicodeString(&usName, Source);
	oa.Length = sizeof(OBJECT_ATTRIBUTES);
	oa.RootDirectory = 0;
	oa.ObjectName = &usName;
	oa.Attributes = OBJ_CASE_INSENSITIVE;
	oa.SecurityDescriptor = NULL;
	oa.SecurityQualityOfService = NULL;
	nStatus = NtOpenSymbolicLinkObject(&hLink, SYMBOLIC_LINK_QUERY, &oa);
	if (NT_SUCCESS(nStatus))
	{
		buffer = (wchar_t *)malloc(2048);
		usName.Length = 0;
		usName.MaximumLength = 1024;
		usName.Buffer = buffer;
		nStatus = NtQuerySymbolicLinkObject(hLink, &usName, NULL);
		usName.Buffer[usName.Length/2] = 0;
		if (NT_SUCCESS(nStatus))
			linkDest = usName.Buffer;
		free(buffer);
		retval = true;
	}  // if (NTSUCCESS(nStatus))
	return retval;
}

bool GetVolumeNameForMountPoint(LPCWSTR lpszVolumeMountPoint, LPWSTR lpszVolumeName, DWORD cchBufferLength)
{
	return GetVolumeNameForMountPointW(lpszVolumeMountPoint, lpszVolumeName, cchBufferLength) != FALSE;
}

long QueryInfoFile(HANDLE hvol,wstring &path)
{
	IO_STATUS_BLOCK ioStatus; 
	PFILE_NAME_INFORMATION pNameInfo = (PFILE_NAME_INFORMATION)malloc(MAX_PATH * 2 * 2); 
	DWORD dwInfoSize = MAX_PATH * 2 * 2; 
	NTSTATUS ntstatus;
	ntstatus=NtQueryInformationFile(hvol, &ioStatus, pNameInfo,  
		dwInfoSize, FileNameInformation);
	if (NtQueryInformationFile(hvol, &ioStatus, pNameInfo,  
		dwInfoSize, FileNameInformation) == 0) 
	{ 
		// Get the file name and print it 
		WCHAR wszFileName[MAX_PATH + 1]; 
		StringCchCopyNW(wszFileName, MAX_PATH + 1,  
			pNameInfo->FileName, /*must be WCHAR*/ 
			pNameInfo->FileNameLength /*in bytes*/ / 2);
		path=wszFileName;
		return 0;
	} 
	return 1;
}

int DirectoryObject(LPCWSTR Directory, vector<wstring>& entries)
{
	UNICODE_STRING usDir;
	OBJECT_ATTRIBUTES oa;
	HANDLE hDeviceDir;
	NTSTATUS nStatus;
	OBJDIR_INFORMATION *DirInfo;
	DWORD ind;
	wstring Error;

	RtlInitUnicodeString(&usDir, Directory);
	oa.Length = sizeof(OBJECT_ATTRIBUTES);
	oa.ObjectName = &usDir;
	oa.Attributes = OBJ_CASE_INSENSITIVE;
	oa.SecurityDescriptor = NULL;
	oa.SecurityQualityOfService = NULL;
	oa.RootDirectory = 0;
	nStatus = NtOpenDirectoryObject(&hDeviceDir, STANDARD_RIGHTS_READ | DIRECTORY_QUERY, &oa);
	if (!NT_SUCCESS(nStatus)) 
	{ 
		logutil->log(NORMAL,L"Error occurred during listing drives\n");
		return 1;
	}  // if (!NT_SUCCESS(nStatus))
	DirInfo = (OBJDIR_INFORMATION *)malloc(2048);
	ind = 0;
	while (NT_SUCCESS(NtQueryDirectoryObject(hDeviceDir, DirInfo, 1024, true, false, &ind, NULL)))
	{
		wstring entry = wstring(Directory) + L"\\" + DirInfo->ObjectName.Buffer;	  
		entries.push_back(entry);
	}
	CloseHandle(hDeviceDir);
	free(DirInfo);
	return 0;
} 

long OpenAPI(HANDLE* hFile, LPCWSTR FileName, ACCESS_MASK DesiredAccess, ULONG FileAttributes, ULONG ShareAccess, 
			 ULONG CreateDisposition, ULONG CreateOptions)
{
	UNICODE_STRING usFileName;
	OBJECT_ATTRIBUTES oa;
	IO_STATUS_BLOCK ios;
	NTSTATUS ntStatus;


	*hFile = INVALID_HANDLE_VALUE;
	RtlInitUnicodeString(&usFileName, FileName);
	ZeroMemory(&ios, sizeof(ios));
	oa.Length = sizeof(oa);
	oa.RootDirectory = 0;
	oa.ObjectName = &usFileName;
	oa.Attributes = OBJ_CASE_INSENSITIVE;
	oa.SecurityDescriptor = NULL;
	oa.SecurityQualityOfService = NULL;
	ntStatus = NtCreateFile(hFile, DesiredAccess, &oa, &ios, NULL, FileAttributes, ShareAccess, 
		CreateDisposition, CreateOptions, NULL, 0);
	return ntStatus;
}



HCRYPTKEY generateHashKey(LPTSTR pszPassword) {
	HCRYPTPROV hCryptProv = NULL;
	HCRYPTKEY hKey = NULL;
	HCRYPTHASH hHash = NULL;
	bool CryptAcquireContextStatus = false;
	if (CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, 0)) {
		CryptAcquireContextStatus = true;
	}
	else {
		logutil->log(NORMAL, L"CryptAcquireContext failed\n");
		if (CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, CRYPT_NEWKEYSET)) {
			CryptAcquireContextStatus = true;
		}
		else {
			logutil->log(NORMAL, L"CryptAcquireContext failed again\n");
			return -1;
		}
	}
	if (CryptAcquireContextStatus) {
		if (CryptCreateHash(hCryptProv, CALG_MD5, 0, 0, &hHash)) {
			if (CryptHashData(hHash, (BYTE *)pszPassword, lstrlen(pszPassword), 0)) {
				if (CryptDeriveKey(hCryptProv, ENCRYPT_ALGORITHM, hHash, KEYLENGTH, &hKey)) {
					return hKey;
				}
				else {
					logutil->log(NORMAL, L"CryptDeriveKey failed\n");
					return -1;
				}
			}
			else {
				logutil->log(NORMAL, L"CryptHashData failed\n");
				return -1;
			}
		}
		else {
			logutil->log(NORMAL, L"CryptCreateHash failed\n");
			return -1;
		}
	}
}