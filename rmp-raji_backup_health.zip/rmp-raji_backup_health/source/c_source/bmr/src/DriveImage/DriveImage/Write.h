#ifndef Write_HEADER
#define Write_HEADER
#include "stdafx.h"
#include <stdio.h>
#include <Windows.h>
#include <iostream>
#include <string>
#include "Bitmap.h"
#include "Header.h"
#include "zlib.h"

using namespace std;
class Queuecode;

class Write : public Thread
{
public:
	Write(Queuecode *inputQueue,  Queuecode *outputQueue,HANDLE drivehan,HANDLE filehan,unsigned __int64 partsize,unsigned int pos,unsigned clustersize,int val,wstring name,wstring src, wstring secretKey);
	virtual DWORD Execute();
	Queuecode *inpQueue;
	Queuecode *outQueue;
	HANDLE fhan;
	HANDLE dhan;
	//HANDLE bhan;
	int check;
        int wError;
        wstring src;
        wstring secretKey;
        gzFile ofile;
	unsigned __int64 ptnsize;
	unsigned int position;
	unsigned clusterSize;
	DWORD WriteData();
        DWORD WriteRestoreData();
	DWORD  Writeusedonly();
	DWORD FileWrite(void * buffer, unsigned nLength, unsigned *nbytesRead);
        DWORD CompressAndWrite(void *buffer, unsigned nLength, unsigned *nBytesWritten);
        DWORD WriteEncryptedRestoreData();
}; 

	ULONGLONG getProgress();
#endif