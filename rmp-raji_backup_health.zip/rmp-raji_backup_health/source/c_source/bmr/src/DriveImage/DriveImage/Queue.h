#ifndef Queuecode_HEADER
#define Queuecode_HEADER
#include "stdafx.h"
#include <stdio.h>
#include <iostream>
#include <string> 
#include <Windows.h>
#include <list>
#include <synchapi.h>
using namespace std;

class BufferChunk
{
public:
	BufferChunk(int size);
	void setend(bool val)
	{
		fileEnd=val;
	}
	bool getend()
	{
		return fileEnd;
	}
	void *GetData() 
	{
		return Data;
	}
	unsigned GetSize()
	{ 
		return  UsedSize; 
	}
	void SetSize(unsigned newSize) 
	{
		UsedSize = newSize;
	}

private:
	unsigned UsedSize;
	bool fileEnd;
	BYTE *Data;
};

class Queuecode {
public:
	Queuecode(wstring name);
	Queuecode(int ChunkSize, int ChunkCount);
    ~Queuecode();
	BufferChunk* GetChunk();
	void ReleaseChunk(BufferChunk *Chunk);

private:

	CRITICAL_SECTION CriticalSec;
	list<BufferChunk*> Chunks;
	unsigned ChunkCount;         // Must be power of two
	HANDLE han;
};
#endif