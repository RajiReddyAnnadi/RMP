#include "stdafx.h"
#include "Write.h"
extern "C"
{
__declspec(dllexport) ULONGLONG __cdecl get_Progress()
{
	return getProgress();
}
}
