#ifndef Read_HEADER
#define Read_HEADER
#include "stdafx.h"
#include <stdio.h>
#include <Windows.h>
#include <iostream>
#include <string>
#include "Header.h"
#include "Bitmap.h"
#include "zlib.h"

using namespace std;
class Queuecode;

class Read : public Thread
{
public:
	Read(Queuecode *inputQueue,  Queuecode *outputQueue,HANDLE drivehan,HANDLE filehan,unsigned __int64 partsize,unsigned int pos,unsigned clustersize,bool val,unsigned __int64 offset,wstring name,wstring src);
	virtual DWORD Execute();
	Queuecode *inpQueue;
	Queuecode *outQueue;
	HANDLE dhan;
	HANDLE fhan;
	//HANDLE bhan;
	BOOL check;
        int rError;
        wstring src;
        gzFile ifile;
	unsigned __int64 ptnsize;
	unsigned int position;
	unsigned clusterSize;
	unsigned __int64 off;
	DWORD ReadData();
	DWORD  Readusedonly();
        DWORD ReadEncryptedData();
	DWORD FileRead(void * buffer, unsigned nLength, unsigned *nbytesRead);
    DWORD DecompressAndRead(void * buffer, unsigned nLength, unsigned *nbytesRead);
}; 
#endif