//Read.cpp
#include "stdafx.h"
#include <stdio.h>
#include "Read.h"
#include "Queue.h"
#include "Logger.h"
#include <io.h>
#include <fcntl.h>
LPWSTR levelread = NORMAL;
LPWSTR readloc;
Logger *logread;

Read::Read(Queuecode *inputQueue, Queuecode *outputQueue, HANDLE drivehan, HANDLE filehan, unsigned __int64 partsize, unsigned int pos, unsigned clustersize, bool val, unsigned __int64 offset,wstring name, wstring src) : Thread(CREATE_SUSPENDED) {
    readloc = (LPWSTR) name.c_str();
    logread = new Logger(readloc, (LPWSTR) levelread);	
    this->inpQueue = inputQueue;
    this->outQueue = outputQueue;
    this->dhan = drivehan;
    this->fhan = filehan;
    //this->bhan=backuphan;
    this->ptnsize = partsize;
    this->position = pos;
    this->clusterSize = clustersize;
    this->check = val;
    this->off = offset;
    this->rError = 0;
    this->src = src;
}

DWORD Read::Execute() {
    try {
        DWORD retVal;
        if (check) {
            //retVal = Readusedonly();   //ReadUsedOnly is only used in Backup code;Not needed here,so changing it for encryption
            retVal = ReadEncryptedData(); 
            if(logread != NULL)
            delete logread;
            return retVal;
        } else {
            //string decompress(src.begin(), src.end());
            //this->ifile = gzopen(decompress.c_str(), "rb");
			int a = _wopen(src.c_str(),_O_RDONLY|_O_BINARY);
            if(a==-1){
                logread->log(NORMAL, L"wopen error: %s\n",strerror (errno));
            }
		this->ifile = gzdopen(a,"rb");
            if(!ifile){
                logread->log(NORMAL, L"gzdopen error %s\n",strerror (errno));
            }
            retVal = ReadData();
            gzclose(ifile);           
            if(logread != NULL)
            delete logread;
            return retVal;
        }

    } catch (exception &e) {
        return E_FAIL;
    }
}

DWORD Read::Readusedonly() {
    unsigned __int64 runLength;
    unsigned __int64 seekPos = 0;
    unsigned __int64 toRead;
    unsigned bytesToRead, bytesRead, remainingBufferSize, bufferBytesUsed = 0;
    unsigned blksize = 2097152;
    BufferChunk *Chunk1 = inpQueue->GetChunk(); // may block
    if (Chunk1 == NULL) {
        rError = 1;
        return 1;
    }
    BYTE* Chunk = (BYTE*) Chunk1->GetData();
    DWORD Pos;
    bool ValueAvailable;
    unsigned LastIndex;
    GetValues(Pos, ValueAvailable, LastIndex);
    remainingBufferSize = blksize;
    while (!((!ValueAvailable) && Pos > LastIndex)) {
        // read run length of used clusters
        runLength = GetNextRunLength(fhan);
        GetValues(Pos, ValueAvailable, LastIndex);
        toRead = clusterSize * runLength;
        while (toRead > 0) {
            if (toRead < remainingBufferSize) {
                bytesToRead = (unsigned) toRead;
                runLength = 0;
            }
            else {
                bytesToRead = remainingBufferSize;
                runLength -= remainingBufferSize / clusterSize;
            }
            FileRead(Chunk, bytesToRead, &bytesRead);
            seekPos += bytesRead;
            Chunk += bytesRead;
            bufferBytesUsed += bytesRead;
            remainingBufferSize -= bytesRead;
            toRead -= bytesRead;
            Chunk1->SetSize(bufferBytesUsed);
            if (remainingBufferSize <= 0) {
                // release current block, because it is full and get a new block.
                outQueue->ReleaseChunk(Chunk1);
                Chunk1 = inpQueue->GetChunk(); // may block
                if (Chunk1 == NULL) {
                    rError = 1;
                    return 1;
                }
                Chunk = (BYTE*) Chunk1->GetData();
                remainingBufferSize = Chunk1->GetSize();
                bufferBytesUsed = 0;
            }
        } // inner while


        // read run length of free clusters
        runLength = GetNextRunLength(fhan);
        seekPos += clusterSize * runLength; // skip free clusters  

        GetValues(Pos, ValueAvailable, LastIndex);

        LARGE_INTEGER pos, newOffset;
        pos.QuadPart = seekPos;
        BOOL bSuccess = SetFilePointerEx(dhan, pos, &newOffset, FILE_BEGIN);
    } // outer while

    Chunk1->setend(true);
    outQueue->ReleaseChunk(Chunk1);
    return 0;
}

DWORD Read::ReadData() {
    bool bEOF = false;
    bool bSkipUnallocated = true;
    unsigned nBytesRead;
    // LARGE_INTEGER pos, newOffset;
    //pos.QuadPart = off;
    //BOOL bSuccess = SetFilePointerEx(bhan, pos, &newOffset, FILE_BEGIN);
    //position = newOffset.QuadPart;
    // position=gzseek(ifile,off,SEEK_SET);
    while (!bEOF) {
        BufferChunk *chunk1 = inpQueue->GetChunk(); // may block
        if(chunk1==NULL){
        rError=1;
        return 1;
    }
        DecompressAndRead(chunk1->GetData(), chunk1->GetSize(), &nBytesRead);
        //FileRead(chunk1->GetData(), chunk1->GetSize(), &nBytesRead);
        // If we didn't get as much data as we expected, then we're at the end of the file.  Set the EOF marker
        // in the buffer chunk so the write thread knows this is the last.
        if (chunk1->GetSize() != nBytesRead) {
            bEOF = true;
            chunk1->setend(true);
        }
        chunk1->SetSize(nBytesRead);
        outQueue->ReleaseChunk(chunk1);
    }
    return 0;
}

DWORD Read::ReadEncryptedData() {
    bool bEOF = false;
    unsigned nBytesRead;
    while (!bEOF) {
        BufferChunk *chunk1 = inpQueue->GetChunk(); // may block
        if (chunk1 == NULL) {
            rError = 1;
            return 1;
        }
        FileRead(chunk1->GetData(), chunk1->GetSize(), &nBytesRead);
        // If we didn't get as much data as we expected, then we're at the end of the file.  Set the EOF marker
        // in the buffer chunk so the write thread knows this is the last.
        if (chunk1->GetSize() != nBytesRead) {
            bEOF = true;
            chunk1->setend(true);
        }
        chunk1->SetSize(nBytesRead);
        outQueue->ReleaseChunk(chunk1);
    }
    return 0;
}

DWORD Read::FileRead(void * buffer, unsigned nLength, unsigned *nbytesRead) {
    BOOL bSuccess;
    DWORD nbytesReadTemp;
    if ((unsigned __int64) nLength > ptnsize - position) // we will read beyond end of partition--> results in error see above
    {
        nLength = (DWORD) (ptnsize - position);
    }

    bSuccess = ReadFile(dhan, buffer, nLength, &nbytesReadTemp, NULL);
    if (!bSuccess) {
        DWORD error = GetLastError();
        rError = error;
        cout << "Reading drive data failed with error" << error << endl;
    }
    position += nbytesReadTemp;
    *nbytesRead = nbytesReadTemp;
    return 0;
}

DWORD Read::DecompressAndRead(void * buffer, unsigned nLength, unsigned *nbytesRead) {
    DWORD nbytesReadTemp;
    if ((unsigned __int64) nLength > ptnsize - position) // we will read beyond end of partition--> results in error see above
    {
        nLength = (DWORD) (ptnsize - position);
    }
    nbytesReadTemp = gzread(ifile, buffer, nLength);
    if (nbytesReadTemp == -1) {
        DWORD error = GetLastError();
        rError = error;
        logread->log(NORMAL, L"Reading drive data failed with error %d\n", error);
    }

    position += nbytesReadTemp;
    *nbytesRead = nbytesReadTemp;
    return 0;
}
