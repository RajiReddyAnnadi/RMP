#include "stdafx.h"
#include "Source.h" 
#include <Shlwapi.h>
#include <shlobj.h>
#include <psapi.h>
#include <atlstr.h>
#include <io.h>
#include <fcntl.h>
#include "Util.h"
#include "Logger.h"

#define BUFSIZE MAX_PATH
#define BUF_LEN 4096

USN maxusn;
HANDLE hVol, hVol1;
wstring name1;
LPWSTR levelsrc = NORMAL;
LPWSTR srcloc;
Logger *logger;
ULONGLONG Iprogress = 0;
CREATE_USN_JOURNAL_DATA CreateData = {1000, 100};
USN_JOURNAL_DATA JournalData;
READ_USN_JOURNAL_DATA ReadData;
PUSN_RECORD UsnRecord;
DWORD dwBytes;
DWORD dwRetBytes;
CHAR Buffer[BUF_LEN];

void show_record(USN_RECORD * record) {
    void * buffer;
    MFT_ENUM_DATA_V0 mft_enum_data;
    DWORD bytecount = 1;
    USN_RECORD * parent_record;
    WCHAR * filename;
    WCHAR * filenameend;
    DWORDLONG num = record->FileReferenceNumber;
    filename = (WCHAR *) (((BYTE *) record) + record->FileNameOffset);
    filenameend = (WCHAR *) (((BYTE *) record) + record->FileNameOffset + record->FileNameLength);

    name1.insert(0, filename, 0, filenameend - filename);
    buffer = VirtualAlloc(NULL, BUF_LEN, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);

    if (buffer == NULL) {
        logger->log(NORMAL, L"VirtualAlloc failed with error %d\n", GetLastError());
        return;
    }

    mft_enum_data.StartFileReferenceNumber = record->ParentFileReferenceNumber;
    mft_enum_data.LowUsn = 0;
    mft_enum_data.HighUsn = maxusn;

    if (!DeviceIoControl(hVol1, FSCTL_ENUM_USN_DATA, &mft_enum_data, sizeof (mft_enum_data), buffer, BUF_LEN, &bytecount, NULL)) {
        logger->log(NORMAL, L"Enumerating usn records failed with error %d\n", GetLastError());
        return;
    }

    parent_record = (USN_RECORD *) ((USN *) buffer + 1);

    if (parent_record->FileReferenceNumber != record->ParentFileReferenceNumber) {
        return;
    }
    name1.insert(0, L"\\");
    show_record(parent_record);
}

wstring findfilename(HANDLE hvol, DWORDLONG num) {

    HRESULT hResult;
    FILE_ID_DESCRIPTOR FileID;
    FileID.FileId.QuadPart = num;
    FileID.Type = FileIdType;
    FileID.dwSize = sizeof (FileID);
    HANDLE hFile = OpenFileById(hvol,
            &FileID,
            GENERIC_READ,
            FILE_SHARE_READ,
            NULL,
            0);
    if (hFile == INVALID_HANDLE_VALUE) {
        hResult = HRESULT_FROM_WIN32(GetLastError());
        logger->log(NORMAL, L"OpenFileById failed with error %d\n", hResult);
        return L"failed";
    }
    wstring Path;
    QueryInfoFile(hFile, Path);
    CloseHandle(hFile);
    return Path;


}

HRESULT BackupFile(_In_ const wstring& source, _In_ const wstring& destination) {
    HRESULT hr = S_OK;
    HANDLE hSourceFile = ::CreateFile(
            source.c_str(),
            GENERIC_READ,
            FILE_SHARE_READ,
            NULL,
            OPEN_EXISTING,
            FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_BACKUP_SEMANTICS,
            NULL);

    if (hSourceFile == INVALID_HANDLE_VALUE) {
        logger->log(NORMAL, L"CreateFile failed with error %d\n", GetLastError());
        hr = HRESULT_FROM_WIN32(GetLastError());
        return hr;
    }
    const DWORD DEFAULT_BUFFER_SIZE = 4086;
    DWORD bytesRead = 0, bytesWritten = 0;
    BYTE buffer[DEFAULT_BUFFER_SIZE];
    LPVOID context = NULL;

    HANDLE hDestinationFile = ::CreateFile(
            destination.c_str(),
            GENERIC_WRITE,
            FILE_SHARE_READ,
            NULL,
            CREATE_ALWAYS,
            FILE_FLAG_BACKUP_SEMANTICS,
            NULL);
    if (hDestinationFile == INVALID_HANDLE_VALUE) {
        logger->log(NORMAL, L"CreateFile failed with error %d\n", GetLastError());
        hr = HRESULT_FROM_WIN32(GetLastError());
        return hr;
    }

    while (BackupRead(hSourceFile, buffer, DEFAULT_BUFFER_SIZE, &bytesRead, FALSE, TRUE, &context) && bytesRead > 0) {
        if (!WriteFile(hDestinationFile, buffer, bytesRead, &bytesWritten, NULL)) {
            logger->log(NORMAL, L"WriteFile failed with error %d\n", GetLastError());
            break;
        }

        if (bytesRead != bytesWritten) {
            logger->log(NORMAL, L"WriteFile wrote less number of bytes than expected\n");
            break;
        }
    }
    BackupRead(hSourceFile, NULL, 0, NULL, TRUE, TRUE, &context);
    CloseHandle(hSourceFile);
    return hr;
}

void findnextrecord() {
    // Update starting USN for next call
    ReadData.StartUsn = *(USN *) & Buffer;
    memset(Buffer, 0, BUF_LEN);
    if (!DeviceIoControl(hVol1,
            FSCTL_READ_USN_JOURNAL,
            &ReadData,
            sizeof (ReadData),
            &Buffer,
            BUF_LEN,
            &dwBytes,
            NULL)) {
        logger->log(NORMAL, L"Read journal failed with error %d\n", GetLastError());
        return;
    }
    dwRetBytes = dwBytes - sizeof (USN);
    // Find the first record
    UsnRecord = (PUSN_RECORD) (((PUCHAR) Buffer) + sizeof (USN));
    if (UsnRecord->Usn >= JournalData.NextUsn) {
        return;
    }
}

void setLogger(wstring locname) {
    srcloc = (LPWSTR) locname.c_str();
    logger = new Logger(srcloc, (LPWSTR) levelsrc);
}

int QueryJournal(wstring letter) {
    wstring name = L"\\\\.\\";
    name += letter;
    hVol1 = CreateFile(name.c_str(),
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            NULL,
            OPEN_EXISTING,
            0,
            NULL);

    if (hVol1 == INVALID_HANDLE_VALUE) {
        logger->log(NORMAL, L"CreateFile failed with error %d\n", GetLastError());
        return 1;
    }
    if (!DeviceIoControl(hVol1,
            FSCTL_QUERY_USN_JOURNAL,
            NULL,
            0,
            &JournalData,
            sizeof (JournalData),
            &dwBytes,
            NULL)) {
        logger->log(NORMAL, L"Query journal failed with error %d ,so we create new journal\n", GetLastError());
        if (DeviceIoControl(hVol1,
                FSCTL_CREATE_USN_JOURNAL,
                &CreateData,
                sizeof (CreateData),
                NULL,
                0,
                &dwBytes,
                NULL))
            logger->log(NORMAL, L"Journal creation successful\n");

        if (!DeviceIoControl(hVol1,
                FSCTL_QUERY_USN_JOURNAL,
                NULL,
                0,
                &JournalData,
                sizeof (JournalData),
                &dwBytes,
                NULL)) {
            logger->log(NORMAL, L"Error while querying journal\n");
            return 1;
        }
    }
    return JournalData.NextUsn;
}

int BackupDirectoryTree(wstring source, wstring destination, wstring device, string val) {
    string delimiter = "--";
    int flag = 0;
    if (!::CreateDirectory(destination.c_str(), NULL)) {
        DWORD error = GetLastError();
        if (error != ERROR_ALREADY_EXISTS) {
            logger->log(NORMAL, L"CreateDirectory failed with error %d\n", GetLastError());
        }
    }

    HANDLE h;
    wstring fn = destination;
    fn += '\\';
    fn += L"rename_file.txt";
    h = CreateFile(fn.c_str(),
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            NULL,
            CREATE_ALWAYS,
            FILE_ATTRIBUTE_HIDDEN,
            NULL);
    CloseHandle(h);
    HANDLE h1;
    wstring fn1 = destination;
    fn1 += '\\';
    fn1 += L"delete_file.txt";
    h1 = CreateFile(fn1.c_str(),
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            NULL,
            CREATE_ALWAYS,
            FILE_ATTRIBUTE_HIDDEN,
            NULL);
    CloseHandle(h1);


    ofstream delete_file(fn1, ios::out | ios::app);
    ofstream rename_file(fn, ios::out | ios::app);



    hVol = CreateFile(device.c_str(),
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            NULL,
            OPEN_EXISTING,
            0,
            NULL);

    if (hVol == INVALID_HANDLE_VALUE) {
        logger->log(NORMAL, L"Opening snapshot failed with error %d\n", GetLastError());
        return 1;
    }

    int startval = stoi(val, nullptr, 10);
    ReadData.UsnJournalID = JournalData.UsnJournalID;
    ReadData.BytesToWaitFor = 0;
    ReadData.MaxMajorVersion = 2;
    ReadData.MinMajorVersion = 2;
    ReadData.ReasonMask = USN_REASON_FILE_CREATE | USN_REASON_RENAME_NEW_NAME | USN_REASON_RENAME_OLD_NAME | USN_REASON_DATA_EXTEND | USN_REASON_DATA_OVERWRITE | USN_REASON_DATA_TRUNCATION | USN_REASON_FILE_DELETE | USN_REASON_CLOSE;
    ReadData.ReturnOnlyOnClose = FALSE;
    ReadData.StartUsn = startval;
    ReadData.Timeout = 0;
    maxusn = JournalData.MaxUsn;
    memset(Buffer, 0, BUF_LEN);
    if (!DeviceIoControl(hVol1,
            FSCTL_READ_USN_JOURNAL,
            &ReadData,
            sizeof (ReadData),
            &Buffer,
            BUF_LEN,
            &dwBytes,
            NULL)) {
        logger->log(NORMAL, L"Read journal failed with error %d\n", GetLastError());
        return 1;
    }
    dwRetBytes = dwBytes - sizeof (USN);
    // Find the first record
    UsnRecord = (PUSN_RECORD) (((PUCHAR) Buffer) + sizeof (USN));
    // This loop could go on for a long time, given the current buffer size.
    while ((dwRetBytes > 0)&&(UsnRecord->Usn < JournalData.NextUsn)) {


        if ((UsnRecord->Reason == USN_REASON_FILE_CREATE)&&(UsnRecord->Usn < JournalData.NextUsn)) {

            wstring w(UsnRecord->FileName);
            string recycle(w.begin(), w.end());

            if (recycle.compare(0, 2, "$I") == 0) {
                show_record(UsnRecord);
                string name;
                string tmp;
                name.assign(name1.begin(), name1.end());
                const size_t pos = name.find('\\');
                if (std::string::npos != pos)
                    tmp = name.substr(0, pos);
                if (_stricmp(tmp.c_str(), "$recycle.bin") == 0) {
                    while ((UsnRecord->Reason) != USN_REASON_RENAME_OLD_NAME) {
                        dwRetBytes -= UsnRecord->RecordLength;
                        // Find the next record
                        if (dwRetBytes <= 0)
                            findnextrecord();
                        else
                            UsnRecord = (PUSN_RECORD) (((PCHAR) UsnRecord) + UsnRecord->RecordLength);
                        if ((UsnRecord->Reason == USN_REASON_RENAME_OLD_NAME)&&(UsnRecord->Usn < JournalData.NextUsn)) {
                            name1.clear();
                            show_record(UsnRecord);
                            string name;
                            name.assign(name1.begin(), name1.end());
                            delete_file.write(name.c_str(), strlen(name.c_str()));
                            delete_file << endl;
                            name1.clear();
                        }
                    }
                    dwRetBytes -= UsnRecord->RecordLength;
                    // Find the next record
                    if (dwRetBytes <= 0)
                        findnextrecord();
                    else
                        UsnRecord = (PUSN_RECORD) (((PCHAR) UsnRecord) + UsnRecord->RecordLength);
                }
            } else {
                show_record(UsnRecord);
                DWORDLONG num = UsnRecord->FileReferenceNumber;
                wstring Path;
                Path = findfilename(hVol, num);
                wstring nsrc;
                nsrc = device;
                nsrc += Path;
                wstring ndst;
                ndst = destination;
                ndst += Path;
                name1.clear();
                wstring ndst1;
                const size_t pos = ndst.rfind('\\');
                if (std::string::npos != pos)
                    ndst1 = ndst.substr(0, pos);

                if ((PathFileExists(nsrc.c_str()))&&(!PathFileExists(ndst.c_str()))) {
                    if (UsnRecord->FileAttributes == 0x10)
                        SHCreateDirectoryEx(NULL, ndst.c_str(), NULL);
                    else {
                        SHCreateDirectoryEx(NULL, ndst1.c_str(), NULL);
                        BackupFile(nsrc, ndst);
                    }
                }
            }
        }

        if ((UsnRecord->Reason == USN_REASON_RENAME_OLD_NAME)&&(UsnRecord->Usn < JournalData.NextUsn)) {
            show_record(UsnRecord);
            string name;
            name.assign(name1.begin(), name1.end());
            name1.clear();
            while ((UsnRecord->Reason) != USN_REASON_RENAME_NEW_NAME) {
                dwRetBytes -= UsnRecord->RecordLength;
                // Find the next record
                if (dwRetBytes <= 0)
                    findnextrecord();
                else
                    UsnRecord = (PUSN_RECORD) (((PCHAR) UsnRecord) + UsnRecord->RecordLength);
                show_record(UsnRecord);
                name1.clear();
                if ((UsnRecord->Reason == USN_REASON_RENAME_NEW_NAME)&&(UsnRecord->Usn < JournalData.NextUsn)) {
                    show_record(UsnRecord);
                    rename_file.write(name.c_str(), strlen(name.c_str()));
                    rename_file << "--";
                    string name2;
                    name2.assign(name1.begin(), name1.end());
                    rename_file.write(name2.c_str(), strlen(name2.c_str()));
                    rename_file << endl;
                    name1.clear();
                }
            }
        }

        if (((UsnRecord->Reason & USN_REASON_DATA_OVERWRITE) | (UsnRecord->Reason & USN_REASON_DATA_EXTEND) | (UsnRecord->Reason & USN_REASON_DATA_TRUNCATION))&&(UsnRecord->Usn < JournalData.NextUsn)) {
            show_record(UsnRecord);
            DWORDLONG num = UsnRecord->FileReferenceNumber;
            wstring Path;
            Path = findfilename(hVol, num);
            wstring newS;
            newS = device;
            newS += Path;
            wstring newD;
            newD = destination;
            newD += Path;

            if ((!PathFileExists(newD.c_str()))&&(PathFileExists(newS.c_str()))) {

                wstring newDest1;
                const size_t pos = newD.rfind('\\');
                if (std::string::npos != pos) {
                    newDest1 = newD.substr(0, pos);
                }
                SHCreateDirectoryEx(NULL, newDest1.c_str(), NULL);
                BackupFile(newS, newD);
            }
            name1.clear();
        }

        if ((UsnRecord->Reason == (USN_REASON_FILE_DELETE | USN_REASON_CLOSE))&&(UsnRecord->Usn < JournalData.NextUsn)) {
            show_record(UsnRecord);
            string name;
            name.assign(name1.begin(), name1.end());
            delete_file.write(name.c_str(), strlen(name.c_str()));
            delete_file << endl;
            name1.clear();
        }
        dwRetBytes -= UsnRecord->RecordLength;
        // Find the next record
        if (dwRetBytes <= 0)
            findnextrecord();
        else
            UsnRecord = (PUSN_RECORD) (((PCHAR) UsnRecord) + UsnRecord->RecordLength);
    }


    CloseHandle(hVol);
    CloseHandle(hVol1);
    delete_file.close();
    rename_file.close();
    return 0;
}

HRESULT RestoreEncryptedFile(_In_ wstring& source, _In_ wstring& destination, wstring secretKey) {
    const DWORD DEFAULT_BUFFER_SIZE = 4096;
    unsigned char *input = new unsigned char[DEFAULT_BUFFER_SIZE];
    unsigned char *output = new unsigned char[DEFAULT_BUFFER_SIZE];
    DWORD dwBlockLen;
    DWORD dwCount;
    FILE *in;
    int ret;
    z_stream strm;
    HRESULT hr = S_OK;

    HCRYPTKEY hKey = generateHashKey(&secretKey[0]);
    if (hKey == -1) {
        logger->log(NORMAL, L"hkey is -1\n");
        if (input)
            delete[] input;
        if (output)
            delete[] output;
        return E_HANDLE;
    }
    int fd = _wopen(source.c_str(), _O_RDONLY | _O_BINARY);
    if (fd == -1) {
        int errsv = errno;
        logger->log(NORMAL, L"_wopen: could not open for reading %d\n", errsv);
        return E_HANDLE;
    }
    in = _fdopen(fd, "rb");
    if (in == NULL) {
        logger->log(NORMAL, L"_fdopen: could not open %ws\n", source.c_str());
        return E_HANDLE;
    }
    HANDLE hDestinationFile = CreateFile(destination.c_str(), FILE_WRITE_DATA, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

    if (hDestinationFile == INVALID_HANDLE_VALUE) {
        hr = HRESULT_FROM_WIN32(GetLastError());
        logger->log(NORMAL, L"RestoreEncryptedFile invalid handle %d\n", hr);
        if (input)
            delete[] input;
        if (output)
            delete[] output;
        return hr;
    }

    /* initialize file and inflate state to start there */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = inflateInit2(&strm, 47); /* raw inflate */
    if (ret != Z_OK) {
        logger->log(NORMAL, L"inflateInit2 failed %d\n", ret);
        if (input)
            delete[] input;
        if (output)
            delete[] output;
        return E_HANDLE;
    }

    bool fEOF = false;
    while (!fEOF) {
        memset(input, 0, DEFAULT_BUFFER_SIZE);
        dwBlockLen = fread(input, 1, DEFAULT_BUFFER_SIZE, in);
        if (feof(in)) {
            ret = Z_ERRNO;
            logger->log(NORMAL, L"end of file\n");
            fEOF = true;
        }
        if (ferror(in)) {
            ret = Z_ERRNO;
            logger->log(NORMAL, L"Z_ERRNO failed\n");
            if (input)
                delete[] input;
            if (output)
                delete[] output;
            return E_HANDLE;
        }
        if (dwBlockLen < DEFAULT_BUFFER_SIZE) {
            fEOF = TRUE;
        }
        if (input != NULL) {
            if (CryptDecrypt(hKey, NULL, fEOF, 0, input, &dwBlockLen)) {
                strm.avail_in = dwBlockLen;
            } else {
                hr = HRESULT_FROM_WIN32(GetLastError());
                logger->log(NORMAL, L"cryptdecrypt failed %d\n", hr);
                if (input)
                    delete[] input;
                if (output)
                    delete[] output;
                return hr;
            }
        }
        strm.next_in = input;

        do {
            strm.avail_out = DEFAULT_BUFFER_SIZE;
            strm.next_out = output;
            ret = inflate(&strm, Z_NO_FLUSH); /* normal inflate */
            if (ret == Z_NEED_DICT) {
                logger->log(NORMAL, L"Z_NEED_DICT\n");
                ret = Z_DATA_ERROR;
            }
            if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR) {
                logger->log(NORMAL, L"Z_MEM_ERROR or Z_DATA_ERROR %d %s\n", ret, strm.msg);
                if (input)
                    delete[] input;
                if (output)
                    delete[] output;
                return E_HANDLE;
            }
            int have = DEFAULT_BUFFER_SIZE - strm.avail_out;
            if (WriteFile(hDestinationFile, output, have, &dwCount, NULL)) {
            } else {
                hr = HRESULT_FROM_WIN32(GetLastError());
                logger->log(NORMAL, L"Writefile error %d\n", hr);
                if (input)
                    delete[] input;
                if (output)
                    delete[] output;
                return hr;
            }
            memset(output, 0, DEFAULT_BUFFER_SIZE);
        } while (strm.avail_out == 0);
    }
    fclose(in);
    CloseHandle(hDestinationFile);
    (void) inflateEnd(&strm);
    if (input)
        delete[] input;
    if (output)
        delete[] output;
    return S_OK;
}

HRESULT RestoreFile(_In_ wstring& source, _In_ wstring& destination) {
    gzFile hSourceFile;
    int failFlag = 0;
    int decompHan = _wopen(source.c_str(), _O_RDONLY | _O_BINARY);
    if (decompHan == -1) {
        logger->log(NORMAL, L"wopen error: %s\n", source.c_str());
        return E_HANDLE;
    }
    hSourceFile = gzdopen(decompHan, "rb");
    if (!hSourceFile) {
        logger->log(NORMAL, L"Decompress open error %s\n", source.c_str());
        return E_HANDLE;
    }
    HANDLE hDestinationFile = ::CreateFile(
            destination.c_str(),
            GENERIC_WRITE | WRITE_OWNER | WRITE_DAC,
            FILE_SHARE_READ,
            NULL,
            CREATE_ALWAYS,
            FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_BACKUP_SEMANTICS,
            NULL);
    if (hDestinationFile == INVALID_HANDLE_VALUE) {
        //cout<<"Accessing destination failed with error:"<<HRESULT_FROM_WIN32(GetLastError())<<endl;
        HRESULT hr = HRESULT_FROM_WIN32(GetLastError());
        //cout<<"Accessing destination failed with errorrrr:"<<hr<<endl;
        return HRESULT_FROM_WIN32(GetLastError());
    }

    const DWORD DEFAULT_BUFFER_SIZE = 4086;
    DWORD bytesRead, bytesWritten;
    BYTE buffer[DEFAULT_BUFFER_SIZE];
    LPVOID context = NULL;
    HRESULT hr = S_OK;

    while ((bytesRead = gzread(hSourceFile, buffer, DEFAULT_BUFFER_SIZE)) > 0) {
        if (!BackupWrite(hDestinationFile, buffer, bytesRead, &bytesWritten, FALSE, TRUE, &context)) {
            hr = HRESULT_FROM_WIN32(GetLastError());
            logger->log(NORMAL, L"Writing to destination failed with error %d\n", hr);
            break;
        }

        if (bytesRead != bytesWritten) {
            logger->log(NORMAL, L"Decompress Write failed.Retrying normal write \n");
            failFlag = 1;
            break;
        }
    }
    BackupWrite(hDestinationFile, NULL, 0, NULL, TRUE, TRUE, &context);
    gzclose(hSourceFile);
    CloseHandle(hDestinationFile);
    if (failFlag == 1) {
        hr = RestoreFileRetry(source, destination);
    }

    return hr;
}

HRESULT RestoreFileRetry(_In_ const wstring& source, _In_ const wstring& destination) {
    HANDLE hSourceFile = ::CreateFile(
            source.c_str(),
            GENERIC_READ,
            FILE_SHARE_READ,
            NULL,
            OPEN_EXISTING,
            FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_BACKUP_SEMANTICS,
            NULL);
    if (hSourceFile == INVALID_HANDLE_VALUE) {
        logger->log(NORMAL, L"Opening source folder failed with error %d in retry\n", GetLastError());
        return HRESULT_FROM_WIN32(GetLastError());
    }
    HANDLE hDestinationFile = ::CreateFile(
            destination.c_str(),
            GENERIC_WRITE | WRITE_OWNER | WRITE_DAC,
            FILE_SHARE_READ,
            NULL,
            CREATE_ALWAYS,
            FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_BACKUP_SEMANTICS,
            NULL);
    if (hDestinationFile == INVALID_HANDLE_VALUE) {
        HRESULT hr = HRESULT_FROM_WIN32(GetLastError());
        return HRESULT_FROM_WIN32(GetLastError());
    }

    const DWORD DEFAULT_BUFFER_SIZE = 4086;
    DWORD bytesRead, bytesWritten;
    BYTE buffer[DEFAULT_BUFFER_SIZE];
    LPVOID context = NULL;
    HRESULT hr = S_OK;
    while (ReadFile(hSourceFile, buffer, DEFAULT_BUFFER_SIZE, &bytesRead, NULL) && bytesRead > 0) {
        if (!BackupWrite(hDestinationFile, buffer, bytesRead, &bytesWritten, FALSE, TRUE, &context)) {
            hr = HRESULT_FROM_WIN32(GetLastError());
            logger->log(NORMAL, L"Writing to destination failed with error %d in retry\n", hr);
            break;
        }

        if (bytesRead != bytesWritten) {
            logger->log(NORMAL, L"BackupWrite wrote less bytes than expected in retry\n");
            break;
        }
    }
    BackupWrite(hDestinationFile, NULL, 0, NULL, TRUE, TRUE, &context);
    CloseHandle(hSourceFile);
    CloseHandle(hDestinationFile);

    return hr;
}

HRESULT ModifyPrivilege(IN LPCTSTR szPrivilege, IN BOOL fEnable) {
    HRESULT hr = S_OK;
    TOKEN_PRIVILEGES NewState;
    LUID luid;
    HANDLE hToken = NULL;

    // Open the process token for this process.
    if (!OpenProcessToken(GetCurrentProcess(),
            TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
            &hToken)) {
        logger->log(NORMAL, L"Failed in OpenProcessToken\n");
        return ERROR_FUNCTION_FAILED;
    }

    // Get the local unique ID for the privilege.
    if (!LookupPrivilegeValue(NULL,
            szPrivilege,
            &luid)) {
        CloseHandle(hToken);
        logger->log(NORMAL, L"Failed in LookupPrivilegeValue\n");
        return ERROR_FUNCTION_FAILED;
    }

    // Assign values to the TOKEN_PRIVILEGE structure.
    NewState.PrivilegeCount = 1;
    NewState.Privileges[0].Luid = luid;
    NewState.Privileges[0].Attributes =
            (fEnable ? SE_PRIVILEGE_ENABLED : 0);

    // Adjust the token privilege.
    if (!AdjustTokenPrivileges(hToken,
            FALSE,
            &NewState,
            0,
            NULL,
            NULL)) {
        logger->log(NORMAL, L"Failed in AdjustTokenPrivileges\n");
        hr = ERROR_FUNCTION_FAILED;
    }

    // Close the handle.
    CloseHandle(hToken);

    return hr;
}

void RenameFiles(wstring src, wstring dest) {
    wstring rname = src + L"\\rename_file.txt";
    string newname, oldname;
    string delimiter = "--";
    size_t pos = 0;
    int result;
    ifstream renam(rname);
    while (getline(renam, newname)) {
        if ((pos = newname.find(delimiter)) != string::npos) {
            oldname = newname.substr(0, pos);
            newname.erase(0, pos + delimiter.length());
            string oname(dest.begin(), dest.end());
            oname.append("\\");
            oname.append(oldname);
            string nname(dest.begin(), dest.end());
            nname.append("\\");
            nname.append(newname);
            result = rename(oname.c_str(), nname.c_str());
            oname.clear();
            nname.clear();
            oldname.clear();
            newname.clear();
        }
    }
    renam.close();
}

void DeleteFiles(wstring src, wstring dest) {
    wstring dname = src + L"\\delete_file.txt";
    string temp;
    ifstream del(dname);
    while (getline(del, temp)) {
        string temp1(dest.begin(), dest.end());
        temp1.append("\\");
        temp1.append(temp);
        //remove(temp1.c_str());

        CString strPath = temp1.c_str();
        strPath += '\0';
        logger->log(NORMAL, L"Delete file: %s\n", strPath);
        SHFILEOPSTRUCT strOper = {0};
        strOper.hwnd = NULL;
        strOper.wFunc = FO_DELETE;
        strOper.pFrom = strPath;
        strOper.fFlags = FOF_NO_UI;

        int val = SHFileOperation(&strOper);
        if (val != 0) {
            logger->log(NORMAL, L"Delete returned: %d\n", val);
            DWORD attr = GetFileAttributes(strPath);
            if (attr & FILE_ATTRIBUTE_DIRECTORY) {
                string cmd = "cmd /c rmdir /s/q \"" + temp1 + "\"";
                int res = WinExec(cmd.c_str(), SW_HIDE);
                logger->log(NORMAL, L"Delete retry returned: %d\n", res);
            } else {
                string cmd = "cmd /c rm \"" + temp1 + "\"";
                int res = WinExec(cmd.c_str(), SW_HIDE);
                logger->log(NORMAL, L"Delete retry returned: %d\n", res);
            }
        }
        temp1.clear();
    }
    del.close();
}

int RestoreDirectoryTree(wstring source, wstring destination, bool isEncrypted, wstring secretKey) {
    WIN32_FIND_DATA findData;
    wstring pattern = source;
    pattern += L"\\*";
    HANDLE hFind = FindFirstFile((LPCWSTR) pattern.c_str(), &findData);
    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            // If not . or .. 
            wstring name = findData.cFileName;
            if ((name != L".") && (name != L"..")&&(name != L"rename_file.txt")&&(name != L"delete_file.txt")) {
                wstring newSource = source;
                newSource += '\\';
                newSource += name;
                wstring newDestination = destination;
                newDestination += '\\';
                newDestination += name;
                if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                    if (!::CreateDirectory(newDestination.c_str(), NULL)) {
                        DWORD error = GetLastError();
                        if (error != ERROR_ALREADY_EXISTS) {
                            logger->log(NORMAL, L"CreateDirectory %s failed with error %d\n", destination.c_str(), GetLastError());
                        }
                    }
                    RestoreDirectoryTree(newSource, newDestination, isEncrypted, secretKey);
                } else {
                    Iprogress++;
                    HRESULT hr1;
                    if (isEncrypted) {
                        hr1 = RestoreEncryptedFile(newSource, newDestination, secretKey);
                    } else {
                        hr1 = RestoreFile(newSource, newDestination);
                    }
                    if (FAILED(hr1)) {
                        logger->log(NORMAL, L"Failed at restoreFile source %ws destination %ws\n", newSource.c_str(), newDestination.c_str());
                    }

                }
            }
        } while (FindNextFile(hFind, &findData));

        FindClose(hFind);
    } else {
        logger->log(NORMAL, L"RestoreDirectoryTree FindFirstFile failed with error %d\n", GetLastError());
    }
    return 0;
}

ULONGLONG getIRProgress() {
    ULONGLONG val = Iprogress;
    Iprogress = 0;
    return val;
}