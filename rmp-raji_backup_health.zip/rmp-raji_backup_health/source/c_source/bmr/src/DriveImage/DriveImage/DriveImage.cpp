// Completebu.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "DriveImage.h"
#include "Read.h"
#include "Write.h"
#include "Util.h"
#include "Source.h"
#include "Logger.h"
#include <fstream>
#include "time.h"
#include <vector>
#include <atlstr.h>
#define BUFSIZE 2097152
#define FMIFS_HARDDISK 0xC
using namespace std;

int getDiskNumberFromDriveLetter(LPCWSTR);

Read *read;
Write *write;
wstring location;
HANDLE* Handles;
IMGFileHeader img;
wstring usnvalue;
wstring maindest;
fstream usnfile;
Logger *logdrive;
LPWSTR level = NORMAL;
int entireProcessStatus = 0, formatFlag = 0;
int *diskStatus = NULL;
int *layoutStatus = NULL;
int *volumeCnt = NULL;
int diskCnt, diskNo, partitionInProgress = 0;
vector<int> restoreStatus;

int operation(wstring op, int isOldBackup, int currentDiskNo, bool isEncrypted, LPCWSTR secretKey) {
    int retval;
    if (op == L"Backup") {
        logdrive->log(NORMAL, L"Backup started\n");
        wstring srcdrivename = L"\\Device\\Harddisk0\\Partition0";
        wstring targetfilename = L"Z:\\";
        retval = ListDrives();
        if (retval == 0)
            retval = DriveBackup(srcdrivename, targetfilename);
        else {
            logdrive->log(NORMAL, L"Backup failed due to error while listing drives");
            return 1;
        }
    } else if (op == L"Ibackup") {
        logdrive->log(NORMAL, L"Incremental backup started\n");
        wstring srcdrivename = L"\\Device\\Harddisk0\\Partition0";
        wstring targetfilename = L"Z:\\";
        retval = ListDrives();
        if (retval == 0)
            retval = IncrBackup(srcdrivename, targetfilename);
        else {
            logdrive->log(NORMAL, L"Backup failed due to error while listing drives");
            return 1;
        }
    } else if (op == L"Irestore") {
        logdrive->log(NORMAL, L"Incremental restore started");
        Initialize(location);
        retval = ListDrives();

        if (volumeCnt)
            delete[] volumeCnt;
        if (diskStatus)
            delete[] diskStatus;

		map<pair<string, string>, string> fileMapping;
		string backupLocS(maindest.begin(), maindest.end());
		string mapping = backupLocS + "\\DriveMapping.txt";
        string partitionLetter, partitionNumber, diskNumber;
        string delimiter = "--";
        size_t pos = 0;

        if (PathFileExistsA(mapping.c_str())) {
            ifstream mapStream(mapping);
            while (getline(mapStream, partitionLetter)) {
                if ((pos = partitionLetter.find(delimiter)) != string::npos) {
                    diskNumber = partitionLetter.substr(0, pos);
                    partitionLetter.erase(0, pos + delimiter.length());
                    pos = partitionLetter.find(delimiter);
                    partitionNumber = partitionLetter.substr(0, pos);
                    partitionLetter.erase(0, pos + delimiter.length());
                    fileMapping[make_pair(diskNumber, partitionNumber)] = partitionLetter;
                    diskNumber.clear();
                    partitionNumber.clear();
                    partitionLetter.clear();
                }
            }
            mapStream.close();
        }

        diskStatus = new int[diskCnt];
        volumeCnt = new int[diskCnt];

        restoreStatus.clear();
        for (diskNo = 0; diskNo < diskCnt; diskNo++) {

            if (diskNo == currentDiskNo) {
                diskStatus[diskNo] = 9999;
                volumeCnt[diskNo] = 0;
                continue;
            }
            wstring srcdrivename, targetfilename;
            partitionInProgress = 0;
            diskStatus[diskNo] = 0;
            volumeCnt[diskNo] = 0;
            if (isOldBackup == 1) {
				srcdrivename = maindest + L"\\";
                targetfilename = L"\\Device\\Harddisk0\\Partition0";
            } else {
				srcdrivename = maindest + L"\\Harddisk";
                srcdrivename += to_wstring(diskNo);
                srcdrivename += L"\\";
                targetfilename = L"\\Device\\Harddisk";
                targetfilename += to_wstring(diskNo);
                targetfilename += L"\\Partition0";
            }
            if (retval == 0)
                retval = IncrRestore(srcdrivename, targetfilename, diskNo, fileMapping, isEncrypted, secretKey);
            else {
                logdrive->log(NORMAL, L"Backup failed due to error while listing drives");
                return 1;
            }
            srcdrivename.clear();
            targetfilename.clear();
        }
    } else if (op == L"Restore") {
        logdrive->log(NORMAL, L"Restore started\n");
		string backupLocS(maindest.begin(), maindest.end());
        map<pair<string, string>, string> fileMapping;
		string mapping = backupLocS + "\\DriveMapping.txt";
        string partitionLetter, partitionNumber, diskNumber;
        string delimiter = "--";
        size_t pos = 0;
        int restoreUsedOnly = 0;
        if (PathFileExistsA(mapping.c_str())) {
            ifstream mapStream(mapping);
            while (getline(mapStream, partitionLetter)) {
                if ((pos = partitionLetter.find(delimiter)) != string::npos) {
                    diskNumber = partitionLetter.substr(0, pos);
                    partitionLetter.erase(0, pos + delimiter.length());
                    pos = partitionLetter.find(delimiter);
                    partitionNumber = partitionLetter.substr(0, pos);
                    partitionLetter.erase(0, pos + delimiter.length());
                    fileMapping[make_pair(diskNumber, partitionNumber)] = partitionLetter;
                    diskNumber.clear();
                    partitionNumber.clear();
                    partitionLetter.clear();
                }
            }
            mapStream.close();
        }
        if (fileMapping.empty())
            restoreUsedOnly = 1;
        if (isEncrypted) //If encrypted, set restoreUsedOnly to 3 to tell Write thread that data is encrypted.
            restoreUsedOnly = 3;
        diskStatus = new int[diskCnt];
        volumeCnt = new int[diskCnt];
        layoutStatus = new int[diskCnt];

        setLogger(location);
        Initialize(location);

        for (diskNo = 0; diskNo < diskCnt; diskNo++) {
            if (diskNo != currentDiskNo) {
                wstring sourceName, targetName;
                layoutStatus[diskNo] = 0;
                if (isOldBackup == 1) {
                    sourceName = maindest + L"\\";
                    targetName = L"\\Device\\Harddisk0\\Partition0";
                } else {
					sourceName = maindest + L"\\Harddisk" + to_wstring(diskNo) + L"\\";
                    targetName = L"\\Device\\Harddisk" + to_wstring(diskNo) + L"\\Partition0";
                }

                updateDiskStructure(sourceName, targetName, diskNo);
            }
        }

        driveList.clear();
        Sleep(5000); // wait for drives to get ready
        ListDrives();

        for (diskNo = 0; diskNo < diskCnt; diskNo++) {
            if (diskNo == currentDiskNo) {
                diskStatus[diskNo] = 9999;
                volumeCnt[diskNo] = 0;
                continue;
            }
            diskStatus[diskNo] = 0;
            volumeCnt[diskNo] = 0;
            formatFlag = 0;
            wstring srcfilename, targetdrivename;
            if (isOldBackup == 1) {
				srcfilename = maindest + L"\\";
                targetdrivename = L"\\Device\\Harddisk0\\Partition0";
            } else {
				srcfilename = maindest + L"\\Harddisk";
                srcfilename += to_wstring(diskNo);
                srcfilename += L"\\";
                targetdrivename = L"\\Device\\Harddisk";
                targetdrivename += to_wstring(diskNo);
                targetdrivename += L"\\Partition0";
            }
            retval = RestoreDrive(srcfilename, targetdrivename, diskNo, fileMapping, restoreUsedOnly, isEncrypted, secretKey);
            srcfilename.clear();
            targetdrivename.clear();
        }
    }
    return retval;
}

void updateDiskStructure(wstring sourceName, wstring targetName, int diskNo) {

    BOOL ismbr = TestIsMBR(sourceName);

    if (ismbr) {

        wstring mbrfilename = sourceName;

        int retval = ReadFromFile(mbrfilename);

        if (retval) {
            layoutStatus[diskNo] = retval;
            return;
        }

        retval = WriteDriveInfo(targetName);

        if (retval) {
            layoutStatus[diskNo] = retval;
            return;
        }
    }
}

int ListDrives() {
    int ret;
    DWORD sectorsPerCluster;
    DWORD bytesPerSector;
    DWORD numberOfFreeClusters;
    DWORD totalNumberOfClusters;
    DWORD diskClusterSize = 0;
    DWORD clusterSize = 0;
    vector<wstring> devices;
    map<wstring, wstring> volumes;
    map<wstring, wstring> guidpath;
    ret = DirectoryObject(L"\\Device", devices);
    if (ret)
        return 1;
    if (devices.size() > 0) {

        wchar_t *buffer = new wchar_t [1024];

        for (wchar_t letter = L'A'; letter <= L'Z'; letter++) {
            wstring drive;
            drive = letter;
            drive += L":\\";
            if (GetVolumeNameForMountPoint(drive.c_str(), buffer, 1000)) {
                wstring volume = buffer;
                wstring param = L"\\??\\" + volume.substr(4, volume.length() - 5);
                wstring volumeLink;
                bool ok = GetNTLinkDestination(param.c_str(), volumeLink);
                if (ok) {
                    volumes[volumeLink] = drive;
                }
            }
        }
        delete[] buffer;

        DWORD charCount = 0;
        WCHAR name[MAX_PATH] = L"";
        DWORD error = ERROR_SUCCESS;
        HANDLE findHandle = INVALID_HANDLE_VALUE;
        size_t index = 0;
        BOOL success = FALSE;
        WCHAR volumeName[MAX_PATH] = L"";
        findHandle = FindFirstVolumeW(volumeName, ARRAYSIZE(volumeName));

        if (findHandle == INVALID_HANDLE_VALUE) {
            error = GetLastError();
            logdrive->log(NORMAL, L"FindFirstVolumeW failed with error code %d\n", error);
        }

        for (;;) {
            //
            //  Skip the \\?\ prefix and remove the trailing backslash.
            index = wcslen(volumeName) - 1;

            if (volumeName[0] != L'\\' || volumeName[1] != L'\\' || volumeName[2] != L'?' || volumeName[3] != L'\\' || volumeName[index] != L'\\') {
                error = ERROR_BAD_PATHNAME;
                logdrive->log(NORMAL, L"FindFirstVolumeW/FindNextVolumeW returned a bad path: %s\n", volumeName);
                break;
            }

            //
            //  QueryDosDeviceW does not allow a trailing backslash,
            //  so temporarily remove it.
            volumeName[index] = L'\0';

            charCount = QueryDosDeviceW(&volumeName[4], name, ARRAYSIZE(name));

            volumeName[index] = L'\\';

            if (charCount == 0) {
                error = GetLastError();
                logdrive->log(NORMAL, L"QueryDosDeviceW failed with error code %d\n", error);
                break;
            }

            guidpath[name] = volumeName;
            //
            //  Move on to the next volume.
            success = FindNextVolumeW(findHandle, volumeName, ARRAYSIZE(volumeName));

            if (!success) {
                error = GetLastError();

                if (error != ERROR_NO_MORE_FILES) {
                    logdrive->log(NORMAL, L"FindNextVolumeW failed with error code %d\n", error);
                    break;
                }

                //
                //  Finished iterating
                //  through all the volumes.
                error = ERROR_SUCCESS;
                break;
            }
        }

        FindVolumeClose(findHandle);
        findHandle = INVALID_HANDLE_VALUE;

        for (unsigned n = 0; n < devices.size(); n++) {
            wstring deviceName = devices[n], displayName, mountPoint, driveguid;
            size_t length = deviceName.length();
            size_t slashPos = deviceName.find(L'\\', 8); // pos of '\' after \Device\...
            size_t slashPos2;
            // search for \Device\HarddiskNN without a suffix
            if ((slashPos == string::npos && deviceName.find(L"Harddisk") == 8) && deviceName[16] >= L'0' && deviceName[16] <= L'9') {
                displayName = deviceName;
                mountPoint = volumes[deviceName];
                driveguid = guidpath[deviceName];
                if (!mountPoint.length() == 0)
                    displayName += L" (" + mountPoint + L")";
                if (deviceName.find(L"Harddisk") != string::npos) {
                    vector<wstring> partitions;
                    int partitionCount = 0;
                    DirectoryObject(deviceName.c_str(), partitions);
                    deviceName += L"\\Partition0";
                    //deviceName = partitions[0];
                    displayName += L" (entire disk)";
                    Info *diskInfo = new Info(displayName, deviceName, mountPoint, true);
                    diskInfo->guid = driveguid;
                    if (mountPoint.length() > 0) {
                        BOOL ok = GetDiskFreeSpace(mountPoint.c_str(), &sectorsPerCluster, &bytesPerSector, &numberOfFreeClusters, &totalNumberOfClusters);
                        if (ok) {
                            diskClusterSize = bytesPerSector * sectorsPerCluster;
                        } else {
                            diskClusterSize = 0;
                        }
                    }
                    // If this is a hard disk, check for and add any partitions
                    if (partitions.size() > 0) {
                        for (unsigned i = 0; i < partitions.size(); i++) {
                            wstring partitionDeviceName = partitions[i], partitionDisplayName, partitionMountPoint, pathguid;
                            slashPos = partitionDeviceName.find(L'\\', 8); // pos of '\' after \Device\HarddiskNN
                            slashPos2 = partitionDeviceName.find(L'\\', slashPos + 1); // pos of '\' after \Device\HarddiskNN\PartitionMM
                            if ((partitionDeviceName.find(L"Partition0") == string::npos) &&
                                    (partitionDeviceName.find(L"Partition") == slashPos + 1) && (slashPos2 == string::npos)
                                    && partitionDeviceName[slashPos + 10] >= L'0' && partitionDeviceName[slashPos + 10] <= L'9') { // \Device\HarddiskNN\PartionMM                
                                partitionCount++; // we found a real partition
                                Info *partitionInfo;
                                wstring volumeLink;
                                partitionDisplayName = partitionDeviceName;
                                bool ok = GetNTLinkDestination(partitionDeviceName.c_str(), volumeLink);
                                partitionMountPoint = volumes[volumeLink];
                                pathguid = guidpath[volumeLink];
                                if (partitionMountPoint.length() > 0)
                                    partitionDisplayName += L" (" + partitionMountPoint + L")";
                                if (partitionMountPoint.length() > 0) {
                                    BOOL ok = GetDiskFreeSpace(partitionMountPoint.c_str(), &sectorsPerCluster, &bytesPerSector, &numberOfFreeClusters, &totalNumberOfClusters);
                                    if (ok) {
                                        clusterSize = bytesPerSector * sectorsPerCluster;
                                    } else {
                                        clusterSize = 0;
                                    }
                                }
                                partitionInfo = new Info(partitionDisplayName, partitionDeviceName, partitionMountPoint, false);
                                partitionInfo->parent = diskInfo;
                                partitionInfo->clusterSize = clusterSize;
                                partitionInfo->guid = pathguid;
                                driveList.push_back(partitionInfo);
                            }
                        }
                    } // if
                    bool skipEntireDiskPartion = false;
                    if (partitionCount == 1) {
                        // if we have only one partition and this is same size as partition0 then it is an unpartioned device
                        // like a memory stick and we omit the entire disk as this is redundant
                        PARTITION_INFORMATION_EX partition;
                        unsigned __int64 bytes1, bytes2;
                        DWORD nCount;
                        long ntStatus;
                        HANDLE hDrive;

                        ntStatus = OpenAPI(&hDrive, deviceName.c_str(), GENERIC_READ, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_OPEN, FILE_SEQUENTIAL_ONLY);
                        DeviceIoControl(hDrive, IOCTL_DISK_GET_PARTITION_INFO_EX, NULL, 0, &partition, sizeof (partition), &nCount, NULL);
                        bytes1 = partition.PartitionLength.QuadPart;
                        CloseHandle(hDrive);
                        // find correct partition
                        for (unsigned i = 0; i < partitions.size(); i++) {
                            wstring partitionDeviceName = partitions[i];
                            slashPos = partitionDeviceName.find(L'\\', 8); // pos of '\' after \Device
                            slashPos2 = partitionDeviceName.find(L'\\', slashPos + 1); // pos of '\' after \Device\HarddiskNN
                            if ((partitionDeviceName.find(L"Partition0") == string::npos) && (partitionDeviceName.find(L"Partition") == slashPos + 1) && (slashPos2 == string::npos)
                                    && partitionDeviceName[slashPos + 10] >= L'0' && partitionDeviceName[slashPos + 10] <= L'9') { // \Device\HarddiskNN\PartionMM                
                                ntStatus = OpenAPI(&hDrive, partitionDeviceName.c_str(), GENERIC_READ, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_OPEN, FILE_SEQUENTIAL_ONLY);
                                DeviceIoControl(hDrive, IOCTL_DISK_GET_PARTITION_INFO_EX, NULL, 0, &partition, sizeof (partition), &nCount, NULL);
                                bytes2 = partition.PartitionLength.QuadPart;
                                CloseHandle(hDrive);
                            }
                        }
                        skipEntireDiskPartion = bytes1 == bytes2; // does root partition and first partions have same size?
                    }
                    if (skipEntireDiskPartion) {
                        delete diskInfo;
                        diskInfo = NULL;
                    } else {
                        diskInfo->containedVolumes = partitionCount;
                        diskInfo->clusterSize = diskClusterSize;
                        driveList.push_back(diskInfo);
                    }
                } // find hard disk
            }
        }
    }
    return 0;

}

int DriveBackup(wstring src, wstring dest) {
    int retval, value;
    wstring volumeFileName, driveletter, metadata;
    wstring devicename = src;
    for (int i = 0; i < driveList.size(); i++) {
        if (driveList[i]->deviceName == devicename)
            index = i;
    }
    Info* driveInfo = driveList[index];

    Info **pContainedVolumes = NULL;
    int subPartitions = driveInfo->containedVolumes;
    pContainedVolumes = new Info* [subPartitions];
    int res = GetVolumes(driveInfo, pContainedVolumes, subPartitions);
    usnfile.open(usnvalue, ios::out);
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!driveletter.empty()) {
            value = QueryJournal(driveletter);
            usnfile << value;
            usnfile << endl;
        }
    }
    usnfile.close();
    wstring mbrfilename = dest;
    Creatembrfilename(mbrfilename);
    retval = ReadDriveInfo(src);
    if (retval)
        return 1;
    retval = WriteToFile(mbrfilename);
    if (retval)
        return 1;
    retval = MakeSnapshot(index);
    if (retval)
        return 1;
    for (int i = 0; i < subPartitions; i++) {
        logdrive->log(NORMAL, L"Backing up partition %d\n", i + 1);
        GenerateFileNameForEntireDiskBackup(volumeFileName, dest, pContainedVolumes[i]->deviceName);

        GenerateFileNameForMetadata(metadata, dest, pContainedVolumes[i]->deviceName);
        vssindex = i;
        retval = BackupandRestorePartitions(index, pContainedVolumes[i]->deviceName, volumeFileName, 4096, L"Backup", metadata, 2, false, L""); //restoreUsedOnly hardcoded to 2 for Backup
        if (retval)
            logdrive->log(NORMAL, L"Backup of partition %d failed\n", i + 1);
        else
            logdrive->log(NORMAL, L"Backup of partition %d completed\n", i + 1);
    }
    ReleaseSnapshot(false);
    CloseVss();
    return 0;

}

int IncrBackup(wstring src, wstring dest) {
    int value;
    usnfile.open(usnvalue, ios::in);
    int retval;
    wstring destName;
    wstring devicename = src;
    for (int i = 0; i < driveList.size(); i++) {
        if (driveList[i]->deviceName == devicename)
            index = i;
    }
    Info* driveInfo = driveList[index];
    const wchar_t* vssVolume;
    wstring device, driveletter;
    Info **pContainedVolumes = NULL;
    int subPartitions = driveInfo->containedVolumes;
    pContainedVolumes = new Info* [subPartitions];
    int res = GetVolumes(driveInfo, pContainedVolumes, subPartitions);
    string usnval;
    string *valarr = new string[subPartitions];
    int loop = 0;
    size_t pos;
    while (getline(usnfile, usnval)) {
        valarr[loop++] = usnval;
    }
    usnfile.close();
    usnfile.open(usnvalue, ios::out | ios::trunc);
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!driveletter.empty()) {
            value = QueryJournal(driveletter);
            usnfile << value;
            usnfile << endl;
        }
    }
    usnfile.close();
    retval = MakeSnapshot(index);
    if (retval)
        return 1;
    loop = 0;
    for (int i = 0; i < subPartitions; i++) {
        logdrive->log(NORMAL, L"Backing up partition %d\n", i + 1);
        vssindex = i;
        destName = dest;
        pos = (pContainedVolumes[i]->deviceName).rfind(L"Partition");
        destName += (pContainedVolumes[i]->deviceName).substr(pos);

        driveletter = pContainedVolumes[i]->mountPoint;
        pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!(driveletter.empty())) {
            vssVolume = GetSnapshotDeviceName(vssindex);
            if (vssVolume != NULL && *vssVolume != L'\0') // can be 0 if not mounted
                device = vssVolume;
            else {
                logdrive->log(NORMAL, L"vss volume name is not valid\n");
                throw 1;
            }
            retval = BackupDirectoryTree(driveletter, destName, device, valarr[loop++]);
            if (retval)
                logdrive->log(NORMAL, L"Backup of partition %d failed\n", i + 1);
            else
                logdrive->log(NORMAL, L"Backup of partition %d completed\n", i + 1);
        }
        destName.clear();
        device.clear();
    }
    ReleaseSnapshot(false);
    CloseVss();
    return 0;

}

int IncrRestore(wstring src, wstring dest, int num, map<pair<string, string>, string> &fileMapping, bool isEncrypted, wstring secretKey) {
    setLogger(location);
    int retval = 1, IR = 0;
    wstring destName;
    wstring devicename = dest;
    bool chckFlag = false, canRestore = false;
    for (int i = 0; i < driveList.size(); i++) {
        if (driveList[i]->deviceName == devicename) {
            index = i;
            chckFlag = true;
            break;
        }
    }
    if (!chckFlag) {
        logdrive->log(NORMAL, L"Disk not found in IR\n");
        diskStatus[num] = 5;
        return 0;
    }
    Info* driveInfo = driveList[index];
    wstring driveletter;
    Info **pContainedVolumes = NULL;
    int subPartitions = driveInfo->containedVolumes;
    pContainedVolumes = new Info* [subPartitions];
    int res = GetVolumes(driveInfo, pContainedVolumes, subPartitions);
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!(driveletter.empty())) {
            if (fileMapping.empty()) {
                //Old BMR backups
                destName = src + L"Partition" + driveletter.substr(0, 1);
                canRestore = true;
            } else {
                if (fileMapping.find(make_pair(to_string(num), to_string(i + 1))) != fileMapping.end()) {
                    string pLetter = fileMapping[make_pair(to_string(num), to_string(i + 1))];
                    wstring pLetterW(pLetter.begin(), pLetter.end());
                    destName = src + L"Partition" + pLetterW;
                    canRestore = true;
                } else {
                    logdrive->log(NORMAL, L"Could not find %d %d in driveMapping\n", num, (i + 1));
                    canRestore = false;
                }
            }
            if (canRestore) {
                if (PathFileExists(destName.c_str())) {
                    logdrive->log(NORMAL, L"Restoring partition %d\n", i + 1);
                    partitionInProgress = IR++;
                    HRESULT hr;

                    hr = ModifyPrivilege(SE_RESTORE_NAME, TRUE);

                    if (!SUCCEEDED(hr))
                        logdrive->log(NORMAL, L"Failed to modify privilege.\n");
                    else
                        logdrive->log(NORMAL, L"Successfully modified privilege.\n");
                    RenameFiles(destName, driveletter);
                    DeleteFiles(destName, driveletter);
                    retval = RestoreDirectoryTree(destName, driveletter, isEncrypted, secretKey);
                    if (retval) {
                        diskStatus[num] = retval;
                        restoreStatus.push_back(1);
                        logdrive->log(NORMAL, L"Restore of partition %d failed\n", i + 1);
                    } else {
                        restoreStatus.push_back(0);
                        logdrive->log(NORMAL, L"Restore of partition %d completed\n", i + 1);
                    }

                    wstring drvletter = pContainedVolumes[i]->mountPoint;
                    size_t pos = drvletter.find('\\');
                    drvletter = drvletter.substr(0, pos);
                    wstring testFile = drvletter + L"\\Program Files\\ManageEngine\\RMP\\usnvalues_0.txt";
                    if (PathFileExists(testFile.c_str())) {
                        logdrive->log(NORMAL, L"usnvalues file found\n");
                        for (int del = 0; del < diskCnt; del++) {
                            wstring deleteUsnFile = drvletter + L"\\Program Files\\ManageEngine\\RMP\\usnvalues_" + to_wstring(del) + L".txt";
                            string cmdPath(deleteUsnFile.begin(), deleteUsnFile.end());
                            CString strPath = cmdPath.c_str();
                            strPath += '\0';
                            logdrive->log(NORMAL, L"Delete file: %s\n", strPath);
                            SHFILEOPSTRUCT strOper = {0};
                            strOper.hwnd = NULL;
                            strOper.wFunc = FO_DELETE;
                            strOper.pFrom = strPath;
                            strOper.fFlags = FOF_NO_UI;

                            int val = SHFileOperation(&strOper);
                            logdrive->log(NORMAL, L"Delete usnfile returned: %d\n", val);
                            deleteUsnFile.clear();
                        }
                    } else {
                        logdrive->log(NORMAL, L"usnvalues file not found in this partition\n");
                    }
                    testFile.clear();
                    drvletter.clear();
                }
                destName.clear();
            } 
        }
    }
    if(IR == 0){
        diskStatus[num] = 1;
    }
    volumeCnt[num] = IR;
    return 0;

}

int RestoreDrive(wstring src, wstring dest, int num, map<pair<string, string>, string> &fileMapping, int restoreUsedOnly, bool isEncrypted, LPCWSTR secretKey) {
    int retval;
    wstring volumeFileName;
    bool ismbr;
    unsigned subPartitions = 0;
    wstring devicename = dest;

    wstring mbrSrc = src;
    ismbr = TestIsMBR(mbrSrc);
    if (layoutStatus[num] == 0) {
        wstring mbrfilename = mbrSrc;
        retval = ReadFromFile(mbrfilename);
        if (retval) {
            diskStatus[num] = 1;
            return 1;
        }

        Initialize(location);

        driveList.clear();

        WaitForDriveReady(index, subPartitions, devicename);
        for (size_t i = 0; i < driveList.size(); i++) {
            if (driveList[i]->deviceName == devicename) {
                index = (int) i;
                break;
            }
        }


        Info* driveInfo = driveList[index];
        volumecount = driveInfo->containedVolumes;
        subPartitions = volumecount;
        volumeCnt[num] = subPartitions;

        loadFmifs();
        logdrive->log(NORMAL, L"Formatting all volumes..\n");
        Info **pContainedVolumes = NULL;
        pContainedVolumes = new Info* [subPartitions];
        int res = GetVolumes(driveInfo, pContainedVolumes, subPartitions);
        for (int i = 0; i < subPartitions; i++) {
            partitionInProgress = i;
            wstring driveletter = pContainedVolumes[i]->mountPoint;
            if (driveletter.length() != 0) {
                bool result = FormatDrive(driveletter.c_str(), L"RMP", false);
                if (!result) {
                    logdrive->log(NORMAL, L"Formatting %s failed\n", driveletter.c_str());
                } else {
                    logdrive->log(NORMAL, L"Formatted %s successfully\n", driveletter.c_str());
                }
            } else {
                logdrive->log(NORMAL, L"Found driveLetter empty. Skipping format\n");
            }
        }
        releaseFmifs();
        formatFlag = 1;

        driveHandle = NULL;
        position = 0;

        retval = Opendisk(devicename, L"read");
        if (retval) {
            diskStatus[num] = 1;
            return 1;
        }
        driveHandle = NULL;
        unsigned diskno;
        size_t pos1 = driveInfo->deviceName.find(L"Harddisk") + 8;
        size_t pos2 = driveInfo->deviceName.find(L'\\', pos1);
        diskno = _wtoi(driveInfo->deviceName.substr(pos1, pos2 - pos1).c_str());
        wstring volumeDeviceName, partitionFileName, metadata;
        for (unsigned i = 0; i < subPartitions; i++) {
            partitionInProgress = i;
            logdrive->log(NORMAL, L"Restoring partition %d\n", i + 1);
            GenerateDeviceNameForVolume(volumeDeviceName, diskno, i + 1);
            if (fileMapping.find(make_pair(to_string(diskno), to_string(i + 1))) != fileMapping.end()) {
                string pLetter = fileMapping[make_pair(to_string(diskno), to_string(i + 1))];
                wstring pLetterW(pLetter.begin(), pLetter.end());
                volumeFileName = src + L"\\Partition" + pLetterW + L".img";
                //GenerateFileNameForEntireDiskBackup(volumeFileName, src, volumeDeviceName);
                metadata = src + L"\\Partition" + pLetterW + L"_metadata.txt";
            } else {
                GenerateFileNameForEntireDiskBackup(volumeFileName, src, volumeDeviceName);
                GenerateFileNameForMetadata(metadata, src, volumeDeviceName);
            }
            CloseAndUnlockVolume(i);
            retval = BackupandRestorePartitions(index, volumeFileName, volumeDeviceName, 4096, L"Restore", metadata, restoreUsedOnly, isEncrypted, secretKey);
            if (retval == 3) {
                restoreStatus.push_back(3);
                logdrive->log(NORMAL, L"Restore of partition %d failed due to insufficient space\n", i + 1);
            } else if (retval) {
                restoreStatus.push_back(1);
                logdrive->log(NORMAL, L"Restore of partition %d failed\n", i + 1);
            } else {
                restoreStatus.push_back(0);
                logdrive->log(NORMAL, L"Restore of partition %d completed\n", i + 1);
            }

            wstring drvletter = pContainedVolumes[i]->mountPoint;
            size_t pos = drvletter.find('\\');
            drvletter = drvletter.substr(0, pos);
            wstring testFile = drvletter + L"\\Program Files\\ManageEngine\\RMP\\usnvalues_0.txt";
            if (PathFileExists(testFile.c_str())) {
                logdrive->log(NORMAL, L"usnvalues file found\n");
                for (int del = 0; del < diskCnt; del++) {
                    wstring deleteUsnFile = drvletter + L"\\Program Files\\ManageEngine\\RMP\\usnvalues_" + to_wstring(del) + L".txt";
                    string cmdPath(deleteUsnFile.begin(), deleteUsnFile.end());
                    CString strPath = cmdPath.c_str();
                    strPath += '\0';
                    logdrive->log(NORMAL, L"Delete file: %s\n", strPath);
                    SHFILEOPSTRUCT strOper = {0};
                    strOper.hwnd = NULL;
                    strOper.wFunc = FO_DELETE;
                    strOper.pFrom = strPath;
                    strOper.fFlags = FOF_NO_UI;

                    int val = SHFileOperation(&strOper);
                    logdrive->log(NORMAL, L"Delete usnfile returned: %d\n", val);
                    deleteUsnFile.clear();
                }
            } else {
                logdrive->log(NORMAL, L"usnvalues file not found in this partition\n");
            }


            testFile.clear();
            drvletter.clear();
        }
        return 0;
    } else {
        logdrive->log(NORMAL, L"Layout application unsuccessful for disk %d\n", num);
        diskStatus[num] = 1;
        return 1;
    }
}

__declspec(dllexport) int __cdecl get_Disk() {
    return diskNo;
}

__declspec(dllexport) int __cdecl getVolumeCnt(int i) {
    return volumeCnt[i];
}

__declspec(dllexport) int __cdecl getPartitionInProgress() {
    return partitionInProgress;
}

__declspec(dllexport) int __cdecl get_DiskStatus(int i) {
    return diskStatus[i];
}

__declspec(dllexport) int __cdecl get_Status(int i) {
    return restoreStatus[i];
}

__declspec(dllexport) int __cdecl get_EntireProcessStatus() {
    return entireProcessStatus;
}

__declspec(dllexport) int __cdecl getProcessFormatStatus() {
    return formatFlag;
}

void WaitForDriveReady(int index, unsigned partitionCount, const wstring& targetDiskDeviceName) {
    int retries = 0;
    DWORD waitTime = 50;
    bool allPartitionsFound = false;
    wstring volumeDeviceName;
    while ((index < 0 || !allPartitionsFound) && retries++ < 5) {
        Sleep(waitTime); // wait a moment, may cause crash because list is not yet up to date
        // waitTime += 100;
        allPartitionsFound = true;
        driveList.clear();
        ListDrives();
        for (size_t i = 0; i < driveList.size(); i++) {
            if (driveList[i]->deviceName == targetDiskDeviceName) {
                index = (int) i;
                break;
            }
        }

        unsigned diskNum = 0;
        int volumeIndex;
        if (index >= 0) {
            for (unsigned i = 0; i < partitionCount; i++) {
                GenerateDeviceNameForVolume(volumeDeviceName, diskNum, i + 1);
                for (size_t i = 0; i < driveList.size(); i++) {
                    if (driveList[i]->deviceName == volumeDeviceName) {
                        volumeIndex = (int) i;
                        break;
                    }
                }

                if (volumeIndex < 0) {
                    allPartitionsFound = false;
                    logdrive->log(NORMAL, L"Device not available for backup\n");
                    break;
                }
            }
        }
    }

    if (index < 0)
        logdrive->log(NORMAL, L"Device not available for backup\n");

}

void GenerateDeviceNameForVolume(wstring& volumeFileName, unsigned diskNum, unsigned volumeNo) {
    const int bufSize = 10;
    wchar_t buffer[bufSize];
    volumeFileName = L"\\Device\\Harddisk";
    _ui64tow_s(diskNum, buffer, bufSize, 10);
    volumeFileName += buffer;
    volumeFileName += L"\\Partition";
    _ui64tow_s(volumeNo, buffer, bufSize, 10);
    volumeFileName += buffer;
}

int GetVolumes(const Info* driveInfo, Info** Volumes, int Count) {
    int result = 0;
    int j = 0;
    for (unsigned i = 0; i < driveList.size(); i++) {
        if (driveList[i]->parent == driveInfo && j < Count)
            Volumes[j++] = driveList[i];
    }
    return j;
}

void Creatembrfilename(wstring &name) {
    wstring mbrFileName = L"Bootloader.mbr";
    name += mbrFileName;
}

int ReadDriveInfo(wstring source) {
    try {
        wstring name = source;
        HANDLE hFile;
        long ntStatus;
        DWORD bytesRead, buf, res;
        ntStatus = OpenAPI(&hFile, name.c_str(), GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT | FILE_RANDOM_ACCESS | FILE_NON_DIRECTORY_FILE);

        // allocate buffer that is large enough
        DWORD bufferSize = 1024 * sizeof (PARTITION_INFORMATION_EX) + sizeof (DRIVE_LAYOUT_INFORMATION_EX);
        BYTE* Bufferestimate = new BYTE [bufferSize];
        res = DeviceIoControl(hFile, IOCTL_DISK_GET_DRIVE_LAYOUT_EX, NULL, 0, Bufferestimate, bufferSize, &buf, NULL);
        if (res == FALSE && GetLastError() == ERROR_INSUFFICIENT_BUFFER) {
            logdrive->log(NORMAL, L"Reading drive layout failed with error %d\n", GetLastError());
            CloseHandle(hFile);
            throw 1;
        }
        partitioncount = ((DRIVE_LAYOUT_INFORMATION_EX*) Bufferestimate)->PartitionCount;

        // reallocate buffer with the size that is really in use
        bufferSize = (partitioncount - 1) * sizeof (PARTITION_INFORMATION_EX) + sizeof (DRIVE_LAYOUT_INFORMATION_EX);
        Buffer = new BYTE[bufferSize];
        CopyMemory(Buffer, Bufferestimate, bufferSize);
        delete[] Bufferestimate;

        PARTITION_INFORMATION_EX* partInfo = &(((DRIVE_LAYOUT_INFORMATION_EX*) Buffer)->PartitionEntry[0]);

        // get size of disk
        GET_LENGTH_INFORMATION lengthInfo;
        res = DeviceIoControl(hFile, IOCTL_DISK_GET_LENGTH_INFO, NULL, 0, &lengthInfo, sizeof (lengthInfo), &buf, NULL);
        disksize = lengthInfo.Length.QuadPart;

        // Set extended read mode for disks in Vista (fails on Win XP, no problem in Vista)
        res = DeviceIoControl(hFile, FSCTL_ALLOW_EXTENDED_DASD_IO, NULL, 0, NULL, 0, &buf, NULL);



        // if (res == 0)
        //  ; // no error checking here because a failure always occurs on Win XP

        // Read Boot Loader Code
        res = SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
        if (res == INVALID_SET_FILE_POINTER) {
            logdrive->log(NORMAL, L"Invalid file pointer");
            throw 1;
        }
        res = ReadFile(hFile, bootloader, SIZE, &bytesRead, NULL);
        if (res == 0) {
            logdrive->log(NORMAL, L"Reading bootloader failed with error %d\n", GetLastError());
            throw 1;
        }
        res = CloseHandle(hFile);
        return 0;
    } catch (int e) {
        return e;
    }
}

int WriteToFile(wstring fileName) {
    try {
        HANDLE hFile;
        MBRFileHeader header;
        DWORD sizeWritten, bufferSize, res;

        header.guid = magicGUID;
        header.versionMajor = 1;
        header.versionMinor = 0;
        header.partitionCount = partitioncount;
        header.diskExtent = disksize;
        header.bootLoaderOffset = sizeof (MBRFileHeader);
        header.bootLoaderLength = SIZE;
        header.partInfoOffset = header.bootLoaderOffset + header.bootLoaderLength;
        header.partInfoLength = (partitioncount - 1) * sizeof (PARTITION_INFORMATION_EX) + sizeof (DRIVE_LAYOUT_INFORMATION_EX);

        hFile = CreateFile(fileName.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hFile == INVALID_HANDLE_VALUE) {
            logdrive->log(NORMAL, L"Invalid file handle error %d\n", GetLastError());
            throw 1;
        }
        // write header information
        res = WriteFile(hFile, &header, sizeof (header), &sizeWritten, NULL);
        if (res == 0) {
            logdrive->log(NORMAL, L"Writing header failed with error %d\n", GetLastError());
            throw 1;
        }
        // write boot loader block  
        res = WriteFile(hFile, bootloader, SIZE, &sizeWritten, NULL);
        if (res == 0) {
            logdrive->log(NORMAL, L"Writing bootloader failed with error %d\n", GetLastError());
            throw 1;
        }
        // write partition information  
        bufferSize = (partitioncount - 1) * sizeof (PARTITION_INFORMATION_EX) + sizeof (DRIVE_LAYOUT_INFORMATION_EX);
        if (Buffer) {
            res = WriteFile(hFile, Buffer, bufferSize, &sizeWritten, NULL);
            if (res == 0) {
                logdrive->log(NORMAL, L"Writing drive information failed with error %d\n", GetLastError());
                throw 1;
            }
        }
        res = CloseHandle(hFile);
        return 0;
    } catch (int e) {
        return e;
    }
}

void GenerateFileNameForEntireDiskBackup(wstring &volumeFileName, wstring name, wstring partitionDeviceName) {

    size_t pos = partitionDeviceName.rfind(L"Partition");
    wstring ext = L".img";
    volumeFileName = name;
    volumeFileName += partitionDeviceName.substr(pos);
    volumeFileName += ext;
}

void GenerateFileNameForMetadata(wstring &volumeFileName, wstring name, wstring partitionDeviceName) {

    size_t pos = partitionDeviceName.rfind(L"Partition");
    wstring ext = L".txt";
    volumeFileName = name;
    volumeFileName += L"\\";
    volumeFileName += partitionDeviceName.substr(pos);
    volumeFileName += L"_metadata";
    volumeFileName += ext;
}

BOOL findIsSystemPartition(wstring volumeFileName) {
    try {
        size_t pos = volumeFileName.rfind(L".img");
        wstring drive = volumeFileName.substr(pos - 1, 1);
        int i = stoi(drive);
    } catch (exception e) {
        return false;
    }
    return true;
}

int BackupandRestorePartitions(int index, wstring src, wstring dest, unsigned clustersize, wstring operation, wstring origName, int restoreUsedOnly, bool isEncrypted, LPCWSTR secretKey) {
    try {
        int val;
        wstring device = src;
        Info* driveInfo = driveList[index];
        LPCWSTR mountPoint = NULL;
        mountPoint = driveInfo->mountPoint.c_str();
        unsigned __int64 bitmapsize = 0, offsetpos, data;
        DWORD error = 0;
        string restorename(src.begin(), src.end());
        if (operation == L"Backup") {
            const wchar_t* vssVolume;
            metaHandle = CreateFile(origName.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
            if (metaHandle == INVALID_HANDLE_VALUE) {
                logdrive->log(NORMAL, L"Invalid metafile handle %d\n", GetLastError());
                throw 1;
            }
            val = Opentargetfile(dest, L"write");
            if (val)
                throw 1;
            vssVolume = GetSnapshotDeviceName(vssindex);

            if (vssVolume != NULL && *vssVolume != L'\0') // can be 0 if not mounted
                device = vssVolume;
            else {
                logdrive->log(NORMAL, L"vss volume name is not valid\n");
                throw 1;
            }
            device.erase(0, 14);
            Opendisk(device, L"read");
        } else if (operation == L"Restore") {
            metaHandle = CreateFile(origName.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            if (metaHandle == INVALID_HANDLE_VALUE) {
		logdrive->log(NORMAL, L"Invalid metafile handle %d %ws\n", GetLastError(), origName.c_str());
                throw 1;
            }
            if (isEncrypted) {
                val = Opentargetfile(src, L"read");
                if (val)
                    throw 1;
            } else {
                fileHandle = NULL;
            }
            val = Opendisk(dest, L"write");

            BOOL isSystemPartition = findIsSystemPartition(device);

            if (!isSystemPartition || (isSystemPartition && val != 3)) {
                if (val == 3) {
                    return val;
                } else if (val)
                    throw 1;
            }
        }
        Queuecode *initialReader = new Queuecode(2097152, 16);
        Queuecode *finalReader = new Queuecode(location);
        Queuecode *writerIn = finalReader;
        Queuecode *writerOut = initialReader;
        if (operation == L"Backup") {
            memset(&img, 0, sizeof (img));
            img.guid = magicGUID;
            img.versionMajor = 1;
            img.versionMinor = 0;
            WriteHeader();
            BOOL bSuccess;
            LARGE_INTEGER pos, newOffset;
            pos.QuadPart = 0;
            bSuccess = SetFilePointerEx(fileHandle, pos, &newOffset, FILE_END);
            offsetpos = newOffset.QuadPart;
            img.volumeBitmapOffset = offsetpos;

            read = new Read(initialReader, finalReader, driveHandle, metaHandle, partitionsize, position, clustersize, true, 0, location, dest);
            write = new Write(writerIn, writerOut, driveHandle, metaHandle, partitionsize, position, clustersize, restoreUsedOnly, location, dest, secretKey);
            bitmapsize = GetVolumeBitmap(metaHandle, driveHandle, partitionsize, bytesPerCluster);
            data = offsetpos + bitmapsize;
            img.volumeBitmapLength = bitmapsize;
            img.dataOffset = data;
            WriteHeader();
            CloseHandle(fileHandle);
        } else if (operation == L"Restore") {
            memset(&img, 0, sizeof (img));
            ReadHeader();

            if (img.guid != magicGUID) {
                logdrive->log(NORMAL, L"GUID error\n");
                throw 1;
            }
            if (img.versionMajor != 1) {
                logdrive->log(NORMAL, L"Version error\n");
                throw 1;
            }
            BOOL bSuccess;
            LARGE_INTEGER pos, newOffset;
            pos.QuadPart = 0;
            bitmapsize = img.volumeBitmapLength;
            offsetpos = img.volumeBitmapOffset;
            data = img.volumeBitmapOffset;
			if (bitmapsize > 0){
				InitReader(offsetpos, (DWORD)bitmapsize, metaHandle);
			}
            //delete read;
            //delete write;
            read = new Read(initialReader, finalReader, fileHandle, driveHandle, partitionsize, position, clustersize, isEncrypted, 0, location, src);
            write = new Write(writerIn, writerOut, metaHandle, driveHandle, partitionsize, position, clustersize, restoreUsedOnly, location, src, secretKey);
        }
        if (read != NULL)
            read->Resume();
        if (write != NULL)
            write->Resume();
        WaitForSingleObject(read->GetHandle(), INFINITE);
        WaitForSingleObject(write->GetHandle(), INFINITE);
        CloseHandle(read->GetHandle());
        CloseHandle(write->GetHandle());
        Terminate();
        if (driveHandle)
            CloseHandle(driveHandle);
        if (metaHandle)
            CloseHandle(metaHandle);
        if (fileHandle)
            CloseHandle(fileHandle);

        return 0;
    } catch (int e) {
        return e;
    }
}

int Opentargetfile(wstring name, wstring mode) {
    DWORD access = GENERIC_READ | (mode == L"write" ? GENERIC_WRITE : 0);
    DWORD createMode = (mode == L"write" ? OPEN_ALWAYS : OPEN_EXISTING);
    // note: use OPEN_ALWAYS and not CREATE_ALWAYS because file header is written later in an existing file!
    fileMode = mode;
    if (name.c_str()) {
        fileHandle = CreateFile(name.c_str(), access, FILE_SHARE_READ, NULL, createMode, FILE_ATTRIBUTE_NORMAL, NULL);
        if (fileHandle == INVALID_HANDLE_VALUE) {
            logdrive->log(NORMAL, L"Invalid file handle %d\n", GetLastError());
            return 1;
        }

    }
    return 0;
}

int Opendisk(wstring name, wstring mode) {
    PARTITION_INFORMATION_EX partInfo;
    DISK_GEOMETRY diskGeometry;
    NTFS_VOLUME_DATA_BUFFER ntfsVolData;
    GET_LENGTH_INFORMATION lengthInfo;
    DWORD buf, res;
    long ntStatus;
    bool isRawDisk;
    DWORD shareMode;
    int val;
    diskName = name;
    diskMode = mode;
    isRawDisk = diskName.find(L"Partition0") != std::string::npos;
    if (isRawDisk) {
        shareMode = FILE_SHARE_READ | FILE_SHARE_WRITE;
        DWORD access = (mode == L"write") ? (GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE) : GENERIC_READ | SYNCHRONIZE;
        ntStatus = OpenAPI(&driveHandle, diskName.c_str(), access, FILE_ATTRIBUTE_NORMAL, shareMode, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT | FILE_RANDOM_ACCESS | FILE_NON_DIRECTORY_FILE);
        if (ntStatus != 0) {
            logdrive->log(NORMAL, L"Opening raw disk failed with error %d\n", ntStatus);
            return 1;
        }
        if (volumecount > 0) {
            wstring rootName = diskName.substr(0, diskName.length() - 1);
            val = Lockvolumes(rootName, volumecount);
        }
    } else {
        shareMode = FILE_SHARE_DELETE | FILE_SHARE_WRITE | FILE_SHARE_READ;
        DWORD access = (mode == L"write") ? (GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE) : GENERIC_READ | SYNCHRONIZE;
        ntStatus = OpenAPI(&driveHandle, diskName.c_str(), access, FILE_ATTRIBUTE_NORMAL, shareMode, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT | FILE_RANDOM_ACCESS | FILE_NON_DIRECTORY_FILE);
        if (ntStatus != 0) {
            logdrive->log(NORMAL, L"Opening disk failed with error %d\n", ntStatus);
            return 1;
        }
    }
    if (diskMode == L"read") {
        memset(&partInfo, 0, sizeof (partInfo));
        memset(&diskGeometry, 0, sizeof (diskGeometry));
        memset(&lengthInfo, 0, sizeof (lengthInfo));
        memset(&ntfsVolData, 0, sizeof (ntfsVolData));
        res = DeviceIoControl(driveHandle, IOCTL_DISK_GET_PARTITION_INFO_EX, NULL, 0, &partInfo, sizeof (partInfo), &buf, NULL);
        // on some disks this might fail try PARTITION_INFORMATION then
        if (res == 0) {
            PARTITION_INFORMATION partInfo2;
            memset(&partInfo, 0, sizeof (partInfo));
            res = DeviceIoControl(driveHandle, IOCTL_DISK_GET_PARTITION_INFO, NULL, 0, &partInfo2, sizeof (partInfo2), &buf, NULL);
            Type = partInfo2.PartitionType;
        } else {
            Type = partInfo.Mbr.PartitionType;
        }
        mounted = DeviceIoControl(driveHandle, FSCTL_IS_VOLUME_MOUNTED, NULL, 0, NULL, 0, &buf, NULL);
        res = DeviceIoControl(driveHandle, IOCTL_DISK_GET_LENGTH_INFO, NULL, 0, &lengthInfo, sizeof (lengthInfo), &buf, NULL);
        if (res == FALSE)
            partitionsize = partInfo.PartitionLength.QuadPart; // IOCTL_DISK_GET_LENGTH_INFO not available on some older windows versions
        else
            partitionsize = lengthInfo.Length.QuadPart;


        res = DeviceIoControl(driveHandle, IOCTL_DISK_GET_DRIVE_GEOMETRY, NULL, 0, &diskGeometry, sizeof (diskGeometry), &buf, NULL);


        bytesPerSector = diskGeometry.BytesPerSector;
        res = DeviceIoControl(driveHandle, FSCTL_GET_NTFS_VOLUME_DATA, NULL, 0, &ntfsVolData, sizeof (ntfsVolData), &buf, NULL);
        if (res != 0) {
            // we have an NTFSVolume
            bytesPerCluster = ntfsVolData.BytesPerCluster;
        }

    } else if (diskMode == L"write") {
        res = DeviceIoControl(driveHandle, FSCTL_LOCK_VOLUME, NULL, 0, NULL, 0, &buf, NULL);
        if (res == 0) { // force a dismount
            int res1 = DeviceIoControl(driveHandle, FSCTL_DISMOUNT_VOLUME, NULL, 0, NULL, 0, &buf, NULL);
            res1 = CloseHandle(driveHandle);
            DWORD access = (mode == L"write") ? (GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE) : GENERIC_READ | SYNCHRONIZE;
            ntStatus = OpenAPI(&driveHandle, diskName.c_str(), access, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_DELETE | FILE_SHARE_WRITE | FILE_SHARE_READ, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT | FILE_RANDOM_ACCESS | FILE_NON_DIRECTORY_FILE);
            res1 = DeviceIoControl(driveHandle, FSCTL_LOCK_VOLUME, NULL, 0, NULL, 0, &buf, NULL);
        }
        locked = true;
        if (!isRawDisk) { // does not work for raw disks in Win XP, no problem in Vista
            res = DeviceIoControl(driveHandle, FSCTL_ALLOW_EXTENDED_DASD_IO, NULL, 0, NULL, 0, &buf, NULL);
            if (res == 0) {
                logdrive->log(NORMAL, L"Signalling file system driver failed with error %d\n", GetLastError());
                return 3;
            }
        }
    }
    return 0;
}

int Lockvolumes(wstring rootName, int containedVolumes) {
    Handles = new HANDLE[containedVolumes];
    const int bufferSize = 10;
    wchar_t buffer[bufferSize];
    int val;
    for (int i = 0; i < containedVolumes; i++)
        Handles[i] = NULL;
    for (int i = 0; i < containedVolumes; i++) {
        wstring volName = rootName;
        _itow_s(i + 1, buffer, 10, bufferSize);
        volName += buffer;
        val = OpenAndLockVolume(volName, i);
    }
    return 0;
}

int OpenAndLockVolume(wstring volName, int index) {
    DWORD result, buf;
    long ntStatus;
    HANDLE h;
    ntStatus = OpenAPI(&h, volName.c_str(), GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT | FILE_RANDOM_ACCESS | FILE_NON_DIRECTORY_FILE);
    Handles[index] = h;
    result = DeviceIoControl(h, FSCTL_LOCK_VOLUME, NULL, 0, NULL, 0, &buf, NULL);
    if (result == 0)
        logdrive->log(NORMAL, L"Locking volume failed with error %d\n", GetLastError());

    return 0;
}

void CloseAndUnlockVolume(int index) {
    HANDLE h = Handles[index];
    if (h != NULL && h != INVALID_HANDLE_VALUE) {
        DWORD result, buf;
        result = DeviceIoControl(h, FSCTL_UNLOCK_VOLUME, NULL, 0, NULL, 0, &buf, NULL);
        result = CloseHandle(h);
        Handles[index] = NULL;
    }
}

void WriteHeader() {
    DWORD sizeWritten;
    LARGE_INTEGER pos, curPos;
    pos.QuadPart = 0LL;
    BOOL ok = SetFilePointerEx(fileHandle, pos, &curPos, FILE_CURRENT);
    ok = SetFilePointerEx(fileHandle, pos, NULL, FILE_BEGIN);
    ok = WriteFile(fileHandle, &img, sizeof (img), &sizeWritten, NULL);
    ok = SetFilePointerEx(fileHandle, curPos, NULL, FILE_BEGIN);
}

void ReadHeader() {
    DWORD sizeRead;
    LARGE_INTEGER pos, curPos;
    pos.QuadPart = 0LL;
    BOOL ok = SetFilePointerEx(metaHandle, pos, &curPos, FILE_BEGIN);
    ok = ReadFile(metaHandle, &img, sizeof (img), &sizeRead, NULL);
    ok = SetFilePointerEx(metaHandle, curPos, NULL, FILE_BEGIN);
}

int ReadFromFile(wstring fileName) {
    MBRFileHeader header;
    HANDLE hDisk;
    DWORD result;
    DWORD bytesRead;


    hDisk = CreateFile(fileName.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

    partitioncount = 0;
    disksize = 0;
    delete Buffer;
    Buffer = NULL;
    ZeroMemory(&bootloader, sizeof (bootloader));

    // Read file header
    result = ReadFile(hDisk, &header, sizeof (header), &bytesRead, NULL);
    if (header.guid != magicGUID) {
        CloseHandle(hDisk);
        logdrive->log(NORMAL, L"GUID error\n");
        return 1;
    }
    if (header.versionMajor != 1) {
        CloseHandle(hDisk);
        logdrive->log(NORMAL, L"Version error\n");
        return 1;
    }

    // read boot loader block
    result = SetFilePointer(hDisk, header.bootLoaderOffset, NULL, FILE_BEGIN);
    result = ReadFile(hDisk, bootloader, header.bootLoaderLength, &bytesRead, NULL);

    // read partition information
    result = SetFilePointer(hDisk, header.partInfoOffset, NULL, FILE_BEGIN);
    dl = (DRIVE_LAYOUT_INFORMATION_EX*) new BYTE[header.partInfoLength];
    Buffer = new BYTE[header.partInfoLength];
    result = ReadFile(hDisk, dl, header.partInfoLength, &bytesRead, NULL);
    if (bytesRead != header.partInfoLength) {
        CloseHandle(hDisk);
        logdrive->log(NORMAL, L"Reading header failed with error %d\n", GetLastError());
        return 1;
    }
    partitioncount = header.partitionCount;
    logdrive->log(NORMAL, L"Partition count in readFromFile: %d\n", partitioncount);
    disksize = header.diskExtent;
    result = CloseHandle(hDisk);

    return 0;
}

BOOL setDiskAttr(HANDLE h_file, bool enable, bool isOnline) {
    DWORD bytes_returned = 0;
    BOOL b_offline = 0;
    SET_DISK_ATTRIBUTES disk_attr;
    ZeroMemory(&disk_attr, sizeof (disk_attr));
    disk_attr.Version = sizeof (SET_DISK_ATTRIBUTES);

    if (isOnline) {
        disk_attr.Attributes = enable ? DISK_ATTRIBUTE_OFFLINE : 0;
        disk_attr.AttributesMask = DISK_ATTRIBUTE_OFFLINE;
    } else {
        disk_attr.Attributes = enable ? DISK_ATTRIBUTE_READ_ONLY : 0;
        disk_attr.AttributesMask = DISK_ATTRIBUTE_READ_ONLY;
    }

    b_offline = DeviceIoControl(h_file, IOCTL_DISK_SET_DISK_ATTRIBUTES, &disk_attr, disk_attr.Version, NULL, 0, &bytes_returned, NULL);

    if (!b_offline) {
        logdrive->log(NORMAL, L"setdisk attr failed with error %d\n", (int) GetLastError());
    }

    if (!enable) BOOL b_update = DeviceIoControl(h_file, IOCTL_DISK_UPDATE_PROPERTIES, NULL, 0, NULL, 0, &bytes_returned, NULL);

    return b_offline;
}

void doPreOperationsGpt(HANDLE driveHandle) {
    DWORD no;

    BOOL RES = DeviceIoControl(driveHandle, IOCTL_DISK_DELETE_DRIVE_LAYOUT, NULL, 0, NULL, 0, &no, NULL);

    if (!RES) {
        printf("IOCTL_DISK_DELETE_DRIVE_LAYOUT failed with error %d\n", (int) GetLastError());
        return;
    }

    BOOL res = setDiskAttr(driveHandle, false, false);

    if (!res) {
        logdrive->log(NORMAL, L"Setting readonly attribute failed with error %d\n", GetLastError());
    }

    res = setDiskAttr(driveHandle, false, true);

    if (!res) {
        logdrive->log(NORMAL, L"Setting online attribute failed with error %d\n", GetLastError());
    }

    CREATE_DISK dsk;
    dsk.PartitionStyle = PARTITION_STYLE_GPT;

    GUID PARTITION_BASIC_DATA_GUID;

    CoCreateGuid(&PARTITION_BASIC_DATA_GUID);

    dsk.Gpt.DiskId = PARTITION_BASIC_DATA_GUID;
    dsk.Gpt.MaxPartitionCount = 128;

    DWORD bytesRead;

    DWORD bResult = DeviceIoControl(driveHandle,
            IOCTL_DISK_CREATE_DISK,
            &dsk, sizeof (dsk),
            NULL, 0,
            &bytesRead,
            NULL);

    if (!bResult) {
        logdrive->log(NORMAL, L"Create disk failed with error %d\n", GetLastError());
    }
}

int WriteDriveInfo(wstring driveName) {
    wstring driveDeviceName(driveName);
    DWORD buf, result, bytesWritten, dummy;
    int val;
    volumecount = 0;
    unsigned testpartitioncount;
    bool isRawDisk = driveName.find(L"Partition0") != std::string::npos;
    val = Opendisk(driveName, L"write");
    if (val)
        return 5;

    if (isRawDisk && dl->PartitionStyle != PARTITION_STYLE_MBR) {
        doPreOperationsGpt(driveHandle);
    }

    // Set extended read mode for disks in Vista (fails on Win XP, no problem in Vista)
    result = DeviceIoControl(driveHandle, FSCTL_ALLOW_EXTENDED_DASD_IO, NULL, 0, NULL, 0, &buf, NULL);
    result = SetFilePointer(driveHandle, 0, NULL, FILE_BEGIN);
    result = WriteFile(driveHandle, bootloader, sizeof (bootloader), (DWORD *) & bytesWritten, NULL);
    DWORD bufferSize = (partitioncount - 1) * sizeof (PARTITION_INFORMATION_EX) + sizeof (DRIVE_LAYOUT_INFORMATION_EX);
    result = DeviceIoControl(driveHandle, IOCTL_DISK_SET_DRIVE_LAYOUT_EX, dl, bufferSize, NULL, 0, &buf, NULL);
    if (result == 0) {
        logdrive->log(NORMAL, L"Setting drive layout failed with error %d\n", GetLastError());
        return 1;
    }
    result = DeviceIoControl(driveHandle, IOCTL_DISK_UPDATE_PROPERTIES, NULL, 0, NULL, 0, &dummy, NULL);
    if (result == 0) {
        logdrive->log(NORMAL, L"Updating drive properties failed with error %d\n", GetLastError());
        return 1;
    }
    result = DeviceIoControl(driveHandle, FSCTL_UNLOCK_VOLUME, NULL, 0, NULL, 0, &dummy, NULL);

    if (dl->PartitionStyle != PARTITION_STYLE_MBR) {
        BOOL res = setDiskAttr(driveHandle, false, true);

        if (!res) {
            logdrive->log(NORMAL, L"Two : Setting online attribute failed with error %d\n", GetLastError());
        }
    }

    DWORD bufferSize1 = 1024 * sizeof (PARTITION_INFORMATION_EX) + sizeof (DRIVE_LAYOUT_INFORMATION_EX);
    BYTE* Bufferestimate = new BYTE [bufferSize1];
    result = DeviceIoControl(driveHandle, IOCTL_DISK_GET_DRIVE_LAYOUT_EX, NULL, 0, Bufferestimate, bufferSize1, &buf, NULL);
    if (result == FALSE && GetLastError() == ERROR_INSUFFICIENT_BUFFER) {
        logdrive->log(NORMAL, L"Reading drive layout after applying failed with error %d\n", GetLastError());
        CloseHandle(driveHandle);
        return 1;
    }
    testpartitioncount = ((DRIVE_LAYOUT_INFORMATION_EX*) Bufferestimate)->PartitionCount;
    logdrive->log(NORMAL, L"After writeDriveInfo %d\n", testpartitioncount);
    if (testpartitioncount != partitioncount) {
        logdrive->log(NORMAL, L"Partitions count mismatch\n");
        return 3;
    }
    if (driveHandle != NULL) {
        DWORD res = CloseHandle(driveHandle);
        driveHandle = NULL;
    }
    return 0;
}

bool TestIsMBR(wstring &fileName) {
    bool ismbr;
    wstring mbrName = fileName;

    Creatembrfilename(mbrName);
    HANDLE h = CreateFile(mbrName.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h != INVALID_HANDLE_VALUE) {
        CloseHandle(h);
    }
    ismbr = h != INVALID_HANDLE_VALUE;
    fileName = mbrName;
    return ismbr;
}

void Terminate() {
    if (NULL != read)
        read->Terminate();

    if (NULL != write)
        write->Terminate();
    delete read;
    read = NULL;
    delete write;
    write = NULL;

}

int MakeSnapshot(int driveIndex) {
    try {
        int val;
        Info* mdriveInfo = driveList[driveIndex];
        int subPartitions = mdriveInfo->containedVolumes;
        LPCWSTR *mountPoints;
        Info **pContainedVolumes = new Info* [subPartitions];
        mountPoints = new LPCWSTR [subPartitions];
        int res = GetVolumes(mdriveInfo, pContainedVolumes, subPartitions);
        for (int i = 0, j = 0; i < res; i++) {

            if (pContainedVolumes[i]->guid.length() > 0)
                mountPoints[j++] = pContainedVolumes[i]->guid.c_str();
            else
                mountPoints[j++] = NULL; // unmounted volume
        }
        delete pContainedVolumes;
        /* else {
        subPartitions = 1;
        mountPoints = new LPCWSTR [1];
        }*/
        bool testvss = VssSupport();
        val = InitVss();
        if (val) {
            throw 1;
        }
        val = PrepareSnapshot(mountPoints, subPartitions);
        if (val)
            throw 1;
        delete mountPoints;
        return 0;
    } catch (int e) {
        return e;
    }
}

Info::Info(wstring& dpName, wstring& dvName, wstring& mPoint, bool isDisk) {
    displayName = dpName;
    deviceName = dvName;
    mountPoint = mPoint;
    bytes = sectors = bytesPerSector = sectorsPerTrack = clusterSize = 0;
    containedVolumes = 0;
    parent = NULL;
    isMounted = false;
}

BOOLEAN __stdcall FormatExCallback(CALLBACKCOMMAND Command, DWORD Modifier, PVOID Argument) {
    PDWORD percent;
    PTEXTOUTPUT output;
    PBOOLEAN status;
    static int createStructures = FALSE;

    // 
    // We get other types of commands, but we don't have to pay attention to them
    //
    switch (Command) {

        case PROGRESS:
            percent = (PDWORD) Argument;
            _tprintf(L"%d percent completed.\r", *percent);
            break;

        case OUTPUT:
            output = (PTEXTOUTPUT) Argument;
            fprintf(stdout, "%s", output->Output);
            break;

        case DONE:
            status = (PBOOLEAN) Argument;
            if (*status == FALSE) {
                _tprintf(L"FormatEx was unable to complete successfully.\n\n");
                sError = TRUE;
            }
            break;
    }
    return TRUE;
}

void loadFmifs() {
    sError = FALSE;
    fLib = LoadLibrary(L"fmifs.dll");
    if (fLib) {
        if (!(fFormatEx = (PFORMATEX) GetProcAddress(GetModuleHandle(L"fmifs.dll"), "FormatEx"))) {
            FreeLibrary(fLib);
            fLib = NULL;
            logdrive->log(NORMAL, L"Could not open format method in library...\n");
        }
    } else {
        logdrive->log(NORMAL, L"Could not load format library...\n");
    }
}

void releaseFmifs() {
    if (fLib != NULL)
        FreeLibrary(fLib);
}

bool FormatDrive(LPCWSTR drive, LPCWSTR label, BOOL quickFormat) {
    DWORD mediaFlag = FMIFS_HARDDISK;
    LPCWSTR fsFormat = L"NTFS";
    DWORD clusterSize = 0; // default
    sError = 0;


    fFormatEx(drive, mediaFlag, fsFormat, label, quickFormat, clusterSize, FormatExCallback);
    if (sError)
        return false;

    return true;
}


//int _tmain(int argc, _TCHAR* argv[])

int getDiskNumberFromDriveLetter(LPCWSTR drive) {
    HANDLE hDeviceHandle = NULL;

    hDeviceHandle = CreateFile(drive, 0, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

    if (hDeviceHandle != (HANDLE) - 1) {
        STORAGE_DEVICE_NUMBER sdn;
        DWORD returned;

        if (DeviceIoControl(hDeviceHandle, IOCTL_STORAGE_GET_DEVICE_NUMBER, NULL, 0, &sdn, sizeof (sdn), &returned, NULL));
        {
            return sdn.DeviceNumber;
        }

    }

    return -1;
}

__declspec(dllexport) int __cdecl callRestore(bool op, int cnt, int isOldBackup, LPCWSTR drivePath, bool isEncrypted, LPCWSTR secretKey, LPCWSTR backupLoc) {
    entireProcessStatus = 0;
    diskCnt = cnt;
    int val;
    wstring opval;
    int currentDiskNo;
    time_t rawtime;
    struct tm * timeinfo;
	wchar_t buffer[80];
	maindest = backupLoc;

    time(&rawtime);
    timeinfo = localtime(&rawtime);
    currentDiskNo = getDiskNumberFromDriveLetter(drivePath);

    wcsftime(buffer, 80, L"%d.%m.%Y_%H.%M", timeinfo);

	location = maindest;
	location += L"\\restore\\LogFile_";
    location += buffer;
    location += L".txt";
    LPWSTR logloc = (LPWSTR) location.c_str();
    logdrive = new Logger(logloc, (LPWSTR) level);

    if (op)
        opval = L"Restore";
    else
        opval = L"Irestore";
    val = operation(opval, isOldBackup, currentDiskNo, isEncrypted, secretKey);
    if (val == 0)
        logdrive->log(NORMAL, L"Restore completed\n");
    else
        logdrive->log(NORMAL, L"Restore failed\n");
    entireProcessStatus = 1;
    return val;
}

__declspec(dllexport) int __cdecl compareHash(LPSTR secretKey, LPCWSTR backupLoc) {

	wstring backup = backupLoc;
    time_t rawtime;
    struct tm * timeinfo;
    wchar_t buffer[80];

    time(&rawtime);
    timeinfo = localtime(&rawtime);

    wcsftime(buffer, 80, L"%d.%m.%Y_%H.%M", timeinfo);

	wstring logLocation = backup;
	logLocation+= L"\\restore\\LogFile_";
    logLocation += buffer;
    logLocation += L".txt";
    LPWSTR logloc = (LPWSTR) logLocation.c_str();
    Logger *hashLog = new Logger(logloc, (LPWSTR) level);

    HCRYPTPROV hProv = 0;
    HCRYPTHASH hHash = 0;
    BYTE *pbHash = NULL;
    BYTE *backupHash = NULL;
    DWORD dwHashLen;

    BYTE * pbBuffer = NULL;
    DWORD dwCount;
    DWORD i;
    unsigned long bufLen = 0;
    int compareResult = 1;
    HANDLE hSourceFile = NULL;

	wstring source = backup + L"\\encryptBackup.txt";
    if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_AES, 0)) {
        hashLog->log(NORMAL, L"CryptAcquireContext success\n");
    } else {
        if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_AES, CRYPT_NEWKEYSET)) {
            hashLog->log(NORMAL, L"CryptAcquireContext success in next attempt\n");
        } else {
            hashLog->log(NORMAL, L"CryptAcquireContext failed %d\n", (int) GetLastError());
            return 1;
        }
    }
    if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
        hashLog->log(NORMAL, L"CryptCreateHash failed %d\n", (int) GetLastError());
        return 1;
    }

    bufLen = strlen(secretKey);

    pbBuffer = (BYTE*) malloc(bufLen + 1);
    memset(pbBuffer, 0, bufLen + 1);
    memcpy(pbBuffer, (BYTE *) secretKey, bufLen);

    if (!CryptHashData(hHash, pbBuffer, bufLen, 0)) {
        hashLog->log(NORMAL, L"CryptHashData failed %d\n", (int) GetLastError());
        return 1;
    }

    dwCount = sizeof (DWORD);
    if (!CryptGetHashParam(hHash, HP_HASHSIZE, (BYTE *) & dwHashLen, &dwCount, 0)) {
        hashLog->log(NORMAL, L"CryptGetHashParam failed getting hash size %d\n", (int) GetLastError());
        return 1;
    }
    if ((pbHash = (unsigned char*) malloc(dwHashLen)) == NULL) {
        hashLog->log(NORMAL, L"Allocating memory for new hash failed\n");
        return 1;
    }
    memset(pbHash, 0, dwHashLen);
    if ((backupHash = (unsigned char*) malloc(dwHashLen)) == NULL) {
        hashLog->log(NORMAL, L"Allocating memory for backup hash failed\n");
        return 1;
    }
    memset(backupHash, 0, dwHashLen);


    if (!CryptGetHashParam(hHash, HP_HASHVAL, pbHash, &dwHashLen, 0)) {
        hashLog->log(NORMAL, L"CryptGetHashParam failed getting hash value %d\n", (int) GetLastError());
        return 1;
    }
    hSourceFile = CreateFile(source.c_str(), FILE_READ_DATA, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

    if (hSourceFile == NULL) {
        hashLog->log(NORMAL, L"CreateHandle failed with error %d\n", (int) GetLastError());
    }
    if (ReadFile(hSourceFile, backupHash, dwHashLen, &dwCount, NULL)) {

    } else {
        hashLog->log(NORMAL, L"ReadFile failed with error %d\n", (int) GetLastError());
    }
    if (memcmp(backupHash, pbHash, dwHashLen) == 0) {
        compareResult = 0;
    }
    if (hHash)
        CryptDestroyHash(hHash);
    if (hProv)
        CryptReleaseContext(hProv, 0);
    if (hSourceFile)
        CloseHandle(hSourceFile);
    if (pbBuffer)
        free(pbBuffer);
    if (pbHash)
        free(pbHash);
    if (backupHash)
        free(backupHash);
    if (hashLog)
        delete hashLog;
    return compareResult;
}