
#include "ImageBackup/Vss.h"
#include "ImageBackup/Logger.h"

LPWSTR levelvss=NORMAL;
LPWSTR vssloc;
Logger *logvss;

HMODULE vsshan;
CComPtr<IVssBackupComponents> backupcomp; 
GUID *snapshotId;
wstring *snapshotName;
unsigned snapshotCount;
vector<WriterClass> Writers;
bool sptcreated;
GUID sptSetId;
bool abnormalStop; 
bool exceptionStop;

bool VssSupport(wstring name) 
{
	// check if we run or XP or higher
	// check if not run on WIndows PE
	/*
	Basically, the logic can be this:
	-	If the key MiniNT is found in HKLM\System\ControlSet001\Control we are
	running on WinPE
	*/
	vssloc=(LPWSTR)name.c_str();
	logvss= new Logger(vssloc,(LPWSTR)levelvss);
	OSVERSIONINFOEX osInfo;
	HKEY hKey = NULL;
	LONG lRet;
	bool xpOrHigher, winPE;

	// check win pe
	lRet = RegOpenKeyEx( HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\MiniNT", 0, KEY_QUERY_VALUE, &hKey );
	if (lRet == ERROR_SUCCESS && hKey != NULL) {
		winPE = true;
		RegCloseKey(hKey);
	} else {
		winPE = false;
	}
	// check version number
	ZeroMemory(&osInfo, sizeof(osInfo));
	osInfo.dwOSVersionInfoSize = sizeof(osInfo);
	BOOL ok = GetVersionEx((LPOSVERSIONINFO)&osInfo);
	if (!ok)
		return false;

	xpOrHigher = osInfo.dwMajorVersion > 5 || (osInfo.dwMajorVersion == 5 && osInfo.dwMinorVersion >= 1);
	bool is32BitRunnninOn64 = Is32BitProcessRunningInWow64();
	return xpOrHigher && !winPE && !is32BitRunnninOn64;

}

bool Is32BitProcessRunningInWow64()
{
	typedef BOOL (WINAPI *LPFN_ISWOW64PROCESS) (HANDLE, PBOOL);
	LPFN_ISWOW64PROCESS fnIsWow64Process;
	BOOL bIsWow64 = FALSE;

	fnIsWow64Process = (LPFN_ISWOW64PROCESS)GetProcAddress(GetModuleHandle(L"kernel32"),"IsWow64Process");
	if (NULL != fnIsWow64Process)
	{
		BOOL ok = fnIsWow64Process(GetCurrentProcess(), &bIsWow64);
		if (!ok) {
			// todo: log error
		}
	}
	// else kernel function is missing and we are not in an 64Bit emulator
	return bIsWow64 != 0;
}

int  InitVss()
{
	backupcomp =  NULL; 
	sptSetId = GUID_NULL; 
	vsshan = NULL;
	sptcreated = false; 
	abnormalStop = true; 
	snapshotId = NULL;
	snapshotCount = 0;
	snapshotName = 0;
	snapshotId = 0;
	//load vssapi.dll
	vsshan = LoadLibrary(L"vssapi.dll");  
	if (!vsshan)
	{
logvss->log(NORMAL,L"Loading vssapi.dll failed\n");
		return 1;
	}
	return 0;
}

void CloseVss()
{
	backupcomp = NULL;
	/*if (vsshan)
		FreeLibrary(vsshan);
	vsshan = NULL;*/
	snapshotCount = 0;
	delete [] snapshotName;
	delete [] snapshotId;
}

int PrepareSnapshot(const wchar_t** volumeNames, int volumeCount)
{
	logvss->log(NORMAL,L"Preparing snapshot...\n");
	int fileCount = 0; 
	__int64 byteCount = 0; 
	int directoryCount = 0; 
	int skipCount = 0; 
	VSS_SNAPSHOT_PROP snapshotProperties; 

	try
	{
		const char CreateVssBackupComponent[] = "CreateVssBackupComponentsInternal";
		typedef HRESULT (__stdcall *CreateVssBackupComponents)(IVssBackupComponents**);
		CComPtr<IVssAsync> writerMetadata; 
		HRESULT metadataResult; 
		//        vector<WriterClass> writers;
		UINT cWriters; 
		GUID sptId; 
		WCHAR VolPathName[MAX_PATH];           
		CreateVssBackupComponents CreateVssBackupComponentsPtr = NULL;
		HRESULT prepareResult; 
		CComPtr<IVssAsync> doSpt;
		HRESULT doSptResult;
		HRESULT hr = CoInitialize(NULL);
		CreateVssBackupComponentsPtr = (CreateVssBackupComponents)::GetProcAddress(vsshan, CreateVssBackupComponent);
		if (!CreateVssBackupComponentsPtr)
		{       
			logvss->log(NORMAL,L"Error in createvssbackupcomponents\n");
			throw 1;
		}       
		CreateVssBackupComponentsPtr(&backupcomp); 
		hr=backupcomp->InitializeForBackup(); 
		if (hr!=S_OK) {
		logvss->log(NORMAL,L"InitializeForBackup %ld\n",hr);
		throw 1;
		}
		hr=backupcomp->GatherWriterMetadata(&writerMetadata); 
		if (hr!=S_OK) {
		logvss->log(NORMAL,L"GatherWriterMetadata %ld\n",hr);
		throw 1;
		}
		writerMetadata->Wait(); 
		writerMetadata->QueryStatus(&metadataResult, NULL); 
		if (metadataResult == VSS_S_ASYNC_CANCELLED)
		{
			if (SUCCEEDED(metadataResult))  
				metadataResult = E_FAIL;  // throw unspecified error
			logvss->log(NORMAL,L"Vss creation cancelled\n");
			throw 1;
		}
		
		hr=backupcomp->GetWriterMetadataCount(&cWriters);
		if (hr!=S_OK) {
		logvss->log(NORMAL,L"GetWriterMetadataCount %ld\n",hr);
		throw 1;
		}
		for (UINT iWriter = 0; iWriter < cWriters; ++iWriter)
		{
			WriterClass writer; 
			CComPtr<IVssExamineWriterMetadata> getMetadata; 
			GUID id; 
			GUID idInstance; 
			GUID idWriter; 
			BSTR bstrWriterName;
			VSS_USAGE_TYPE usage; 
			VSS_SOURCE_TYPE source; 
			UINT cIncludeFiles;
			UINT cExcludeFiles; 
			UINT cComponents; 


			hr=backupcomp->GetWriterMetadata(iWriter, &id, &getMetadata); 
			if (hr!=S_OK) {
		logvss->log(NORMAL,L"GetWriterMetadata(1,2,3) %ld\n",hr);
		throw 1;
		}
			
			hr=getMetadata->GetIdentity(&idInstance, &idWriter, &bstrWriterName, &usage, &source); 
			if (hr!=S_OK) {
		logvss->log(NORMAL,L"GetIdentity() %ld\n",hr);
		throw 1;
		}
			writer.instanceId=idInstance; 
			writer.compName=bstrWriterName; 
			writer.writerId=idWriter; 

			CComBSTR writerName(bstrWriterName); 

/*DWORD mask=NULL;
			hr=getMetadata -> GetBackupSchema(&mask);
			logvss->log(NORMAL,L"GetBackupSchema result() %ld\n",hr);
			logvss->log(NORMAL,L"GetBackupSchema() %ld\n",(mask));
			logvss->log(NORMAL,L"GetBackupSchema string() %s\n",bstrWriterName);*/

			hr=getMetadata->GetFileCounts(&cIncludeFiles, &cExcludeFiles, &cComponents); 
			if (hr!=S_OK) {
		logvss->log(NORMAL,L"GetFileCounts() %ld\n",hr);
		throw 1;
		}

			for (UINT iComponent = 0; iComponent < cComponents; ++iComponent)
			{
				WriterComp component; 
				CComPtr<IVssWMComponent> WMComponent; 
				PVSSCOMPONENTINFO CompInfo; 

				hr=getMetadata->GetComponent(iComponent, &WMComponent); 
				if (hr!=S_OK) {
		logvss->log(NORMAL,L"GetComponent() %ld\n",hr);
		throw 1;
		}

				hr=WMComponent->GetComponentInfo(&CompInfo); 
				if (hr!=S_OK) {
		logvss->log(NORMAL,L"GetComponentInfo() %ld\n",hr);
		throw 1;
		}


				if (CompInfo->bstrLogicalPath)
				{
					component.compPath=CompInfo->bstrLogicalPath; 
				}
				component.isSelectable=CompInfo->bSelectable; 
				component.writer=iWriter; 
				if (CompInfo->bstrComponentName)
					component.compName=CompInfo->bstrComponentName;
				if (CompInfo->type)
					component.compType=CompInfo->type;

				hr=WMComponent->FreeComponentInfo(CompInfo); 
				if (hr!=S_OK) {
		logvss->log(NORMAL,L"FreeComponentInfo() %ld\n",hr);
		throw 1;
		}
				writer.components.push_back(component); 

			}

			writer.ComputeComponentTree(); 

			for (unsigned int iComponent = 0; iComponent < writer.components.size(); ++iComponent)
			{
				WriterComp& component = writer.components[iComponent]; 
			}

			Writers.push_back(writer); 
		}


		hr=backupcomp->StartSnapshotSet(&sptSetId);
		if (hr!=S_OK) {
		logvss->log(NORMAL,L"StartSnapshotSet %ld\n",hr);
		throw 1;
		}
                
                VSS_ID providerId;
		wchar_t* clsid_str = L"{b5946137-7b9f-4925-af80-51abd60b20d5}";
		CLSIDFromString(clsid_str, &providerId);
                
		snapshotId = new GUID[volumeCount];
		snapshotName = new wstring[volumeCount];
		snapshotCount = volumeCount;
		for (int i=0; i < volumeCount; i++)
		{
			if (volumeNames[i] != NULL )
			{
				// mounted volume
				BOOL bWorked = ::GetVolumePathName(volumeNames[i], VolPathName, MAX_PATH);
				hr=backupcomp->AddToSnapshotSet(VolPathName, providerId, &sptId);
				if (hr!=S_OK) {
		logvss->log(NORMAL,L"AddToSnapshotSet %ld\n",hr);
		throw 1;
		}
				snapshotId[i] = sptId;  
			} else
			{
				// unmounted volume
				snapshotId[i] = GUID_NULL;
			}
		}

		for (unsigned int iWriter = 0; iWriter < Writers.size(); ++iWriter)
		{
			WriterClass writer = Writers[iWriter];
			for (unsigned int iComponent = 0; iComponent < writer.components.size(); ++iComponent)
			{
				WriterComp& component = writer.components[iComponent];

				bool addedComponent = ShouldAddComponent(component);
				writer.includedComp[iComponent]= addedComponent;
				if (addedComponent)
					backupcomp->AddComponent(writer.instanceId, writer.writerId,component.compType, component.compPath.c_str(), component.compName.c_str());
			}
		}
		CComPtr<IVssAsync> prepBackup; 
		hr=backupcomp->SetBackupState(FALSE, TRUE, VSS_BT_COPY,FALSE); 
		if (hr!=S_OK) {
		logvss->log(NORMAL,L"SetBackupState %ld\n",hr);
		throw 1;
		}
		backupcomp->PrepareForBackup(&prepBackup); 
		prepBackup->Wait(); 
		prepBackup->QueryStatus(&prepareResult, NULL); 


		if (prepareResult != VSS_S_ASYNC_FINISHED)
		{
			if (SUCCEEDED(prepareResult)) {
		logvss->log(NORMAL,L"PrepareForBackup %ld\n",prepareResult);
		throw 1;
		}

		}


		hr=backupcomp->DoSnapshotSet(&doSpt); 
		doSpt->Wait();
		sptcreated = true; 
		doSpt->QueryStatus(&doSptResult, NULL); 


		if (doSptResult != VSS_S_ASYNC_FINISHED)
		{
			logvss->log(NORMAL,L"DoSnapshotSet %ld\n",doSptResult);
			if (SUCCEEDED(doSptResult))  
				doSptResult = E_FAIL;  
			throw 1;
		}
/*for (unsigned int iWriter = 0; iWriter < Writers.size(); ++iWriter)
		{
			CComPtr<IVssWriterComponentsExt> getWriterComponent; 
			hr=backupcomp->GetWriterComponents(iWriter,&getWriterComponent);
			UINT count;
			hr=getWriterComponent->GetComponentCount(&count);
			logvss->log(NORMAL,L"GetComponentCount %ld\n",count);
			for(unsigned int i=0;i<count;i++){
				CComPtr<IVssComponent> vssComp;
				BSTR stamp;
				hr=getWriterComponent->GetComponent(i,&vssComp);
				logvss->log(NORMAL,L"GetComponent %ld\n",hr);
				hr=vssComp->GetBackupStamp(&stamp);
				logvss->log(NORMAL,L"GetBackupStamp result %ld\n",hr);
				logvss->log(NORMAL,L"GetBackupStamp %s\n",stamp);
			}
}*/


		for (int i=0; i < volumeCount; i++) {
			if (snapshotId[i] == GUID_NULL) {
				logvss->log(NORMAL,L"Value null\n");
				snapshotName[i].clear();
			} else {

				backupcomp->GetSnapshotProperties(snapshotId[i], &snapshotProperties);

				snapshotName[i] = snapshotProperties.m_pwszSnapshotDeviceObject;
			}
		}
		logvss->log(NORMAL,L"Snapshots prepared\n");
		return 0;
	}
	catch (int e)
	{
		return e;
	}
}

void ReleaseSnapshot(bool wasAborted)
{
	try {
		CComPtr<IVssAsync> buComplete;
		HRESULT buCompleteResult = VSS_S_ASYNC_PENDING; 

		if (backupcomp == NULL)
		{
			return; 
		}
		ReportBackupResultsToWriters(!wasAborted);

		if (sptcreated)
		{

			if (backupcomp) 
			{
				backupcomp->BackupComplete(&buComplete); 
			}
			if (buComplete) 
			{
				if (wasAborted) 
				{
					buComplete->Cancel(); 
				}
				buComplete->Wait(); 
				buComplete->QueryStatus(&buCompleteResult, NULL); 
			}

		}

		if (buCompleteResult != VSS_S_ASYNC_FINISHED)
		{
			logvss->log(NORMAL,L"Error in releasing snapshots\n");
		}
		abnormalStop = false;

	}
	catch (exception& e) 
	{
		exceptionStop = true;
		Cleanup();
		throw e; 
	}
	Cleanup();
}

void ReportBackupResultsToWriters(bool successful) 
{
	for (unsigned int iWriter = 0; iWriter < Writers.size(); ++iWriter)
	{
		WriterClass& writer = Writers[iWriter];

		for (unsigned int iComponent = 0; iComponent < writer.components.size(); ++iComponent)
		{
			if (writer.includedComp[iComponent]) 
			{
				WriterComp& component = writer.components[iComponent];       
				backupcomp->SetBackupSucceeded(writer.instanceId, writer.writerId,component.compType, component.compPath.c_str(), component.compName.c_str(), successful);

			}
		}
	}
}


void Cleanup()
{
	if (backupcomp == NULL)
	{
		return; 
	}

	try 
	{
		if (abnormalStop)
		{         
			backupcomp->AbortBackup(); 
                }
			if (sptcreated)
			{
				LONG cDeletedSnapshots; 
				GUID nonDeletedSnapshotId; 

				backupcomp->DeleteSnapshots(sptSetId, VSS_OBJECT_SNAPSHOT_SET, TRUE, 
					&cDeletedSnapshots, &nonDeletedSnapshotId);// omit CHECK_HRESULT(, L"DeleteSnapshots"); 

			}		
	}
	catch (exception& e)
	{
		// if cleanup was called from raising an exception than it is probable that the cleanup actions
		// cause another exception that we simply ignore then
		if (!exceptionStop)
		{
			abnormalStop = true; 
			sptcreated = false;
			backupcomp = NULL;
			throw e;
		}
	}
	abnormalStop = true; 
	sptcreated = false;
	backupcomp = NULL;
}


const wchar_t* GetSnapshotDeviceName(int driveIndex) 
{
	return snapshotName[driveIndex].empty() ? NULL : snapshotName[driveIndex].c_str();
	// remove prefix \\?\GLOBALROOT
}

bool ShouldAddComponent(WriterComp& component)
{
	// Component should not be added if
	// 1) It is not selectable for backup and 
	// 2) It has a selectable ancestor
	// Otherwise, add it. 

	if (component.isSelectable)
	{
		return true; 
	}

	return !component.isAncestorSelectable();

}