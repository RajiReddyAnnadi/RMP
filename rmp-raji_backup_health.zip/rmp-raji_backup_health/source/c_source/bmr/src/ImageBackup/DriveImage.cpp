// Completebu.cpp : Defines the entry point for the console application.

#include "ImageBackup/DriveImage.h"
#include "ImageBackup/BuildIndex.h"
#include "ImageBackup/Read.h"
#include "ImageBackup/Write.h"
#include "ImageBackup/Util.h"
#include "ImageBackup/Source.h"
#include "ImageBackup/Logger.h"
#include <fstream>
#include <math.h>
#include <time.h>
#include <shlwapi.h>
#define BUFSIZE 2097152
#define FMIFS_HARDDISK 0xC
using namespace std;

Read *read;
Write *write;
wstring location;
wstring usnLocation;
HANDLE* Handles;
IMGFileHeader img;
wstring usnvalue;
wstring buDetails;
wstring mapDetails;
fstream usnfile;
ofstream buDetailsFile;
ofstream mapDetailsFile;
Logger *logdrive;
LPWSTR level = NORMAL;
wstring maindest;
int *validPartitions;
long *timeArray;
DWORD readError;
int volumeCnt = 0, isVolumeAvailable = 0;
bool statusFlag;

int performRestore(int type, wstring files, wstring merge, wstring user, wstring pwd, bool isEncrypted, wstring secretKey) {
    int retval = 1, harddiskcnt = 0;
    isVolumeAvailable = 0;
    logdrive->log(NORMAL, L"Restore started %ws\n", files.c_str());
    std::vector<string> volumeList;
    size_t pos;
    string backupList, delimiter = "<?>";
    backupList.assign(files.begin(), files.end());

    while ((pos = backupList.find(delimiter)) != string::npos) {
        volumeList.push_back(backupList.substr(0, pos));
        backupList.erase(0, pos + delimiter.length());
    }
    harddiskcnt = ListDrives();

    if (harddiskcnt == -1) {
        logdrive->log(NORMAL, L"Restore failed due to error while listing drives");
        return 1;
    } else {
        logdrive->log(NORMAL, L"harddiskcnt %d\n", harddiskcnt);
        buDetailsFile.open(buDetails, ios::out | ios::app);
        for (int i = 0; i < harddiskcnt; i++) {
            wstring srcfilename, targetdrivename, mergePath;

            srcfilename = maindest;
            mergePath = merge;
            if (type == 0) //BMR Backup
            {
                srcfilename += L"\\Harddisk";
                srcfilename += to_wstring(i);
                if (mergePath != L"-") {
                    mergePath += L"\\Harddisk";
                    mergePath += to_wstring(i);
                }
            }

            targetdrivename = L"\\Device\\Harddisk";
            targetdrivename += to_wstring(i);
            targetdrivename += L"\\Partition0";
            retval = RestoreDrive(srcfilename, targetdrivename, volumeList, mergePath, user, pwd, isEncrypted, secretKey);
            if (retval == 1) {
                buDetailsFile << 1;
                buDetailsFile << endl;
            }
            srcfilename.clear();
            targetdrivename.clear();
            mergePath.clear();
        }
        buDetailsFile.close();
    }
    for (unsigned n = 0; n < driveList.size(); n++)
        delete driveList[n];

    if (isVolumeAvailable == 0) { //Selected volumes not found in the Server
        logdrive->log(NORMAL, L"Selected volumes not found in the Server\n");
        return 456;
    }
    return retval;
}

int operation(wstring op, wstring files, bool isEncrypted, wstring secretKey) {
    int retval = 1, harddiskcnt = 0;
    if (op == L"Backup") {
        logdrive->log(NORMAL, L"Backup started\n");
        harddiskcnt = ListDrives();
        if (harddiskcnt == -1) {
            logdrive->log(NORMAL, L"Backup failed due to error while listing drives\n");
            return 1;
        } else {
            logdrive->log(NORMAL, L"harddiskcnt %d\n", harddiskcnt);
            buDetailsFile.open(buDetails, ios::out | ios::app);
            mapDetailsFile.open(mapDetails, ios::out | ios::app);
            buDetailsFile << harddiskcnt;
            buDetailsFile << endl;
            idxLogger(location);

            if (isEncrypted) {
                wstring encryptedFile = maindest + L"\\encryptBackup.txt";
                if (!PathFileExists(encryptedFile.c_str())) {
                    writePasswordHash(encryptedFile, secretKey);
                }
            }
            for (int i = 0; i < harddiskcnt; i++) {
                usnvalue = usnLocation;
                usnvalue += L"\\usnvalues_";
                usnvalue += to_wstring(i);
                usnvalue += L".txt";
                wstring srcdrivename = L"\\Device\\Harddisk";
                srcdrivename += to_wstring(i);
                srcdrivename += L"\\Partition0";
                wstring targetfilename = maindest;
                targetfilename += L"\\Harddisk";
                targetfilename += to_wstring(i);
                if (!CreateDirectory(targetfilename.c_str(), NULL)) {
                    DWORD error = GetLastError();
                    if (error != ERROR_ALREADY_EXISTS) {
                        logdrive->log(NORMAL, L"CreateDirectory failed with error %d\n", GetLastError());
                        return 1;
                    }
                }
                retval = DriveBackup(srcdrivename, targetfilename, i, isEncrypted, secretKey);
                if (retval == 1) {
                    buDetailsFile << 1;
                    buDetailsFile << endl;
                } else if (retval == 112) {
                    logdrive->log(NORMAL, L"Stopping backup due to insufficient space\n");
                    break;
                }
                usnvalue.clear();
            }
            buDetailsFile.close();
            mapDetailsFile.close();
        }
        for (unsigned n = 0; n < driveList.size(); n++)
            delete driveList[n];
    } else if (op == L"Ibackup") {
        logdrive->log(NORMAL, L"Incremental backup started\n");
        harddiskcnt = ListDrives();
        if (harddiskcnt == -1) {
            logdrive->log(NORMAL, L"Backup failed due to error while listing drives");
            return 1;
        } else {
            logdrive->log(NORMAL, L"harddiskcnt %d\n", harddiskcnt);
            buDetailsFile.open(buDetails, ios::out | ios::app);
            mapDetailsFile.open(mapDetails, ios::out | ios::app);
            buDetailsFile << harddiskcnt;
            buDetailsFile << endl;
            if (isEncrypted) {
                wstring encryptedFile = maindest + L"\\encryptBackup.txt";
                if (!PathFileExists(encryptedFile.c_str())) {
                    writePasswordHash(encryptedFile, secretKey);
                }
            }
            for (int i = 0; i < harddiskcnt; i++) {
                usnvalue = usnLocation;
                usnvalue += L"\\usnvalues_";
                usnvalue += to_wstring(i);
                usnvalue += L".txt";
                wstring srcdrivename = L"\\Device\\Harddisk";
                srcdrivename += to_wstring(i);
                srcdrivename += L"\\Partition0";
                wstring targetfilename = maindest;
                targetfilename += L"\\Harddisk";
                targetfilename += to_wstring(i);
                if (!CreateDirectory(targetfilename.c_str(), NULL)) {
                    DWORD error = GetLastError();
                    if (error != ERROR_ALREADY_EXISTS) {
                        logdrive->log(NORMAL, L"CreateDirectory failed with error %d\n", GetLastError());
                        return 1;
                    }
                }
                retval = IncrBackup(srcdrivename, targetfilename, i, isEncrypted, secretKey);
                if (retval == 1) {
                    buDetailsFile << 1;
                    buDetailsFile << endl;
                } else if (retval == 112) {
                    logdrive->log(NORMAL, L"Stopping backup due to insufficient space\n");
                    break;
                } else if (retval == 123) {
                    logdrive->log(NORMAL, L"Stopping backup due to error 123\n");
                    break;
                }
                usnvalue.clear();
            }
            buDetailsFile.close();
            mapDetailsFile.close();
        }
        for (unsigned n = 0; n < driveList.size(); n++)
            delete driveList[n];
    } else if (op == L"Volume") {
        logdrive->log(NORMAL, L"Volume level Backup started %ws\n", files.c_str());

        int loop = 0;
        std::vector<string> volumeList;
        size_t pos;
        string backupList, delimiter = "<?>";
        backupList.assign(files.begin(), files.end());

        while ((pos = backupList.find(delimiter)) != string::npos) {
            volumeList.push_back(backupList.substr(0, pos));
            backupList.erase(0, pos + delimiter.length());
            loop++;
        }
        harddiskcnt = ListDrives();
        if (harddiskcnt == -1) {
            logdrive->log(NORMAL, L"Backup failed due to error while listing drives");
            return 1;
        } else {
            logdrive->log(NORMAL, L"harddiskcnt %d\n", harddiskcnt);
            buDetailsFile.open(buDetails, ios::out | ios::app);
            idxLogger(location);
            for (int i = 0; i < harddiskcnt; i++) {
                usnvalue = usnLocation;
                usnvalue += L"\\usnvalues_";
                usnvalue += to_wstring(i);
                usnvalue += L".txt";
                wstring srcdrivename = L"\\Device\\Harddisk";
                srcdrivename += to_wstring(i);
                srcdrivename += L"\\Partition0";
                retval = VolumeBackup(srcdrivename, maindest, volumeList, isEncrypted, secretKey);
                if (retval == 1) {
                    buDetailsFile << 1;
                    buDetailsFile << endl;
                } else if (retval == 112) {
                    logdrive->log(NORMAL, L"Stopping backup due to insufficient space\n");
                    break;
                }
                if (statusFlag && volumeCnt < loop) {
                    buDetailsFile << "BackupInProgress";
                    buDetailsFile << endl;
                }
                usnvalue.clear();
            }
            if (volumeCnt == loop) {
                buDetailsFile << "VolumeLevelEnd";
                buDetailsFile << endl;
            } else if (volumeCnt == 0) {
                retval = 456;
            }
            buDetailsFile.close();
        }
        for (unsigned n = 0; n < driveList.size(); n++)
            delete driveList[n];
    } else if (op == L"Ivolume") {
        logdrive->log(NORMAL, L"Incremental Volume level Backup started %ws\n", files.c_str());

        int loop = 0;
        std::vector<string> volumeList;
        size_t pos;
        string backupList, delimiter = "<?>";
        backupList.assign(files.begin(), files.end());

        while ((pos = backupList.find(delimiter)) != string::npos) {
            volumeList.push_back(backupList.substr(0, pos));
            backupList.erase(0, pos + delimiter.length());
            loop++;
        }

        harddiskcnt = ListDrives();
        if (harddiskcnt == -1) {
            logdrive->log(NORMAL, L"Backup failed due to error while listing drives");
            return 1;
        } else {
            logdrive->log(NORMAL, L"harddiskcnt %d\n", harddiskcnt);
            buDetailsFile.open(buDetails, ios::out | ios::app);
            for (int i = 0; i < harddiskcnt; i++) {
                usnvalue = usnLocation;
                usnvalue += L"\\usnvalues_";
                usnvalue += to_wstring(i);
                usnvalue += L".txt";
                wstring srcdrivename = L"\\Device\\Harddisk";
                srcdrivename += to_wstring(i);
                srcdrivename += L"\\Partition0";
                retval = IncrVolumeBackup(srcdrivename, maindest, volumeList, isEncrypted, secretKey);
                if (retval == 1) {
                    buDetailsFile << 1;
                    buDetailsFile << endl;
                } else if (retval == 3) {
                    logdrive->log(NORMAL, L"Stopping backup due to error in reading journal\n");
                    break;
                } else if (retval == 112) {
                    logdrive->log(NORMAL, L"Stopping backup due to insufficient space\n");
                    break;
                }
                if (statusFlag && volumeCnt < loop) {
                    buDetailsFile << "BackupInProgress";
                    buDetailsFile << endl;
                }
                usnvalue.clear();
            }
            if (volumeCnt == loop) {
                buDetailsFile << "VolumeLevelEnd";
                buDetailsFile << endl;
            } else if (volumeCnt == 0) {
                retval = 456;
            }
            buDetailsFile.close();
        }
        for (unsigned n = 0; n < driveList.size(); n++)
            delete driveList[n];
    } else if (op == L"File") {
        logdrive->log(NORMAL, L"File level Backup started %ws\n", files.c_str());

        map <string, vector<string> > fileList;

        size_t pos;
        string backupList, delimiter = "<?>";
        backupList.assign(files.begin(), files.end());

        while ((pos = backupList.find(delimiter)) != string::npos) {
            string file = backupList.substr(0, pos);
            string drive = file.substr(0, 2);
            fileList[drive].push_back(file);
            backupList.erase(0, pos + delimiter.length());
        }
        harddiskcnt = ListDrives();
        if (harddiskcnt == -1) {
            logdrive->log(NORMAL, L"Backup failed due to error while listing drives");
            return 1;
        } else {
            logdrive->log(NORMAL, L"harddiskcnt %d\n", harddiskcnt);
            clock_t t1, t2;
            t1 = clock();
            buDetailsFile.open(buDetails, ios::out | ios::app);
            for (int i = 0; i < harddiskcnt; i++) {
                usnvalue = usnLocation;
                usnvalue += L"\\usnvalues_";
                usnvalue += to_wstring(i);
                usnvalue += L".txt";
                wstring srcdrivename = L"\\Device\\Harddisk";
                srcdrivename += to_wstring(i);
                srcdrivename += L"\\Partition0";
                retval = FileBackup(srcdrivename, maindest, fileList, isEncrypted, secretKey);
                if (retval == 1) {
                    if (statusFlag) {
                        buDetailsFile << 1;
                        buDetailsFile << endl;
                    }
                } else if (retval == 112) {
                    logdrive->log(NORMAL, L"Stopping backup due to insufficient space\n");
                    break;
                } else {
                    if (statusFlag) {
                        buDetailsFile << "DiskEnd";
                        buDetailsFile << endl;
                    }
                }
                usnvalue.clear();
            }
            buDetailsFile << "FileLevelEnd";
            buDetailsFile << endl;
            t2 = clock();
            long timediff((long) t2 - (long) t1);
            long seconds = timediff / CLOCKS_PER_SEC;
            buDetailsFile << seconds;
            buDetailsFile << endl;
            buDetailsFile.close();
        }
        for (unsigned n = 0; n < driveList.size(); n++)
            delete driveList[n];
    } else if (op == L"Ifile") {
        logdrive->log(NORMAL, L"Incremental file level Backup started %ws\n", files.c_str());

        map <string, vector<string> > fileList;
        size_t pos;
        string backupList, delimiter = "<?>";
        backupList.assign(files.begin(), files.end());

        while ((pos = backupList.find(delimiter)) != string::npos) {
            string file = backupList.substr(0, pos);
            string drive = file.substr(0, 2);
            fileList[drive].push_back(file);
            backupList.erase(0, pos + delimiter.length());
        }
        harddiskcnt = ListDrives();
        if (harddiskcnt == -1) {
            logdrive->log(NORMAL, L"Backup failed due to error while listing drives");
            return 1;
        } else {
            logdrive->log(NORMAL, L"harddiskcnt %d\n", harddiskcnt);
            clock_t t1, t2;
            t1 = clock();
            buDetailsFile.open(buDetails, ios::out | ios::app);
            for (int i = 0; i < harddiskcnt; i++) {
                usnvalue = usnLocation;
                usnvalue += L"\\usnvalues_";
                usnvalue += to_wstring(i);
                usnvalue += L".txt";
                wstring srcdrivename = L"\\Device\\Harddisk";
                srcdrivename += to_wstring(i);
                srcdrivename += L"\\Partition0";
                retval = IncrFileBackup(srcdrivename, maindest, fileList, isEncrypted, secretKey);
                if (retval == 1) {
                    if (statusFlag) {
                        buDetailsFile << 1;
                        buDetailsFile << endl;
                    }
                } else if (retval == 3) {
                    logdrive->log(NORMAL, L"Stopping backup due to error in reading journal\n");
                    break;
                } else if (retval == 112) {
                    logdrive->log(NORMAL, L"Stopping backup due to insufficient space\n");
                    break;
                } else {
                    if (statusFlag) {
                        buDetailsFile << "DiskEnd";
                        buDetailsFile << endl;
                    }
                }
                usnvalue.clear();
            }
            buDetailsFile << "FileLevelEnd";
            buDetailsFile << endl;
            t2 = clock();
            long timediff((long) t2 - (long) t1);
            long seconds = timediff / CLOCKS_PER_SEC;
            buDetailsFile << seconds;
            buDetailsFile << endl;
            buDetailsFile.close();
        }
        for (unsigned n = 0; n < driveList.size(); n++)
            delete driveList[n];
    } else if (op == L"Restore") {
        /*logdrive->log(NORMAL, L"Restore started\n");
        std::vector<string> volumeList;
        size_t pos;
        string backupList, delimiter = "<?>";
        backupList.assign(files.begin(), files.end());

        while ((pos = backupList.find(delimiter)) != string::npos) {
            volumeList.push_back(backupList.substr(0, pos));
            backupList.erase(0, pos + delimiter.length());
        }
        retval = ListDrives();
        if (retval == 0) {
            buDetailsFile.open(buDetails, ios::out | ios::app);
            for (int i = 0; i < harddiskcnt; i++) {
                wstring srcfilename, targetdrivename;

                wstring srcfilename = maindest;
                if (type == 0) //BMR Backup
                {
                    srcfilename += L"\\Harddisk";
                    srcfilename += to_wstring(i);
                }

                targetdrivename = L"\\Device\\Harddisk";
                targetdrivename += to_wstring(i);
                targetdrivename += L"\\Partition0";
                retval = RestoreDrive(srcfilename, targetdrivename, volumeList);
                if (retval == 1) {
                    buDetailsFile << 1;
                    buDetailsFile << endl;
                }
                srcfilename.clear();
                targetdrivename.clear();
            }
            buDetailsFile.close();
        } else {
            logdrive->log(NORMAL, L"Backup failed due to error while listing drives");
            return 1;
        }
        for (unsigned n = 0; n < driveList.size(); n++)
            delete driveList[n];*/
    }
    return retval;
}

int ListDrives() {
    int ret, harddiskcnt = 0;
    Initialize(location);
    DWORD sectorsPerCluster;
    DWORD bytesPerSector;
    DWORD numberOfFreeClusters;
    DWORD totalNumberOfClusters;
    DWORD diskClusterSize = 0;
    DWORD clusterSize = 0;
    vector<wstring> devices;
    map<wstring, wstring> volumes;
    map<wstring, wstring> guidpath;
    ret = DirectoryObject(L"\\Device", devices);
    if (ret)
        return -1;
    if (devices.size() > 0) {

        wchar_t *buffer = new wchar_t [1024];

        for (wchar_t letter = L'A'; letter <= L'Z'; letter++) {
            wstring drive;
            drive = letter;
            drive += L":\\";
            if (GetVolumeNameForMountPoint(drive.c_str(), buffer, 1000)) {
                wstring volume = buffer;
                wstring param = L"\\??\\" + volume.substr(4, volume.length() - 5);
                wstring volumeLink;
                bool ok = GetNTLinkDestination(param.c_str(), volumeLink);
                if (ok) {
                    volumes[volumeLink] = drive;
                }
            }
        }
        delete[] buffer;

        DWORD charCount = 0;
        WCHAR name[MAX_PATH] = L"";
        DWORD error = ERROR_SUCCESS;
        HANDLE findHandle = INVALID_HANDLE_VALUE;
        size_t index = 0;
        BOOL success = FALSE;
        WCHAR volumeName[MAX_PATH] = L"";
        findHandle = FindFirstVolumeW(volumeName, ARRAYSIZE(volumeName));

        if (findHandle == INVALID_HANDLE_VALUE) {
            error = GetLastError();
            logdrive->log(NORMAL, L"FindFirstVolumeW failed with error code %d\n", error);
        }

        for (;;) {
            //
            //  Skip the \\?\ prefix and remove the trailing backslash.
            index = wcslen(volumeName) - 1;

            if (volumeName[0] != L'\\' || volumeName[1] != L'\\' || volumeName[2] != L'?' || volumeName[3] != L'\\' || volumeName[index] != L'\\') {
                error = ERROR_BAD_PATHNAME;
                logdrive->log(NORMAL, L"FindFirstVolumeW/FindNextVolumeW returned a bad path: %s\n", volumeName);
                break;
            }

            //
            //  QueryDosDeviceW does not allow a trailing backslash,
            //  so temporarily remove it.
            volumeName[index] = L'\0';

            charCount = QueryDosDeviceW(&volumeName[4], name, ARRAYSIZE(name));

            volumeName[index] = L'\\';

            if (charCount == 0) {
                error = GetLastError();
                logdrive->log(NORMAL, L"QueryDosDeviceW failed with error code %d\n", error);
                break;
            }

            guidpath[name] = volumeName;
            //
            //  Move on to the next volume.
            success = FindNextVolumeW(findHandle, volumeName, ARRAYSIZE(volumeName));

            if (!success) {
                error = GetLastError();

                if (error != ERROR_NO_MORE_FILES) {
                    logdrive->log(NORMAL, L"FindNextVolumeW failed with error code %d\n", error);
                    break;
                }

                //
                //  Finished iterating
                //  through all the volumes.
                error = ERROR_SUCCESS;
                break;
            }
        }

        FindVolumeClose(findHandle);
        findHandle = INVALID_HANDLE_VALUE;

        for (unsigned n = 0; n < devices.size(); n++) {
            wstring deviceName = devices[n], displayName, mountPoint, driveguid;
            size_t length = deviceName.length();
            size_t slashPos = deviceName.find(L'\\', 8); // pos of '\' after \Device\...
            size_t slashPos2;
            // search for \Device\HarddiskNN without a suffix
            if ((slashPos == string::npos && deviceName.find(L"Harddisk") == 8) && deviceName[16] >= L'0' && deviceName[16] <= L'9') {
                displayName = deviceName;
                mountPoint = volumes[deviceName];
                driveguid = guidpath[deviceName];
                if (!mountPoint.length() == 0)
                    displayName += L" (" + mountPoint + L")";
                if (deviceName.find(L"Harddisk") != string::npos) {
                    harddiskcnt++;
                    vector<wstring> partitions;
                    int partitionCount = 0;
                    DirectoryObject(deviceName.c_str(), partitions);
                    deviceName += L"\\Partition0";
                    //deviceName = partitions[0];
                    displayName += L" (entire disk)";
                    Info *diskInfo = new Info(displayName, deviceName, mountPoint, true);
                    diskInfo->guid = driveguid;
                    if (mountPoint.length() > 0) {
                        BOOL ok = GetDiskFreeSpace(mountPoint.c_str(), &sectorsPerCluster, &bytesPerSector, &numberOfFreeClusters, &totalNumberOfClusters);
                        if (ok) {
                            diskClusterSize = bytesPerSector * sectorsPerCluster;
                        } else {
                            diskClusterSize = 0;
                        }
                    }
                    // If this is a hard disk, check for and add any partitions
                    if (partitions.size() > 0) {
                        for (unsigned i = 0; i < partitions.size(); i++) {
                            wstring partitionDeviceName = partitions[i], partitionDisplayName, partitionMountPoint, pathguid;
                            slashPos = partitionDeviceName.find(L'\\', 8); // pos of '\' after \Device\HarddiskNN
                            slashPos2 = partitionDeviceName.find(L'\\', slashPos + 1); // pos of '\' after \Device\HarddiskNN\PartitionMM
                            if ((partitionDeviceName.find(L"Partition0") == string::npos) &&
                                    (partitionDeviceName.find(L"Partition") == slashPos + 1) && (slashPos2 == string::npos)
                                    && partitionDeviceName[slashPos + 10] >= L'0' && partitionDeviceName[slashPos + 10] <= L'9') { // \Device\HarddiskNN\PartionMM                
                                partitionCount++; // we found a real partition
                                Info *partitionInfo;
                                wstring volumeLink;
                                partitionDisplayName = partitionDeviceName;
                                bool ok = GetNTLinkDestination(partitionDeviceName.c_str(), volumeLink);
                                partitionMountPoint = volumes[volumeLink];
                                pathguid = guidpath[volumeLink];
                                if (partitionMountPoint.length() > 0)
                                    partitionDisplayName += L" (" + partitionMountPoint + L")";
                                if (partitionMountPoint.length() > 0) {
                                    BOOL ok = GetDiskFreeSpace(partitionMountPoint.c_str(), &sectorsPerCluster, &bytesPerSector, &numberOfFreeClusters, &totalNumberOfClusters);
                                    if (ok) {
                                        clusterSize = bytesPerSector * sectorsPerCluster;
                                    } else {
                                        clusterSize = 0;
                                    }
                                }
                                partitionInfo = new Info(partitionDisplayName, partitionDeviceName, partitionMountPoint, false);
                                partitionInfo->parent = diskInfo;
                                partitionInfo->clusterSize = clusterSize;
                                partitionInfo->guid = pathguid;
                                driveList.push_back(partitionInfo);
                            }
                        }
                    } // if
                    bool skipEntireDiskPartion = false;
                    if (partitionCount == 1) {
                        // if we have only one partition and this is same size as partition0 then it is an unpartioned device
                        // like a memory stick and we omit the entire disk as this is redundant
                        PARTITION_INFORMATION_EX partition;
                        unsigned __int64 bytes1, bytes2;
                        DWORD nCount;
                        long ntStatus;
                        HANDLE hDrive;

                        ntStatus = OpenAPI(&hDrive, deviceName.c_str(), GENERIC_READ, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_OPEN, FILE_SEQUENTIAL_ONLY);
                        DeviceIoControl(hDrive, IOCTL_DISK_GET_PARTITION_INFO_EX, NULL, 0, &partition, sizeof (partition), &nCount, NULL);
                        bytes1 = partition.PartitionLength.QuadPart;
                        CloseHandle(hDrive);
                        // find correct partition
                        for (unsigned i = 0; i < partitions.size(); i++) {
                            wstring partitionDeviceName = partitions[i];
                            slashPos = partitionDeviceName.find(L'\\', 8); // pos of '\' after \Device
                            slashPos2 = partitionDeviceName.find(L'\\', slashPos + 1); // pos of '\' after \Device\HarddiskNN
                            if ((partitionDeviceName.find(L"Partition0") == string::npos) && (partitionDeviceName.find(L"Partition") == slashPos + 1) && (slashPos2 == string::npos)
                                    && partitionDeviceName[slashPos + 10] >= L'0' && partitionDeviceName[slashPos + 10] <= L'9') { // \Device\HarddiskNN\PartionMM                
                                ntStatus = OpenAPI(&hDrive, partitionDeviceName.c_str(), GENERIC_READ, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_OPEN, FILE_SEQUENTIAL_ONLY);
                                DeviceIoControl(hDrive, IOCTL_DISK_GET_PARTITION_INFO_EX, NULL, 0, &partition, sizeof (partition), &nCount, NULL);
                                bytes2 = partition.PartitionLength.QuadPart;
                                CloseHandle(hDrive);
                            }
                        }
                        skipEntireDiskPartion = bytes1 == bytes2; // does root partition and first partions have same size?
                    }
                    if (skipEntireDiskPartion) {
                        delete diskInfo;
                        diskInfo = NULL;
                    } else {
                        diskInfo->containedVolumes = partitionCount;
                        diskInfo->clusterSize = diskClusterSize;
                        driveList.push_back(diskInfo);
                    }
                } // find hard disk
            }
        }
    }
    return harddiskcnt;

}

int DriveBackup(wstring src, wstring dest, int dskNo, bool isEncrypted, wstring secretKey) {
    int retval;
    int j = 0, encryptVal = 0;
    LONGLONG value;
    wstring volumeFileName, driveletter, metadata;
    wstring devicename = src;
    if (isEncrypted) {
        encryptVal = 3;
    } else {
        encryptVal = 2;
    }
    for (int i = 0; i < driveList.size(); i++) {
        if (driveList[i]->deviceName == devicename)
            index = i;
    }
    Info* driveInfo = driveList[index];

    Info **pContainedVolumes = NULL;
    int subPartitions = driveInfo->containedVolumes;

    pContainedVolumes = new Info* [subPartitions];
    int res = GetVolumes(driveInfo, pContainedVolumes, subPartitions);
    usnfile.open(usnvalue, ios::out);
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!driveletter.empty()) {
            string letter(driveletter.begin(), driveletter.end());
            buDetailsFile << letter;
            buDetailsFile << endl;
        } else {
            wstring name = pContainedVolumes[i]->deviceName;
            size_t pos = name.rfind(L"Partition");
            wstring partition = name.substr(pos);
            string unnamed(partition.begin(), partition.end());
            buDetailsFile << unnamed;
            buDetailsFile << endl;
        }
    }
    buDetailsFile << "Partitions:";
    buDetailsFile << endl;

    validPartitions = new int[subPartitions + 10];
    timeArray = new long[subPartitions + 10];
    for (int i = 0; i < subPartitions + 10; i++) {
        validPartitions[i] = 0;
        timeArray[i] = 0;
    }
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!driveletter.empty()) {
            value = QueryJournal(driveletter, location);
            if (value == -1) {
                validPartitions[i] = 1;
            } else {
                validPartitions[i] = 0;
            }
            usnfile << value;
            usnfile << endl;
            buDetailsFile << value;
            buDetailsFile << endl;
        } else {
            validPartitions[i] = 0;
        }
    }
    usnfile.close();
    buDetailsFile << "Status:";
    buDetailsFile << endl;
    wstring mbrfilename = dest;
    Creatembrfilename(mbrfilename);
    retval = ReadDriveInfo(src);
    if (retval)
        return 1;
    retval = WriteToFile(mbrfilename);
    if (retval) {
        if (retval == 112)
            return retval;
        return 1;
    }
    retval = MakeSnapshot(index);
    if (retval)
        return 1;
    buDetailsFile << 0; //Disk status to indicate it has crossed return stts
    buDetailsFile << endl;
    for (int i = 0; i < subPartitions; i++) {
        if (validPartitions[i] == 0) {
            logdrive->log(NORMAL, L"Backing up partition %d\n", i + 1);
            driveletter = pContainedVolumes[i]->mountPoint;
            size_t pos = driveletter.find('\\');
            driveletter = driveletter.substr(0, pos);
            if (!driveletter.empty()) {
                wstring tmp = driveletter.substr(0, 1);
                string letter(tmp.begin(), tmp.end());
                mapDetailsFile << to_string(dskNo);
                mapDetailsFile << "--";
                mapDetailsFile << to_string(i + 1);
                mapDetailsFile << "--";
                mapDetailsFile << letter;
                mapDetailsFile << endl;
                volumeFileName = dest + L"\\Partition" + driveletter.substr(0, 1) + L".img";
                logdrive->log(NORMAL, L"volumeFileName %ws\n", volumeFileName.c_str());
                metadata = dest + L"\\Partition" + driveletter.substr(0, 1) + L"_metadata.txt";
                logdrive->log(NORMAL, L"metadata %ws\n", metadata.c_str());
            } else {
                GenerateFileNameForEntireDiskBackup(volumeFileName, dest, pContainedVolumes[i]->deviceName);
                GenerateFileNameForMetadata(metadata, dest, pContainedVolumes[i]->deviceName);
            }
            vssindex = i;
            clock_t t1, t2;
            t1 = clock();
            retval = BackupandRestorePartitions(index, pContainedVolumes[i]->deviceName, volumeFileName, 4096, L"Backup", metadata, encryptVal, secretKey);
            if (retval || readError) {
                logdrive->log(NORMAL, L"Backup of partition %d failed\n", i + 1);
                buDetailsFile << 0;
                buDetailsFile << endl;
                buDetailsFile << "Failed";
                buDetailsFile << endl;
                if (retval == 112) {
                    logdrive->log(NORMAL, L"Backup of partition %d failed due to insufficient space\n", i + 1);
                    break;
                }
            } else {
                logdrive->log(NORMAL, L"Backup of partition %d completed\n", i + 1);
                buDetailsFile << partitionsize;
                buDetailsFile << endl;
                buDetailsFile << "Success";
                buDetailsFile << endl;
                int indexRetVal = indexCreation(volumeFileName, isEncrypted, secretKey);
            }
            t2 = clock();
            long timediff((long) t2 - (long) t1);
            long seconds = timediff / CLOCKS_PER_SEC;
            timeArray[j] = seconds;
            j++;
        } else {
            logdrive->log(NORMAL, L"Cannot backup partition %d\n", i + 1);
            buDetailsFile << "Inaccessible";
            buDetailsFile << endl;
            timeArray[j] = 0;
            j++;
        }
    }
    ReleaseSnapshot(false);
    CloseVss();
    buDetailsFile << "Time:";
    buDetailsFile << endl;
    for (int i = 0; i < j; i++) {
        buDetailsFile << timeArray[i];
        buDetailsFile << endl;
    }
    delete[] validPartitions;
    delete[] timeArray;
    delete[] pContainedVolumes;
    return retval;

}

int IncrBackup(wstring src, wstring dest, int dskNo, bool isEncrypted, wstring secretKey) {
    std::vector<string> volumeList;
    LONGLONG value;
    int retval;
    int j = 0, checkStatus = 0;
    wstring destName;
    wstring devicename = src;
    for (int i = 0; i < driveList.size(); i++) {
        if (driveList[i]->deviceName == devicename)
            index = i;
    }
    Info* driveInfo = driveList[index];
    const wchar_t* vssVolume;
    wstring device, driveletter;
    Info **pContainedVolumes = NULL;
    int subPartitions = driveInfo->containedVolumes;
    int validPartitionCnt = 0;
    pContainedVolumes = new Info* [subPartitions];
    int res = GetVolumes(driveInfo, pContainedVolumes, subPartitions);
    string usnval;
    validPartitions = new int[subPartitions + 10];
    timeArray = new long[subPartitions + 10];
    string *valarr = new string[subPartitions + 10];
    LONGLONG *newusnarr = new LONGLONG[subPartitions + 10];
    int loop = 0, newUsn = 0;
    size_t pos;
    for (int i = 0; i < subPartitions + 10; i++) {
        validPartitions[i] = 0;
        timeArray[i] = 0;
        valarr[i] = "0";
        newusnarr[i] = 0;
    }
    if (PathFileExists(usnvalue.c_str())) {
        usnfile.open(usnvalue, ios::in);
        while (getline(usnfile, usnval)) {
            valarr[loop++] = usnval;
        }
        usnfile.close();
    }
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!driveletter.empty()) {
            string letter(driveletter.begin(), driveletter.end());
            buDetailsFile << letter;
            buDetailsFile << endl;
            value = QueryJournal(driveletter, location);
            if (value == -1) {
                validPartitions[i] = 1;
            } else {
                validPartitions[i] = 0;
                validPartitionCnt++;
            }
            newusnarr[newUsn++] = value;
        } else {
            validPartitions[i] = 0;
        }
    }
    buDetailsFile << "Status:";
    buDetailsFile << endl;
    if (validPartitionCnt < loop) {
        logdrive->log(NORMAL, L"Returning error 123 due to count mismatch\n");
        return 123;
    }
    retval = MakeSnapshot(index);
    if (retval)
        return 1;
    buDetailsFile << 0; //Disk status to indicate it has crossed return stts
    buDetailsFile << endl;
    loop = 0;
    for (int i = 0; i < subPartitions; i++) {
        if (validPartitions[i] == 0) {
            driveletter = pContainedVolumes[i]->mountPoint;
            pos = driveletter.find('\\');
            driveletter = driveletter.substr(0, pos);
            if (!(driveletter.empty())) {
                string letter(driveletter.begin(), driveletter.end());
                wstring tmp = driveletter.substr(0, 1);
                string dletter(tmp.begin(), tmp.end());
                mapDetailsFile << to_string(dskNo);
                mapDetailsFile << "--";
                mapDetailsFile << to_string(i + 1);
                mapDetailsFile << "--";
                mapDetailsFile << dletter;
                mapDetailsFile << endl;
                logdrive->log(NORMAL, L"Backing up partition %d\n", i + 1);
                QueryJournal(driveletter, location);
                vssindex = i;
                destName = dest + L"\\Partition" + driveletter.substr(0, 1);
                vssVolume = GetSnapshotDeviceName(vssindex);
                if (vssVolume != NULL && *vssVolume != L'\0') // can be 0 if not mounted
                    device = vssVolume;
                else {
                    logdrive->log(NORMAL, L"vss volume name is not valid\n");
                    throw 1;
                }
                clock_t t1, t2;
                t1 = clock();
                retval = BackupDirectoryTree(letter, destName, device, valarr[loop++], volumeList, false, buDetailsFile, isEncrypted, secretKey);
                if (retval) {
                    checkStatus++;
                    logdrive->log(NORMAL, L"Backup of partition %d failed\n", i + 1);
                    buDetailsFile << "Failed";
                    buDetailsFile << endl;
                    if (retval == 112) {
                        logdrive->log(NORMAL, L"Backup of partition %d failed due to insufficient space\n", i + 1);
                        break;
                    }
                } else {
                    logdrive->log(NORMAL, L"Backup of partition %d completed\n", i + 1);
                    buDetailsFile << "Success";
                    buDetailsFile << endl;
                }
                t2 = clock();
                long timediff((long) t2 - (long) t1);
                long seconds = timediff / CLOCKS_PER_SEC;
                timeArray[j] = seconds;
                j++;
            }

            destName.clear();
            device.clear();
        } else {
            logdrive->log(NORMAL, L"Cannot backup partition %d\n", i + 1);
            buDetailsFile << "Inaccessible";
            buDetailsFile << endl;
            timeArray[j] = 0;
            j++;
        }
    }
    ReleaseSnapshot(false);
    CloseVss();
    buDetailsFile << "Time:";
    buDetailsFile << endl;
    for (int i = 0; i < j; i++) {
        buDetailsFile << timeArray[i];
        buDetailsFile << endl;
    }
    if (checkStatus == 0) {
        usnfile.open(usnvalue, ios::out | ios::trunc);
        for (int i = 0; i < newUsn; i++) {
            usnfile << newusnarr[i];
            usnfile << endl;
        }
        usnfile.close();
    }
    delete[] validPartitions;
    delete[] timeArray;
    delete[] valarr;
    delete[] newusnarr;
    delete[] pContainedVolumes;
    //buDetailsFile.close();
    return retval;

}

int VolumeBackup(wstring src, wstring dest, std::vector<string> &volumeList, bool isEncrypted, wstring secretKey) {
    statusFlag = false;
    int retval;
    int j = 0, encryptVal = 0;
    LONGLONG value;

    wstring volumeFileName, driveletter, metadata;
    wstring devicename = src;
    if (isEncrypted) {
        encryptVal = 3;
    } else {
        encryptVal = 2;
    }
    if (isEncrypted) {
        wstring encryptedFile = dest + L"\\encryptBackup.txt";
        if (!PathFileExists(encryptedFile.c_str())) {
            writePasswordHash(encryptedFile, secretKey);
        }
    }

    for (int i = 0; i < driveList.size(); i++) {
        if (driveList[i]->deviceName == devicename)
            index = i;
    }
    Info* driveInfo = driveList[index];

    Info **pContainedVolumes = NULL;
    int subPartitions = driveInfo->containedVolumes;

    pContainedVolumes = new Info* [subPartitions];
    int res = GetVolumes(driveInfo, pContainedVolumes, subPartitions);

    validPartitions = new int[subPartitions + 10];
    timeArray = new long[subPartitions + 10];
    for (int i = 0; i < subPartitions + 10; i++) {
        validPartitions[i] = 0;
        timeArray[i] = 0;
    }

    usnfile.open(usnvalue, ios::out);

    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!driveletter.empty()) {
            string letter(driveletter.begin(), driveletter.end());
            if (std::find(volumeList.begin(), volumeList.end(), letter) != volumeList.end()) {
                statusFlag = true;
                volumeCnt++;
                buDetailsFile << letter;
                buDetailsFile << endl;
                value = QueryJournal(driveletter, location);
                if (value == -1) {
                    validPartitions[i] = 1;
                } else {
                    validPartitions[i] = 0;
                }
                usnfile << value;
                usnfile << endl;
            }
        }
    }

    usnfile.close();


    if (statusFlag) {
        buDetailsFile << "Status:";
        buDetailsFile << endl;
    }

    retval = MakeSnapshot(index);
    if (retval) {
        return 1;
    }

    if (statusFlag) {
        buDetailsFile << 0; //Disk status to indicate it has crossed return stts
        buDetailsFile << endl;
    }

    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!driveletter.empty()) {
            string letter(driveletter.begin(), driveletter.end());
            if (std::find(volumeList.begin(), volumeList.end(), letter) != volumeList.end()) {
                if (validPartitions[i] == 0) {
                    logdrive->log(NORMAL, L"Backing up partition %d\n", i + 1);
                    //GenerateFileNameForEntireDiskBackup(volumeFileName, dest, pContainedVolumes[i]->deviceName);
                    volumeFileName = dest + L"\\Partition" + driveletter.substr(0, 1) + L".img";
                    logdrive->log(NORMAL, L"volumeFileName %ws\n", volumeFileName.c_str());
                    //GenerateFileNameForMetadata(metadata, dest, pContainedVolumes[i]->deviceName);
                    metadata = dest + L"\\Partition" + driveletter.substr(0, 1) + L"_metadata.txt";
                    logdrive->log(NORMAL, L"metadata %ws\n", metadata.c_str());
                    vssindex = i;
                    clock_t t1, t2;
                    t1 = clock();
                    retval = BackupandRestorePartitions(index, pContainedVolumes[i]->deviceName, volumeFileName, 4096, L"Backup", metadata, encryptVal, secretKey);
                    if (retval || readError) {
                        logdrive->log(NORMAL, L"Backup of partition %d failed\n", i + 1);
                        buDetailsFile << 0;
                        buDetailsFile << endl;
                        buDetailsFile << "Failed";
                        buDetailsFile << endl;
                        if (retval == 112) {
                            logdrive->log(NORMAL, L"Backup of partition %d failed due to insufficient space\n", i + 1);
                            break;
                        }
                    } else {
                        logdrive->log(NORMAL, L"Backup of partition %d completed\n", i + 1);
                        buDetailsFile << partitionsize;
                        buDetailsFile << endl;
                        buDetailsFile << "Success";
                        buDetailsFile << endl;
                        int indexRetVal = indexCreation(volumeFileName, isEncrypted, secretKey);
                    }
                    t2 = clock();
                    long timediff((long) t2 - (long) t1);
                    long seconds = timediff / CLOCKS_PER_SEC;
                    timeArray[j] = seconds;
                    j++;
                } else {
                    logdrive->log(NORMAL, L"Cannot backup partition %d\n", i + 1);
                    buDetailsFile << "Inaccessible";
                    buDetailsFile << endl;
                    timeArray[j] = 0;
                    j++;
                }
            } else {
                logdrive->log(NORMAL, L"Cannot find partition in backup list \n");
            }
        }
    }
    ReleaseSnapshot(false);
    CloseVss();
    if (statusFlag) {
        buDetailsFile << "Time:";
        buDetailsFile << endl;
        for (int i = 0; i < j; i++) {
            buDetailsFile << timeArray[i];
            buDetailsFile << endl;
        }
    }
    delete[] validPartitions;
    delete[] timeArray;
    delete[] pContainedVolumes;
    return retval;
}

int IncrVolumeBackup(wstring src, wstring dest, std::vector<string> &volumeList, bool isEncrypted, wstring secretKey) {
    statusFlag = false;
    LONGLONG value;
    int retval;
    int j = 0, checkStatus = 0;
    wstring destName;
    wstring devicename = src;
    if (isEncrypted) {
        wstring encryptedFile = dest + L"\\encryptBackup.txt";
        if (!PathFileExists(encryptedFile.c_str())) {
            writePasswordHash(encryptedFile, secretKey);
        }
    }
    for (int i = 0; i < driveList.size(); i++) {
        if (driveList[i]->deviceName == devicename)
            index = i;
    }
    Info* driveInfo = driveList[index];
    const wchar_t* vssVolume;
    wstring device, driveletter;
    Info **pContainedVolumes = NULL;
    int subPartitions = driveInfo->containedVolumes;
    pContainedVolumes = new Info* [subPartitions];
    int res = GetVolumes(driveInfo, pContainedVolumes, subPartitions);
    string usnval;
    validPartitions = new int[subPartitions + 10];
    timeArray = new long[subPartitions + 10];
    string *valarr = new string[subPartitions + 10];
    LONGLONG *newusnarr = new LONGLONG[subPartitions + 10];
    int loop = 0, newUsn = 0;
    size_t pos;
    for (int i = 0; i < subPartitions + 10; i++) {
        validPartitions[i] = 0;
        timeArray[i] = 0;
        valarr[i] = "0";
        newusnarr[i] = 0;
    }
    if (PathFileExists(usnvalue.c_str())) {
        usnfile.open(usnvalue, ios::in);
        while (getline(usnfile, usnval)) {
            valarr[loop++] = usnval;
        }
        usnfile.close();
    }
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!driveletter.empty()) {
            string letter(driveletter.begin(), driveletter.end());
            if (std::find(volumeList.begin(), volumeList.end(), letter) != volumeList.end()) {
                statusFlag = true;
                volumeCnt++;
                buDetailsFile << letter;
                buDetailsFile << endl;
                value = QueryJournal(driveletter, location);
                if (value == -1) {
                    validPartitions[i] = 1;
                } else {
                    validPartitions[i] = 0;
                }
                newusnarr[newUsn++] = value;
            }
        }
    }

    if (statusFlag) {
        buDetailsFile << "Status:";
        buDetailsFile << endl;
    }

    retval = MakeSnapshot(index);
    if (retval)
        return 1;
    if (statusFlag) {
        buDetailsFile << 0; //Disk status to indicate it has crossed return stts
        buDetailsFile << endl;
    }
    loop = 0;
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!(driveletter.empty())) {
            string letter(driveletter.begin(), driveletter.end());
            if (std::find(volumeList.begin(), volumeList.end(), letter) != volumeList.end()) {
                if (validPartitions[i] == 0) {
                    logdrive->log(NORMAL, L"Backing up partition %d\n", i + 1);
                    QueryJournal(driveletter, location);
                    vssindex = i;
                    destName = dest + L"\\Partition" + driveletter.substr(0, 1);
                    vssVolume = GetSnapshotDeviceName(vssindex);
                    if (vssVolume != NULL && *vssVolume != L'\0') // can be 0 if not mounted
                        device = vssVolume;
                    else {
                        logdrive->log(NORMAL, L"vss volume name is not valid\n");
                        throw 1;
                    }
                    clock_t t1, t2;
                    t1 = clock();
                    retval = BackupDirectoryTree(letter, destName, device, valarr[loop++], volumeList, false, buDetailsFile, isEncrypted, secretKey);
                    if (retval) {
                        checkStatus++;
                        logdrive->log(NORMAL, L"Backup of partition %d failed\n", i + 1);
                        buDetailsFile << "Failed";
                        buDetailsFile << endl;
                        if (retval == 3) {
                            logdrive->log(NORMAL, L"Backup of partition %d failed due to error in reading journal\n", i + 1);
                            break;
                        } else if (retval == 112) {
                            logdrive->log(NORMAL, L"Backup of partition %d failed due to insufficient space\n", i + 1);
                            break;
                        }
                    } else {
                        logdrive->log(NORMAL, L"Backup of partition %d completed\n", i + 1);
                        buDetailsFile << "Success";
                        buDetailsFile << endl;
                    }
                    t2 = clock();
                    long timediff((long) t2 - (long) t1);
                    long seconds = timediff / CLOCKS_PER_SEC;
                    timeArray[j] = seconds;
                    j++;
                } else {
                    logdrive->log(NORMAL, L"Cannot backup partition %d\n", i + 1);
                    buDetailsFile << "Inaccessible";
                    buDetailsFile << endl;
                    timeArray[j] = 0;
                    j++;
                }
            } else {
                logdrive->log(NORMAL, L"Cannot find partition in backup list \n");
            }

            destName.clear();
            device.clear();
        }
    }
    ReleaseSnapshot(false);
    CloseVss();
    if (statusFlag) {
        buDetailsFile << "Time:";
        buDetailsFile << endl;
        for (int i = 0; i < j; i++) {
            buDetailsFile << timeArray[i];
            buDetailsFile << endl;
        }
        if (checkStatus == 0) {
            usnfile.open(usnvalue, ios::out | ios::trunc);
            for (int i = 0; i < newUsn; i++) {
                usnfile << newusnarr[i];
                usnfile << endl;
            }
            usnfile.close();
        }
    }
    delete[] validPartitions;
    delete[] timeArray;
    delete[] valarr;
    delete[] newusnarr;
    delete[] pContainedVolumes;
    //buDetailsFile.close();
    return retval;

}

int FileBackup(wstring src, wstring dest, map <string, vector<string> > &fileList, bool isEncrypted, wstring secretKey) {
    statusFlag = false;
    int retval;
    LONGLONG value;

    wstring device, driveletter;

    wstring destName;
    const wchar_t* vssVolume;
    wstring devicename = src;
    if (isEncrypted) {
        wstring encryptedFile = dest + L"\\encryptBackup.txt";
        if (!PathFileExists(encryptedFile.c_str())) {
            writePasswordHash(encryptedFile, secretKey);
        }
    }
    for (int i = 0; i < driveList.size(); i++) {
        if (driveList[i]->deviceName == devicename)
            index = i;
    }
    Info* driveInfo = driveList[index];

    Info **pContainedVolumes = NULL;
    int subPartitions = driveInfo->containedVolumes;

    pContainedVolumes = new Info* [subPartitions];
    int res = GetVolumes(driveInfo, pContainedVolumes, subPartitions);

    validPartitions = new int[subPartitions + 10];
    for (int i = 0; i < subPartitions + 10; i++) {
        validPartitions[i] = 0;
    }

    usnfile.open(usnvalue, ios::out);

    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!driveletter.empty()) {
            string letter(driveletter.begin(), driveletter.end());
            if (fileList.find(letter) != fileList.end()) {
                statusFlag = true;
                buDetailsFile << letter;
                buDetailsFile << endl;
                value = QueryJournal(driveletter, location);
                if (value == -1) {
                    validPartitions[i] = 1;
                } else {
                    validPartitions[i] = 0;
                }
                usnfile << value;
                usnfile << endl;
            }
        }
    }

    usnfile.close();

    if (statusFlag) {
        buDetailsFile << "Status:";
        buDetailsFile << endl;
    }

    retval = MakeSnapshot(index);
    if (retval)
        return 1;
    if (statusFlag) {
        buDetailsFile << 0; //Disk status to indicate it has crossed return stts
        buDetailsFile << endl;
    }
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!(driveletter.empty())) {
            string letter(driveletter.begin(), driveletter.end());
            if (fileList.find(letter) != fileList.end()) {
                if (validPartitions[i] == 0) {
                    logdrive->log(NORMAL, L"Backing up partition %d\n", i + 1);
                    vssindex = i;
                    destName = dest + L"\\Partition" + driveletter.substr(0, 1);
                    vssVolume = GetSnapshotDeviceName(vssindex);
                    if (vssVolume != NULL && *vssVolume != L'\0') // can be 0 if not mounted
                        device = vssVolume;
                    else {
                        logdrive->log(NORMAL, L"vss volume name is not valid\n");
                        throw 1;
                    }
                    retval = FileLevelBackup(device, destName, letter, location, fileList, buDetailsFile, isEncrypted, secretKey);
                    if (retval) {
                        logdrive->log(NORMAL, L"Backup of partition %d failed\n", i + 1);
                        if (retval == 112) {
                            logdrive->log(NORMAL, L"Backup of partition %d failed due to insufficient space\n", i + 1);
                            break;
                        }
                    } else {
                        logdrive->log(NORMAL, L"Backup of partition %d completed\n", i + 1);
                    }
                    destName.clear();
                    device.clear();
                } else {
                    logdrive->log(NORMAL, L"Cannot backup partition %ws\n", driveletter.c_str());
                    auto it = fileList.find(letter);

                    if (it != fileList.end()) {
                        auto& vIt = it->second;

                        for (string elem : vIt) {
                            buDetailsFile << elem;
                            buDetailsFile << endl;
                            buDetailsFile << "Failed";
                            buDetailsFile << endl;
                        }
                    }
                }
            } else {
                logdrive->log(NORMAL, L"Cannot find partition in backup list \n");
            }
        }
    }
    ReleaseSnapshot(false);
    CloseVss();

    delete[] validPartitions;
    delete[] pContainedVolumes;
    return retval;
}

int IncrFileBackup(wstring src, wstring dest, map <string, vector<string> > &fileList, bool isEncrypted, wstring secretKey) {
    statusFlag = false;
    LONGLONG value;
    int retval;
    int checkStatus = 0;
    wstring destName;
    wstring devicename = src;
    if (isEncrypted) {
        wstring encryptedFile = dest + L"\\encryptBackup.txt";
        if (!PathFileExists(encryptedFile.c_str())) {
            writePasswordHash(encryptedFile, secretKey);
        }
    }
    for (int i = 0; i < driveList.size(); i++) {
        if (driveList[i]->deviceName == devicename)
            index = i;
    }
    Info* driveInfo = driveList[index];
    const wchar_t* vssVolume;
    wstring device, driveletter;
    Info **pContainedVolumes = NULL;
    int subPartitions = driveInfo->containedVolumes;
    pContainedVolumes = new Info* [subPartitions];
    int res = GetVolumes(driveInfo, pContainedVolumes, subPartitions);
    string usnval;
    validPartitions = new int[subPartitions + 10];
    string *valarr = new string[subPartitions + 10];
    LONGLONG *newusnarr = new LONGLONG[subPartitions + 10];
    int loop = 0, newUsn = 0;
    size_t pos;
    for (int i = 0; i < subPartitions + 10; i++) {
        validPartitions[i] = 0;
        valarr[i] = "0";
        newusnarr[i] = 0;
    }
    if (PathFileExists(usnvalue.c_str())) {
        usnfile.open(usnvalue, ios::in);
        while (getline(usnfile, usnval)) {
            valarr[loop++] = usnval;
        }
        usnfile.close();
    }
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!driveletter.empty()) {
            string letter(driveletter.begin(), driveletter.end());
            if (fileList.find(letter) != fileList.end()) {
                statusFlag = true;
                buDetailsFile << letter;
                buDetailsFile << endl;
                value = QueryJournal(driveletter, location);
                if (value == -1) {
                    validPartitions[i] = 1;
                } else {
                    validPartitions[i] = 0;
                }
                newusnarr[newUsn++] = value;
            }
        }
    }

    if (statusFlag) {
        buDetailsFile << "Status:";
        buDetailsFile << endl;
    }

    retval = MakeSnapshot(index);
    if (retval)
        return 1;

    if (statusFlag) {
        buDetailsFile << 0; //Disk status to indicate it has crossed return stts
        buDetailsFile << endl;
    }

    loop = 0;
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!(driveletter.empty())) {
            string letter(driveletter.begin(), driveletter.end());
            if (fileList.find(letter) != fileList.end()) {
                if (validPartitions[i] == 0) {
                    logdrive->log(NORMAL, L"Backing up partition %d\n", i + 1);
                    QueryJournal(driveletter, location);
                    vssindex = i;
                    destName = dest + L"\\Partition" + driveletter.substr(0, 1);
                    vssVolume = GetSnapshotDeviceName(vssindex);
                    if (vssVolume != NULL && *vssVolume != L'\0') // can be 0 if not mounted
                        device = vssVolume;
                    else {
                        logdrive->log(NORMAL, L"vss volume name is not valid\n");
                        throw 1;
                    }
                    auto it = fileList.find(letter);
                    retval = BackupDirectoryTree(letter, destName, device, valarr[loop++], it->second, true, buDetailsFile, isEncrypted, secretKey);
                    if (retval) {
                        checkStatus++;
                        logdrive->log(NORMAL, L"Backup of partition %d failed\n", i + 1);
                        if (retval == 3) {
                            logdrive->log(NORMAL, L"Backup of partition %d failed due to error in reading journal\n", i + 1);
                            break;
                        } else if (retval == 112) {
                            logdrive->log(NORMAL, L"Backup of partition %d failed due to insufficient space\n", i + 1);
                            break;
                        }
                    } else {
                        logdrive->log(NORMAL, L"Backup of partition %d completed\n", i + 1);
                    }
                } else {
                    logdrive->log(NORMAL, L"Cannot backup partition %ws\n", driveletter.c_str());
                    auto it = fileList.find(letter);

                    if (it != fileList.end()) {
                        auto& vIt = it->second;

                        for (string elem : vIt) {
                            buDetailsFile << elem;
                            buDetailsFile << endl;
                            buDetailsFile << "Failed";
                            buDetailsFile << endl;
                        }
                    }
                }
            } else {
                logdrive->log(NORMAL, L"Cannot find partition in backup list \n");
            }

            destName.clear();
            device.clear();
        }
    }
    ReleaseSnapshot(false);
    CloseVss();
    if (statusFlag) {
        if (checkStatus == 0) {
            usnfile.open(usnvalue, ios::out | ios::trunc);
            for (int i = 0; i < newUsn; i++) {
                usnfile << newusnarr[i];
                usnfile << endl;
            }
            usnfile.close();
        }
    }
    delete[] validPartitions;
    delete[] valarr;
    delete[] newusnarr;
    delete[] pContainedVolumes;
    //buDetailsFile.close();
    return retval;

}

int IncrRestore(wstring src, wstring dest, bool isEncrypted, wstring secretKey) {
    int retval = 1;
    wstring destName;
    wstring devicename = dest;
    for (int i = 0; i < driveList.size(); i++) {
        if (driveList[i]->deviceName == devicename)
            index = i;
    }
    Info* driveInfo = driveList[index];
    wstring driveletter;
    Info **pContainedVolumes = NULL;
    int subPartitions = driveInfo->containedVolumes;
    pContainedVolumes = new Info* [subPartitions];
    int res = GetVolumes(driveInfo, pContainedVolumes, subPartitions);
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!(driveletter.empty())) {
            //logdrive->log(NORMAL,L"Restoring partition %d\n",i+1);
            wcout << L"driveletter" << driveletter << endl;
            pos = (pContainedVolumes[i]->deviceName).rfind(L"Partition");
            destName = src;
            destName += L"\\";
            destName += (pContainedVolumes[i]->deviceName).substr(pos);
            if (PathFileExists(destName.c_str())) {
                //logdrive->log(NORMAL,L"destname %s\n",destName);
                wcout << L"destname" << destName << endl;
                HRESULT hr;

                hr = ModifyPrivilege(SE_RESTORE_NAME, TRUE);

                if (!SUCCEEDED(hr))
                    cout << "Failed to modify privilege." << endl;
                else
                    cout << "Successfully modified privilege." << endl;
                //FirstRestore(destName, driveletter);
                retval = RestoreDirectoryTree(destName, driveletter, isEncrypted, secretKey);

                if (retval)
                    //logdrive->log(NORMAL,L"Restore of partition %d failed\n",i+1);
                    wcout << L"failed to restore" << endl;
                else
                    //logdrive->log(NORMAL,L"Restore of partition %d completed\n",i+1);
                    wcout << L"successfully restored" << endl;
                //logdrive->log(NORMAL,L"retval %d\n",retval);
                wcout << L"retval" << retval << endl;
            }
            destName.clear();
        }
    }
    return 0;

}

int RestoreDrive(wstring src, wstring dest, std::vector<string> &volumeList, wstring mergePath, wstring user, wstring pwd, bool isEncrypted, wstring secretKey) {

    DWORD dwRetVal;
    NETRESOURCE nr;
    DWORD dwFlags;
    memset(&nr, 0, sizeof (NETRESOURCE));

    bool statusFlag = false;
    setLogger(location);
    int retval, j = 0, encryptVal = 0;
    wstring volumeFileName;
    unsigned subPartitions = 0;
    wstring devicename = dest;
    wstring driveletter;
    if (isEncrypted) {
        encryptVal = 1;
    } else {
        encryptVal = 0;
    }
    for (size_t i = 0; i < driveList.size(); i++) {
        if (driveList[i]->deviceName == devicename) {
            index = (int) i;
            break;
        }
    }

    Info* driveInfo = driveList[index];
    volumecount = driveInfo->containedVolumes;
    subPartitions = volumecount;
    Info **pContainedVolumes = NULL;
    pContainedVolumes = new Info* [subPartitions];
    int res = GetVolumes(driveInfo, pContainedVolumes, subPartitions);
    timeArray = new long[subPartitions + 10];
    for (int i = 0; i < subPartitions + 10; i++) {
        timeArray[i] = 0;
    }

    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!driveletter.empty()) {
            string letter(driveletter.begin(), driveletter.end());
            if (std::find(volumeList.begin(), volumeList.end(), letter) != volumeList.end()) {
                statusFlag = true;
                buDetailsFile << letter;
                buDetailsFile << endl;
            }
        }
    }

    if (statusFlag) {
        buDetailsFile << "Status:";
        buDetailsFile << endl;
    }

    /*loadFmifs();
    logdrive->log(NORMAL, L"Formatting volumes...\n");
    for (int i = 0; i < subPartitions; i++) {
        driveletter = pContainedVolumes[i]->mountPoint;
        size_t pos = driveletter.find('\\');
        wstring drvletter = driveletter.substr(0, pos);
        if (!drvletter.empty()) {
            string letter(drvletter.begin(), drvletter.end());
            if (std::find(volumeList.begin(), volumeList.end(), letter) != volumeList.end()) {
                bool result = FormatDrive(driveletter.c_str(), L"RMP", false);
                if (!result) {
                    logdrive->log(NORMAL, L"Formatting %s failed\n", driveletter.c_str());
                    return 1;
                } else {
                    logdrive->log(NORMAL, L"Formatted %s successfully\n", driveletter.c_str());
                }
            }
        }
    }
    releaseFmifs();*/

    driveHandle = NULL;
    position = 0;

    retval = Opendisk(devicename, L"read");
    if (retval) {
        return 1;
    }
    if (statusFlag) {
        buDetailsFile << 0; //Disk status to indicate it has crossed return stts
        buDetailsFile << endl;
    }
    if (driveHandle != NULL) {
        CloseHandle(driveHandle);
        driveHandle = NULL;
    }
    unsigned diskno;
    size_t pos1 = driveInfo->deviceName.find(L"Harddisk") + 8;
    size_t pos2 = driveInfo->deviceName.find(L'\\', pos1);
    diskno = _wtoi(driveInfo->deviceName.substr(pos1, pos2 - pos1).c_str());
    wstring volumeDeviceName, metadata;
    for (unsigned i = 0; i < subPartitions; i++) {
        CloseAndUnlockVolume(i);
        wstring driveletter = pContainedVolumes[i]->mountPoint;
        logdrive->log(NORMAL, L"driveletter %ws\n", driveletter.c_str());
        size_t pos = driveletter.find('\\');
        driveletter = driveletter.substr(0, pos);
        if (!driveletter.empty()) {
            string letter(driveletter.begin(), driveletter.end());
            if (std::find(volumeList.begin(), volumeList.end(), letter) != volumeList.end()) {
                logdrive->log(NORMAL, L"Restoring partition %d\n", i + 1);
                isVolumeAvailable++;
                GenerateDeviceNameForVolume(volumeDeviceName, diskno, i + 1);
                volumeFileName = src + L"\\Partition" + driveletter.substr(0, 1) + L".img";
                //GenerateFileNameForEntireDiskBackup(volumeFileName, src, volumeDeviceName);
                metadata = src + L"\\Partition" + driveletter.substr(0, 1) + L"_metadata.txt";
                //GenerateFileNameForMetadata(metadata, src, volumeDeviceName);
                logdrive->log(NORMAL, L"volumeDeviceName %ws\n", volumeDeviceName.c_str());
                logdrive->log(NORMAL, L"volumeFileName %ws\n", volumeFileName.c_str());
                logdrive->log(NORMAL, L"metadata %ws\n", metadata.c_str());
                clock_t t1, t2;
                t1 = clock();
                retval = BackupandRestorePartitions(index, volumeFileName, volumeDeviceName, 4096, L"Restore", metadata, encryptVal, secretKey);
                if ((retval == 3) || (retval == 87)) { //Writing data failed with error 87 comes instead of 112 when there is less space in the volume during restore
                    logdrive->log(NORMAL, L"Full Restore of partition %d failed due to insufficient space\n", i + 1);
                    buDetailsFile << "Failed (Insufficient space in the destination)";
                    buDetailsFile << endl;
                } else if (retval) {
                    logdrive->log(NORMAL, L"Full Restore of partition %d failed\n", i + 1);
                    buDetailsFile << "Failed";
                    buDetailsFile << endl;
                } else {
                    logdrive->log(NORMAL, L"Full Restore of partition %d completed\n", i + 1);
                    if (mergePath != L"-") {
                        nr.dwType = RESOURCETYPE_ANY;
                        nr.lpRemoteName = &mergePath[0];
                        nr.lpProvider = NULL;
                        dwFlags = CONNECT_TEMPORARY;
                        dwRetVal = WNetAddConnection2(&nr, pwd.c_str(), user.c_str(), dwFlags);
                        if (dwRetVal == NO_ERROR || dwRetVal == 1219) {
                            logdrive->log(NORMAL, L"Connect to mergePath successful\n");
                            HRESULT hr;
                            wstring destName = mergePath + L"\\Partition" + driveletter.substr(0, 1);
                            logdrive->log(NORMAL, L"destName %ws\n", destName.c_str());

                            if (PathFileExists(destName.c_str())) {
                                hr = ModifyPrivilege(SE_RESTORE_NAME, TRUE);

                                if (!SUCCEEDED(hr))
                                    logdrive->log(NORMAL, L"Failed to modify privilege.\n");
                                else
                                    logdrive->log(NORMAL, L"Successfully modified privilege.\n");

                                RenameFiles(destName, driveletter);
                                DeleteFiles(destName, driveletter);
                                retval = RestoreDirectoryTree(destName, driveletter, isEncrypted, secretKey);
                                if (retval) {
                                    logdrive->log(NORMAL, L"Incremental Restore of partition %d failed\n", i + 1);
                                } else {
                                    logdrive->log(NORMAL, L"Incremental Restore of partition %d completed\n", i + 1);
                                }
                            } else {
                                logdrive->log(NORMAL, L"destName %s not found\n", destName.c_str());
                            }
                            //dwRetVal = WNetCancelConnection2(mergePath.c_str(), 0, TRUE);
                            buDetailsFile << "Success";
                            buDetailsFile << endl;
                        } else {
                            logdrive->log(NORMAL, L"Connect to mergePath failed\n");
                            buDetailsFile << "Failed";
                            buDetailsFile << endl;
                        }
                    } else {
                        buDetailsFile << "Success";
                        buDetailsFile << endl;
                    }
                }
                t2 = clock();
                long timediff((long) t2 - (long) t1);
                long seconds = timediff / CLOCKS_PER_SEC;
                timeArray[j] = seconds;
                j++;
            } else {
                logdrive->log(NORMAL, L"Cannot find partition in restore list \n");
            }
        }
    }
    if (statusFlag) {
        buDetailsFile << "Time:";
        buDetailsFile << endl;
        for (int i = 0; i < j; i++) {
            buDetailsFile << timeArray[i];
            buDetailsFile << endl;
        }
    }
    delete[] timeArray;
    delete[] pContainedVolumes;
    return 0;
}

void WaitForDriveReady(int index, unsigned partitionCount, const wstring & targetDiskDeviceName) {
    int retries = 0;
    DWORD waitTime = 50;
    bool allPartitionsFound = false;
    wstring volumeDeviceName;
    while ((index < 0 || !allPartitionsFound) && retries++ < 5) {
        Sleep(waitTime); // wait a moment, may cause crash because list is not yet up to date
        // waitTime += 100;
        allPartitionsFound = true;
        ListDrives();
        Info* driveInfo = driveList[index];
        for (size_t i = 0; i < driveList.size(); i++) {
            if (driveList[i]->deviceName == targetDiskDeviceName) {
                index = (int) i;
                break;
            }
        }

        unsigned diskNo = 0;
        int volumeIndex;
        if (index >= 0) {
            for (unsigned i = 0; i < partitionCount; i++) {
                GenerateDeviceNameForVolume(volumeDeviceName, diskNo, i + 1);
                for (size_t i = 0; i < driveList.size(); i++) {
                    if (driveList[i]->deviceName == volumeDeviceName) {
                        volumeIndex = (int) i;
                        break;
                    }
                }

                if (volumeIndex < 0) {
                    allPartitionsFound = false;
                    logdrive->log(NORMAL, L"Device not available for backup\n");
                    break;
                }
            }
        }
    }

    if (index < 0)
        logdrive->log(NORMAL, L"Device not available for backup\n");

}

void GenerateDeviceNameForVolume(wstring& volumeFileName, unsigned diskNo, unsigned volumeNo) {
    const int bufSize = 10;
    wchar_t buffer[bufSize];
    volumeFileName = L"\\Device\\Harddisk";
    _ui64tow_s(diskNo, buffer, bufSize, 10);
    volumeFileName += buffer;
    volumeFileName += L"\\Partition";
    _ui64tow_s(volumeNo, buffer, bufSize, 10);
    volumeFileName += buffer;
}

int GetVolumes(const Info* driveInfo, Info** Volumes, int Count) {
    int result = 0;
    int j = 0;
    for (unsigned i = 0; i < driveList.size(); i++) {
        if (driveList[i]->parent == driveInfo && j < Count)
            Volumes[j++] = driveList[i];
    }
    return j;
}

void Creatembrfilename(wstring & name) {
    wstring mbrFileName = L"\\Bootloader.mbr";
    name += mbrFileName;
}

BOOLEAN __stdcall FormatExCallback(CALLBACKCOMMAND Command, DWORD Modifier, PVOID Argument) {
    PDWORD percent;
    PTEXTOUTPUT output;
    PBOOLEAN status;
    static int createStructures = FALSE;

    // 
    // We get other types of commands, but we don't have to pay attention to them
    //
    switch (Command) {

        case PROGRESS:
            percent = (PDWORD) Argument;
            _tprintf(L"%d percent completed.\r", *percent);
            break;

        case OUTPUT:
            output = (PTEXTOUTPUT) Argument;
            fprintf(stdout, "%s", output->Output);
            break;

        case DONE:
            status = (PBOOLEAN) Argument;
            if (*status == FALSE) {
                _tprintf(L"FormatEx was unable to complete successfully.\n\n");
                sError = TRUE;
            }
            break;
    }
    return TRUE;
}

void loadFmifs() {
    sError = FALSE;
    fLib = LoadLibrary(L"fmifs.dll");
    if (fLib) {
        if (!(fFormatEx = (PFORMATEX) GetProcAddress(GetModuleHandle(L"fmifs.dll"), "FormatEx"))) {
            FreeLibrary(fLib);
            fLib = NULL;
            logdrive->log(NORMAL, L"Could not open format method in library...\n");
        }
    } else {
        logdrive->log(NORMAL, L"Could not load format library...\n");
    }
}

void releaseFmifs() {
    if (fLib != NULL)
        FreeLibrary(fLib);
}

bool FormatDrive(LPCWSTR drive, LPCWSTR label, BOOL quickFormat) {
    DWORD mediaFlag = FMIFS_HARDDISK;
    LPCWSTR fsFormat = L"NTFS";
    DWORD clusterSize = 0; // default
    sError = 0;


    fFormatEx(drive, mediaFlag, fsFormat, label, quickFormat, clusterSize, FormatExCallback);
    if (sError)
        return false;

    return true;
}

int ReadDriveInfo(wstring source) {
    try {
        wstring name = source;
        HANDLE hFile;
        long ntStatus;
        DWORD bytesRead, buf, res;
        ntStatus = OpenAPI(&hFile, name.c_str(), GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT | FILE_RANDOM_ACCESS | FILE_NON_DIRECTORY_FILE);

        // allocate buffer that is large enough
        DWORD bufferSize = 1024 * sizeof (PARTITION_INFORMATION_EX) + sizeof (DRIVE_LAYOUT_INFORMATION_EX);
        BYTE* Bufferestimate = new BYTE [bufferSize];
        res = DeviceIoControl(hFile, IOCTL_DISK_GET_DRIVE_LAYOUT_EX, NULL, 0, Bufferestimate, bufferSize, &buf, NULL);
        if (res == FALSE && GetLastError() == ERROR_INSUFFICIENT_BUFFER) {
            logdrive->log(NORMAL, L"Reading drive layout failed with error %d\n", GetLastError());
            CloseHandle(hFile);
            throw 1;
        }
        partitioncount = ((DRIVE_LAYOUT_INFORMATION_EX*) Bufferestimate)->PartitionCount;

        // reallocate buffer with the size that is really in use
        bufferSize = (partitioncount - 1) * sizeof (PARTITION_INFORMATION_EX) + sizeof (DRIVE_LAYOUT_INFORMATION_EX);
        Buffer = new BYTE[bufferSize];
        CopyMemory(Buffer, Bufferestimate, bufferSize);
        delete[] Bufferestimate;

        if (((DRIVE_LAYOUT_INFORMATION_EX*) Buffer)->PartitionStyle != PARTITION_STYLE_MBR) {
            logdrive->log(NORMAL, L"Partition style other than MBR is found\n");
        }

        PARTITION_INFORMATION_EX* partInfo = &(((DRIVE_LAYOUT_INFORMATION_EX*) Buffer)->PartitionEntry[0]);

        // get size of disk
        GET_LENGTH_INFORMATION lengthInfo;
        res = DeviceIoControl(hFile, IOCTL_DISK_GET_LENGTH_INFO, NULL, 0, &lengthInfo, sizeof (lengthInfo), &buf, NULL);
        disksize = lengthInfo.Length.QuadPart;

        // Set extended read mode for disks in Vista (fails on Win XP, no problem in Vista)
        res = DeviceIoControl(hFile, FSCTL_ALLOW_EXTENDED_DASD_IO, NULL, 0, NULL, 0, &buf, NULL);



        // if (res == 0)
        //  ; // no error checking here because a failure always occurs on Win XP

        // Read Boot Loader Code
        res = SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
        if (res == INVALID_SET_FILE_POINTER) {
            logdrive->log(NORMAL, L"Invalid file pointer");
            throw 1;
        }
        res = ReadFile(hFile, bootloader, SIZE, &bytesRead, NULL);
        if (res == 0) {
            logdrive->log(NORMAL, L"Reading bootloader failed with error %d\n", GetLastError());
            throw 1;
        }
        res = CloseHandle(hFile);
        return 0;
    } catch (int e) {
        return e;
    }
}

int WriteToFile(wstring fileName) {
    try {
        HANDLE hFile;
        MBRFileHeader header;
        DWORD sizeWritten, bufferSize, res;

        header.guid = magicGUID;
        header.versionMajor = 1;
        header.versionMinor = 0;
        header.partitionCount = partitioncount;
        header.diskExtent = disksize;
        header.bootLoaderOffset = sizeof (MBRFileHeader);
        header.bootLoaderLength = SIZE;
        header.partInfoOffset = header.bootLoaderOffset + header.bootLoaderLength;
        header.partInfoLength = (partitioncount - 1) * sizeof (PARTITION_INFORMATION_EX) + sizeof (DRIVE_LAYOUT_INFORMATION_EX);

        hFile = CreateFile(fileName.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hFile == INVALID_HANDLE_VALUE) {
            logdrive->log(NORMAL, L"Invalid file handle error %d\n", GetLastError());
            throw (int) GetLastError();
        }
        // write header information
        res = WriteFile(hFile, &header, sizeof (header), &sizeWritten, NULL);
        if (res == 0) {
            logdrive->log(NORMAL, L"Writing header failed with error %d\n", GetLastError());
            throw (int) GetLastError();
        }
        // write boot loader block  
        res = WriteFile(hFile, bootloader, SIZE, &sizeWritten, NULL);
        if (res == 0) {
            logdrive->log(NORMAL, L"Writing bootloader failed with error %d\n", GetLastError());
            throw (int) GetLastError();
        }
        // write partition information  
        bufferSize = (partitioncount - 1) * sizeof (PARTITION_INFORMATION_EX) + sizeof (DRIVE_LAYOUT_INFORMATION_EX);
        if (Buffer) {
            res = WriteFile(hFile, Buffer, bufferSize, &sizeWritten, NULL);
            if (res == 0) {
                logdrive->log(NORMAL, L"Writing drive information failed with error %d\n", GetLastError());
                throw (int) GetLastError();
            }
        }
        res = CloseHandle(hFile);
        delete[] Buffer;
        return 0;
    } catch (int e) {
        return e;
    }
}

void GenerateFileNameForEntireDiskBackup(wstring &volumeFileName, wstring name, wstring partitionDeviceName) {

    size_t pos = partitionDeviceName.rfind(L"Partition");
    wstring ext = L".img";
    volumeFileName = name;
    volumeFileName += L"\\";
    volumeFileName += partitionDeviceName.substr(pos);
    volumeFileName += ext;
}

/*void GenerateFileNameForCompressDiskBackup(wstring &volumeFileName, wstring name, wstring partitionDeviceName) {

    size_t pos = partitionDeviceName.rfind(L"Partition");
    wstring ext = L".img";
    volumeFileName = name;
    volumeFileName += L"\\";
    volumeFileName += partitionDeviceName.substr(pos);
    volumeFileName += L"_compress";
    volumeFileName += ext;
}*/

void GenerateFileNameForMetadata(wstring &volumeFileName, wstring name, wstring partitionDeviceName) {

    size_t pos = partitionDeviceName.rfind(L"Partition");
    wstring ext = L".txt";
    volumeFileName = name;
    volumeFileName += L"\\";
    volumeFileName += partitionDeviceName.substr(pos);
    volumeFileName += L"_metadata";
    volumeFileName += ext;
}

int BackupandRestorePartitions(int index, wstring src, wstring dest, unsigned clustersize, wstring operation, wstring origName, int isEncrypted, wstring secretKey) {
    try {
        int val;
        wstring device = src;
        Info* driveInfo = driveList[index];
        LPCWSTR mountPoint = NULL;
        mountPoint = driveInfo->mountPoint.c_str();
        unsigned __int64 bitmapsize = 0, offsetpos, data;
        DWORD error = 0;

        if (operation == L"Backup") {
            const wchar_t* vssVolume;
            metaHandle = CreateFile(origName.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
            if (metaHandle == INVALID_HANDLE_VALUE) {
                logdrive->log(NORMAL, L"Invalid metafile handle %d\n", GetLastError());
                throw 1;
            }
            if (isEncrypted == 2) {//No encryption
                fileHandle = NULL;
            } else if (isEncrypted == 3) {//Encryption needed
                val = Opentargetfile(dest, L"write");
                if (val)
                    throw 1;
            }
            vssVolume = GetSnapshotDeviceName(vssindex);

            if (vssVolume != NULL && *vssVolume != L'\0') {// can be 0 if not mounted 
                device = vssVolume;
                device.erase(0, 14);
            } else {
                logdrive->log(NORMAL, L"vss volume name is not valid. Using Original Device Name %ws\n", device.c_str());
            }
            val = Opendisk(device, L"read");
            if (val) {
                throw 1;
            }
        } else if (operation == L"Restore") {
            metaHandle = CreateFile(origName.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
            if (metaHandle == INVALID_HANDLE_VALUE) {
                logdrive->log(NORMAL, L"Invalid metafile handle %d\n", GetLastError());
                throw 1;
            }
            if (isEncrypted == 0) {//No encryption
                fileHandle = NULL;
            } else if (isEncrypted == 1) {//Encrypted
                val = Opentargetfile(src, L"read");
                if (val)
                    throw 1;
            }
            val = Opendisk(dest, L"write");

            if (val == 3) {
                return val;
            } else if (val)
                throw 1;
        }
        initialReader = new Queuecode(2097152, 16);
        finalReader = new Queuecode(location);
        Queuecode *writerIn = finalReader;
        Queuecode *writerOut = initialReader;
        if (operation == L"Backup") {
            memset(&img, 0, sizeof (img));
            img.guid = magicGUID;
            img.versionMajor = 1;
            img.versionMinor = 0;
            WriteHeader();
            BOOL bSuccess;
            LARGE_INTEGER pos, newOffset;
            int check = 2; //To backup all data(Free+Used) in Read.cpp
            pos.QuadPart = 0;
            bSuccess = SetFilePointerEx(metaHandle, pos, &newOffset, FILE_END);
            offsetpos = newOffset.QuadPart;
            img.volumeBitmapOffset = offsetpos;
            if (bytesPerCluster != 0) {
                bitmapsize = GetVolumeBitmap(metaHandle, driveHandle, partitionsize, bytesPerCluster, location);
                if (bitmapsize > 0) {
                    check = 3; //To backup only used space data in Read.cpp
                }
            }
            read = new Read(initialReader, finalReader, driveHandle, metaHandle, partitionsize, position, clustersize, check, 0, location, dest);
            write = new Write(writerIn, writerOut, driveHandle, fileHandle, partitionsize, position, clustersize, isEncrypted, location, dest, secretKey);
            
            data = offsetpos + bitmapsize;
            img.volumeBitmapLength = bitmapsize;
            img.dataOffset = data;
            WriteHeader();

        } else if (operation == L"Restore") {
            memset(&img, 0, sizeof (img));
            ReadHeader();
            if (img.guid != magicGUID) {
                logdrive->log(NORMAL, L"GUID error\n");
                throw 1;
            }
            if (img.versionMajor != 1) {
                logdrive->log(NORMAL, L"Version error\n");
                throw 1;
            }
            bitmapsize = img.volumeBitmapLength;
            offsetpos = img.volumeBitmapOffset;
            data = img.volumeBitmapOffset;
            InitReader(offsetpos, (DWORD) bitmapsize, metaHandle);
            //delete read;
            //delete write;
            read = new Read(initialReader, finalReader, fileHandle, driveHandle, partitionsize, position, clustersize, isEncrypted, 0, location, src);
            write = new Write(writerIn, writerOut, metaHandle, driveHandle, partitionsize, position, clustersize, isEncrypted, location, src, secretKey);
        }
        if (read != NULL)
            read->Resume();
        if (write != NULL)
            write->Resume();
        WaitForSingleObject(read->GetHandle(), INFINITE);
        logdrive->log(NORMAL, L"Read thread completed\n");
        WaitForSingleObject(write->GetHandle(), INFINITE);
        logdrive->log(NORMAL, L"Write thread completed\n");
        readError = read->rError;
        error = write->wError;
        if (read->GetHandle())
            CloseHandle(read->GetHandle());
        if (write->GetHandle())
            CloseHandle(write->GetHandle());
        Terminate();
        if (driveHandle)
            CloseHandle(driveHandle);
        if (metaHandle)
            CloseHandle(metaHandle);
        if (fileHandle)
            CloseHandle(fileHandle);
        return error;
    } catch (int e) {
        return e;
    }
}

int Opentargetfile(wstring name, wstring mode) {
    DWORD access = GENERIC_READ | (mode == L"write" ? GENERIC_WRITE : 0);
    DWORD createMode = (mode == L"write" ? OPEN_ALWAYS : OPEN_EXISTING);
    // note: use OPEN_ALWAYS and not CREATE_ALWAYS because file header is written later in an existing file!
    fileMode = mode;
    if (name.c_str()) {
        fileHandle = CreateFile(name.c_str(), access, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, createMode, FILE_ATTRIBUTE_NORMAL, NULL);
        if (fileHandle == INVALID_HANDLE_VALUE) {
            logdrive->log(NORMAL, L"Invalid file handle %d\n", GetLastError());
            return 1;
        }

    }
    return 0;
}

int Opendisk(wstring name, wstring mode) {
    PARTITION_INFORMATION_EX partInfo;
    DISK_GEOMETRY diskGeometry;
    NTFS_VOLUME_DATA_BUFFER ntfsVolData;
    GET_LENGTH_INFORMATION lengthInfo;
    DWORD buf, res;
    long ntStatus;
    bool isRawDisk;
    DWORD shareMode;

    diskName = name;
    diskMode = mode;
    isRawDisk = diskName.find(L"Partition0") != std::string::npos;
    if (isRawDisk) {
        shareMode = FILE_SHARE_READ | FILE_SHARE_WRITE;
        DWORD access = (mode == L"write") ? (GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE) : GENERIC_READ | SYNCHRONIZE;
        ntStatus = OpenAPI(&driveHandle, diskName.c_str(), access, FILE_ATTRIBUTE_NORMAL, shareMode, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT | FILE_RANDOM_ACCESS | FILE_NON_DIRECTORY_FILE);
        if (ntStatus != 0) {
            logdrive->log(NORMAL, L"Opening raw disk failed with error %d\n", ntStatus);
            return 1;
        }
        if (volumecount > 0) {
            wstring rootName = diskName.substr(0, diskName.length() - 1);
            Lockvolumes(rootName, volumecount);
        }
    } else {
        shareMode = FILE_SHARE_DELETE | FILE_SHARE_WRITE | FILE_SHARE_READ;
        DWORD access = (mode == L"write") ? (GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE) : GENERIC_READ | SYNCHRONIZE;
        ntStatus = OpenAPI(&driveHandle, diskName.c_str(), access, FILE_ATTRIBUTE_NORMAL, shareMode, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT | FILE_RANDOM_ACCESS | FILE_NON_DIRECTORY_FILE);
        if (ntStatus != 0) {
            logdrive->log(NORMAL, L"Opening disk failed with error %d\n", ntStatus);
            return 1;
        }
    }
    if (diskMode == L"read") {
        bytesPerCluster = 0;
        memset(&partInfo, 0, sizeof (partInfo));
        memset(&diskGeometry, 0, sizeof (diskGeometry));
        memset(&lengthInfo, 0, sizeof (lengthInfo));
        memset(&ntfsVolData, 0, sizeof (ntfsVolData));
        res = DeviceIoControl(driveHandle, IOCTL_DISK_GET_PARTITION_INFO_EX, NULL, 0, &partInfo, sizeof (partInfo), &buf, NULL);
        // on some disks this might fail try PARTITION_INFORMATION then
        if (res == 0) {
            PARTITION_INFORMATION partInfo2;
            memset(&partInfo, 0, sizeof (partInfo));
            res = DeviceIoControl(driveHandle, IOCTL_DISK_GET_PARTITION_INFO, NULL, 0, &partInfo2, sizeof (partInfo2), &buf, NULL);
            Type = partInfo2.PartitionType;
        } else {
            Type = partInfo.Mbr.PartitionType;
        }
        mounted = DeviceIoControl(driveHandle, FSCTL_IS_VOLUME_MOUNTED, NULL, 0, NULL, 0, &buf, NULL);
        res = DeviceIoControl(driveHandle, IOCTL_DISK_GET_LENGTH_INFO, NULL, 0, &lengthInfo, sizeof (lengthInfo), &buf, NULL);
        if (res == FALSE)
            partitionsize = partInfo.PartitionLength.QuadPart; // IOCTL_DISK_GET_LENGTH_INFO not available on some older windows versions
        else
            partitionsize = lengthInfo.Length.QuadPart;


        res = DeviceIoControl(driveHandle, IOCTL_DISK_GET_DRIVE_GEOMETRY, NULL, 0, &diskGeometry, sizeof (diskGeometry), &buf, NULL);


        bytesPerSector = diskGeometry.BytesPerSector;
        res = DeviceIoControl(driveHandle, FSCTL_GET_NTFS_VOLUME_DATA, NULL, 0, &ntfsVolData, sizeof (ntfsVolData), &buf, NULL);
        if (res != 0) {
            // we have an NTFSVolume
            bytesPerCluster = ntfsVolData.BytesPerCluster;
        }

    } else if (diskMode == L"write") {
        res = DeviceIoControl(driveHandle, FSCTL_LOCK_VOLUME, NULL, 0, NULL, 0, &buf, NULL);
        if (res == 0) { // force a dismount
            int res1 = DeviceIoControl(driveHandle, FSCTL_DISMOUNT_VOLUME, NULL, 0, NULL, 0, &buf, NULL);
            res1 = CloseHandle(driveHandle);
            DWORD access = (mode == L"write") ? (GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE) : GENERIC_READ | SYNCHRONIZE;
            ntStatus = OpenAPI(&driveHandle, diskName.c_str(), access, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_DELETE | FILE_SHARE_WRITE | FILE_SHARE_READ, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT | FILE_RANDOM_ACCESS | FILE_NON_DIRECTORY_FILE);
            res1 = DeviceIoControl(driveHandle, FSCTL_LOCK_VOLUME, NULL, 0, NULL, 0, &buf, NULL);
        }
        locked = true;
        if (!isRawDisk) { // does not work for raw disks in Win XP, no problem in Vista
            res = DeviceIoControl(driveHandle, FSCTL_ALLOW_EXTENDED_DASD_IO, NULL, 0, NULL, 0, &buf, NULL);
            if (res == 0) {
                logdrive->log(NORMAL, L"Signalling file system driver failed with error %d\n", GetLastError());
                return 3;
            }
        }
    }
    return 0;
}

void Lockvolumes(wstring rootName, int containedVolumes) {
    Handles = new HANDLE[containedVolumes];
    const int bufferSize = 10;
    wchar_t buffer[bufferSize];
    for (int i = 0; i < containedVolumes; i++)
        Handles[i] = NULL;
    for (int i = 0; i < containedVolumes; i++) {
        wstring volName = rootName;
        _itow_s(i + 1, buffer, 10, bufferSize);
        volName += buffer;
        OpenAndLockVolume(volName, i);
    }
}

void OpenAndLockVolume(wstring volName, int index) {
    DWORD result, buf;
    long ntStatus;
    HANDLE h;
    ntStatus = OpenAPI(&h, volName.c_str(), GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_OPEN, FILE_SYNCHRONOUS_IO_NONALERT | FILE_RANDOM_ACCESS | FILE_NON_DIRECTORY_FILE);
    Handles[index] = h;
    result = DeviceIoControl(h, FSCTL_LOCK_VOLUME, NULL, 0, NULL, 0, &buf, NULL);
    if (result == 0)
        logdrive->log(NORMAL, L"Locking volume failed with error %d\n", GetLastError());
}

void CloseAndUnlockVolume(int index) {
    HANDLE h = Handles[index];
    if (h != NULL && h != INVALID_HANDLE_VALUE) {
        DWORD result, buf;
        result = DeviceIoControl(h, FSCTL_UNLOCK_VOLUME, NULL, 0, NULL, 0, &buf, NULL);
        result = CloseHandle(h);
        Handles[index] = NULL;
    }
}

void WriteHeader() {
    DWORD sizeWritten;
    LARGE_INTEGER pos, curPos;
    pos.QuadPart = 0LL;
    BOOL ok = SetFilePointerEx(metaHandle, pos, &curPos, FILE_CURRENT);
    ok = SetFilePointerEx(metaHandle, pos, NULL, FILE_BEGIN);
    ok = WriteFile(metaHandle, &img, sizeof (img), &sizeWritten, NULL);
    ok = SetFilePointerEx(metaHandle, curPos, NULL, FILE_BEGIN);
}

void ReadHeader() {
    DWORD sizeRead;
    LARGE_INTEGER pos, curPos;
    pos.QuadPart = 0LL;
    BOOL ok = SetFilePointerEx(metaHandle, pos, &curPos, FILE_BEGIN);
    ok = ReadFile(metaHandle, &img, sizeof (img), &sizeRead, NULL);
    ok = SetFilePointerEx(metaHandle, curPos, NULL, FILE_BEGIN);
}

void ReadFromFile(wstring fileName) {
    MBRFileHeader header;
    HANDLE hDisk;
    DWORD result;
    DWORD bytesRead;


    hDisk = CreateFile(fileName.c_str(), GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

    partitioncount = 0;
    disksize = 0;
    delete Buffer;
    Buffer = NULL;
    ZeroMemory(&bootloader, sizeof (bootloader));

    // Read file header
    result = ReadFile(hDisk, &header, sizeof (header), &bytesRead, NULL);
    if (header.guid != magicGUID) {
        CloseHandle(hDisk);
        logdrive->log(NORMAL, L"GUID error\n");
    }
    if (header.versionMajor != 1) {
        CloseHandle(hDisk);
        logdrive->log(NORMAL, L"Version error\n");
    }

    // read boot loader block
    result = SetFilePointer(hDisk, header.bootLoaderOffset, NULL, FILE_BEGIN);
    if (result == INVALID_SET_FILE_POINTER)
        logdrive->log(NORMAL, L"Invalid file pointer %d\n", GetLastError());
    result = ReadFile(hDisk, bootloader, header.bootLoaderLength, &bytesRead, NULL);

    // read partition information
    result = SetFilePointer(hDisk, header.partInfoOffset, NULL, FILE_BEGIN);
    if (result == INVALID_SET_FILE_POINTER)
        logdrive->log(NORMAL, L"Invalid file pointer %d\n", GetLastError());
    dl = (DRIVE_LAYOUT_INFORMATION_EX*) new BYTE[header.partInfoLength];
    Buffer = new BYTE[header.partInfoLength];
    result = ReadFile(hDisk, dl, header.partInfoLength, &bytesRead, NULL);
    if (bytesRead != header.partInfoLength) {
        CloseHandle(hDisk);
        logdrive->log(NORMAL, L"Reading header failed with error %d\n", GetLastError());
    }
    partitioncount = header.partitionCount;
    disksize = header.diskExtent;
    result = CloseHandle(hDisk);

    if (dl->PartitionStyle != PARTITION_STYLE_MBR) {
        logdrive->log(NORMAL, L"Partition layout other than MBR found\n");
    }
}

void WriteDriveInfo(wstring driveName) {
    wstring driveDeviceName(driveName);
    DWORD buf, result, bytesWritten, dummy;
    HANDLE hDisk;
    volumecount = 0;
    Opendisk(driveName, L"write");
    hDisk = driveHandle;
    // Set extended read mode for disks in Vista (fails on Win XP, no problem in Vista)
    result = DeviceIoControl(hDisk, FSCTL_ALLOW_EXTENDED_DASD_IO, NULL, 0, NULL, 0, &buf, NULL);
    if (result == 0) {
        logdrive->log(NORMAL, L"Signalling file system driver failed with error %d\n", GetLastError());
    }



    result = SetFilePointer(hDisk, 0, NULL, FILE_BEGIN);
    if (result == INVALID_SET_FILE_POINTER)
        logdrive->log(NORMAL, L"Invalid file pointer %d\n", GetLastError());

    result = WriteFile(hDisk, bootloader, sizeof (bootloader), (DWORD *) & bytesWritten, NULL);
    DWORD bufferSize = (partitioncount - 1) * sizeof (PARTITION_INFORMATION_EX) + sizeof (DRIVE_LAYOUT_INFORMATION_EX);
    result = DeviceIoControl(hDisk, IOCTL_DISK_SET_DRIVE_LAYOUT_EX, dl, bufferSize, NULL, 0, &buf, NULL);
    if (result == 0)
        logdrive->log(NORMAL, L"Setting drive layout failed with error %d\n", GetLastError());
    result = DeviceIoControl(driveHandle, IOCTL_DISK_UPDATE_PROPERTIES, NULL, 0, NULL, 0, &dummy, NULL);
    if (result == 0)
        logdrive->log(NORMAL, L"Updating drive properties failed with error %d\n", GetLastError());
    result = DeviceIoControl(driveHandle, FSCTL_UNLOCK_VOLUME, NULL, 0, NULL, 0, &dummy, NULL);
    if (result == 0)
        logdrive->log(NORMAL, L"Unlock volume failed with error %d\n", GetLastError());
    if (driveHandle != NULL) {
        DWORD res = CloseHandle(driveHandle);
        driveHandle = NULL;
    }
}

bool TestIsMBR(wstring & fileName) {
    bool ismbr;
    wstring mbrName = fileName;

    Creatembrfilename(mbrName);
    HANDLE h = CreateFile(mbrName.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h != INVALID_HANDLE_VALUE) {
        CloseHandle(h);
    }
    ismbr = h != INVALID_HANDLE_VALUE;
    fileName = mbrName;
    return ismbr;
}

void Terminate() {
    if (NULL != read)
        read->Terminate();

    if (NULL != write)
        write->Terminate();
    delete read;
    read = NULL;
    delete write;
    write = NULL;
    delete initialReader;
    initialReader = NULL;
    delete finalReader;
    finalReader = NULL;
}

int MakeSnapshot(int driveIndex) {
    try {
        int val;
        Info* mdriveInfo = driveList[driveIndex];
        int subPartitions = mdriveInfo->containedVolumes;
        LPCWSTR *mountPoints;
        Info **pContainedVolumes = new Info* [subPartitions];
        mountPoints = new LPCWSTR [subPartitions];
        int res = GetVolumes(mdriveInfo, pContainedVolumes, subPartitions);
        for (int i = 0, j = 0; i < res; i++) {
            if ((pContainedVolumes[i]->guid.length() > 0)&&(validPartitions[i] == 0))
                mountPoints[j++] = pContainedVolumes[i]->guid.c_str();
            else
                mountPoints[j++] = NULL; // unmounted volume
        }
        delete[] pContainedVolumes;
        /* else {
        subPartitions = 1;
        mountPoints = new LPCWSTR [1];
        }*/
        bool testvss = VssSupport(location);
        val = InitVss();
        if (val) {
            throw 1;
        }
        val = PrepareSnapshot(mountPoints, subPartitions);
        if (val) {
            throw 1;
        }
        delete[] mountPoints;
        return 0;
    } catch (int e) {
        return e;
    }
}

Info::Info(wstring& dpName, wstring& dvName, wstring& mPoint, bool isDisk) {
    displayName = dpName;
    deviceName = dvName;
    mountPoint = mPoint;
    bytes = sectors = bytesPerSector = sectorsPerTrack = clusterSize = 0;
    containedVolumes = 0;
    parent = NULL;
    isMounted = false;
}

int writePasswordHash(wstring destination, wstring secretKeyW) {
    logdrive->log(NORMAL, L"Creating password hash...\n");
    HCRYPTPROV hProv = 0;
    HCRYPTHASH hHash = 0;
    BYTE *pbHash = NULL;
    DWORD dwHashLen;

    BYTE * pbBuffer = NULL;
    DWORD dwCount;
    unsigned long bufLen = 0;
    string secretKeyS(secretKeyW.begin(), secretKeyW.end());
    LPSTR secretKey = &secretKeyS[0];
    
    if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_AES, 0)) {
        logdrive->log(NORMAL, L"CryptAcquireContext success\n");
    } else {
        if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_AES, CRYPT_NEWKEYSET)) {
            logdrive->log(NORMAL, L"CryptAcquireContext success in next attempt\n");
        } else {
            logdrive->log(NORMAL, L"CryptAcquireContext failed %d\n", (int) GetLastError());
            return 1;
        }
    }
    if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
        logdrive->log(NORMAL, L"CryptCreateHash failed %d\n", (int) GetLastError());
        return 1;
    }

    bufLen = strlen(secretKey);

    pbBuffer = (BYTE*) malloc(bufLen + 1);
    memset(pbBuffer, 0, bufLen + 1);
    memcpy(pbBuffer, (BYTE *) (secretKey), bufLen);

    if (!CryptHashData(hHash, pbBuffer, bufLen, 0)) {
        logdrive->log(NORMAL, L"CryptHashData failed %d\n", (int) GetLastError());
        return 1;
    }

    dwCount = sizeof (DWORD);
    if (!CryptGetHashParam(hHash, HP_HASHSIZE, (BYTE *) & dwHashLen, &dwCount, 0)) {
        logdrive->log(NORMAL, L"CryptGetHashParam failed getting hash size %d\n", (int) GetLastError());
        return 1;
    }
    if ((pbHash = (unsigned char*) malloc(dwHashLen)) == NULL) {
        logdrive->log(NORMAL, L"Allocating memory for new hash failed\n");
        return 1;
    }
    memset(pbHash, 0, dwHashLen);

    if (!CryptGetHashParam(hHash, HP_HASHVAL, pbHash, &dwHashLen, 0)) {
        logdrive->log(NORMAL, L"CryptGetHashParam failed getting hash value %d\n", (int) GetLastError());
        return 1;
    }
    HANDLE hDestinationFile = CreateFile(destination.c_str(), FILE_WRITE_DATA, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

    if (hDestinationFile == INVALID_HANDLE_VALUE) {
        logdrive->log(NORMAL, L"Encryptfile handle invalid %d\n", (int) GetLastError());
    }
    if (WriteFile(hDestinationFile, pbHash, dwHashLen, &dwCount, NULL)) {
    } else {
        logdrive->log(NORMAL, L"Encrypt Writefile failed %d\n", (int) GetLastError());
    }

    if (hHash)
        CryptDestroyHash(hHash);
    if (hProv)
        CryptReleaseContext(hProv, 0);
    if (hDestinationFile)
        CloseHandle(hDestinationFile);
    if (pbBuffer)
        free(pbBuffer);
    if (pbHash)
        free(pbHash);

    return 0;
}

int Add(wchar_t *storageLoc, wchar_t *logLoc, wchar_t *code, wchar_t *files, int isEncrypted, wchar_t *secretKey) {
    int val;
    bool encryption;
    wstring opval;
    opval = code;
    usnLocation = logLoc;
    maindest = storageLoc;
    location = usnLocation;
    location += L"\\LogFile.txt";
    LPWSTR logloc = (LPWSTR) location.c_str();
    logdrive = new Logger(logloc, (LPWSTR) level);
    buDetails = maindest;
    buDetails += L"\\BackupDetails.txt";
    mapDetails = maindest;
    mapDetails += L"\\DriveMapping.txt";
    logdrive->log(NORMAL, L"Agent version 1.2.1\n");
    encryption = (isEncrypted == 1) ? true : false;
    if (encryption) {
        logdrive->log(NORMAL, L"Creating encrypted backup...\n");
    }
    val = operation(opval, files, encryption, secretKey);
    if (val == 0)
        logdrive->log(NORMAL, L"Backup completed\n");
    else
        logdrive->log(NORMAL, L"Backup failed\n");
    return val;
}

int volumeLevelRestore(wchar_t *storageLoc, wchar_t *logLoc, wchar_t *files, int type, wchar_t *mergePath, wchar_t *user, wchar_t *pwd, wchar_t *restoreLogFile, int isEncrypted, wchar_t *secretKey) {
    int val;
    bool encryption;
    wstring restoreFilePath = restoreLogFile;
    maindest = storageLoc;
    location = logLoc;
    location += L"\\LogFile.txt";
    LPWSTR logloc = (LPWSTR) location.c_str();
    logdrive = new Logger(logloc, (LPWSTR) level);
    buDetails = restoreFilePath;

    logdrive->log(NORMAL, L"Agent version 1.2.1\n");
    encryption = (isEncrypted == 1) ? true : false;
    if (encryption) {
        logdrive->log(NORMAL, L"Restoring encrypted backup...\n");
    }
    val = performRestore(type, files, mergePath, user, pwd, encryption, secretKey);
    if (val == 0)
        logdrive->log(NORMAL, L"Restore completed\n");
    else
        logdrive->log(NORMAL, L"Restore failed\n");

    return val;
}

int getDiskCount() {
    int harddiskcnt = -1;

    harddiskcnt = ListDrives();

    return harddiskcnt;
}

