
#include "ImageBackup/Queue.h"
#include "ImageBackup/Logger.h"
LPWSTR levelqueue=NORMAL;
LPWSTR queueloc;
Logger *logqueue;
BufferChunk::BufferChunk(int size)
{
	Data=new BYTE[size];
	fileEnd=false;
	UsedSize = size;
}

BufferChunk::~BufferChunk() {
  delete[] Data;
}

Queuecode::Queuecode(wstring name) 
{
	queueloc=(LPWSTR)name.c_str();
	logqueue= new Logger(queueloc,(LPWSTR)levelqueue);
	InitializeCriticalSection(&CriticalSec);
	ChunkCount = 0;
	han=CreateSemaphore(NULL, 0, 9999, NULL);
}

Queuecode::Queuecode(int size, int count)
{	
	InitializeCriticalSection(&CriticalSec);
	ChunkCount = count;
	// Create all the buffer chunks
	for (unsigned n = 0; n < ChunkCount; n++)
	{	  
		Chunks.push_back(new BufferChunk(size));
	}
	han=CreateSemaphore(NULL, count, count, NULL);
}

Queuecode::~Queuecode()
{
  EnterCriticalSection(&CriticalSec);
  list <BufferChunk*>::iterator it = Chunks.begin();

  while(it != Chunks.end())
	{
		delete *it;
		it++;
	}
  Chunks.clear();
  LeaveCriticalSection(&CriticalSec);
}

BufferChunk*  Queuecode::GetChunk() 
{
	BufferChunk *chunk = NULL;
	DWORD res = WaitForSingleObject(han, 1000000);
	if ( res == WAIT_TIMEOUT){
		logqueue->log(NORMAL,L"Time out error\n");
                return NULL;
        }
	EnterCriticalSection(&CriticalSec);
	chunk = Chunks.front();
	Chunks.pop_front();
	LeaveCriticalSection(&CriticalSec);
	return chunk;
} 

void  Queuecode::ReleaseChunk(BufferChunk *chunk) 
{
	EnterCriticalSection(&CriticalSec);
	Chunks.push_back(chunk);
	LeaveCriticalSection(&CriticalSec);
	ReleaseSemaphore(han,1,NULL); 
}

