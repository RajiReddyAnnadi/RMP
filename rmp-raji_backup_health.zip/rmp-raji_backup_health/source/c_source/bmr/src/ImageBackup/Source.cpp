
#include "ImageBackup/Source.h" 
#include <Shlwapi.h>
#include <shlobj.h>
#include <psapi.h>
#include <atlstr.h>
#include <io.h>
#include <fcntl.h>
#include "ImageBackup/Util.h"
#include "ImageBackup/Logger.h"

#define BUFSIZE MAX_PATH
#define BUF_LEN 4096

#define ENCRYPT_BLOCK_SIZE 16
#define KEYLENGTH  0x00800000
#define ENCRYPT_ALGORITHM CALG_AES_128

USN maxusn;
HANDLE hVol, hVol1;
wstring name1;
LPWSTR levelsrc = NORMAL;
LPWSTR srcloc;
Logger *logger;

CREATE_USN_JOURNAL_DATA CreateData = {1000, 100};
USN_JOURNAL_DATA JournalData;
READ_USN_JOURNAL_DATA ReadData;
PUSN_RECORD UsnRecord;
DWORD dwBytes;
DWORD dwRetBytes;
CHAR Buffer[BUF_LEN];

void show_record(USN_RECORD * record) {
    BYTE buffer[BUF_LEN];
    //void * buffer;
    MFT_ENUM_DATA_V0 mft_enum_data;
    DWORD bytecount = 1;
    USN_RECORD * parent_record;
    WCHAR * filename;
    WCHAR * filenameend;
    DWORDLONG num = record->FileReferenceNumber;
    filename = (WCHAR *) (((BYTE *) record) + record->FileNameOffset);
    filenameend = (WCHAR *) (((BYTE *) record) + record->FileNameOffset + record->FileNameLength);

    name1.insert(0, filename, 0, filenameend - filename);
    /*buffer = VirtualAlloc(NULL, BUF_LEN, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);

    if (buffer == NULL) {
        logger->log(NORMAL, L"VirtualAlloc failed with error %d\n", GetLastError());
        return;
    }*/

    mft_enum_data.StartFileReferenceNumber = record->ParentFileReferenceNumber;
    mft_enum_data.LowUsn = 0;
    mft_enum_data.HighUsn = maxusn;

    if (!DeviceIoControl(hVol1, FSCTL_ENUM_USN_DATA, &mft_enum_data, sizeof (mft_enum_data), buffer, BUF_LEN, &bytecount, NULL)) {
        return;
    }

    parent_record = (USN_RECORD *) ((USN *) buffer + 1);
    if (parent_record->FileReferenceNumber != record->ParentFileReferenceNumber) {
        return;
    }
    name1.insert(0, L"\\");
    show_record(parent_record);
}

wstring findfilename(HANDLE hvol, DWORDLONG num) {

    HRESULT hResult;
    FILE_ID_DESCRIPTOR FileID;
    FileID.FileId.QuadPart = num;
    FileID.Type = FileIdType;
    FileID.dwSize = sizeof (FileID);
    HANDLE hFile = OpenFileById(hvol,
            &FileID,
            GENERIC_READ,
            FILE_SHARE_READ,
            NULL,
            0);
    if (hFile == INVALID_HANDLE_VALUE) {
        hResult = HRESULT_FROM_WIN32(GetLastError());
        return L"";
    }
    wstring Path;
    QueryInfoFile(hFile, Path);
    CloseHandle(hFile);
    return Path;


}

int BackupFile(_In_ wstring& source, _In_ wstring& destination) {
    HRESULT hr = S_OK;
    gzFile hDestinationFile;
    HANDLE hSourceFile = ::CreateFile(
            source.c_str(),
            GENERIC_READ,
            FILE_SHARE_READ,
            NULL,
            OPEN_EXISTING,
            FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_BACKUP_SEMANTICS,
            NULL);

    if (hSourceFile == INVALID_HANDLE_VALUE) {
        int error = (int) GetLastError();
        logger->log(NORMAL, L"CreateFile failed with error %d when opening source file %ws\n", error, source.c_str());
        return error;
    }
    const DWORD DEFAULT_BUFFER_SIZE = 4086;
    DWORD bytesRead = 0, bytesWritten = 0;
    BYTE buffer[DEFAULT_BUFFER_SIZE];
    LPVOID context = NULL;
    int compHandle = _wopen(destination.c_str(), _O_CREAT | _O_TRUNC | _O_WRONLY | _O_BINARY);
    if (compHandle == -1) {
        logger->log(NORMAL, L"wopen error %d %ws\n", errno, destination.c_str());
        if (hSourceFile)
            CloseHandle(hSourceFile);
        return errno;
    }
    hDestinationFile = gzdopen(compHandle, "wb");
    if (!hDestinationFile) {
        logger->log(NORMAL, L"Compressed open error %ws\n", destination.c_str());
        if (hSourceFile)
            CloseHandle(hSourceFile);
        return 1;
    }
    while (BackupRead(hSourceFile, buffer, DEFAULT_BUFFER_SIZE, &bytesRead, FALSE, TRUE, &context) && bytesRead > 0) {
        if (!gzwrite(hDestinationFile, buffer, bytesRead)) {
            int error = (int) GetLastError();
            logger->log(NORMAL, L"Compressed write failed with error %d\n", error);
            if (hSourceFile)
                CloseHandle(hSourceFile);
            if (hDestinationFile)
                gzclose(hDestinationFile);
            return error;
        }
    }
    BackupRead(hSourceFile, NULL, 0, NULL, TRUE, TRUE, &context);
    if (hSourceFile)
        CloseHandle(hSourceFile);
    if (hDestinationFile)
        gzclose(hDestinationFile);
    return 0;
}

int EncryptBackupFile(_In_ wstring& source, _In_ wstring& destination, wstring secretKey) {
    return compressEncrypt(source, destination, secretKey);
}

int compressEncrypt(wstring source, wstring destination, wstring secretKey) {
    const DWORD DEFAULT_BUFFER_SIZE = 4096;
    FILE *in;
    int ret;
    int flush = Z_NO_FLUSH;
    int read;
    z_stream strm;
    BYTE *input = new BYTE[DEFAULT_BUFFER_SIZE];
    BYTE *output = new BYTE[DEFAULT_BUFFER_SIZE];
    PBYTE encrypt = NULL;
    DWORD dwBlockLen;
    DWORD dwBufferLen, dwCount;
    int fd = _wopen(source.c_str(), _O_RDONLY | _O_BINARY);
    if (fd == -1) {
        int errsv = errno;
        logger->log(NORMAL, L"_wopen: could not open for reading %d\n", errsv);
        return 1;
    }
    in = _fdopen(fd, "rb");
    if (in == NULL) {
        logger->log(NORMAL, L"_fdopen: could not open %ws\n", source.c_str());
        return 1;
    }

    HCRYPTKEY hKey = generateHashKey(&secretKey[0]);
    if (hKey == -1) {
        logger->log(NORMAL, L"hkey is -1\n");
        if (input)
            delete[] input;
        if (output)
            delete[] output;
        return 1;
    }
    HANDLE hDestinationFile = CreateFile(destination.c_str(), FILE_WRITE_DATA, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hDestinationFile == INVALID_HANDLE_VALUE) {
        int val = (int) GetLastError();
        logger->log(NORMAL, L"compressEncrypt invalid handle error %d for %ws\n", val, destination.c_str());
        if (input)
            delete[] input;
        if (output)
            delete[] output;
        if (in)
            fclose(in);
        return val;
    }
    /* initialize file and deflate state to start there */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = deflateInit(&strm, Z_DEFAULT_COMPRESSION);
    if (ret != Z_OK) {
        logger->log(NORMAL, L"deflateInit failed %d\n", ret);
        if (input)
            delete[] input;
        if (output)
            delete[] output;
        return 1;
    }

    bool fEOF = FALSE, cryptEOF = FALSE;
    do {
        strm.avail_out = DEFAULT_BUFFER_SIZE;
        strm.next_out = output;

        do {
            if ((!fEOF) && (strm.avail_in == 0)) {
                strm.avail_in = fread(input, 1, DEFAULT_BUFFER_SIZE, in);
                read = strm.avail_in;
                if (read < DEFAULT_BUFFER_SIZE || feof(in)) {
                    fEOF = TRUE;
                }
                flush = (fEOF) ? Z_FINISH : Z_NO_FLUSH;
                if (ferror(in)) {
                    ret = Z_ERRNO;
                    logger->log(NORMAL, L"Z_ERRNO failed\n");
                    if (input)
                        delete[] input;
                    if (output)
                        delete[] output;
                    return 1;
                }
                strm.next_in = input;
            }
            ret = deflate(&strm, flush); /* normal deflate */
            if (ret == Z_NEED_DICT) {
                logger->log(NORMAL, L"Z_NEED_DICT\n");
                ret = Z_DATA_ERROR;
            }
            if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR) {
                logger->log(NORMAL, L"Z_MEM_ERROR or Z_DATA_ERROR %d %s\n", ret, strm.msg);
                if (input)
                    delete[] input;
                if (output)
                    delete[] output;
                return 1;
            }
            if (ret == Z_STREAM_END) {
                cryptEOF = TRUE;
            }
        } while ((!fEOF)&&(strm.avail_out != 0));

        dwBlockLen = DEFAULT_BUFFER_SIZE - strm.avail_out;
        if (dwBlockLen > 0) {
            dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
            if (encrypt = (BYTE *) malloc(dwBufferLen)) {
                memcpy((encrypt), output, (dwBlockLen));

                if (CryptEncrypt(hKey, NULL, cryptEOF, 0, encrypt, &dwBlockLen, dwBufferLen)) {
                    if (WriteFile(hDestinationFile, encrypt, dwBlockLen, &dwCount, NULL)) {
                    } else {
                        int val = (int) GetLastError();
                        logger->log(NORMAL, L"WriteFile failed %d\n", val);
                        if (encrypt)
                            free(encrypt);
                        if (input)
                            delete[] input;
                        if (output)
                            delete[] output;
                        return val;
                    }
                } else {
                    DWORD dw = GetLastError();
                    logger->log(NORMAL, L"cryptencrypt failed %d\n", (int) dw);
                    if (encrypt)
                        free(encrypt);
                    if (input)
                        delete[] input;
                    if (output)
                        delete[] output;
                    return (int) dw;
                }

                memset(output, 0, DEFAULT_BUFFER_SIZE);
                if (encrypt)
                    free(encrypt);
            } else {
                logger->log(NORMAL, L"malloc failed\n");
                if (input)
                    delete[] input;
                if (output)
                    delete[] output;
                return 1;
            }
        }
    } while (ret != Z_STREAM_END);
    if (in)
        fclose(in);
    if (hDestinationFile)
        CloseHandle(hDestinationFile);
    (void) deflateEnd(&strm);
    if (input)
        delete[] input;
    if (output)
        delete[] output;
    return 0;
}

int BackupFolder(_In_ const wstring& source, _In_ const wstring& destination, bool isEncrypted, wstring secretKey) {
    int buVal = 0, retVal = 0;

    if (!::CreateDirectory(destination.c_str(), NULL)) {
        DWORD error = GetLastError();
        if (error != ERROR_ALREADY_EXISTS) {
            logger->log(NORMAL, L"CreateDirectory %ws failed with error %d\n", destination.c_str(), (int) error);
            return (int) error;
        }
    }
    // Backup the directory 
    // Walk through all the files and subdirectories 
    WIN32_FIND_DATA findData;
    wstring pattern = source;
    pattern += L"\\*";
    HANDLE hFind = FindFirstFile(pattern.c_str(), &findData);
    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            // If not . or .. 
            wstring name = findData.cFileName;
            if ((name != L".") && (name != L"..")) {
                wstring newSource = source;
                newSource += '\\';
                newSource += findData.cFileName;
                wstring newDestination = destination;
                newDestination += '\\';
                newDestination += findData.cFileName;
                // Backup the source file or directory 
                if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                    if (!::CreateDirectory(newDestination.c_str(), NULL)) {
                        DWORD error = GetLastError();
                        if (error != ERROR_ALREADY_EXISTS) {
                            logger->log(NORMAL, L"CreateDirectory %ws failed with error %d\n", newDestination.c_str(), (int) error);
                            retVal = (int) error;
                        } else {
                            BackupFolder(newSource, newDestination, isEncrypted, secretKey);
                        }
                    } else {
                        BackupFolder(newSource, newDestination, isEncrypted, secretKey);
                    }
                } else {
                    // Do BackupRead and backup the file 
                    if (isEncrypted) {
                        buVal = EncryptBackupFile(newSource, newDestination, secretKey);
                    } else {
                        buVal = BackupFile(newSource, newDestination);
                    }
                    if (buVal == 0) {
                        //logger->log(NORMAL, L"Backupfile %ws successful\n", newDestination.c_str());
                    } else if (buVal == 112 || buVal == 28) {//Insufficient space error codes
                        return buVal;
                    } else {
                        retVal = buVal;
                    }
                }
            }
        } while (FindNextFile(hFind, &findData));
        if (hFind)
            FindClose(hFind);
    } else {
        int errorCode = (int) GetLastError();
        logger->log(NORMAL, L"BackupFolder FindFirstFile failed with error: %d", errorCode);
        retVal = errorCode;
    }
    return retVal;
}

int FileLevelBackup(wstring src, wstring dest, string driveLetter, wstring locname, map <string, vector<string> > &fileList, ofstream& buDetailsFile, bool isEncrypted, wstring secretKey) {
    logger->log(NORMAL, L"In FileLevelBackup");
    int buVal;
    srcloc = (LPWSTR) locname.c_str();
    logger = new Logger(srcloc, (LPWSTR) levelsrc);

    auto it = fileList.find(driveLetter);

    if (it != fileList.end()) {
        auto& vIt = it->second;

        for (string elem : vIt) {
            string cropVolumeList = elem.substr(2);
            wstring filePath(cropVolumeList.begin(), cropVolumeList.end());
            wstring fullDest = dest + filePath;
            wstring fullSrc = src + filePath;
            if (PathFileExists(fullSrc.c_str())) {
                wstring destFol;
                const size_t pos = fullDest.rfind('\\');
                if (std::string::npos != pos)
                    destFol = fullDest.substr(0, pos);
                SHCreateDirectoryEx(NULL, destFol.c_str(), NULL);

                DWORD attr = GetFileAttributes(fullSrc.c_str());
                if (attr & FILE_ATTRIBUTE_DIRECTORY) {
                    buVal = BackupFolder(fullSrc, fullDest, isEncrypted, secretKey);
                    buDetailsFile << elem;
                    buDetailsFile << endl;
                    if (buVal == 0) {
                        buDetailsFile << "Success";
                        buDetailsFile << endl;
                    } else if (buVal == 112 || buVal == 28) {//Insufficient space error codes
                        return buVal;
                    } else {
                        buDetailsFile << "Failed";
                        buDetailsFile << endl;
                    }
                } else {
                    if (isEncrypted) {
                        buVal = EncryptBackupFile(fullSrc, fullDest, secretKey);
                    } else {
                        buVal = BackupFile(fullSrc, fullDest);
                    }
                    buDetailsFile << elem;
                    buDetailsFile << endl;
                    if (buVal == 0) {
                        buDetailsFile << "Success";
                        buDetailsFile << endl;
                    } else if (buVal == 112 || buVal == 28) {//Insufficient space error codes
                        return buVal;
                    } else {
                        buDetailsFile << "Failed";
                        buDetailsFile << endl;
                    }
                }
            } else {
                buDetailsFile << elem;
                buDetailsFile << endl;
                buDetailsFile << "Not found";
                buDetailsFile << endl;
            }
        }
    }
    return 0;
}

void findnextrecord() {
    // Update starting USN for next call
    ReadData.StartUsn = *(USN *) & Buffer;
    memset(Buffer, 0, BUF_LEN);
    if (!DeviceIoControl(hVol1,
            FSCTL_READ_USN_JOURNAL,
            &ReadData,
            sizeof (ReadData),
            &Buffer,
            BUF_LEN,
            &dwBytes,
            NULL)) {
        logger->log(NORMAL, L"Read journal failed with error %d\n", GetLastError());
        return;
    }
    dwRetBytes = dwBytes - sizeof (USN);
    // Find the first record
    UsnRecord = (PUSN_RECORD) (((PUCHAR) Buffer) + sizeof (USN));
    if (UsnRecord->Usn >= JournalData.NextUsn) {
        return;
    }
}

void setLogger(wstring locname) {
    srcloc = (LPWSTR) locname.c_str();
    logger = new Logger(srcloc, (LPWSTR) levelsrc);
}

LONGLONG QueryJournal(wstring letter, wstring locname) {
    srcloc = (LPWSTR) locname.c_str();
    logger = new Logger(srcloc, (LPWSTR) levelsrc);
    wstring name = L"\\\\.\\";
    name += letter;
    hVol1 = CreateFile(name.c_str(),
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            NULL,
            OPEN_EXISTING,
            0,
            NULL);

    if (hVol1 == INVALID_HANDLE_VALUE) {
        logger->log(NORMAL, L"CreateFile failed with error %d when querying journal\n", GetLastError());
        return 1;
    }
    if (!DeviceIoControl(hVol1,
            FSCTL_QUERY_USN_JOURNAL,
            NULL,
            0,
            &JournalData,
            sizeof (JournalData),
            &dwBytes,
            NULL)) {
        logger->log(NORMAL, L"Query journal failed with error %d ,so we create new journal\n", GetLastError());
        if (DeviceIoControl(hVol1,
                FSCTL_CREATE_USN_JOURNAL,
                &CreateData,
                sizeof (CreateData),
                NULL,
                0,
                &dwBytes,
                NULL))
            logger->log(NORMAL, L"Journal creation successful\n");

        if (!DeviceIoControl(hVol1,
                FSCTL_QUERY_USN_JOURNAL,
                NULL,
                0,
                &JournalData,
                sizeof (JournalData),
                &dwBytes,
                NULL)) {
            logger->log(NORMAL, L"Error while querying journal\n");
            return -1;
        }
    }
    return JournalData.NextUsn;
}

int BackupDirectoryTree(string source, wstring destination, wstring device, string val, std::vector<string> &volumeList, bool isFLR, ofstream& buDetailsFile, bool isEncrypted, wstring secretKey) {
    string delimiter = "--";
    std::vector<string> overwriteFailedList;
    int flag = 0;
    int buVal = 0;
    if (!::CreateDirectory(destination.c_str(), NULL)) {
        DWORD error = GetLastError();
        if (error != ERROR_ALREADY_EXISTS) {
            logger->log(NORMAL, L"CreateDirectory failed with error %d for %ws\n", (int) error, destination.c_str());
        }
    }

    HANDLE h;
    wstring fn = destination;
    fn += '\\';
    fn += L"rename_file.txt";
    h = CreateFile(fn.c_str(),
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            NULL,
            CREATE_ALWAYS,
            FILE_ATTRIBUTE_HIDDEN,
            NULL);
    if (h)
        CloseHandle(h);
    HANDLE h1;
    wstring fn1 = destination;
    fn1 += '\\';
    fn1 += L"delete_file.txt";
    h1 = CreateFile(fn1.c_str(),
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            NULL,
            CREATE_ALWAYS,
            FILE_ATTRIBUTE_HIDDEN,
            NULL);
    if (h1)
        CloseHandle(h1);

    ofstream delete_file(fn1, ios::out | ios::app);
    ofstream rename_file(fn, ios::out | ios::app);


    hVol = CreateFile(device.c_str(),
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            NULL,
            OPEN_EXISTING,
            0,
            NULL);

    if (hVol == INVALID_HANDLE_VALUE) {
        logger->log(NORMAL, L"Opening snapshot failed with error %d\n", GetLastError());
        return 1;
    }
    LONGLONG startval = stoll(val, nullptr, 10);
    ReadData.UsnJournalID = JournalData.UsnJournalID;
    ReadData.BytesToWaitFor = 0;
    ReadData.MaxMajorVersion = 2;
    ReadData.MinMajorVersion = 2;
    ReadData.ReasonMask = USN_REASON_FILE_CREATE | USN_REASON_RENAME_NEW_NAME | USN_REASON_RENAME_OLD_NAME | USN_REASON_DATA_EXTEND | USN_REASON_DATA_OVERWRITE | USN_REASON_DATA_TRUNCATION | USN_REASON_FILE_DELETE | USN_REASON_CLOSE;
    ReadData.ReturnOnlyOnClose = FALSE;
    ReadData.StartUsn = startval;
    ReadData.Timeout = 0;
    maxusn = JournalData.NextUsn;
    memset(Buffer, 0, BUF_LEN);
    if (!DeviceIoControl(hVol1,
            FSCTL_READ_USN_JOURNAL,
            &ReadData,
            sizeof (ReadData),
            &Buffer,
            BUF_LEN,
            &dwBytes,
            NULL)) {
        logger->log(NORMAL, L"Read journal failed with error %d\n", GetLastError());
        return 3;
    }
    dwRetBytes = dwBytes - sizeof (USN);
    // Find the first record
    UsnRecord = (PUSN_RECORD) (((PUCHAR) Buffer) + sizeof (USN));
    // This loop could go on for a long time, given the current buffer size.
    while ((dwRetBytes > 0)&&(UsnRecord->Usn < JournalData.NextUsn)) {
        if ((UsnRecord->Reason == USN_REASON_FILE_CREATE)&&(UsnRecord->Usn < JournalData.NextUsn)) {
            wstring w(UsnRecord->FileName);
            string recycle(w.begin(), w.end());

            if (recycle.compare(0, 2, "$I") == 0) {
                show_record(UsnRecord);
                string name;
                string tmp;
                name.assign(name1.begin(), name1.end());
                const size_t pos = name.find('\\');
                if (std::string::npos != pos)
                    tmp = name.substr(0, pos);
                if (_stricmp(tmp.c_str(), "$recycle.bin") == 0) {
                    bool backupFlag = true;
                    while ((UsnRecord->Reason) != USN_REASON_RENAME_OLD_NAME) {
                        dwRetBytes -= UsnRecord->RecordLength;
                        // Find the next record
                        if (dwRetBytes <= 0)
                            findnextrecord();
                        else
                            UsnRecord = (PUSN_RECORD) (((PCHAR) UsnRecord) + UsnRecord->RecordLength);
                        if ((UsnRecord->Reason == USN_REASON_RENAME_OLD_NAME)&&(UsnRecord->Usn < JournalData.NextUsn)) {
                            name1.clear();
                            show_record(UsnRecord);
                            wstring delS;
                            delS = device;
                            delS += '\\';
                            delS += name1;
                            string checkPath;
                            checkPath.assign(name1.begin(), name1.end());
                            if (isFLR) {
                                if (!(isSelectedFile(checkPath, source, volumeList)))
                                    backupFlag = false;
                            }
                            if (backupFlag) {
                                if (!PathFileExists(delS.c_str())) {
                                    delete_file.write(checkPath.c_str(), strlen(checkPath.c_str()));
                                    delete_file << endl;
                                    if (isFLR) {
                                        checkPath.insert(0, source);
                                        checkPath.insert(2, "\\");
                                        buDetailsFile << checkPath;
                                        buDetailsFile << endl;
                                        buDetailsFile << "Deleted";
                                        buDetailsFile << endl;
                                    }
                                }
                            }
                            name1.clear();
                        }
                    }
                    dwRetBytes -= UsnRecord->RecordLength;
                    // Find the next record
                    if (dwRetBytes <= 0)
                        findnextrecord();
                    else
                        UsnRecord = (PUSN_RECORD) (((PCHAR) UsnRecord) + UsnRecord->RecordLength);
                }
            } else {
                bool backupFlag = true;
                show_record(UsnRecord);
                DWORDLONG num = UsnRecord->FileReferenceNumber;
                wstring Path;
                string checkPath;
                Path = findfilename(hVol, num);
                if (!Path.empty()) {
                    wstring nsrc;
                    nsrc = device;
                    nsrc += Path;
                    wstring ndst;
                    ndst = destination;
                    ndst += Path;
                    name1.clear();
                    wstring ndst1;
                    const size_t pos = ndst.rfind('\\');
                    if (std::string::npos != pos) {
                        ndst1 = ndst.substr(0, pos);
                    }
                    if (isFLR) {
                        wstring croppedPath = Path.substr(1);
                        checkPath.assign(croppedPath.begin(), croppedPath.end());
                        if (!(isSelectedFile(checkPath, source, volumeList)))
                            backupFlag = false;
                    }
                    if (backupFlag) {
                        if ((nsrc.find(L"pagefile.sys") == std::string::npos) && (PathFileExists(nsrc.c_str()))&&(!PathFileExists(ndst.c_str()))) {
                            if (UsnRecord->FileAttributes == 0x10) {
                                SHCreateDirectoryEx(NULL, ndst.c_str(), NULL);
                            } else {
                                SHCreateDirectoryEx(NULL, ndst1.c_str(), NULL);
                                if (isEncrypted) {
                                    buVal = EncryptBackupFile(nsrc, ndst, secretKey);
                                } else {
                                    buVal = BackupFile(nsrc, ndst);
                                }
                                if (buVal == 112 || buVal == 28) {//Insufficient space error codes
                                    break;
                                }
                            }
                        }
                        if (isFLR) {
                            checkPath.insert(0, source);
                            checkPath.insert(2, "\\");
                            buDetailsFile << checkPath;
                            buDetailsFile << endl;
                            if (buVal == 0) {
                                buDetailsFile << "Success";
                                buDetailsFile << endl;
                            } else {
                                buDetailsFile << "Failed";
                                buDetailsFile << endl;
                            }
                        }
                    }
                }
            }
        }

        if ((UsnRecord->Reason == USN_REASON_RENAME_OLD_NAME)&&(UsnRecord->Usn < JournalData.NextUsn)) {
            bool backupFlag = true;
            show_record(UsnRecord);
            string name;
            name.assign(name1.begin(), name1.end());
            name1.clear();

            while ((UsnRecord->Reason) != USN_REASON_RENAME_NEW_NAME) {
                dwRetBytes -= UsnRecord->RecordLength;
                // Find the next record
                if (dwRetBytes <= 0)
                    findnextrecord();
                else
                    UsnRecord = (PUSN_RECORD) (((PCHAR) UsnRecord) + UsnRecord->RecordLength);
                show_record(UsnRecord);
                name1.clear();
                if ((UsnRecord->Reason == USN_REASON_RENAME_NEW_NAME)&&(UsnRecord->Usn < JournalData.NextUsn)) {
                    show_record(UsnRecord);
                    string name2;
                    name2.assign(name1.begin(), name1.end());
                    if (isFLR) {
                        if ((!(isSelectedFile(name, source, volumeList)))&&(!(isSelectedFile(name2, source, volumeList))))
                            backupFlag = false;
                    }
                    if (backupFlag) {
                        rename_file.write(name.c_str(), strlen(name.c_str()));
                        rename_file << "--";
                        rename_file.write(name2.c_str(), strlen(name2.c_str()));
                        rename_file << endl;
                        name1.clear();
                    }
                }
            }
            if (isFLR) {
                name.insert(0, source);
                name.insert(2, "\\");
                if (std::find(volumeList.begin(), volumeList.end(), name) != volumeList.end()) {
                    buDetailsFile << name;
                    buDetailsFile << endl;
                    buDetailsFile << "Not found";
                    buDetailsFile << endl;
                }
            }
        }

        if (((UsnRecord->Reason & USN_REASON_DATA_OVERWRITE) | (UsnRecord->Reason & USN_REASON_DATA_EXTEND) | (UsnRecord->Reason & USN_REASON_DATA_TRUNCATION))&&(UsnRecord->Usn < JournalData.NextUsn)) {
            bool backupFlag = true;
            string checkPath;
            show_record(UsnRecord);
            DWORDLONG num = UsnRecord->FileReferenceNumber;
            wstring Path;
            Path = findfilename(hVol, num);
            if (!Path.empty()) {
                wstring newS;
                newS = device;
                newS += Path;
                wstring newD;
                newD = destination;
                newD += Path;
                if (isFLR) {
                    wstring croppedPath = Path.substr(1);
                    checkPath.assign(croppedPath.begin(), croppedPath.end());
                    if (!(isSelectedFile(checkPath, source, volumeList)))
                        backupFlag = false;
                }
                if (backupFlag) {
                    if ((newS.find(L"pagefile.sys") == std::string::npos) && (!PathFileExists(newD.c_str()))&&(PathFileExists(newS.c_str()))) {

                        wstring newDest1;
                        const size_t pos = newD.rfind('\\');
                        if (std::string::npos != pos) {
                            newDest1 = newD.substr(0, pos);
                        }
                        SHCreateDirectoryEx(NULL, newDest1.c_str(), NULL);
                        if (isEncrypted) {
                            buVal = EncryptBackupFile(newS, newD, secretKey);
                        } else {
                            buVal = BackupFile(newS, newD);
                        }
                        if (buVal == 112 || buVal == 28) {//Insufficient space error codes
                            break;
                        }
                        if (isFLR) {
                            checkPath.insert(0, source);
                            checkPath.insert(2, "\\");
                            std::vector<string>::iterator overwriteIterator;
                            overwriteIterator = std::find(overwriteFailedList.begin(), overwriteFailedList.end(), checkPath);
                            if (buVal == 0) {
                                if (overwriteIterator != overwriteFailedList.end()) {
                                    overwriteFailedList.erase(overwriteIterator);
                                }
                                buDetailsFile << checkPath;
                                buDetailsFile << endl;
                                buDetailsFile << "Success";
                                buDetailsFile << endl;
                            } else {
                                if (overwriteIterator != overwriteFailedList.end()) {
                                    overwriteFailedList.push_back(checkPath);
                                }
                            }
                        }
                    }
                }
            }
            name1.clear();
        }

        if ((UsnRecord->Reason == (USN_REASON_FILE_DELETE | USN_REASON_CLOSE))&&(UsnRecord->Usn < JournalData.NextUsn)) {
            bool backupFlag = true;
            show_record(UsnRecord);
            wstring delS;
            delS = device;
            delS += '\\';
            delS += name1;
            string checkPath;
            checkPath.assign(name1.begin(), name1.end());
            if (isFLR) {
                if (!(isSelectedFile(checkPath, source, volumeList)))
                    backupFlag = false;
            }
            if (backupFlag) {
                if (!PathFileExists(delS.c_str())) {
                    delete_file.write(checkPath.c_str(), strlen(checkPath.c_str()));
                    delete_file << endl;
                }
                if (isFLR) {
                    checkPath.insert(0, source);
                    checkPath.insert(2, "\\");
                    if (std::find(volumeList.begin(), volumeList.end(), checkPath) != volumeList.end()) {
                        buDetailsFile << checkPath;
                        buDetailsFile << endl;
                        buDetailsFile << "Deleted";
                        buDetailsFile << endl;
                    }
                }
            }
            name1.clear();
        }
        dwRetBytes -= UsnRecord->RecordLength;
        // Find the next record
        if (dwRetBytes <= 0)
            findnextrecord();
        else
            UsnRecord = (PUSN_RECORD) (((PCHAR) UsnRecord) + UsnRecord->RecordLength);
    }
    if (hVol)
        CloseHandle(hVol);
    if (hVol1)
        CloseHandle(hVol1);
    delete_file.close();
    rename_file.close();
    
    for (vector<string>::iterator loop = overwriteFailedList.begin(); loop != overwriteFailedList.end(); ++loop) {
        buDetailsFile << (*loop);
        buDetailsFile << endl;
        buDetailsFile << "Failed";
        buDetailsFile << endl;
    }
    
    if (buVal == 112 || buVal == 28)
        return 112;
    
    return 0;
}

bool isSelectedFile(string file, string letter, std::vector<string> &volumeList) {
    file.insert(0, letter);
    file.insert(2, "\\");
    for (vector<string>::iterator loop = volumeList.begin(); loop != volumeList.end(); ++loop) {
        string fileInList = *loop;
        if (!file.compare(0, fileInList.size(), fileInList)) {
            if (PathFileExistsA(fileInList.c_str())) {
                DWORD attr = GetFileAttributesA(fileInList.c_str());
                if (attr & FILE_ATTRIBUTE_DIRECTORY) {
                    fileInList.append("\\");
                    if (!file.compare(0, fileInList.size(), fileInList)) {
                        return true;
                    }
                } else {
                    return true;
                }
            } else {
                return true;
            }
        }
    }
    return false;
}

int RestoreFile(_In_ wstring& source, _In_ wstring& destination) {
    gzFile hSourceFile;
    int decompHan = _wopen(source.c_str(), _O_RDONLY | _O_BINARY);
    if (decompHan == -1) {
        logger->log(NORMAL, L"wopen error %d %ws\n", errno, source.c_str());
        return errno;
    }
    hSourceFile = gzdopen(decompHan, "rb");
    if (!hSourceFile) {
        logger->log(NORMAL, L"Decompress open error %ws\n", source.c_str());
        return 1;
    }
    HANDLE hDestinationFile = ::CreateFile(
            destination.c_str(),
            GENERIC_WRITE | WRITE_OWNER | WRITE_DAC,
            FILE_SHARE_READ,
            NULL,
            CREATE_ALWAYS,
            FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_BACKUP_SEMANTICS,
            NULL);
    if (hDestinationFile == INVALID_HANDLE_VALUE) {
        int val = (int) GetLastError();
        logger->log(NORMAL, L"CreateFile failed with error %d when opening destination file %ws\n", val, destination.c_str());
        return val;
    }

    const DWORD DEFAULT_BUFFER_SIZE = 4086;
    DWORD bytesRead, bytesWritten;
    BYTE buffer[DEFAULT_BUFFER_SIZE];
    LPVOID context = NULL;
    HRESULT hr = S_OK;

    while ((bytesRead = gzread(hSourceFile, buffer, DEFAULT_BUFFER_SIZE)) > 0) {
        if (!BackupWrite(hDestinationFile, buffer, bytesRead, &bytesWritten, FALSE, TRUE, &context)) {
            int val = (int) GetLastError();
            logger->log(NORMAL, L"Decompress write failed with error %d\n", val);
            if (hDestinationFile)
                CloseHandle(hDestinationFile);
            if (hSourceFile)
                gzclose(hSourceFile);
            return val;
        }
    }
    BackupWrite(hDestinationFile, NULL, 0, NULL, TRUE, TRUE, &context);
    if (hSourceFile)
        gzclose(hSourceFile);
    if (hDestinationFile)
        CloseHandle(hDestinationFile);

    return 0;
}

int RestoreEncryptedFile(_In_ wstring& source, _In_ wstring& destination, wstring secretKey) {
    const DWORD DEFAULT_BUFFER_SIZE = 4096;
    unsigned char *input = new unsigned char[DEFAULT_BUFFER_SIZE];
    unsigned char *output = new unsigned char[DEFAULT_BUFFER_SIZE];
    DWORD dwBlockLen;
    DWORD dwCount;
    FILE *in;
    int ret;
    z_stream strm;
    HCRYPTKEY hKey = generateHashKey(&secretKey[0]);
    if (hKey == -1) {
        logger->log(NORMAL, L"hkey is -1\n");
        if (input)
            delete[] input;
        if (output)
            delete[] output;
        return 1;
    }
    int fd = _wopen(source.c_str(), _O_RDONLY | _O_BINARY);
    if (fd == -1) {
        int errsv = errno;
        logger->log(NORMAL, L"_wopen: could not open for reading %d\n", errsv);
        return 1;
    }
    in = _fdopen(fd, "rb");
    if (in == NULL) {
        logger->log(NORMAL, L"_fdopen: could not open %ws\n", source.c_str());
        return 1;
    }
    HANDLE hDestinationFile = CreateFile(destination.c_str(), FILE_WRITE_DATA, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

    if (hDestinationFile == INVALID_HANDLE_VALUE) {
        int val = (int) GetLastError();
        logger->log(NORMAL, L"RestoreEncryptedFile invalid handle error %d for %ws\n", val, destination.c_str());
        if (input)
            delete[] input;
        if (output)
            delete[] output;
        return val;
    }

    /* initialize file and inflate state to start there */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = inflateInit2(&strm, 47); /* raw inflate */
    if (ret != Z_OK) {
        logger->log(NORMAL, L"inflateInit2 failed %d\n", ret);
        if (input)
            delete[] input;
        if (output)
            delete[] output;
        return 1;
    }

    bool fEOF = false;
    while (!fEOF) {
        memset(input, 0, DEFAULT_BUFFER_SIZE);
        dwBlockLen = fread(input, 1, DEFAULT_BUFFER_SIZE, in);
        if (feof(in)) {
            ret = Z_ERRNO;
            fEOF = true;
        }
        if (ferror(in)) {
            ret = Z_ERRNO;
            logger->log(NORMAL, L"Z_ERRNO failed\n");
            if (input)
                delete[] input;
            if (output)
                delete[] output;
            return 1;
        }
        if (dwBlockLen < DEFAULT_BUFFER_SIZE) {
            fEOF = TRUE;
        }
        if (input != NULL) {
            if (CryptDecrypt(hKey, NULL, fEOF, 0, input, &dwBlockLen)) {
                strm.avail_in = dwBlockLen;
            } else {
                DWORD dw = GetLastError();
                logger->log(NORMAL, L"cryptdecrypt failed %d\n", (int) dw);
                if (input)
                    delete[] input;
                if (output)
                    delete[] output;
                return (int) dw;
            }
        }
        strm.next_in = input;

        do {
            strm.avail_out = DEFAULT_BUFFER_SIZE;
            strm.next_out = output;
            ret = inflate(&strm, Z_NO_FLUSH); /* normal inflate */
            if (ret == Z_NEED_DICT) {
                logger->log(NORMAL, L"Z_NEED_DICT\n");
                ret = Z_DATA_ERROR;
            }
            if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR) {
                logger->log(NORMAL, L"Z_MEM_ERROR or Z_DATA_ERROR %d %s\n", ret, strm.msg);
                if (input)
                    delete[] input;
                if (output)
                    delete[] output;
                return 1;
            }
            int have = DEFAULT_BUFFER_SIZE - strm.avail_out;
            if (WriteFile(hDestinationFile, output, have, &dwCount, NULL)) {
            } else {
                int val = (int) GetLastError();
                logger->log(NORMAL, L"Writefile error %d\n", val);
                if (input)
                    delete[] input;
                if (output)
                    delete[] output;
                return val;
            }
            memset(output, 0, DEFAULT_BUFFER_SIZE);
        } while (strm.avail_out == 0);
    }
    if (in)
        fclose(in);
    if (hDestinationFile)
        CloseHandle(hDestinationFile);
    (void) inflateEnd(&strm);
    if (input)
        delete[] input;
    if (output)
        delete[] output;
    return 0;
}

HRESULT ModifyPrivilege(IN LPCTSTR szPrivilege, IN BOOL fEnable) {
    HRESULT hr = S_OK;
    TOKEN_PRIVILEGES NewState;
    LUID luid;
    HANDLE hToken = NULL;

    // Open the process token for this process.
    if (!OpenProcessToken(GetCurrentProcess(),
            TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
            &hToken)) {
        logger->log(NORMAL, L"Failed in OpenProcessToken\n");
        return ERROR_FUNCTION_FAILED;
    }

    // Get the local unique ID for the privilege.
    if (!LookupPrivilegeValue(NULL,
            szPrivilege,
            &luid)) {
        CloseHandle(hToken);
        logger->log(NORMAL, L"Failed in LookupPrivilegeValue\n");
        return ERROR_FUNCTION_FAILED;
    }

    // Assign values to the TOKEN_PRIVILEGE structure.
    NewState.PrivilegeCount = 1;
    NewState.Privileges[0].Luid = luid;
    NewState.Privileges[0].Attributes =
            (fEnable ? SE_PRIVILEGE_ENABLED : 0);

    // Adjust the token privilege.
    if (!AdjustTokenPrivileges(hToken,
            FALSE,
            &NewState,
            0,
            NULL,
            NULL)) {
        logger->log(NORMAL, L"Failed in AdjustTokenPrivileges\n");
        hr = ERROR_FUNCTION_FAILED;
    }

    // Close the handle.
    if (hToken)
        CloseHandle(hToken);

    return hr;
}

void RenameFiles(wstring src, wstring dest) {
    logger->log(NORMAL, L"In RenameFiles\n");
    wstring rname = src + L"\\rename_file.txt";
    string newname, oldname;
    string delimiter = "--";
    size_t pos = 0;
    int result;
    ifstream renam(rname);
    while (getline(renam, newname)) {
        if ((pos = newname.find(delimiter)) != string::npos) {
            oldname = newname.substr(0, pos);
            newname.erase(0, pos + delimiter.length());
            string oname(dest.begin(), dest.end());
            oname.append("\\");
            oname.append(oldname);
            string nname(dest.begin(), dest.end());
            nname.append("\\");
            nname.append(newname);
            result = rename(oname.c_str(), nname.c_str());
            oname.clear();
            nname.clear();
            oldname.clear();
            newname.clear();
        }
    }
    renam.close();
    logger->log(NORMAL, L"Completed Renaming files\n");
}

void DeleteFiles(wstring src, wstring dest) {
    logger->log(NORMAL, L"In DeleteFiles\n");
    wstring dname = src + L"\\delete_file.txt";
    string temp;
    ifstream del(dname);
    while (getline(del, temp)) {
        string temp1(dest.begin(), dest.end());
        temp1.append("\\");
        temp1.append(temp);
        //remove(temp1.c_str());

        CString strPath = temp1.c_str();
        strPath += '\0';
        SHFILEOPSTRUCT strOper = {0};
        strOper.hwnd = NULL;
        strOper.wFunc = FO_DELETE;
        strOper.pFrom = strPath;
        strOper.fFlags = FOF_NO_UI;

        int val = SHFileOperation(&strOper);
        if (val != 0) {
            DWORD attr = GetFileAttributes(strPath);
            if (attr & FILE_ATTRIBUTE_DIRECTORY) {
                string cmd = "cmd /c rmdir /s/q \"" + temp1 + "\"";
                int res = WinExec(cmd.c_str(), SW_HIDE);
            } else {

                string cmd = "cmd /c rm \"" + temp1 + "\"";
                int res = WinExec(cmd.c_str(), SW_HIDE);
            }
        }
        temp1.clear();
    }
    del.close();
    logger->log(NORMAL, L"Completed Deleting files\n");
}

int RestoreDirectoryTree(wstring source, wstring destination, bool isEncrypted, wstring secretKey) {
    int restoreVal = 0, retVal = 0;
    WIN32_FIND_DATA findData;
    wstring pattern = source;
    pattern += L"\\*";
    HANDLE hFind = FindFirstFile((LPCWSTR) pattern.c_str(), &findData);
    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            // If not . or .. 
            wstring name = findData.cFileName;
            if ((name != L".") && (name != L"..")&&(name != L"rename_file.txt")&&(name != L"delete_file.txt")) {
                wstring newSource = source;
                newSource += '\\';
                newSource += name;
                wstring newDestination = destination;
                newDestination += '\\';
                newDestination += name;
                if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                    if (!::CreateDirectory(newDestination.c_str(), NULL)) {
                        DWORD error = GetLastError();
                        if (error != ERROR_ALREADY_EXISTS) {
                            retVal = (int) GetLastError();
                            logger->log(NORMAL, L"CreateDirectory %ws failed with error %d\n", destination.c_str(), retVal);
                        } else {
                            RestoreDirectoryTree(newSource, newDestination, isEncrypted, secretKey);
                        }
                    } else {
                        RestoreDirectoryTree(newSource, newDestination, isEncrypted, secretKey);
                    }
                } else {
                    if (isEncrypted) {
                        restoreVal = RestoreEncryptedFile(newSource, newDestination, secretKey);
                    } else {
                        restoreVal = RestoreFile(newSource, newDestination);
                    }
                    if (restoreVal == 112 || restoreVal == 28) {//Insufficient space error codes
                        return restoreVal;
                    } else if (restoreVal != 0) {
                        retVal = restoreVal;
                    }
                }
            }
        } while (FindNextFile(hFind, &findData));
        if (hFind)
            FindClose(hFind);
    } else {
        logger->log(NORMAL, L"RestoreDirectoryTree FindFirstFile failed with error %d\n", (int) GetLastError());
    }
    return retVal;
}
