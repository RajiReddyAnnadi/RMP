
#include <stdio.h>
#include "ImageBackup/Write.h"
#include "ImageBackup/Util.h"
#include "ImageBackup/Queue.h"
#include "ImageBackup/Logger.h"
#include <io.h>
#include <fcntl.h>

#define ENCRYPT_BLOCK_SIZE 16
#define KEYLENGTH  0x00800000
#define ENCRYPT_ALGORITHM CALG_AES_128

LPWSTR levelwrite = NORMAL;
LPWSTR writeloc;
Logger *logwrite;

Write::Write(Queuecode *inputQueue, Queuecode *outputQueue, HANDLE drivehan, HANDLE filehan, unsigned __int64 partsize, unsigned int pos, unsigned clustersize, int val, wstring name, wstring src, wstring secretKey) : Thread(CREATE_SUSPENDED) {
    writeloc = (LPWSTR) name.c_str();
    logwrite = new Logger(writeloc, (LPWSTR) levelwrite);
    this->inpQueue = inputQueue;
    this->outQueue = outputQueue;
    this->dhan = drivehan;
    this->fhan = filehan;
    //this->bhan = backuphan;
    this->ptnsize = partsize;
    this->position = pos;
    this->clusterSize = clustersize;
    this->check = val;
    this->wError = 0;
    this->src = src;
    this->encryptionKey = secretKey;
}

DWORD Write::Execute() {
    try {
        DWORD retVal;
        if (check == 0) { //Restore without decryption
            retVal = WriteRestoreData();
            return retVal;
        } else if (check == 1) {//Restore with decryption
            retVal = WriteEncryptedRestoreData();
            return retVal;
        } else if (check == 2) {//Backup without encryption
            int a = _wopen(src.c_str(), _O_CREAT | _O_WRONLY | _O_BINARY);
            if (a == -1) {
                logwrite->log(NORMAL, L"wopen error: %d\nlog", errno);
            }
            this->ofile = gzdopen(a, "wb1");
            if (!ofile) {
                logwrite->log(NORMAL, L"gzdopen error %d\n", errno);
            }
            retVal = WriteData();
            gzclose(ofile);
            return retVal;
        } else if (check == 3) {//Backup with encryption
            retVal = WriteEncryptedData();
            return retVal;
        }
    } catch (exception &e) {
        return E_FAIL;
    }
}

DWORD Write::Writeusedonly() {
    unsigned __int64 runLength;
    unsigned __int64 seekPos = 0;
    unsigned __int64 toRead;
    unsigned bytesToRead, bytesRead, remainingBufferSize, bufferBytesUsed = 0;
    unsigned blksize = 2097152;
    BufferChunk *Chunk1 = inpQueue->GetChunk();
    if (Chunk1 == NULL) {
        wError = 1;
        return 1;
    }
    BYTE* Chunk = (BYTE*) Chunk1->GetData();
    DWORD Pos;
    bool ValueAvailable;
    unsigned LastIndex;
    GetValues(Pos, ValueAvailable, LastIndex);
    remainingBufferSize = Chunk1->GetSize();
    while (!((!ValueAvailable) && Pos > LastIndex)) {
        // read run length of used clusters
        runLength = GetNextRunLength(dhan);
        GetValues(Pos, ValueAvailable, LastIndex);
        toRead = clusterSize * runLength;
        while (toRead > 0) {
            if (toRead < remainingBufferSize) {
                bytesToRead = (unsigned) toRead;
                runLength = 0;
            } else {
                bytesToRead = remainingBufferSize;
                runLength -= remainingBufferSize / clusterSize;
            }
            FileWrite(Chunk, bytesToRead, &bytesRead);

            seekPos += bytesRead;
            Chunk += bytesRead;
            bufferBytesUsed += bytesRead;
            remainingBufferSize -= bytesRead;
            toRead -= bytesRead;
            Chunk1->SetSize(bufferBytesUsed);

            if (remainingBufferSize <= 0) {
                bool endval = Chunk1->getend();
                Chunk1->setend(false);
                Chunk1->SetSize(blksize);
                // release current block, because it is full and get a new block.
                outQueue->ReleaseChunk(Chunk1);

                if (!endval) {
                    Chunk1 = inpQueue->GetChunk(); // may block	
                    if (Chunk1 == NULL) {
                        wError = 1;
                        return 1;
                    }
                    Chunk = (BYTE*) Chunk1->GetData();
                    remainingBufferSize = Chunk1->GetSize();
                    bufferBytesUsed = 0;
                }
            }
        } // inner while

        // read run length of free clusters
        runLength = GetNextRunLength(dhan);
        seekPos += clusterSize * runLength; // skip free clusters  

        GetValues(Pos, ValueAvailable, LastIndex);

        LARGE_INTEGER pos, newOffset;
        pos.QuadPart = seekPos;
        BOOL bSuccess = SetFilePointerEx(fhan, pos, &newOffset, FILE_BEGIN);
    } // outer while
    return 0;
}

DWORD Write::WriteData() {
    unsigned nWriteCount;
    int blksize = 2097152;
    unsigned nBytesWritten;
    unsigned dbgRunLength = 0;
    BYTE array[3584] = {0};

    bool bEOF = false;
    while (!bEOF) {
        BufferChunk *ReadChunk = inpQueue->GetChunk();
        if (ReadChunk == NULL) {
            wError = 1;
            return 1;
        }
        nWriteCount = ReadChunk->GetSize();
        bEOF = ReadChunk->getend();
        CompressAndWrite(ReadChunk->GetData(), nWriteCount, &nBytesWritten);
        ReadChunk->setend(false);
        ReadChunk->SetSize(blksize);
        dbgRunLength += nBytesWritten;
        outQueue->ReleaseChunk(ReadChunk);
    } // while (!EOF)
    CompressAndWrite(array, 3584, &nBytesWritten);
    return 0;
}

DWORD Write::WriteEncryptedData() {
    int blksize = 2097152;

    const DWORD DEFAULT_BUFFER_SIZE = 2097152;
    int ret;
    int flush = Z_NO_FLUSH;
    z_stream strm;
    BYTE *output = new BYTE[DEFAULT_BUFFER_SIZE];

    PBYTE encrypt = NULL;
    DWORD dwBlockLen, dwCount;
    DWORD dwBufferLen;
    BufferChunk *ReadChunk;

    HCRYPTKEY hKey = generateHashKey(&encryptionKey[0]);
    if (hKey == -1) {
        logwrite->log(NORMAL, L"hkey is -1\n");
        wError = 1;
        return 1;
    }
    /* initialize file and deflate state to start there */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = deflateInit(&strm, Z_DEFAULT_COMPRESSION);
    if (ret != Z_OK) {
        logwrite->log(NORMAL, L"deflateInit failed %d\n", ret);
        wError = 1;
        return 1;
    }

    bool bEOF = false, cryptEOF = FALSE;
    do {
        strm.avail_out = DEFAULT_BUFFER_SIZE;
        strm.next_out = output;

        do {
            if ((!bEOF) && (strm.avail_in == 0)) {
                ReadChunk = inpQueue->GetChunk();
                if (ReadChunk == NULL) {
                    logwrite->log(NORMAL, L"write getchunk null\n");
                    wError = 1;
                    return 1;
                }
                bEOF = ReadChunk->getend();
                strm.avail_in = ReadChunk->GetSize();
                flush = (bEOF) ? Z_FINISH : Z_NO_FLUSH;
                strm.next_in = (BYTE *) ReadChunk->GetData();
            }
            ret = deflate(&strm, flush); /* normal deflate */
            if (ret == Z_NEED_DICT) {
                logwrite->log(NORMAL, L"Z_NEED_DICT\n");
                ret = Z_DATA_ERROR;
            }
            if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR) {
                logwrite->log(NORMAL, L"Z_MEM_ERROR or Z_DATA_ERROR %d %s\n", ret, strm.msg);
                wError = 1;
            }
            if (ret == Z_STREAM_END) {
                cryptEOF = TRUE;
            }
            if (strm.avail_in == 0) {
                ReadChunk->setend(false);
                ReadChunk->SetSize(blksize);
                outQueue->ReleaseChunk(ReadChunk);
            }
        } while ((!bEOF)&&(strm.avail_out != 0));

        int have = DEFAULT_BUFFER_SIZE - strm.avail_out;
        if (have > 0) {
            dwBlockLen = have;
            dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
            if (encrypt = (BYTE *) malloc(dwBufferLen)) {
                memcpy((encrypt), output, (dwBlockLen));

                if (CryptEncrypt(hKey, NULL, cryptEOF, 0, encrypt, &dwBlockLen, dwBufferLen)) {
                    if (WriteFile(fhan, encrypt, dwBlockLen, &dwCount, NULL)) {
                    } else {
                        int val = (int) GetLastError();
                        logwrite->log(NORMAL, L"WriteFile failed %d\n", val);
                        wError = val;
                    }
                } else {
                    DWORD dw = GetLastError();
                    logwrite->log(NORMAL, L"cryptencrypt failed %d\n", (int) dw);
                    wError = (int) dw;
                }

                memset(output, 0, DEFAULT_BUFFER_SIZE);
                free(encrypt);
            } else {
                logwrite->log(NORMAL, L"malloc failed\n");
                wError = 1;
            }
        }
    } while (ret != Z_STREAM_END);
    (void) deflateEnd(&strm);
    delete[] output;
    return 0;
}

DWORD Write::WriteRestoreData() {
    unsigned nWriteCount;
    int blksize = 2097152;
    unsigned nBytesWritten;
    unsigned dbgRunLength = 0;

    bool bEOF = false;
    while (!bEOF) {
        BufferChunk *ReadChunk = inpQueue->GetChunk();
        if (ReadChunk == NULL) {
            wError = 1;
            return 1;
        }
        nWriteCount = ReadChunk->GetSize();
        bEOF = ReadChunk->getend();
        FileWrite(ReadChunk->GetData(), nWriteCount, &nBytesWritten);
        ReadChunk->setend(false);
        ReadChunk->SetSize(blksize);
        dbgRunLength += nBytesWritten;
        outQueue->ReleaseChunk(ReadChunk);
    }
    return 0;
}

DWORD Write::WriteEncryptedRestoreData() {
    int blksize = 2097152;

    const DWORD DEFAULT_BUFFER_SIZE = 2097152;
    const DWORD SECTOR_SIZE = 512;
    int ret;
    z_stream strm;
    int prevLen = 0, newLen = 0;
    unsigned char *tempBuf = new unsigned char[DEFAULT_BUFFER_SIZE];
    unsigned char *encrypt = new unsigned char[DEFAULT_BUFFER_SIZE + ENCRYPT_BLOCK_SIZE];
    unsigned char *output = new unsigned char[DEFAULT_BUFFER_SIZE];
    DWORD dwBlockLen;
    DWORD dwCount;
    HCRYPTKEY hKey = generateHashKey(&encryptionKey[0]);
    if (hKey == -1) {
        logwrite->log(NORMAL, L"hkey is -1\n");
        wError = 1;
        return 1;
    }
    /* initialize file and inflate state to start there */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = inflateInit2(&strm, 47); /* raw inflate */
    if (ret != Z_OK) {
        logwrite->log(NORMAL, L"inflateInit2 failed %d\n", ret);
        wError = 1;
        return 1;
    }

    bool bEOF = false;
    while (!bEOF) {
        BufferChunk *ReadChunk = inpQueue->GetChunk();
        if (ReadChunk == NULL) {
            logwrite->log(NORMAL, L"readchunk null\n");
            wError = 1;
            return 1;
        }
        dwBlockLen = ReadChunk->GetSize();
        bEOF = ReadChunk->getend();
        if (CryptDecrypt(hKey, NULL, bEOF, 0, (BYTE *) ReadChunk->GetData(), &dwBlockLen)) {
        } else {
            DWORD dw = GetLastError();
            logwrite->log(NORMAL, L"cryptdecrypt failed %d\n", (int) dw);
            wError = (int) dw;
        }
        strm.avail_in = dwBlockLen;
        strm.next_in = (BYTE *) ReadChunk->GetData();

        do {
            strm.avail_out = DEFAULT_BUFFER_SIZE;
            strm.next_out = output;
            ret = inflate(&strm, Z_NO_FLUSH); /* normal inflate */
            if (ret == Z_NEED_DICT) {
                logwrite->log(NORMAL, L"Z_NEED_DICT\n");
                ret = Z_DATA_ERROR;
            }
            if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR) {
                logwrite->log(NORMAL, L"Z_MEM_ERROR or Z_DATA_ERROR %d\n", ret);
                wError = 1;
            }
            /*if (ret == Z_STREAM_END) {
                logwrite->log(NORMAL, L"Z_STREAM_END %d\n", ret);
            }*/
            int have = DEFAULT_BUFFER_SIZE - strm.avail_out;
            if (have > 0) {
                dwBlockLen = have + prevLen;
                if (dwBlockLen < SECTOR_SIZE) {
                    memcpy((tempBuf + prevLen), (output), have);
                    prevLen += have;
                } else {
                    if (dwBlockLen > DEFAULT_BUFFER_SIZE) {
                        dwBlockLen = DEFAULT_BUFFER_SIZE;
                    }
                    if ((dwBlockLen > SECTOR_SIZE) && (dwBlockLen % SECTOR_SIZE > 0)) {
                        dwBlockLen = dwBlockLen - (dwBlockLen % SECTOR_SIZE);
                    }
                    newLen = have - (dwBlockLen - prevLen);
                    if (prevLen > 0) {
                        memcpy(encrypt, tempBuf, prevLen);
                    }
                    if (newLen > 0) {
                        memcpy(tempBuf, (output + (dwBlockLen - prevLen)), newLen);
                    }

                    memcpy((encrypt + prevLen), output, (dwBlockLen - prevLen));

                    if (WriteFile(fhan, encrypt, dwBlockLen, &dwCount, NULL)) {
                    } else {
                        int val = (int) GetLastError();
                        logwrite->log(NORMAL, L"WriteFile error %d\n", val);
                        wError = val;
                    }
                    memset(output, 0, DEFAULT_BUFFER_SIZE);

                    prevLen = newLen;
                    newLen = 0;
                }
            }
        } while (strm.avail_out == 0);

        ReadChunk->setend(false);
        ReadChunk->SetSize(blksize);
        outQueue->ReleaseChunk(ReadChunk);
    }
    if (prevLen > 0) {
        if (WriteFile(fhan, tempBuf, prevLen, &dwCount, NULL)) {
        } else {
            int val = (int) GetLastError();
            logwrite->log(NORMAL, L"WriteFile error %d\n", val);
            wError = val;
        }
    }
    (void) inflateEnd(&strm);
    if (encrypt)
        delete[] encrypt;
    if (tempBuf)
        delete[] tempBuf;
    if (output)
        delete[] output;
    return 0;
}

DWORD Write::FileWrite(void *buffer, unsigned nLength, unsigned *nBytesWritten) {
    BOOL bSuccess;
    unsigned nWrote;

    bSuccess = WriteFile(fhan, buffer, nLength, (unsigned long *) &nWrote, NULL);
    if (!bSuccess) {
        DWORD error = GetLastError();
        wError = error;
        logwrite->log(NORMAL, L"Writing drive data failed with error %d\n", error);
    }
    position += nWrote;
    *nBytesWritten = nWrote;
    return 0;
}

DWORD Write::CompressAndWrite(void *buffer, unsigned nLength, unsigned *nBytesWritten) {
    unsigned nWrote;
    nWrote = gzwrite(ofile, buffer, nLength);
    if (!nWrote) {
        DWORD error = GetLastError();
        wError = error;
        logwrite->log(NORMAL, L"Writing drive data failed with error %d\n", error);
    }
    position += nWrote;
    *nBytesWritten = nWrote;
    return 0;
}