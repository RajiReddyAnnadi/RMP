#include "ImageBackup/BuildIndex.h"
#include "ImageBackup/Logger.h"
#include "ImageBackup/Util.h"
#include <io.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

LPWSTR levelidx = NORMAL;
LPWSTR idxloc;
Logger *logidx;

#define ENCRYPT_BLOCK_SIZE 16
#define KEYLENGTH  0x00800000
#define ENCRYPT_ALGORITHM CALG_AES_128

void idxLogger(wstring locname) {
    idxloc = (LPWSTR) locname.c_str();
    logidx = new Logger(idxloc, (LPWSTR) levelidx);
}

/* Deallocate an index built by build_index() */
void free_index(struct access *index) {
    if (index != NULL) {
        free(index->list);
        free(index);
    }
}

/* Add an entry to the access point list.  If out of memory, deallocate the
existing list and return NULL. */
struct access *addpoint(struct access *index, int bits,
        __int64 in, __int64 out, unsigned left, unsigned char *window) {
    struct point *next;

    /* if list is empty, create it (start with eight points) */
    if (index == NULL) {
        index = (struct access*) malloc(sizeof (struct access));
        if (index == NULL) return NULL;
        index->list = (point*) malloc(sizeof (struct point) << 3);
        if (index->list == NULL) {
            free(index);
            return NULL;
        }
        index->size = 8;
        index->have = 0;
    }/* if list is full, make it bigger */
    else if (index->have == index->size) {
        index->size <<= 1;
        next = (point*) realloc(index->list, sizeof (struct point) * index->size);
        if (next == NULL) {
            free_index(index);
            return NULL;
        }
        index->list = next;
    }

    /* fill in entry and increment how many we have */
    next = index->list + index->have;
    next->bits = bits;
    next->in = in;
    next->out = out;
    if (left)
        memcpy(next->window, window + WINSIZE - left, left);
    if (left < WINSIZE)
        memcpy(next->window + left, window, WINSIZE - left);
    index->have++;

    /* return list, possibly reallocated */
    return index;
}

/* Make one entire pass through the compressed stream and build an index, with
access points about every span bytes of uncompressed output -- span is
chosen to balance the speed of random access against the memory requirements
of the list, about 32K bytes per access point.  Note that data after the end
of the first zlib or gzip stream in the file is ignored.  build_index()
returns the number of access points on success (>= 1), Z_MEM_ERROR for out
of memory, Z_DATA_ERROR for an error in the input file, or Z_ERRNO for a
file read error.  On success, *built points to the resulting index. */
int build_index(FILE *in, __int64 span, struct access **built) {
    logidx->log(NORMAL, L"Building index...\n");
    int ret;
    __int64 totin, totout; /* our own total counters to avoid 4GB limit */
    __int64 last; /* totout value of last access point */
    struct access *index; /* access points being generated */
    z_stream strm;
    unsigned char input[CHUNK];
    unsigned char window[WINSIZE];

    /* initialize inflate */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = inflateInit2(&strm, 47); /* automatic zlib or gzip decoding */
    if (ret != Z_OK)
        return ret;

    /* inflate the input, maintain a sliding window, and build an index -- this
    also validates the integrity of the compressed data using the check
    information at the end of the gzip or zlib stream */
    totin = totout = last = 0;
    index = NULL; /* will be allocated by first addpoint() */
    strm.avail_out = 0;
    do {
        /* get some compressed data from input file */
        strm.avail_in = fread(input, 1, CHUNK, in);
        if (ferror(in)) {
            ret = Z_ERRNO;
            goto build_index_error;
        }
        if (strm.avail_in == 0) {
            ret = Z_DATA_ERROR;
            goto build_index_error;
        }
        strm.next_in = input;

        /* process all of that, or until end of stream */
        do {
            /* reset sliding window if necessary */
            if (strm.avail_out == 0) {
                strm.avail_out = WINSIZE;
                strm.next_out = window;
            }

            /* inflate until out of input, output, or at end of block --
            update the total input and output counters */
            totin += strm.avail_in;
            totout += strm.avail_out;
            ret = inflate(&strm, Z_BLOCK); /* return at end of block */
            totin -= strm.avail_in;
            totout -= strm.avail_out;
            if (ret == Z_NEED_DICT)
                ret = Z_DATA_ERROR;
            if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
                goto build_index_error;
            if (ret == Z_STREAM_END)
                break;

            /* if at end of block, consider adding an index entry (note that if
            data_type indicates an end-of-block, then all of the
            uncompressed data from that block has been delivered, and none
            of the compressed data after that block has been consumed,
            except for up to seven bits) -- the totout == 0 provides an
            entry point after the zlib or gzip header, and assures that the
            index always has at least one access point; we avoid creating an
            access point after the last block by checking bit 6 of data_type
             */
            if ((strm.data_type & 128) && !(strm.data_type & 64) &&
                    (totout == 0 || totout - last > span)) {
                index = addpoint(index, strm.data_type & 7, totin,
                        totout, strm.avail_out, window);
                if (index == NULL) {
                    ret = Z_MEM_ERROR;
                    goto build_index_error;
                }
                last = totout;
            }
        } while (strm.avail_in != 0);
    } while (ret != Z_STREAM_END);

    /* clean up and return index (release unused entries in list) */
    (void) inflateEnd(&strm);
    index->list = (point*) realloc(index->list, sizeof (struct point) * index->have);
    index->size = index->have;
    *built = index;
    return index->size;

    /* return error */
build_index_error:
    (void) inflateEnd(&strm);
    if (index != NULL)
        free_index(index);
    return ret;
}

int build_indexForEncryptedFile(FILE *in, __int64 span, struct access **built, LPTSTR pszPassword) {
    logidx->log(NORMAL, L"Building index for encrypted backup...\n");
    HCRYPTKEY hKey = generateHashKey(pszPassword);
    int ret;
    __int64 totin, totout; /* our own total counters to avoid 4GB limit */
    __int64 last; /* totout value of last access point */
    struct access *index; /* access points being generated */
    z_stream strm;
    unsigned char input[CHUNK];
    unsigned char window[WINSIZE];

    /* initialize inflate */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = inflateInit2(&strm, 47); /* automatic zlib or gzip decoding */
    if (ret != Z_OK)
        return ret;

    /* inflate the input, maintain a sliding window, and build an index -- this
    also validates the integrity of the compressed data using the check
    information at the end of the gzip or zlib stream */
    totin = totout = last = 0;
    index = NULL; /* will be allocated by first addpoint() */
    strm.avail_out = 0;
    do {
        /* get some compressed data from input file */
        strm.avail_in = fread(input, 1, CHUNK, in);
        if (ferror(in)) {
            ret = Z_ERRNO;
            goto build_index_error;
        }
        if (strm.avail_in == 0) {
            logidx->log(NORMAL, L"avail_in 0\n");
            break;
        }
        //decrypt logic
        DWORD dwBlockLen;
        DWORD dwBufferLen;
        dwBlockLen = strm.avail_in;
        dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
        bool fEOF = FALSE;
        if (dwBlockLen < CHUNK) {
            fEOF = TRUE;
        }
        strm.avail_in = decryptBuffer(hKey, input, dwBlockLen, fEOF);

        strm.next_in = input;

        /* process all of that, or until end of stream */
        do {
            /* reset sliding window if necessary */
            if (strm.avail_out == 0) {
                strm.avail_out = WINSIZE;
                strm.next_out = window;
            }

            /* inflate until out of input, output, or at end of block --
            update the total input and output counters */
            totin += strm.avail_in;
            totout += strm.avail_out;
            ret = inflate(&strm, Z_BLOCK); /* return at end of block */
            totin -= strm.avail_in;
            totout -= strm.avail_out;
            if (ret == Z_NEED_DICT)
                ret = Z_DATA_ERROR;
            if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR) {
                logidx->log(NORMAL, L"\n Buld_index data error %s", strm.msg);
                goto build_index_error;
            }
            if (ret == Z_STREAM_END)
                break;

            /* if at end of block, consider adding an index entry (note that if
            data_type indicates an end-of-block, then all of the
            uncompressed data from that block has been delivered, and none
            of the compressed data after that block has been consumed,
            except for up to seven bits) -- the totout == 0 provides an
            entry point after the zlib or gzip header, and assures that the
            index always has at least one access point; we avoid creating an
            access point after the last block by checking bit 6 of data_type
             */
            if ((strm.data_type & 128) && !(strm.data_type & 64) &&
                    (totout == 0 || totout - last > span)) {
                index = addpoint(index, strm.data_type & 7, totin,
                        totout, strm.avail_out, window);
                if (index == NULL) {
                    ret = Z_MEM_ERROR;
                    goto build_index_error;
                }
                last = totout;
            }
        } while (strm.avail_in != 0);
    } while (ret != Z_STREAM_END);

    /* clean up and return index (release unused entries in list) */
    (void) inflateEnd(&strm);
    index->list = (point*) realloc(index->list, sizeof (struct point) * index->have);
    index->size = index->have;
    *built = index;
    return index->size;

    /* return error */
build_index_error:
    (void) inflateEnd(&strm);
    if (index != NULL)
        free_index(index);
    return ret;
}

unsigned decryptBuffer(HCRYPTKEY hKey, PBYTE pbBuffer, DWORD dwCount, bool fEOF) {
    if (pbBuffer != NULL) {
        if (CryptDecrypt(hKey, NULL, fEOF, 0, pbBuffer, &dwCount)) {
            return dwCount; //return encrypted buffer
        } else {
            DWORD dw = GetLastError();
            logidx->log(NORMAL, L"\n CryptDecrypt failed %d", (int) dw);
        }
    }
}

int write_uint32(gzFile gz, uint32_t v) {
    return gzwrite(gz, &v, sizeof (v));
}

/* Demonstrate the use of build_index() and extract() by processing the file
provided on the command line, and the extracting 16K from about 2/3rds of
the way through the uncompressed output, and writing that to stdout. */
int indexCreation(wstring backupFile, bool isEncrypted, wstring secretKey) {
    size_t pos = backupFile.rfind(L".");
    wstring indexName = backupFile.substr(0, pos) + L".idx";
    //string fileName(backupFile.begin(), backupFile.end());
    //string indexFile(indexName.begin(), indexName.end());
    int len;
    off_t offset;
    FILE *in;
    struct access *index = NULL;
    unsigned char buf[CHUNK];
    
    //in = fopen(fileName.c_str(), "rb");
        int fd = _wopen(backupFile.c_str(), _O_RDONLY | _O_BINARY);
        if (fd == -1) {
            int errsv = errno;
            logidx->log(NORMAL, L"_wopen: could not open for reading %d\n", errsv);
            return 1;
        }
        else {
            logidx->log(NORMAL, L"index file : fd ok\n");
        }
        in = _fdopen(fd, "rb");
	if (in == NULL) {
		logidx->log(NORMAL, L"_fdopen: could not open %ws for reading\n", backupFile.c_str());
		return 1;
	}

    /* build index */
    if (isEncrypted) {
        len = build_indexForEncryptedFile(in, SPAN, &index, &secretKey[0]);
    } else {
        len = build_index(in, SPAN, &index);
    }
    if (len < 0) {
        fclose(in);
        switch (len) {
            case Z_MEM_ERROR:
                logidx->log(NORMAL, L"zran: out of memory\n");
                break;
            case Z_DATA_ERROR:
                logidx->log(NORMAL, L"zran: compressed data error in %ws\n", backupFile.c_str());
                break;
            case Z_ERRNO:
                logidx->log(NORMAL, L"zran: read error on %ws\n", backupFile.c_str());
                break;
            default:
                logidx->log(NORMAL, L"zran: error %d while building index\n", len);
        }
        return 1;
    }
    logidx->log(NORMAL, L"zran: built index with %d access points\n", len);
    fclose(in);

    int fileDescriptor = _wopen(indexName.c_str(),  _O_CREAT | _O_WRONLY | _O_BINARY, _S_IWRITE);
        if (fileDescriptor == -1) {
                int errsv = errno;
                logidx->log(NORMAL, L"_wopen fileDescriptor error %d\n", errsv);
        }
        else {
                logidx->log(NORMAL, L"_wopen fileDescriptor success\n");
        }
    gzFile gz = gzdopen(fileDescriptor, "wb");
	//gzFile gz = gzopen(indexFile.c_str(), "wb");
    if (gz == NULL) {
        logidx->log(NORMAL, L"gz null\n");
    }

    // Write a header.
    write_uint32(gz, (uint32_t) index->have);

    // Write out entry points.
    for (int i = 0; i < index->have; ++i) {
        gzwrite(gz, &index->list[i].out, sizeof (__int64));
        gzwrite(gz, &index->list[i].in, sizeof (__int64));
        gzwrite(gz, &index->list[i].bits, sizeof (int));
        gzwrite(gz, index->list[i].window, WINSIZE);
    }

    if (gz != NULL) {
        gzclose(gz);
    }
    if (index != NULL) {
        free_index(index);
    }
    return 0;
}