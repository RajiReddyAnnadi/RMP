

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.00.0603 */
/* at Sun Jan 14 23:02:55 2018
 */
/* Compiler settings for BMR_RPCAgent.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.00.0603 
    protocol : dce , ms_ext, app_config, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__


#ifndef __BMR_RPCAgent_h__
#define __BMR_RPCAgent_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __BMR_RPCAgent_INTERFACE_DEFINED__
#define __BMR_RPCAgent_INTERFACE_DEFINED__

/* interface BMR_RPCAgent */
/* [implicit_handle][version][uuid] */ 

int startBackup( 
    /* [string][in] */ wchar_t *loc,
    /* [string][in] */ wchar_t *user,
    /* [string][in] */ wchar_t *pwd,
    /* [string][in] */ wchar_t *code,
    /* [string][in] */ wchar_t *filesList,
    /* [in] */ int isEncrypted,
    /* [string][in] */ wchar_t *secretKey);

int startVolRestore( 
    /* [string][in] */ wchar_t *loc,
    /* [string][in] */ wchar_t *user,
    /* [string][in] */ wchar_t *pwd,
    /* [string][in] */ wchar_t *filesList,
    /* [in] */ int type,
    /* [string][in] */ wchar_t *mergePath,
    /* [string][in] */ wchar_t *mergeUser,
    /* [string][in] */ wchar_t *mergePwd,
    /* [string][in] */ wchar_t *restoreLogFile,
    /* [in] */ int isEncrypted,
    /* [string][in] */ wchar_t *secretKey);

int getDiskCnt( void);

void startServer( void);

void Shutdown( void);


extern handle_t BMR_RPCAgent_IfHandle;


extern RPC_IF_HANDLE BMR_RPCAgent_v1_0_c_ifspec;
extern RPC_IF_HANDLE BMR_RPCAgent_v1_0_s_ifspec;
#endif /* __BMR_RPCAgent_INTERFACE_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


