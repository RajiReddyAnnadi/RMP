#include "BMR_RPCAgent.h"

__declspec(dllexport) void __cdecl call_start()
{
	startServer();
}


__declspec(dllexport) void __cdecl call_stop()
{
	Shutdown();
}
