
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <Shlwapi.h>
#include "BMR_RPCAgent.h"
#include <windows.h>

typedef int(*trigger_backup)(wchar_t *storageLoc, wchar_t *logLoc, wchar_t *code, wchar_t *filesList, int isEncrypted, wchar_t *secretKey);

typedef int (* Disk_Cnt)();

typedef int(*trigger_volrestore)(wchar_t *storageLoc, wchar_t *logLoc, wchar_t *filesList, int type, wchar_t *mergePath, wchar_t *mergeUser, wchar_t *mergePwd, wchar_t *restoreLogFile, int isEncrypted, wchar_t *secretKey);

int startBackup(wchar_t *loc, wchar_t *user, wchar_t *pwd, wchar_t *code, wchar_t *filesList, int isEncrypted, wchar_t *secretKey) {
    trigger_backup backup;
    HINSTANCE hGetProcIDDLL;
    DWORD dwRetVal;
    NETRESOURCE nr;
    DWORD dwFlags;
    int len;
    int retVal;
    int fFreeDLL;
    wchar_t buffer[MAX_PATH];
    memset(&nr, 0, sizeof (NETRESOURCE));

    nr.dwType = RESOURCETYPE_ANY;
    nr.lpRemoteName = loc;
    nr.lpProvider = NULL;
    dwFlags = CONNECT_TEMPORARY;
    dwRetVal = WNetAddConnection2(&nr, pwd, user, dwFlags);
    if (dwRetVal == NO_ERROR || dwRetVal == 1219) {
        hGetProcIDDLL = LoadLibrary(L"BMR.dll");

        if (!hGetProcIDDLL) {
            return 11;
        }
        GetModuleFileName(NULL, buffer, MAX_PATH);
        PathRemoveFileSpec(buffer);
        backup = (trigger_backup) GetProcAddress(hGetProcIDDLL, "Add");
        if (!backup) {
            return 2;
        }
		retVal = backup(loc, buffer, code, filesList, isEncrypted, secretKey);

        dwRetVal = WNetCancelConnection2(loc, 0, TRUE);
    } else {
        if(dwRetVal==86 || dwRetVal==1326) {
            return dwRetVal;
        } else {
            return 53;
        }
    }
    fFreeDLL = FreeLibrary(hGetProcIDDLL);
    return retVal;
}

int startVolRestore(wchar_t *loc, wchar_t *user, wchar_t *pwd, wchar_t *filesList, int type, wchar_t *mergePath, wchar_t *mergeUser, wchar_t *mergePwd, wchar_t *restoreLogFile, int isEncrypted, wchar_t *secretKey) {
    trigger_volrestore restore;
    HINSTANCE hGetProcIDDLL;
    DWORD dwRetVal;
    NETRESOURCE nr;
    DWORD dwFlags;
    int retVal;
    int fFreeDLL;
    wchar_t buffer[MAX_PATH];
    memset(&nr, 0, sizeof (NETRESOURCE));

    nr.dwType = RESOURCETYPE_ANY;
    nr.lpRemoteName = loc;
    nr.lpProvider = NULL;
    dwFlags = CONNECT_TEMPORARY;
    dwRetVal = WNetAddConnection2(&nr, pwd, user, dwFlags);
    if (dwRetVal == NO_ERROR || dwRetVal == 1219) {
        hGetProcIDDLL = LoadLibrary(L"BMR.dll");

        if (!hGetProcIDDLL) {
            return 11;
        }
        GetModuleFileName(NULL, buffer, MAX_PATH);
        PathRemoveFileSpec(buffer);
        restore = (trigger_volrestore) GetProcAddress(hGetProcIDDLL, "volumeLevelRestore");
        if (!restore) {
            return 2;
        }

		retVal = restore(loc, buffer, filesList, type, mergePath, mergeUser, mergePwd, restoreLogFile, isEncrypted, secretKey);

        dwRetVal = WNetCancelConnection2(loc, 0, TRUE);
    } else {
        if(dwRetVal==86 || dwRetVal==1326) {
            return dwRetVal;
        } else {
            return 53;
        }
    }
    fFreeDLL = FreeLibrary(hGetProcIDDLL);
    return retVal;
}

int getDiskCnt() {
    Disk_Cnt count;
    HINSTANCE hGetProcIDDLL;
    int retVal = -1;
    int fFreeDLL;
    
    hGetProcIDDLL = LoadLibrary(L"BMR.dll");

    if (!hGetProcIDDLL) {
        return -1;
    }
    
    count = (Disk_Cnt) GetProcAddress(hGetProcIDDLL, "getDiskCount");
    
    retVal = count();
    
    fFreeDLL = FreeLibrary(hGetProcIDDLL);
    return retVal;
}

void startServer() {
    RPC_STATUS status;
    RPC_WSTR pszProtocolSequence = (unsigned short *) L"ncacn_np";
    RPC_WSTR pszSecurity = NULL;
    RPC_WSTR pszEndpoint = (unsigned short *) L"\\pipe\\BMR_RPCAgent";
    unsigned int cMinCalls = 1;
    unsigned int fDontWait = FALSE;
    status = RpcServerUseProtseqEp(pszProtocolSequence,
            RPC_C_LISTEN_MAX_CALLS_DEFAULT,
            pszEndpoint,
            pszSecurity);

    if (status) return;

    status = RpcServerRegisterIfEx(BMR_RPCAgent_v1_0_s_ifspec,
            NULL,
            NULL,
            RPC_IF_ALLOW_CALLBACKS_WITH_NO_AUTH,
            RPC_C_LISTEN_MAX_CALLS_DEFAULT, NULL);


    if (status) return;
    status = RpcServerListen(cMinCalls,
            RPC_C_LISTEN_MAX_CALLS_DEFAULT,
            fDontWait);

    if (status) return;
}

void Shutdown() {
    RPC_STATUS status;

    status = RpcMgmtStopServerListening(NULL);

    if (status) {
        return;
    }

    status = RpcServerUnregisterIf(NULL, NULL, FALSE);

    if (status) {
        return;
    }
}

/******************************************************/
/*         MIDL allocate and free                     */
/******************************************************/

void __RPC_FAR * __RPC_USER midl_user_allocate(size_t len) {
    return (malloc(len));
}

void __RPC_USER midl_user_free(void __RPC_FAR * ptr) {
    free(ptr);
}
