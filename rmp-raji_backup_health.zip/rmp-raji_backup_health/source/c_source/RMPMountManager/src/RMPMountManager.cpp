#include <RMPMountManager.h>
#include <jni/com_manageengine_rmp_jni_RMPMountManager.h>
#include <fstream>
#include <iostream>
#include <util/FLRManager.h>
using namespace std;

void log(JNIEnv *env, int level, const char* message, ...) {
    va_list args;
    int len;
    jint jlevel = (jint) level;
    char * buffer;
    va_start(args, message);
    len = _vscprintf(message, args) + 1;
    buffer = (char*) malloc(len * sizeof (char));
    vsprintf(buffer, message, args);
    jstring jsMessage = env->NewStringUTF(buffer);
    env->CallStaticVoidMethod(LogClass, LogID, jlevel, jsMessage);
    free(buffer);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_createSparseFile(JNIEnv *env, jclass obj, jstring sparseFileName, jlong offset) {
    log(env, 1, "createSparseFile Start 1");
    return createSparseFile(env, sparseFileName, offset);
}

JNIEXPORT void JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_installRMPDriver(JNIEnv *env, jclass obj, jstring infPath) {
    log(env, 1, "installRMPDriver Start 1");
    installRMPDriver(env, infPath);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_startRMPDriver(JNIEnv *env, jclass obj) {
    log(env, 1, "startRMPDriver Start 1");
    return startRMPDriver(env);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_deleteRMPDriver(JNIEnv *env, jclass obj) {
    log(env, 1, "deleteRMPDriver Start 1");
    return deleteRMPDriver(env);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_startVDDKDriver(JNIEnv *env, jclass obj) {
    log(env, 1, "startVDDKDriver Start 1");
    return startVDDKDriver(env);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_checkDriverStatus(JNIEnv *env, jclass obj) {
    log(env, 1, "checkDriverStatus Start 1");
    return checkDriverStatus(env);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_checkVDDKDriverStatus(JNIEnv *env, jclass obj) {
    log(env, 1, "checkVDDKDriverStatus Start 1");
    return checkVDDKDriverStatus(env);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_attachVolume(JNIEnv *env, jclass obj, jstring volumeName) {
    log(env, 1, "attachVolume Start 1");
    return attachVolume(env, volumeName);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_installVdk(JNIEnv *env, jclass obj, jstring pathToVdk) {
    log(env, 1, "installVdk Start 1");
    return installVdk(env, pathToVdk);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_installVddkDriver(JNIEnv *env, jclass obj, jstring pathToVdk) {
    log(env, 1, "installVddkDriver Start 1");
    return installVddkDriver(env, pathToVdk);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_installVcRuntime2013(JNIEnv *env, jclass obj, jstring pathToVdk) {
    log(env, 1, "installVcRuntime2013 Start 1");
    return installVcRuntime2013(env, pathToVdk);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_uninstallVdk(JNIEnv *env, jclass obj, jstring pathToVdk) {
    log(env, 1, "uninstallVdk Start 1");
    return uninstallVdk(env, pathToVdk);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_setDiskCnt(JNIEnv *env, jclass obj, jstring pathToVdk) {
    log(env, 1, "setDiskCnt Start 1");
    return setDiskCnt(env, pathToVdk);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_startVdk(JNIEnv *env, jclass obj, jstring pathToVdk) {
    log(env, 1, "startVdk Start 1");
    return startVdk(env, pathToVdk);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_stopVdk(JNIEnv *env, jclass obj, jstring pathToVdk) {
    log(env, 1, "stopVdk Start 1");
    return stopVdk(env, pathToVdk);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_chooseDriveLetter(JNIEnv *env, jclass obj) {
    log(env, 1, "chooseDriveLetter Start 1");
    return chooseDriveLetter(env);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_linkDriveLetter(JNIEnv *env, jclass obj, jstring pathToVdk, jstring driveLetter, jint diskNo) {
    log(env, 1, "linkDriveLetter Start 1");
    return linkDriveLetter(env, pathToVdk, driveLetter, diskNo);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_startUserMode(JNIEnv *env, jclass obj, jstring userMode, jstring compressedFile, jstring indexFile, jstring tempFile) {
    log(env, 1, "startUserMode Start 1");
    return startUserMode(env, userMode, compressedFile, indexFile, tempFile);
}

JNIEXPORT void JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_terminateUserMode(JNIEnv *env, jclass obj) {
    log(env, 1, "terminateUserMode Start 1");
    terminateUserMode(env);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_mountBackupImage(JNIEnv *env, jclass obj, jstring pathToVdk, jstring sparseFile, jint diskNo) {
    log(env, 1, "mountBackupImage Start 1");
    return mountBackupImage(env, pathToVdk, sparseFile, diskNo);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_mountFileLevelBackup(JNIEnv *env, jclass obj, jstring drive, jstring merge) {
    log(env, 1, "mountFileLevelBackup Start 1");
    return mountFileLevelBackup(env, drive, merge);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_unmountFileLevelBackup(JNIEnv *env, jclass obj, jstring drive) {
    log(env, 1, "unmountFileLevelBackup Start 1");
    return unmountFileLevelBackup(env, drive);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_stopRMPDriver(JNIEnv *env, jclass obj) {
    log(env, 1, "stopRMPDriver Start 1");
    return stopRMPDriver(env);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_unmountBackupImage(JNIEnv *env, jclass obj, jstring pathToVdk) {
    log(env, 1, "unmountBackupImage Start 1");
    return unmountBackupImage(env, pathToVdk);
}

JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_jni_RMPMountManager_getOsVersion
  (JNIEnv * env, jclass obj) {
     log(env, 1, "getOsVersion Start 1");
     return getOsVersion(env);
}