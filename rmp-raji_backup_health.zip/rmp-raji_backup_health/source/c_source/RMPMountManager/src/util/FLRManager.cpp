#include <util/FLRManager.h>
#include <RMPMountManager.h>
#include <windows.h>

#define FILTER_NAME	L"RMPFileMounter"
#define VDDK_DRIVER_NAME L"vstor2-mntapi20-shared"
typedef LONG NTSTATUS;
#define STATUS_SUCCESS (0x00000000)

typedef NTSTATUS(WINAPI* RtlGetVersionPtr)(PRTL_OSVERSIONINFOW);

int startProcess(JNIEnv *env, wstring cmd, bool wait) {
    size_t len = cmd.length();
    wchar_t *cmdArray = new wchar_t[len + 1];
    wcscpy(cmdArray, cmd.c_str());
    STARTUPINFO si;
    PROCESS_INFORMATION pi;

    HANDLE han;
    DWORD flags = CREATE_NO_WINDOW;

    ZeroMemory(&si, sizeof (STARTUPINFO));
    si.cb = sizeof (STARTUPINFO);
    ZeroMemory(&pi, sizeof (pi));

    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof (sa);
    sa.lpSecurityDescriptor = NULL;
    sa.bInheritHandle = TRUE;

    han = CreateFile(L"..\\logs\\DriverLogs.txt",
            FILE_APPEND_DATA,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            &sa,
            OPEN_ALWAYS,
            FILE_ATTRIBUTE_NORMAL,
            NULL);
    si.hStdInput = NULL;
    si.hStdOutput = han;
    si.dwFlags = STARTF_USESTDHANDLES;

    // Start the child process. 
    if (!CreateProcess(NULL, cmdArray, NULL, NULL, TRUE, flags, NULL, NULL, &si, &pi)) {
        log(env, 1, "CreateProcess failed %d", GetLastError());
        delete[] cmdArray;
        return -1;
    }

    if (wait) {
        WaitForSingleObject(pi.hProcess, INFINITE);
        DWORD status;
        if (!GetExitCodeProcess(pi.hProcess, &status)) {
            log(env, 1, "GetExitCodeProcess failed %d", GetLastError());
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
            CloseHandle(han);
            delete[] cmdArray;
            return -1;
        }
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        CloseHandle(han);
        delete[] cmdArray;
        return (int) status;
    }
    CloseHandle(han);
    delete[] cmdArray;
    return 1;
}

jint createSparseFile(JNIEnv *env, jstring sparseFileName, jlong offset) {
    log(env, 1, "In createSparseFile");
    LPWSTR sparse = NULL;
    sparse = (LPWSTR) env->GetStringChars(sparseFileName, NULL);
    wstring sparsePath = sparse;
    HANDLE hSparseFile = CreateFile(sparsePath.c_str(),
            GENERIC_READ | GENERIC_WRITE | DELETE,
            FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
            NULL,
            CREATE_ALWAYS,
            FILE_ATTRIBUTE_NORMAL,
            NULL);

    if (hSparseFile == INVALID_HANDLE_VALUE) {
        log(env, 1, "CreateSparseFile failed %d", GetLastError());
        if (sparse)
            env->ReleaseStringChars(sparseFileName, (const jchar*) sparse);
        return 1;
    }

    DWORD dwTemp;
    BOOL val = DeviceIoControl(hSparseFile, FSCTL_SET_SPARSE, NULL, 0, NULL, 0, &dwTemp, NULL);
    if (!val) {
        log(env, 1, "SetSparseFlag failed %d", GetLastError());
        CloseHandle(hSparseFile);
        if (sparse)
            env->ReleaseStringChars(sparseFileName, (const jchar*) sparse);
        return 1;
    }

    FILE_END_OF_FILE_INFO fileInformation;
    fileInformation.EndOfFile.QuadPart = offset;

    BOOL res = SetFileInformationByHandle(hSparseFile, FileEndOfFileInfo, &fileInformation, sizeof (FILE_END_OF_FILE_INFO));
    if (!res) {
        log(env, 1, "SetFileInfo failed %d", GetLastError());
        CloseHandle(hSparseFile);
        if (sparse)
            env->ReleaseStringChars(sparseFileName, (const jchar*) sparse);
        return 1;
    }
    CloseHandle(hSparseFile);
    if (sparse)
        env->ReleaseStringChars(sparseFileName, (const jchar*) sparse);
    return 0;
}

void installRMPDriver(JNIEnv *env, jstring pathToInf) {
    log(env, 1, "In installRMPDriver");
    LPWSTR inf = NULL;
    inf = (LPWSTR) env->GetStringChars(pathToInf, NULL);
    wstring infPath = inf;
    wstring installRMPCmd = L"DefaultInstall 128 " + infPath;
    InstallHinfSection(NULL, NULL, installRMPCmd.c_str(), 0);
    if (inf)
        env->ReleaseStringChars(pathToInf, (const jchar*) inf);
}

jint checkDriverStatus(JNIEnv *env) {
    log(env, 1, "In checkDriverStatus");
    wstring checkRMPCmd = L"sc query RMPFileMounter";
    int val = startProcess(env, checkRMPCmd, true);
    return val;
}

jint checkVDDKDriverStatus(JNIEnv *env) {
    log(env, 1, "In checkVDDKDriverStatus");
    wstring checkRMPCmd = L"sc query vstor2-mntapi20-shared";
    int val = startProcess(env, checkRMPCmd, true);
    return val;
}

jint startRMPDriver(JNIEnv *env) {
    log(env, 1, "In startRMPDriver");
    SC_HANDLE schSCManager = OpenSCManager(
            NULL,
            NULL,
            SC_MANAGER_ALL_ACCESS);

    if (NULL == schSCManager) {
        log(env, 1, "OpenSCManager failed %d", GetLastError());
        return 1;
    }

    // Get a handle to the service.

    SC_HANDLE schService = OpenService(
            schSCManager,
            FILTER_NAME,
            SERVICE_ALL_ACCESS);

    if (schService == NULL) {
        log(env, 1, "OpenService failed %d", GetLastError());
        CloseServiceHandle(schSCManager);
        return 1;
    }
    SERVICE_STATUS_PROCESS status;
    DWORD bytesNeeded;
    QueryServiceStatusEx(schService, SC_STATUS_PROCESS_INFO, (LPBYTE) & status, sizeof (SERVICE_STATUS_PROCESS), &bytesNeeded);
    if (status.dwCurrentState == SERVICE_STOPPED) {// Start it
        if (!StartService(
                schService,
                0,
                NULL)) {
            log(env, 1, "StartDriver failed %d", GetLastError());
            CloseServiceHandle(schService);
            CloseServiceHandle(schSCManager);
            return 1;
        }
    } else {
        log(env, 1, "Driver is not in stopped state %d", (int) status.dwCurrentState);
        return (int) status.dwCurrentState;
    }
    log(env, 1, "Started driver successfully");
    CloseServiceHandle(schService);
    CloseServiceHandle(schSCManager);
    return 0;
}

jint deleteRMPDriver(JNIEnv *env) {
    log(env, 1, "In deleteRMPDriver");
    SC_HANDLE schSCManager = OpenSCManager(
            NULL,
            NULL,
            SC_MANAGER_ALL_ACCESS);

    if (NULL == schSCManager) {
        log(env, 1, "OpenSCManager failed %d", GetLastError());
        return 1;
    }

    // Get a handle to the service.

    SC_HANDLE schService = OpenService(
            schSCManager,
            FILTER_NAME,
            SERVICE_ALL_ACCESS);

    if (schService == NULL) {
        log(env, 1, "OpenService failed %d", GetLastError());
        CloseServiceHandle(schSCManager);
        return 1;
    }
    SERVICE_STATUS_PROCESS status;
    DWORD bytesNeeded;
    QueryServiceStatusEx(schService, SC_STATUS_PROCESS_INFO, (LPBYTE) & status, sizeof (SERVICE_STATUS_PROCESS), &bytesNeeded);

    if (status.dwCurrentState == SERVICE_RUNNING) {// Stop it
        BOOL res = ControlService(schService, SERVICE_CONTROL_STOP, (LPSERVICE_STATUS) & status);
        if (!res) {
            log(env, 1, "StopDriver failed %d", GetLastError());
            CloseServiceHandle(schService);
            CloseServiceHandle(schSCManager);
            return 1;
        }
    }

    if (!DeleteService(schService)) {
        log(env, 1, "deleteService failed %d", GetLastError());
        CloseServiceHandle(schService);
        CloseServiceHandle(schSCManager);
        return 1;
    } else {
        log(env, 1, "Driver deleted successfully");
        return 0;
    }
}

jint startVDDKDriver(JNIEnv *env) {
    log(env, 1, "In startVDDKDriver");
    SC_HANDLE schSCManager = OpenSCManager(
            NULL,
            NULL,
            SC_MANAGER_ALL_ACCESS);

    if (NULL == schSCManager) {
        log(env, 1, "OpenSCManager failed %d", GetLastError());
        return 1;
    }

    // Get a handle to the service.

    SC_HANDLE schService = OpenService(
            schSCManager,
            VDDK_DRIVER_NAME,
            SERVICE_ALL_ACCESS);

    if (schService == NULL) {
        log(env, 1, "OpenService failed %d", GetLastError());
        CloseServiceHandle(schSCManager);
        return 1;
    }
    SERVICE_STATUS_PROCESS status;
    DWORD bytesNeeded;
    QueryServiceStatusEx(schService, SC_STATUS_PROCESS_INFO, (LPBYTE) & status, sizeof (SERVICE_STATUS_PROCESS), &bytesNeeded);
    if (status.dwCurrentState == SERVICE_STOPPED) {// Start it
        if (!StartService(
                schService,
                0,
                NULL)) {
            int error = GetLastError();
            log(env, 1, "StartDriver failed %d", error);
            CloseServiceHandle(schService);
            CloseServiceHandle(schSCManager);
            return error;
        }
    } else {
        log(env, 1, "Driver is not in stopped state %d", (int) status.dwCurrentState);
        return (int) status.dwCurrentState;
    }
    log(env, 1, "Started driver successfully");
    CloseServiceHandle(schService);
    CloseServiceHandle(schSCManager);
    return 0;
}

jint stopRMPDriver(JNIEnv *env) {
    log(env, 1, "In stopRMPDriver");
    SC_HANDLE schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    if (NULL == schSCManager) {
        log(env, 1, "OpenSCManager failed %d", GetLastError());
        return 1;
    }
    SC_HANDLE schService = OpenService(schSCManager, FILTER_NAME, SC_MANAGER_ALL_ACCESS);
    if (schService == NULL) {
        log(env, 1, "OpenService failed %d", GetLastError());
        CloseServiceHandle(schSCManager);
        return 1;
    }

    SERVICE_STATUS_PROCESS status;
    DWORD bytesNeeded;
    QueryServiceStatusEx(schService, SC_STATUS_PROCESS_INFO, (LPBYTE) & status, sizeof (SERVICE_STATUS_PROCESS), &bytesNeeded);

    if (status.dwCurrentState == SERVICE_RUNNING) {// Stop it
        BOOL res = ControlService(schService, SERVICE_CONTROL_STOP, (LPSERVICE_STATUS) & status);
        if (!res) {
            log(env, 1, "StopDriver failed %d", GetLastError());
            CloseServiceHandle(schService);
            CloseServiceHandle(schSCManager);
            return 1;
        }
    } else {
        log(env, 1, "Driver is not running %d", (int) status.dwCurrentState);
        return 0;
    }
    log(env, 1, "Stopped driver successfully");
    CloseServiceHandle(schService);
    CloseServiceHandle(schSCManager);
    return 0;
}

jint installVdk(JNIEnv *env, jstring pathToVdk) {
    log(env, 1, "In installVdk");
    LPWSTR vdk = NULL;
    vdk = (LPWSTR) env->GetStringChars(pathToVdk, NULL);
    wstring vdkPath = vdk;
    wstring installVdkCmd = L"cmd /c \"\"" + vdkPath + L"\" install\"";
    int val = startProcess(env, installVdkCmd, true);
    if (vdk)
        env->ReleaseStringChars(pathToVdk, (const jchar*) vdk);
    return val;
}

jint installVddkDriver(JNIEnv *env, jstring pathToVddkDriver) {
    log(env, 1, "In installVddkDriver");
    LPWSTR vddkPath = NULL;
    vddkPath = (LPWSTR) env->GetStringChars(pathToVddkDriver, NULL);
    wstring vddkPathW = vddkPath;
    wstring installVddkCmd = L"cmd /c \"\"" + vddkPathW + L"\"";
    int val = startProcess(env, installVddkCmd, true);
    log(env, 1, "installVddkDriver : %d", val);
    if (vddkPath)
        env->ReleaseStringChars(pathToVddkDriver, (const jchar*) vddkPath);
    return val;
}

jint installVcRuntime2013(JNIEnv *env, jstring pathToVCRuntime) {
    log(env, 1, "In installVcRuntime2013");
    LPWSTR vcRuntimePath = NULL;
    vcRuntimePath = (LPWSTR) env->GetStringChars(pathToVCRuntime, NULL);
    wstring vcRuntimePathW = vcRuntimePath;
    wstring installVcRuntimeCmd = L"\"" + vcRuntimePathW + L"\" /install /quiet";
    log(env, 1, "installVcRuntimeCmd: %ws", installVcRuntimeCmd.c_str());
    int val = startProcess(env, installVcRuntimeCmd, true);
    log(env, 1, "installVcRuntime2013 : %d", val);
    if (vcRuntimePath)
        env->ReleaseStringChars(pathToVCRuntime, (const jchar*) vcRuntimePath);
    return val;
}

jint uninstallVdk(JNIEnv *env, jstring pathToVdk) {
    log(env, 1, "In uninstallVdk");
    LPWSTR vdk = NULL;
    vdk = (LPWSTR) env->GetStringChars(pathToVdk, NULL);
    wstring vdkPath = vdk;
    wstring installVdkCmd = L"cmd /c \"\"" + vdkPath + L"\" remove\"";
    int val = startProcess(env, installVdkCmd, true);
    if (vdk)
        env->ReleaseStringChars(pathToVdk, (const jchar*) vdk);
    return val;
}

jint setDiskCnt(JNIEnv *env, jstring pathToVdk) {
    log(env, 1, "In setDiskCnt");
    LPWSTR vdk = NULL;
    vdk = (LPWSTR) env->GetStringChars(pathToVdk, NULL);
    wstring vdkPath = vdk;
    wstring startVdkCmd = L"cmd /c \"\"" + vdkPath + L"\" disk 22\"";
    int val = startProcess(env, startVdkCmd, true);
    if (vdk)
        env->ReleaseStringChars(pathToVdk, (const jchar*) vdk);
    return val;
}

jint startVdk(JNIEnv *env, jstring pathToVdk) {
    log(env, 1, "In startVdk");
    LPWSTR vdk = NULL;
    vdk = (LPWSTR) env->GetStringChars(pathToVdk, NULL);
    wstring vdkPath = vdk;
    wstring startVdkCmd = L"cmd /c \"\"" + vdkPath + L"\" start\"";
    int val = startProcess(env, startVdkCmd, true);
    if (vdk)
        env->ReleaseStringChars(pathToVdk, (const jchar*) vdk);
    return val;
}

jint stopVdk(JNIEnv *env, jstring pathToVdk) {
    log(env, 1, "In stopVdk");
    LPWSTR vdk = NULL;
    vdk = (LPWSTR) env->GetStringChars(pathToVdk, NULL);
    wstring vdkPath = vdk;
    wstring stopVdkCmd = L"cmd /c \"\"" + vdkPath + L"\" stop\"";
    int val = startProcess(env, stopVdkCmd, true);
    if (vdk)
        env->ReleaseStringChars(pathToVdk, (const jchar*) vdk);
    return val;
}

jint chooseDriveLetter(JNIEnv *env) {
    log(env, 1, "In chooseDriveLetter");
    DWORD logical_drives = GetLogicalDrives();
    int drive_letter = 3; //Starting from C:

    if (logical_drives == 0) {
        return 0;
    }
    //	Do not assign A and B to Virtual Disk even if they are not used
    //
    logical_drives >>= 2;

    while (logical_drives & 0x1) {
        logical_drives >>= 1;
        drive_letter++;
    }

    if (drive_letter > 26) {
        return 0;
    }

    return drive_letter;
}

jint linkDriveLetter(JNIEnv *env, jstring pathToVdk, jstring driveLetter, jint diskNo) {
    log(env, 1, "In linkDriveLetter");
    LPWSTR vdk = NULL;
    vdk = (LPWSTR) env->GetStringChars(pathToVdk, NULL);
    wstring vdkPath = vdk;
    LPWSTR letter = NULL;
    letter = (LPWSTR) env->GetStringChars(driveLetter, NULL);
    wstring drive = letter;
    wstring linkCmd = L"cmd /c \"\"" + vdkPath + L"\" link " + to_wstring(diskNo) + L" 0 " + drive + L"\"";
    int val = startProcess(env, linkCmd, true);
    if (vdk)
        env->ReleaseStringChars(pathToVdk, (const jchar*) vdk);
    if (letter)
        env->ReleaseStringChars(driveLetter, (const jchar*) letter);
    return val;
}

jint attachVolume(JNIEnv *env, jstring volumeName) {
    log(env, 1, "In attachVolume");
    LPWSTR vol = NULL;
    vol = (LPWSTR) env->GetStringChars(volumeName, NULL);
    HRESULT hResult;
    WCHAR instanceName[INSTANCE_NAME_MAX_CHARS + 1];

    // Validate FilterAttach parameters before method invocation
    // hResult = FilterAttachAtAltitude(FILTER_NAME,
    //         vol,
    //         L"48000",
    //         NULL, // instance name
    //         sizeof (instanceName),
    //         instanceName);
    log(env, 1, "Volume:%S", vol);
    hResult = FilterAttach( FILTER_NAME,
            (PWSTR)vol,
            NULL, // instance name
            sizeof(instanceName),
            instanceName );
    log(env, 1, "After Attaching to Volume:%S", vol);
    if (SUCCEEDED(hResult)) {
    log(env, 1, "Could not attach to device: 0x%08x", hResult);
    log(env, 1, "Attaching to Instance name: %S, Volume:%S", instanceName, vol);
    if (vol)
    env->ReleaseStringChars(volumeName, (const jchar*) vol);
    return 0;
    } else if(ERROR_FLT_INSTANCE_NAME_COLLISION == hResult || ERROR_FLT_INSTANCE_ALTITUDE_COLLISION == hResult){
    log(env, 1, "Could not attach to device: 0x%08x", hResult);
    if (vol)
    env->ReleaseStringChars(volumeName, (const jchar*) vol);
    return 0;
    }else {
    log(env, 1, "Could not attach to device: 0x%08x", hResult);
    if (vol)
    env->ReleaseStringChars(volumeName, (const jchar*) vol);
    return 1;
    }
}

jint detachVolume(JNIEnv *env, jstring volumeName) {
    log(env, 1, "In detachVolume");
    LPWSTR vol = NULL;
    vol = (LPWSTR) env->GetStringChars(volumeName, NULL);
    HRESULT hResult;

    hResult = FilterDetach(FILTER_NAME,
            vol,
            NULL);

    if (SUCCEEDED(hResult)) {
        log(env, 1, "Detaching from Volume:%S", vol);
        if (vol)
            env->ReleaseStringChars(volumeName, (const jchar*) vol);
        return 0;
    } else {
        log(env, 1, "Could not detach from device: 0x%08x", hResult);
        if (vol)
            env->ReleaseStringChars(volumeName, (const jchar*) vol);
        return 1;
    }
}

jint startUserMode(JNIEnv *env, jstring userMode, jstring compressedFile, jstring indexFile, jstring tempFile) {
    log(env, 1, "In startUserMode");
    LPWSTR cFile = NULL, iFile = NULL, uFile = NULL, tFile = NULL;
    cFile = (LPWSTR) env->GetStringChars(compressedFile, NULL);
    wstring compFileW = cFile;
    iFile = (LPWSTR) env->GetStringChars(indexFile, NULL);
    wstring indexFileW = iFile;
    uFile = (LPWSTR) env->GetStringChars(userMode, NULL);
    wstring userFileW = uFile;
    tFile = (LPWSTR) env->GetStringChars(tempFile, NULL);
    wstring tempFileW = tFile;
    //log(env, 1, "userMode: %S, compressedFile:%S, indexFile: %S", uFile, cFile, iFile);
    wstring strtCmd = L"cmd /c \"\"" + userFileW + L"\" \"" + compFileW + L"\" \"" + indexFileW + L"\" \"" + tempFileW + L"\"\"";
    //log(env, 1, "strtCmd: %ws", strtCmd.c_str());
    int val = startProcess(env, strtCmd, false);
    log(env, 1, "startUserMode returned: %d", val);
    if (cFile)
        env->ReleaseStringChars(compressedFile, (const jchar*) cFile);
    if (iFile)
        env->ReleaseStringChars(indexFile, (const jchar*) iFile);
    if (uFile)
        env->ReleaseStringChars(userMode, (const jchar*) uFile);
    return val;
}

void terminateUserMode(JNIEnv *env) {
    log(env, 1, "In terminateUserMode");
    wstring filename = L"RMPFileMounterClient.exe";
    HANDLE hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPALL, NULL);
    PROCESSENTRY32 pEntry;
    pEntry.dwSize = sizeof (pEntry);
    BOOL hRes = Process32First(hSnapShot, &pEntry);
    while (hRes) {
        if (wcscmp(pEntry.szExeFile, filename.c_str()) == 0) {
            HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, 0,
                    (DWORD) pEntry.th32ProcessID);
            if (hProcess != NULL) {
                TerminateProcess(hProcess, 0);
                CloseHandle(hProcess);
            }
        }
        hRes = Process32Next(hSnapShot, &pEntry);
    }
    CloseHandle(hSnapShot);
}

jint mountBackupImage(JNIEnv *env, jstring pathToVdk, jstring sparseFile, jint diskNo) {
    log(env, 1, "In mountBackupImage");
    LPWSTR vdk = NULL, mount = NULL;
    vdk = (LPWSTR) env->GetStringChars(pathToVdk, NULL);
    mount = (LPWSTR) env->GetStringChars(sparseFile, NULL);
    wstring vdkPath = vdk;
    wstring sparseFileW = mount;
    wstring mountCmd = L"cmd /c \"\"" + vdkPath + L"\" open " + to_wstring(diskNo) + L" \"" + sparseFileW + L"\" /p:0\"";
    int val = startProcess(env, mountCmd, true);
    log(env, 1, "mountBackupImage returned: %d", val);
    if (vdk)
        env->ReleaseStringChars(pathToVdk, (const jchar*) vdk);
    if (mount)
        env->ReleaseStringChars(sparseFile, (const jchar*) mount);
    return val;
}

jint unmountBackupImage(JNIEnv *env, jstring pathToVdk) {
    log(env, 1, "In unmountBackupImage");
    LPWSTR vdk = NULL;
    vdk = (LPWSTR) env->GetStringChars(pathToVdk, NULL);
    wstring vdkPath = vdk;
    wstring unmountCmd = L"cmd /c \"\"" + vdkPath + L"\" close *\"";
    int val = startProcess(env, unmountCmd, true);
    log(env, 1, "unmountBackupImage returned: %d", val);
    if (vdk)
        env->ReleaseStringChars(pathToVdk, (const jchar*) vdk);
    return val;
}

jint mountFileLevelBackup(JNIEnv *env, jstring drive, jstring merge) {
    log(env, 1, "In mountFileLevelBackup");
    LPWSTR letter = NULL;
    letter = (LPWSTR) env->GetStringChars(drive, NULL);
    wstring driveLetter = letter;
    LPWSTR mergeW = NULL;
    mergeW = (LPWSTR) env->GetStringChars(merge, NULL);
    wstring mergePath = mergeW;
    wstring cmd = L"cmd /c net use " + driveLetter + L" \"" + mergePath + L"\"";
    int val = startProcess(env, cmd, true);
    log(env, 1, "mountFileLevelBackup returned: %d", val);
    if (letter)
        env->ReleaseStringChars(drive, (const jchar*) letter);
    if (mergeW)
        env->ReleaseStringChars(merge, (const jchar*) mergeW);
    return val;
}

jint unmountFileLevelBackup(JNIEnv *env, jstring drive) {
    log(env, 1, "In unmountFileLevelBackup");
    LPWSTR letter = NULL;
    letter = (LPWSTR) env->GetStringChars(drive, NULL);
    wstring driveLetter = letter;
    wstring cmd = L"cmd /c net use /delete /y " + driveLetter;
    int val = startProcess(env, cmd, true);
    log(env, 1, "startUserMode returned: %d", val);
    return val;
}

jobject getOsVersion(JNIEnv *env) {
    log(env, 1, "In getOsVersion");
    HMODULE hMod = ::GetModuleHandleW(L"ntdll.dll");
    jobject properties = env->NewObject(propClass, propConID);
    if (hMod) {
        RtlGetVersionPtr fxPtr = (RtlGetVersionPtr)::GetProcAddress(hMod, "RtlGetVersion");
        if (fxPtr) {
            RTL_OSVERSIONINFOW rovi = {0};
            rovi.dwOSVersionInfoSize = sizeof (rovi);
            if (STATUS_SUCCESS == fxPtr(&rovi)) {
                int majorVersion = rovi.dwMajorVersion;
                jobject majorVersionObject = env->NewObject(intClass, intConID, (jint) majorVersion);
                env->CallObjectMethod(properties, propPutID, env->NewStringUTF("majorVersion"), majorVersionObject);
                int minorVersion = rovi.dwMinorVersion;
                jobject minorVersionObject = env->NewObject(intClass, intConID, (jint) minorVersion);
                env->CallObjectMethod(properties, propPutID, env->NewStringUTF("minorVersion"), minorVersionObject);
                return properties;
            }
        }
    }
    return properties;
}