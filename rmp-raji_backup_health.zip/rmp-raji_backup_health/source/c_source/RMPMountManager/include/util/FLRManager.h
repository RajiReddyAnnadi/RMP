#include <Windows.h>
#include <fltUser.h>
#include <string>
#include <Setupapi.h>
#include <process.h>
#include <Tlhelp32.h>
#include <winbase.h>
#include <jni.h>
using namespace std;

int startProcess(JNIEnv *env, string cmd, bool wait);
jint createSparseFile(JNIEnv *env, jstring sparseFileName, jlong offset);
void installRMPDriver(JNIEnv *env, jstring pathToInf);
jint startRMPDriver(JNIEnv *env);
jint deleteRMPDriver(JNIEnv *env);
jint startVDDKDriver(JNIEnv *env);
jint checkDriverStatus(JNIEnv *env);
jint checkVDDKDriverStatus(JNIEnv *env);
jint attachVolume(JNIEnv *env, jstring volumeName);
jint startUserMode(JNIEnv *env, jstring userMode, jstring compressedFile, jstring indexFile, jstring tempFile);
void terminateUserMode(JNIEnv *env);
jint installVdk(JNIEnv *env, jstring pathToVdk);
jint installVddkDriver(JNIEnv *env, jstring pathToVddkDriver);
jint installVcRuntime2013(JNIEnv *env, jstring pathToVCRuntime);
jint uninstallVdk(JNIEnv *env, jstring pathToVdk);
jint setDiskCnt(JNIEnv *env, jstring pathToVdk);
jint startVdk(JNIEnv *env, jstring pathToVdk);
jint stopVdk(JNIEnv *env, jstring pathToVdk);
jint chooseDriveLetter(JNIEnv *env);
jint linkDriveLetter(JNIEnv *env, jstring pathToVdk, jstring driveLetter, jint diskNo);
jint mountBackupImage(JNIEnv *env, jstring pathToVdk, jstring sparseFile, jint diskNo);
jint mountFileLevelBackup(JNIEnv *env, jstring drive, jstring merge);
jint unmountFileLevelBackup(JNIEnv *env, jstring drive);
jint unmountBackupImage(JNIEnv *env, jstring pathToVdk);
jint detachVolume(JNIEnv *env, jstring volumeName);
jint stopRMPDriver(JNIEnv *env);
jobject getOsVersion(JNIEnv *env);