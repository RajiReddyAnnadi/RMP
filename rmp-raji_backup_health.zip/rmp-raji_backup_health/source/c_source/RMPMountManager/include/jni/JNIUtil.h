/*-----For GlobalReference-------------*/

#include <jni.h>

jclass    hashClass=0;
jmethodID hashConID=0;
jmethodID hashPutID=0;

jclass    intClass=0;
jmethodID intConID=0;
jmethodID intValueID=0;

jclass    propClass=0;
jmethodID propConID=0;
jmethodID propPutID=0;
jmethodID propGetPropertyID=0;
jmethodID propGetID=0;
jmethodID containsKeyID=0;

jclass    listClass=0;
jmethodID listGetID=0;
jmethodID listSizeID=0;
jmethodID listConID=0;
jmethodID listSizeConID=0;
jmethodID listAddID=0;
jmethodID listRemoveID=0;
jmethodID listAddIndexID=0;

jclass    gClLogger=0;
jclass    LogClass=0;
jmethodID LogID=0;
jmethodID gMtdFine=0;		
jclass    gClWinAccessProvider=0;


/*------------------------------------*/
