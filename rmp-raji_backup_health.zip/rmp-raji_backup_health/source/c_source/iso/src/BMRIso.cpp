#include <BMRIso.h>
#include <jni/com_manageengine_rmp_jni_BMRIso.h>
#include <fstream>
#include <iostream>
#include <util/CreateIso.h>
using namespace std;

void log(JNIEnv *env, int level, const char* message, ...) {
    va_list args;
    int len;
    jint jlevel = (jint) level;
    char * buffer;
    va_start(args, message);
    len = _vscprintf(message, args) + 1;
    buffer = (char*) malloc(len * sizeof (char));
    vsprintf(buffer, message, args);
    jstring jsMessage = env->NewStringUTF(buffer);
    env->CallStaticVoidMethod(LogClass, LogID, jlevel, jsMessage);
    free(buffer);
}

JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_jni_BMRIso_createIso(JNIEnv *env, jclass obj, jstring mount, jstring kit) {
    log(env, 1, "createIso Start 1");
    return createIso(env, mount, kit);
}

JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_jni_BMRIso_updateIso(JNIEnv *env, jclass obj, jstring mount) {
    log(env, 1, "updateIso Start 1");
    return updateIso(env, mount);
}
