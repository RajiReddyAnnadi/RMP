#include <util/CreateIso.h>
#include <imapi2fs.h>
#include <BMRIso.h>

jobject createIso(JNIEnv *env, jstring mount, jstring kit) {
    log(env, 1, "createIso Start 2");

    jobject properties = env->NewObject(propClass, propConID);
    LPWSTR mntPathW = NULL, kitPathW = NULL;
    DWORD dwError = ERROR_SUCCESS;
    HRESULT hr;
    mntPathW = (LPWSTR) env->GetStringChars(mount, NULL);
    kitPathW = (LPWSTR) env->GetStringChars(kit, NULL);
    wstring mountPath = mntPathW;
    wstring kitPath = kitPathW;
    wstring isoPath = mountPath + L"RMP.iso";
    wstring mountPathW = mountPath + L"mount";
    wstring dllPath = mountPath + L"DriveImage64.dll";
    wstring dllMount = mountPath + L"mount\\Windows\\System32\\DriveImage64.dll";
    wstring wizardPath = mountPath + L"Wizard64.exe";
    wstring wizardMount = mountPath + L"mount\\Windows\\System32\\Wizard64.exe";
    wstring toolkitPath = mountPath + L"Xceed.Wpf.Toolkit.dll";
    wstring toolkitMount = mountPath + L"mount\\Windows\\System32\\Xceed.Wpf.Toolkit.dll";
    wstring batPath = mountPath + L"pestart.bat";
    wstring batMount = mountPath + L"mount\\Windows\\System32\\pestart.bat";
    wstring isoFolder = mountPath + L"iso";
    wstring bootFolder = mountPath + L"iso\\BOOT";
    wstring efiFolder = mountPath + L"iso\\EFI";
    wstring efiBootFolder = mountPath + L"iso\\EFI\\BOOT";
    wstring efiMicrosoftFolder = mountPath + L"iso\\EFI\\Microsoft";
    wstring efiMicrosoftBootFolder = mountPath + L"iso\\EFI\\Microsoft\\Boot";
    wstring sourcesFolder = mountPath + L"iso\\sources";
    wstring wimPath = kitPath + L"\\Windows Preinstallation Environment\\amd64\\en-us\\winpe.wim";
    wstring wimMount = mountPath + L"iso\\sources\\boot.wim";
    wstring bcdPath = kitPath + L"\\Windows Preinstallation Environment\\amd64\\Media\\Boot\\BCD";
    wstring bcdMount = mountPath + L"iso\\BOOT\\BCD";
    wstring bootPath = kitPath + L"\\Windows Preinstallation Environment\\amd64\\Media\\Boot\\boot.sdi";
    wstring bootMount = mountPath + L"iso\\BOOT\\BOOT.SDI";
    wstring bootfixPath = kitPath + L"\\Windows Preinstallation Environment\\amd64\\Media\\Boot\\bootfix.bin";
    wstring bootfixMount = mountPath + L"iso\\BOOT\\BOOTFIX.BIN";
    wstring etfsbootPath = kitPath + L"\\Deployment Tools\\amd64\\Oscdimg\\etfsboot.com";
    wstring etfsbootMount = mountPath + L"iso\\BOOT\\etfsboot.com";
    wstring bootmgrPath = kitPath + L"\\Windows Preinstallation Environment\\amd64\\Media\\bootmgr";
    wstring bootmgrMount = mountPath + L"iso\\BOOTMGR";
    wstring bootmgrEfiPath = kitPath + L"\\Windows Preinstallation Environment\\amd64\\Media\\bootmgr.efi";
    wstring bootmgrEfiMount = mountPath + L"iso\\BOOTMGR.EFI";
    wstring bootx64EfiPath = kitPath + L"\\Windows Preinstallation Environment\\amd64\\Media\\EFI\\BOOT\\BOOTX64.EFI";
    wstring bootx64EfiMount = mountPath + L"iso\\EFI\\BOOT\\BOOTX64.EFI";
    wstring microsBcdPath = kitPath + L"\\Windows Preinstallation Environment\\amd64\\Media\\EFI\\Microsoft\\Boot\\BCD";
    wstring bcdMountPath = mountPath + L"iso\\EFI\\Microsoft\\Boot\\BCD";
    wstring efiSysBin = kitPath + L"\\Deployment Tools\\amd64\\Oscdimg\\efisys.bin";
    wstring efiSysBinMount = mountPath + L"iso\\EFI\\Microsoft\\Boot\\efisys.bin";
    wstring startnetPath = mountPath + L"mount\\Windows\\System32\\startnet.cmd";
    wofstream ofile;
    CreateDirectory(mountPathW.c_str(), NULL);
    CreateDirectory(isoFolder.c_str(), NULL);
    CreateDirectory(bootFolder.c_str(), NULL);
    CreateDirectory(efiFolder.c_str(), NULL);
    CreateDirectory(efiBootFolder.c_str(), NULL);
    CreateDirectory(efiMicrosoftFolder.c_str(), NULL);
    CreateDirectory(efiMicrosoftBootFolder.c_str(), NULL);
    CreateDirectory(sourcesFolder.c_str(), NULL);
    CopyFile(wimPath.c_str(), wimMount.c_str(), FALSE);
    CopyFile(etfsbootPath.c_str(), etfsbootMount.c_str(), FALSE);
    dwError = UnmountImage(FALSE, mountPathW);
    dwError = MountImage(TRUE, wimMount, mountPathW);
    if (ERROR_SUCCESS == dwError) {
        AddPackage(mountPathW, kitPath);
        CopyFile(dllPath.c_str(), dllMount.c_str(), FALSE);
        CopyFile(batPath.c_str(), batMount.c_str(), FALSE);
        CopyFile(wizardPath.c_str(), wizardMount.c_str(), FALSE);
        CopyFile(toolkitPath.c_str(), toolkitMount.c_str(), FALSE);
        ofile.open(startnetPath.c_str(), ios::out);
        ofile << L"wpeinit";
        ofile << endl;
        ofile << L"Wizard64.exe";
        ofile.close();
        dwError = UnmountImage(TRUE, mountPathW);
        if (ERROR_SUCCESS == dwError) {
            CopyFile(bcdPath.c_str(), bcdMount.c_str(), FALSE);
            CopyFile(bootPath.c_str(), bootMount.c_str(), FALSE);
            CopyFile(bootfixPath.c_str(), bootfixMount.c_str(), FALSE);
            CopyFile(bootmgrPath.c_str(), bootmgrMount.c_str(), FALSE);
            CopyFile(bootmgrEfiPath.c_str(), bootmgrEfiMount.c_str(), FALSE);
            CopyFile(bootx64EfiPath.c_str(), bootx64EfiMount.c_str(), FALSE);
            CopyFile(microsBcdPath.c_str(), bcdMountPath.c_str(), FALSE);
            CopyFile(efiSysBin.c_str(), efiSysBinMount.c_str(), FALSE);
            hr = isoCreation(env, etfsbootMount, efiSysBinMount, bootFolder, efiFolder, sourcesFolder, bootmgrMount, bootmgrEfiMount, isoPath);
            if (hr == S_OK) {
                log(env, 1, "Iso creation successful");
                int retValInt = 0;
                jobject installObject = env->NewObject(intClass, intConID, (jint) retValInt);
                env->CallObjectMethod(properties, propPutID, env->NewStringUTF("retVal"), installObject);
            } else {
                log(env, 1, "Iso creation failed");
                int retValInt = 1;
                jobject installObject = env->NewObject(intClass, intConID, (jint) retValInt);
                env->CallObjectMethod(properties, propPutID, env->NewStringUTF("retVal"), installObject);
            }
        } else {
            log(env, 1, "Unmounting image failed");
            int retValInt = (int) dwError;
            jobject installObject = env->NewObject(intClass, intConID, (jint) retValInt);
            env->CallObjectMethod(properties, propPutID, env->NewStringUTF("retVal"), installObject);
        }
    } else {
        log(env, 1, "Mounting image failed");
        int retValInt = (int) dwError;
        jobject installObject = env->NewObject(intClass, intConID, (jint) retValInt);
        env->CallObjectMethod(properties, propPutID, env->NewStringUTF("retVal"), installObject);
    }
    if (mntPathW) env->ReleaseStringChars(mount, (const jchar*) mntPathW);
    if (kitPathW) env->ReleaseStringChars(kit, (const jchar*) kitPathW);
    return properties;
}

jobject updateIso(JNIEnv *env, jstring mount) {

    log(env, 1, "updateIso Start 2");

    jobject properties = env->NewObject(propClass, propConID);
    LPWSTR mntPathW = (LPWSTR) env->GetStringChars(mount, NULL);
    wstring mountPath = mntPathW;
    wstring etfsbootMount = mountPath + L"iso\\BOOT\\etfsboot.com";
    wstring bootFolder = mountPath + L"iso\\BOOT";
    wstring sourcesFolder = mountPath + L"iso\\sources";
    wstring bootmgrMount = mountPath + L"iso\\BOOTMGR";
    wstring isoPath = mountPath + L"RMP.iso";
    wstring efiFolder = mountPath + L"iso\\EFI";
    wstring bootmgrEfiMount = mountPath + L"iso\\BOOTMGR.EFI";
    wstring efiSysBinMount = mountPath + L"iso\\EFI\\Microsoft\\Boot\\efisys.bin";

    HRESULT hr;
    hr = isoCreation(env, etfsbootMount, efiSysBinMount, bootFolder, efiFolder, sourcesFolder, bootmgrMount, bootmgrEfiMount, isoPath);


    if (hr == S_OK) {
        log(env, 1, "Iso creation successful");
        int retValInt = 0;
        jobject installObject = env->NewObject(intClass, intConID, (jint) retValInt);
        env->CallObjectMethod(properties, propPutID, env->NewStringUTF("retVal"), installObject);
    } else {
        log(env, 1, "Iso creation failed");
        int retValInt = 1;
        jobject installObject = env->NewObject(intClass, intConID, (jint) retValInt);
        env->CallObjectMethod(properties, propPutID, env->NewStringUTF("retVal"), installObject);
    }

    if (mntPathW) env->ReleaseStringChars(mount, (const jchar*) mntPathW);

    return properties;
}

DWORD MountImage(BOOL bOpenForWriting, wstring wimpath, wstring mountpath) {
    BOOL bRet = FALSE;
    DWORD dwError = ERROR_SUCCESS;
    WCHAR szTempPath[MAX_PATH] = {0};
    HANDLE hWim = NULL;
    HANDLE hImage = NULL;

    bRet = GetTempPathW(ARRAYSIZE(szTempPath), szTempPath);
    if (!bRet) {
        dwError = GetLastError();
    }

    if (bRet) {
        DWORD dwDesiredAccess = WIM_GENERIC_READ | WIM_GENERIC_MOUNT;
        DWORD dwCreateFlags = 0;
        DWORD dwCreationResult = 0;

        if (bOpenForWriting) {
            dwDesiredAccess |= WIM_GENERIC_WRITE;
        }
        hWim = WIMCreateFile(wimpath.c_str(),
                dwDesiredAccess,
                WIM_OPEN_EXISTING,
                dwCreateFlags,
                0,
                &dwCreationResult);
        if (!hWim) {
            dwError = GetLastError();
            bRet = FALSE;
        }
    }
    if (bRet) {
        bRet = WIMSetTemporaryPath(hWim, szTempPath);

        if (!bRet) {
            dwError = GetLastError();
        }
    }
    if (bRet) {
        hImage = WIMLoadImage(hWim, 1);

        if (!hImage) {
            dwError = GetLastError();
            bRet = FALSE;
        }
    }
    if (bRet) {
        DWORD dwMountFlags = 0;

        if (!bOpenForWriting) {
            dwMountFlags |= WIM_FLAG_MOUNT_READONLY;
        }
        bRet = WIMMountImageHandle(hImage, mountpath.c_str(), dwMountFlags);

        if (!bRet) {
            dwError = GetLastError();
        }
    }

    if (hImage) WIMCloseHandle(hImage);
    if (hWim) WIMCloseHandle(hWim);

    return dwError;
}

void AddPackage(wstring mountPathW, wstring kitPath) {
    wstring pack1 = kitPath + L"\\Windows Preinstallation Environment\\amd64\\WinPE_OCs\\WinPE-NetFx.cab";
    wstring pack2 = kitPath + L"\\Windows Preinstallation Environment\\amd64\\WinPE_OCs\\en-us\\WinPE-NetFx_en-us.cab";
    DismSession session = DISM_SESSION_DEFAULT;
    HRESULT hr;
    hr = DismInitialize(DismLogErrorsWarningsInfo, NULL, NULL);
    if (FAILED(hr)) {
        wprintf(L"DismInitialize Failed: %x\n", hr);
    }
    hr = DismOpenSession(mountPathW.c_str(), NULL, NULL, &session);
    if (FAILED(hr)) {
        wprintf(L"DismOpenSession Failed: %x\n", hr);
    }
    hr = DismAddPackage(session, pack1.c_str(), FALSE, FALSE, NULL, NULL, NULL);
    if (FAILED(hr)) {
        wprintf(L"DismAddPackage Failed: %x\n", hr);
        wstring pack3 = kitPath + L"\\Windows Preinstallation Environment\\amd64\\WinPE_OCs\\WinPE-NetFx4.cab";
        hr = DismAddPackage(session, pack3.c_str(), FALSE, FALSE, NULL, NULL, NULL);
        if (FAILED(hr)) {
            wprintf(L"DismAddPackage Failed: %x\n", hr);
        }
    }
    hr = DismAddPackage(session, pack2.c_str(), FALSE, FALSE, NULL, NULL, NULL);
    if (FAILED(hr)) {
        wprintf(L"DismAddPackage Failed: %x\n", hr);
        wstring pack4 = kitPath + L"\\Windows Preinstallation Environment\\amd64\\WinPE_OCs\\en-us\\WinPE-NetFx4_en-us.cab";
        hr = DismAddPackage(session, pack4.c_str(), FALSE, FALSE, NULL, NULL, NULL);
        if (FAILED(hr)) {
            wprintf(L"DismAddPackage Failed: %x\n", hr);
        }
    }
    hr = DismCloseSession(session);
    if (FAILED(hr)) {
        wprintf(L"DismCloseSession Failed: %x\n", hr);
    }
    hr = DismShutdown();
    if (FAILED(hr)) {
        wprintf(L"DismShutdown Failed: %x\n", hr);
    }
}

DWORD UnmountImage(BOOL bCommitChanges, wstring mountpath) {
    BOOL bRet = TRUE;
    DWORD dwError = ERROR_SUCCESS;
    HANDLE hWim = NULL;
    HANDLE hImage = NULL;
    DWORD dwHandleFlags = 0;
    bRet = WIMGetMountedImageHandle(mountpath.c_str(), dwHandleFlags, &hWim, &hImage);
    if (!bRet) {
        dwError = GetLastError();
    }

    if (bRet && bCommitChanges) {
        DWORD dwCommitFlags = 0;
        bRet = WIMCommitImageHandle(hImage, dwCommitFlags, NULL);
        if (!bRet) {
            dwError = GetLastError();
        }
    }

    if (bRet) {
        bRet = WIMUnmountImageHandle(hImage, 0);

        if (!bRet) {
            dwError = GetLastError();
        }
    }


    if (hImage) WIMCloseHandle(hImage);
    if (hWim) WIMCloseHandle(hWim);

    return dwError;
}

HRESULT isoCreation(JNIEnv *env, wstring bootFile, wstring uefiBootFile, wstring bootW, wstring efiFolder, wstring sourcesW, wstring bootmgrW, wstring bootmgrEfiW, wstring isoPath) {

    log(env, 1, "isoCreation Start 1");
    CoInitialize(NULL);

    HRESULT res = 0;
    IFileSystemImage2* image = NULL;
    IFileSystemImageResult* result = NULL;
    IFsiDirectoryItem* root = NULL;
    IStream* stream = NULL;
    IStream* bootstream = NULL;
    IStream* uefiBootstream = NULL;
    IBootOptions* bootoptions = NULL;
    IBootOptions* uefiBootoptions = NULL;
    BSTR bootmgr = NULL;
    BSTR bootmgrEfi = NULL;
    BSTR sources = NULL;
    BSTR boot = NULL;
    BSTR efiFol = NULL;

    res = CoCreateInstance(CLSID_MsftFileSystemImage, NULL, CLSCTX_ALL, __uuidof(IFileSystemImage2), (void**) &image);

    if (res == S_OK) {
        log(env, 1, "CoCreateInstance image successful");
        res = CoCreateInstance(CLSID_BootOptions, NULL, CLSCTX_ALL, __uuidof(IBootOptions), (void**) &bootoptions);
        res = CoCreateInstance(CLSID_BootOptions, NULL, CLSCTX_ALL, __uuidof(IBootOptions), (void**) &uefiBootoptions);
        if (res == S_OK) {
            log(env, 1, "CoCreateInstance boot options successful");
            res = image -> put_FileSystemsToCreate((FsiFileSystems) (FsiFileSystemUDF | FsiFileSystemISO9660));
            if (res == S_OK) {
                log(env, 1, "put_FileSystemsToCreate successful");
                res = image -> put_FreeMediaBlocks(0);
                if (res == S_OK) {
                    log(env, 1, "put_FreeMediaBlocks successful");
                    bootoptions->put_PlatformId(PlatformX86);
                    bootoptions->put_Emulation(EmulationNone);
                    uefiBootoptions->put_PlatformId(PlatformX86);
                    uefiBootoptions->put_Emulation(EmulationNone);
                    res = SHCreateStreamOnFileEx(bootFile.c_str(), STGM_READ | STGM_SHARE_DENY_WRITE, 0, 0, 0, &bootstream);
                    res = SHCreateStreamOnFileEx(uefiBootFile.c_str(), STGM_READ | STGM_SHARE_DENY_WRITE, 0, 0, 0, &uefiBootstream);
                    if (res == S_OK) {
                        log(env, 1, "SHCreateStreamOnFileEx successful");
                        res = bootoptions->AssignBootImage(bootstream);
                        res = uefiBootoptions->AssignBootImage(uefiBootstream);
                        if (res == S_OK) {
                            log(env, 1, "AssignBootImage successful");
                            CComSafeArray<VARIANT> bootOptArr(2);
                            CComVariant normalBootOptions(bootoptions);
                            bootOptArr.SetAt(0, normalBootOptions);
                            CComVariant uefiBootVar(uefiBootoptions);
                            bootOptArr.SetAt(1, uefiBootVar);
                            res = image->put_BootImageOptionsArray(bootOptArr.m_psa);
                            if (res == S_OK) {
                                log(env, 1, "put_BootImageOptions successful");
                                res = image -> ChooseImageDefaultsForMediaType(IMAPI_MEDIA_TYPE_CDRW);
                                if (res == S_OK) {
                                    log(env, 1, "ChooseImageDefaultsForMediaType successful");
                                    res = image -> get_Root(&root);
                                    if (res == S_OK) {
                                        log(env, 1, "get_Root successful");
                                        boot = SysAllocString(bootW.c_str());
                                        res = root -> AddTree(boot, VARIANT_TRUE);
                                        if (res == S_OK) {
                                            log(env, 1, "AddTree boot successful");
                                            efiFol = SysAllocString(efiFolder.c_str());
                                            res = root -> AddTree(efiFol, VARIANT_TRUE);
                                            if (res == S_OK) {
                                                log(env, 1, "AddTree efiFol successful");
                                                sources = SysAllocString(sourcesW.c_str());
                                                res = root -> AddTree(sources, VARIANT_TRUE);
                                                if (res == S_OK) {
                                                    log(env, 1, "AddTree sources successful");
                                                    bootmgr = SysAllocString(bootmgrW.c_str());
                                                    res = root -> AddTree(bootmgr, VARIANT_TRUE);
                                                    if (res == S_OK) {
                                                        log(env, 1, "AddTree bootmgr successful");
                                                        bootmgrEfi = SysAllocString(bootmgrEfiW.c_str());
                                                        res = root -> AddTree(bootmgrEfi, VARIANT_TRUE);
                                                        if (res == S_OK) {
                                                            log(env, 1, "AddTree bootmgrEfi successful");
                                                            res = image -> CreateResultImage(&result);
                                                            if (res == S_OK) {
                                                                log(env, 1, "CreateResultImage successful");
                                                                res = result -> get_ImageStream(&stream);
                                                                if (res == S_OK) {
                                                                    log(env, 1, "get_ImageStream successful");
                                                                    STATSTG stg;
                                                                    stream -> Stat(&stg, 1);
                                                                    char* data = new char[stg.cbSize.QuadPart];
                                                                    ULONG junk;
                                                                    stream -> Read(data, stg.cbSize.QuadPart, &junk);
                                                                    string path(isoPath.begin(), isoPath.end());
                                                                    FILE* f = fopen(path.c_str(), "wb");
                                                                    if (f == NULL) {
                                                                        log(env, 1, "fopen failed");
                                                                        res = E_HANDLE;
                                                                    } else {
                                                                        fwrite(data, stg.cbSize.QuadPart, 1, f);
                                                                        fclose(f);
                                                                    }
                                                                    delete data;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }
        }
    }

    if (res == S_OK) {
        log(env, 1, "isoCreation method successful");
    } else {
        log(env, 1, "isoCreation method failed");
    }

    if (boot != NULL) {
        SysFreeString(boot);
    }
    if (sources != NULL) {
        SysFreeString(sources);
    }
    if (sources != NULL) {
        SysFreeString(sources);
    }
    if (stream) {
        stream -> Release();
    }
    if (root) {
        root -> Release();
    }
    if (result) {
        result -> Release();
    }
    if (image) {
        image-> Release();
    }
    if (bootstream) {
        bootstream -> Release();
    }
    if (bootoptions) {
        bootoptions -> Release();
    }

    CoUninitialize();
    return res;
}