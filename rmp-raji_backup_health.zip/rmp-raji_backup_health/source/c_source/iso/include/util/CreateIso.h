#include <stdio.h>
#include <windows.h>
#include <iostream>
#include <shlwapi.h>
#include <cstdio>
#include <string>
#include <wimgapi.h>
#include <dismapi.h>
#include <fstream>
#include <jni.h>
#include <atlsafe.h>
using namespace std;

jobject createIso(JNIEnv *env,jstring mount, jstring kit);
jobject updateIso(JNIEnv *env,jstring mount);
DWORD MountImage(BOOL bOpenForWriting,wstring wimpath,wstring mountpath);
DWORD UnmountImage(BOOL bCommitChanges,wstring mountpath);
void AddPackage(wstring mountPathW,wstring kitPath);
HRESULT isoCreation(JNIEnv *env, wstring bootFile, wstring uefiBootFile, wstring bootW, wstring efiFolder, wstring sourcesW, wstring bootmgrW, wstring bootmgrEfiW, wstring isoPath);