// FileLevel.cpp : Defines the entry point for the console application.
//

#define VIXDISKLIB_VERSION_MAJOR 5
#define VIXDISKLIB_VERSION_MINOR 0
#include "stdafx.h"
#include <stdio.h>
#include <conio.h>
#include <memory.h>
#include <iostream>
#include <sstream>
#include "vixDiskLib.h"
#include "vixMntapi.h"
#include <vector>
#include <string>
#include <assert.h>
#include <windows.h>
#include <fstream>
extern "C" {
#include "vm_basic_types.h"
}
using namespace std;

//log file initialize
FILE *logFile = fopen("VixMountLogger.txt", "a");

static void
printfVDDK(FILE* file, const char* prefix, const char *fmt, va_list args)
{
	fprintf(file, "%s", prefix);
	vfprintf(file, fmt, args);
	int len = strlen(fmt);
	if (fmt[len - 1] != '\n') {
		fprintf(file, "\n");
	}
}

static void
LogVixDiskLib(const char *fmt, va_list args)
{
	printfVDDK(logFile, "Log - VixDiskLib - ", fmt, args);
}

static void
WarnVixDiskLib(const char *fmt, va_list args)
{
	printfVDDK(logFile, "Warn - VixDiskLib - ", fmt, args);
}

static void
PanicVixDiskLib(const char *fmt, va_list args)
{
	printfVDDK(logFile, "Panic - VixDiskLib - ", fmt, args);
}

static void
LogVixMntApi(const char *fmt, va_list args)
{
	printfVDDK(logFile, "Log - VixMntApi - ", fmt, args);
}

static void
WarnVixMntApi(const char *fmt, va_list args)
{
	printfVDDK(logFile, "Warn - VixMntApi - ", fmt, args);
}

static void
PanicVixMntApi(const char *fmt, va_list args)
{
	printfVDDK(logFile, "Panic - VixMntApi - ", fmt, args);
}

static void
Check(VixError error)
{
	if (error != VIX_OK) {
		fprintf(logFile, "error: %d", error);
	}
}

typedef struct {
	VixVolumeHandle volumeHandle;
	VixVolumeInfo* volInfo;
} MountedVolume;

std::vector<MountedVolume> mountedVolumes;
std::vector<VixDiskSetHandle> mountedDisks;

LPWSTR chooseDriveLetter() {
	DWORD logical_drives = GetLogicalDrives();
	int drive_letter = 3; //Starting from C:

	if (logical_drives == 0) {
		return 0;
	}
	//	Do not assign A and B to Virtual Disk even if they are not used
	//
	logical_drives >>= 2;

	while (logical_drives & 0x1) {
		logical_drives >>= 1;
		drive_letter++;
	}

	if (drive_letter > 26) {
		return 0;
	}
	char driveLetter = drive_letter + 64;

	char* driveName = new char(2 * sizeof(char));
	driveName[0] = driveLetter;
	driveName[1] = ':';

	int length = strlen(driveName) + 1;
	wchar_t* driveLetterWide = new wchar_t[length*sizeof(WCHAR)];
	mbstowcs(driveLetterWide, driveName, length);

	fprintf(logFile, "\ngot value : %ws", driveLetterWide);



	return (LPWSTR)driveLetterWide;
}

int main(int argc, char* argv[])
{

	//unmount code
	fprintf(logFile, "argc count : %d", argc);
	if (strcmp(argv[1],"unmount") == 0 ){
		for (int i = 2; i < argc; i++){
			char* driveName = argv[i];
			int length = strlen(driveName) + 1;
			wchar_t* driveLetterWide = new wchar_t[length*sizeof(WCHAR)];
			mbstowcs(driveLetterWide, driveName, length);
			DefineDosDeviceW(DDD_RAW_TARGET_PATH |
				DDD_REMOVE_DEFINITION, driveLetterWide, NULL);
		}
	return 0;
	}

	fprintf(logFile, "before vixdiskinit");
	fprintf(logFile, "\nfile name : %s", argv[1]);

	Check(VixDiskLib_Init(5,
		0,		// Minor VixDiskLib version
		LogVixDiskLib,
		WarnVixDiskLib,
		PanicVixDiskLib,
		"..\\lib\\native\\vm"));
	fprintf(logFile, "\nafter vixdiskinit\n");
	fprintf(logFile, "\nbefore vixmntapiinit\n");
	fprintf(logFile, "---> Calling VixMntapi_Init:\n");
	Check(VixMntapi_Init(5,
		0,
		NULL,
		NULL,
		NULL,
		".\\",
		"VixMntApi.config"));
	fprintf(logFile, "---> After VixMntapi_Init:\n");
	VixDiskLibConnection localConnection = NULL;
	fprintf(logFile, "---> Before VixDiskLib_Connect:\n");
	Check(VixDiskLib_Connect(NULL, &localConnection));
	fprintf(logFile, "---> After VixDiskLib_Connect:\n");
	VixDiskLibHandle childDiskHandle;
	fprintf(logFile, "---> Before VixDiskLib_Open:\n");
	uint32 openFlags = VIXDISKLIB_FLAG_OPEN_READ_ONLY;
	Check(VixDiskLib_Open(localConnection,
		argv[1],
		openFlags,
		&childDiskHandle));
	fprintf(logFile, "---> After VixDiskLib_Open:\n");

	fprintf(logFile, "---> Calling VixMntapi_OpenDiskSet:\n");
	VixDiskLibHandle* diskHandles;
	int diskHandlesCount = 1;
	diskHandles = new VixDiskLibHandle[diskHandlesCount];
	diskHandles[0] = childDiskHandle;
	VixDiskSetHandle diskSetHandle = NULL;
	fprintf(logFile, "---> Before VixMntapi_OpenDiskSet:\n");
	Check(VixMntapi_OpenDiskSet(diskHandles,
		diskHandlesCount,
		openFlags,
		&diskSetHandle));
	fprintf(logFile, "---> After VixMntapi_OpenDiskSet:\n");

	size_t volumeHandlesNumber = 0;
	VixVolumeHandle *volumeHandles = NULL;
	VixVolumeInfo *volumeInfo = NULL;

	std::vector<VixVolumeHandle> mountedVolumes;


	fprintf(logFile, "---> Calling VixMntapi_GetVolumeHandles:\n");

	Check(VixMntapi_GetVolumeHandles(diskSetHandle,
		&volumeHandlesNumber,
		&volumeHandles));
	printf("---> After VixMntapi_GetVolumeHandles:\n");


	fprintf(logFile, "---> Before VixMntapi_MountVolume:\n");
	fprintf(logFile, "--> volume handle number : %d ", volumeHandlesNumber);
	MountedVolume newVolume = { 0, 0 };
	ofstream driveList;
	driveList.open("driveList.txt", ios::out | ios::app);
	wstring returnString;
	std::wstring sVolumeName;
	for (size_t i = 0; i<volumeHandlesNumber; i++) {
		fprintf(logFile, "\n--------------------------------------------------------------------\n");
		fprintf(logFile, "---> Calling VixMntapi_MountVolume:\n");
		Check(VixMntapi_MountVolume(volumeHandles[i], TRUE));
		mountedVolumes.push_back(volumeHandles[i]);

		VixVolumeInfo *volumeInfo;
		fprintf(logFile, "---> Before VixMntapi_GetVolumeInfo:\n");
		Check(VixMntapi_GetVolumeInfo(volumeHandles[i], &volumeInfo));
		Bool test = volumeInfo->isMounted;
		fprintf(logFile, "-->type : %d\n", volumeInfo->type);
		fprintf(logFile, "-->isMounted : %d\n", test);
		fprintf(logFile, "-->symbolicLink: %s\n", volumeInfo->symbolicLink);
		fprintf(logFile, "-->inGuestMountPoints: %s\n", volumeInfo->inGuestMountPoints);
		
		fprintf(logFile, "---> After VixMntapi_GetVolumeInfo:\n");


		fprintf(logFile, "\nMounted Volume %d, Type %d, isMounted %d, symLink %s, numGuestMountPoints %d (%s)\n\n",
			i, volumeInfo->type, volumeInfo->isMounted,
			volumeInfo->symbolicLink == NULL ? "<null>" : volumeInfo->symbolicLink,
			volumeInfo->numGuestMountPoints,
			(volumeInfo->numGuestMountPoints == 1) ? (volumeInfo->inGuestMountPoints[0]) : "<null>");

		assert(volumeHandles[i]);
		assert(volumeInfo);
		newVolume.volumeHandle = volumeHandles[i];
		std::wstringstream ansiSS;
		ansiSS << volumeInfo->symbolicLink;
		sVolumeName = ansiSS.str();
		sVolumeName = sVolumeName.substr(3);
		sVolumeName.erase(sVolumeName.length() - 1);
		sVolumeName = L"\\Device" + sVolumeName;
		fprintf(logFile, "Defining MS-DOS device name \"T:\" for volume - %s", volumeInfo->symbolicLink);

		LPWSTR driveLetter = chooseDriveLetter();
		returnString = driveLetter;
		returnString = returnString.substr(0, 2);
		fprintf(logFile, "\ndrive letter: %ws", driveLetter);


		if (DefineDosDeviceW(DDD_RAW_TARGET_PATH, returnString.c_str(), sVolumeName.c_str())) {
			char* mountPoint = (volumeInfo->numGuestMountPoints == 1) ? (volumeInfo->inGuestMountPoints[0]) : "<null>";
			driveList << (char*)returnString.c_str() << "-" << mountPoint << endl;
		}
		else{
			fprintf(logFile, "not able to mount");
		}


	}
	driveList.close();
	FILE *tempFile = fopen("temp.tmp", "w");
	fclose(tempFile);
	printf("\n---> temp file created...\n");
	printf("\n---> Mounted successfully waiting for user...\n");
	Sleep(INFINITE);

Main_Exit:
	printf("\n---> came in main_exit...\n");
	VixMntapi_FreeVolumeInfo(volumeInfo);

	printf("---> After VixMntapi_MountVolume:\n");

	printf("---> Before VixDiskLib_Close:\n");
	VixDiskLib_Close(childDiskHandle);
	printf("---> After VixDiskLib_Close:\n");

	getchar();
	return 0;
}

