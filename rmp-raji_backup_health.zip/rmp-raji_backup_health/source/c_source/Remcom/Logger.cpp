#include "Logger.h"

Logger::Logger(LPWSTR logFileName, LPWSTR loglevel)
{
	this->level = loglevel;
    this->checkLogFile(logFileName);
}

Logger::~Logger()
{
	if (this->logFile != NULL)
	{
		fclose(this->logFile);
	}
}

void Logger::log(LPWSTR writeLevel, const wchar_t* message, va_list* args)
{
	if(!((_tcsicmp(DEBUG,this->level) == 0) || (_tcsicmp(writeLevel,this->level) == 0)) && this->logFile)
		return;
	int len;
	wchar_t* buffer;
	len = _vscwprintf(message, *args) + 1;
	len += 40; // some more space for timestamp and thread ID
	buffer = (wchar_t*)malloc(len * sizeof(wchar_t));

	struct __timeb64 timebuffer;
	_ftime64(&timebuffer);
	wchar_t* timeline = _wctime64(&timebuffer.time);
	swprintf(buffer, L"%.15ws: %ld: ", (timeline+4), GetCurrentThreadId());
	vswprintf(buffer + wcslen(buffer), message, *args);
	fwprintf(logFile, L"%ws", buffer);
	fflush(logFile);
	free(buffer);
}

void Logger::log(LPWSTR writeLevel, const wchar_t* message, ...)
{
	if (NULL == this->logFile) 
	{
		return;
	}
	va_list args;
	va_start(args, message);
	log(writeLevel,message, &args);
	va_end(args);
}

void Logger::checkLogFile(LPWSTR logFileName)
{
	if(!(this->logFile = _wfopen(logFileName,L"a+")))
	{
		WCHAR drive[_MAX_DRIVE], dir[_MAX_DIR];
		_tsplitpath(logFileName,drive,dir,NULL,NULL);
		WCHAR *dirFullPath = new WCHAR[wcslen(drive) + wcslen(dir) + 1];
		_tcscpy(dirFullPath,drive);
		_tcscat(dirFullPath,dir);
		if(_tcscmp(dirFullPath,L"") != 0)														
			if(GetFileAttributes(dirFullPath) == INVALID_FILE_ATTRIBUTES)							//if the given log file dir doesn't exists
				CreateDirectory(dirFullPath,NULL);												//create one
		this->logFile = _wfopen(logFileName,L"a+");

		if(dirFullPath!=NULL)	delete[] dirFullPath;
	}
}
