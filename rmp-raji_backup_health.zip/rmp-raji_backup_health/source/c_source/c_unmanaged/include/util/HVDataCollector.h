#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <windows.h>
#include <jni.h>

extern jclass hashClass;
extern jmethodID hashConID;
extern jmethodID hashPutID;

extern jclass    intClass;
extern jmethodID intConID;
extern jmethodID intValueID;

extern jclass    listClass;
extern jmethodID listGetID;
extern jmethodID listSizeID;
extern jmethodID listConID;
extern jmethodID listSizeConID;
extern jmethodID listAddID;
extern jmethodID listRemoveID;
extern jmethodID listAddIndexID;

extern jclass    propClass;
extern jmethodID propConID;
extern jmethodID propPutID;
extern jmethodID propGetPropertyID;
extern jmethodID propGetID;
extern jmethodID containsKeyID;

extern jclass gClLogger;
extern jmethodID gMtdFine;
extern jclass gClWinAccessProvider;
extern jclass LogClass;
extern jmethodID LogID;
jobject HyperVBackupC(JNIEnv *env,jstring domain, jstring user, jstring pwd, jstring jhypervHostName, jstring jfullbackupVMs, 
                            jstring jincrementalbackupVMs, jstring jrepositoryPath, jstring jbackupName, jstring jscheduleName, jstring repositoryDetailsJson, jstring jisanyVHDchanged);

jint doCBToperationsforscheduleC(JNIEnv* env, jstring jdomainName, jstring juserName, jstring jpassword, jstring jhostServer, jstring jbackupId, jstring jallVMIds);

jobject HyperVRestoreC(JNIEnv *env,jstring domain, jstring user, jstring pwd, jstring jhypervHostName, jstring vmName, jstring vmfullbackupPath, jstring vmincrementalbackupPaths,
							 jstring ischangeVMName, jstring newVMName, jstring VHDnewstorageLocation, jstring repositoryDetailsJson, jstring isPowerOn, jstring isEncrypted, jstring encryptPassword, jstring vmId, jstring restoreId, jstring paramsjson, jstring restoreFormatString);

jint InstallandstartHypervdriverC(JNIEnv* env, jstring jdomainName, jstring juserName, jstring jpassword, jstring jhostServer, jstring isInstall);

jobject copyVMfilesfromVSSSnapshotC(JNIEnv *env,jstring domain, jstring user, jstring password, jstring hostServer, jstring hypervVMId, jstring newbackupType, jstring repositoryPath, jstring backupIdentifier,
            jstring backupId, jstring jrepositoryDetailsJson, jstring isEncrypted, jstring encryptPassword, jstring vmId, jstring generateHash);

jobject HyperVHealthCheckC(JNIEnv *env,jstring domain, jstring user, jstring pwd, jstring jhypervHostName, jstring healthCheckParametersJson, jstring vmBackupDetailsJson);

void hypervJNIInitializeClassIDs(JNIEnv *env);
void log(JNIEnv *env, int level,const char* message, ...);
