#include <tchar.h>
#include<string.h>
#include <Windows.h>
#include <jni.h>

jobject checkCredentials(JNIEnv *env,jstring loc, jstring user, jstring pass,jstring connDisconn);
