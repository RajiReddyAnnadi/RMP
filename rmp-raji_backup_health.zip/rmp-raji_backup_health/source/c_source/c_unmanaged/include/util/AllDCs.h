#include <Windows.h>
#include <DsGetDC.h>
#include <ntdsapi.h>
#include <list>
#include <string>
#include <tchar.h>
#include <jni.h>
#include <activeds.h>
#include <atlbase.h>
#include <WtsApi32.h>
#include <string>
#include <iostream>
using namespace std;

jobject getAllDCs(JNIEnv *env,jstring domain, jstring juserDomain, jstring user, jstring pass, jstring dcToBind);
jobject getDCOsInfo(JNIEnv *env,jstring domain, jstring user, jstring pass, jstring dcToBind);
jobject getAllServers(JNIEnv *env,jstring domain, jstring user, jstring pass, jstring dcToBind);
jobject getAllEndPoints(JNIEnv *env,jstring domain, jstring user, jstring pass, jstring dcToBind);
