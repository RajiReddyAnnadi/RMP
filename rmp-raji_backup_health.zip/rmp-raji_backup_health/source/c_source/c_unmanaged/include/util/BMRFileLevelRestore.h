#include <Windows.h>
#include <WinIoCtl.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <tchar.h> 
#include <string>
#include <map>
#include <vector>
#include <time.h>
#include <Shlwapi.h>
#include <shlobj.h>
#include <atlstr.h>
#include <io.h>
#include <fcntl.h>
#include <jni.h>
#include "util/zlib.h"

#define ENCRYPT_BLOCK_SIZE 16
#define KEYLENGTH  0x00800000
#define ENCRYPT_ALGORITHM CALG_AES_128
using namespace std;

jint performFLR(JNIEnv *env, jint type, jint mode, jstring dc, jstring domUser, jstring domPwd, jstring rep, jstring repUser, jstring repPwd, jstring filesList,jstring ibFilesList, jstring driveMap, jstring dwnld, jstring restoreFile, jstring fbUser, jstring fbPwd,jstring renameFilesList, jboolean encypted, jstring encrPwd);
int restoreLogic(JNIEnv *env, wstring dcPath, wstring mergePath, wstring dwnldPath, int backupMode, int restoreType, std::vector<string> &volumeList, map<string, string> &fileMapping, ofstream& restoreDetailsFile, std::map<wstring, wstring> *restoredFilesMap, bool isFullRestore, bool isEncrypted, wstring secretKey);
int RestoreUncompressedFile(JNIEnv *env, wstring source, wstring destination);
int RestoreUnencryptedFile(JNIEnv *env, wstring source, wstring destination);
int RestoreEncryptedFile(JNIEnv *env, wstring source, wstring destination,wstring secretKey);
int RestoreDirectoryTree(JNIEnv *env, wstring source, wstring destination, int backupMode, bool isEncrypted, wstring secretKey);
void renameFiles(wstring renameList, wstring dcPath, int restoreType, std::map<wstring, wstring> *restoredFilesMap, wstring dwnldPath);
int decryptExtract(JNIEnv *env, wstring source, wstring destination, LPTSTR secretKey);
HCRYPTKEY generateHashKey(JNIEnv *env,LPTSTR pszPassword);