//$Id: RemoteFileAccess.h,v 1.0 2015/10/14 12:07:09 lucky.k Exp $
#ifndef UNICODE
#define UNICODE
#endif
#pragma comment(lib, "mpr.lib")

#include <jni.h>

jint RemoteFileAccessAdd(JNIEnv *env, jstring remotePath, jstring userName, jstring password);
jint RemoteFileAccessClose(JNIEnv *env, jstring remotePath);
