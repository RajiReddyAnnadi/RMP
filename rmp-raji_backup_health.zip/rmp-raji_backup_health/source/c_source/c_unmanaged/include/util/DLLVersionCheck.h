//$Id: DLLVersionCheck.h,v 1.0 2015/10/14 12:07:09 lucky.k Exp $

#include <jni.h>
#include <Windows.h>
jobject GetDotNetFrameworkRegValue(JNIEnv *env);
BOOL RegGetDWord(LPWSTR RegistryPath, LPWSTR KeyName, DWORD *value);
