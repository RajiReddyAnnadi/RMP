#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <windows.h>
#include <jni.h>

jobject triggerBackup(JNIEnv *env,jstring dc,jstring domain,jstring user,jstring pwd,jstring loc,jstring locUser,jstring locPwd,jstring code,jstring jFilesList, jint encypted, jstring encrPwd);

jobject performVLR(JNIEnv *env,jstring dc,jstring domain,jstring user,jstring pwd,jstring loc,jstring locUser,jstring locPwd,jstring jFilesList,jint type,jstring mergePath,jstring mergeUser,jstring mergePwd,jstring restoreLog, jint encypted, jstring encrPwd);

jint getCurrentDiskCnt(JNIEnv *env,jstring dc,jstring domain,jstring user,jstring pwd);

RPC_STATUS bindRPC(JNIEnv *env, LPWSTR dcName, LPWSTR domainName, LPWSTR userName, LPWSTR password);

RPC_STATUS unbindRPC();