//$Id: RMPNative.h,v 1.0 2015/10/14 12:07:09 lucky.k Exp $

#include <jni.h>

void log(JNIEnv *env, int level,const char* message, ...);

extern jclass hashClass;
extern jmethodID hashConID;
extern jmethodID hashPutID;

extern jclass    intClass;
extern jmethodID intConID;
extern jmethodID intValueID;

extern jclass    listClass;
extern jmethodID listGetID;
extern jmethodID listSizeID;
extern jmethodID listConID;
extern jmethodID listSizeConID;
extern jmethodID listAddID;
extern jmethodID listRemoveID;
extern jmethodID listAddIndexID;

extern jclass    propClass;
extern jmethodID propConID;
extern jmethodID propPutID;
extern jmethodID propGetPropertyID;
extern jmethodID propGetID;
extern jmethodID containsKeyID;

extern jclass gClLogger;
extern jmethodID gMtdFine;
extern jclass gClWinAccessProvider;
extern jclass LogClass;
extern jmethodID LogID;
