#include "VMDataCollector.h"

//int add(int a, int b);
int generateSingleHashandBlockbyBlockforIncrementalDisk(VMDataCollector* vmd,wchar_t* destFileDir, wchar_t* sourceFilePath, wchar_t* destFilePath, wchar_t* backupIdentifier,  wchar_t* hashType, wchar_t* fileType,bool isEncrypted,wchar_t* encryptPassword);
int generateSingleHashandBlockbyBlockHashforDisk(VMDataCollector* vmd,wchar_t* destFileDir, wchar_t* sourceFilePath, wchar_t* destFilePath, wchar_t* backupIdentifier,  bool isEncrypted, wchar_t* encryptPassword, wchar_t* hashType, wchar_t* fileType);
int generateHashforFile(VMDataCollector* vmd,wchar_t* sourceFilePath, wchar_t* destFilePath, wchar_t* backupIdentifier,  wchar_t* hashType, wchar_t* isSingleHash, wchar_t* mode, wchar_t* fileType);
int generateHashForFilesInDirectory(VMDataCollector* vmd,jstring backupIdentifier,jstring directoryPath, bool isFullBackup, wstring hashType, bool isEncrypted, jstring password);
int compareHashValues(VMDataCollector* vmd,wchar_t* backupIdentifier,jlong vmid,bool isvmdkSecured, wchar_t* repoPath, wchar_t* fileNameStr, wchar_t* backuphashFile, wchar_t* healthcheckhashFile, wchar_t* backupType, wchar_t* backupmetadata);
int checkHash(VMDataCollector* vmd,wchar_t* destFilesDir,wchar_t* scheduleName, wchar_t* vmName, wchar_t* backupIdentifier,jlong vmid, wchar_t* backupType, bool isEncrypted, LPWSTR encryptPassword);
BOOL listFiles(VMDataCollector* vmd,wstring directoryPath, wstring mask, map<wstring, BOOL> *filesList);






