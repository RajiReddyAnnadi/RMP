#include "com_manageengine_rmp_virtual_VMNativeHandler.h"
#include "util/vixDiskLib.h"
#include "util/zlib.h"
#include <windows.h>
//#include <time.h>
#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include<stdio.h>
#include<conio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <io.h>
#include<Shlwapi.h>
#include<queue>
#include<thread>
#include <atomic>
#include<map>
#include<string>
#include<string.h>
#include<wchar.h>

using namespace::std;

#define VIXDISKLIB_VERSION_MAJOR 5
#define VIXDISKLIB_VERSION_MINOR 0

#define ENCRYPT_BLOCK_SIZE 16
#define KEYLENGTH  0x00800000
#define ENCRYPT_ALGORITHM CALG_AES_128

#define BUFSIZE 1024*1024*16
#define BUFSIZETOHASH 1024*1024*16
#define MD5LEN 16
// Default buffer size (in sectors) for read/write benchmarks
#define DEFAULT_BUFSIZE 128

#define SPAN 10485760L       /* desired distance between access points */
#define WINSIZE 32768U      /* sliding window size */
#define CHUNK 65536       /* file input buffer size */
//#define INDEXCHUNK 4096         /* file input buffer size */

// Print updated statistics for read/write benchmarks roughly every
// BUFS_PER_STAT sectors (current value is 64MBytes worth of data)
#define BUFS_PER_STAT (64 * 1024)

extern jmethodID jMtdGetHashtable;
extern jclass listClass;
extern jmethodID listSizeID;
extern jmethodID listGetID;

extern jclass ProgressClass;
extern jmethodID setProgressMethodID;
extern jmethodID setMaximumMethodID;
extern jclass VMNativeHandlerClass;
extern jmethodID releaseLockID;
extern jmethodID getLockID;

extern jmethodID loggerMethodId;
extern jclass loggerClass;

extern jclass jClHashtable;

extern jclass    propClass ;
extern jmethodID propConID ;
extern jmethodID propPutID ;
extern jmethodID propGetPropertyID ;
extern jmethodID propGetID ;
extern jmethodID containsKeyID ;

extern jclass nativeExceptionClass;
extern jfieldID exceptionOccuredFieldID;
extern jfieldID lineNumberID;
extern jfieldID errorCodeID;
extern jfieldID errorMessageID;
extern jfieldID moduleNameID;
extern jfieldID APINameID;

extern jclass diskReadWriteControlClass;
extern jmethodID proceedCheckID;


int extractDecrypt(FILE *in, struct access *index, __int64 offset, unsigned char *buf, int len, LPTSTR secretKey);
int extract(FILE *in, struct access *index, __int64 offset, unsigned char *buf, int len);

void LogFunc(const char *fmt, va_list args);
void WarnFunc(const char *fmt, va_list args);
void PanicFunc(const char *fmt, va_list args);

struct AppGlobals {
    int command;
    VixDiskLibAdapterType adapterType;
    char *transportModes;
    char *diskPath;
    char *parentPath;
    char *metaKey;
    char *metaVal;
    int filler;
    int operation;
    unsigned mbSize;
    VixDiskLibSectorType numSectors;
    VixDiskLibSectorType startSector;
    VixDiskLibSectorType bufSize;
    uint32 openFlags;
    unsigned numThreads;
    Bool success;
    Bool isRemote;
    Bool isBackup;
    char *host;
    char *userName;
    char *password;
    char *thumbPrint;
	char *originalPath;
    char *vmdkPath;
	wchar_t* wvmdkPath;
	wchar_t* woriginalPath;
	char *metaPath;
	wchar_t* wmetaPath;
    int port;
    char *srcPath;
    VixDiskLibConnection connection;
    char *vmxSpec;
    char *cfgFile;
    char *libdir;
    char *ssMoRef;
    int repair;
};

/* access point entry */
struct point {
	__int64 out;          /* corresponding offset in uncompressed data */
	__int64 in;           /* offset in input file of first full byte */
	int bits;           /* number of bits (1-7) from byte at in - 1, or 0 */
	unsigned char window[WINSIZE];  /* preceding 32K of uncompressed data */
};

/* access point list */
struct access {
	int have;           /* number of list entries filled in */
	int size;           /* number of list entries allocated */
	struct point *list; /* allocated list */
};

struct FileStructure {
	uint64 filetype;
	boolean isencrypted;
	LPWSTR encryptionkey;
	FILE* filepointer;
	gzFile gzfilepointer;
	struct access* index;
};

struct StoreDetails {
	LPWSTR storeLPPath;
	LPWSTR storeUserName;
	LPWSTR storePwd;
        LPWSTR secretKey;
        bool isEncrypted;
};
class BufferChunk
{
    public:
    uint8 *buff;
    BufferChunk(int size);
    ~BufferChunk() ;
};

class Synchronizer
{
    public :
    std::atomic<bool> isReadCompleted;
    std::atomic<bool> isExceptionGenerated;
    CRITICAL_SECTION shared_buffer_lock;
};

class VMDataCollector {


public:
    VMDataCollector(JNIEnv * env, jthrowable exceptionObject);
    int setStoreDetails(jobject storeDetails);
    void initializeGlobals(jobject serverDetails, jstring diskPath, jobject storeDetails, char* moduleName);
    int ParseArguments(jobject serverDetails, jstring diskPath, jobject storeDetails);
    bool connectLocation();
    void disconnectLocation();
    void replace(char * path, char source, char target);
    void wreplace(wchar_t * path, wchar_t source, wchar_t target);
    void disconnectExit();
    void DoDumpMetadata();
    void fileCloser(gzFile fileHandle);
	int readFromDisk(queue<BufferChunk*> *que, Synchronizer* s, jobject progressObject, jobject diskReadWriteControl, VixDiskLibHandle diskHandle);
	int writeToDisk(queue<BufferChunk*> *que, Synchronizer* s, jobject progressObject, VixDiskLibHandle diskHandle);
	int writeToRepository(queue<BufferChunk*> *que, Synchronizer* s, jobject progressObject);
    void DoRWBench(bool read, char * moduleName, jobject progressObject, jobject diskReadWriteControl);
    void DoWriteMetadata();
    void DoIncReadWrite(jobject incBackupDetails, bool isRead, char* moduleName, jobject progressObject,jobject diskReadWriteControl);
	void DoIncReadAndWrite(jobject incBackupDetails,VMDataCollector* vmdDestination,VixDiskLibHandle diskHandleSource,VixDiskLibHandle diskHandleDestination, char* moduleName, jobject progressObject, jobject diskReadWriteControl);
	void DoDiffMaker(jobject incBackupDetails,jobject ProgressBar,char* moduleName, jobject diskReadWriteControl);
    int DoSyntheticFullBackup(jobject incBackupDetails,jobject filelist, char* moduleName, jobject progressObject, jobject diskReadWriteControl);
	int doEfficientRestore(jstring diskPath, jstring restoreType, jobject finalDisksInfo, jobject finalIncrementalsInfo, jobject progressObject, char* moduleName);
    int DoSyntheticMigration(VixDiskLibHandle targetDisk,VixDiskLibHandle srcDisk, jobject incBackupDetails, jobject filelist, char *moduleName, jobject progressObject, jobject diskReadWriteControl);
	boolean impersonate(LPTSTR userName, LPTSTR domainName, LPTSTR password);
	boolean RevertImpersonate();
	boolean readFromFile(gzFile &fileToBeReadFrom, uint64 fileseeklength, uint64 lengthToBeRead, gzFile &ofile, uint8 *buf);
    boolean readFromFile(gzFile &fileToBeReadFrom, uint64 fileseeklength, uint64 lengthToBeRead, VixDiskLibHandle diskHandle, long long currentOutputOffset, uint8 *buf);
	boolean readFromEncryptedFile(FILE &fileToBeReadFrom, struct access &index, LPTSTR secretKey, uint64 fileseeklength, uint64 lengthToBeRead, gzFile &ofile, uint8 *buf);
    boolean readFromEncryptedFile(FILE &fileToBeReadFrom, struct access &index, LPTSTR secretKey, uint64 fileseeklength, uint64 lengthToBeRead, VixDiskLibHandle diskHandle, long long currentOutputOffset, uint8 *buf);
	boolean readFromVM(VixDiskLibHandle diskHandle, uint64 offset, uint64 lengthToBeRead, gzFile &ofile, uint8 *buf);
    boolean readFromVM(VixDiskLibHandle srcdiskHandle, uint64 offset, uint64 lengthToBeRead, VixDiskLibHandle targetdiskHandle, long long currentOutputOffset, uint8 *buf);
    void getLock();
    void releaseLock();
    void generateException(int lineNumber, char* moduleName, string APIName, int errorCode, string errorMessage);
    void log(JNIEnv *env, int level,const char* message, ...);
    bool protect(wchar_t *filePath, LPTSTR pszPassword, bool isEncrypt);
    bool unmountDrive();
    int RestoreDirectoryTree(JNIEnv *env, wstring source, wstring destination);
    int RestoreUncompressedFile(JNIEnv *env, wstring source, wstring destination);
    int indexCreation(wstring backupFile, boolean isEncrypted, LPWSTR secretKey);
    struct access *getIndexforFile(struct access *index, wchar_t* indexFile);
    void printJNI(jstring myStringArgs);
    JNIEnv * env;
    jthrowable exceptionObject;

    JavaVM* jvm;
    struct AppGlobals appGlobals;
    struct StoreDetails storeDetails;
};
