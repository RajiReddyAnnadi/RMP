// This is the main DLL file.
//#define _LARGEFILE64_SOURCE

#define ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS 1
#define ERROR_COULD_NOT_CREATE_BACKUP_FILE 2
#define ERROR_COULD_NOT_READ_FROM_FILE 3
#define ERROR_COULD_NOT_READ_FROM_VM 4
#define ERROR_COULD_NOT_READ_FROM_FILE_NOT_STAR_BACKUP 5
#define ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_GZDOPEN 6
#define ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_FDOPEN 7
#define ERROR_COULD_NOT_ALLOCATE_MEMORY 7
#define OPERATION_ABORTED 8
#define ERROR_COULD_NOT_LOAD_INDEX 9


#include "jni/VMDataCollector.h"
#include <Windows.h>
#include <WinIoCtl.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <tchar.h>
#include <string>
#include <map>
#include <vector>
#include <Shlwapi.h>
#include <shlobj.h>
#include <io.h>
#include <fcntl.h>

jmethodID jMtdGetHashtable;
jclass listClass;
jmethodID listSizeID;
jmethodID listGetID;

jclass ProgressClass;
jmethodID setProgressMethodID;
jmethodID setMaximumMethodID;
jclass VMNativeHandlerClass;
jmethodID releaseLockID;
jmethodID getLockID;

jmethodID loggerMethodId;
jclass loggerClass;

jclass jClHashtable;

jclass    propClass = 0;
jmethodID propConID = 0;
jmethodID propPutID = 0;
jmethodID propGetPropertyID = 0;
jmethodID propGetID = 0;
jmethodID containsKeyID = 0;

jclass nativeExceptionClass;
jfieldID exceptionOccuredFieldID;
jfieldID lineNumberID;
jfieldID errorCodeID;
jfieldID errorMessageID;
jfieldID moduleNameID;
jfieldID APINameID;

jclass diskReadWriteControlClass;
jmethodID proceedCheckID;


uint32_t read_uint32(gzFile gz)
{
	uint32_t v;
	gzread(gz, &v, sizeof(v));
	return v;
}

//build index

/* Deallocate an index built by build_index() */
void free_index(struct access *index) {
	if (index != NULL) {
		free(index->list);
		free(index);
	}
}

/* Add an entry to the access point list.  If out of memory, deallocate the
existing list and return NULL. */
struct access *addpoint(struct access *index, int bits,
	__int64 in, __int64 out, unsigned left, unsigned char *window) {
	struct point *next;

	/* if list is empty, create it (start with eight points) */
	if (index == NULL) {
		index = (struct access*) malloc(sizeof(struct access));
		if (index == NULL) return NULL;
		index->list = (point*)malloc(sizeof(struct point) << 3);
		if (index->list == NULL) {
			free(index);
			return NULL;
		}
		index->size = 8;
		index->have = 0;
	}/* if list is full, make it bigger */
	else if (index->have == index->size) {
		index->size <<= 1;
		next = (point*)realloc(index->list, sizeof(struct point) * index->size);
		if (next == NULL) {
			free_index(index);
			return NULL;
		}
		index->list = next;
	}

	/* fill in entry and increment how many we have */
	next = index->list + index->have;
	next->bits = bits;
	next->in = in;
	next->out = out;
	if (left)
		memcpy(next->window, window + WINSIZE - left, left);
	if (left < WINSIZE)
		memcpy(next->window + left, window, WINSIZE - left);
	index->have++;

	/* return list, possibly reallocated */
	return index;
}

/* Make one entire pass through the compressed stream and build an index, with
access points about every span bytes of uncompressed output -- span is
chosen to balance the speed of random access against the memory requirements
of the list, about 32K bytes per access point.  Note that data after the end
of the first zlib or gzip stream in the file is ignored.  build_index()
returns the number of access points on success (>= 1), Z_MEM_ERROR for out
of memory, Z_DATA_ERROR for an error in the input file, or Z_ERRNO for a
file read error.  On success, *built points to the resulting index. */
int build_index(FILE *in, __int64 span, struct access **built) {
	int ret;
	__int64 totin, totout; /* our own total counters to avoid 4GB limit */
	__int64 last; /* totout value of last access point */
	struct access *index; /* access points being generated */
	z_stream strm;
	unsigned char input[CHUNK];
	unsigned char window[WINSIZE];

	/* initialize inflate */
	strm.zalloc = Z_NULL;
	strm.zfree = Z_NULL;
	strm.opaque = Z_NULL;
	strm.avail_in = 0;
	strm.next_in = Z_NULL;
	ret = inflateInit2(&strm, 47); /* automatic zlib or gzip decoding */
	if (ret != Z_OK)
		return ret;

	/* inflate the input, maintain a sliding window, and build an index -- this
	also validates the integrity of the compressed data using the check
	information at the end of the gzip or zlib stream */
	totin = totout = last = 0;
	index = NULL; /* will be allocated by first addpoint() */
	strm.avail_out = 0;
	do {
		/* get some compressed data from input file */
		strm.avail_in = fread(input, 1, CHUNK, in);
		if (ferror(in)) {
			ret = Z_ERRNO;
			goto build_index_error;
		}
		if (strm.avail_in == 0) {
			ret = Z_DATA_ERROR;
			goto build_index_error;
		}
		strm.next_in = input;

		/* process all of that, or until end of stream */
		do {
			/* reset sliding window if necessary */
			if (strm.avail_out == 0) {
				strm.avail_out = WINSIZE;
				strm.next_out = window;
			}

			/* inflate until out of input, output, or at end of block --
			update the total input and output counters */
			totin += strm.avail_in;
			totout += strm.avail_out;
			ret = inflate(&strm, Z_BLOCK); /* return at end of block */
			totin -= strm.avail_in;
			totout -= strm.avail_out;
			if (ret == Z_NEED_DICT)
				ret = Z_DATA_ERROR;
			if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
				goto build_index_error;
			if (ret == Z_STREAM_END)
				break;

			/* if at end of block, consider adding an index entry (note that if
			data_type indicates an end-of-block, then all of the
			uncompressed data from that block has been delivered, and none
			of the compressed data after that block has been consumed,
			except for up to seven bits) -- the totout == 0 provides an
			entry point after the zlib or gzip header, and assures that the
			index always has at least one access point; we avoid creating an
			access point after the last block by checking bit 6 of data_type
			*/
			if ((strm.data_type & 128) && !(strm.data_type & 64) &&
				(totout == 0 || totout - last > span)) {
				index = addpoint(index, strm.data_type & 7, totin,
					totout, strm.avail_out, window);
				if (index == NULL) {
					ret = Z_MEM_ERROR;
					goto build_index_error;
				}
				last = totout;
			}
		} while (strm.avail_in != 0);
	} while (ret != Z_STREAM_END);

	/* clean up and return index (release unused entries in list) */
	(void)inflateEnd(&strm);
	index->list = (point*)realloc(index->list, sizeof(struct point) * index->have);
	index->size = index->have;
	*built = index;
	return index->size;

	/* return error */
build_index_error:
	(void)inflateEnd(&strm);
	if (index != NULL)
		free_index(index);
	return ret;
}

int write_uint32(gzFile gz, uint32_t v) {
	return gzwrite(gz, &v, sizeof(v));
}


unsigned decryptBuffer(HCRYPTKEY hKey, PBYTE pbBuffer, DWORD dwCount, bool fEOF)
{
	if (pbBuffer != NULL) {
		if (CryptDecrypt(hKey, NULL, fEOF, 0, pbBuffer, &dwCount)) {
			return dwCount;//return encrypted buffer
		}
		else {
			DWORD dw = GetLastError();
		}
	}
	//	else {
	//		cout << "\n pbBuffer null" << endl;
	//	}
}

HCRYPTKEY generateHashKey(LPTSTR pszPassword) {
	HCRYPTPROV hCryptProv = NULL;
	HCRYPTKEY hKey = NULL;
	HCRYPTHASH hHash = NULL;
	bool CryptAcquireContextStatus = false;
	if (CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, 0)) {
		CryptAcquireContextStatus = true;
	}
	else {
		//cout << "\n CryptAcquireContext failed" << endl;
		if (CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, CRYPT_NEWKEYSET)) {
			CryptAcquireContextStatus = true;
		}
		else {
			return -1;
		}
	}
	if (CryptAcquireContextStatus) {
		if (CryptCreateHash(hCryptProv, CALG_MD5, 0, 0, &hHash)) {
			if (CryptHashData(hHash, (BYTE *)pszPassword, lstrlen(pszPassword), 0)) {
				if (CryptDeriveKey(hCryptProv, ENCRYPT_ALGORITHM, hHash, KEYLENGTH, &hKey)) {
					return hKey;
				}
				else {
					//cout << "\n CryptDeriveKey failed" << endl;
					return -1;
				}
			}
			else {
				//cout << "\n CryptHashData failed" << endl;
				return -1;
			}
		}
		else {
			//cout << "\n CryptCreateHash failed" << endl;
			return -1;
		}
	}
}


int build_indexForEncryptedFile(FILE *in, __int64 span, struct access **built, LPTSTR pszPassword)
{
	HCRYPTKEY hKey = generateHashKey(pszPassword);
	int ret;
	__int64 totin, totout;        /* our own total counters to avoid 4GB limit */
	__int64 last;                 /* totout value of last access point */
	struct access *index;       /* access points being generated */
	z_stream strm;
	unsigned char input[CHUNK];
	unsigned char window[WINSIZE];

	/* initialize inflate */
	strm.zalloc = Z_NULL;
	strm.zfree = Z_NULL;
	strm.opaque = Z_NULL;
	strm.avail_in = 0;
	strm.next_in = Z_NULL;
	ret = inflateInit2(&strm, 47);      /* automatic zlib or gzip decoding */
	if (ret != Z_OK)
		return ret;

	/* inflate the input, maintain a sliding window, and build an index -- this
	also validates the integrity of the compressed data using the check
	information at the end of the gzip or zlib stream */
	totin = totout = last = 0;
	index = NULL;               /* will be allocated by first addpoint() */
	strm.avail_out = 0;
	do {
		//printf("in build_index\n");
		/* get some compressed data from input file */
		strm.avail_in = fread(input, 1, CHUNK, in);
		if (ferror(in)) {
			ret = Z_ERRNO;
			goto build_index_error;
		}
		if (strm.avail_in == 0) {
			ret = Z_DATA_ERROR;
			goto build_index_error;
		}

		//decrypt logic
		DWORD dwBlockLen;
		DWORD dwBufferLen;
		dwBlockLen = strm.avail_in;
		dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
		bool fEOF = FALSE;
		if (dwBlockLen < CHUNK) {
			fEOF = TRUE;
		}
		strm.avail_in = decryptBuffer(hKey, input, dwBlockLen, fEOF);

		strm.next_in = input;

		/* process all of that, or until end of stream */
		do {
			/* reset sliding window if necessary */
			if (strm.avail_out == 0) {
				strm.avail_out = WINSIZE;
				strm.next_out = window;
			}

			/* inflate until out of input, output, or at end of block --
			update the total input and output counters */
			totin += strm.avail_in;
			totout += strm.avail_out;
			ret = inflate(&strm, Z_BLOCK);      /* return at end of block */
			totin -= strm.avail_in;
			totout -= strm.avail_out;
			if (ret == Z_NEED_DICT)
				ret = Z_DATA_ERROR;
			if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
				goto build_index_error;
			if (ret == Z_STREAM_END)
				break;

			/* if at end of block, consider adding an index entry (note that if
			data_type indicates an end-of-block, then all of the
			uncompressed data from that block has been delivered, and none
			of the compressed data after that block has been consumed,
			except for up to seven bits) -- the totout == 0 provides an
			entry point after the zlib or gzip header, and assures that the
			index always has at least one access point; we avoid creating an
			access point after the last block by checking bit 6 of data_type
			*/
			if ((strm.data_type & 128) && !(strm.data_type & 64) &&
				(totout == 0 || totout - last > span)) {
				index = addpoint(index, strm.data_type & 7, totin,
					totout, strm.avail_out, window);
				if (index == NULL) {
					ret = Z_MEM_ERROR;
					goto build_index_error;
				}
				last = totout;
			}
		} while (strm.avail_in != 0);
	} while (ret != Z_STREAM_END);

	/* clean up and return index (release unused entries in list) */
	(void)inflateEnd(&strm);
	index->list = (point*)realloc(index->list, sizeof(struct point) * index->have);
	index->size = index->have;
	*built = index;
	return index->size;

	/* return error */
build_index_error:
	(void)inflateEnd(&strm);
	if (index != NULL)
		free_index(index);
	return ret;
}


/* Demonstrate the use of build_index() and extract() by processing the file
provided on the command line, and the extracting 16K from about 2/3rds of
the way through the uncompressed output, and writing that to stdout. */
int VMDataCollector::indexCreation(wstring backupFile, boolean isEncrypted, LPWSTR secretKey) {
	size_t pos = backupFile.rfind(L".");
	wstring indexName = backupFile.substr(0, pos) + L".idx";
	string fileName(backupFile.begin(), backupFile.end());
	string indexFile(indexName.begin(), indexName.end());
	int len;
	__int64 offset;
	FILE *in;
	struct access *index = NULL;
	unsigned char buf[CHUNK];

	//in = fopen(fileName.c_str(), "rb");
        int fd = _wopen(backupFile.c_str(), _O_RDONLY | _O_BINARY);
        if (fd == -1) {
            int errsv = errno;
            this->log(this->env, 1, "index file: could not open for reading : %d\n",errsv);
            return 1;
        }
        else {
            this->log(this->env, 1, "index file : fd ok\n");
        }
        in = _fdopen(fd, "rb");
	if (in == NULL) {
		this->log(this->env, 1, "zran: could not open %ws for reading\n", backupFile.c_str());
		return 1;
	}

	/* build index */
	if (isEncrypted) {
        len = build_indexForEncryptedFile(in, SPAN, &index, secretKey);
    }
    else {
        len = build_index(in, SPAN, &index);
    }

	if (len < 0) {
		fclose(in);
		switch (len) {
		case Z_MEM_ERROR:
			this->log(this->env, 1, "zran: out of memory\n");
			break;
		case Z_DATA_ERROR:
			this->log(this->env, 1, "zran: compressed data error in %ws\n", backupFile.c_str());
			break;
		case Z_ERRNO:
			this->log(this->env, 1, "zran: read error on %ws\n", backupFile.c_str());
			break;
		default:
			this->log(this->env, 1, "zran: error %d while building index\n", len);
		}
		return 1;
	}
	this->log(this->env, 1, "zran: built index with %d access points\n", len);
	fclose(in);

	int fileDescriptor = _wopen(indexName.c_str(),  _O_CREAT | _O_WRONLY | _O_BINARY, _S_IWRITE);
        if (fileDescriptor == -1) {
                int errsv = errno;
                this->log(this->env, 1, "zran: fileDescriptor error : %d\n", errsv);
        }
        else {
                this->log(this->env, 1, "wopen done fileDescriptor");
        }
        gzFile gz = gzdopen(fileDescriptor, "wb");
	//gzFile gz = gzopen(indexFile.c_str(), "wb");
	if (gz == NULL) {
		this->log(this->env, 1, "gz null\n");
	}

	// Write a header.
	write_uint32(gz, (uint32_t)index->have);

	// Write out entry points.
	for (int i = 0; i < index->have; ++i) {
		gzwrite(gz, &index->list[i].out, sizeof(__int64));
		gzwrite(gz, &index->list[i].in, sizeof(__int64));
		gzwrite(gz, &index->list[i].bits, sizeof(int));
		gzwrite(gz, index->list[i].window, WINSIZE);
	}

	if (gz != NULL) {
		gzclose(gz);
	}
	if (index != NULL) {
		free_index(index);
	}
	return 0;
}
//build index ends

BufferChunk::BufferChunk(int size) {
	buff = new uint8[size];
}

BufferChunk::~BufferChunk() {
	delete[] buff;
}

void VMDataCollector::log(JNIEnv *env, int level, const char* message, ...) {
	va_list args;
	int len;
	jint jlevel = (jint)level;
	char * buffer;
	va_start(args, message);
	len = _vscprintf(message, args) + 1;
	buffer = (char*)malloc(len * sizeof(char));
	vsprintf(buffer, message, args);
	jstring jsMessage = env->NewStringUTF(buffer);
	env->CallStaticVoidMethod(loggerClass, loggerMethodId, jlevel, jsMessage);
	free(buffer);
}
//usage
//log(env,level,message); "level" : 1 - INFO, 2 - WARNING, 3 - FINE, 4 - SEVERE
//logger ends

void LogFunc(const char *fmt, va_list args) {
	//printf("Log: ");
	//vprintf(fmt, args);
}

void WarnFunc(const char *fmt, va_list args) {
	//printf("Warning: ");
	//vprintf(fmt, args);
}

void PanicFunc(const char *fmt, va_list args) {
	//printf("Panic: ");
	//vprintf(fmt, args);
	exit(10);
}

using std::string;
using std::vector;
using namespace std;

#define THROW_ERROR(vixError) \
throw VixDiskLibErrWrapper((vixError), __FILE__, __LINE__,__FUNCTION__)

#define CHECK_AND_THROW(vixError)                                    \
do {                                                              \
    if (VIX_FAILED((vixError))) {                                  \
        throw VixDiskLibErrWrapper((vixError), __FILE__, __LINE__,__FUNCTION__); \
    }                                                              \
} while (0)

class VixDiskLibErrWrapper {
public:

	explicit VixDiskLibErrWrapper(VixError errCode, const char* file, int line, const char* functionName)
		:
		_errCode(errCode),
		_file(file),
		_line(line),
		_functionName(functionName) {
		char* msg = VixDiskLib_GetErrorText(errCode, NULL);
		_desc = msg;
		VixDiskLib_FreeErrorText(msg);
	}

	VixDiskLibErrWrapper(const char* description, const char* file, int line, const char* functionName)
		:
		_errCode(VIX_E_FAIL),
		_desc(description),
		_file(file),
		_line(line),
		_functionName(functionName) {
	}

	string Description() const {
		return _desc;
	}

	VixError ErrorCode() const {
		return _errCode;
	}

	string File() const {
		return _file;
	}

	string FunctionName() const {
		return _functionName;
	}

	int Line() const {
		return _line;
	}

private:
	VixError _errCode;
	string _desc;
	string _file;
	string _functionName;
	int _line;
};

class VixDisk {
	VMDataCollector* vmObject;

public:

	VixDiskLibHandle Handle() {
		return _handle;
	}

	VixDisk(VixDiskLibConnection connection, char *path, uint32 flags, VMDataCollector* vmObj, int line, char* moduleName) {
		_handle = NULL;
		this->vmObject = vmObj;
		vmObject->getLock();
		vmObj->log(vmObj->env, 1, "VixDiskLib_Open starting %s", path);
		VixError vixError = VixDiskLib_Open(connection, path, flags, &_handle);
		vmObj->log(vmObj->env, 1, "VixDiskLib_Open done %s", path);
		vmObject->releaseLock();
		if (vixError != VIX_OK) {
			vmObj->generateException(line, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
		}
		CHECK_AND_THROW(vixError);
	}

	//	VixDisk(VixDiskLibConnection connection, char *path, uint32 flags, VMDataCollector* vmObj, int line, char* moduleName, JNIEnv *myNewEnv) {
	//		_handle = NULL;
	//		this->vmObject = vmObj;
	//		myNewEnv->CallStaticVoidMethod(VMNativeHandlerClass, getLockID);
	//		VixError vixError = VixDiskLib_Open(connection, path, flags, &_handle);
	//		myNewEnv->CallStaticVoidMethod(VMNativeHandlerClass, releaseLockID);
	//		if (vixError != VIX_OK) {
	//			throw "VixError while VixDiskLib_Open";
	//		}
	//	}

	~VixDisk() {
		vmObject->getLock();
		if (_handle) {

			VixDiskLib_Close(_handle);
		}
		vmObject->releaseLock();
		vmObject = NULL;
		_handle = NULL;
	}

private:
	VixDiskLibHandle _handle;
};

static bool bVixInit = false;

bool initVixDix(VMDataCollector *vmd) {
	vmd->log(vmd->env, 1, "initVixDix() started");

	try {
		VixError vixError;
		vixError = VixDiskLib_Init(VIXDISKLIB_VERSION_MAJOR,
			VIXDISKLIB_VERSION_MINOR,
			&LogFunc, &WarnFunc, &PanicFunc, // Log, warn, panic
			"..\\lib\\native\\vm"); //Need to give the libdir

		if (vixError != VIX_OK) {
			vmd->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_vixDiskInit", __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
		}

		CHECK_AND_THROW(vixError);

		bVixInit = true;
		vmd->log(vmd->env, 1, "VixDiskInit completed successfully");
	}
	catch (const VixDiskLibErrWrapper& e) {
		vmd->log(vmd->env, 1, "initVixDix() failed");
		vmd->generateException(e.Line(), "Java_com_manageengine_rmp_virtual_VMNativeHandler_vixDiskInit", e.FunctionName(), e.ErrorCode(), e.Description());
	}

	return bVixInit;
}

void initializeStaticVariables(JNIEnv * env) {

	//For Progress
	jclass ProgressClassRef = (jclass)env->FindClass("com/manageengine/rmp/virtual/progressbar/ProgressBar");
	ProgressClass = (jclass)env->NewGlobalRef(ProgressClassRef);
	setProgressMethodID = env->GetMethodID(ProgressClass, "setProgress", "(J)V");
	setMaximumMethodID = env->GetMethodID(ProgressClass, "setMaximum", "(J)V");
	//For Progress

	//For Locking
	jclass VMNativeHandlerClassRef = (jclass)env->FindClass("com/manageengine/rmp/virtual/VMNativeHandler");
	VMNativeHandlerClass = (jclass)env->NewGlobalRef(VMNativeHandlerClassRef);
	getLockID = env->GetStaticMethodID(VMNativeHandlerClass, "getLock", "()V");
	releaseLockID = env->GetStaticMethodID(VMNativeHandlerClass, "releaseLock", "()V");
	//For Locking

	//for logger initialization
	jclass loggerClassRef = env->FindClass("com/manageengine/rmp/jni/VirtualNativeLogger");
	loggerClass = (jclass)env->NewGlobalRef(loggerClassRef);
	loggerMethodId = env->GetStaticMethodID(loggerClass, "log", "(ILjava/lang/String;)V");
	//for logger initialization ends

	//for exception reporting
	jclass nativeExceptionClassRef = env->FindClass("com/manageengine/rmp/virtual/NativeException");
	nativeExceptionClass = (jclass)env->NewGlobalRef(nativeExceptionClassRef);
	exceptionOccuredFieldID = env->GetFieldID(nativeExceptionClass, "exceptionOccured", "Z");
	lineNumberID = env->GetFieldID(nativeExceptionClass, "lineNumber", "I");
	errorCodeID = env->GetFieldID(nativeExceptionClass, "errorCode", "I");
	errorMessageID = env->GetFieldID(nativeExceptionClass, "message", "Ljava/lang/String;");
	moduleNameID = env->GetFieldID(nativeExceptionClass, "moduleName", "Ljava/lang/String;");
	APINameID = env->GetFieldID(nativeExceptionClass, "APIName", "Ljava/lang/String;");
	//for exception reporting

	//for DiskReadWiteControlClass
	jclass diskReadWiteControlClassRef = env->FindClass("com/manageengine/rmp/virtual/DiskReadWriteControl");
	diskReadWriteControlClass = (jclass)env->NewGlobalRef(diskReadWiteControlClassRef);
	proceedCheckID = env->GetMethodID(diskReadWriteControlClass, "proceedCheck", "()Z");
	//for DiskReadWiteControlClass


	//for HashClass
	jclass LRefHashClass = env->FindClass("java/util/Hashtable");
	jClHashtable = (jclass)env->NewGlobalRef(LRefHashClass);
	jMtdGetHashtable = env->GetMethodID(jClHashtable, "get", "(Ljava/lang/Object;)Ljava/lang/Object;");
	//for HashClass


	//for ListClass
	jclass listClassRef = (jclass)env->FindClass("java/util/ArrayList");
	listClass = (jclass)env->NewGlobalRef(listClassRef);
	listSizeID = env->GetMethodID(listClass, "size", "()I");
	listGetID = env->GetMethodID(listClass, "get", "(I)Ljava/lang/Object;");
	//for ListClass

	//for properties
	jclass LRefpropClass = env->FindClass("java/util/Properties");
	propClass = (jclass)env->NewGlobalRef(LRefpropClass);
	propConID = env->GetMethodID(propClass, "<init>", "()V");
	propPutID = env->GetMethodID(propClass, "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
	propGetPropertyID = env->GetMethodID(propClass, "getProperty", "(Ljava/lang/String;)Ljava/lang/String;");
	propGetID = env->GetMethodID(propClass, "get", "(Ljava/lang/Object;)Ljava/lang/Object;");
	containsKeyID = env->GetMethodID(propClass, "containsKey", "(Ljava/lang/Object;)Z");

}

unsigned encryptBuffer(HCRYPTKEY hKey, PBYTE pbBuffer, DWORD dwCount, bool fEOF)
{

	//to set the isEncrypted value to true if all the above if cases are successfull
	DWORD dwBlockLen;
	DWORD dwBufferLen;

	//dwBlockLen = 1000 - 1000 % ENCRYPT_BLOCK_SIZE;

	//dwBlockLen = CHUNK;
	dwBlockLen = dwCount;
	dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
	//if (pbBuffer = (BYTE *)malloc(dwBufferLen)) {
	if (pbBuffer != NULL) {

		if (CryptEncrypt(hKey, NULL, fEOF, 0, pbBuffer, &dwCount, dwBufferLen)) {
			return dwCount;//return encrypted buffer
		}
		else {
			DWORD dw = GetLastError();
		}
	}
	//}

}

int extract(FILE *in, struct access *index, __int64 offset, unsigned char *buf, int len)
{
    int ret, skip;
    z_stream strm;
    struct point *here;
    unsigned char input[CHUNK];
    unsigned char discard[WINSIZE];

    //clock_t t1, t2;
    /* proceed only if something reasonable to do */
    if (len < 0)
        return 0;

    /* find where in stream to start */
    here = index->list;
    ret = index->have;

    //t1 = clock();
    while (--ret && here[1].out <= offset)
    {
        //fprintf(outputFile, "in while\n");
        here++;
    }

    //t2 = clock();
    //long timediff = ((long)t2 - (long)t1);
    //long seconds = timediff;
    //fprintf(outputFile, "while Time diff %ld", seconds);
    //cout << "while Time diff " << seconds << endl;

    /* initialize file and inflate state to start there */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;

    ret = inflateInit2(&strm, -15); /* raw inflate */

    if (ret != Z_OK)
        return ret;
    long long seekValue = here->in - (here->bits ? 1 : 0);

    ret = _fseeki64(in, seekValue, SEEK_SET);

    if (ret == -1)
        goto extract_ret;

    if (here->bits)
    {
        ret = getc(in);
        if (ret == -1)
        {
            ret = ferror(in) ? Z_ERRNO : Z_DATA_ERROR;
            goto extract_ret;
        }
        (void)inflatePrime(&strm, here->bits, ret >> (8 - here->bits));
    }

    (void)inflateSetDictionary(&strm, here->window, WINSIZE);

    /* skip uncompressed bytes until offset reached, then satisfy request */
    offset -= here->out;
    strm.avail_in = 0;
    skip = 1; /* while skipping to offset */
    do
    {
        /* define where to put uncompressed data, and how much */
        if (offset == 0 && skip)
        { /* at offset now */
            strm.avail_out = len;
            strm.next_out = buf;
            skip = 0; /* only do this once */
        }
        if (offset > WINSIZE)
        { /* skip WINSIZE bytes */
            strm.avail_out = WINSIZE;
            strm.next_out = discard;
            offset -= WINSIZE;
        }
        else if (offset != 0)
        { /* last skip */
            strm.avail_out = (unsigned)offset;
            strm.next_out = discard;
            offset = 0;
        }

        /* uncompress until avail_out filled, or end of stream */
        do
        {
            if (strm.avail_in == 0)
            {
                strm.avail_in = fread(input, 1, CHUNK, in);
                if (ferror(in))
                {
                    ret = Z_ERRNO;
                    goto extract_ret;
                }
                if (strm.avail_in == 0)
                {
                    ret = Z_DATA_ERROR;
                    goto extract_ret;
                }
                strm.next_in = input;
            }
            ret = inflate(&strm, Z_NO_FLUSH); /* normal inflate */
            if (ret == Z_NEED_DICT)
                ret = Z_DATA_ERROR;
            if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
                goto extract_ret;
            if (ret == Z_STREAM_END)
                break;
        } while (strm.avail_out != 0);

        /* if reach end of stream, then don't keep trying to get more */
        if (ret == Z_STREAM_END)
            break;

        /* do until offset reached and requested data read, or stream ends */
    } while (skip);

    /* compute number of uncompressed bytes read after offset */
    ret = skip ? 0 : len - strm.avail_out;

    /* clean up and return bytes read or error */
extract_ret:
    (void)inflateEnd(&strm);
    return ret;
}

boolean VMDataCollector::impersonate(LPTSTR userName, LPTSTR domainName, LPTSTR password)
{
	BOOL ret = true;
	HANDLE lTokenHandle = NULL;
	if (userName != NULL)
	{
		ret = LogonUser(userName, domainName, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &lTokenHandle);
		if (ret)
		{
			ret = ImpersonateLoggedOnUser(lTokenHandle);
			if (!ret)
			{
				this->log(this->env, 1, "ImpersonateLoggedOnUser :%x", GetLastError());
			}
			CloseHandle(lTokenHandle);
		}
		else
		{
			this->log(this->env, 1, "Logon User Error :%lu\n", GetLastError());
		}
	}
	return ret;
}

boolean VMDataCollector::RevertImpersonate()
{
	BOOL ret = true;

	ret = RevertToSelf();
	if (ret != 0)
	{
		this->log(this->env, 1,  "Impersonate Reverted");
	}
	else
	{
		this->log(this->env, 1,  "Revert Impersonate failes :%x", GetLastError());
		ret = false;
	}

	return ret;
}

BOOL jstringToWide(jstring val, LPTSTR details, JNIEnv *env)
{
	if (val == NULL) return false;
	const jchar* temp = env->GetStringChars(val, 0);
	wcscpy(details, (wchar_t*)temp);
	env->ReleaseStringChars(val, temp);
	return true;
}

int extractDecrypt(FILE *in, struct access *index, __int64 offset, unsigned char *buf, int len, LPTSTR secretKey)
{
	int ret, skip;
	z_stream strm;
	struct point *here;
	unsigned char input[CHUNK];
	unsigned char discard[WINSIZE];
	HCRYPTKEY hKey = generateHashKey(secretKey);

	/* proceed only if something reasonable to do */
	if (len < 0)
		return 0;

	/* find where in stream to start */
	here = index->list;
	ret = index->have;

	while (--ret && here[1].out <= offset) {
		here++;
	}

	/* initialize file and inflate state to start there */
	strm.zalloc = Z_NULL;
	strm.zfree = Z_NULL;
	strm.opaque = Z_NULL;
	strm.avail_in = 0;
	strm.next_in = Z_NULL;
	ret = inflateInit2(&strm, -15);         /* raw inflate */
	if (ret != Z_OK) {
		//cout << "\n\nProblem at line" << __LINE__ << "\n\n";
		return ret;
	}
	int remainder = (here->in - (here->bits ? 1 : 0)) % CHUNK;
	uint64 seekValue = (here->in - (here->bits ? 1 : 0)) / CHUNK * CHUNK;
	if (here->in < CHUNK) {
		seekValue = 0;
		remainder = here->in - (here->bits ? 1 : 0);
	}
	ret = _fseeki64(in, seekValue, SEEK_SET);//replace this after decryption

	if (ret == -1) {
		goto extract_ret;
	}

	/* skip uncompressed bytes until offset reached, then satisfy request */
	offset -= here->out;
	strm.avail_in = 0;
	skip = 1;                               /* while skipping to offset */
	boolean alreadyMoved = false;

	boolean tempBuf = false;
	do {
		/* define where to put uncompressed data, and how much */
		if (offset == 0 && skip) {          /* at offset now */
			strm.avail_out = len;
			strm.next_out = buf;
			skip = 0;                       /* only do this once */
		}
		if (offset > WINSIZE) {             /* skip WINSIZE bytes */
			strm.avail_out = WINSIZE;
			strm.next_out = discard;
			offset -= WINSIZE;
		}
		else if (offset != 0) {             /* last skip */
			strm.avail_out = (unsigned)offset;
			strm.next_out = discard;
			offset = 0;
		}


		/* uncompress until avail_out filled, or end of stream */
		unsigned char tempBuffer[CHUNK];
		do {
			if (strm.avail_in == 0) {
				//to handle the next decryption
				if (!tempBuf && seekValue != 0) {
					fseek(in, -CHUNK, SEEK_CUR);
					int test = fread(tempBuffer, 1, CHUNK, in);
					tempBuf = true;
					bool fEOF = FALSE;
					if (test < CHUNK) {
						fEOF = TRUE;
					}
					test = decryptBuffer(hKey, tempBuffer, test, fEOF);
				}

				strm.avail_in = fread(input, 1, CHUNK, in);
				if (ferror(in)) {
					ret = Z_ERRNO;
					//cout << "\n\nProblem at line" << __LINE__ << "\n\n";
					goto extract_ret;
				}
				if (strm.avail_in == 0) {
					ret = Z_DATA_ERROR;
					//cout << "\n\nProblem at line" << __LINE__ << "\n\n";
					goto extract_ret;
				}
				strm.next_in = input;

				//decrypt logic
				DWORD dwBlockLen;
				DWORD dwBufferLen;
				dwBlockLen = strm.avail_in;
				dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
				bool fEOF = FALSE;
				if (dwBlockLen < CHUNK) {
					fEOF = TRUE;
				}

				strm.avail_in = decryptBuffer(hKey, input, dwBlockLen, fEOF);

				strm.next_in = input;

				//remove bits before inflate
				int moverCount = remainder;//here->in - (here->bits ? 1 : 0);

				for (int testMove = 0; testMove < moverCount && !alreadyMoved; testMove++) {
					strm.next_in++;
					strm.avail_in--;
				}

				int getcValue = 0;
				if (here->bits && !alreadyMoved) {//getc logic
					getcValue = strm.next_in[0];
					strm.next_in++;
					strm.avail_in--;
				}


				//logic for bits inflate prime
				if (!alreadyMoved) {
					uInt avail_in_temp = strm.avail_in;
					z_const Bytef *next_in_temp = strm.next_in;
					if (here->bits) {
						ret = getcValue;//need to add logic for this code
						if (ret == -1) {
							ret = ferror(in) ? Z_ERRNO : Z_DATA_ERROR;
							//cout << "\n\nProblem at line" << __LINE__ << "\n\n";
							goto extract_ret;
						}
						(void)inflatePrime(&strm, here->bits, ret >> (8 - here->bits));
					}
					(void)inflateSetDictionary(&strm, here->window, WINSIZE);
					strm.next_in = next_in_temp;
					strm.avail_in = avail_in_temp;
				}
				alreadyMoved = true;
			}

			ret = inflate(&strm, Z_NO_FLUSH);       /* normal inflate */
			if (ret == Z_NEED_DICT) {
				//cout << "\n\nProblem at line" << __LINE__ << "\n\n";
				ret = Z_DATA_ERROR;
			}
			if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
				goto extract_ret;
			if (ret == Z_STREAM_END)
				break;
		} while (strm.avail_out != 0);

		/* if reach end of stream, then don't keep trying to get more */
		if (ret == Z_STREAM_END)
			break;

		/* do until offset reached and requested data read, or stream ends */
	} while (skip);

	/* compute number of uncompressed bytes read after offset */
	ret = skip ? 0 : len - strm.avail_out;

	/* clean up and return bytes read or error */
extract_ret:
	(void)inflateEnd(&strm);
	return ret;
}

VMDataCollector::VMDataCollector(JNIEnv * env, jthrowable exceptionObject) {
	this->env = env;
	this->exceptionObject = exceptionObject;
}

JNIEXPORT jboolean JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_vixDiskInit
(JNIEnv * env, jclass obj, jthrowable exceptionObject) {
	initializeStaticVariables(env); //initialzes all static Class references and method IDs and Field IDs

	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);

	if (initVixDix(vmd)) {
		vmd->log(env, 1, "vix Disk Init Worked");
		delete vmd;
		return JNI_TRUE;
	}
	else {
		vmd->log(env, 1, "vix Disk Init Failed");
		delete vmd;
		return JNI_FALSE;
	}
}

JNIEXPORT jboolean JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_validateConnectRepository
(JNIEnv * env, jclass obj, jobject jstoreDetails, jstring flag, jthrowable exceptionObject) {
	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_validateConnectRepository() started");

	memset(&vmd->storeDetails, 0, sizeof vmd->storeDetails);
	int retval = vmd->setStoreDetails(jstoreDetails);
	if (retval) {
		vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_validateConnectRepository() done");
		delete vmd;
		return JNI_FALSE;
	}
	LPWSTR conFlag = (LPWSTR)env->GetStringChars(flag, NULL);
	if (wcscmp(conFlag, L"connect") == 0) {
		if (vmd->connectLocation()) {
			vmd->log(env, 1, "Connection success");
			vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_validateConnectRepository() done");
			delete vmd;
			return JNI_TRUE;
		}
		else {
			vmd->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_validateConnectRepository", __FUNCTION__, 0, "Connection to repository failed");
			vmd->log(env, 1, "Unable to connect to Native");
			delete vmd;
			vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_validateConnectRepository() done");
			return JNI_FALSE;
		}
	}
	else {
		vmd->disconnectLocation();
		vmd->log(env, 1, "Disconnect Success");
		vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_validateConnectRepository() done");
		delete vmd;
		return JNI_TRUE;
	}
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_createSyntheticFullBackup
(JNIEnv * env, jclass obj, jobject serverDetails, jstring diskPath, jobject storeDetails, jobject incrDetails, jobject filelist, jthrowable exceptionObject, jobject progressObject, jobject diskReadWriteControl) {
	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_createSyntheticFullBackup() started");
	int errorCode = 0;
	try {
		vmd->initializeGlobals(serverDetails, diskPath, storeDetails, "Java_com_manageengine_rmp_virtual_VMNativeHandler_createSyntheticFullBackup");
		vmd->appGlobals.operation = 0;
		vmd->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_READ_ONLY;
		vmd->log(env, 1, "Going to call DoSyntheticFullBackup()");
		errorCode = vmd->DoSyntheticFullBackup(incrDetails, filelist, "Java_com_manageengine_rmp_virtual_VMNativeHandler_createSyntheticFullBackup", progressObject, diskReadWriteControl);
		vmd->log(env, 1, "Going to call DoDumpMetadata() DoSyntheticBackup");
		vmd->DoDumpMetadata();

	}
	catch (const VixDiskLibErrWrapper& e) {
		vmd->generateException(e.Line(), "Java_com_manageengine_rmp_virtual_VMNativeHandler_createSyntheticFullBackup", e.FunctionName(), e.ErrorCode(), e.Description());
	}
	catch (...) {
		vmd->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_createSyntheticFullBackup", "Generic", 0, "A native error occurred");
	}

	vmd->disconnectExit();
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_createSyntheticFullBackup() done");

	delete vmd;
	if (errorCode == 0) {
		return (jstring)env->NewStringUTF("Synthetic full backup completed successfully.");
	}
	else if (errorCode == ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS) {
		return (jstring)env->NewStringUTF("Synthetic full backup failed : Could not open exisitng backup files.");
	}
	else if (errorCode == ERROR_COULD_NOT_CREATE_BACKUP_FILE) {
		return (jstring)env->NewStringUTF("Synthetic full backup failed : Could not create backup file.");
	}
	else if (errorCode == ERROR_COULD_NOT_READ_FROM_FILE) {
		return (jstring)env->NewStringUTF("Synthetic full backup failed : Error while reading backup files.");
	}
	else if (errorCode == ERROR_COULD_NOT_READ_FROM_VM) {
		return (jstring)env->NewStringUTF("Synthetic full backup failed : Error while reading virtual machine disk.");
	}
	else if (errorCode == ERROR_COULD_NOT_READ_FROM_FILE_NOT_STAR_BACKUP) {
		return (jstring)env->NewStringUTF("Synthetic full backup failed : Error while reading backup files.");
	}
	else if (errorCode == ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_GZDOPEN) {
		return (jstring)env->NewStringUTF("Synthetic full backup failed : Could not open exisitng backup files.");
	}
	else {
		return (jstring)env->NewStringUTF("Synthetic full backup failed due to native errors.");

	}
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_performSyntheticMigration
(JNIEnv * env, jclass obj, jobject serverDetails, jstring srcdiskPath, jobject destHostDetails, jstring destdiskPath, jobject incrDetails, jobject filelist, jobject storeDetails, jthrowable exceptionObject, jobject progressObject, jobject diskReadWriteControl) {

	VMDataCollector* vmdSource = new VMDataCollector(env, exceptionObject);
	VMDataCollector* vmdDestination = new VMDataCollector(env, exceptionObject);

	vmdSource->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_performSyntheticMigration() started");
	int errorCode = 0;
	try {
		vmdSource->initializeGlobals(serverDetails, srcdiskPath, storeDetails, "Java_com_manageengine_rmp_virtual_VMNativeHandler_performSyntheticMigration");
		vmdSource->appGlobals.operation = 0;
		vmdSource->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_READ_ONLY;

		vmdDestination->appGlobals.operation = 1;
		vmdDestination->initializeGlobals(destHostDetails, destdiskPath, storeDetails, "Java_com_manageengine_rmp_virtual_VMNativeHandler_performSyntheticMigration");
		vmdDestination->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_UNBUFFERED; //= 1, # disable host disk caching

		VixDisk targetDisk(vmdDestination->appGlobals.connection, vmdDestination->appGlobals.diskPath, vmdDestination->appGlobals.openFlags, vmdDestination, __LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_performSyntheticMigration");
		vmdSource->log(env, 1, "targetDisk opened");

		VixDisk srcDisk(vmdSource->appGlobals.connection, vmdSource->appGlobals.diskPath, vmdSource->appGlobals.openFlags, vmdSource, __LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_performSyntheticMigration");
		vmdSource->log(env, 1, "srcDisk opened");

		vmdSource->log(env, 1, "Going to call doSyntheticMigration()");
		errorCode = vmdSource->DoSyntheticMigration(targetDisk.Handle(), srcDisk.Handle(), incrDetails, filelist, "Java_com_manageengine_rmp_virtual_VMNativeHandler_createSyntheticFullBackup", progressObject, diskReadWriteControl);
		vmdSource->log(env, 1, "doSyntheticMigration() finished");

	}
	catch (const VixDiskLibErrWrapper& e) {
		vmdSource->generateException(e.Line(), "Java_com_manageengine_rmp_virtual_VMNativeHandler_performSyntheticMigration", e.FunctionName(), e.ErrorCode(), e.Description());
	}
	catch (...) {
		vmdSource->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_performSyntheticMigration", "Generic", 0, "A native error occurred");
	}

	if (vmdSource != nullptr)
	{
		vmdSource->disconnectExit();
		delete vmdSource;
	}
	if (vmdDestination != nullptr)
	{
		vmdDestination->disconnectExit();
		delete vmdDestination;
	}

	if (errorCode == 0) {
		return (jstring)env->NewStringUTF("Synthetic migration completed successfully.");
	}
	else if (errorCode == ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS) {
		return (jstring)env->NewStringUTF("Synthetic migration failed : Could not open exisitng backup files.");
	}
	else if (errorCode == ERROR_COULD_NOT_CREATE_BACKUP_FILE) {
		return (jstring)env->NewStringUTF("Synthetic migration failed : Could not create backup file.");
	}
	else if (errorCode == ERROR_COULD_NOT_READ_FROM_FILE) {
		return (jstring)env->NewStringUTF("Synthetic migration failed : Error while reading backup files.");
	}
	else if (errorCode == ERROR_COULD_NOT_READ_FROM_VM) {
		return (jstring)env->NewStringUTF("Synthetic migration failed : Error while reading virtual machine disk.");
	}
	else if (errorCode == ERROR_COULD_NOT_READ_FROM_FILE_NOT_STAR_BACKUP) {
		return (jstring)env->NewStringUTF("Synthetic migration failed : Error while reading backup files.");
	}
	else if (errorCode == ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_GZDOPEN) {
		return (jstring)env->NewStringUTF("Synthetic migration failed : Could not open exisitng backup files.");
	}
	else {
		return (jstring)env->NewStringUTF("Synthetic migration failed due to native errors.");
	}
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_validateLocalRepository
(JNIEnv *env, jclass obj, jstring domainName, jstring userName, jstring password, jthrowable exceptionObject) {
	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_validateLocalRepository() started...");
	jint returnValue;

	try {
		wchar_t* domain = (wchar_t*)env->GetStringChars(domainName, 0);
		wchar_t* uname = (wchar_t*)env->GetStringChars(userName, 0);
		wchar_t* pwd = (wchar_t*)env->GetStringChars(password, 0);

		HANDLE hToken;
		bool res = LogonUser(uname, domain, pwd, LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT, &hToken);
		if (!res) {
			returnValue = (jint)GetLastError();
		}
		else {
			returnValue = 0;
		}
		if (hToken != NULL) {
            CloseHandle(hToken);
        }
	}
	catch (const VixDiskLibErrWrapper& e) {
		vmd->generateException(e.Line(), "Java_com_manageengine_rmp_virtual_VMNativeHandler_validateLocalRepository", e.FunctionName(), e.ErrorCode(), e.Description());
	}
	catch (...) {
		vmd->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_validateLocalRepository", "Generic", 0, "A native error has occured");
	}

	//vmd->disconnectExit();
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_validateLocalRepository() done");

	delete vmd;
	return returnValue;
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_getIncrementalInfo
(JNIEnv * env, jclass obj, jobject serverDetails, jstring diskPath, jobject storeDetails, jobject incrDetails, jthrowable exceptionObject, jobject progressObject, jobject diskReadWriteControl) {
	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getIncrementalInfo() started");

	try {
		vmd->initializeGlobals(serverDetails, diskPath, storeDetails, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getIncrementalInfo");
		vmd->appGlobals.operation = 2;
		vmd->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_READ_ONLY;
		vmd->DoIncReadWrite(incrDetails, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getIncrementalInfo", progressObject, diskReadWriteControl);
		vmd->log(env, 1, "Going to call DoDumpMetadata() IncrementalBackup");
		vmd->DoDumpMetadata();
	}
	catch (const VixDiskLibErrWrapper& e) {
		vmd->generateException(e.Line(), "Java_com_manageengine_rmp_virtual_VMNativeHandler_getIncrementalInfo", e.FunctionName(), e.ErrorCode(), e.Description());
	}
	catch (...) {
		vmd->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getIncrementalInfo", "Generic", 0, "A native error occurred");
	}
	vmd->disconnectExit();
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getIncrementalInfo() done");

	delete vmd;
	return (jstring)env->NewStringUTF("Incremental Backup Completed");
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_readRegistry
(JNIEnv * env, jclass obj, jobject domainProperties, jstring machineName, jstring registryPath, jstring keyName, jthrowable exceptionObject) {
	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_readRegistry() started");
	BOOL ret = true;

	jstring domainName = (jstring)env->CallObjectMethod(domainProperties, propGetPropertyID, env->NewStringUTF("DOMAIN_NAME"));
	jstring userName = (jstring)env->CallObjectMethod(domainProperties, propGetPropertyID, env->NewStringUTF("USER_NAME"));
	jstring password = (jstring)env->CallObjectMethod(domainProperties, propGetPropertyID, env->NewStringUTF("PASSWORD"));

	LPTSTR domainname = new WCHAR[100];
	jstringToWide(domainName, domainname, env);
	LPTSTR username = new WCHAR[100];
	jstringToWide(userName, username, env);
	LPTSTR pwd = new WCHAR[100];
	jstringToWide(password, pwd, env);
	LPTSTR machinename = new WCHAR[100];
	jstringToWide(machineName, machinename, env);
	LPTSTR regpath = new WCHAR[100];
	jstringToWide(registryPath, regpath, env);
	LPTSTR key = new WCHAR[100];
	jstringToWide(keyName, key, env);

	wstring resultFinal;
	char *returnValue = (char*)malloc(40);
	strcpy(returnValue, "REGError");
	jstring returnjValue = env->NewStringUTF(returnValue);
	DWORD resultantValue(0);

	if (!(vmd->impersonate(username, domainname, pwd)))
	{
		vmd->log(env, 1, "Impersonation failed...");
		ret = false;
	}
	else {
		LONG RegCon;
		HKEY hKeyHandle = NULL;
		RegCon = RegConnectRegistry(machinename, HKEY_LOCAL_MACHINE, &hKeyHandle);
		if (RegCon != ERROR_SUCCESS)
		{
			vmd->log(env, 1, "couldnt connect, %ld", RegCon);
			ret = false;
		}
		else
		{
			vmd->log(env, 1, "connect success");
			HKEY hReg = NULL;
			DWORD dwStat;
			DWORD dwLen;
			dwStat = RegOpenKeyEx(hKeyHandle,
				regpath,
				0,
				KEY_READ | KEY_WOW64_64KEY,
				&hReg);
			if (dwStat != ERROR_SUCCESS)
			{
				vmd->log(env, 1, "RegOpenKeyEx failed: 0x%x\n", dwStat);
				ret = false;
			}
			else
			{
				vmd->log(env, 1, "open success");
				/*DWORD dwBufferSize(sizeof(DWORD));
				dwStat = RegQueryValueEx(hReg, key, NULL, NULL,
					reinterpret_cast<LPBYTE>(&resultantValue), &dwBufferSize);
				if (dwStat != NO_ERROR) {
					vmd->log(env, 1, "Reading the value got failed: 0x%x\n", dwStat);
					ret = false;
				}
				else {
					resultFinal = to_wstring(resultantValue);
					vmd->log(env, 1, "Reading success");
				}*/
				WCHAR szBuff[512];
				DWORD dwBuffSize = sizeof(szBuff);
				dwStat = RegQueryValueEx(hReg, key, 0, NULL, (LPBYTE)&szBuff, &dwBuffSize);
				if (dwStat == NO_ERROR)
				{
					vmd->log(env, 1, "Reading success");
					resultFinal = szBuff;
				}
				else {
					vmd->log(env, 1, "Reading the value got failed: 0x%x\n", dwStat);
					ret = false;
				}

			}
			if (hReg != NULL)
				RegCloseKey(hReg);
		}
		if (ret) {
			returnjValue = env->NewString((jchar*)resultFinal.c_str(), wcslen(resultFinal.c_str()));
		}

		if (hKeyHandle != NULL)
			RegCloseKey(hKeyHandle);
		boolean returnFromRevertImpersonate = vmd->RevertImpersonate();
	}
	delete[] domainname;
	delete[] username;
	delete[] pwd;
	delete[] machinename;
	delete[] key;
	delete[] regpath;

	delete vmd;

	return returnjValue;
}

JNIEXPORT jboolean JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_writeRegistry
(JNIEnv * env, jclass obj, jobject domainProperties, jstring machineName, jstring registryPath, jstring keyName, jstring value, jthrowable exceptionObject) {
	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_writeRegistry() started");
	BOOL ret = true;

	jstring domainName = (jstring)env->CallObjectMethod(domainProperties, propGetPropertyID, env->NewStringUTF("DOMAIN_NAME"));
	jstring userName = (jstring)env->CallObjectMethod(domainProperties, propGetPropertyID, env->NewStringUTF("USER_NAME"));
	jstring password = (jstring)env->CallObjectMethod(domainProperties, propGetPropertyID, env->NewStringUTF("PASSWORD"));

	LPTSTR domainname = new WCHAR[100];
	jstringToWide(domainName, domainname, env);
	LPTSTR username = new WCHAR[100];
	jstringToWide(userName, username, env);
	LPTSTR pwd = new WCHAR[100];
	jstringToWide(password, pwd, env);
	LPTSTR machinename = new WCHAR[100];
	jstringToWide(machineName, machinename, env);
	LPTSTR regpath = new WCHAR[100];
	jstringToWide(registryPath, regpath, env);
	LPTSTR key = new WCHAR[100];
	jstringToWide(keyName, key, env);
	LPTSTR addingValue = new WCHAR[100];
	jstringToWide(value, addingValue, env);

	if (!(vmd->impersonate(username, domainname, pwd)))
	{
		vmd->log(env, 1, "Impersonation failed...");
		ret = false;
	}
	else {
		LONG RegCon;
		HKEY hKeyHandle = NULL;
		RegCon = RegConnectRegistry(machinename, HKEY_LOCAL_MACHINE, &hKeyHandle);
		if (RegCon != ERROR_SUCCESS)
		{
			vmd->log(env, 1, "couldnt connect, %ld", RegCon);
			ret = false;
		}
		else
		{
			vmd->log(env, 1, "connect success");
			HKEY hReg = NULL;
			DWORD dwStat = NO_ERROR;
			dwStat = RegCreateKeyExW(hKeyHandle,
				regpath,
				0,
				NULL,
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS | KEY_WOW64_64KEY,
				NULL,
				&hReg,
				NULL);
			if (dwStat != NO_ERROR)
			{
				vmd->log(env, 1, "RegCreateKeyEx failed: 0x%x\n", dwStat);
				ret = false;
			}
			else
			{
				/*vmd->log(env, 1, "create success");
				const char* cstr = env->GetStringUTFChars(value, 0);
				DWORD fillingValue = atoi(cstr);
				dwStat = RegSetValueEx(hReg, key, 0, REG_DWORD,
					(const BYTE *)&fillingValue, sizeof(fillingValue));
				if (dwStat != NO_ERROR)
				{
					vmd->log(env, 1, "RegSetValueEx for cookie failed: 0x%x\n", dwStat);
					ret = false;
				}
				else {
					vmd->log(env, 1, "value set success");
				}*/
				dwStat = RegSetValueEx(hReg, key, 0, REG_SZ,
					(LPBYTE)addingValue, (wcslen(addingValue)*sizeof(WCHAR)));
				if (dwStat != NO_ERROR)
				{
					vmd->log(env, 1, "RegSetValueEx for cookie failed: 0x%x\n", dwStat);
					ret = false;
				}
				else {
					vmd->log(env, 1, "value set success");
				}
			}
			if (hReg != NULL)
				RegCloseKey(hReg);
		}
		if (hKeyHandle != NULL)
			RegCloseKey(hKeyHandle);
		boolean returnFromRevertImpersonate = vmd->RevertImpersonate();
	}

	delete[] domainname;
	delete[] username;
	delete[] pwd;
	delete[] machinename;
	delete[] key;
	delete[] regpath;

	delete vmd;
	return ret;
}

JNIEXPORT jboolean JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_writeRevertDiff
(JNIEnv * env, jclass obj, jobject serverDetails, jstring diskPath, jobject storeDetails, jobject incrDetails, jthrowable exceptionObject, jobject progressObject, jobject diskReadWriteControl) {
	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_writeRevertDiff() started");

	try {
		vmd->initializeGlobals(serverDetails, diskPath, storeDetails, "Java_com_manageengine_rmp_virtual_VMNativeHandler_writeRevertDiff");
		vmd->appGlobals.operation = 1;
		vmd->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_UNBUFFERED;
		vmd->appGlobals.isBackup = FALSE;
		vmd->log(env, 1, "Going to call DoDiffMaker()");
		vmd->DoDiffMaker(incrDetails, progressObject, "Java_com_manageengine_rmp_virtual_VMNativeHandler_writeRevertDiff", diskReadWriteControl);
		//dont forget to close files after exception
	}
	catch (const VixDiskLibErrWrapper& e) {
		vmd->generateException(e.Line(), "Java_com_manageengine_rmp_virtual_VMNativeHandler_writeRevertDiff", e.FunctionName(), e.ErrorCode(), e.Description());
	}
	catch (...) {
		vmd->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_writeRevertDiff", "Generic", 0, "A native error occurred");
	}
	vmd->disconnectExit();
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_writeRevertDiff() done");

	delete vmd;
	return JNI_TRUE;
}

int VMDataCollector::readFromDisk(queue<BufferChunk*> *que, Synchronizer* s, jobject progressObject, jobject diskReadWriteControl, VixDiskLibHandle diskHandle) {
	JNIEnv* myNewEnv;
	int getEnvStat = this->jvm->GetEnv((void**)&myNewEnv, NULL);
	if (getEnvStat == JNI_EDETACHED) {
		if (this->jvm->AttachCurrentThread((void **)&myNewEnv, NULL) < 0) {
			s->isExceptionGenerated = true;
            return -1;
		}
	}
	log(myNewEnv, 1, "API called readFromDisk()");
	const int QUEUE_LIMIT = 25;
	size_t bufSize;
	uint8 *buf;
	VixDiskLibInfo *info;
	VixError err;
	uint32 maxOps, i;
	bufSize = 4096 * 2 * VIXDISKLIB_SECTOR_SIZE;
	this->appGlobals.bufSize = 4096 * 2;
	try {
		err = VixDiskLib_GetInfo(diskHandle, &info);
		if (VIX_FAILED(err)) {
		    this->generateException(__LINE__, "readFromDisk", __FUNCTION__, 0, VixDiskLib_GetErrorText(err, NULL));
			throw "Vixerror while VixDiskLib_GetInfo";
		}

		maxOps = info->capacity / this->appGlobals.bufSize; //this->appGlobals.bufSize;
		myNewEnv->CallObjectMethod(progressObject, setMaximumMethodID, (jlong)maxOps);

		VixDiskLib_FreeInfo(info);
		bool isPrevWriteCompleted = true;
		BufferChunk* buffer;
		for (i = 0; i < maxOps;) {
			VixError vixError;
			if (i % 500 == 0 && !myNewEnv->CallObjectMethod(diskReadWriteControl, proceedCheckID)) {
				log(myNewEnv, 1, "Disk RW Aborted from DoRWBench");
				this->generateException(__LINE__, "readFromDisk", __FUNCTION__, 0, "Disk read|write was aborted");
				throw "Thrown because Other disk read/write is terminated";
				break;
			}
			if (isPrevWriteCompleted) {
				buffer = new BufferChunk(bufSize);
				//cout<<"reading"<<endl;
				vixError = VixDiskLib_Read(diskHandle,
					i * this->appGlobals.bufSize,
					this->appGlobals.bufSize, buffer->buff);
				if (VIX_FAILED(vixError)) {
					delete buffer;
					log(myNewEnv, 1, "vixerror while reading ");
					this->generateException(__LINE__, "readFromDisk", __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
					throw "Exception generated in readFromDisk because VixDiskLib_Read";
				}
				i++;
			}
			isPrevWriteCompleted = false;

			if (que->size() < QUEUE_LIMIT) { //To limit the queue size
				EnterCriticalSection(&(s->shared_buffer_lock));
				que->push(buffer);
				LeaveCriticalSection(&(s->shared_buffer_lock));
				isPrevWriteCompleted = true;
			}
			else {
				if (s->isExceptionGenerated) {
				    //cout<<"exception generated in partner thread"<<endl;
					throw "Thrown because this disk partner thread is terminated";
				}
				else {
				    //cout<<"disk sleep"<<endl;
					std::this_thread::sleep_for(std::chrono::seconds(2));
				}
			}
			// if (i % 100 == 0 || i == maxOps - 1) {
			//     myNewEnv->CallObjectMethod(progressObject, setProgressMethodID, (jlong) (i + 1));
			// }

		}
		s->isReadCompleted = true;
        this->jvm->DetachCurrentThread();
        return 0;
	}
	catch (const VixDiskLibErrWrapper& e) {
		log(myNewEnv, 1, "readFromDisk() Exception Caught VixDiskLibErrWrapper ");
		s->isExceptionGenerated = true;
	}
	catch (char const* message) {
		log(myNewEnv, 1, message);
		log(myNewEnv, 1, "readFromDisk() Exception Caught ");
		s->isExceptionGenerated = true;
	}
	catch (...) {
		log(myNewEnv, 1, "readFromDisk() General Exception Caught ");
		s->isExceptionGenerated = true;
	}
	this->jvm->DetachCurrentThread();
	return -1;
}

int VMDataCollector::writeToRepository(queue<BufferChunk*> *que, Synchronizer* s, jobject progressObject) {
    JNIEnv* myNewEnv;
    int getEnvStat = this->jvm->GetEnv((void**)&myNewEnv, NULL);
    if (getEnvStat == JNI_EDETACHED) {
        if (this->jvm->AttachCurrentThread((void **)&myNewEnv, NULL) < 0) {
            s->isExceptionGenerated = true;
            return -1;
        }
    }
    this->log(myNewEnv, 1, "API called writeToRepository()");
    size_t bufSize;
    VixError err;
    uint32 i = 0;
    bufSize = 4096 * 2 * VIXDISKLIB_SECTOR_SIZE;
    this->appGlobals.bufSize = 4096 * 2;
    BufferChunk* buffer;
    bool isReadFromQueue = false;
    int gzerror;
    gzFile ofile;
    try{
        this->log(myNewEnv, 1, "this->appGlobals.wvmdkPath %ws",this->appGlobals.wvmdkPath);
        int fileDescriptor = _wopen(this->appGlobals.wvmdkPath, _O_CREAT | _O_WRONLY | _O_BINARY, _S_IWRITE);

        if (fileDescriptor == -1) {
            int errsv = errno;
            this->log(myNewEnv, 1, "_wopen error : %d", errsv);
            this->generateException(__LINE__, "getfulldisk", __FUNCTION__, 0, "File open error");
            throw "_wopen error occurred while opening wvmdkPath";
            //(jstring)env->NewStringUTF("Full Backup Failed1");
        }
        ofile = gzdopen(fileDescriptor, "wb1");
        if (!ofile) {
            this->log(myNewEnv, 1, "Error Opening File");
            this->log(myNewEnv, 1, this->appGlobals.vmdkPath);
            this->generateException(__LINE__, "getfulldisk", __FUNCTION__, 0, "File open error");
            throw "gzdopen error occurred ";
           // (jstring)env->NewStringUTF("Full Backup Failed2");
        }
        this->log(myNewEnv, 1, "DoRWBench_multiththread() : File opened successfully for full backup");

        while (!(s->isReadCompleted && que->empty())) {
            isReadFromQueue = false;
            if (!que->empty()) {
                EnterCriticalSection(&(s->shared_buffer_lock));
                buffer = que->front();
                que->pop();
                LeaveCriticalSection(&(s->shared_buffer_lock));
                isReadFromQueue = true;

            }
            else {
                if (s->isExceptionGenerated) {
                    //cout<<"exception in partner thread"<<endl;
                    throw "Thrown because this disk partner thread is terminated";
                }
                else {
                    //cout<<"sleep"<<endl;
                    std::this_thread::sleep_for(std::chrono::seconds(2));
                }
            }
            if (isReadFromQueue) {
                //cout<<"writing"<<endl;
                gzerror = gzwrite(ofile, buffer->buff, bufSize);
                if (i % 100 == 0) {
                    myNewEnv->CallObjectMethod(progressObject, setProgressMethodID, (jlong)(i + 1));
                }
                i++;
                delete buffer;
                if(gzerror <= 0){
                    if(ofile !=NULL ){
                        gzclose(ofile);
                    }
                    this->generateException(__LINE__, "getfulldisk", __FUNCTION__, 0, "Error occurred while writing to file");
                    log(myNewEnv, 1, "gzerror while writing ");
                    throw "Exception generated while writing to file";
                }
            }
        }
        myNewEnv->CallObjectMethod(progressObject, setProgressMethodID, (jlong)(i));
        if(ofile !=NULL ){
            gzclose(ofile);
        }
        this->jvm->DetachCurrentThread();
        return 0;
    }catch(char const* message) {
        log(myNewEnv, 1, message);
        log(myNewEnv, 1, "writeToRepository() Exception Caught : %s", message);
        s->isExceptionGenerated = true;
    }catch (...) {
        log(myNewEnv, 1, "writeToRepository() General Exception Caught ");
        s->isExceptionGenerated = true;
    }
    this->jvm->DetachCurrentThread();
    return -1;
}
int VMDataCollector::writeToDisk(queue<BufferChunk*> *que, Synchronizer* s, jobject progressObject, VixDiskLibHandle diskHandle) {
	JNIEnv* myNewEnv;
	int getEnvStat = this->jvm->GetEnv((void**)&myNewEnv, NULL);
	if (getEnvStat == JNI_EDETACHED) {
		if (this->jvm->AttachCurrentThread((void **)&myNewEnv, NULL) < 0) {
		    s->isExceptionGenerated = true;
			return -1;
		}
	}
	this->log(myNewEnv, 1, "API called writeToDisk()");

	size_t bufSize;
	uint32 i;
	bufSize = 4096 * 2 * VIXDISKLIB_SECTOR_SIZE;
	this->appGlobals.bufSize = 4096 * 2;

	BufferChunk* buffer;
	i = 0;
	bool isReadFromQueue = false;
	try {
		while (!(s->isReadCompleted && que->empty())) {
			isReadFromQueue = false;
			if (!que->empty()) {
				EnterCriticalSection(&(s->shared_buffer_lock));
				buffer = que->front();
				que->pop();
				LeaveCriticalSection(&(s->shared_buffer_lock));
				isReadFromQueue = true;
			}
			else {
				if (s->isExceptionGenerated) {
					throw "Thrown because this disk partner thread is terminated";
				}
				else {
					std::this_thread::sleep_for(std::chrono::seconds(2));
				}
			}
			if (isReadFromQueue) {
				VixError vixError = VixDiskLib_Write(diskHandle,
					i * this->appGlobals.bufSize,
					this->appGlobals.bufSize, buffer->buff);
				if (i % 100 == 0) {
					myNewEnv->CallObjectMethod(progressObject, setProgressMethodID, (jlong)(i + 1));
				}
				i++;
				delete buffer;
				if (VIX_FAILED(vixError)) {
					log(myNewEnv, 1, "vixerror while writing ");
					this->generateException(__LINE__, "writeToDisk", __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
					throw "Exception generated in writeToDisk";
				}
			}
		}
		myNewEnv->CallObjectMethod(progressObject, setProgressMethodID, (jlong)(i));
        this->jvm->DetachCurrentThread();
        return 0;
	}
	catch (const VixDiskLibErrWrapper& e) {
		log(myNewEnv, 1, "writeToDisk() Exception Caught VixDiskLibErrWrapper ");
		s->isExceptionGenerated = true;
	}
	catch (char const* message) {
		log(myNewEnv, 1, message);
		log(myNewEnv, 1, "writeToDisk() Exception Caught ");
		s->isExceptionGenerated = true;
	}
	catch (...) {
		log(myNewEnv, 1, "writeToDisk() General Exception Caught ");
		s->isExceptionGenerated = true;
	}
	this->jvm->DetachCurrentThread();
	return -1;
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateDiskData
(JNIEnv * env, jclass obj, jobject sourceHostDetails, jobject destHostDetails, jstring sourceDiskPath, jstring destDiskPath, jthrowable exceptionObject, jobject progressObject, jobject diskReadWriteControl) {
	VMDataCollector* vmdSource = new VMDataCollector(env, exceptionObject);
	VMDataCollector* vmdDestination = new VMDataCollector(env, exceptionObject);
	vmdSource->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateDiskData() started without repo details");

	try {
		BufferChunk* buffer;
		env->GetJavaVM(&(vmdSource->jvm));
		vmdDestination->jvm = vmdSource->jvm;
		vmdSource->initializeGlobals(sourceHostDetails, sourceDiskPath, NULL, "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateDiskData");
		vmdDestination->initializeGlobals(destHostDetails, destDiskPath, NULL, "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateDiskData");
		vmdSource->appGlobals.operation = 0;
		vmdSource->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_READ_ONLY; // = 4 # open read-only
		vmdDestination->appGlobals.operation = 1;
		vmdDestination->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_UNBUFFERED; //= 1, # disable host disk caching
		Synchronizer* syn = new Synchronizer();
		syn->isReadCompleted = false;
		syn->isExceptionGenerated = false;
		queue<BufferChunk*>* que = new queue<BufferChunk*>();
		InitializeCriticalSection(&(syn->shared_buffer_lock));

		VixDisk diskSource(vmdSource->appGlobals.connection, vmdSource->appGlobals.diskPath, vmdSource->appGlobals.openFlags, vmdSource, __LINE__, "readFromDisk");
		VixDisk diskDestination(vmdDestination->appGlobals.connection, vmdDestination->appGlobals.diskPath, vmdDestination->appGlobals.openFlags, vmdDestination, __LINE__, "writeToDisk");


		thread readFromDiskThread(&VMDataCollector::readFromDisk, vmdSource, que, syn, progressObject, diskReadWriteControl, diskSource.Handle());
		vmdSource->log(env, 1, "Going to call writeToDiskThread");
		thread writeToDiskThread(&VMDataCollector::writeToDisk, vmdDestination, que, syn, progressObject, diskDestination.Handle());

		if (readFromDiskThread.joinable()) {
			vmdSource->log(env, 1, "readFromDiskThread.joinable()");
			readFromDiskThread.join();
		}
		else {
			vmdSource->log(env, 1, "readFromDiskThread not joinable()");
		}
		if (writeToDiskThread.joinable()) {
			vmdSource->log(env, 1, "writeToDiskThread.joinable()");
			writeToDiskThread.join();
		}
		else {
			vmdSource->log(env, 1, "writeToDiskThread not joinable()");
		}

		readFromDiskThread.~thread();
		writeToDiskThread.~thread();

		DeleteCriticalSection(&(syn->shared_buffer_lock));
		while (!que->empty()) {
			buffer = que->front();
			que->pop();
			delete buffer;
		}
		delete que;

		if (syn->isExceptionGenerated) {
			vmdSource->log(env, 1, "Exception occurred in either of the native threads");
		}
		delete syn;
		vmdSource->log(env, 1, "Migrating Data from Disks completed!!!");
	}
	catch (char const* message) {
		vmdSource->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateDiskData", "Generic", 0, message);
	}
	catch (...) {
		//to catch all exceptions
		vmdSource->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateDiskData", "Generic", 0, "A native error has occured");
	}

	vmdSource->disconnectExit();
	vmdDestination->disconnectExit();
	vmdSource->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateDiskData() done");

	delete vmdSource;
	delete vmdDestination;
	return (jstring)env->NewStringUTF("Writing Disk for Live VM Migration Completed");
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateIncrementalDiskData
(JNIEnv * env, jclass obj, jobject sourceHostDetails, jobject destHostDetails, jstring sourceDiskPath, jstring destDiskPath, jobject incrDetails, jthrowable exceptionObject, jobject progressObject, jobject diskReadWriteControl) {
	VMDataCollector* vmdSource = new VMDataCollector(env, exceptionObject);
	VMDataCollector* vmdDestination = new VMDataCollector(env, exceptionObject);
	vmdSource->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateIncrementalDiskData() started without repo details");

	try {
		vmdSource->initializeGlobals(sourceHostDetails, sourceDiskPath, NULL, "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateIncrementalDiskData");
		vmdDestination->initializeGlobals(destHostDetails, destDiskPath, NULL, "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateIncrementalDiskData");
		vmdSource->appGlobals.operation = 0;
		vmdSource->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_READ_ONLY; // = 4 # open read-only
		vmdDestination->appGlobals.operation = 1;
		vmdDestination->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_UNBUFFERED; //= 1, # disable host disk caching
		VixDisk diskSource(vmdSource->appGlobals.connection, vmdSource->appGlobals.diskPath, vmdSource->appGlobals.openFlags, vmdSource, __LINE__, "readFromDisk");
		VixDisk diskDestination(vmdDestination->appGlobals.connection, vmdDestination->appGlobals.diskPath, vmdDestination->appGlobals.openFlags, vmdDestination, __LINE__, "writeToDisk");
		vmdSource->DoIncReadAndWrite(incrDetails, vmdDestination, diskSource.Handle(), diskDestination.Handle(), "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateIncrementalDiskData", progressObject, diskReadWriteControl);

		vmdSource->log(env, 1, "Migrating Data from Disks completed!!!");
	}
	catch (char const* message) {
		vmdSource->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateIncrementalDiskData", "Generic", 0, message);
	}
	catch (const VixDiskLibErrWrapper& e) {
		vmdSource->generateException(e.Line(), "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateIncrementalDiskData", e.FunctionName(), e.ErrorCode(), e.Description());
	}
	catch (...) {
		//to catch all exceptions
		vmdSource->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateIncrementalDiskData", "Generic", 0, "A native error has occured");
	}

	vmdSource->disconnectExit();
	vmdDestination->disconnectExit();
	vmdSource->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_migrateDiskData() done");

	delete vmdSource;
	delete vmdDestination;
	return (jstring)env->NewStringUTF("Writing Disk for Live VM Migration Completed");
}

struct access* VMDataCollector::getIndexforFile(struct access *index, wchar_t* indexFile)
{
    //logdrive->logchar(NORMAL, "BuildIndex.cpp Loading Index for index file : %ws", indexFile);
    this->log(this->env, 1, "BuildIndex.cpp Loading Index for index file : %ws", indexFile);
    int fd = _wopen(indexFile, _O_RDONLY | _O_BINARY);
    if (fd == -1) {
        int errsv = errno;
        //logdrive->logchar(NORMAL, "BuildIndex.cpp _wopen index error : %d", errsv);
        this->log(this->env, 1, "BuildIndex.cpp _wopen index error : %d", errsv);
        return NULL;
    }
    else {
        //logdrive->logchar(NORMAL, "BuildIndex.cpp fd not -1 : A-OK [%d]", __LINE__);
        this->log(this->env, 1, "BuildIndex.cpp fd not -1 : A-OK [%d]", __LINE__);
    }
    gzFile gz = gzdopen(fd, "rb");
    if (gz == NULL) {
        //logdrive->logchar(NORMAL, "BuildIndex.cpp gzdopen index error at %d", __LINE__);
        this->log(this->env, 1, "BuildIndex.cpp gzdopen index error at %d", __LINE__);
    }

    // Allocate a seekgzip_t instance.
    index = (struct access *)malloc(sizeof(struct access));
    if (index == NULL) {
        //logdrive->logchar(NORMAL, "BuildIndex.cpp Index null.out of memory");
        this->log(this->env, 1, "BuildIndex.cpp Index null.out of memory");
        return NULL;
    }
    memset(index, 0, sizeof(*index));

    // Read the number of entry points.
    index->have = index->size = read_uint32(gz);

    // Allocate an array for entry points.
    index->list = (struct point *)malloc(sizeof(struct point) * index->have);
    if (index->list == NULL) {
        //logdrive->logchar(NORMAL, "BuildIndex.cpp Index->list empty");
        this->log(this->env, 1, "BuildIndex.cpp Index->list empty");
    }
    //logdrive->logchar(NORMAL, "BuildIndex.cpp Index size : %d", index->have);
    this->log(this->env, 1, "BuildIndex.cpp Index size : %d", index->have);
    // Read entry points.
    for (int m = 0; m < index->have; ++m) {
        gzread(gz, &index->list[m].out, sizeof(__int64));
        gzread(gz, &index->list[m].in, sizeof(__int64));
        gzread(gz, &index->list[m].bits, sizeof(int));
        gzread(gz, index->list[m].window, WINSIZE);
    }
    if (gz != NULL) {
        gzclose(gz);
    }
    //logdrive->logchar(NORMAL, "BuildIndex.cpp Building Index for file is completed..");
    this->log(this->env, 1, "BuildIndex.cpp Building Index for file is completed..");
    return index;
}
void VMDataCollector::printJNI(jstring myStringArgs){
    const char *str = env->GetStringUTFChars(myStringArgs, NULL);
    cout<<str<<endl;
    this->log(env, 1, "%s ",str);
    (env)->ReleaseStringUTFChars( myStringArgs, str);
}
JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_getFullDiskInfo
(JNIEnv * env, jclass obj, jobject serverDetails, jstring diskPath, jobject storeDetails, jthrowable exceptionObject, jobject progressObject, jobject diskReadWriteControl) {
	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getFullDiskInfo() started");

	try {
	    BufferChunk* buffer;
        env->GetJavaVM(&(vmd->jvm));
		vmd->initializeGlobals(serverDetails, diskPath, storeDetails, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getFullDiskInfo");
		vmd->appGlobals.operation = 0;
		vmd->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_READ_ONLY;
		Synchronizer* syn = new Synchronizer();
        syn->isReadCompleted = false;
        syn->isExceptionGenerated = false;
        queue<BufferChunk*>* que = new queue<BufferChunk*>();
        InitializeCriticalSection(&(syn->shared_buffer_lock));
		vmd->log(env, 1, "Going to call threads in FullBackup");
		VixDisk disk(vmd->appGlobals.connection, vmd->appGlobals.diskPath, vmd->appGlobals.openFlags, vmd, __LINE__, "getfulldisk");
        thread readFromDiskThread(&VMDataCollector::readFromDisk, vmd, que, syn, progressObject, diskReadWriteControl, disk.Handle());
        thread writeToRepositoryThread(&VMDataCollector::writeToRepository,vmd, que, syn, progressObject);
        if (readFromDiskThread.joinable()) {
            vmd->log(env, 1, "readFromDiskThread.joinable()");
            readFromDiskThread.join();
        }
        else {
            vmd->log(env, 1, "readFromDiskThread not joinable()");
        }
        if (writeToRepositoryThread.joinable()) {
            vmd->log(env, 1, "writeToRepositoryThread.joinable()");
            writeToRepositoryThread.join();
        }
        else {
            vmd->log(env, 1, "writeToRepositoryThread not joinable()");
        }
        readFromDiskThread.~thread();
        writeToRepositoryThread.~thread();

        DeleteCriticalSection(&(syn->shared_buffer_lock));
        while (!que->empty()) {
            buffer = que->front();
            que->pop();
            delete buffer;
        }
        delete que;
        if (syn->isExceptionGenerated) {
            vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getFullDiskInfo() Exception generated in either of Threads");
        }
        delete syn;
		//vmd->DoRWBench(vmd->appGlobals.isBackup, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getFullDiskInfo", progressObject, diskReadWriteControl);
		//build index call
		vmd->log(env, 1, "Going to call indexCreation() FullBackup");
        wstring backupFile = vmd->appGlobals.wvmdkPath;
        int indexCreationResult = vmd->indexCreation(backupFile, false, NULL);
        vmd->log(env, 1, "indexCreationResult : %d", indexCreationResult);

		vmd->log(env, 1, "Going to call DoDumpMetadata() FullBackup");
		vmd->DoDumpMetadata();
        vmd->log(env, 1, "Full backup Data from Disks completed!!!");
	}
	catch (const VixDiskLibErrWrapper& e) {
		vmd->generateException(e.Line(), "Java_com_manageengine_rmp_virtual_VMNativeHandler_getFullDiskInfo", e.FunctionName(), e.ErrorCode(), e.Description());
	}
	catch (...) {
		vmd->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getFullDiskInfo", "Generic", 0, "A native error has occured");
	}
	vmd->disconnectExit();
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getFullDiskInfo() done");
	delete vmd;
	return (jstring)env->NewStringUTF("Full Backup Completed");
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_setDiskInfoEfficient
(JNIEnv * env, jclass obj, jobject serverDetails, jstring restoreType, jstring diskPath, jobject finalDisksInfo, jobject finalIncrementalsInfo, jthrowable exceptionObject, jobject progressObject, jobject diskReadWriteControl) {

	VMDataCollector* vmdEfficient = new VMDataCollector(env, exceptionObject);
	vmdEfficient->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setDiskInfoEfficient() started");
	int res;
	try {
		vmdEfficient->initializeGlobals(serverDetails, diskPath, NULL, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setDiskInfoEfficient");
		vmdEfficient->appGlobals.operation = 1;
		vmdEfficient->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_UNBUFFERED;
		res = vmdEfficient->doEfficientRestore(diskPath, restoreType, finalDisksInfo, finalIncrementalsInfo, progressObject, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setDiskInfoEfficient");
	}
	catch (const VixDiskLibErrWrapper& e) {
		vmdEfficient->generateException(e.Line(), "Java_com_manageengine_rmp_virtual_VMNativeHandler_setDiskInfoEfficient", e.FunctionName(), e.ErrorCode(), e.Description());
	}

	vmdEfficient->disconnectExit();
	vmdEfficient->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setDiskInfoEfficient() done");

	delete vmdEfficient;

	if (res == 1) {
		return (jstring)env->NewStringUTF("Error Occurred in Efficient Restore");
	}
	else {
		return (jstring)env->NewStringUTF("Efficient Restore Completed");
	}

}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_setFullDiskInfo
(JNIEnv * env, jclass obj, jobject serverDetails, jstring diskPath, jobject storeDetails, jthrowable exceptionObject, jobject progressObject, jobject diskReadWriteControl) {

	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setFullDiskInfo() started");

	try {
		vmd->initializeGlobals(serverDetails, diskPath, storeDetails, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setFullDiskInfo");
		vmd->appGlobals.operation = 1;
		vmd->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_UNBUFFERED;
		vmd->appGlobals.isBackup = FALSE;
		vmd->log(env, 1, "Going to call DoWriteMetadata() setFullDiskInfo");
		vmd->DoWriteMetadata();
		vmd->log(env, 1, "Going to call DoRWBench() setFullDiskInfo");
		vmd->DoRWBench(vmd->appGlobals.isBackup, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setFullDiskInfo", progressObject, diskReadWriteControl);
	}
	catch (const VixDiskLibErrWrapper& e) {

		vmd->generateException(e.Line(), "Java_com_manageengine_rmp_virtual_VMNativeHandler_setFullDiskInfo", e.FunctionName(), e.ErrorCode(), e.Description());
	}
	catch (...) {
		vmd->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setFullDiskInfo", "Generic", 0, "A native error has occured");
	}
	vmd->disconnectExit();
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setFullDiskInfo() done");

	delete vmd;
	return (jstring)env->NewStringUTF("Full Restore Completed");
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_setIncrementalInfo
(JNIEnv * env, jclass obj, jobject serverDetails, jstring diskPath, jobject storeDetails, jobject incrDetails, jthrowable exceptionObject, jobject progressObject, jobject diskReadWriteControl) {
	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setIncrementalInfo() started");

	try {
		vmd->initializeGlobals(serverDetails, diskPath, storeDetails, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setIncrementalInfo");
		vmd->appGlobals.operation = 3;
		vmd->appGlobals.openFlags |= VIXDISKLIB_FLAG_OPEN_UNBUFFERED;
		vmd->log(env, 1, "Going to call DoIncReadWrite() setIncrementalInfo");
		vmd->DoIncReadWrite(incrDetails, 0, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setIncrementalInfo", progressObject, diskReadWriteControl);
	}
	catch (const VixDiskLibErrWrapper& e) {
		vmd->generateException(e.Line(), "Java_com_manageengine_rmp_virtual_VMNativeHandler_setIncrementalInfo", e.FunctionName(), e.ErrorCode(), e.Description());
	}
	catch (...) {
		vmd->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setIncrementalInfo", "Generic", 0, "A native error has occured");
	}
	vmd->disconnectExit();
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setIncrementalInfo() done");
	delete vmd;
	return (jstring)env->NewStringUTF("Incremental Restore Completed");
}

void VMDataCollector::DoIncReadAndWrite(jobject incBackupDetails, VMDataCollector* vmdDestination, VixDiskLibHandle diskHandleSource, VixDiskLibHandle diskHandleDestination, char* moduleName, jobject progressObject, jobject diskReadWriteControl) {
	this->log(this->env, 1, "DoIncReadAndWrite started");
	VixDisk disk(this->appGlobals.connection, this->appGlobals.diskPath, this->appGlobals.openFlags, this, __LINE__, moduleName);
	uint32 maxOps, j, bufUpdate;
	VixError err;
	boolean abort = false;
	size_t bufSize;
	uint8 *buf;
	if (this->appGlobals.bufSize == 0) {
		this->appGlobals.bufSize = DEFAULT_BUFSIZE;
	}
	bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
	buf = new uint8[bufSize];
	gzFile ofile;
	gzFile ifile;
	int size = (jint)env->CallIntMethod(incBackupDetails, listSizeID);

	//env->CallObjectMethod(progressObject, setMaximumMethodID, (jlong)size);
	bool noDecryptError = false;

	VixError vixError;
	int percent = 1 + (size / 10);
	__int64 progress = 0;
	for (int i = 0; i < size; i++) {
		jobject incDetail = env->CallObjectMethod(incBackupDetails, listGetID, (jint)i);
		jstring startVal = (jstring)env->CallObjectMethod(incDetail, jMtdGetHashtable, env->NewStringUTF("OFFSET"));
		jstring length = (jstring)env->CallObjectMethod(incDetail, jMtdGetHashtable, env->NewStringUTF("LENGTH"));
		const char* cstr = env->GetStringUTFChars(startVal, 0);
		uint64 start = _strtoui64(cstr, NULL, 0);
		cstr = env->GetStringUTFChars(length, 0);
		uint64 len = _strtoui64(cstr, NULL, 0);
		start = start / VIXDISKLIB_SECTOR_SIZE;
		len = len / VIXDISKLIB_SECTOR_SIZE;
		maxOps = len / this->appGlobals.bufSize;
		bufUpdate = 0;
		for (j = 0; j < maxOps; j++) {
			if (j % 1000 == 0 && !env->CallObjectMethod(diskReadWriteControl, proceedCheckID)) {
				abort = true;
				this->log(this->env, 1, "Disk RW Aborted from DoIncReadWrite()");
				this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Disk read|write was aborted");
				break;
			}
			vixError = VixDiskLib_Read(diskHandleSource, start + (j * this->appGlobals.bufSize), this->appGlobals.bufSize, buf);
			if (VIX_FAILED(vixError)) {
				delete[] buf;
				this->generateException(__LINE__, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
				fileCloser(ofile);
				throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
			}
			vixError = VixDiskLib_Write(diskHandleDestination, start + (j * this->appGlobals.bufSize), this->appGlobals.bufSize, buf);
			if (VIX_FAILED(vixError)) {
				delete[] buf;
				this->generateException(__LINE__, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
				fileCloser(ifile);
				throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
			}


			//outfile.write ((char *)buf, bufSize);
			bufUpdate += this->appGlobals.bufSize;
			if (bufUpdate >= BUFS_PER_STAT) {
				bufUpdate = 0;
			}
			len = len - this->appGlobals.bufSize;
			progress = progress + (this->appGlobals.bufSize*VIXDISKLIB_SECTOR_SIZE);
			//for every 1GB : since each loop is @2MB
			if (j % 500 == 0) {
				env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)progress);
			}
		}

		if (abort) {
			break;
		}

		if (len > 0) {
			bufSize = len * VIXDISKLIB_SECTOR_SIZE;
			vixError = VixDiskLib_Read(diskHandleSource, start + (j * this->appGlobals.bufSize), len, buf);
			if (VIX_FAILED(vixError)) {
				delete[] buf;
				this->generateException(__LINE__, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
				fileCloser(ofile);
				throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
			}

			vixError = VixDiskLib_Write(diskHandleDestination, start + (j * this->appGlobals.bufSize), len, buf);
			if (VIX_FAILED(vixError)) {
				delete[] buf;
				this->generateException(__LINE__, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
				fileCloser(ifile);
				throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
			}


			progress = progress + bufSize;
			bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
		}
		if (i % percent == 0 || i == size - 1) {
			this->log(this->env, 1, "rw progress : %lld", progress);
			env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)progress);
		}
	}
	delete[] buf;
	this->log(this->env, 1, "DoIncReadWrite completed");
}

void VMDataCollector::generateException(int lineNumber, char* moduleName, string APIName, int errorCode, string errorMessage) {
	(env)->SetBooleanField(exceptionObject, exceptionOccuredFieldID, true);
	(env)->SetIntField(exceptionObject, lineNumberID, lineNumber);
	(env)->SetIntField(exceptionObject, errorCodeID, errorCode);

	const char *cerrorMessage = errorMessage.c_str();
	jstring jerrorMessage = env->NewStringUTF(cerrorMessage);
	env->SetObjectField(exceptionObject, errorMessageID, jerrorMessage);

	jstring jmoduleName = env->NewStringUTF(moduleName);
	env->SetObjectField(exceptionObject, moduleNameID, jmoduleName);

	const char *cAPIName = APIName.c_str();
	jstring jAPIName = env->NewStringUTF(cAPIName);
	env->SetObjectField(exceptionObject, APINameID, jAPIName);
}

void VMDataCollector::DoWriteMetadata() {
	this->log(env, 1, "DoWriteMetadata() started");

	VixDisk disk(this->appGlobals.connection, this->appGlobals.diskPath, this->appGlobals.openFlags, this, __LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setFullDiskInfo");
	std::ifstream infile(this->appGlobals.metaPath);
	std::string line;
	while (getline(infile, line)) {
		istringstream iss(line);
		string sub;
		string eq;
		string val;
		iss >> sub;
		const char *key = sub.c_str();
		if (sub.compare("uuid") == 0) {
			val = line.substr(7);
		}
		else {
			iss >> eq;
			iss >> val;
		}
		const char *value = val.c_str();
		//cout << "Final o/p : " << key << " = " << value << "\n";
		VixError vixError = VixDiskLib_WriteMetadata(disk.Handle(), key, value);
		if (vixError != VIX_OK) {
			this->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_setFullDiskInfo", __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
		}
		CHECK_AND_THROW(vixError);
	}
	infile.close();
	this->log(env, 1, "DoWriteMetadata() done ");

}

void VMDataCollector::DoDiffMaker(jobject incBackupDetails, jobject progressObject, char* moduleName, jobject diskReadWriteControl) {

	this->log(this->env, 1, "DoDiffMaker started");

	gzFile origFile;
	//gzFile diffFile;
	size_t bufSize;
	uint32 maxOps;
	boolean abort = false;

	long progress = 0;
	//env->CallNonvirtualLongMethod(progressObject, ProgressClass, setProgressMethodID, (jlong)progress);

	if (this->appGlobals.bufSize == 0) {
		this->appGlobals.bufSize = DEFAULT_BUFSIZE;
	}
	bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
	bool noDecryptError = false;
	if (this->storeDetails.isEncrypted) {
		int length = wcslen(this->appGlobals.woriginalPath) + 1;
		wchar_t* wtextSource = new wchar_t[length];
		if (this->appGlobals.woriginalPath != NULL) {
			wcscpy(wtextSource, this->appGlobals.woriginalPath);
		}
		LPTSTR tempFilePath = wtextSource;
		if (PathFileExists(tempFilePath) == 1) {
			this->log(this->env, 1, "File already exists no need to decrypt");
		}
		else {
			noDecryptError = this->protect(this->appGlobals.woriginalPath, this->storeDetails.secretKey, false);
			this->log(this->env, 1, "decryptStatus : %d", noDecryptError);
		}
		delete[] wtextSource;
	}


	//for non-english character handling
	//this->appGlobals.originalPath
	int fileDescriptor = _wopen(this->appGlobals.woriginalPath, _O_RDONLY | _O_BINARY);
	if (fileDescriptor == -1) {
		int errsv = errno;
		this->log(env, 1, "_wopen error : %d", errsv);
		this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "File open error");
		return;
	}
	else {
		this->log(env, 1, "_wopen done in DoDiffMaker()");
	}
	origFile = gzdopen(fileDescriptor, "rb");
	if (!origFile) {
		this->log(env, 1, "Compressed open error %s\n", this->appGlobals.woriginalPath);
		this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "File open error");
		return;
	}
	//origFile = gzopen(this->appGlobals.originalPath, "rb");


	VixDisk disk(this->appGlobals.connection, this->appGlobals.diskPath, this->appGlobals.openFlags, this, __LINE__, moduleName);
	VixError vixError;
	VixError err;
	int j;

	int size = (jint)env->CallIntMethod(incBackupDetails, listSizeID);
	uint64 last_seek = 0;
	env->CallObjectMethod(progressObject, setMaximumMethodID, (jlong)size);
	int percent = 1 + (size / 10);
	for (int i = 0; i < size; i++) {

		jobject incDetail = env->CallObjectMethod(incBackupDetails, listGetID, (jint)i);
		jstring startVal = (jstring)env->CallObjectMethod(incDetail, jMtdGetHashtable, env->NewStringUTF("OFFSET"));
		jstring length = (jstring)env->CallObjectMethod(incDetail, jMtdGetHashtable, env->NewStringUTF("LENGTH"));
		const char* cstr = env->GetStringUTFChars(startVal, 0);
		uint64 start = _strtoui64(cstr, NULL, 0);
		z_off_t pointer = start;
		start = start / VIXDISKLIB_SECTOR_SIZE;
		cstr = env->GetStringUTFChars(length, 0);
		uint64 len = _strtoui64(cstr, NULL, 0);
		len = len / VIXDISKLIB_SECTOR_SIZE;
		maxOps = len / this->appGlobals.bufSize;
		z_off_t bytes_seeked;
		bytes_seeked = gzseek(origFile, pointer, SEEK_SET);
		uint8 *buf = new uint8[bufSize];

		int bytes_read = 0;
		for (j = 0; j < maxOps; j++) {

			if (j % 1000 == 0 && !env->CallObjectMethod(diskReadWriteControl, proceedCheckID)) {
				abort = true;
				this->log(this->env, 1, "Disk RW Aborted from");
				this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Disk read|write was aborted during revert");
				break;
			}

			bytes_read = gzread(origFile, buf, bufSize);
			if (bytes_read <= 0) {
				this->log(this->env, 1, "Error has occurred in DoDiffMaker : gzread");
			}
			int err;
			const char * error_string;
			error_string = gzerror(origFile, &err);
			if (err) {
				this->log(this->env, 1, "DoDiffMaker gzerror");
				abort = true;
				break;
			}
			vixError = VixDiskLib_Write(disk.Handle(), start + (j * this->appGlobals.bufSize), this->appGlobals.bufSize, buf);

			if (VIX_FAILED(vixError)) {
				delete[] buf;
				this->log(this->env, 1, "Error has occurred in DoDiffMaker : VIX_FAILED");
				this->generateException(__LINE__, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
				throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
			}
			if (bytes_read < bufSize) {
				if (!gzeof(origFile)) {
					this->log(this->env, 1, "Error has occurred in DoDiffMaker : gzread bytes_read < bufSize");
				}
				break;
			}
		}

		if (abort) {
			break;
		}
		int frag = (len % this->appGlobals.bufSize) * VIXDISKLIB_SECTOR_SIZE;
		if (frag > 0) {
			int err;
			uint8 *buffer = new uint8[frag];
			int bytes_read;
			bytes_read = gzread(origFile, buffer, (unsigned int)frag);
			const char * error_string;
			error_string = gzerror(origFile, &err);
			if (err) {
				this->log(this->env, 1, "DoDiffMaker gzerror in fragmented read");
				abort = true;
				break;
			}
			if (bytes_read > 0) {
				vixError = VixDiskLib_Write(disk.Handle(), start + (j * this->appGlobals.bufSize), (len % this->appGlobals.bufSize), buffer);
				if (VIX_FAILED(vixError)) {
					this->log(this->env, 1, "Error has occurred in DoDiffMaker : VIX_FAILED gzread bytes_read > 0 ");
					delete[] buffer;
					delete[] buf;
					this->generateException(__LINE__, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
					throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
				}
			}
			else {
				this->log(this->env, 1, "DoDiffMaker : gzread did not read any bytes");
			}
			delete[] buffer;
		}
		//outfile.write ((char *)buf, bufSize);
		delete[] buf;
		if (i % percent == 0 || i == size - 1) {
			env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)(i + 1));
		}
	}
	this->log(this->env, 1, "DoDiffMaker completed");
     if(origFile !=NULL ){
            gzclose(origFile);
        }
	//delete wtextDest;
	//gzclose(diffFile);
	//outfile.close();
	if (this->storeDetails.isEncrypted && noDecryptError) {
		int length = wcslen(this->appGlobals.woriginalPath) + 1;
		wchar_t* wtextSource = new wchar_t[length];
		if (this->appGlobals.woriginalPath != NULL) {
			wcscpy(wtextSource, this->appGlobals.woriginalPath);
		}
		LPTSTR decryptedFile = wtextSource;
		bool isDeleted = DeleteFile(decryptedFile);
		if (!isDeleted)
		{
			this->log(this->env, 1, "DoDiffMaker - Delete failed first time");
			Sleep(5000);
			isDeleted = DeleteFile(decryptedFile);
			if (!isDeleted)
			{
				this->log(this->env, 1, "DoDiffMaker - Delete failed second time - error : %d", GetLastError());
			}
		}
		delete[] wtextSource;
	}

}

void VMDataCollector::DoIncReadWrite(jobject incBackupDetails, bool isRead, char* moduleName, jobject progressObject, jobject diskReadWriteControl) {
	this->log(this->env, 1, "DoIncReadWrite started");

	VixDisk disk(this->appGlobals.connection, this->appGlobals.diskPath, this->appGlobals.openFlags, this, __LINE__, moduleName);
	uint32 maxOps, j, bufUpdate;
	VixError err;
	boolean abort = false;
	size_t bufSize;
	uint8 *buf;
	if (this->appGlobals.bufSize == 0) {
		this->appGlobals.bufSize = DEFAULT_BUFSIZE;
	}
	bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
	buf = new uint8[bufSize];
	gzFile ofile;
	gzFile ifile;
	int size = (jint)env->CallIntMethod(incBackupDetails, listSizeID);

	//env->CallObjectMethod(progressObject, setMaximumMethodID, (jlong)size);
	bool noDecryptError = false;
	if (isRead) {
		//for non-english character handling
		int fileDescriptor = _wopen(this->appGlobals.wvmdkPath, _O_CREAT | _O_WRONLY | _O_BINARY, _S_IWRITE);
		if (fileDescriptor == -1) {
			int errsv = errno;
			this->log(env, 1, "_wopen error : %d", errsv);
			this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "File open error");
			return;
		}
		ofile = gzdopen(fileDescriptor, "wb1");
		if (!ofile) {
			this->log(env, 1, "Compressed open error %s\n", this->appGlobals.wvmdkPath);
			this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "File open error");
			return;
		}
		//ofile = gzopen(this->appGlobals.vmdkPath, "wb1");
	}
	else {
		if (this->storeDetails.isEncrypted) {
			int length = wcslen(this->appGlobals.wvmdkPath) + 1;
			wchar_t* wtextSource = new wchar_t[length];
			if (this->appGlobals.wvmdkPath != NULL) {
				wcscpy(wtextSource, this->appGlobals.wvmdkPath);
			}
			LPTSTR tempFilePath = wtextSource;
			if (PathFileExists(tempFilePath) == 1) {
				this->log(this->env, 1, "File already exists no need to decrypt");
			}
			else {
				noDecryptError = this->protect(this->appGlobals.wvmdkPath, this->storeDetails.secretKey, false);
				this->log(this->env, 1, "decryptStatus : %d", noDecryptError);
			}
			delete[] wtextSource;
		}
		//for non-english character handling
		int fileDescriptor = _wopen(this->appGlobals.wvmdkPath, _O_RDONLY | _O_BINARY);
		if (fileDescriptor == -1) {
			int errsv = errno;
			this->log(env, 1, "_wopen error : %d", errsv);
			this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "File open error");
			return;
		}
		ifile = gzdopen(fileDescriptor, "rb");
		if (!ifile) {
			this->log(env, 1, "Compressed open error %s\n", this->appGlobals.wvmdkPath);
			this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "File open error");
			return;
		}
		//ifile = gzopen(this->appGlobals.vmdkPath, "rb");
	}
	VixError vixError;
	int percent = 1 + (size / 10);
	__int64 progress = 0;
	for (int i = 0; i < size; i++) {
		jobject incDetail = env->CallObjectMethod(incBackupDetails, listGetID, (jint)i);
		jstring startVal = (jstring)env->CallObjectMethod(incDetail, jMtdGetHashtable, env->NewStringUTF("OFFSET"));
		jstring length = (jstring)env->CallObjectMethod(incDetail, jMtdGetHashtable, env->NewStringUTF("LENGTH"));
		const char* cstr = env->GetStringUTFChars(startVal, 0);
		uint64 start = _strtoui64(cstr, NULL, 0);
		cstr = env->GetStringUTFChars(length, 0);
		uint64 len = _strtoui64(cstr, NULL, 0);
		start = start / VIXDISKLIB_SECTOR_SIZE;
		len = len / VIXDISKLIB_SECTOR_SIZE;
		maxOps = len / this->appGlobals.bufSize;
		bufUpdate = 0;

		for (j = 0; j < maxOps; j++) {

			if (j % 1000 == 0 && !env->CallObjectMethod(diskReadWriteControl, proceedCheckID)) {
				abort = true;
				this->log(this->env, 1, "Disk RW Aborted from DoIncReadWrite()");
				this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Disk read|write was aborted");
				break;
			}

			if (isRead) {
				vixError = VixDiskLib_Read(disk.Handle(), start + (j * this->appGlobals.bufSize), this->appGlobals.bufSize, buf);
				if (VIX_FAILED(vixError)) {
					delete[] buf;
					this->generateException(__LINE__, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
					fileCloser(ofile);
					throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
				}
				gzwrite(ofile, buf, bufSize);
			}
			else {
				gzread(ifile, buf, bufSize);
				vixError = VixDiskLib_Write(disk.Handle(), start + (j * this->appGlobals.bufSize), this->appGlobals.bufSize, buf);
				if (VIX_FAILED(vixError)) {
					delete[] buf;
					this->generateException(__LINE__, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
					fileCloser(ifile);
					throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
				}
			}
			//outfile.write ((char *)buf, bufSize);
			bufUpdate += this->appGlobals.bufSize;
			if (bufUpdate >= BUFS_PER_STAT) {
				bufUpdate = 0;
			}
			len = len - this->appGlobals.bufSize;
			progress = progress + (this->appGlobals.bufSize*VIXDISKLIB_SECTOR_SIZE);
			//for every 1GB : since each loop is @2MB
			if (j % 500 == 0) {
				env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)progress);
			}
		}

		if (abort) {
			break;
		}

		if (len > 0) {
			bufSize = len * VIXDISKLIB_SECTOR_SIZE;
			if (isRead) {
				vixError = VixDiskLib_Read(disk.Handle(), start + (j * this->appGlobals.bufSize), len, buf);
				if (VIX_FAILED(vixError)) {
					delete[] buf;
					this->generateException(__LINE__, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
					fileCloser(ofile);
					throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
				}
				gzwrite(ofile, buf, bufSize);
			}
			else {
				gzread(ifile, buf, bufSize);
				vixError = VixDiskLib_Write(disk.Handle(), start + (j * this->appGlobals.bufSize), len, buf);
				if (VIX_FAILED(vixError)) {
					delete[] buf;
					this->generateException(__LINE__, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
					fileCloser(ifile);
					throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
				}
			}
			progress = progress + bufSize;
			bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
		}
		if (i % percent == 0 || i == size - 1) {
			this->log(this->env, 1, "rw progress : %lld", progress);
			env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)progress);
		}
	}
	delete[] buf;
	if (isRead) {
         if(ofile !=NULL ){
                gzclose(ofile);
        }

	}
	else {
         if(ifile !=NULL ){
                gzclose(ifile);
        }
	}
	this->log(this->env, 1, "DoIncReadWrite completed");

	//build index call
	wstring backupFile = this->appGlobals.wvmdkPath;
	int indexCreationResult = this->indexCreation(backupFile, false, NULL);
	this->log(this->env, 1, "indexCreationResult : %d", indexCreationResult);
	//outfile.close();
	//to delete the decrypted file
	if (!isRead && this->storeDetails.isEncrypted && noDecryptError) {
		int length = wcslen(this->appGlobals.wvmdkPath) + 1;
		wchar_t* wtextSource = new wchar_t[length];
		if (this->appGlobals.wvmdkPath != NULL) {
			wcscpy(wtextSource, this->appGlobals.wvmdkPath);
		}
		LPTSTR decryptedFile = wtextSource;
		bool isDeleted = DeleteFile(decryptedFile);
		if (!isDeleted)
		{
			this->log(this->env, 1, "DoIncReadWrite - Delete failed first time");
			Sleep(5000);
			isDeleted = DeleteFile(decryptedFile);
			if (!isDeleted)
			{
				this->log(this->env, 1, "DoIncReadWrite - Delete failed second time - error : %d", GetLastError());
			}
		}
		delete[] wtextSource;
	}
}

void VMDataCollector::disconnectExit() {
	this->log(env, 1, "disconnectExit() started");
	getLock();
	if (this->appGlobals.connection != NULL) {
		VixDiskLib_Disconnect(this->appGlobals.connection);
	}
	releaseLock();
	this->log(env, 1, "disconnectExit() done");

}

void VMDataCollector::getLock() {
	env->CallStaticVoidMethod(VMNativeHandlerClass, getLockID);
}

void VMDataCollector::releaseLock() {
	env->CallStaticVoidMethod(VMNativeHandlerClass, releaseLockID);
}

void VMDataCollector::initializeGlobals(jobject serverDetails, jstring diskPath, jobject storeDetails, char* moduleName) {
	this->log(env, 1, "initializeGlobals() started");

	memset(&this->appGlobals, 0, sizeof this->appGlobals);
	this->appGlobals.command = 0;
	this->appGlobals.adapterType = VIXDISKLIB_ADAPTER_SCSI_BUSLOGIC;
	this->appGlobals.startSector = 0;
	this->appGlobals.numSectors = 1;
	this->appGlobals.mbSize = 100;
	this->appGlobals.filler = 0xff;
	this->appGlobals.openFlags = 0;
	this->appGlobals.numThreads = 1;
	this->appGlobals.success = TRUE;
	this->appGlobals.isRemote = FALSE;
	this->appGlobals.isBackup = TRUE;

	int retval = this->ParseArguments(serverDetails, diskPath, storeDetails);
	if (retval) {
		this->log(this->env, 1, "Wrong Arguments !!");
		this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Error while initializing parameters");
		return;
	}

	VixDiskLibConnectParams cnxParams = { 0 };
	VixError vixError;

	try {
		if (this->appGlobals.isRemote) {
			cnxParams.serverName = this->appGlobals.host;
			cnxParams.credType = VIXDISKLIB_CRED_UID;
			cnxParams.creds.uid.userName = this->appGlobals.userName;
			cnxParams.creds.uid.password = this->appGlobals.password;
			cnxParams.thumbPrint = this->appGlobals.thumbPrint;
			//cnxParams.port = this->appGlobals.port;
			cnxParams.port = 0;
			cnxParams.vmxSpec = this->appGlobals.vmxSpec;
		}

		getLock();
		vixError = VixDiskLib_Connect(&cnxParams, &this->appGlobals.connection);
		releaseLock();

		if (vixError != VIX_OK) {
			this->generateException(__LINE__, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
		}
		CHECK_AND_THROW(vixError);
	}
	catch (const VixDiskLibErrWrapper& e) {
		this->generateException(e.Line(), moduleName, e.FunctionName(), e.ErrorCode(), e.Description());
		throw e;
	}
	this->log(env, 1, "initializeGlobals() done");
}

void VMDataCollector::disconnectLocation() {
	DWORD dwRetVal = WNetCancelConnection2(this->storeDetails.storeLPPath, 0, FALSE);
	this->log(this->env, 1, "disconnectLocation dwRetVal : %d", dwRetVal);
}

bool VMDataCollector::connectLocation() {
	NETRESOURCE nr;
	DWORD dwFlags;

	memset(&nr, 0, sizeof(NETRESOURCE));

	nr.dwType = RESOURCETYPE_ANY;
	nr.lpRemoteName = this->storeDetails.storeLPPath;
	nr.lpProvider = NULL;
	dwFlags = CONNECT_TEMPORARY;

	DWORD dwRetVal = WNetAddConnection2(&nr, this->storeDetails.storePwd, this->storeDetails.storeUserName, dwFlags);
	this->log(this->env, 1, "connectLocation dwRetVal : %d", dwRetVal);
	if (dwRetVal == NO_ERROR || dwRetVal == 1219) {
		this->log(this->env, 1, "Bind to path success !!");
		return 1;
	}
	else if (dwRetVal == 5) {
		this->log(this->env, 1, "Bind to path : Access_Denied");
	}
	else if (dwRetVal == 53) {
		this->log(this->env, 1, "Bind to path : Bad_Net_Path");
	}
	else if (dwRetVal == 67) {
		this->log(this->env, 1, "Bind to path : Bad_Net_Name");
	}
	else if (dwRetVal == 86) {
		this->log(this->env, 1, "Bind to path : Invalid_Password");
	}
	else if (dwRetVal == 1203) {
		this->log(this->env, 1, "Bind to path : NoNet_BadPath");
	}
	else if (dwRetVal == 1326) {
		this->log(this->env, 1, "Bind to path : Logon_Failure");
	}
	else if (dwRetVal == 2202) {
		this->log(this->env, 1, "Bind to path : Bad_UserName");
	}
	else {
		this->log(this->env, 1, "Bind to path : Other");
	}

	return 0;
}

void VMDataCollector::fileCloser(gzFile fileHandle) {
	    if (fileHandle != NULL)
        {
            gzclose(fileHandle);
        }
}

int VMDataCollector::doEfficientRestore(jstring diskPath, jstring restoreType, jobject finalDisksInfo, jobject finalIncrementalsInfo, jobject progressObject, char* moduleName) {
	this->log(env, 1, "doEfficientRestore() started");
	VixDisk disk(this->appGlobals.connection, this->appGlobals.diskPath, 1, this, __LINE__, moduleName);
	this->log(env, 1, "disk connection successful");
	size_t bufsize;
	uint8 *buf;
	uint8 *temp;
	VixError err;
	VixDiskLibInfo *info;
	int errorCode = 0;

	uint64 filledSectorCount;
	boolean isStarBackup = false;
	char *resultPath = (char *)env->GetStringUTFChars(diskPath, 0);

	size_t maximumSectorsCount = 4096 * 2;
	//size_t maximumSectorsCount = DEFAULT_BUFSIZE;
	bufsize = maximumSectorsCount * VIXDISKLIB_SECTOR_SIZE;
	int bufSize = 4096 * 2 * 512;
	buf = new uint8[bufsize];

	const char* restoreType_cstr = env->GetStringUTFChars(restoreType, 0);
	int restoretype = atoi(restoreType_cstr);

	int noOfIncrementals = (jint)env->CallIntMethod(finalIncrementalsInfo, listSizeID);
	int noOfFiles = (jint)env->CallIntMethod(finalDisksInfo, listSizeID);


	std::map<int, FileStructure*> indexToFileStructMap;
	this->log(env, 1, "Starting for loop");
	for (int j = 0; j < noOfFiles; j++) {
		FileStructure* fileStructure = (FileStructure*)malloc(sizeof(FileStructure));
		this->log(env, 1, "loop:%d", j);
		if (fileStructure == NULL) {
			errorCode = ERROR_COULD_NOT_ALLOCATE_MEMORY;
			break;
		}

		jobject fileMapper = env->CallObjectMethod(finalDisksInfo, listGetID, (jint)j);

		jstring jfilePath = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("FILEPATH"));
		jstring jfileIndex = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("FILEINDEX"));
		jstring jisStarBackup = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("IS_STAR_BACKUP"));
		jstring jfileType = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("FILETYPE"));
		jstring jisEncrypted = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("IS_ENCRYPTED"));
		jstring jsecretKey;

		this->log(env, 1, "after assigning values:%d", j);
		const char *fileIndex_cstr = (char *)env->GetStringUTFChars(jfileIndex, 0);
		int fileIndex = atoi(fileIndex_cstr);

		//mapping isStarBackup to fileStructure
		const char *isStarBackup_cstr = (char *)env->GetStringUTFChars(jisStarBackup, 0);
		if (isStarBackup == false) {
			if (strcmp(isStarBackup_cstr, "true") == 0) {
				isStarBackup = true;
			}
			else {
				isStarBackup = false;
			}
		}

		//mapping fileIndex to fileStructure
		const char *fileType_cstr = (char *)env->GetStringUTFChars(jfileType, 0);
		int fileType = atoi(fileType_cstr);
		fileStructure->filetype = fileType;

		//mapping isencrypted to fileStructure
		boolean isEncrypted;
		const char *isEncrypted_cstr = (char *)env->GetStringUTFChars(jisEncrypted, 0);
		if (strcmp(isEncrypted_cstr, "true") == 0) {
			jsecretKey = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("SECRETKEY"));
			LPWSTR secretKey = (LPWSTR)env->GetStringChars(jsecretKey, 0);
			isEncrypted = true;
			fileStructure->isencrypted = true;
			fileStructure->encryptionkey = secretKey;
		}
		else {
			fileStructure->isencrypted = false;
			fileStructure->encryptionkey = L"";
		}

		//mapping gzfile to fileStructure
		this->log(env, 1, "before mapping:%d", j);
		if (fileType == 0) {
			wchar_t* filePath_str = (wchar_t*)env->GetStringChars(jfilePath, 0);
			const char *filePath_cstr = (char *)env->GetStringUTFChars(jfilePath, 0);
			if (PathFileExists(filePath_str) == 1) {
				this->log(env, 1, "File already exists no need to decrypt");
				isEncrypted = false;
				fileStructure->isencrypted = false;
				fileStructure->encryptionkey = L"";
			}
			this->log(env, 1, "Starting File Management : %d", __LINE__);
			//if (isEncrypted || fileIndex==0)
			 {
				int length = wcslen(filePath_str) + 1;
				wchar_t *wtextDest;
				if(isEncrypted){
				    wtextDest = new wchar_t[(length + 7) * sizeof(WCHAR)];
                    wcscpy(wtextDest, filePath_str);
                    wcscat(wtextDest, L"_secure");
				}else{
				    wtextDest = new wchar_t[(length) * sizeof(WCHAR)];
                    wcscpy(wtextDest, filePath_str);
				}

				this->log(this->env, 1, "wtextdest");
				this->log(this->env, 1, "%ws", wtextDest);
				int fd = _wopen(wtextDest, _O_RDONLY | _O_BINARY);
				if (fd == -1) {
					this->log(env, 1, "file opening error in encrypted file _wopen");
					break;
				}
				else {
					this->log(env, 1, "File opened successfully _wopen");
				}

				FILE* InfileHandle = fdopen(fd, "rb");
				if (!InfileHandle) {
					this->log(env, 1, "compressed fdopen error");
					break;
				}
				else {
					this->log(env, 1, "compressed fdopen success");
				}

				fileStructure->filepointer = InfileHandle;
				this->log(env, 1, "Loading Index at %d for fileIndex: %d", __LINE__, fileIndex);

				{
					wstring backupFile(wtextDest);
					//size_t pos = backupFile.rfind(L".vmdk_secure");
					size_t pos = backupFile.rfind(L".vmdk");
					wstring indexName = backupFile.substr(0, pos) + L".idx";
					wstring fileName(backupFile.begin(), backupFile.end());
					wstring indexFile(indexName.begin(), indexName.end());

					this->log(env, 1, "Loading Index at %d for index file : %ws", __LINE__, indexFile.c_str());

					int fdForIndexedFile = _wopen(indexFile.c_str(), _O_RDONLY | _O_BINARY);
					if (fdForIndexedFile == -1) {
						int errsv = errno;
						this->log(env, 1, "_wopen index error : %d", errsv);
						//errorCode = ERROR_COULD_NOT_LOAD_INDEX;
						errorCode = 1;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Error : could not open index file");
						break;
					}
					else {
						this->log(env, 1, "fdForIndexedFile not -1 : A-OK [%d]", __LINE__);
					}
					gzFile gz = gzdopen(fdForIndexedFile, "rb");

					//gzFile gz = gzopen(indexFile.c_str(), "rb");
					if (gz == NULL) {
						printf("gz is null\n");
						this->log(env, 1, "gzdopen index error at %d", __LINE__);
						//errorCode = ERROR_COULD_NOT_LOAD_INDEX;
						errorCode = 1;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Error : could not open index file");
						break;
					}

					// Allocate a seekgzip_t instance.
					fileStructure->index = (struct access*)malloc(sizeof(struct access));
					if (fileStructure->index == NULL) {
						this->log(env, 1, "Index null.out of memory %d", __LINE__);
						//errorCode = ERROR_COULD_NOT_LOAD_INDEX;
						errorCode = 1;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Error : could not open index file");
						break;
					}
					memset(fileStructure->index, 0, sizeof(*fileStructure->index));

					// Read the number of entry points.
					fileStructure->index->have = fileStructure->index->size = read_uint32(gz);

					// Allocate an array for entry points.
					fileStructure->index->list = (struct point*)malloc(sizeof(struct point) * fileStructure->index->have);
					if (fileStructure->index->list == NULL) {
						this->log(env, 1, "Index->list empty %d", __LINE__);
					}
					this->log(env, 1, "Index size : %d", fileStructure->index->have);
					// Read entry points.
					for (int m = 0; m < fileStructure->index->have; ++m) {
						gzread(gz, &fileStructure->index->list[m].out, sizeof(__int64));
						gzread(gz, &fileStructure->index->list[m].in, sizeof(__int64));
						gzread(gz, &fileStructure->index->list[m].bits, sizeof(int));
						gzread(gz, fileStructure->index->list[m].window, WINSIZE);
					}
					if (gz != NULL) {
						gzclose(gz);
					}
				}


				this->log(env, 1, "Loading Index completed at %d for fileIndex: %d", __LINE__, fileIndex);
				fileStructure->gzfilepointer = NULL;
				delete[] wtextDest;
			}
//			else {
//				int fd = _wopen(filePath_str, _O_RDONLY | _O_BINARY);
//				if (fd == -1) {
//					this->log(env, 1, "error in openingfile with index[%d]", fileIndex);
//					break;
//				}
//				gzFile infile = gzdopen(fd, "rb");
//				fileStructure->gzfilepointer = infile;
//				fileStructure->filepointer = NULL;
//				fileStructure->index = NULL;
//			}
		}
		else {
			this->log(env, 1, "this is file type of 1");
			fileStructure->gzfilepointer = NULL;
			fileStructure->filepointer = NULL;
			fileStructure->index = NULL;
		}

		indexToFileStructMap.insert(pair<int, FileStructure*>(fileIndex, fileStructure));  //mapping fileStructure to appropriate index
	}

	int percent = 1 + (noOfIncrementals / 10);
	__int64 progress = 0;


	//starting filling data
	if (errorCode == 0) {
		VixError vixError;
		jstring jlength;
		jstring joffset;
		jobject incDetailsObject;
		jstring jseekLength;
		jstring jfileIndex;
		const char* fileindexcstr;
		const char* offsetcstr;
		const char* lengthcstr;
		const char* fileseeklengthcstr;
		uint64 offset;
		uint64 length;
		uint64 fileseeklength;
		uint64 currentOutputOffset = 0;
		filledSectorCount = 0;
		int fileIndex;
		FileStructure* fileStructForFull;
		FileStructure* fileStructForIncremental;
		FileStructure* fileStructForClosing;

		uint64 maxOpsForFull;
		uint64 remainingOpsForFull;
		uint64 noOfSectors;
		uint64 maxOpsForIncremental;
		uint64 remainingOpsForIncremental;

		auto keyValueForFull = indexToFileStructMap.find(0);
		fileStructForFull = (FileStructure *)keyValueForFull->second;
		for (int k = 0; k < noOfIncrementals; k++) {
			incDetailsObject = env->CallObjectMethod(finalIncrementalsInfo, listGetID, (jint)k);
			joffset = (jstring)env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, env->NewStringUTF("OFFSET"));
			jlength = (jstring)env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, env->NewStringUTF("LENGTH"));
			jfileIndex = (jstring)env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, env->NewStringUTF("FILEINDEX"));
			jseekLength = (jstring)env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, env->NewStringUTF("SEEKLENGTH"));

			offsetcstr = env->GetStringUTFChars(joffset, 0);
			offset = _strtoui64(offsetcstr, NULL, 0);

			fileindexcstr = env->GetStringUTFChars(jfileIndex, 0);
			fileIndex = atoi(fileindexcstr);

			lengthcstr = env->GetStringUTFChars(jlength, 0);
			length = _strtoui64(lengthcstr, NULL, 0);

			fileseeklengthcstr = env->GetStringUTFChars(jseekLength, 0);
			fileseeklength = _strtoui64(fileseeklengthcstr, NULL, 0);

			auto keyValueForIncremental = indexToFileStructMap.find(fileIndex);
			fileStructForIncremental = (FileStructure *)keyValueForIncremental->second;
            this->log(env, 1, "offset [%d], fileIndex [%d], length [%d], fileseeklength [%d]",offset,fileIndex,length, fileseeklength);
			//reading data from fullbackup file if it is not a star backup and it is full restore
			if (!isStarBackup && restoretype == 1) {
				noOfSectors = (offset - currentOutputOffset) / VIXDISKLIB_SECTOR_SIZE;
				maxOpsForFull = noOfSectors / maximumSectorsCount;
				remainingOpsForFull = noOfSectors % maximumSectorsCount;
//				if (fileStructForFull->isencrypted)
				{
					int checkPoint = 0;
					while (maxOpsForFull) {
					    int temp = -1;
					    if (fileStructForFull->isencrypted){
					        temp = extractDecrypt(fileStructForFull->filepointer, fileStructForFull->index, currentOutputOffset, buf, bufSize, fileStructForFull->encryptionkey);
					    }else{
					        temp = extract(fileStructForFull->filepointer, fileStructForFull->index, currentOutputOffset, buf, bufSize);
					    }


						vixError = VixDiskLib_Write(disk.Handle(), filledSectorCount, maximumSectorsCount, buf);

						if (VIX_FAILED(vixError) || temp < 0) {
							this->log(env, 1, "error in writing data from full backup encrypted file 1 at:[%d]", maxOpsForFull);
							errorCode = 1;
							break;
						}

						maxOpsForFull--;
						currentOutputOffset = currentOutputOffset + bufsize;
						filledSectorCount = filledSectorCount + maximumSectorsCount;
						checkPoint++;
						if (checkPoint % 100 == 0) {
							env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);
						}
					}

					if (errorCode == 0 && remainingOpsForFull) {
						int temp = (int)remainingOpsForFull * 512;
						int trial = -1;
						this->log(env, 1, "fileStructForFull->filepointer %d ",fileStructForFull->filepointer);
                        this->log(env, 1, "fileStructForFull->index %d ",fileStructForFull->index);
                        this->log(env, 1, "currentOutputOffset %d ",currentOutputOffset);
                        this->log(env, 1, "bufSize %d ",bufSize);
                        if (fileStructForFull->isencrypted){
                            this->log(env, 1, " %d ",__LINE__);
                            trial = extractDecrypt(fileStructForFull->filepointer, fileStructForFull->index, currentOutputOffset, buf, temp, fileStructForFull->encryptionkey);
                        }else{
                            this->log(env, 1, " %d ",__LINE__);
                            trial = extract(fileStructForFull->filepointer, fileStructForFull->index, currentOutputOffset, buf, temp);
                        }

						//int trial = extractDecrypt(fileStructForFull->filepointer, fileStructForFull->index, currentOutputOffset, buf, temp, fileStructForFull->encryptionkey);
						//int trial = extract(fileStructForFull->filepointer, fileStructForFull->index, currentOutputOffset, buf, temp);
						this->log(env, 1, "filledSectorCount %d ",filledSectorCount);
						this->log(env, 1, "remainingOpsForFull %d ",remainingOpsForFull);
						this->log(env, 1, "buf %d",buf);
						vixError = VixDiskLib_Write(disk.Handle(), filledSectorCount, remainingOpsForFull, buf);

						if (VIX_FAILED(vixError) || trial < 0) {
							this->log(env, 1, "error in writing data from full backup encrypted file 2 at:[%d]", remainingOpsForFull);
							this->log(env, 1, "error in writing data from full backup encrypted file vixError [%d], trial [%d]", vixError,trial);
							errorCode = 1;
							break;
						}

						currentOutputOffset = offset;
						filledSectorCount = filledSectorCount + remainingOpsForFull;
					}
				}
//				else {
//					gzseek(fileStructForFull->gzfilepointer, currentOutputOffset, SEEK_SET);
//					int checkPoint = 0;
//					while (maxOpsForFull) {
//						gzread(fileStructForFull->gzfilepointer, buf, bufsize);
//						vixError = VixDiskLib_Write(disk.Handle(), filledSectorCount, maximumSectorsCount, buf);
//
//						if (VIX_FAILED(vixError)) {
//							this->log(env, 1, "error in writing data from full backup file 1 at:[%d]", maxOpsForFull);
//							errorCode = 1;
//							break;
//						}
//
//						maxOpsForFull--;
//						currentOutputOffset = currentOutputOffset + bufsize;
//						filledSectorCount = filledSectorCount + maximumSectorsCount;
//						checkPoint++;
//						if (checkPoint % 100 == 0) {
//							env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);
//						}
//					}
//
//					if (errorCode == 0) {
//						gzread(fileStructForFull->gzfilepointer, buf, remainingOpsForFull * VIXDISKLIB_SECTOR_SIZE);
//						vixError = VixDiskLib_Write(disk.Handle(), filledSectorCount, remainingOpsForFull, buf);
//
//						if (VIX_FAILED(vixError)) {
//							this->log(env, 1, "error in writing data from full backup file 2 at:[%d]", remainingOpsForFull);
//							errorCode = 1;
//							break;
//						}
//
//						currentOutputOffset = offset;
//						filledSectorCount = filledSectorCount + remainingOpsForFull;
//					}
//				}
			}
			env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);

			//reading data from incremental change from appropriate file
			if (errorCode == 0) {
				int checkPoint = 0;
				noOfSectors = length / VIXDISKLIB_SECTOR_SIZE;
				maxOpsForIncremental = noOfSectors / maximumSectorsCount;
				remainingOpsForIncremental = noOfSectors % maximumSectorsCount;
				if (isStarBackup || (!isStarBackup && (restoretype == 3 || restoretype == 2))) {
					uint64 temp;
					filledSectorCount = offset / VIXDISKLIB_SECTOR_SIZE;
				}
				//if (fileStructForIncremental->isencrypted)
				{
					int checkPoint = 0;
					while (maxOpsForIncremental) {
					    int trial = -1;
					    if (fileStructForIncremental->isencrypted){
					        trial = extractDecrypt(fileStructForIncremental->filepointer, fileStructForIncremental->index, fileseeklength, buf, bufSize, fileStructForIncremental->encryptionkey);
					    }else{
					        trial = extract(fileStructForIncremental->filepointer, fileStructForIncremental->index, fileseeklength, buf, bufSize);
					    }
						vixError = VixDiskLib_Write(disk.Handle(), filledSectorCount, maximumSectorsCount, buf);

						if (VIX_FAILED(vixError) || trial<0) {
							this->log(env, 1, "error in writing data from incremental encrypted backup file 1 at:[%d]", maxOpsForIncremental);
							errorCode = 1;
							break;
						}
						currentOutputOffset = currentOutputOffset + bufsize;
						fileseeklength = fileseeklength + bufsize;
						filledSectorCount = filledSectorCount + maximumSectorsCount;
						maxOpsForIncremental--;
						checkPoint++;
						if (checkPoint % 100 == 0) {
							env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);
						}
					}
					if (errorCode == 0 && remainingOpsForIncremental) {
						int temp = (int)remainingOpsForIncremental * 512;
						int trial2 = -1;
                        if (fileStructForIncremental->isencrypted){
                            trial2 = extractDecrypt(fileStructForIncremental->filepointer, fileStructForIncremental->index, fileseeklength, buf, temp, fileStructForIncremental->encryptionkey);
                        }else{
                            trial2 = extract(fileStructForIncremental->filepointer, fileStructForIncremental->index, fileseeklength, buf, temp);
                        }
						//int trial2 = extractDecrypt(fileStructForIncremental->filepointer, fileStructForIncremental->index, fileseeklength, buf, temp, fileStructForIncremental->encryptionkey);
						vixError = VixDiskLib_Write(disk.Handle(), filledSectorCount, remainingOpsForIncremental, buf);

						if (VIX_FAILED(vixError) || trial2<0) {
							this->log(env, 1, "error in writing data from incremental encrypted backup file 2 at:[%d]", remainingOpsForIncremental);
							errorCode = 1;
							break;
						}
						currentOutputOffset = offset + length;
						filledSectorCount = filledSectorCount + remainingOpsForIncremental;
					}
				}
//				else {
//				    this->log(env, 1, "fileseeklength :[%d]", fileseeklength);
//					gzseek(fileStructForIncremental->gzfilepointer, fileseeklength, SEEK_SET);
//					int checkPoint = 0;
//					while (maxOpsForIncremental) {
//						gzread(fileStructForIncremental->gzfilepointer, buf, bufsize);
//						vixError = VixDiskLib_Write(disk.Handle(), filledSectorCount, maximumSectorsCount, buf);
//
//						if (VIX_FAILED(vixError)) {
//							this->log(env, 1, "error in writing data from incremental backup file 1 at:[%d]", maxOpsForIncremental);
//							errorCode = 1;
//							break;
//						}
//						currentOutputOffset = currentOutputOffset + bufsize;
//						filledSectorCount = filledSectorCount + maximumSectorsCount;
//						maxOpsForIncremental--;
//						checkPoint++;
//						if (checkPoint % 100 == 0) {
//							env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);
//						}
//					}
//					if (errorCode == 0) {
//						gzread(fileStructForIncremental->gzfilepointer, buf, remainingOpsForIncremental * VIXDISKLIB_SECTOR_SIZE);
//						vixError = VixDiskLib_Write(disk.Handle(), filledSectorCount, remainingOpsForIncremental, buf);
//
//						if (VIX_FAILED(vixError)) {
//							cout << "break2Rem" << endl;
//							this->log(env, 1, "error in writing data from incremental backup file 2 at:[%d]", remainingOpsForIncremental);
//							errorCode = 1;
//							break;
//						}
//						currentOutputOffset = offset + length;
//						filledSectorCount = filledSectorCount + remainingOpsForIncremental;
//					}
//
//				}

			}
			env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);

			if (errorCode == 1) {
				this->log(env, 1, "error in writing to disk");
				break;
			}
		}


		//reading remaining data from full backup file if it is not a star backup
		if (!isStarBackup && errorCode == 0 && restoretype == 1) {
			size_t num_read = 0;
			//if (/*fileStructForFull->isencrypted*/true)
			{
				int bytes_read;
				int checkPoint = 0;
				while (1) {
					//
					this->log(env, 1, "fileStructForFull->filepointer %d ",fileStructForFull->filepointer);
					this->log(env, 1, "fileStructForFull->index %d ",fileStructForFull->index);
					this->log(env, 1, "currentOutputOffset %d ",currentOutputOffset);
					this->log(env, 1, "bufSize %d ",bufSize);
					if(fileStructForFull->isencrypted){
					    bytes_read = extractDecrypt(fileStructForFull->filepointer, fileStructForFull->index, currentOutputOffset, buf, bufSize, fileStructForFull->encryptionkey);
					}else{
					    bytes_read = extract(fileStructForFull->filepointer, fileStructForFull->index, currentOutputOffset, buf, bufSize);
					}

					this->log(env, 1, "bytes_read %d ",bytes_read);
					if (bytes_read < 0) {
						this->log(this->env, 1, "Error has occurred in extractDecrypt of Efficient Restore module");
						errorCode = 1;
						break;
					}
					else {

						noOfSectors = bytes_read / VIXDISKLIB_SECTOR_SIZE;
						this->log(env, 1, "noOfSectors %d ",noOfSectors);
						vixError = VixDiskLib_Write(disk.Handle(), filledSectorCount, noOfSectors, buf);
						this->log(env, 1, "vixError %d ",vixError);

						if (VIX_FAILED(vixError)) {
							this->log(env, 1, "error in writing data from remaining full backup encrypted file 1");
							errorCode = 1;
						}

					}

					if (bytes_read < bufSize) {
						if (feof(fileStructForFull->filepointer)) {
							this->log(env, 1, "Finally here");
							break;
						}
					}

					currentOutputOffset = currentOutputOffset + (noOfSectors * VIXDISKLIB_SECTOR_SIZE);
					filledSectorCount = filledSectorCount + noOfSectors;
					checkPoint++;
					if (checkPoint % 100 == 0) {
						env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);
					}
				}
			}
//			else {
//				int checkPoint = 0;
//				gzseek(fileStructForFull->gzfilepointer, currentOutputOffset, SEEK_SET);
//				this->log(env, 1, "currentOutputOffset : %d ",currentOutputOffset);
//				while ((num_read = gzread(fileStructForFull->gzfilepointer, buf, bufsize)) > 0) {
//		            this->log(env, 1, "num_read : %d ",num_read);
//					noOfSectors = num_read / VIXDISKLIB_SECTOR_SIZE;
//					this->log(env, 1, "filledSectorCount : %d ",filledSectorCount);
//					this->log(env, 1, "noOfSectors : %d ",noOfSectors);
//					this->log(env, 1, "buf : %d ",buf);
//					this->log(env, 1, "disk.Handle() : %d ",disk.Handle());
//					vixError = VixDiskLib_Write(disk.Handle(), filledSectorCount, noOfSectors, buf);
//
//					if (VIX_FAILED(vixError)) {
//						this->log(env, 1, "error in writing data from remaining full backup file 1");
//					}
//					currentOutputOffset = currentOutputOffset + (noOfSectors * VIXDISKLIB_SECTOR_SIZE);
//					filledSectorCount = filledSectorCount + noOfSectors;
//					checkPoint++;
//					if (checkPoint % 100 == 0) {
//						env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);
//					}
//				}
//			}

		}

		//closing of all gzread files
		for (int i = 0; i < noOfFiles - 1; i++) {
			this->log(env, 1, "closing all opened files");
			auto keyValueForClosing = indexToFileStructMap.find(i);
			fileStructForClosing = (FileStructure *)keyValueForClosing->second;
			//if (fileStructForClosing->isencrypted)
			{
				fclose(fileStructForClosing->filepointer);
			}
//			else {
//				    if (fileStructForClosing->gzfilepointer != NULL)
//                    {
//                        gzclose(fileStructForClosing->gzfilepointer);
//                    }
//			}
		}

		for (int i = 0; i < indexToFileStructMap.size(); i++) {
			auto keyValue = indexToFileStructMap.find(i);
			FileStructure* fileStruct = (FileStructure *)keyValue->second;
			if (fileStruct->index != NULL)
			{
				if (fileStruct->index->list != NULL) {
					delete fileStruct->index->list;
				}
				delete fileStruct->index;
			}
			delete fileStruct;
		}

	}
	else {
		this->log(env, 1, "some Error Occurred");
	}
	return errorCode;
}

void VMDataCollector::DoRWBench(bool read, char * moduleName, jobject progressObject, jobject diskReadWriteControl) {
	this->log(this->env, 1, "API called DoRWBench()");

	VixDisk disk(this->appGlobals.connection, this->appGlobals.diskPath, this->appGlobals.openFlags, this, __LINE__, moduleName);
	size_t bufSize;
	uint8 *buf;
	VixDiskLibInfo *info;
	VixError err;
	uint32 maxOps, i;
	uint32 bufUpdate;
	//std::ifstream infile;
	//std::ofstream outfile;
	gzFile ofile;
	gzFile ifile;
	bool noDecryptError = false;

	if (read) {
		//for non-english character handling
		int fileDescriptor = _wopen(this->appGlobals.wvmdkPath, _O_CREAT | _O_WRONLY | _O_BINARY, _S_IWRITE);
		//printf("open returned %d\n", fileDescriptor);
		//cout << __LINE__;

		////std::ofstream out("output.txt");
		////out << this->appGlobals.vmdkPath;
		////out.close();

		if (fileDescriptor == -1) {
			int errsv = errno;
			this->log(env, 1, "gzdopen error : %d", errsv);
			this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "File open error");
			return;
		}
		ofile = gzdopen(fileDescriptor, "wb1");
		//ofile = gzopen_w(this->appGlobals.wOriginalPath, "wb1");

		//ofile = gzopen(this->appGlobals.vmdkPath, "wb1");
		if (ofile == Z_NULL) {
			this->log(this->env, 1, "Error Opening File");
			this->log(this->env, 1, this->appGlobals.vmdkPath);
			this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "File open error");
			return;
		}
		this->log(this->env, 1, "DoRWBench() : File opened successfully for full backup");

		//outfile.open(appGlobals.vmdkPath, ios::out | ios::app | ios::binary);
	}
	else {
		if (this->storeDetails.isEncrypted) {
			this->log(this->env, 1, "DoRWBench() : isEncrypted");
			int length = wcslen(this->appGlobals.wvmdkPath) + 1;
			wchar_t* wtextSource = new wchar_t[length];
			if (this->appGlobals.wvmdkPath != NULL) {
				wcscpy(wtextSource, this->appGlobals.wvmdkPath);
			}
			LPTSTR tempFilePath = wtextSource;
			if (PathFileExists(tempFilePath) == 1) {
				this->log(this->env, 1, "File already exists no need to decrypt");
			}
			else {
				noDecryptError = this->protect(this->appGlobals.wvmdkPath, this->storeDetails.secretKey, false);
				this->log(this->env, 1, "decryptStatus : %d", noDecryptError);
			}
			delete[] wtextSource;
		}
		//for non-english character handling
		int fileDescriptor = _wopen(this->appGlobals.wvmdkPath, _O_RDONLY | _O_BINARY);
		if (fileDescriptor == -1) {
			int errsv = errno;
			this->log(env, 1, "_wopen error : %d", errsv);
			this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "File open error");
			return;
		}
		ifile = gzdopen(fileDescriptor, "rb");
		//ifile = gzopen(this->appGlobals.vmdkPath, "rb");
		if (ifile == Z_NULL) {
			this->log(this->env, 1, "Error Opening File");
			this->log(this->env, 1, this->appGlobals.vmdkPath);
			this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "File open error");
			return;
		}

		this->log(this->env, 1, "DoRWBench() : File opened successfully for full restore");

		/*infile.open(appGlobals.vmdkPath, ios::in | ios::binary | ios::app );
		if(!infile.is_open())
		{
		printf("The backup file is not valid !!");
		return;
		}*/
	}

	if (this->appGlobals.bufSize == 0) {
		this->appGlobals.bufSize = DEFAULT_BUFSIZE;
	}
	bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;

	buf = new uint8[bufSize];

	err = VixDiskLib_GetInfo(disk.Handle(), &info);
	if (VIX_FAILED(err)) {
		delete[] buf;
		this->generateException(__LINE__, moduleName, __FUNCTION__, err, VixDiskLib_GetErrorText(err, NULL));
		throw VixDiskLibErrWrapper(err, __FILE__, __LINE__, __FUNCTION__);
	}

	maxOps = info->capacity / this->appGlobals.bufSize;


	env->CallObjectMethod(progressObject, setMaximumMethodID, (jlong)maxOps);

	VixDiskLib_FreeInfo(info);
	bufUpdate = 0;
	for (i = 0; i < maxOps; i++) {
		VixError vixError;

		if (i % 1000 == 0 && !env->CallObjectMethod(diskReadWriteControl, proceedCheckID)) {
			this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Disk read|write aborted");
			break;
		}
		if (read) {
			vixError = VixDiskLib_Read(disk.Handle(),
				i * this->appGlobals.bufSize,
				this->appGlobals.bufSize, buf);
			//outfile.write ((char *)buf,bufSize);
			gzwrite(ofile, buf, bufSize);
		}
		else {
			int vvv = gzread(ifile, buf, bufSize);
			//infile.read((char *)buf,bufSize);
			vixError = VixDiskLib_Write(disk.Handle(),
				i * this->appGlobals.bufSize,
				this->appGlobals.bufSize, buf);

		}
		if (i % 100 == 0 || i == maxOps - 1) {
			env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)(i + 1));
		}
		if (VIX_FAILED(vixError)) {
			delete[] buf;
			this->generateException(__LINE__, moduleName, __FUNCTION__, vixError, VixDiskLib_GetErrorText(vixError, NULL));
			if (read) {
            if (ofile != NULL)
            {
                gzclose(ofile);
            }
				//outfile.close();
			}
			else {
                if (ifile != NULL)
                {
                    gzclose(ifile);
                }
				//infile.close();
			}
			throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
		}

		bufUpdate += this->appGlobals.bufSize;
		if (bufUpdate >= BUFS_PER_STAT) {
			/*if(read){
			outfile.close();
			char fileName[200];
			strcpy(fileName, appGlobals.vmdkPath);
			std::string s = std::to_string(i);
			char const *pchar = s.c_str();
			strcat(fileName,pchar);
			outfile.open(fileName, ios::out | ios::app | ios::binary);
			}*/
			bufUpdate = 0;
		}
	}
	delete[] buf;

	if (read) {
        if (ofile != NULL)
        {
            gzclose(ofile);
        }
		//outfile.close();
	}
	else {
        if (ifile != NULL)
        {
            gzclose(ifile);
        }
		//infile.close();
	}

	//build index call
	wstring backupFile = this->appGlobals.wvmdkPath;
	int indexCreationResult = this->indexCreation(backupFile, false, NULL);
	this->log(this->env, 1, "indexCreationResult : %d", indexCreationResult);



	//FILE *ip = fopen(appGlobals.vmdkPath, "rb");
	//FILE *op = fopen("D:\\Compress.zip", "wb");

	//def(ip,op,Z_DEFAULT_COMPRESSION);

	//to delete the decrypted file
	if (!read && this->storeDetails.isEncrypted && noDecryptError) {
		int length = wcslen(this->appGlobals.wvmdkPath) + 1;
		wchar_t* wtextSource = new wchar_t[length];
		if (this->appGlobals.wvmdkPath != NULL) {
			wcscpy(wtextSource, this->appGlobals.wvmdkPath);
		}
		LPTSTR decryptedFile = wtextSource;
		bool isDeleted = DeleteFile(decryptedFile);
		if (!isDeleted)
		{
			this->log(this->env, 1, "DoRWBench - Delete failed first time");
			Sleep(5000);
			isDeleted = DeleteFile(decryptedFile);
			if (!isDeleted)
			{
				this->log(this->env, 1, "DoRWBench - Delete failed second time - error : %d", GetLastError());
			}
		}
		delete[] wtextSource;
	}

	this->log(this->env, 1, "DoRWBench() completed");

}

void VMDataCollector::DoDumpMetadata() {

	this->log(this->env, 1, "DoDumpMetadata() started");


	VixDisk disk(this->appGlobals.connection, this->appGlobals.diskPath, this->appGlobals.openFlags, this, __LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getFullDiskInfo");
	char *key;
	size_t requiredLen;

	VixError vixError = VixDiskLib_GetMetadataKeys(disk.Handle(),
		NULL, 0, &requiredLen);
	if (vixError != VIX_OK && vixError != VIX_E_BUFFER_TOOSMALL) {
		THROW_ERROR(vixError);
	}
	std::wofstream outfile(this->appGlobals.wmetaPath);

	std::vector<char> buf(requiredLen);
	vixError = VixDiskLib_GetMetadataKeys(disk.Handle(), &buf[0], requiredLen, NULL);

	if (vixError != VIX_OK) {
		outfile.close();
		this->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getFullDiskInfo", __FUNCTION__, vixError, "Error while trying to fetching metadata");
	}
	CHECK_AND_THROW(vixError);
	key = &buf[0];

	while (*key) {
		vixError = VixDiskLib_ReadMetadata(disk.Handle(), key, NULL, 0, &requiredLen);
		if (vixError != VIX_OK && vixError != VIX_E_BUFFER_TOOSMALL) {
			this->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getFullDiskInfo", __FUNCTION__, vixError, "Error while trying to read metadata");
			outfile.close();
			THROW_ERROR(vixError);
		}
		std::vector <char> val(requiredLen);
		vixError = VixDiskLib_ReadMetadata(disk.Handle(), key, &val[0], requiredLen, NULL);

		if (vixError != VIX_OK) {
			this->generateException(__LINE__, "Java_com_manageengine_rmp_virtual_VMNativeHandler_getFullDiskInfo", __FUNCTION__, vixError, "Error while trying to write metadata");
		}
		CHECK_AND_THROW(vixError);
		outfile << key << " = " << &val[0] << endl;
		key += (1 + strlen(key));

	}
	outfile.close();
	this->log(this->env, 1, "DoDumpMetadata() done");

}

int VMDataCollector::setStoreDetails(jobject storeInfo) {

	this->log(this->env, 1, "setStoreDetails() started");

	jstring storeUser, storePwd, storeBasePath;

	storeBasePath = (jstring)env->CallObjectMethod(storeInfo, jMtdGetHashtable, env->NewStringUTF("REPOSITORY_PATH"));
	storeUser = (jstring)env->CallObjectMethod(storeInfo, jMtdGetHashtable, env->NewStringUTF("USERNAME"));
	storePwd = (jstring)env->CallObjectMethod(storeInfo, jMtdGetHashtable, env->NewStringUTF("PASSWORD"));

	this->storeDetails.storeLPPath = (LPWSTR)env->GetStringChars(storeBasePath, 0);
	this->storeDetails.storeUserName = (LPWSTR)env->GetStringChars(storeUser, 0);
	this->storeDetails.storePwd = (LPWSTR)env->GetStringChars(storePwd, 0);

	this->log(this->env, 1, "setStoreDetails() done");

	return 0;
}

void VMDataCollector::replace(char * path, char source, char target) {
	int len = strlen(path);
	int i;
	for (i = 0; i < len; i++) {
		if (*(path + i) == source) {
			*(path + i) = target;
		}
	}
}

void VMDataCollector::wreplace(wchar_t * path, wchar_t source, wchar_t target) {
	int len = wcslen(path);
	int i;
	for (i = 0; i < len; i++) {
		if (*(path + i) == source) {
			*(path + i) = target;
		}
	}
}

int VMDataCollector::ParseArguments(jobject serverDetails, jstring diskPath, jobject storeInfo) {

	this->log(this->env, 1, "ParseArguments() started");


	jstring hostNameIp, userName, pwd, vmxSpec, sslThumbPrint, originalvmlocation;
	jstring storevmLocation;
	jstring vmDiskBackupLocation;


	hostNameIp = (jstring)env->CallObjectMethod(serverDetails, jMtdGetHashtable, env->NewStringUTF("SERVER_NAME"));
	userName = (jstring)env->CallObjectMethod(serverDetails, jMtdGetHashtable, env->NewStringUTF("USER_NAME"));
	pwd = (jstring)env->CallObjectMethod(serverDetails, jMtdGetHashtable, env->NewStringUTF("PASSWORD"));
	vmxSpec = (jstring)env->CallObjectMethod(serverDetails, jMtdGetHashtable, env->NewStringUTF("VMXSPEC"));
	sslThumbPrint = (jstring)env->CallObjectMethod(serverDetails, jMtdGetHashtable, env->NewStringUTF("SSL"));

	this->appGlobals.host = (char *)env->GetStringUTFChars(hostNameIp, 0);
	this->appGlobals.userName = (char *)env->GetStringUTFChars(userName, 0);
	this->appGlobals.password = (char *)env->GetStringUTFChars(pwd, 0);
	this->appGlobals.diskPath = (char *)env->GetStringUTFChars(diskPath, 0);


	this->appGlobals.vmxSpec = "";
	if (vmxSpec != nullptr) {
		this->appGlobals.vmxSpec = (char *)env->GetStringUTFChars(vmxSpec, 0);
	}

	this->appGlobals.thumbPrint = (char *)env->GetStringUTFChars(sslThumbPrint, 0);
	this->appGlobals.isRemote = TRUE;
	if (storeInfo == NULL) {
		return 0;
	}
	storevmLocation = (jstring)env->CallObjectMethod(storeInfo, jMtdGetHashtable, env->NewStringUTF("REPOSITORY_VM_PATH"));
	char *storePath = (char *)env->GetStringUTFChars(storevmLocation, 0);



	//FlashBack
	originalvmlocation = (jstring)env->CallObjectMethod(storeInfo, jMtdGetHashtable, env->NewStringUTF("PATH"));
	if (originalvmlocation != nullptr) {
		char *originalvmpath = (char *)env->GetStringUTFChars(originalvmlocation, 0);


		vmDiskBackupLocation = (jstring)env->CallObjectMethod(storeInfo, jMtdGetHashtable, env->NewStringUTF("VM_FULL_DISK_NAME"));

		if (vmDiskBackupLocation != nullptr) {
			char *vmFullDiskBackupPath = (char *)env->GetStringUTFChars(vmDiskBackupLocation, 0);


			this->replace(vmFullDiskBackupPath, '/', '_');
			this->appGlobals.originalPath = (char *)malloc(strlen(originalvmpath) + strlen(vmFullDiskBackupPath) + 1);
			strcpy(this->appGlobals.originalPath, originalvmpath);
			strcat(this->appGlobals.originalPath, vmFullDiskBackupPath);


			int len = env->GetStringLength(vmDiskBackupLocation) + env->GetStringLength(originalvmlocation) + 1;
			this->appGlobals.woriginalPath = new WCHAR[len]; /* new wchar_t* value in appGlobals*/
			ZeroMemory(this->appGlobals.woriginalPath, len * (sizeof(WCHAR))); /*WinBase.h*/
			wchar_t* temp = (wchar_t*)env->GetStringChars(originalvmlocation, 0);
			wcscpy(this->appGlobals.woriginalPath, temp);
			env->ReleaseStringChars(originalvmlocation, (jchar *)temp);

			temp = (wchar_t*)env->GetStringChars(vmDiskBackupLocation, 0);
			this->wreplace(temp, L'/', L'_');
			wcscat(this->appGlobals.woriginalPath, temp);
			env->ReleaseStringChars(vmDiskBackupLocation, (jchar *)temp);

		}


	}

	vmDiskBackupLocation = (jstring)env->CallObjectMethod(storeInfo, jMtdGetHashtable, env->NewStringUTF("VM_BACKUP_DISKPATH"));
	char *vmDiskBackupPath = (char *)env->GetStringUTFChars(vmDiskBackupLocation, 0);

	int len = env->GetStringLength(vmDiskBackupLocation) + env->GetStringLength(storevmLocation) + 1;
	this->appGlobals.wvmdkPath = new WCHAR[len]; /* new wchar_t* value in appGlobals*/
	ZeroMemory(this->appGlobals.wvmdkPath, len * (sizeof(WCHAR))); /*WinBase.h*/
	wchar_t* temp = (wchar_t*)env->GetStringChars(storevmLocation, 0);
	wcscpy(this->appGlobals.wvmdkPath, temp);
	env->ReleaseStringChars(storevmLocation, (jchar *)temp);

	temp = (wchar_t*)env->GetStringChars(vmDiskBackupLocation, 0);
	this->wreplace(temp, L'/', L'_');
	wcscat(this->appGlobals.wvmdkPath, temp);
	env->ReleaseStringChars(vmDiskBackupLocation, (jchar *)temp);

	//std::ofstream out("output.txt");
	//out << this->appGlobals.wOriginalPath;
	//out.close();

	this->replace(vmDiskBackupPath, '/', '_');
	this->appGlobals.vmdkPath = (char *)malloc(strlen(storePath) + strlen(vmDiskBackupPath) + 1);
	strcpy(this->appGlobals.vmdkPath, storePath);
	strcat(this->appGlobals.vmdkPath, vmDiskBackupPath);

	char *metaEnd = "_META.txt";
	this->replace(vmDiskBackupPath, '/', '_');
	this->appGlobals.metaPath = (char *)malloc(strlen(storePath) + strlen(vmDiskBackupPath) + strlen(metaEnd) + 1);
	strcpy(this->appGlobals.metaPath, storePath);
	strcat(this->appGlobals.metaPath, vmDiskBackupPath);
	strcat(this->appGlobals.metaPath, metaEnd);



	len = env->GetStringLength(vmDiskBackupLocation) + env->GetStringLength(storevmLocation) + strlen(metaEnd) + 1;
	this->appGlobals.wmetaPath = new WCHAR[len]; /* new wchar_t* value in appGlobals*/
	ZeroMemory(this->appGlobals.wmetaPath, len * (sizeof(WCHAR))); /*WinBase.h*/
	temp = (wchar_t*)env->GetStringChars(storevmLocation, 0);
	wcscpy(this->appGlobals.wmetaPath, temp);
	env->ReleaseStringChars(storevmLocation, (jchar *)temp);

	temp = (wchar_t*)env->GetStringChars(vmDiskBackupLocation, 0);
	this->wreplace(temp, L'/', L'_');
	wcscat(this->appGlobals.wmetaPath, temp);
	env->ReleaseStringChars(vmDiskBackupLocation, (jchar *)temp);

	wcscat(this->appGlobals.wmetaPath, L"_META.txt");

	this->appGlobals.bufSize = 4096 * 2;

	//for encryption starts
	jstring secretKey;
	jobject isEncryptedInt = env->CallObjectMethod(storeInfo, jMtdGetHashtable, env->NewStringUTF("IS_ENCRYPTED_INT"));

	jclass integerClass = env->FindClass("java/lang/Integer");
	jmethodID integerID = env->GetMethodID(integerClass, "intValue", "()I");
	jint jintVal = (jint)env->CallIntMethod(isEncryptedInt, integerID);
	int isEncrypted = (int)jintVal;

	secretKey = (jstring)env->CallObjectMethod(storeInfo, jMtdGetHashtable, env->NewStringUTF("SECRETKEY"));
	//for encryption start
	if (isEncrypted) {
		this->storeDetails.isEncrypted = true;
	}
	else {
		this->storeDetails.isEncrypted = false;
	}

	this->storeDetails.secretKey = (LPWSTR)env->GetStringChars(secretKey, 0);

	//for encryption ends


	if (this->appGlobals.isRemote) {
		if (this->appGlobals.port == 0) {
			this->appGlobals.port = 902;
		}
	}

	this->log(this->env, 1, "ParseArguments() done");

	return 0;
}

int VMDataCollector::DoSyntheticFullBackup(jobject incrementalArrayList, jobject filelist, char* moduleName, jobject progressObject, jobject diskReadWriteControl) {
	this->log(this->env, 1, "DoSyntheticFullBackup started");
	int errorCode = 0;
	gzFile ofile;
	this->log(env, 1, "Starting VixDisk disk() call at : %d", __LINE__);
	VixDisk disk(this->appGlobals.connection, this->appGlobals.diskPath, this->appGlobals.openFlags, this, __LINE__, moduleName);
	this->log(env, 1, "Starting VixDisk disk() call completed at : %d", __LINE__);

	int incrementalArrayListSize = (jint)env->CallIntMethod(incrementalArrayList, listSizeID);
	int filelistSize = (jint)env->CallIntMethod(filelist, listSizeID);

	env->CallObjectMethod(progressObject, setMaximumMethodID, (jlong)(incrementalArrayListSize + 1));

	int outfileDescriptor = _wopen(this->appGlobals.wvmdkPath, _O_CREAT | _O_WRONLY | _O_BINARY, _S_IWRITE);
	if (outfileDescriptor == -1) {
		int errsv = errno;
		this->log(env, 1, "_wopen error : %d", errsv);
		this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : ERROR_COULD_NOT_CREATE_BACKUP_FILE_WOPEN");
		return ERROR_COULD_NOT_CREATE_BACKUP_FILE;
	}
	else {
		this->log(env, 1, "outfileDescriptor not -1 : A-OK [%d]", __LINE__);
	}
	ofile = gzdopen(outfileDescriptor, "wb1");
	if (!ofile) {
		this->log(env, 1, "Compressed open error %s\n", this->appGlobals.wvmdkPath);
		this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : ERROR_COULD_NOT_CREATE_BACKUP_FILE_GZDOPEN");
		return ERROR_COULD_NOT_CREATE_BACKUP_FILE;
	}
	else {
		this->log(env, 1, "No gzdopen errors [%d]", __LINE__);
	}
	//filesopener
	std::map<int, FileStructure*> indexToFileStructMap;

	boolean isStarBackup = false;
	{
		for (int i = 0; i < filelistSize; i++) {

			FileStructure* fileStructure = (FileStructure*)malloc(sizeof(FileStructure));

			if (fileStructure == NULL) {
				errorCode = ERROR_COULD_NOT_ALLOCATE_MEMORY;
				break;
			}
			jobject fileMapper = env->CallObjectMethod(filelist, listGetID, (jint)i);
			jstring jfileIndex = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("FILEINDEX"));
			jstring jfilePath = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("FILEPATH"));
			jstring jfileType = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("FILETYPE"));
			jstring jisStarBackup = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("IS_STAR_BACKUP"));
			jstring jisEncrypted = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("IS_ENCRYPTED"));
			jstring jisSecretKey;

			const char* fileindexcstr = env->GetStringUTFChars(jfileIndex, 0);
			uint64 fileIndex = _strtoui64(fileindexcstr, NULL, 0);

			const char* isStarBackupChar = env->GetStringUTFChars(jisStarBackup, 0);
			if (isStarBackup == false) {
				if (strcmp(isStarBackupChar, "true") == 0) {
					isStarBackup = true;
				}
				else {
					isStarBackup = false;
				}
			}
			const char* filetypecstr = env->GetStringUTFChars(jfileType, 0);
			uint64 fileType = _strtoui64(filetypecstr, NULL, 0);
			fileStructure->filetype = fileType;

			const char* isEncryptedChar = env->GetStringUTFChars(jisEncrypted, 0);
			boolean isEncrypted = false;
			if (strcmp(isEncryptedChar, "true") == 0) {
				jisSecretKey = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("SECRETKEY"));
				LPWSTR secretKey = (LPWSTR)env->GetStringChars(jisSecretKey, 0);
				isEncrypted = true;
				fileStructure->isencrypted = true;
				fileStructure->encryptionkey = secretKey;

			}
			else {
				fileStructure->isencrypted = false;
				fileStructure->encryptionkey = L"";
			}

			if (fileType == 0) { //normal files in repository
				wchar_t* filePath = (wchar_t*)env->GetStringChars(jfilePath, 0);

				if (PathFileExists(filePath) == 1) {
					this->log(this->env, 1, "File already exists no need to decrypt");
					isEncrypted = false;
					fileStructure->isencrypted = false;
					fileStructure->encryptionkey = L"";
				}
				this->log(env, 1, "Starting File Management : %d", __LINE__);
				if (isEncrypted) {

					int length = wcslen(filePath) + 1;
					wchar_t *wtextDest = new wchar_t[(length + 7)];
					wcscpy(wtextDest, filePath);
					wcscat(wtextDest, L"_secure");
					this->log(this->env, 1, "wtextdest");
					this->log(this->env, 1, "%ws", wtextDest);
					int fd = _wopen(wtextDest, _O_RDONLY | _O_BINARY);

					if (fd == -1) {
						int errsv = errno;
						this->log(env, 1, "_wopen error : %d", errsv);
						errorCode = ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS");
						break;
					}
					else {
						this->log(env, 1, "fd not -1 : A-OK [%d]", __LINE__);
					}
					FILE* InfileHandle = fdopen(fd, "rb");
					if (!InfileHandle) {
						this->log(env, 1, "Compressed fdopen error %s\n", this->appGlobals.woriginalPath);
						errorCode = ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_FDOPEN;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_FDOPEN");
						break;
					}
					fileStructure->filepointer = InfileHandle;
					this->log(env, 1, "Loading Index at %d for fileIndex: %d", __LINE__, fileIndex);
					{
						wstring backupFile(wtextDest);
						size_t pos = backupFile.rfind(L".vmdk_secure");
						wstring indexName = backupFile.substr(0, pos) + L".idx";
						wstring fileName(backupFile.begin(), backupFile.end());
						wstring indexFile(indexName.begin(), indexName.end());

						this->log(env, 1, "Loading Index at %d for index file : %ws", __LINE__, indexFile.c_str());

						int fd = _wopen(indexFile.c_str(), _O_RDONLY | _O_BINARY);
						if (fd == -1) {
							int errsv = errno;
							this->log(env, 1, "_wopen index error : %d", errsv);
							errorCode = ERROR_COULD_NOT_LOAD_INDEX;
							this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : ERROR_COULD_NOT_OPEN_EXISTING_INDEX");
							break;
						}
						else {
							this->log(env, 1, "fd not -1 : A-OK [%d]", __LINE__);
						}
						gzFile gz = gzdopen(fd, "rb");

						//gzFile gz = gzopen(indexFile.c_str(), "rb");
						if (gz == NULL) {
							this->log(env, 1, "gzdopen index error at %d", __LINE__);
							errorCode = ERROR_COULD_NOT_LOAD_INDEX;
							this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : ERROR_COULD_NOT_OPEN_EXISTING_INDEX");
							break;
						}

						// Allocate a seekgzip_t instance.``
						fileStructure->index = (struct access*)malloc(sizeof(struct access));
						if (fileStructure->index == NULL) {
							this->log(env, 1, "Index null.out of memory %d", __LINE__);
							errorCode = ERROR_COULD_NOT_LOAD_INDEX;
							this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : ERROR_COULD_NOT_OPEN_EXISTING_INDEX");
							break;
						}
						memset(fileStructure->index, 0, sizeof(*fileStructure->index));

						// Read the number of entry points.
						fileStructure->index->have = fileStructure->index->size = read_uint32(gz);

						// Allocate an array for entry points.
						fileStructure->index->list = (struct point*)malloc(sizeof(struct point) * fileStructure->index->have);
						if (fileStructure->index->list == NULL) {
							this->log(env, 1, "Index->list empty %d", __LINE__);
						}
						this->log(env, 1, "Index size : %d", fileStructure->index->have);
						// Read entry points.
						for (int m = 0; m < fileStructure->index->have; ++m) {
							gzread(gz, &fileStructure->index->list[m].out, sizeof(__int64));
							gzread(gz, &fileStructure->index->list[m].in, sizeof(__int64));
							gzread(gz, &fileStructure->index->list[m].bits, sizeof(int));
							gzread(gz, fileStructure->index->list[m].window, WINSIZE);
						}
						if (gz != NULL) {
							gzclose(gz);
						}
					}
					//build_indexForEncryptedFile(InfileHandle, SPAN, &fileStructure->index, fileStructure->encryptionkey);
					this->log(env, 1, "Loading Index completed at %d for fileIndex: %d", __LINE__, fileIndex);
					fileStructure->gzfilepointer = NULL;
					if (wtextDest != NULL) {
						delete[] wtextDest;
					}
				}
				else {
					int fd = _wopen(filePath, _O_RDONLY | _O_BINARY);
					if (fd == -1) {
						int errsv = errno;
						this->log(env, 1, "_wopen error : %d", errsv);
						errorCode = ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS");
						break;
					}
					else {
						this->log(env, 1, "fd not -1 : A-OK [%d]", __LINE__);
					}
					gzFile InfileHandle = gzdopen(fd, "rb");
					if (!InfileHandle) {
						this->log(env, 1, "Compressed open error %s\n", this->appGlobals.woriginalPath);
						errorCode = ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_GZDOPEN;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_GZDOPEN");
						break;
					}
					fileStructure->gzfilepointer = InfileHandle;
					fileStructure->filepointer = NULL;
					fileStructure->index = NULL;
				}
			}
			else {
				fileStructure->gzfilepointer = NULL;
				fileStructure->filepointer = NULL;
				fileStructure->index = NULL;
			}
			indexToFileStructMap.insert(pair<int, FileStructure*>(fileIndex, fileStructure));
		}
	}

	int bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
	uint8 *buf = new uint8[bufSize];

	//start filling data
	if (errorCode == 0) {

		uint64 currentOutputOffset = 0;
		jstring jlength;
		jstring joffset;
		jobject incDetailsObject;
		jstring jseekLength;
		jstring jfileIndex;
		const char* fileindexcstr;
		const char* offsetcstr;
		const char* lengthcstr;
		const char* fileseeklengthcstr;
		uint64 offset;
		uint64 length;
		uint64 fileseeklength;
		int fileIndex;
		FileStructure* fileStruct;
		int percent = 1 + (incrementalArrayListSize / 10);

		for (int i = 0; i < incrementalArrayListSize; i++) {

			if (i % percent == 0 && !env->CallObjectMethod(diskReadWriteControl, proceedCheckID)) {
				this->log(this->env, 1, "Disk RW Aborted from DoSyntheticFullbackup()");
				this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Disk read|write was aborted");
				errorCode = OPERATION_ABORTED;
				break;
			}
			incDetailsObject = env->CallObjectMethod(incrementalArrayList, listGetID, (jint)i);
			joffset = (jstring)env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, env->NewStringUTF("OFFSET"));
			jlength = (jstring)env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, env->NewStringUTF("LENGTH"));
			jseekLength = (jstring)env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, env->NewStringUTF("SEEKLENGTH"));
			jfileIndex = (jstring)env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, env->NewStringUTF("FILEINDEX"));

			offsetcstr = env->GetStringUTFChars(joffset, 0);
			offset = _strtoui64(offsetcstr, NULL, 0);

			fileindexcstr = env->GetStringUTFChars(jfileIndex, 0);
			fileIndex = atoi(fileindexcstr);

			lengthcstr = env->GetStringUTFChars(jlength, 0);
			length = _strtoui64(lengthcstr, NULL, 0);

			fileseeklengthcstr = env->GetStringUTFChars(jseekLength, 0);
			fileseeklength = _strtoui64(fileseeklengthcstr, NULL, 0);

			auto keyValue = indexToFileStructMap.find(0);
			fileStruct = (FileStructure *)keyValue->second;

			if (currentOutputOffset < offset) {
				//read from original full backup if not star backup
				this->log(env, 1, "isStarBackup:[%d]  [%d]", isStarBackup, __LINE__);
				if (!isStarBackup) {
					if (fileStruct->isencrypted) {
						if (!readFromEncryptedFile(*(fileStruct->filepointer), *(fileStruct->index), fileStruct->encryptionkey, currentOutputOffset, offset - currentOutputOffset, ofile, buf)) {
							errorCode = ERROR_COULD_NOT_READ_FROM_FILE;
							this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : Could not read from backup file");
							break;
						}
					}
					else {
						if (!readFromFile((fileStruct->gzfilepointer), currentOutputOffset, offset - currentOutputOffset, ofile, buf)) {
							errorCode = ERROR_COULD_NOT_READ_FROM_FILE;
							this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : Could not read from backup file");
							break;
						}
					}
				}
				else {
					this->log(env, 1, "This is a star backup. Hence no need for initial correction  [%d]", __LINE__);
				}
				currentOutputOffset = offset;
			}

			keyValue = indexToFileStructMap.find(fileIndex);
			fileStruct = (FileStructure *)keyValue->second;

			if (fileStruct->filetype == 0) { //normal files in repository
											 //fileToBeReadFrom = indexToFileMap.at(fileIndex);
				if (fileStruct->isencrypted) {
					if (!readFromEncryptedFile(*(fileStruct->filepointer), *(fileStruct->index), fileStruct->encryptionkey, fileseeklength, length, ofile, buf)) {
						errorCode = ERROR_COULD_NOT_READ_FROM_FILE;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : Could not read from backup file");
						break;
					}
				}
				else {
					if (!readFromFile(fileStruct->gzfilepointer, fileseeklength, length, ofile, buf)) {
						this->log(env, 1, "****************************[%d Problem]*********************************", __LINE__);
						errorCode = ERROR_COULD_NOT_READ_FROM_FILE;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : Could not read from backup file");
						break;
					}
				}
			}
			else { //directly from vmfiles
				if (!readFromVM(disk.Handle(), offset, length, ofile, buf)) {
					this->log(env, 1, "****************************[%d Problem]*********************************", __LINE__);
					errorCode = ERROR_COULD_NOT_READ_FROM_VM;
					this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : Could not read from vmdk");
					break;
				}
			}
			currentOutputOffset = offset + length;
			if (i % percent == 0 || i == incrementalArrayListSize - 1) {
				env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)(i + 1));
			}
		}

		//todo is there a need to check for other disks status ?
		if (errorCode == 0) {
			if (!isStarBackup) {
				this->log(env, 1, "It's not a star backup. Final Correction by reading remaining data from the full backup file");
				auto keyValue = indexToFileStructMap.find(0);
				fileStruct = (FileStructure *)keyValue->second;
				if (fileStruct->isencrypted) {
					int bytes_read;
					int bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
					//uint8 *buf = new uint8[bufSize];
					while (1) {
						bytes_read = extractDecrypt(fileStruct->filepointer, fileStruct->index, currentOutputOffset, buf, bufSize, fileStruct->encryptionkey);

						if (bytes_read < 0) {
							this->log(this->env, 1, "Error has occurred in extractDecrypt of synthetic module");
							errorCode = ERROR_COULD_NOT_READ_FROM_FILE_NOT_STAR_BACKUP;
							this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : Could not read from backup file");
							break;
						}
						else {
							gzwrite(ofile, buf, bytes_read);
						}

						if (bytes_read < bufSize) {
							if (feof(fileStruct->filepointer)) {
								this->log(env, 1, "EOF reached in extractDecrypt ofile currentpoint %lld [%d]", gztell(ofile), __LINE__);
								break;
							}
						}
						currentOutputOffset = currentOutputOffset + bytes_read;
					}

					//delete[] buf;
				}
				else {
					//moving the original file's pointer to the same offset as the output;
					gzseek(fileStruct->gzfilepointer, currentOutputOffset, SEEK_SET);
					uint64 bytes_read;
					size_t bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
					//uint8 *buf = new uint8[bufSize];
					while (1) {
						bytes_read = gzread(fileStruct->gzfilepointer, buf, bufSize);
						if (bytes_read < 0) {
							this->log(this->env, 1, "Error has occurred in gzread of synthetic module");
							int err;
							const char * error_string;
							error_string = gzerror(fileStruct->gzfilepointer, &err);
							if (err) {
								this->log(env, 1, "****************************[%d Problem]*********************************", __LINE__);
								this->log(this->env, 1, "gzerror [%d]", __LINE__);
								errorCode = ERROR_COULD_NOT_READ_FROM_FILE_NOT_STAR_BACKUP;
								this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : Could not read from file");
								break;
							}
						}
						else {
							gzwrite(ofile, buf, bytes_read);
							//this->log(this->env, 1, "line : [%d] readFromFile :buffer content [%s]", __LINE__, buf);

						}
						if (bytes_read < bufSize) {
							if (gzeof(fileStruct->gzfilepointer)) {
								break;
							}
						}
					}

					//delete[] buf;
				}

				//progress completed
				env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)(incrementalArrayListSize + 1));
			}
			else {
				this->log(env, 1, "It's a star backup. No final correction required [%d]", __LINE__);
			}
		}
		else {
			this->log(env, 1, "Error has occurred", __LINE__);
		}

	}

	{
		//closing files
		if (ofile != NULL) {
			gzclose(ofile);
		}

		for (int i = 0; i < indexToFileStructMap.size(); i++) {

			auto keyValue = indexToFileStructMap.find(i);
			FileStructure* fileStruct = (FileStructure *)keyValue->second;
			if (fileStruct->isencrypted) {
				FILE* fileToBeClosed = fileStruct->filepointer;
				if (fileStruct->filepointer != NULL) {
					fclose(fileToBeClosed);
				}
			}
			else {
				gzFile fileToBeClosed = fileStruct->gzfilepointer;
				if (fileStruct->gzfilepointer != NULL) {
					gzclose(fileToBeClosed);
				}
			}

		}

		//todo null pointer check
		for (int i = 0; i < indexToFileStructMap.size(); i++) {
			auto keyValue = indexToFileStructMap.find(i);
			FileStructure* fileStruct = (FileStructure *)keyValue->second;
			if (fileStruct->index != NULL)
			{
				if (fileStruct->index->list != NULL) {
					delete fileStruct->index->list;
				}
				delete fileStruct->index;
			}
			delete fileStruct;
		}

		if (buf != NULL) {
			delete[] buf;
		}

		//build index call
		if (errorCode == 0) {
            wstring backupFile = this->appGlobals.wvmdkPath;
            int indexCreationResult = this->indexCreation(backupFile, false, NULL);
            this->log(this->env, 1, "indexCreationResult : %d", indexCreationResult);
		}

		this->log(env, 1, "\nError code from DoSyntheticFullBackup is %d\n", errorCode);
		return errorCode;
	}
}

int VMDataCollector::DoSyntheticMigration(VixDiskLibHandle targetDiskHandle, VixDiskLibHandle srcDiskHandle, jobject incrementalArrayList, jobject filelist, char *moduleName, jobject progressObject, jobject diskReadWriteControl)
{

	this->log(env, 1, "DoSyntheticMigration started [%d]", __LINE__);
	int errorCode = 0;

	int incrementalArrayListSize = (jint)env->CallIntMethod(incrementalArrayList, listSizeID);
	int filelistSize = (jint)env->CallIntMethod(filelist, listSizeID);

	//filesopener
	//env->CallObjectMethod(progressObject, setMaximumMethodID, (jlong)(incrementalArrayListSize + 1));

	std::map<int, FileStructure *> indexToFileStructMap;

	boolean isStarBackup = false;
	std::string trueString("true");
	//filesopener
	{




		int i = 0; //dummy to be removed
		for (int i = 0; i < filelistSize; i++) {

			FileStructure* fileStructure = (FileStructure*)malloc(sizeof(FileStructure));

			if (fileStructure == NULL) {
				errorCode = ERROR_COULD_NOT_ALLOCATE_MEMORY;
				break;
			}
			jobject fileMapper = env->CallObjectMethod(filelist, listGetID, (jint)i);
			jstring jfileIndex = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("FILEINDEX"));
			jstring jfilePath = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("FILEPATH"));
			jstring jfileType = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("FILETYPE"));
			jstring jisStarBackup = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("IS_STAR_BACKUP"));
			jstring jisEncrypted = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("IS_ENCRYPTED"));
			jstring jisSecretKey;

			const char* fileindexcstr = env->GetStringUTFChars(jfileIndex, 0);
			uint64 fileIndex = _strtoui64(fileindexcstr, NULL, 0);

			const char* isStarBackupChar = env->GetStringUTFChars(jisStarBackup, 0);
			if (isStarBackup == false) {
				if (strcmp(isStarBackupChar, "true") == 0) {
					isStarBackup = true;
				}
				else {
					isStarBackup = false;
				}
			}
			const char* filetypecstr = env->GetStringUTFChars(jfileType, 0);
			uint64 fileType = _strtoui64(filetypecstr, NULL, 0);
			fileStructure->filetype = fileType;

			const char* isEncryptedChar = env->GetStringUTFChars(jisEncrypted, 0);
			boolean isEncrypted = false;
			if (strcmp(isEncryptedChar, "true") == 0) {
				jisSecretKey = (jstring)env->CallObjectMethod(fileMapper, jMtdGetHashtable, env->NewStringUTF("SECRETKEY"));
				LPWSTR secretKey = (LPWSTR)env->GetStringChars(jisSecretKey, 0);
				isEncrypted = true;
				fileStructure->isencrypted = true;
				fileStructure->encryptionkey = secretKey;

			}
			else {
				fileStructure->isencrypted = false;
				fileStructure->encryptionkey = L"";
			}

			if (fileType == 0) { //normal files in repository
				wchar_t* filePath = (wchar_t*)env->GetStringChars(jfilePath, 0);

				if (PathFileExists(filePath) == 1) {
					this->log(this->env, 1, "File already exists no need to decrypt");
					isEncrypted = false;
					fileStructure->isencrypted = false;
					fileStructure->encryptionkey = L"";
				}
				this->log(env, 1, "Starting File Management : %d", __LINE__);
				if (isEncrypted) {

					int length = wcslen(filePath) + 1;
					wchar_t *wtextDest = new wchar_t[(length + 7)];
					wcscpy(wtextDest, filePath);
					wcscat(wtextDest, L"_secure");
					this->log(this->env, 1, "wtextdest");
					this->log(this->env, 1, "%ws", wtextDest);
					int fd = _wopen(wtextDest, _O_RDONLY | _O_BINARY);

					if (fd == -1) {
						int errsv = errno;
						this->log(env, 1, "_wopen error : %d", errsv);
						errorCode = ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS");
						break;
					}
					else {
						this->log(env, 1, "fd not -1 : A-OK [%d]", __LINE__);
					}
					FILE* InfileHandle = fdopen(fd, "rb");
					if (!InfileHandle) {
						this->log(env, 1, "Compressed fdopen error %s\n", this->appGlobals.woriginalPath);
						errorCode = ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_FDOPEN;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic full backup failed : ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_FDOPEN");
						break;
					}
					fileStructure->filepointer = InfileHandle;
					this->log(env, 1, "Loading Index at %d for fileIndex: %d", __LINE__, fileIndex);
					{
						wstring backupFile(wtextDest);
						size_t pos = backupFile.rfind(L".vmdk_secure");
						wstring indexName = backupFile.substr(0, pos) + L".idx";
						wstring fileName(backupFile.begin(), backupFile.end());
						wstring indexFile(indexName.begin(), indexName.end());

						this->log(env, 1, "Loading Index at %d for index file : %ws", __LINE__, indexFile.c_str());

						int fd = _wopen(indexFile.c_str(), _O_RDONLY | _O_BINARY);
						if (fd == -1) {
							int errsv = errno;
							this->log(env, 1, "_wopen index error : %d", errsv);
							errorCode = ERROR_COULD_NOT_LOAD_INDEX;
							this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic migration failed : ERROR_COULD_NOT_OPEN_EXISTING_INDEX");
							break;
						}
						else {
							this->log(env, 1, "fd not -1 : A-OK [%d]", __LINE__);
						}
						gzFile gz = gzdopen(fd, "rb");

						//gzFile gz = gzopen(indexFile.c_str(), "rb");
						if (gz == NULL) {
							this->log(env, 1, "gzdopen index error at %d", __LINE__);
							errorCode = ERROR_COULD_NOT_LOAD_INDEX;
							this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic migration failed : ERROR_COULD_NOT_OPEN_EXISTING_INDEX");
							break;
						}

						// Allocate a seekgzip_t instance.``
						fileStructure->index = (struct access*)malloc(sizeof(struct access));
						if (fileStructure->index == NULL) {
							this->log(env, 1, "Index null.out of memory %d", __LINE__);
							errorCode = ERROR_COULD_NOT_LOAD_INDEX;
							this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic migration failed : ERROR_COULD_NOT_OPEN_EXISTING_INDEX");
							break;
						}
						memset(fileStructure->index, 0, sizeof(*fileStructure->index));

						// Read the number of entry points.
						fileStructure->index->have = fileStructure->index->size = read_uint32(gz);

						// Allocate an array for entry points.
						fileStructure->index->list = (struct point*)malloc(sizeof(struct point) * fileStructure->index->have);
						if (fileStructure->index->list == NULL) {
							this->log(env, 1, "Index->list empty %d", __LINE__);
						}
						this->log(env, 1, "Index size : %d", fileStructure->index->have);
						// Read entry points.
						for (int m = 0; m < fileStructure->index->have; ++m) {
							gzread(gz, &fileStructure->index->list[m].out, sizeof(__int64));
							gzread(gz, &fileStructure->index->list[m].in, sizeof(__int64));
							gzread(gz, &fileStructure->index->list[m].bits, sizeof(int));
							gzread(gz, fileStructure->index->list[m].window, WINSIZE);
						}
						if (gz != NULL) {
							gzclose(gz);
						}
					}
					//build_indexForEncryptedFile(InfileHandle, SPAN, &fileStructure->index, fileStructure->encryptionkey);
					this->log(env, 1, "Loading Index completed at %d for fileIndex: %d", __LINE__, fileIndex);
					fileStructure->gzfilepointer = NULL;
					if (wtextDest != NULL) {
						delete[] wtextDest;
					}
				}
				else {
					int fd = _wopen(filePath, _O_RDONLY | _O_BINARY);
					if (fd == -1) {
						int errsv = errno;
						this->log(env, 1, "_wopen error : %d", errsv);
						errorCode = ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic migration failed : ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS");
						break;
					}
					else {
						this->log(env, 1, "fd not -1 : A-OK [%d]", __LINE__);
					}
					gzFile InfileHandle = gzdopen(fd, "rb");
					if (!InfileHandle) {
						this->log(env, 1, "Compressed open error %s\n", this->appGlobals.woriginalPath);
						errorCode = ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_GZDOPEN;
						this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic migration failed : ERROR_COULD_NOT_OPEN_EXISTING_BACKUPS_GZDOPEN");
						break;
					}
					fileStructure->gzfilepointer = InfileHandle;
					fileStructure->filepointer = NULL;
					fileStructure->index = NULL;
				}
			}
			else {
				fileStructure->gzfilepointer = NULL;
				fileStructure->filepointer = NULL;
				fileStructure->index = NULL;
			}
			indexToFileStructMap.insert(pair<int, FileStructure*>(fileIndex, fileStructure));
		}

		if (errorCode != 0)
		{
			//todo handle failure say error in parsing itself
			////this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Synthetic Full Backup Failed"); this can't be used in RPC
		}
	}

	int bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
	uint8 *buf = new uint8[bufSize];

	//start filling data
	int i = 0; //dummy to be removed later
	if (errorCode == 0)
	{

		uint64 currentOutputOffset = 0;
		jstring jlength;
		jstring joffset;
		jobject incDetailsObject;
		jstring jseekLength;
		jstring jfileIndex;
		const char *fileindexcstr;
		const char *offsetcstr;
		const char *lengthcstr;
		const char *fileseeklengthcstr;
		uint64 offset;
		uint64 length;
		uint64 fileseeklength;
		uint64 fileType;
		int fileIndex;
		gzFile fileToBeReadFrom;
		FileStructure *fileStruct;
		int percent = 1 + (incrementalArrayListSize / 10);
		for (int i = 0; i < incrementalArrayListSize; i++) {

			if (i % percent == 0 && !env->CallObjectMethod(diskReadWriteControl, proceedCheckID)) {
				this->log(this->env, 1, "Disk RW Aborted from DosyntheticMigration()");
				this->generateException(__LINE__, moduleName, __FUNCTION__, 0, "Disk read|write was aborted");
				errorCode = OPERATION_ABORTED;
				break;
			}
			incDetailsObject = env->CallObjectMethod(incrementalArrayList, listGetID, (jint)i);
			joffset = (jstring)env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, env->NewStringUTF("OFFSET"));
			jlength = (jstring)env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, env->NewStringUTF("LENGTH"));
			jseekLength = (jstring)env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, env->NewStringUTF("SEEKLENGTH"));
			jfileIndex = (jstring)env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, env->NewStringUTF("FILEINDEX"));

			offsetcstr = env->GetStringUTFChars(joffset, 0);
			offset = _strtoui64(offsetcstr, NULL, 0);

			fileindexcstr = env->GetStringUTFChars(jfileIndex, 0);
			fileIndex = atoi(fileindexcstr);

			lengthcstr = env->GetStringUTFChars(jlength, 0);
			length = _strtoui64(lengthcstr, NULL, 0);

			fileseeklengthcstr = env->GetStringUTFChars(jseekLength, 0);
			fileseeklength = _strtoui64(fileseeklengthcstr, NULL, 0);

			auto keyValue = indexToFileStructMap.find(0);
			fileStruct = (FileStructure *)keyValue->second;

			if (currentOutputOffset < offset)
			{
				//this->log(env, 1, "Gonna read from appropriate file currentOutputOffset [%lld] = offset[%lld]   line : [%d]", currentOutputOffset, offset, __LINE__);
				//read from original full backup if not star backup
				//this->log(env, 1, "isStarBackup:[%d]  [%d]\n", isStarBackup, __LINE__);
				if (!isStarBackup)
				{
					this->log(env, 1, "Going to read from full backup file [%d]", __LINE__);
					if (fileStruct->isencrypted)
					{
						if (!readFromEncryptedFile(*(fileStruct->filepointer), *(fileStruct->index), fileStruct->encryptionkey, currentOutputOffset, offset - currentOutputOffset, targetDiskHandle, currentOutputOffset, buf))
						{
							errorCode = ERROR_COULD_NOT_READ_FROM_FILE;
							break;
						}
					}
					else
					{
						if (!readFromFile((fileStruct->gzfilepointer), currentOutputOffset, offset - currentOutputOffset, targetDiskHandle, currentOutputOffset, buf))
						{
							errorCode = ERROR_COULD_NOT_READ_FROM_FILE;
							break;
						}
					}
				}
				else
				{
					this->log(env, 1, "This is a star backup. Hence no need for initial correction  [%d]", __LINE__);
				}
				currentOutputOffset = offset;

				env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);
			}

			//this->log(env, 1, "Gonna read from appropriate file currentOutputOffset [%lld] = offset[%lld]   line : [%d]\n", currentOutputOffset, offset, __LINE__);
			keyValue = indexToFileStructMap.find(fileIndex);
			fileStruct = (FileStructure *)keyValue->second;

			if (fileStruct->filetype == 0)
			{
				//normal files in repository
				//this->log(env, 1, "Gonna read from files in repository currentOutputOffset [%lld] = offset[%lld]   line : [%d]\n", currentOutputOffset, offset, __LINE__);
				//this->log(env, 1, "filetobeReadFrom index :[%d]  [%d]\n", fileIndex, __LINE__);

				if (fileStruct->isencrypted)
				{
					if (!readFromEncryptedFile(*(fileStruct->filepointer), *(fileStruct->index), fileStruct->encryptionkey, fileseeklength, length, targetDiskHandle, currentOutputOffset, buf))
					{
						this->log(env, 1, "\n****************************[%d Problem]*********************************\n", __LINE__);
						errorCode = ERROR_COULD_NOT_READ_FROM_FILE;
						break;
					}
				}
				else
				{
					if (!readFromFile(fileStruct->gzfilepointer, fileseeklength, length, targetDiskHandle, currentOutputOffset, buf))
					{
						this->log(env, 1, "\n****************************[%d Problem]*********************************\n", __LINE__);
						errorCode = ERROR_COULD_NOT_READ_FROM_FILE;
						break;
					}
				}
			}
			else
			{ //directly from vmfiles
				//this->log(env, 1, "Gonna read directly from vmfiles currentOutputOffset [%lld] = offset[%lld]   line : [%d]\n", currentOutputOffset, offset, __LINE__);
				if (!readFromVM(srcDiskHandle, offset, length, targetDiskHandle, currentOutputOffset, buf))
				{
					this->log(env, 1, "\n****************************[%d Problem]*********************************\n", __LINE__);
					errorCode = ERROR_COULD_NOT_READ_FROM_VM;
					break;
				}
			}
			currentOutputOffset = offset + length;
			//i++; //dummy to be removed later
			env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);
			//for progress bar updation
		}

		this->log(env, 1, "Gonna check if !isStarBackup [%d]\n", __LINE__);

		if (!isStarBackup && errorCode == 0)
		{
			this->log(env, 1, "It's not a star backup. Final Correction by reading remaining data from the full backup file");
			auto keyValue = indexToFileStructMap.find(0);
			fileStruct = (FileStructure *)keyValue->second;

			if (fileStruct->isencrypted)
			{
				int bytes_read;
				int checkPoint = 0;
				while (1)
				{
					bytes_read = extractDecrypt(fileStruct->filepointer, fileStruct->index, currentOutputOffset, buf, bufSize, fileStruct->encryptionkey);
					if (bytes_read < 0)
					{
						this->log(env, 1, "Error has occured in gzread of synthetic migration module");
						errorCode = ERROR_COULD_NOT_READ_FROM_FILE_NOT_STAR_BACKUP;
						break;
					}
					else
					{
						//gzwrite(ofile, buf, bytes_read);
						VixDiskLib_Write(targetDiskHandle, currentOutputOffset / VIXDISKLIB_SECTOR_SIZE, this->appGlobals.bufSize, buf);
					}

					if (bytes_read < bufSize)
					{
						if (feof(fileStruct->filepointer))
						{
							this->log(env, 1, "EOF reached ofile currentpoint %lld [%d]\n", currentOutputOffset, __LINE__);
							break;
						}
					}
					currentOutputOffset = currentOutputOffset + bytes_read;
					checkPoint++;
					if(checkPoint % 100 == 0){
					    env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);
					}
				}
			}
			else
			{
				//moving the original file's pointer to the same offset as the output;
				gzseek(fileStruct->gzfilepointer, currentOutputOffset, SEEK_SET);
				uint64 bytes_read;
				int checkPoint = 0;
				while (1)
				{
					size_t bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
					bytes_read = gzread(fileStruct->gzfilepointer, buf, bufSize);
					if (bytes_read < 0)
					{
						this->log(env, 1, "Error has occured in gzread of synthetic module");
						int err;
						const char *error_string;
						error_string = gzerror(fileStruct->gzfilepointer, &err);
						if (err)
						{
							this->log(env, 1, "****************************[%d Problem]*********************************\n", __LINE__);
							this->log(env, 1, "gzerror [%d]\n", __LINE__);
							errorCode = ERROR_COULD_NOT_READ_FROM_FILE_NOT_STAR_BACKUP;
							break;
						}
					}
					else
					{
						//gzwrite(ofile, buf, bytes_read);
						VixDiskLib_Write(targetDiskHandle, currentOutputOffset / VIXDISKLIB_SECTOR_SIZE, this->appGlobals.bufSize, buf);
						//this->log(env, 1, "readFromFile starting sector %lld [%d]\n", currentOutputOffset / VIXDISKLIB_SECTOR_SIZE, __LINE__);
						//this->log(env, 1, "readFromFile sectors covered this->appGlobals.bufSize %lld [%d]\n", this->appGlobals.bufSize, __LINE__);
						currentOutputOffset = currentOutputOffset + bytes_read;
						//this->log(env, 1, "readFromFile ofile currentpoint %lld [%d]\n", currentOutputOffset, __LINE__);
						checkPoint++;
						if(checkPoint % 100 == 0){
                            env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);
                        }
					}
					if (bytes_read < bufSize)
					{
						if (gzeof(fileStruct->gzfilepointer))
						{
							this->log(env, 1, "EOF reached ofile currentpoint %lld [%d]\n", currentOutputOffset, __LINE__);
							break;
						}
					}
				}
			}

			//todo for progress bar updation
			env->CallObjectMethod(progressObject, setProgressMethodID, (jlong)currentOutputOffset);
		}
	}

	//progresscompleted

	{
		//closing files

		for (int i = 0; i < indexToFileStructMap.size(); i++)
		{

			auto keyValue = indexToFileStructMap.find(i);
			FileStructure *fileStruct = (FileStructure *)keyValue->second;
			if (fileStruct->isencrypted)
			{
				FILE *fileToBeClosed = fileStruct->filepointer;
				if (fileStruct->filepointer != NULL)
				{
					fclose(fileToBeClosed);
				}
			}
			else
			{
				gzFile fileToBeClosed = fileStruct->gzfilepointer;
				if (fileStruct->gzfilepointer != NULL)
				{
					gzclose(fileToBeClosed);
				}
			}
		}

		//todo null pointer check
		for (int i = 0; i < indexToFileStructMap.size(); i++)
		{
			auto keyValue = indexToFileStructMap.find(i);
			FileStructure *fileStruct = (FileStructure *)keyValue->second;
			if (fileStruct->index != NULL)
			{
				if (fileStruct->index->list != NULL)
				{
					delete fileStruct->index->list;
				}
				delete fileStruct->index;
			}
			delete fileStruct;
		}

		if (buf != NULL)
		{
			delete[] buf;
		}

	}

	this->log(env, 1, "\nError code from DoSyntheticMigration is %d\n", errorCode);

	return errorCode;
}

boolean VMDataCollector::readFromFile(gzFile &fileToBeReadFrom, uint64 fileseeklength, uint64 lengthToBeRead, gzFile &ofile, uint8 *buf) {

	size_t bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
	uint64 len = lengthToBeRead / VIXDISKLIB_SECTOR_SIZE;
	uint64 maxOps = len / this->appGlobals.bufSize;
	int bytes_read = 0;


	uint64 bytes_seeked = gzseek(fileToBeReadFrom, fileseeklength, SEEK_SET);
	if (bytes_seeked != fileseeklength) {
		this->log(env, 1, "****************************[bytes_seeked %lld gzseek Problem at %d]*********************************", bytes_seeked, __LINE__);
		this->log(this->env, 1, "%lld fileseeklength", fileseeklength);
		this->log(this->env, 1, "%lld lengthToBeRead", lengthToBeRead);
		return false;
	}

	for (int j = 0; j < maxOps; j++) {

		bytes_read = gzread(fileToBeReadFrom, buf, bufSize);
		if (bytes_read < bufSize)
		{
			this->log(env, 1, "****************************[Problem at %d]*********************************", __LINE__);
			this->log(this->env, 1, "%lld fileseeklength", fileseeklength);
			this->log(this->env, 1, "%lld lengthToBeRead", lengthToBeRead);
			if (bytes_read < 0)
			{
				int err;
				const char *error_string;
				error_string = gzerror(fileToBeReadFrom, &err);
				if (err)
				{
					this->log(this->env, 1, "readFromFile :gzerror [%s] at [%d]",error_string, __LINE__);
				}
				else if (gzeof(fileToBeReadFrom) == 1)
				{
					this->log(this->env, 1, "End of file reached abruptly", __LINE__);
				}
				else
				{
					this->log(this->env, 1, "Unhandled gzerror", __LINE__);
				}
			}
			return false;
		}
		else {
			gzwrite(ofile, buf, bytes_read);
		}


	}
	//delete[] buf;

	int frag = (len % this->appGlobals.bufSize) * VIXDISKLIB_SECTOR_SIZE;
	if (frag > 0) {
		int err;
		uint8 *buffer = new uint8[frag];
		int bytes_read;
		bytes_read = gzread(fileToBeReadFrom, buffer, (unsigned int)frag);
		if (bytes_read < frag)
		{
			this->log(env, 1, "****************************[Problem at %d]*********************************", __LINE__);
			this->log(this->env, 1, "%lld fileseeklength", fileseeklength);
			this->log(this->env, 1, "%lld frag lengthToBeRead", frag);
			if (bytes_read < 0)
			{
				int err;
				const char *error_string;
				error_string = gzerror(fileToBeReadFrom, &err);
				if (err)
				{
					this->log(this->env, 1, "readFromFile :gzerror [%s] at [%d]",error_string, __LINE__);
				}
			}
			else if (gzeof(fileToBeReadFrom) == 1)
			{
				this->log(this->env, 1, "End of file reached abruptly", __LINE__);
			}
			else
			{
				this->log(this->env, 1, "Unhandled gzerror", __LINE__);
			}
			delete[] buffer;
			return false;
		}
		else {
			//this->log(this->env, 1, "line : [%d] readFromFile :buffer content [%s]", __LINE__, buffer);
			gzwrite(ofile, buffer, bytes_read);
		}

		delete[] buffer;
	}
	return true;
}

boolean VMDataCollector::readFromFile(gzFile &fileToBeReadFrom, uint64 fileseeklength, uint64 lengthToBeRead, VixDiskLibHandle targetdiskHandle, __int64 currentOutputOffset, uint8 *buf)
{
	//this->log(env, 1, "readFromFile starting at [%d]\n", __LINE__);

	size_t bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
	uint64 len = lengthToBeRead / VIXDISKLIB_SECTOR_SIZE;
	uint64 maxOps = len / this->appGlobals.bufSize;
	int bytes_read = 0;
	__int64 totalBytesRead = currentOutputOffset;
	uint64 bytes_seeked = gzseek(fileToBeReadFrom, fileseeklength, SEEK_SET);
	if (bytes_seeked != fileseeklength)
	{
		this->log(env, 1, "****************************[bytes_seeked %lld gzseek Problem at %d]*********************************", bytes_seeked, __LINE__);
		this->log(this->env, 1, "%lld fileseeklength", fileseeklength);
		this->log(this->env, 1, "%lld lengthToBeRead", lengthToBeRead);
		return false;	}

	for (int j = 0; j < maxOps; j++)
	{

		bytes_read = gzread(fileToBeReadFrom, buf, bufSize);
		if (bytes_read < bufSize)
		{
			this->log(env, 1, "****************************[Problem at %d]*********************************", __LINE__);
			this->log(this->env, 1, "%lld fileseeklength", fileseeklength);
			this->log(this->env, 1, "%lld lengthToBeRead", lengthToBeRead);
			if (bytes_read < 0)
			{
				int err;
				const char *error_string;
				error_string = gzerror(fileToBeReadFrom, &err);
				if (err)
				{
					this->log(this->env, 1, "readFromFile :gzerror [%s] at [%d]",error_string, __LINE__);
				}
				else if (gzeof(fileToBeReadFrom) == 1)
				{
					this->log(this->env, 1, "End of file reached abruptly", __LINE__);
				}
				else
				{
					this->log(this->env, 1, "Unhandled gzerror", __LINE__);
				}
			}
			return false;
		}
		else
		{
			//gzwrite(ofile, buf, bytes_read);
			VixDiskLib_Write(targetdiskHandle, totalBytesRead / VIXDISKLIB_SECTOR_SIZE, this->appGlobals.bufSize, buf);
			//this->log(env, 1, "readFromFile starting sector %lld [%d]\n", totalBytesRead / VIXDISKLIB_SECTOR_SIZE, __LINE__);
			//this->log(env, 1, "readFromFile sectors covered this->appGlobals.bufSize %lld [%d]\n", this->appGlobals.bufSize, __LINE__);
			totalBytesRead += bytes_read;
			//this->log(env, 1, "readFromFile ofile currentpoint %lld [%d]\n", totalBytesRead, __LINE__);

		}
	}
	//this->log(env, 1, "readFromFile maxOps done going to check for frag [%d]\n", __LINE__);

	int frag = (len % this->appGlobals.bufSize) * VIXDISKLIB_SECTOR_SIZE;
	if (frag > 0)
	{
		//this->log(env, 1, "readFromFile frag : [%d]\n", __LINE__);
		int err;
		uint8 *buffer = new uint8[frag];
		int bytes_read;
		bytes_read = gzread(fileToBeReadFrom, buffer, (unsigned int)frag);
		if (bytes_read < frag)
		{
			this->log(env, 1, "****************************[Problem at %d]*********************************", __LINE__);
			this->log(this->env, 1, "%lld fileseeklength", fileseeklength);
			this->log(this->env, 1, "%lld frag lengthToBeRead", frag);
			if (bytes_read < 0)
			{
				int err;
				const char *error_string;
				error_string = gzerror(fileToBeReadFrom, &err);
				if (err)
				{
					this->log(this->env, 1, "readFromFile :gzerror [%s] at [%d]",error_string, __LINE__);
				}
			}
			else if (gzeof(fileToBeReadFrom) == 1)
			{
				this->log(this->env, 1, "End of file reached abruptly", __LINE__);
			}
			else
			{
				this->log(this->env, 1, "Unhandled gzerror", __LINE__);
			}
            delete[] buffer;
			return false;
		}
		else
		{
			//gzwrite(ofile, buffer, bytes_read);
			VixDiskLib_Write(targetdiskHandle, totalBytesRead / VIXDISKLIB_SECTOR_SIZE, len % this->appGlobals.bufSize, buffer);
			//this->log(env, 1, "readFromFile starting frag sector %lld [%d]\n", totalBytesRead / VIXDISKLIB_SECTOR_SIZE, __LINE__);
			//this->log(env, 1, "readFromFile frag sectors covered this->appGlobals.bufSize %lld [%d]\n", len % this->appGlobals.bufSize, __LINE__);
			totalBytesRead += bytes_read;
			//this->log(env, 1, "readFromFile ofile currentpoint %lld [%d]\n", totalBytesRead, __LINE__);
		}

		delete[] buffer;
	}
	//this->log(env, 1, "readFromFile completed [%d]\n", __LINE__);
	return true;
}

boolean VMDataCollector::readFromEncryptedFile(FILE &fileToBeReadFrom, struct access &index, LPTSTR secretKey, uint64 fileseeklength, uint64 lengthToBeRead, gzFile &ofile, uint8 *buf) {

	int bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
	uint64 len = lengthToBeRead / VIXDISKLIB_SECTOR_SIZE;
	uint64 maxOps = len / this->appGlobals.bufSize;
	int bytes_read = 0;

	//FILE* normalFile = fopen("E:\\IRx64\\ManageEngine\\RecoveryManagerPlus\\bin\\virtual_backup\\1\\8\\[datastore123] ajay_map_qa_ajay_map_qa.vmdk", "rb");


	for (int j = 0; j < maxOps; j++) {
		bytes_read = extractDecrypt(&fileToBeReadFrom, &index, fileseeklength, buf, bufSize, secretKey);
		if (bytes_read < 0) {
			this->log(env, 1, "****************************[%d Problem]*********************************", __LINE__);
			this->log(this->env, 1, "readFromEncryptedFile in maxOps: Error has occurred in extractDecrypt of synthetic module");
			this->log(env, 1, "readFromEncryptedFile completed with errors at [%d]", __LINE__);
			//delete[] buf;
			return false;
		}
		else {
			gzwrite(ofile, buf, bytes_read);
			fileseeklength = fileseeklength + bytes_read;
		}
	}
	//delete[] buf;

	int frag = (len % this->appGlobals.bufSize) * VIXDISKLIB_SECTOR_SIZE;
	if (frag > 0) {
		int err;
		uint8 *buffer = new uint8[frag];
		int bytes_read;
		bytes_read = extractDecrypt(&fileToBeReadFrom, &index, fileseeklength, buffer, frag, secretKey);
		if (bytes_read < 0) {
			this->log(env, 1, "****************************[%d Problem]*********************************", __LINE__);
			this->log(this->env, 1, "Error has occurred in gzread of synthetic module");
			this->log(env, 1, "readFromEncryptedFile completed with errors at [%d]", __LINE__);
			delete[] buffer;
			return false;
		}
		else {
			gzwrite(ofile, buffer, bytes_read);
			fileseeklength = fileseeklength + bytes_read;
		}
		delete[] buffer;
	}
	return true;
}

boolean VMDataCollector::readFromEncryptedFile(FILE &fileToBeReadFrom, struct access &index, LPTSTR secretKey, uint64 fileseeklength, uint64 lengthToBeRead, VixDiskLibHandle targetdiskHandle, __int64 currentOutputOffset, uint8 *buf)
{
	this->log(env, 1, "readFromEncryptedFile starting at [%d]", __LINE__);

	int bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
	uint64 len = lengthToBeRead / VIXDISKLIB_SECTOR_SIZE;
	uint64 maxOps = len / this->appGlobals.bufSize;
	int bytes_read = 0;
	__int64 totalBytesRead = currentOutputOffset;
	//this->log(env, 1, "readFromEncryptedFile len:%lld [%d]", len, __LINE__);
	//this->log(env, 1, "readFromEncryptedFile maxOps:%lld: [%d]", maxOps, __LINE__);
	//this->log(env, 1, "readFromEncryptedFile fileseeklength:%lld: [%d]", fileseeklength, __LINE__);

	for (int j = 0; j < maxOps; j++)
	{
		//this->log(env, 1, "readFromEncryptedFile in maxOps : [%d]", __LINE__);
		//this->log(env, 1, "readFromEncryptedFile len:%lld [%d]", len, __LINE__);
		//this->log(env, 1, "readFromEncryptedFile maxOps:%lld: [%d]", maxOps, __LINE__);
		//this->log(env, 1, "readFromEncryptedFile fileseeklength:%lld: [%d]", fileseeklength, __LINE__);

		bytes_read = extractDecrypt(&fileToBeReadFrom, &index, fileseeklength, buf, bufSize, secretKey);
		if (bytes_read < 0)
		{
			this->log(env, 1, "****************************[%d Problem]*********************************", __LINE__);
			this->log(env, 1, "readFromEncryptedFile in maxOps: Error has occured in extractDecrypt of synthetic module");
			this->log(env, 1, "readFromEncryptedFile completed with errors at [%d]", __LINE__);
			return false;
		}
		else
		{
			VixDiskLib_Write(targetdiskHandle, totalBytesRead / VIXDISKLIB_SECTOR_SIZE, this->appGlobals.bufSize, buf);
			totalBytesRead += bytes_read;
			this->log(env, 1, "readFromEncryptedFile in maxOps ofile currentpoint %lld [%d]", totalBytesRead, __LINE__);
			fileseeklength = fileseeklength + bytes_read;
		}
	}
	//this->log(env, 1, "readFromEncryptedFile maxOps done going to check for frag [%d]", __LINE__);

	int frag = (len % this->appGlobals.bufSize) * VIXDISKLIB_SECTOR_SIZE;
	if (frag > 0)
	{
		//this->log(env, 1, "readFromEncryptedFile frag : [%d]", __LINE__);
		int err;
		uint8 *buffer = new uint8[frag];
		int bytes_read;
		bytes_read = extractDecrypt(&fileToBeReadFrom, &index, fileseeklength, buffer, frag, secretKey);
		if (bytes_read < 0)
		{
			this->log(env, 1, "****************************[%d Problem]*********************************", __LINE__);
			this->log(env, 1, "Error has occured in gzread of synthetic module");
			this->log(env, 1, "readFromEncryptedFile completed with errors at [%d]", __LINE__);
			delete[] buffer;
			return false;
		}
		else
		{
			//gzwrite(ofile, buffer, bytes_read);
			VixDiskLib_Write(targetdiskHandle, totalBytesRead / VIXDISKLIB_SECTOR_SIZE, len % this->appGlobals.bufSize, buffer);
			totalBytesRead += bytes_read;
			this->log(env, 1, "readFromEncryptedFile ofile currentpoint %lld [%d]", totalBytesRead, __LINE__);
			fileseeklength = fileseeklength + bytes_read;
		}
		delete[] buffer;
	}
	//this->log(env, 1, "readFromEncryptedFile completed [%d]", __LINE__);
	return true;
}

boolean VMDataCollector::readFromVM(VixDiskLibHandle diskHandle, uint64 offset, uint64 lengthToBeRead, gzFile &ofile, uint8 *buf) {
	size_t bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
	uint64 start = offset / VIXDISKLIB_SECTOR_SIZE;
	uint64 len = lengthToBeRead / VIXDISKLIB_SECTOR_SIZE;
	uint64 maxOps = len / this->appGlobals.bufSize;
	int bytes_read = 0;
	VixError vixError;
	int j = 0;

	for (j = 0; j < maxOps; j++) {

		vixError = VixDiskLib_Read(diskHandle, start + (j * this->appGlobals.bufSize), this->appGlobals.bufSize, buf);
		if (VIX_FAILED(vixError)) {
			//delete[] buf;
			this->log(env, 1, "****************************[%d Problem]*********************************", __LINE__);

			this->log(this->env, 1, "VixError in Synthetic Full Backup readFromVM [VixError : %d] at [%d]", vixError, __LINE__);
			return false;
			//throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
		}
		gzwrite(ofile, buf, bufSize);
	}

	int frag = (len % this->appGlobals.bufSize) * VIXDISKLIB_SECTOR_SIZE;
	if (frag > 0) {
		uint8 *buffer = new uint8[frag];
		vixError = VixDiskLib_Read(diskHandle, start + (j * this->appGlobals.bufSize), (len % this->appGlobals.bufSize), buffer);
		if (VIX_FAILED(vixError)) {
			delete[] buffer;
			this->log(env, 1, "****************************[%d Problem]*********************************", __LINE__);

			this->log(this->env, 1, "VixError in Synthetic Full Backup readFromVM [VixError : %d] at [%d]", vixError, __LINE__);
			return false;
			//throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
		}
		gzwrite(ofile, buffer, frag);
		delete[] buffer;
	}

	return true;
}

boolean VMDataCollector::readFromVM(VixDiskLibHandle srcdiskHandle, uint64 offset, uint64 lengthToBeRead, VixDiskLibHandle targetdiskHandle, __int64 currentOutputOffset, uint8 *buf)
{
	size_t bufSize = this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
	uint64 start = offset / VIXDISKLIB_SECTOR_SIZE;
	uint64 len = lengthToBeRead / VIXDISKLIB_SECTOR_SIZE;
	uint64 maxOps = len / this->appGlobals.bufSize;
	int bytes_read = 0;
	__int64 totalBytesRead = currentOutputOffset;
	VixError vixError;
	int j = 0;
	//this->log(env, 1, "readFromVM [%d]\n", __LINE__);

	for (j = 0; j < maxOps; j++)
	{
		//this->log(env, 1, "readFromVM in maxops [%d]\n", __LINE__);

		vixError = VixDiskLib_Read(srcdiskHandle, totalBytesRead / VIXDISKLIB_SECTOR_SIZE, this->appGlobals.bufSize, buf);
		if (VIX_FAILED(vixError))
		{
			this->log(env, 1, "****************************[%d Problem]*********************************\n", __LINE__);
			this->log(env, 1, "VixError in Synthetic Migration readFromVM [VixError : %d] at [%d]\n", vixError, __LINE__);
			return false;
			//throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
		}
		//gzwrite(ofile, buf, bufSize);
		VixDiskLib_Write(targetdiskHandle, totalBytesRead / VIXDISKLIB_SECTOR_SIZE, this->appGlobals.bufSize, buf);
		//this->log(env, 1, "readFromVM starting sector %lld [%d]\n", totalBytesRead / VIXDISKLIB_SECTOR_SIZE, __LINE__);
		//this->log(env, 1, "readFromVM sectors covered this->appGlobals.bufSize %lld [%d]\n", this->appGlobals.bufSize, __LINE__);
		totalBytesRead = totalBytesRead + this->appGlobals.bufSize * VIXDISKLIB_SECTOR_SIZE;
		//this->log(env, 1, "readFromVM ofile currentpoint %lld [%d]\n", totalBytesRead, __LINE__);

	}
	//this->log(env, 1, "readFromVM outside maxops [%d]\n", __LINE__);

	int frag = (len % this->appGlobals.bufSize) * VIXDISKLIB_SECTOR_SIZE;
	if (frag > 0)
	{
		uint8 *buffer = new uint8[frag];
		vixError = VixDiskLib_Read(srcdiskHandle, totalBytesRead / VIXDISKLIB_SECTOR_SIZE, (len % this->appGlobals.bufSize), buffer);
		if (VIX_FAILED(vixError))
		{
			delete[] buffer;
			this->log(env, 1, "****************************[%d Problem]*********************************\n", __LINE__);
			this->log(env, 1, "VixError in Synthetic migration readFromVM [VixError : %d] at [%d]\n", vixError, __LINE__);
			return false;
			//throw VixDiskLibErrWrapper(vixError, __FILE__, __LINE__, __FUNCTION__);
		}
		//gzwrite(ofile, buf, frag);
		VixDiskLib_Write(targetdiskHandle, totalBytesRead / VIXDISKLIB_SECTOR_SIZE, len % this->appGlobals.bufSize, buffer);
		//this->log(env, 1, "readFromVM starting frag sector %lld [%d]\n", totalBytesRead / VIXDISKLIB_SECTOR_SIZE, __LINE__);
		//this->log(env, 1, "readFromVM sectors covered len per this->appGlobals.bufSize %lld [%d]\n", len % this->appGlobals.bufSize, __LINE__);
		totalBytesRead = totalBytesRead + frag;
		//this->log(env, 1, "readFromVM ofile currentpoint %lld [%d]\n", totalBytesRead, __LINE__);
		//this->log(env, 1, "readFromVM ofile sector currentpoint %lld [%d]\n", totalBytesRead / VIXDISKLIB_SECTOR_SIZE, __LINE__);
		delete[] buffer;
	}
	//this->log(env, 1, "readFromVM [%d]\n", __LINE__);
	return true;
}

bool VMDataCollector::protect(wchar_t* filePath, LPTSTR pszPassword, bool isEncrypt) {
	HCRYPTPROV hCryptProv = NULL;
	HCRYPTKEY hKey = NULL;
	HCRYPTKEY hXchgKey = NULL;
	HCRYPTHASH hHash = NULL;

	//    time_t t = time(0);   // get time now
	wchar_t secure[] = L"_secure";
	int length = wcslen(filePath) + 1;
	wchar_t* wtextSource = new wchar_t[length];
	wchar_t* wtextDest = new wchar_t[(length + 7)];
	if (filePath != NULL) {
		wcscpy(wtextSource, filePath);
		wcscpy(wtextDest, filePath);
	}
	wcscat(wtextDest, secure);
	LPTSTR pszSourceFile, psZDestFile;
	if (isEncrypt) {
		pszSourceFile = wtextSource;
		psZDestFile = wtextDest;
	}
	else {
		pszSourceFile = wtextDest;
		psZDestFile = wtextSource;
	}
	HANDLE hSourceFile = CreateFile(pszSourceFile, FILE_READ_DATA, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hSourceFile == INVALID_HANDLE_VALUE) {
		int errsv = errno;
		this->log(this->env, 1, "unable to open source file : %d", GetLastError());
		return false;
	}
	HANDLE hDestinationFile = CreateFile(psZDestFile, FILE_WRITE_DATA, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hDestinationFile == INVALID_HANDLE_VALUE) {
		int errsv = errno;
		this->log(this->env, 1, "unable to open destination file : %d", GetLastError());
		return false;
	}
	bool isEncrypted = false;
	bool CryptAcquireContextStatus = false;
	if (CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, 0)) {
		this->log(this->env, 1, "CryptAcquireContext success on first try");
		CryptAcquireContextStatus = true;
	}
	else {
		this->log(this->env, 1, "VMDataCollector::protect - CryptAcquireContext FAILED - %d, retrying to create new key container", (int)GetLastError());
		if (CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, CRYPT_NEWKEYSET)) {
			this->log(this->env, 1, "CryptAcquireContext success on second try");
			CryptAcquireContextStatus = true;
		}
		else {
			this->log(this->env, 1, "Could not create a new key container. %d", (int)GetLastError());
		}
	}
        this->log(this->env, 1, "CryptAcquireContext completed");
	if (CryptAcquireContextStatus) {
		if (CryptCreateHash(hCryptProv, CALG_MD5, 0, 0, &hHash)) {
			if (CryptHashData(hHash, (BYTE *)pszPassword, lstrlen(pszPassword), 0)) {
				if (CryptDeriveKey(hCryptProv, ENCRYPT_ALGORITHM, hHash, KEYLENGTH, &hKey)) {
					//to set the isEncrypted value to true if all the above if cases are successfull
                                        this->log(this->env, 1, "CryptDeriveKey success");
					isEncrypted = true;
				}
				else {
					this->log(this->env, 1, "VMDataCollector::protect - CryptDeriveKey FAILED - %d", (int)GetLastError());
				}
			}
			else {
				this->log(this->env, 1, "VMDataCollector::protect - CryptHashData FAILED - %d", (int)GetLastError());
			}
		}
		else {
			this->log(this->env, 1, "VMDataCollector::protect - CryptCreateHash FAILED - %d", (int)GetLastError());
		}
	}
        this->log(this->env, 1, "CryptDeriveKey completed");
	if (isEncrypted) {
		DWORD dwBlockLen;
		DWORD dwBufferLen;
		DWORD dwCount;
		PBYTE pbBuffer = NULL;
		dwBlockLen = 1000 - 1000 % ENCRYPT_BLOCK_SIZE;
		if (ENCRYPT_BLOCK_SIZE > 1) {
			dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
		}
		else {
			dwBufferLen = dwBlockLen;
		}
		if (pbBuffer = (BYTE *)malloc(dwBufferLen)) {
			bool fEOF = FALSE;
			do {
				if (ReadFile(hSourceFile, pbBuffer, dwBlockLen, &dwCount, NULL)) {
					if (dwCount < dwBlockLen) {
						fEOF = TRUE;
					}
					if (isEncrypt) {
						if (CryptEncrypt(hKey, NULL, fEOF, 0, pbBuffer, &dwCount, dwBufferLen)) {
							if (WriteFile(hDestinationFile, pbBuffer, dwCount, &dwCount, NULL)) {

							}
						}
					}
					else {
						if (CryptDecrypt(hKey, NULL, fEOF, 0, pbBuffer, &dwCount)) {
							if (WriteFile(hDestinationFile, pbBuffer, dwCount, &dwCount, NULL)) {

							}
						}
					}
				}
			} while (!fEOF);

			if (pbBuffer) {
				free(pbBuffer);
			}
			if (hHash) {
				if ((CryptDestroyHash(hHash))) {
				}
			}
			if (hCryptProv) {
				if ((CryptReleaseContext(hCryptProv, 0))) {
				}
			}
		}
		else {
			this->log(this->env, 1, "VMDataCollector::protect - malloc FAILED - %d", (int)GetLastError());
		}
	}
        this->log(this->env, 1, "before closing file handles");
	//finally closing  file handles
	if (hSourceFile) {
		CloseHandle(hSourceFile);
	}
	if (hDestinationFile) {
		CloseHandle(hDestinationFile);
	}
        this->log(this->env, 1, "after closing file handles");
	if (isEncrypt && isEncrypted) {
		this->log(this->env, 1, "VMDataCollector::protect - going delete File");
		bool isDeleted = DeleteFile(pszSourceFile);
		if (!isDeleted)
		{
			this->log(this->env, 1, "protect - Delete failed first time");
			Sleep(5000);
			isDeleted = DeleteFile(pszSourceFile);
			if (!isDeleted)
			{
				this->log(this->env, 1, "protect - Delete failed second time - error : %d", (int)GetLastError());
				return false;//encrypted but unable to delete the actual file;
			}
			else {
				return true;//encrypted and deleted the actual file
			}
		}
		else {
			return true;//encrypted and deleted the actual file
		}
	}
	else if (isEncrypt && !isEncrypted) {
		this->log(this->env, 1, "VMDataCollector::protect - encrypt FAILED not deleting file");
		return false;//unable to encrypt
	}

	if (wtextSource != NULL) {
		delete[] wtextSource;
	}
	if (wtextDest != NULL) {
		delete[] wtextDest;
	}
        this->log(this->env, 1, "protect completed");
	//   time_t t2 = time(0);   // get time now
	//   uint32 t3 = t2-t;
	//printf("Total time taken : %d\n",t3);
}

int startProcess(JNIEnv *env, wstring cmd, bool wait) {
	size_t len = cmd.length();
	wchar_t *cmdArray = new wchar_t[len + 1];
	wcscpy(cmdArray, cmd.c_str());
	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	HANDLE han;
	DWORD flags = CREATE_NO_WINDOW;

	ZeroMemory(&si, sizeof(STARTUPINFO));
	si.cb = sizeof(STARTUPINFO);
	ZeroMemory(&pi, sizeof(pi));

	SECURITY_ATTRIBUTES sa;
	sa.nLength = sizeof(sa);
	sa.lpSecurityDescriptor = NULL;
	sa.bInheritHandle = TRUE;

	han = CreateFile(L"..\\logs\\DriverLogs.txt",
		FILE_APPEND_DATA,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		&sa,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
	si.hStdInput = NULL;
	si.hStdOutput = han;
	si.dwFlags = STARTF_USESTDHANDLES;

	// Start the child process.
	if (!CreateProcess(NULL, cmdArray, NULL, NULL, TRUE, flags, NULL, NULL, &si, &pi)) {
		//log(env, 1, "CreateProcess failed %d", GetLastError());
		delete[] cmdArray;
		return -1;
	}

	if (wait) {
		WaitForSingleObject(pi.hProcess, INFINITE);
		DWORD status;
		if (!GetExitCodeProcess(pi.hProcess, &status)) {
			//log(env, 1, "GetExitCodeProcess failed %d", GetLastError());
			CloseHandle(pi.hProcess);
			CloseHandle(pi.hThread);
			CloseHandle(han);
			delete[] cmdArray;
			return -1;
		}
		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);
		CloseHandle(han);
		delete[] cmdArray;
		return (int)status;
	}
	CloseHandle(han);
	delete[] cmdArray;
	return 1;
}

bool VMDataCollector::unmountDrive() {
	wstring stopVddkMounter = L"cmd /c Taskkill /T /F /IM VddkMounter.exe";
	int val = startProcess(this->env, stopVddkMounter, true);
	if (!val) {
		return true;
	}
	else {
		this->log(this->env, 1, "unmountDriveError : %d", (int)GetLastError());
		return false;
	}
}

int VMDataCollector::RestoreUncompressedFile(JNIEnv *env, wstring source, wstring destination) {
	bool retVal = CopyFile(source.c_str(), destination.c_str(), false);
	if (!retVal) {
		int errorCode = (int)GetLastError();
		this->log(this->env, 1, "RestoreUncompressedFile CopyFile failed with error: %d", errorCode);
		return errorCode;
	}
	return 0;
}

int VMDataCollector::RestoreDirectoryTree(JNIEnv *env, wstring source, wstring destination) {
	int restoreVal = 0, retVal = 0, errorCode = 0;
	if (!::CreateDirectory(destination.c_str(), NULL)) {
		DWORD error = GetLastError();
		if (error != ERROR_ALREADY_EXISTS) {
			errorCode = (int)GetLastError();
			this->log(this->env, 1, "RestoreDirectoryTree CreateDirectory failed with error: %ws %d", destination.c_str(), errorCode);
			return errorCode;
		}
	}
	WIN32_FIND_DATA findData;
	wstring pattern = source;
	pattern += L"\\*";
	HANDLE hFind = FindFirstFile((LPCWSTR)pattern.c_str(), &findData);
	if (hFind != INVALID_HANDLE_VALUE) {
		do {
			// If not . or ..
			wstring name = findData.cFileName;
			if ((name != L".") && (name != L"..")) {
				wstring newSource = source;
				newSource += '\\';
				newSource += name;
				wstring newDestination = destination;
				newDestination += '\\';
				newDestination += name;
				if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
					if (!::CreateDirectory(newDestination.c_str(), NULL)) {
						DWORD error = GetLastError();
						if (error != ERROR_ALREADY_EXISTS) {
							errorCode = (int)GetLastError();
							this->log(this->env, 1, "RestoreDirectoryTree CreateDirectory failed with error: %ws %d", destination.c_str(), errorCode);
							retVal = errorCode;
						}
						else {
							restoreVal = RestoreDirectoryTree(env, newSource, newDestination);
							if (restoreVal == 112 || restoreVal == 28) {//Insufficient space error codes
								if (hFind) {
									FindClose(hFind);
									hFind = NULL;
								}
								return restoreVal;
							}
							else if (restoreVal != 0) {
								retVal = restoreVal;
							}
						}
					}
					else {
						restoreVal = RestoreDirectoryTree(env, newSource, newDestination);
						if (restoreVal == 112 || restoreVal == 28) {//Insufficient space error codes
							if (hFind) {
								FindClose(hFind);
								hFind = NULL;
							}
							return restoreVal;
						}
						else if (restoreVal != 0) {
							retVal = restoreVal;
						}
					}
				}
				else {
					restoreVal = RestoreUncompressedFile(env, newSource, newDestination);
					if (restoreVal == 112 || restoreVal == 28) {//Insufficient space error codes
						if (hFind) {
							FindClose(hFind);
							hFind = NULL;
						}
						return restoreVal;
					}
					else if (restoreVal != 0) {
						retVal = restoreVal;
					}

				}
			}
		} while (FindNextFile(hFind, &findData));

		FindClose(hFind);
	}
	else {
		this->log(this->env, 1, "RestoreDirectoryTree FindFirstFile failed with error: %d", (int)GetLastError());
	}
	return retVal;
}

JNIEXPORT jboolean JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_encryptFile(JNIEnv * env, jclass obj, jstring filePath, jstring secretKey, jthrowable exceptionObject) {
	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_encryptFile() started");
	int len = env->GetStringLength(filePath) + 1;
	wchar_t* wFilePath = new WCHAR[len]; /* new wchar_t* value in appGlobals*/
	ZeroMemory(wFilePath, len * (sizeof(WCHAR))); /*WinBase.h*/
	wchar_t* temp = (wchar_t*)env->GetStringChars(filePath, 0);
	wcscpy(wFilePath, temp);
	env->ReleaseStringChars(filePath, (jchar *)temp);

	LPWSTR lSecretKey = (LPWSTR)env->GetStringChars(secretKey, 0);
	//env->ReleaseStringChars(secretKey, (jchar *)temp);

	bool isProtected = vmd->protect(wFilePath, lSecretKey, true);
	vmd->log(vmd->env, 1, "encryptStatus : %d", isProtected);
	delete vmd;
	if (isProtected) {
		return JNI_TRUE;
	}
	else {
		return JNI_FALSE;
	}
}

JNIEXPORT jboolean JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_unmountDrives(JNIEnv * env, jclass obj, jthrowable exceptionObject) {
	bool isUnmounted = true;
	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_unmountDrives() started");
	//call to unmountDrive
	bool stopStatus = vmd->unmountDrive();
	vmd->log(env, 1, "stop vddkMounter result : %d", stopStatus);
	if (stopStatus) {
		return JNI_TRUE;
	}
	else {
		return JNI_FALSE;
	}
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_performFLR(JNIEnv * env, jclass obj, jint type, jstring dc, jstring domUser, jstring domPwd, jstring filesList, jstring driveMap, jstring dwnld, jthrowable exceptionObject) {
	VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
	vmd->log(env, 1, "performFLR Started");
	int returnVal = 0;
	LPWSTR dcName = NULL, domUserName = NULL, domPassword = NULL, filesToRestore = NULL, mountMap = NULL, dwnldW = NULL;
	if (dc != NULL)
		dcName = (LPWSTR)env->GetStringChars(dc, NULL);
	if (domUser != NULL)
		domUserName = (LPWSTR)env->GetStringChars(domUser, NULL);
	if (domPwd != NULL)
		domPassword = (LPWSTR)env->GetStringChars(domPwd, NULL);
	if (filesList != NULL)
		filesToRestore = (LPWSTR)env->GetStringChars(filesList, NULL);
	if (driveMap != NULL)
		mountMap = (LPWSTR)env->GetStringChars(driveMap, NULL);
	if (dwnld != NULL)
		dwnldW = (LPWSTR)env->GetStringChars(dwnld, NULL);
	int restoreType = (int)type;
	vmd->log(env, 1, "type : %d", restoreType);
	vmd->log(env, 1, "obtained data");
	vmd->log(env, 1, "dcName : %ws", dcName);
	vmd->log(env, 1, "domUserName : %ws", domUserName);
	vmd->log(env, 1, "filesToRestore : %ws", filesToRestore);
	vmd->log(env, 1, "mountMap : %ws", mountMap);
	vmd->log(env, 1, "dwnldW : %ws", dwnldW);
	wstring dcPath = dcName;
	NETRESOURCE nr;
	DWORD dwFlags;
	DWORD dwRetVal;
	memset(&nr, 0, sizeof(NETRESOURCE));
	nr.dwType = RESOURCETYPE_ANY;
	nr.lpProvider = NULL;
	dwFlags = CONNECT_TEMPORARY;

	if (restoreType == 0 || restoreType == 1) {
		nr.lpRemoteName = dcName;
		dwRetVal = WNetAddConnection2(&nr, domPassword, domUserName, dwFlags);
		if ((dwRetVal != NO_ERROR) && (dwRetVal != 1219)) {
			vmd->log(env, 1, "Connect to DC failed");
			returnVal = (int)dwRetVal;
			vmd->log(env, 1, "Return value : %d", returnVal);
			return (jstring)env->NewStringUTF("Connect to DC failed");
		}
	}
	wstring dwnldPath = dwnldW;
	wstring files = filesToRestore;
	std::vector<string> volumeList;
	size_t pos, innerpos;
	string backupList, delimiter = "<?>";
	backupList.assign(files.begin(), files.end());
	while ((pos = backupList.find(delimiter)) != string::npos) {
		vmd->log(env, 1, "push to volumeList");
		volumeList.push_back(backupList.substr(0, pos));
		backupList.erase(0, pos + delimiter.length());
	}
	wstring mapping = mountMap;
	map<string, string> fileMapping;
	string origPath, mountedPath;
	string mapDelimiter = "--", backupFile;
	backupFile.assign(mapping.begin(), mapping.end());
	while ((pos = backupFile.find(delimiter)) != string::npos) {
		origPath = backupFile.substr(0, pos);

		if ((innerpos = origPath.find(mapDelimiter)) != string::npos) {
			mountedPath = origPath.substr(0, innerpos);
			origPath.erase(0, innerpos + mapDelimiter.length());
			origPath.append("$");
			fileMapping[mountedPath] = origPath;
		}
		backupFile.erase(0, pos + delimiter.length());
	}
	int restoreVal = 0;
	boolean isFailed = false;
	for (vector<string>::iterator loop = volumeList.begin(); loop != volumeList.end(); ++loop) {
		string fileToRestore = *loop;
		wstring fullSrc(fileToRestore.begin(), fileToRestore.end());
		DWORD attr = GetFileAttributes(fullSrc.c_str());
		string cropVolumeList = fileToRestore.substr(2);
		string origDest = fileMapping[(fileToRestore.substr(0, 1))];
		wstring filePath(cropVolumeList.begin(), cropVolumeList.end());
		wstring dest(origDest.begin(), origDest.end());
		wstring fullDest;
		if (restoreType == 0) {//keep
			int cnt = 1;
			fullDest = dcPath + L"\\" + dest + filePath;
			wstring tempDest = fullDest;
			while (PathFileExists(tempDest.c_str())) {
				tempDest = fullDest;
				if (attr & FILE_ATTRIBUTE_DIRECTORY) {
					tempDest = dcPath + L"\\" + dest + filePath + L" (" + to_wstring(cnt++) + L")";
				}
				else {
					size_t dot = tempDest.rfind('.');
					if (std::string::npos != dot) {
						wstring file = tempDest.substr(0, dot);
						wstring extn = tempDest.substr(dot);
						tempDest = file + L" (" + to_wstring(cnt++) + L")" + extn;
					}
				}
			}
			fullDest = tempDest;
		}
		else if (restoreType == 1) {//overwrite
			fullDest = dcPath + L"\\" + dest + filePath;
			vmd->log(env, 1, "fileToRestore [%s]", fileToRestore.c_str());
		}
		else if (restoreType == 2) {//copyTo
			int cnt = 1;
			fullDest = dwnldPath + filePath;
			wstring tempDest = fullDest;
			while (PathFileExists(tempDest.c_str())) {
				tempDest = fullDest;
				if (attr & FILE_ATTRIBUTE_DIRECTORY) {
					tempDest = dwnldPath + filePath + L" (" + to_wstring(cnt++) + L")";
				}
				else {
					size_t dot = tempDest.rfind('.');
					if (std::string::npos != dot) {
						wstring file = tempDest.substr(0, dot);
						wstring extn = tempDest.substr(dot);
						tempDest = file + L" (" + to_wstring(cnt++) + L")" + extn;
					}
				}
			}
			fullDest = tempDest;
		}
		wstring destFol;
		const size_t pos = fullDest.rfind('\\');
		if (std::string::npos != pos) {
			destFol = fullDest.substr(0, pos);
			SHCreateDirectoryEx(NULL, destFol.c_str(), NULL);
		}

		if (attr & FILE_ATTRIBUTE_DIRECTORY) {
			restoreVal = vmd->RestoreDirectoryTree(env, fullSrc, fullDest);
			if (restoreVal == 0) {
				vmd->log(env, 1, "fileToRestore Success");

			}
			else if (restoreVal == 112 || restoreVal == 28) {//Insufficient space error codes
				vmd->log(env, 1, "fileToRestore [%s]", fileToRestore.c_str());
				vmd->log(env, 1, "Stopping restore due to insufficient space");
				return (jstring)env->NewStringUTF("Stopping restore due to insufficient space");
			}
			else {
				isFailed = true;
				vmd->log(env, 1, "fileToRestore [%s]", fileToRestore.c_str());
				vmd->log(env, 1, "fileToRestore Failed");
			}
		}
		else {
			restoreVal = vmd->RestoreUncompressedFile(env, fullSrc, fullDest);

			if (restoreVal == 0) {
				vmd->log(env, 1, "fileToRestore Success");

			}
			else if (restoreVal == 112 || restoreVal == 28) {//Insufficient space error codes
				vmd->log(env, 1, "restoreValue : %d", restoreVal);
				vmd->log(env, 1, "fileToRestore [%s]", fileToRestore.c_str());
				vmd->log(env, 1, "Stopping restore due to insufficient space");
				return (jstring)env->NewStringUTF("Stopping restore due to insufficient space");
			}
			else {
				vmd->log(env, 1, "restoreValue : %d", restoreVal);
				vmd->log(env, 1, "fileToRestore [%s]", fileToRestore.c_str());
				isFailed = true;
				vmd->log(env, 1, "fileToRestore Failed");
			}
		}
	}
	vmd->log(env, 1, "FLR completed");
	if (restoreType == 0 || restoreType == 1) {
		dwRetVal = WNetCancelConnection2(dcName, 0, FALSE);
	}
	if (isFailed) {
		return (jstring)env->NewStringUTF("FLR failed");
	}
	return (jstring)env->NewStringUTF("FLR completed");
}
