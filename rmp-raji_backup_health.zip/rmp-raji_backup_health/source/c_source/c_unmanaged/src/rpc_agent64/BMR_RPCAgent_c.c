

/* this ALWAYS GENERATED file contains the RPC client stubs */


 /* File created by MIDL compiler version 8.00.0603 */
/* at Sun Jan 14 23:02:55 2018
 */
/* Compiler settings for BMR_RPCAgent.idl:
    Oicf, W1, Zp8, env=Win64 (32b run), target_arch=AMD64 8.00.0603 
    protocol : dce , ms_ext, app_config, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#if defined(_M_AMD64)


#pragma warning( disable: 4049 )  /* more than 64k source lines */
#if _MSC_VER >= 1200
#pragma warning(push)
#endif

#pragma warning( disable: 4211 )  /* redefine extern to static */
#pragma warning( disable: 4232 )  /* dllimport identity*/
#pragma warning( disable: 4024 )  /* array to pointer mapping*/
#pragma warning( disable: 4100 ) /* unreferenced arguments in x86 call */

#pragma optimize("", off ) 

#include <string.h>

#include "rpc_agent64/BMR_RPCAgent.h"

#define TYPE_FORMAT_STRING_SIZE   7                                 
#define PROC_FORMAT_STRING_SIZE   257                               
#define EXPR_FORMAT_STRING_SIZE   1                                 
#define TRANSMIT_AS_TABLE_SIZE    0            
#define WIRE_MARSHAL_TABLE_SIZE   0            

typedef struct _BMR_RPCAgent_MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } BMR_RPCAgent_MIDL_TYPE_FORMAT_STRING;

typedef struct _BMR_RPCAgent_MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } BMR_RPCAgent_MIDL_PROC_FORMAT_STRING;

typedef struct _BMR_RPCAgent_MIDL_EXPR_FORMAT_STRING
    {
    long          Pad;
    unsigned char  Format[ EXPR_FORMAT_STRING_SIZE ];
    } BMR_RPCAgent_MIDL_EXPR_FORMAT_STRING;


static const RPC_SYNTAX_IDENTIFIER  _RpcTransferSyntax = 
{{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}};


extern const BMR_RPCAgent_MIDL_TYPE_FORMAT_STRING BMR_RPCAgent__MIDL_TypeFormatString;
extern const BMR_RPCAgent_MIDL_PROC_FORMAT_STRING BMR_RPCAgent__MIDL_ProcFormatString;
extern const BMR_RPCAgent_MIDL_EXPR_FORMAT_STRING BMR_RPCAgent__MIDL_ExprFormatString;

#define GENERIC_BINDING_TABLE_SIZE   0            


/* Standard interface: BMR_RPCAgent, ver. 1.0,
   GUID={0xd752e018,0xc714,0x4c20,{0xac,0xd3,0x92,0xa6,0x53,0x70,0xb5,0x21}} */

handle_t BMR_RPCAgent_IfHandle;


static const RPC_CLIENT_INTERFACE BMR_RPCAgent___RpcClientInterface =
    {
    sizeof(RPC_CLIENT_INTERFACE),
    {{0xd752e018,0xc714,0x4c20,{0xac,0xd3,0x92,0xa6,0x53,0x70,0xb5,0x21}},{1,0}},
    {{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}},
    0,
    0,
    0,
    0,
    0,
    0x00000000
    };
RPC_IF_HANDLE BMR_RPCAgent_v1_0_c_ifspec = (RPC_IF_HANDLE)& BMR_RPCAgent___RpcClientInterface;

extern const MIDL_STUB_DESC BMR_RPCAgent_StubDesc;

static RPC_BINDING_HANDLE BMR_RPCAgent__MIDL_AutoBindHandle;


int startBackup( 
    /* [string][in] */ wchar_t *loc,
    /* [string][in] */ wchar_t *user,
    /* [string][in] */ wchar_t *pwd,
    /* [string][in] */ wchar_t *code,
    /* [string][in] */ wchar_t *filesList,
    /* [in] */ int isEncrypted,
    /* [string][in] */ wchar_t *secretKey)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall2(
                  ( PMIDL_STUB_DESC  )&BMR_RPCAgent_StubDesc,
                  (PFORMAT_STRING) &BMR_RPCAgent__MIDL_ProcFormatString.Format[0],
                  loc,
                  user,
                  pwd,
                  code,
                  filesList,
                  isEncrypted,
                  secretKey);
    return ( int  )_RetVal.Simple;
    
}


int startVolRestore( 
    /* [string][in] */ wchar_t *loc,
    /* [string][in] */ wchar_t *user,
    /* [string][in] */ wchar_t *pwd,
    /* [string][in] */ wchar_t *filesList,
    /* [in] */ int type,
    /* [string][in] */ wchar_t *mergePath,
    /* [string][in] */ wchar_t *mergeUser,
    /* [string][in] */ wchar_t *mergePwd,
    /* [string][in] */ wchar_t *restoreLogFile,
    /* [in] */ int isEncrypted,
    /* [string][in] */ wchar_t *secretKey)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall2(
                  ( PMIDL_STUB_DESC  )&BMR_RPCAgent_StubDesc,
                  (PFORMAT_STRING) &BMR_RPCAgent__MIDL_ProcFormatString.Format[74],
                  loc,
                  user,
                  pwd,
                  filesList,
                  type,
                  mergePath,
                  mergeUser,
                  mergePwd,
                  restoreLogFile,
                  isEncrypted,
                  secretKey);
    return ( int  )_RetVal.Simple;
    
}


int getDiskCnt( void)
{

    CLIENT_CALL_RETURN _RetVal;

    _RetVal = NdrClientCall2(
                  ( PMIDL_STUB_DESC  )&BMR_RPCAgent_StubDesc,
                  (PFORMAT_STRING) &BMR_RPCAgent__MIDL_ProcFormatString.Format[172],
                  0);
    return ( int  )_RetVal.Simple;
    
}


void startServer( void)
{

    NdrClientCall2(
                  ( PMIDL_STUB_DESC  )&BMR_RPCAgent_StubDesc,
                  (PFORMAT_STRING) &BMR_RPCAgent__MIDL_ProcFormatString.Format[204],
                  0);
    
}


void Shutdown( void)
{

    NdrClientCall2(
                  ( PMIDL_STUB_DESC  )&BMR_RPCAgent_StubDesc,
                  (PFORMAT_STRING) &BMR_RPCAgent__MIDL_ProcFormatString.Format[230],
                  0);
    
}


#if !defined(__RPC_WIN64__)
#error  Invalid build platform for this stub.
#endif

#if !(TARGET_IS_NT50_OR_LATER)
#error You need Windows 2000 or later to run this stub because it uses these features:
#error   /robust command line switch.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will fail with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const BMR_RPCAgent_MIDL_PROC_FORMAT_STRING BMR_RPCAgent__MIDL_ProcFormatString =
    {
        0,
        {

	/* Procedure startBackup */

			0x32,		/* FC_BIND_PRIMITIVE */
			0x48,		/* Old Flags:  */
/*  2 */	NdrFcLong( 0x0 ),	/* 0 */
/*  6 */	NdrFcShort( 0x0 ),	/* 0 */
/*  8 */	NdrFcShort( 0x40 ),	/* x86 Stack size/offset = 64 */
/* 10 */	NdrFcShort( 0x8 ),	/* 8 */
/* 12 */	NdrFcShort( 0x8 ),	/* 8 */
/* 14 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0x8,		/* 8 */
/* 16 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 18 */	NdrFcShort( 0x0 ),	/* 0 */
/* 20 */	NdrFcShort( 0x0 ),	/* 0 */
/* 22 */	NdrFcShort( 0x0 ),	/* 0 */
/* 24 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter loc */

/* 26 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 28 */	NdrFcShort( 0x0 ),	/* x86 Stack size/offset = 0 */
/* 30 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter user */

/* 32 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 34 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 36 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter pwd */

/* 38 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 40 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 42 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter code */

/* 44 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 46 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 48 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter filesList */

/* 50 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 52 */	NdrFcShort( 0x20 ),	/* x86 Stack size/offset = 32 */
/* 54 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter isEncrypted */

/* 56 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 58 */	NdrFcShort( 0x28 ),	/* x86 Stack size/offset = 40 */
/* 60 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter secretKey */

/* 62 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 64 */	NdrFcShort( 0x30 ),	/* x86 Stack size/offset = 48 */
/* 66 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Return value */

/* 68 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 70 */	NdrFcShort( 0x38 ),	/* x86 Stack size/offset = 56 */
/* 72 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure startVolRestore */

/* 74 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x48,		/* Old Flags:  */
/* 76 */	NdrFcLong( 0x0 ),	/* 0 */
/* 80 */	NdrFcShort( 0x1 ),	/* 1 */
/* 82 */	NdrFcShort( 0x60 ),	/* x86 Stack size/offset = 96 */
/* 84 */	NdrFcShort( 0x10 ),	/* 16 */
/* 86 */	NdrFcShort( 0x8 ),	/* 8 */
/* 88 */	0x46,		/* Oi2 Flags:  clt must size, has return, has ext, */
			0xc,		/* 12 */
/* 90 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 92 */	NdrFcShort( 0x0 ),	/* 0 */
/* 94 */	NdrFcShort( 0x0 ),	/* 0 */
/* 96 */	NdrFcShort( 0x0 ),	/* 0 */
/* 98 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Parameter loc */

/* 100 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 102 */	NdrFcShort( 0x0 ),	/* x86 Stack size/offset = 0 */
/* 104 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter user */

/* 106 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 108 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 110 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter pwd */

/* 112 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 114 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 116 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter filesList */

/* 118 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 120 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 122 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter type */

/* 124 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 126 */	NdrFcShort( 0x20 ),	/* x86 Stack size/offset = 32 */
/* 128 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter mergePath */

/* 130 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 132 */	NdrFcShort( 0x28 ),	/* x86 Stack size/offset = 40 */
/* 134 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter mergeUser */

/* 136 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 138 */	NdrFcShort( 0x30 ),	/* x86 Stack size/offset = 48 */
/* 140 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter mergePwd */

/* 142 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 144 */	NdrFcShort( 0x38 ),	/* x86 Stack size/offset = 56 */
/* 146 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter restoreLogFile */

/* 148 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 150 */	NdrFcShort( 0x40 ),	/* x86 Stack size/offset = 64 */
/* 152 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Parameter isEncrypted */

/* 154 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 156 */	NdrFcShort( 0x48 ),	/* x86 Stack size/offset = 72 */
/* 158 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter secretKey */

/* 160 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 162 */	NdrFcShort( 0x50 ),	/* x86 Stack size/offset = 80 */
/* 164 */	NdrFcShort( 0x4 ),	/* Type Offset=4 */

	/* Return value */

/* 166 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 168 */	NdrFcShort( 0x58 ),	/* x86 Stack size/offset = 88 */
/* 170 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure getDiskCnt */

/* 172 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x48,		/* Old Flags:  */
/* 174 */	NdrFcLong( 0x0 ),	/* 0 */
/* 178 */	NdrFcShort( 0x2 ),	/* 2 */
/* 180 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 182 */	NdrFcShort( 0x0 ),	/* 0 */
/* 184 */	NdrFcShort( 0x8 ),	/* 8 */
/* 186 */	0x44,		/* Oi2 Flags:  has return, has ext, */
			0x1,		/* 1 */
/* 188 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 190 */	NdrFcShort( 0x0 ),	/* 0 */
/* 192 */	NdrFcShort( 0x0 ),	/* 0 */
/* 194 */	NdrFcShort( 0x0 ),	/* 0 */
/* 196 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Return value */

/* 198 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 200 */	NdrFcShort( 0x0 ),	/* x86 Stack size/offset = 0 */
/* 202 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure startServer */

/* 204 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x48,		/* Old Flags:  */
/* 206 */	NdrFcLong( 0x0 ),	/* 0 */
/* 210 */	NdrFcShort( 0x3 ),	/* 3 */
/* 212 */	NdrFcShort( 0x0 ),	/* x86 Stack size/offset = 0 */
/* 214 */	NdrFcShort( 0x0 ),	/* 0 */
/* 216 */	NdrFcShort( 0x0 ),	/* 0 */
/* 218 */	0x40,		/* Oi2 Flags:  has ext, */
			0x0,		/* 0 */
/* 220 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 222 */	NdrFcShort( 0x0 ),	/* 0 */
/* 224 */	NdrFcShort( 0x0 ),	/* 0 */
/* 226 */	NdrFcShort( 0x0 ),	/* 0 */
/* 228 */	NdrFcShort( 0x0 ),	/* 0 */

	/* Procedure Shutdown */

/* 230 */	0x32,		/* FC_BIND_PRIMITIVE */
			0x48,		/* Old Flags:  */
/* 232 */	NdrFcLong( 0x0 ),	/* 0 */
/* 236 */	NdrFcShort( 0x4 ),	/* 4 */
/* 238 */	NdrFcShort( 0x0 ),	/* x86 Stack size/offset = 0 */
/* 240 */	NdrFcShort( 0x0 ),	/* 0 */
/* 242 */	NdrFcShort( 0x0 ),	/* 0 */
/* 244 */	0x40,		/* Oi2 Flags:  has ext, */
			0x0,		/* 0 */
/* 246 */	0xa,		/* 10 */
			0x1,		/* Ext Flags:  new corr desc, */
/* 248 */	NdrFcShort( 0x0 ),	/* 0 */
/* 250 */	NdrFcShort( 0x0 ),	/* 0 */
/* 252 */	NdrFcShort( 0x0 ),	/* 0 */
/* 254 */	NdrFcShort( 0x0 ),	/* 0 */

			0x0
        }
    };

static const BMR_RPCAgent_MIDL_TYPE_FORMAT_STRING BMR_RPCAgent__MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */
/*  2 */	
			0x11, 0x8,	/* FC_RP [simple_pointer] */
/*  4 */	
			0x25,		/* FC_C_WSTRING */
			0x5c,		/* FC_PAD */

			0x0
        }
    };

static const unsigned short BMR_RPCAgent_FormatStringOffsetTable[] =
    {
    0,
    74,
    172,
    204,
    230
    };


static const MIDL_STUB_DESC BMR_RPCAgent_StubDesc = 
    {
    (void *)& BMR_RPCAgent___RpcClientInterface,
    MIDL_user_allocate,
    MIDL_user_free,
    &BMR_RPCAgent_IfHandle,
    0,
    0,
    0,
    0,
    BMR_RPCAgent__MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0x50002, /* Ndr library version */
    0,
    0x800025b, /* MIDL Version 8.0.603 */
    0,
    0,
    0,  /* notify & notify_flag routine table */
    0x1, /* MIDL flag */
    0, /* cs routines */
    0,   /* proxy/server info */
    0
    };
#pragma optimize("", on )
#if _MSC_VER >= 1200
#pragma warning(pop)
#endif


#endif /* defined(_M_AMD64)*/

