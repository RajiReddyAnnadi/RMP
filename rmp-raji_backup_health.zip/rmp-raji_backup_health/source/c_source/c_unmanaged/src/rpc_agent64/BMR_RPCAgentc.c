#include <RMPNative.h>
#include <rpc_agent64/BMR_RPCAgent.h>
#include <util/BMR_RPCAgentc.h>

RPC_WSTR pszStringBinding = NULL;

jobject triggerBackup(JNIEnv *env,jstring dc,jstring domain,jstring user,jstring pwd,jstring loc,jstring locUser,jstring locPwd,jstring code,jstring jFilesList, jint encypted, jstring encrPwd)
{
    log(env, 1, "triggerBackup Start 2");
    jobject properties = env->NewObject(propClass, propConID);
    
    LPWSTR dcName = NULL, domainName = NULL, userName = NULL, password = NULL, location = NULL, locationUser = NULL, locationPwd = NULL, buCode = NULL, filesList = NULL, secretKey = NULL;
    RPC_STATUS status;
    unsigned long ulCode;
    
    dcName = (LPWSTR) env->GetStringChars(dc, NULL);
    domainName = (LPWSTR) env->GetStringChars(domain, NULL);
    userName = (LPWSTR) env->GetStringChars(user, NULL);
    password = (LPWSTR) env->GetStringChars(pwd, NULL);
    location = (LPWSTR) env->GetStringChars(loc, NULL);
    locationUser = (LPWSTR) env->GetStringChars(locUser, NULL);
    locationPwd = (LPWSTR) env->GetStringChars(locPwd, NULL);
    buCode = (LPWSTR) env->GetStringChars(code, NULL);
    filesList = (LPWSTR) env->GetStringChars(jFilesList, NULL);
    int isEncrypted = (int)encypted;
    secretKey = (LPWSTR) env->GetStringChars(encrPwd, NULL);
        
    status = bindRPC(env, dcName, domainName, userName, password);
    
    if(status)
        return properties;
    
    RpcTryExcept  
    {
        int retValInt = startBackup(location,locationUser,locationPwd,buCode,filesList,isEncrypted,secretKey);
        jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
	    env->CallObjectMethod(properties, propPutID, env->NewStringUTF("ReturnVal"),  installObject);
        //Shutdown();
    }
    RpcExcept(1) 
    {
        ulCode = RpcExceptionCode();
        log(env, 1,"From triggerBackup: Runtime reported exception");
        jobject installObject = env->NewObject(intClass, intConID, (jint) ulCode);
        env->CallObjectMethod(properties, propPutID, env->NewStringUTF("CantAccess"), installObject);
    }
    RpcEndExcept
    
    status = unbindRPC();
    
    if(status)
        return properties;
    
    return properties;
}

jobject performVLR(JNIEnv *env,jstring dc,jstring domain,jstring user,jstring pwd,jstring loc,jstring locUser,jstring locPwd,jstring jFilesList,jint type,jstring mergePath,jstring mergeUser,jstring mergePwd,jstring restoreLog, jint encypted, jstring encrPwd)
{
    log(env, 1, "performVLR Start 2");
    jobject properties = env->NewObject(propClass, propConID);

    LPWSTR dcName = NULL, domainName = NULL, userName = NULL, password = NULL, location = NULL, locationUser = NULL, locationPwd = NULL, filesList = NULL, secretKey = NULL;
    LPWSTR mergeFolder = NULL, mergeUserName = NULL, mergePassword = NULL,restoreLogFile = NULL;
    int backupType = type;
    RPC_STATUS status;
    unsigned long ulCode;

    dcName = (LPWSTR) env->GetStringChars(dc, NULL);
    domainName = (LPWSTR) env->GetStringChars(domain, NULL);
    userName = (LPWSTR) env->GetStringChars(user, NULL);
    password = (LPWSTR) env->GetStringChars(pwd, NULL);
    location = (LPWSTR) env->GetStringChars(loc, NULL);
    locationUser = (LPWSTR) env->GetStringChars(locUser, NULL);
    locationPwd = (LPWSTR) env->GetStringChars(locPwd, NULL);
    filesList = (LPWSTR) env->GetStringChars(jFilesList, NULL);
    mergeFolder = (LPWSTR) env->GetStringChars(mergePath, NULL);
    mergeUserName = (LPWSTR) env->GetStringChars(mergeUser, NULL);
    mergePassword = (LPWSTR) env->GetStringChars(mergePwd, NULL);
    restoreLogFile = (LPWSTR) env->GetStringChars(restoreLog, NULL);
    int isEncrypted = (int)encypted;
    secretKey = (LPWSTR) env->GetStringChars(encrPwd, NULL);

    status = bindRPC(env, dcName, domainName, userName, password);

    if(status)
        return properties;

    RpcTryExcept
    {
        int retValInt = startVolRestore(location,locationUser,locationPwd,filesList,backupType,mergeFolder, mergeUserName, mergePassword,restoreLogFile,isEncrypted,secretKey);
        jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt);
	    env->CallObjectMethod(properties, propPutID, env->NewStringUTF("ReturnVal"),  installObject);
        //Shutdown();
    }
    RpcExcept(1)
    {
        ulCode = RpcExceptionCode();
        log(env, 1,"From performVLR: Runtime reported exception");
        jobject installObject = env->NewObject(intClass, intConID, (jint) ulCode);
        env->CallObjectMethod(properties, propPutID, env->NewStringUTF("CantAccess"), installObject);
    }
    RpcEndExcept

    status = unbindRPC();

    if(status)
        return properties;

    return properties;
}

jint getCurrentDiskCnt(JNIEnv *env,jstring dc,jstring domain,jstring user,jstring pwd)
{
    log(env, 1, "getCurrentDiskCnt Start 2");
    
    jint currentDiskCnt = -1;
    unsigned long ulCode;
    
    LPWSTR dcName = NULL, domainName = NULL, userName = NULL, password = NULL;
    RPC_STATUS status;
    
    dcName = (LPWSTR) env->GetStringChars(dc, NULL);
    domainName = (LPWSTR) env->GetStringChars(domain, NULL);
    userName = (LPWSTR) env->GetStringChars(user, NULL);
    password = (LPWSTR) env->GetStringChars(pwd, NULL);
    
    status = bindRPC(env, dcName, domainName, userName, password);
    
    if(status)
        return currentDiskCnt;
    
    RpcTryExcept  
    {
        currentDiskCnt = (jint)getDiskCnt(); 
    }
    RpcExcept(1) 
    {
        ulCode = RpcExceptionCode();
        log(env, 1,"From getCurrentDiskCnt: Runtime reported exception code = %lu",ulCode);
        currentDiskCnt = -1;
    }
    RpcEndExcept
    
    status = unbindRPC();
    
    if(status)
        return currentDiskCnt;
    
    return currentDiskCnt;
    
}

RPC_STATUS bindRPC(JNIEnv *env, LPWSTR dcName, LPWSTR domainName, LPWSTR userName, LPWSTR password) {
    
    RPC_STATUS status;
    RPC_WSTR pszUuid = NULL;
    RPC_WSTR pszProtocolSequence = (unsigned short *) L"ncacn_np";
    RPC_WSTR pszNetworkAddress = (unsigned short *) dcName;
    RPC_WSTR pszEndpoint = (unsigned short *) L"\\pipe\\BMR_RPCAgent";
    RPC_WSTR pszOptions = NULL;
    boolean ret = TRUE;
    HANDLE lTokenHandle = NULL;
    
    ret = LogonUser(userName, domainName, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &lTokenHandle);
    
    if (ret) {
        ret = ImpersonateLoggedOnUser(lTokenHandle);
        if (!ret) {
            log(env, 1, "ERROR while calling ImpersonateLoggedOnUser API");
        }
        CloseHandle(lTokenHandle);
    } else {
        log(env, 1, "ERROR while calling LogonUser API, err code");
    }
    
    status = RpcStringBindingCompose(pszUuid,
            pszProtocolSequence,
            pszNetworkAddress,
            pszEndpoint,
            pszOptions,
            &pszStringBinding);

    if (status) return status;

    status = RpcBindingFromStringBinding(pszStringBinding, &BMR_RPCAgent_IfHandle);

    if (status == RPC_S_OK) {
        log(env, 1, "success");
    } else if (status == RPC_S_INVALID_STRING_BINDING) {
        log(env, 1, "invalid binding");
    } else if (status == RPC_S_PROTSEQ_NOT_SUPPORTED) {
        log(env, 1, "prot seq not supported");
    } else if (status == RPC_S_INVALID_RPC_PROTSEQ) {
        log(env, 1, "prot seq invalid");
    } else if (status == RPC_S_INVALID_ENDPOINT_FORMAT) {
        log(env, 1, "endpoint format invalid");
    } else if (status == RPC_S_STRING_TOO_LONG) {
        log(env, 1, "string too long");
    } else if (status == RPC_S_INVALID_NET_ADDR) {
        log(env, 1, "netwrk addr invalid");
    } else if (status == RPC_S_INVALID_ARG) {
        log(env, 1, "argument invalid");
    } else if (status == RPC_S_INVALID_NAF_ID) {
        log(env, 1, "naf invalid");
    }

    if (status) return status;
    
    return status;
}

RPC_STATUS unbindRPC()
{
    RPC_STATUS status;
    
    status = RpcStringFree(&pszStringBinding); 
 
    if (status) return status;
 
    status = RpcBindingFree(&BMR_RPCAgent_IfHandle);
 
    if (status) return status;
    
    return status;
}

/******************************************************/
/*         MIDL allocate and free                     */
/******************************************************/
 
void __RPC_FAR * __RPC_USER midl_user_allocate(size_t len)
{
    return(malloc(len));
}
 
void __RPC_USER midl_user_free(void __RPC_FAR * ptr)
{
    free(ptr);
}