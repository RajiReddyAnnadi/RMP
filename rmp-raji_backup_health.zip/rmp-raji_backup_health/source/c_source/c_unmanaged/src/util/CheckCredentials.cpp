#include <util/CheckCredentials.h>
#include <RMPNative.h>

jobject checkCredentials(JNIEnv *env,jstring loc, jstring user, jstring pass,jstring connDisconn)
{
	log(env, 1, "checkCredentials Start 2");
	jobject properties = env->NewObject(propClass, propConID);
	LPWSTR userName,password ,location = NULL,connectDisconnect=NULL;
	location= (LPWSTR)env->GetStringChars(loc, NULL);
        if(user == NULL || pass == NULL){
        	log(env, 1, "checkCredentials Username or password null");
	userName = NULL;
	password = NULL;
        }else{
        	log(env, 1, "checkCredentials not null");
            userName = (LPWSTR)env->GetStringChars(user, NULL);
	    password = (LPWSTR)env->GetStringChars(pass, NULL);
	    log(env, 1, "checkCredentials not null..done converting");
        }
        connectDisconnect= (LPWSTR)env->GetStringChars(connDisconn, NULL);
        log(env, 1, "checkCredentials converted connectdisconnect");
	DWORD dwRetVal;
        if(wcscmp(connectDisconnect,L"connect")==0){
        	log(env, 1, "checkCredentials CONNECT");
    NETRESOURCE nr;
    DWORD dwFlags; 
	
    memset(&nr, 0, sizeof (NETRESOURCE));
	
    nr.dwType = RESOURCETYPE_ANY;
    nr.lpRemoteName = location;
    nr.lpProvider = NULL;
    dwFlags = CONNECT_TEMPORARY;

    dwRetVal = WNetAddConnection2(&nr, password, userName, dwFlags);
    log(env, 1, "checkCredentials dwRetVal -> %ld",dwRetVal);
    if(dwRetVal == 64){
        log(env, 1, "Got error code 64(network no longer available)...trying to reconnect...");
        Sleep(500);
        dwRetVal = WNetAddConnection2(&nr, password, userName, dwFlags);
    }
    if(dwRetVal==NO_ERROR)
	{
			
                        __int64 lpFreeBytesAvailable, lpTotalNumberOfBytes, lpTotalNumberOfFreeBytes;
			BOOL test;
			log(env, 1, "checkCredentials Going to call GetFreeDiskSpaceEx");
			test = GetDiskFreeSpaceEx(location,
					(PULARGE_INTEGER)&lpFreeBytesAvailable,
					(PULARGE_INTEGER)&lpTotalNumberOfBytes,
					(PULARGE_INTEGER)&lpTotalNumberOfFreeBytes
					);

			int retValInt;
			if(test)
			{
				log(env, 1, "checkCredentials GetFreeDiskSpaceEx SUCCESS");
				retValInt = (int)dwRetVal;
				jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
				env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Success"),  installObject);
			}
			else
			{
				log(env, 1, "checkCredentials GetFreeDiskSpaceEx FAILURE");
				retValInt = -1;
				jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
				env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Other"),  installObject);
				return properties;
			}

			long LfreeSpaceAvailable = lpFreeBytesAvailable/1024/1024/1024;
			log(env, 1, "checkCredentials 1");
			int freeSpaceAvailable = (int) LfreeSpaceAvailable;
			log(env, 1, "checkCredentials 2");
			jobject jfreeSpaceAvailable = env->NewObject(intClass, intConID, (jint)freeSpaceAvailable); 
			log(env, 1, "checkCredentials 3");
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("FreeSpaceAvailable"),  jfreeSpaceAvailable);
			log(env, 1, "checkCredentials 4");
			long LtotalCapacity = lpTotalNumberOfBytes/1024/1024/1024;
			log(env, 1, "checkCredentials 5");
			int totalCapacity = (int) LtotalCapacity;
			log(env, 1, "checkCredentials 6");
			jobject jtotalCapacity = env->NewObject(intClass, intConID, (jint)totalCapacity); 
			log(env, 1, "checkCredentials 7");
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Capacity"),  jtotalCapacity);
			log(env, 1, "checkCredentials 8");
			long LfreeSpace = lpTotalNumberOfFreeBytes/1024/1024/1024;
			log(env, 1, "checkCredentials 9");
			int freeSpace = (int) LfreeSpace;
			log(env, 1, "checkCredentials 10");
			jobject jfreeSpace = env->NewObject(intClass, intConID, (jint)freeSpace); 
			log(env, 1, "checkCredentials 11");
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("FreeSpace"),  jfreeSpace);
			log(env, 1, "checkCredentials 12");
       }
	else if(dwRetVal==5)
	{
			int retValInt = (int)dwRetVal;
			jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Access_Denied"),  installObject);
        }
	else if(dwRetVal==53)
	{
			int retValInt = (int)dwRetVal;
			jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Bad_Net_Path"),  installObject);
        }
	else if(dwRetVal==67)
	{
			int retValInt = (int)dwRetVal;
			jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Bad_Net_Name"),  installObject);
        }
	else if(dwRetVal==86)
	{
			int retValInt = (int)dwRetVal;
			jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Invalid_Password"),  installObject);
        }
	else if(dwRetVal==1203)
	{
			int retValInt = (int)dwRetVal;
			jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("NoNet_BadPath"),  installObject);
        }
    else if(dwRetVal==1219)
	{
			//int retValInt = (int)dwRetVal;
			int retValInt = 0;
                        __int64 lpFreeBytesAvailable, lpTotalNumberOfBytes, lpTotalNumberOfFreeBytes;
			BOOL test;
                        test = GetDiskFreeSpaceEx(location,
					(PULARGE_INTEGER)&lpFreeBytesAvailable,
					(PULARGE_INTEGER)&lpTotalNumberOfBytes,
					(PULARGE_INTEGER)&lpTotalNumberOfFreeBytes
					);
            log(env, 1, "ERROR_SESSION_CONFLICT. Session is active, so not stoppping the process.");
			if(test)
			{
				log(env, 1, "checkCredentials GetFreeDiskSpaceEx SUCCESS");
				retValInt = 0;
				jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
				env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Success"),  installObject);
			}
			else
			{
				log(env, 1, "checkCredentials GetFreeDiskSpaceEx FAILURE");
				retValInt = -1;
				jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
				env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Other"),  installObject);
				return properties;
			}

			long LfreeSpaceAvailable = lpFreeBytesAvailable/1024/1024/1024;
			log(env, 1, "checkCredentials 1");
			int freeSpaceAvailable = (int) LfreeSpaceAvailable;
			log(env, 1, "checkCredentials 2");
			jobject jfreeSpaceAvailable = env->NewObject(intClass, intConID, (jint)freeSpaceAvailable); 
			log(env, 1, "checkCredentials 3");
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("FreeSpaceAvailable"),  jfreeSpaceAvailable);
			log(env, 1, "checkCredentials 4");
			long LtotalCapacity = lpTotalNumberOfBytes/1024/1024/1024;
			log(env, 1, "checkCredentials 5");
			int totalCapacity = (int) LtotalCapacity;
			log(env, 1, "checkCredentials 6");
			jobject jtotalCapacity = env->NewObject(intClass, intConID, (jint)totalCapacity); 
			log(env, 1, "checkCredentials 7");
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Capacity"),  jtotalCapacity);
			log(env, 1, "checkCredentials 8");
			long LfreeSpace = lpTotalNumberOfFreeBytes/1024/1024/1024;
			log(env, 1, "checkCredentials 9");
			int freeSpace = (int) LfreeSpace;
			log(env, 1, "checkCredentials 10");
			jobject jfreeSpace = env->NewObject(intClass, intConID, (jint)freeSpace); 
			log(env, 1, "checkCredentials 11");
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("FreeSpace"),  jfreeSpace);
			log(env, 1, "checkCredentials 12");
            
			jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt);
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Success"),  installObject);
        }
	else if(dwRetVal==1326)
	{
			int retValInt = (int)dwRetVal;
			jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Logon_Failure"),  installObject);
        }
	else if(dwRetVal==2202)
	{
			int retValInt = (int)dwRetVal;
			jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Bad_UserName"),  installObject);
       }
	else if (dwRetVal == 71)
	{
		int retValInt = (int)dwRetVal;
		jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt);
		env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Connections_Exceeded"), installObject);
	}
	else
	{
	        int retValInt = (int)dwRetVal;
			jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Other"),  installObject);
        }
        }else{
        	log(env, 1, "checkCredentials disconnect");
	dwRetVal = WNetCancelConnection2(location, 0, FALSE);
        int retValInt = (int)dwRetVal;
			jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
			env->CallObjectMethod(properties, propPutID, env->NewStringUTF("Return"),  installObject);
        }
        log(env, 1, "checkCredentials Returning");
	return properties;
}
