#include <util/BMRFileLevelRestore.h>
#include <RMPNative.h>

int RestoreUncompressedFile(JNIEnv *env, wstring source, wstring destination) {
    int errorCode;
    if (PathFileExists(destination.c_str())) {
        HANDLE hDestFile = CreateFile(
                destination.c_str(),
                GENERIC_READ,
                FILE_SHARE_READ,
                NULL,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL,
                NULL);
        if (hDestFile == INVALID_HANDLE_VALUE) {
            errorCode = (int) GetLastError();
            log(env, 1, "RestoreUncompressedFile CreateFile failed with error: %d", errorCode);
            return errorCode;
        }
        CloseHandle(hDestFile);
    }
    bool retVal = CopyFile(source.c_str(), destination.c_str(), false);
    if (!retVal) {
        errorCode = (int) GetLastError();
        log(env, 1, "RestoreUncompressedFile CopyFile failed with error: %d", errorCode);
        return errorCode;
    }
    return 0;
}

int RestoreUnencryptedFile(JNIEnv *env, wstring source, wstring destination) {
    gzFile hSourceFile;
    int errorCode;
    int decompHan = _wopen(source.c_str(), _O_RDONLY | _O_BINARY);
    if (decompHan == -1) {
        log(env, 1, "RestoreUnencryptedFile wopen error: %d", errno);
        return errno;
    }
    hSourceFile = gzdopen(decompHan, "rb");
    if (!hSourceFile) {
        log(env, 1, "Decompress open error: %ws", source.c_str());
        return 1;
    }
    HANDLE hDestinationFile = ::CreateFile(
            destination.c_str(),
            GENERIC_WRITE | WRITE_OWNER | WRITE_DAC,
            FILE_SHARE_READ,
            NULL,
            CREATE_ALWAYS,
            FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_BACKUP_SEMANTICS,
            NULL);
    if (hDestinationFile == INVALID_HANDLE_VALUE) {
        errorCode = (int) GetLastError();
        log(env, 1, "Accessing destination failed with error: %ws %d", destination.c_str(), errorCode);
        gzclose(hSourceFile);
        return errorCode;
    }

    const DWORD DEFAULT_BUFFER_SIZE = 4086;
    DWORD bytesRead, bytesWritten;
    BYTE buffer[DEFAULT_BUFFER_SIZE];
    LPVOID context = NULL;

    while ((bytesRead = gzread(hSourceFile, buffer, DEFAULT_BUFFER_SIZE)) > 0) {
        if (!BackupWrite(hDestinationFile, buffer, bytesRead, &bytesWritten, FALSE, TRUE, &context)) {
            errorCode = (int) GetLastError();
            log(env, 1, "DeCompress write failed with error: %d", errorCode);
            CloseHandle(hDestinationFile);
            gzclose(hSourceFile);
            return errorCode;
        }
    }
    BackupWrite(hDestinationFile, NULL, 0, NULL, TRUE, TRUE, &context);
    gzclose(hSourceFile);
    CloseHandle(hDestinationFile);
    return 0;
}

int RestoreEncryptedFile(JNIEnv *env, wstring source, wstring destination, wstring secretKey) {
    return decryptExtract(env, source, destination, &secretKey[0]);
}

int decryptExtract(JNIEnv *env, wstring source, wstring destination, LPTSTR secretKey) {
    log(env, 1, "In decryptExtract\n");
    const DWORD DEFAULT_BUFFER_SIZE = 4096;
    FILE *in;
    int ret;
    z_stream strm;
    unsigned char *input = new unsigned char[DEFAULT_BUFFER_SIZE];
    unsigned char *output = new unsigned char[DEFAULT_BUFFER_SIZE];
    DWORD dwBlockLen;
    DWORD dwCount;
    HCRYPTKEY hKey = generateHashKey(env, secretKey);
    if (hKey == -1) {
        log(env, 1, "hkey is -1\n");
        if (input)
            delete[] input;
        if (output)
            delete[] output;
        return 1;
    }
    int fd = _wopen(source.c_str(), _O_RDONLY | _O_BINARY);
    if (fd == -1) {
        int errsv = errno;
        log(env, 1, "_wopen: could not open for reading %d\n", errsv);
        return 1;
    }
    in = _fdopen(fd, "rb");
    if (in == NULL) {
        log(env, 1, "_fdopen: could not open %ws\n", source.c_str());
        return 1;
    }
    HANDLE hDestinationFile = CreateFile(destination.c_str(), FILE_WRITE_DATA, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hDestinationFile == INVALID_HANDLE_VALUE) {
        int val = (int) GetLastError();
        log(env, 1, "decryptExtract invalid handle %d\n", val);
        if (input)
            delete[] input;
        if (output)
            delete[] output;
        return val;
    }
    /* initialize file and inflate state to start there */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = inflateInit2(&strm, 47); /* raw inflate */
    if (ret != Z_OK) {
        log(env, 1, "inflateInit2 failed %d\n", ret);
        if (input)
            delete[] input;
        if (output)
            delete[] output;
        return 1;
    }

    bool fEOF = false;
    while (!fEOF) {
        memset(input, 0, DEFAULT_BUFFER_SIZE);
        dwBlockLen = fread(input, 1, DEFAULT_BUFFER_SIZE, in);
        if (ferror(in)) {
            ret = Z_ERRNO;
            log(env, 1, "Z_ERRNO failed\n");
            if (input)
                delete[] input;
            if (output)
                delete[] output;
            return 1;
        }
        if (dwBlockLen < DEFAULT_BUFFER_SIZE) {
            fEOF = TRUE;
        }
        if (input != NULL) {
            if (CryptDecrypt(hKey, NULL, fEOF, 0, input, &dwBlockLen)) {
                strm.avail_in = dwBlockLen;
            } else {
                DWORD dw = GetLastError();
                log(env, 1, "cryptdecrypt failed %d\n", (int) dw);
                if (input)
                    delete[] input;
                if (output)
                    delete[] output;
                return (int) dw;
            }
        }
        strm.next_in = input;

        do {
            strm.avail_out = DEFAULT_BUFFER_SIZE;
            strm.next_out = output;
            ret = inflate(&strm, Z_NO_FLUSH); /* normal inflate */
            if (ret == Z_NEED_DICT) {
                log(env, 1, "Z_NEED_DICT\n");
                ret = Z_DATA_ERROR;
            }
            if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR) {
                log(env, 1, "Z_MEM_ERROR or Z_DATA_ERROR %d\n", ret);
                if (input)
                    delete[] input;
                if (output)
                    delete[] output;
                return 1;
            }
            int have = DEFAULT_BUFFER_SIZE - strm.avail_out;
            if (WriteFile(hDestinationFile, output, have, &dwCount, NULL)) {
            } else {
                int val = (int) GetLastError();
                log(env, 1, "WriteFile error %d\n", val);
                if (input)
                    delete[] input;
                if (output)
                    delete[] output;
                return val;
            }
            memset(output, 0, DEFAULT_BUFFER_SIZE);
        } while (strm.avail_out == 0);
    }
    fclose(in);
    CloseHandle(hDestinationFile);
    (void) inflateEnd(&strm);
    if (input)
        delete[] input;
    if (output)
        delete[] output;
    return 0;
}

HCRYPTKEY generateHashKey(JNIEnv *env, LPTSTR pszPassword) {
    HCRYPTPROV hCryptProv = NULL;
    HCRYPTKEY hKey = NULL;
    HCRYPTHASH hHash = NULL;
    bool CryptAcquireContextStatus = false;
    if (CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, 0)) {
        CryptAcquireContextStatus = true;
    } else {
        log(env, 1, "CryptAcquireContext failed\n");
        if (CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, CRYPT_NEWKEYSET)) {
            CryptAcquireContextStatus = true;
        } else {
            log(env, 1, "CryptAcquireContext failed again\n");
            return -1;
        }
    }
    if (CryptAcquireContextStatus) {
        if (CryptCreateHash(hCryptProv, CALG_MD5, 0, 0, &hHash)) {
            if (CryptHashData(hHash, (BYTE *) pszPassword, lstrlen(pszPassword), 0)) {
                if (CryptDeriveKey(hCryptProv, ENCRYPT_ALGORITHM, hHash, KEYLENGTH, &hKey)) {
                    return hKey;
                } else {
                    log(env, 1, "CryptDeriveKey failed\n");
                    return -1;
                }
            } else {
                log(env, 1, "CryptHashData failed\n");
                return -1;
            }
        } else {
            log(env, 1, "CryptCreateHash failed\n");
            return -1;
        }
    }
}

int RestoreDirectoryTree(JNIEnv *env, wstring source, wstring destination, int backupMode, bool isEncrypted, wstring secretKey) {
    int restoreVal = 0, retVal = 0;
    int errorCode;
    if (!::CreateDirectory(destination.c_str(), NULL)) {
        DWORD error = GetLastError();
        if (error != ERROR_ALREADY_EXISTS) {
            errorCode = (int) error;
            log(env, 1, "RestoreDirectoryTree CreateDirectory failed with error: %ws %d", destination.c_str(), errorCode);
            return errorCode;
        }
    }
    WIN32_FIND_DATA findData;
    wstring pattern = source;
    pattern += L"\\*";
    HANDLE hFind = FindFirstFile((LPCWSTR) pattern.c_str(), &findData);
    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            // If not . or ..
            wstring name = findData.cFileName;
            if (name != L"." && name != L"..") {
                wstring newSource = source;
                newSource += '\\';
                newSource += name;
                wstring newDestination = destination;
                newDestination += '\\';
                newDestination += name;
                if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                    if (!::CreateDirectory(newDestination.c_str(), NULL)) {
                        DWORD error = GetLastError();
                        if (error != ERROR_ALREADY_EXISTS) {
                            errorCode = (int) error;
                            log(env, 1, "RestoreDirectoryTree CreateDirectory failed with error: %ws %d", destination.c_str(), errorCode);
                            retVal = errorCode;
                        } else {
                            restoreVal = RestoreDirectoryTree(env, newSource, newDestination, backupMode, isEncrypted, secretKey);
                            if (restoreVal == 112 || restoreVal == 28) {//Insufficient space error codes
                                if (hFind) {
                                    FindClose(hFind);
                                    hFind = NULL;
                                }
                                return restoreVal;
                            } else if (restoreVal != 0) {
                                retVal = restoreVal;
                            }
                        }
                    } else {
                        restoreVal = RestoreDirectoryTree(env, newSource, newDestination, backupMode, isEncrypted, secretKey);
                        if (restoreVal == 112 || restoreVal == 28) {//Insufficient space error codes
                            if (hFind) {
                                FindClose(hFind);
                                hFind = NULL;
                            }
                            return restoreVal;
                        } else if (restoreVal != 0) {
                            retVal = restoreVal;
                        }
                    }
                } else {
                    if (!newSource.compare(0, 2, L"\\\\")) {
                        if (isEncrypted) {
                            restoreVal = RestoreEncryptedFile(env, newSource, newDestination, secretKey);
                        } else {
                            restoreVal = RestoreUnencryptedFile(env, newSource, newDestination);
                        }
                    } else {
                        if (backupMode == 0) {
                            if (isEncrypted) {
                                restoreVal = RestoreEncryptedFile(env, newSource, newDestination, secretKey);
                            } else {
                                restoreVal = RestoreUnencryptedFile(env, newSource, newDestination);
                            }
                        } else {
                            restoreVal = RestoreUncompressedFile(env, newSource, newDestination);
                        }
                    }
                    if (restoreVal == 112 || restoreVal == 28) {//Insufficient space error codes
                        if (hFind) {
                            FindClose(hFind);
                            hFind = NULL;
                        }
                        return restoreVal;
                    } else if (restoreVal != 0) {
                        retVal = restoreVal;
                    }

                }
            }
        } while (FindNextFile(hFind, &findData));

        FindClose(hFind);
    } else {
        errorCode = (int) GetLastError();
        log(env, 1, "RestoreDirectoryTree FindFirstFile failed with error: %d", errorCode);
        retVal = errorCode;
    }
    return retVal;
}

void renameFiles(wstring renameList, wstring dcPath, int restoreType, std::map<wstring, wstring> *restoredFilesMap, wstring dwnldPath) {
    string oldName, newName;
    string renDelimiter = "--", renameFile, delimiter = "<?>";
    string cropOName, cropNName, oDrive, nDrive;
    size_t pos, innerpos;
    std::map<wstring, wstring> *renamedFilesMap = new map<wstring, wstring>();

    renameFile.assign(renameList.begin(), renameList.end());

    while ((pos = renameFile.find(delimiter)) != string::npos) {
        newName = renameFile.substr(0, pos);

        if ((innerpos = newName.find(renDelimiter)) != string::npos) {
            oldName = newName.substr(0, innerpos);
            newName.erase(0, innerpos + renDelimiter.length());
            cropOName = oldName.substr(2);
            wstring cropONameW(cropOName.begin(), cropOName.end());
            cropNName = newName.substr(2);
            wstring cropNNameW(cropNName.begin(), cropNName.end());
            oDrive = oldName.substr(0, 1);
            wstring oDriveW(oDrive.begin(), oDrive.end());
            nDrive = newName.substr(0, 1);
            wstring nDriveW(nDrive.begin(), nDrive.end());
            wstring oldNameW;
            wstring newNameW;
            wstring oldNameWNew,oldNameWMod;

            if (restoreType == 2) {
                BOOL isChangedCopyto = false;
                oldNameW = dwnldPath + cropONameW;
                oldNameWMod = dwnldPath + cropONameW;
                newNameW = dwnldPath + cropNNameW;
                wstring cropONameWithoutSlash = cropONameW.substr(1);
                size_t firstSlashPos = cropONameWithoutSlash.find(L"\\");
                if (std::wstring::npos != firstSlashPos) {
                    wstring parentFolderW = cropONameWithoutSlash.substr(0, firstSlashPos);
                    wstring childFolderW = cropONameWithoutSlash.substr(firstSlashPos, cropONameWithoutSlash.length()-1);
                    wstring cropNNameWithoutSlash = cropNNameW.substr(1);
                    size_t firstSlashPosN = cropNNameWithoutSlash.find(L"\\");
                    wstring childNFolderW = L"";
                    if (std::wstring::npos != firstSlashPosN) {
                        childNFolderW = cropNNameWithoutSlash.substr(firstSlashPosN, cropNNameWithoutSlash.length()-1);
                    }
                    wstring wstrmm = dwnldPath + L"\\"+parentFolderW+L"|"+oDriveW+L"|";
                    std::map<wstring, wstring>::iterator parentIt = restoredFilesMap->find(wstrmm);
                    if (parentIt != restoredFilesMap->end()) {
                        isChangedCopyto = true;
                        oldNameW = parentIt->second + childFolderW;
                        newNameW = parentIt->second + childNFolderW;
                    }
                }
                if(!isChangedCopyto) {
                    oldNameW = dwnldPath + cropONameW;
                    newNameW = dwnldPath + cropNNameW;
                    oldNameWMod = dwnldPath + cropONameW+L"|"+oDriveW+L"|";
                    std::map<wstring, wstring>::iterator parentIt = restoredFilesMap->find(oldNameW+L"|"+oDriveW+L"|");
                    if (parentIt != restoredFilesMap->end()) {
                        isChangedCopyto = true;
                        oldNameW = parentIt->second ;
                    }
                    else {
                        oldNameW=L"";
                    }
                }
            } else {
                BOOL isChanged = false;
                if (restoreType == 1) {
                    wstring cropONameWithoutSlash = cropONameW.substr(1);
                    size_t firstSlashPos = cropONameWithoutSlash.find(L"\\");
                    if (std::wstring::npos != firstSlashPos) {
                        wstring parentFolderW = cropONameWithoutSlash.substr(0, firstSlashPos);
                        wstring childFolderW = cropONameWithoutSlash.substr(firstSlashPos, cropONameWithoutSlash.length() - 1);
                        wstring cropNNameWithoutSlash = cropNNameW.substr(1);
                        size_t firstSlashPosN = cropNNameWithoutSlash.find(L"\\");
                        wstring childNFolderW = L"";

                        if (std::wstring::npos != firstSlashPosN) {
                            childNFolderW = cropNNameWithoutSlash.substr(firstSlashPosN, cropNNameWithoutSlash.length() - 1);
                        }

                        std::map<wstring, wstring>::iterator parentIt = restoredFilesMap->find(dcPath + L"\\" + oDriveW + L"$" + L"\\" + parentFolderW);

                        if (parentIt != restoredFilesMap->end()) {
                            isChanged = true;
                            oldNameW = parentIt->second + childFolderW;
                            newNameW = parentIt->second + childNFolderW;
                        }
                    }
                }

                if (!isChanged) {
                    oldNameW = dcPath + L"\\" + oDriveW + L"$" + cropONameW;
                    newNameW = dcPath + L"\\" + nDriveW + L"$" + cropNNameW;
                }
            }

            int renameRetVal = 0;
            wstring restoredFileNameW;
            if (restoreType == 1 || restoreType == 2 ) {
                std::map<wstring, wstring>::iterator it = renamedFilesMap->find(oldNameW);

                if (it != renamedFilesMap->end()) {
                    restoredFileNameW = it->second;
                } else {
                    it = restoredFilesMap->find(oldNameW);
                    if (it != restoredFilesMap->end()) {
                        restoredFileNameW = it->second;
                    } else {
                        restoredFileNameW = oldNameW;
                    }
                }

                renameRetVal = _wrename(restoredFileNameW.c_str(), newNameW.c_str());
                if (renameRetVal == 0) {
                    renamedFilesMap->insert(std::pair<wstring, wstring>(newNameW, newNameW));
                }
            } else {
                CString strPath = newNameW.c_str();
                strPath += '\0';
                if (PathFileExists(oldNameW.c_str())) {
                    if (PathFileExists(newNameW.c_str())) {
                        SHFILEOPSTRUCT strOper = {0};
                        strOper.hwnd = NULL;
                        strOper.wFunc = FO_DELETE;
                        strOper.pFrom = strPath;
                        strOper.fFlags = FOF_NO_UI;
                        int val = SHFileOperation(&strOper);
                    }
                    renameRetVal = _wrename(oldNameW.c_str(), newNameW.c_str());
                    restoredFileNameW = oldNameW;
                }
            }

            if (renameRetVal != 0) {
                // renaming failed.
                wstring tempName;
                DWORD attr = GetFileAttributes(newNameW.c_str());
                int errorCode = (int) GetLastError();
                int cnt = 1;

                while (errorCode == ERROR_ALREADY_EXISTS) {
                    if (attr & FILE_ATTRIBUTE_DIRECTORY) {
                        tempName = newNameW + L" (" + to_wstring(cnt++) + L")";
                    } else {
                        size_t dot = newNameW.rfind('.');
                        if (std::string::npos != dot) {
                            wstring file = newNameW.substr(0, dot);
                            wstring extn = newNameW.substr(dot);
                            tempName = file + L" (" + to_wstring(cnt++) + L")" + extn;
                        }
                    }
                    renameRetVal = _wrename(restoredFileNameW.c_str(), tempName.c_str());
                    if (renameRetVal == 0) {
                        renamedFilesMap->insert(std::pair<wstring, wstring>(newNameW, tempName));
                        break;
                    }
                    errorCode = (int) GetLastError();
                }

            }
        }
        renameFile.erase(0, pos + delimiter.length());
    }
}

int restoreLogic(JNIEnv *env, wstring dcPath, wstring mergePath, wstring dwnldPath, int backupMode, int restoreType, std::vector<string> volumeList, map<string, string> &fileMapping, ofstream& restoreDetailsFile, wstring renameList, std::map<wstring, wstring> *restoredFilesMap, bool isFullRestore, bool isEncrypted, wstring secretKey) {

    int restoreVal = 0;
    clock_t t1, t2;
    long timediff, seconds = 0;
    for (vector<string>::iterator loop = volumeList.begin(); loop != volumeList.end(); ++loop) {
        string fileToRestore = *loop;
        wstring fullSrc(fileToRestore.begin(), fileToRestore.end());
        DWORD attr = GetFileAttributes(fullSrc.c_str());
        string cropVolumeList = fileToRestore.substr(2);
        string origDest = fileMapping[(fileToRestore.substr(0, 1))];
        wstring filePath(cropVolumeList.begin(), cropVolumeList.end());
        wstring dest(origDest.begin(), origDest.end());
        wstring fullDest, displayDrive, displayPath, originalDestCopyTo;
        if (restoreType == 0) { //Overwrite
            if (!(fullSrc.compare(0, 2, L"\\\\"))) {
                wstring path = fullSrc;
                path.erase(0, mergePath.length());
                if (backupMode == 1) {//BMR backup
                    dest = path.substr(20, 1) + L"$";
                    displayDrive = path.substr(20, 1) + L":";
                    filePath = path.erase(0, 21);
                } else {
                    dest = path.substr(10, 1) + L"$"; // \PartitionX - Getting X Temp method
                    displayDrive = path.substr(10, 1) + L":";
                    filePath = path.erase(0, 11);
                }
                fullDest = dcPath + L"\\" + dest + filePath;
                displayPath = displayDrive + filePath;
            } else {
                fullDest = dcPath + L"\\" + dest + filePath;
                displayDrive = dest.substr(0, 1) + L":";
                displayPath = displayDrive + filePath;
            }
            if (isFullRestore) {
                if (attr & FILE_ATTRIBUTE_DIRECTORY) {
                    if (PathFileExists(fullDest.c_str())) {
                        string destString(fullDest.begin(), fullDest.end());
                        CString strPath = destString.c_str();
                        strPath += '\0';
                        SHFILEOPSTRUCT strOper = {0};
                        strOper.hwnd = NULL;
                        strOper.wFunc = FO_DELETE;
                        strOper.pFrom = strPath;
                        strOper.fFlags = FOF_NO_UI;

                        int val = SHFileOperation(&strOper);
                        log(env, 1, "Deleting destination %ws returned %d", fullDest.c_str(), val);
                        if(val!=0) {
                            string displayString;
                            displayString.assign(displayPath.begin(), displayPath.end());
                            restoreDetailsFile << displayString;
                            restoreDetailsFile << endl;
                            if(val==32) {
                                restoreDetailsFile << "Failed (File in use by another process)";
                                restoreDetailsFile << endl;
                            } else if(val==120) {
                                restoreDetailsFile << "Failed (Restricted Access)";
                                restoreDetailsFile << endl;
                            } else {
                                restoreDetailsFile << "Failed";
                                restoreDetailsFile << endl;
                            }
                            restoreDetailsFile << seconds;
                            restoreDetailsFile << endl;
                            continue;
                        }
                    }
                }
            }
        } else if (restoreType == 1) { //Keep
            int cnt = 1;
            wstring originalDest;
            if (!(fullSrc.compare(0, 2, L"\\\\"))) {
                wstring path = fullSrc;
                path.erase(0, mergePath.length());
                if (backupMode == 1) {//BMR backup
                    dest = path.substr(20, 1) + L"$";
                    displayDrive = path.substr(20, 1) + L":";
                    filePath = path.erase(0, 21);
                } else {
                    dest = path.substr(10, 1) + L"$"; // \PartitionX - Getting X
                    displayDrive = path.substr(10, 1) + L":";
                    filePath = path.erase(0, 11);
                }
                fullDest = dcPath + L"\\" + dest + filePath;
                displayPath = displayDrive + filePath;
            } else {
                fullDest = dcPath + L"\\" + dest + filePath;
                displayDrive = dest.substr(0, 1) + L":";
                displayPath = displayDrive + filePath;
            }
            originalDest = fullDest;

            std::map<wstring, wstring>::iterator it = restoredFilesMap->find(fullDest);

            if ((it != restoredFilesMap->end()) && (!isFullRestore)) {
                fullDest = it->second;
            } else {
                wstring tempDest = fullDest;
                while (PathFileExists(tempDest.c_str())) {
                    tempDest = fullDest;
                    if (attr & FILE_ATTRIBUTE_DIRECTORY) {
                        tempDest = dcPath + L"\\" + dest + filePath + L" (" + to_wstring(cnt++) + L")";
                    } else {
                        size_t dot = tempDest.rfind('.');
                        if (std::string::npos != dot) {
                            wstring file = tempDest.substr(0, dot);
                            wstring extn = tempDest.substr(dot);
                            tempDest = file + L" (" + to_wstring(cnt++) + L")" + extn;
                        }
                    }
                }
                fullDest = tempDest;
            }

            if (isFullRestore) {
                restoredFilesMap->insert(std::pair<wstring, wstring>(originalDest, fullDest));
            }
        } else if (restoreType == 2) { //Copy to
            int cnt = 1;
            wstring origDestMod;
            if (!(fullSrc.compare(0, 2, L"\\\\"))) {
                wstring path = fullSrc;
                path.erase(0, mergePath.length());
                if (backupMode == 1) {//BMR backup
                    displayDrive = path.substr(20, 1) + L":";
                    filePath = path.erase(0, 21); //Removing \\PartitionX
                } else {
                    displayDrive = path.substr(10, 1) + L":";
                    filePath = path.erase(0, 11); //Removing \\PartitionX
                }
                fullDest = dwnldPath + filePath;
                displayPath = displayDrive + filePath;
            } else {
                fullDest = dwnldPath + filePath;
                displayDrive = dest.substr(0, 1) + L":";
                displayPath = displayDrive + filePath;
            }
            originalDestCopyTo = fullDest;
            wstring fullDestFin = fullDest+L"|"+displayDrive.substr(0, 1)+L"|";
            std::map<wstring, wstring>::iterator it = restoredFilesMap->find(fullDestFin);
            if ((it != restoredFilesMap->end()) && (!isFullRestore)) {
                fullDest = it->second;
            } else {
                wstring tempDest = fullDest;
                while (PathFileExists(tempDest.c_str())) {
                    tempDest = fullDest;
                    if (attr & FILE_ATTRIBUTE_DIRECTORY) {
                        tempDest = dwnldPath + filePath + L" (" + to_wstring(cnt++) + L")";
                    } else {
                        size_t dot = tempDest.rfind('.');
                        if (std::string::npos != dot) {
                            wstring file = tempDest.substr(0, dot);
                            wstring extn = tempDest.substr(dot);
                            tempDest = file + L" (" + to_wstring(cnt++) + L")" + extn;
                        }
                    }
                }
                fullDest = tempDest;
                origDestMod = originalDestCopyTo+L"|"+ dest.substr(0, 1)+L"|";
            }
            if (isFullRestore) {
               restoredFilesMap->insert(std::pair<wstring, wstring>(origDestMod, fullDest));
            }
        }
        string displayString;
        displayString.assign(displayPath.begin(), displayPath.end());
        wstring destFol;
        const size_t pos = fullDest.rfind('\\');
        if (std::string::npos != pos) {
            destFol = fullDest.substr(0, pos);
            SHCreateDirectoryEx(NULL, destFol.c_str(), NULL);
        }

        if (attr & FILE_ATTRIBUTE_DIRECTORY) {
            t1 = clock();
            restoreVal = RestoreDirectoryTree(env, fullSrc, fullDest, backupMode, isEncrypted, secretKey);
            t2 = clock();
            timediff = ((long) t2 - (long) t1);
            seconds = timediff / CLOCKS_PER_SEC;
            restoreDetailsFile << displayString;
            restoreDetailsFile << endl;
            if (restoreVal == 0) {
                restoreDetailsFile << "Success";
                restoreDetailsFile << endl;
            } else if (restoreVal == 32) {
                restoreDetailsFile << "Failed (File in use by another process)";
                restoreDetailsFile << endl;
            } else if (restoreVal == 112 || restoreVal == 28) {//Insufficient space error codes
                log(env, 1, "Stopping restore due to insufficient space");
                return restoreVal;
            } else if (restoreVal == 1307 || restoreVal == 5) {
                restoreDetailsFile << "Failed (Restricted Access)";
                restoreDetailsFile << endl;
            } else {
                restoreDetailsFile << "Failed";
                restoreDetailsFile << endl;
            }
            restoreDetailsFile << seconds;
            restoreDetailsFile << endl;
        } else {
            t1 = clock();
            if (!fullSrc.compare(0, 2, L"\\\\")) {
                if (isEncrypted) {
                    restoreVal = RestoreEncryptedFile(env, fullSrc, fullDest, secretKey);
                } else {
                    restoreVal = RestoreUnencryptedFile(env, fullSrc, fullDest);
                }
            } else {
                if (backupMode == 0) {
                    if (isEncrypted) {
                        restoreVal = RestoreEncryptedFile(env, fullSrc, fullDest, secretKey);
                    } else {
                        restoreVal = RestoreUnencryptedFile(env, fullSrc, fullDest);
                    }
                } else {
                    restoreVal = RestoreUncompressedFile(env, fullSrc, fullDest);
                }
            }
            t2 = clock();
            timediff = ((long) t2 - (long) t1);
            seconds = timediff / CLOCKS_PER_SEC;
            restoreDetailsFile << displayString;
            restoreDetailsFile << endl;
            if (restoreVal == 0) {
                restoreDetailsFile << "Success";
                restoreDetailsFile << endl;
            } else if (restoreVal == 112 || restoreVal == 28) {//Insufficient space error codes
                log(env, 1, "Stopping restore due to insufficient space");
                return restoreVal;
            } else if (restoreVal == 32) {
                restoreDetailsFile << "Failed (File in use by another process)";
                restoreDetailsFile << endl;
            } else if (restoreVal == 1307 || restoreVal == 5) {
                restoreDetailsFile << "Failed (Restricted Access)";
                restoreDetailsFile << endl;
            } else {
                restoreDetailsFile << "Failed";
                restoreDetailsFile << endl;
            }
            restoreDetailsFile << seconds;
            restoreDetailsFile << endl;
        }
    }

    if (renameList != L"-") {
        renameFiles(renameList, dcPath, restoreType, restoredFilesMap, dwnldPath);
    }
    return 0;
}

jint performFLR(JNIEnv *env, jint type, jint mode, jstring dc, jstring domUser, jstring domPwd, jstring rep, jstring repUser, jstring repPwd, jstring filesList, jstring ibfilesList, jstring driveMap, jstring dwnld, jstring restoreFile, jstring fbUser, jstring fbPwd, jstring renameFilesList, jboolean encrypted, jstring encrPwd) {
    log(env, 1, "performFLR Start 2");
    int returnVal = 0;
    LPWSTR dcName = NULL, domUserName = NULL, domPassword = NULL, repository = NULL, repUserName = NULL, repPassword = NULL, filesToRestore = NULL, ibfilesToRestore = NULL, mountMap = NULL, dwnldW = NULL, restoreDetails = NULL, fbUserName = NULL, fbPassword = NULL, toRename = NULL, encrPwdW = NULL;
    if (dc != NULL)
        dcName = (LPWSTR) env->GetStringChars(dc, NULL);
    if (domUser != NULL)
        domUserName = (LPWSTR) env->GetStringChars(domUser, NULL);
    if (domPwd != NULL)
        domPassword = (LPWSTR) env->GetStringChars(domPwd, NULL);
    if (rep != NULL)
        repository = (LPWSTR) env->GetStringChars(rep, NULL);
    if (repUser != NULL)
        repUserName = (LPWSTR) env->GetStringChars(repUser, NULL);
    if (repPwd != NULL)
        repPassword = (LPWSTR) env->GetStringChars(repPwd, NULL);
    if (filesList != NULL)
        filesToRestore = (LPWSTR) env->GetStringChars(filesList, NULL);
    if (ibfilesList != NULL)
        ibfilesToRestore = (LPWSTR) env->GetStringChars(ibfilesList, NULL);
    if (driveMap != NULL)
        mountMap = (LPWSTR) env->GetStringChars(driveMap, NULL);
    if (dwnld != NULL)
        dwnldW = (LPWSTR) env->GetStringChars(dwnld, NULL);
    if (restoreFile != NULL)
        restoreDetails = (LPWSTR) env->GetStringChars(restoreFile, NULL);
    if (fbUser != NULL)
        fbUserName = (LPWSTR) env->GetStringChars(fbUser, NULL);
    if (fbPwd != NULL)
        fbPassword = (LPWSTR) env->GetStringChars(fbPwd, NULL);
    if (renameFilesList != NULL)
        toRename = (LPWSTR) env->GetStringChars(renameFilesList, NULL);
    if (encrPwd != NULL)
        encrPwdW = (LPWSTR) env->GetStringChars(encrPwd, NULL);

    int restoreType = (int) type;
    int backupMode = (int) mode; //0 for File Backup; 1 for BMR; 2 for VLR
    bool isEncrypted = (bool) encrypted;
    log(env, 1, "Restore input %d %d %S %d", restoreType, backupMode, repository, isEncrypted);

    wstring dcPath = dcName;
    wstring fbPath = restoreDetails;
    wstring mergePath = repository;
    size_t fbPos = fbPath.rfind(L"\\");
    fbPath = fbPath.substr(0, fbPos);
    wstring secretKey = encrPwdW;

    NETRESOURCE nr;
    DWORD dwFlags;
    DWORD dwRetVal;
    memset(&nr, 0, sizeof (NETRESOURCE));
    nr.dwType = RESOURCETYPE_ANY;
    nr.lpProvider = NULL;
    dwFlags = CONNECT_TEMPORARY;
    ofstream restoreDetailsFile;
    restoreDetailsFile.open(restoreDetails, ios::out | ios::app);

    if (restoreType == 0 || restoreType == 1) {
        nr.lpRemoteName = dcName;

        dwRetVal = WNetAddConnection2(&nr, domPassword, domUserName, dwFlags);
        if ((dwRetVal != NO_ERROR) && (dwRetVal != 1219)) {
            int retVal = (int) dwRetVal;
            log(env, 1, "Connect to DC failed with error: %d", retVal);
            return -1;
        }
    }

    if (mergePath != L"-") {
        nr.lpRemoteName = repository;

        dwRetVal = WNetAddConnection2(&nr, repPassword, repUserName, dwFlags);
        if ((dwRetVal != NO_ERROR) && (dwRetVal != 1219)) {
            int retVal = (int) dwRetVal;
            log(env, 1, "Connect to repository failed with error: %d", retVal);
            return -2;
        }
    }

    if (restoreDetails != NULL) {
        nr.lpRemoteName = &fbPath[0];

        dwRetVal = WNetAddConnection2(&nr, fbPassword, fbUserName, dwFlags);
        if ((dwRetVal != NO_ERROR) && (dwRetVal != 1219)) {
            int retVal = (int) dwRetVal;
            log(env, 1, "Connect to full backup repository failed with error: %d", retVal);
            return -2;
        }
    }

    wstring dwnldPath = dwnldW;
    wstring files = filesToRestore;
    wstring ibfiles = ibfilesToRestore;
    std::vector<string> volumeList;
    std::vector<string> ibvolumeList;
    size_t pos, innerpos;
    string backupList, delimiter = "<?>";
    backupList.assign(files.begin(), files.end());

    while ((pos = backupList.find(delimiter)) != string::npos) {
        volumeList.push_back(backupList.substr(0, pos));
        backupList.erase(0, pos + delimiter.length());
    }
    if (ibfiles != L"-") {
        string ibBackupList;
        ibBackupList.assign(ibfiles.begin(), ibfiles.end());

        while ((pos = ibBackupList.find(delimiter)) != string::npos) {
            ibvolumeList.push_back(ibBackupList.substr(0, pos));
            ibBackupList.erase(0, pos + delimiter.length());
        }
    }

    wstring mapping = mountMap;
    map<string, string> fileMapping;
    string origPath, mountedPath;
    string mapDelimiter = "--", backupFile;
    backupFile.assign(mapping.begin(), mapping.end());

    while ((pos = backupFile.find(delimiter)) != string::npos) {
        origPath = backupFile.substr(0, pos);

        if ((innerpos = origPath.find(mapDelimiter)) != string::npos) {
            mountedPath = origPath.substr(0, innerpos);
            origPath.erase(0, innerpos + mapDelimiter.length());
            origPath.append("$");
            fileMapping[mountedPath] = origPath;
        }

        backupFile.erase(0, pos + delimiter.length());
    }

    wstring renameList = toRename;
    std::map<wstring, wstring> *restoredFilesMap = new map<wstring, wstring>();

    //RestoreLogic call with only FB files
    returnVal = restoreLogic(env, dcPath, mergePath, dwnldPath, backupMode, restoreType, volumeList, fileMapping, restoreDetailsFile, renameList, restoredFilesMap, true, isEncrypted, secretKey);
    if (returnVal == 112 || returnVal == 28) {
        return returnVal;
    }

    renameList = L"-";

    //RestoreLogic call with only IB files
    if (ibfiles != L"-") {
        returnVal = restoreLogic(env, dcPath, mergePath, dwnldPath, backupMode, restoreType, ibvolumeList, fileMapping, restoreDetailsFile, renameList, restoredFilesMap, false, isEncrypted, secretKey);
        if (returnVal == 112 || returnVal == 28) {
            return returnVal;
        }
    }

    if (restoreType == 0 || restoreType == 1) {
        dwRetVal = WNetCancelConnection2(dcName, 0, TRUE);
    }
    if (repository != NULL) {
        dwRetVal = WNetCancelConnection2(repository, 0, TRUE);
    }
    if (restoreDetails != NULL) {
        dwRetVal = WNetCancelConnection2(&fbPath[0], 0, TRUE);
    }
    if (dcName)
        env->ReleaseStringChars(dc, (const jchar*) dcName);
    if (domUserName)
        env->ReleaseStringChars(domUser, (const jchar*) domUserName);
    if (domPassword)
        env->ReleaseStringChars(domPwd, (const jchar*) domPassword);
    if (repository)
        env->ReleaseStringChars(rep, (const jchar*) repository);
    if (repUserName)
        env->ReleaseStringChars(repUser, (const jchar*) repUserName);
    if (repPassword != NULL)
        env->ReleaseStringChars(repPwd, (const jchar*) repPassword);
    if (filesToRestore)
        env->ReleaseStringChars(filesList, (const jchar*) filesToRestore);
    if (mountMap)
        env->ReleaseStringChars(driveMap, (const jchar*) mountMap);
    if (dwnldW)
        env->ReleaseStringChars(dwnld, (const jchar*) dwnldW);
    if (restoreDetails)
        env->ReleaseStringChars(restoreFile, (const jchar*) restoreDetails);
    if (fbUserName)
        env->ReleaseStringChars(fbUser, (const jchar*) fbUserName);
    if (fbPassword)
        env->ReleaseStringChars(fbPwd, (const jchar*) fbPassword);
    return 0;
}
