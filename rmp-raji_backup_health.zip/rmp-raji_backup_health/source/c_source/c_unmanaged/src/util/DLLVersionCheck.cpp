//$Id: DLLVersionCheck.cpp,v 1.0 2015/10/14 12:07:09 lucky.k Exp $
#include <util/DLLVersionCheck.h>
#include <Windows.h>
#include <tchar.h>
#include <shlwapi.h>
#include <stdlib.h>
#include <RMPNative.h>

jobject GetDotNetFrameworkRegValue(JNIEnv *env)
{
	log(env, 1, "GetDotNetFrameworkRegValue Start 2");
	jobject properties = env->NewObject(hashClass, hashConID);
	DWORD installVal;
	DWORD spVal;
	if(RegGetDWord(L"SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v3.5", L"Install", &installVal))
	{
		int installValInt = (int)installVal;
		jobject installObject = env->NewObject(intClass, intConID, (jint)installValInt);
		env->CallObjectMethod(properties, hashPutID, env->NewStringUTF("is3.5Install"),  installObject);
	}

	if(RegGetDWord(L"SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v3.5", L"SP", &spVal))
	{
		int spValInt = (int)spVal;
		jobject spObject = env->NewObject(intClass, intConID, (jint)spValInt);
		env->CallObjectMethod(properties, hashPutID, env->NewStringUTF("SP"), spObject);
	}

	if(RegGetDWord(L"SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v4.0\\Client", L"Install", &installVal))
	{
		int installValInt = (int)installVal;
		jobject installObject = env->NewObject(intClass, intConID, (jint)installValInt);
		env->CallObjectMethod(properties, hashPutID, env->NewStringUTF("is4.5Install"),  installObject);
	}
	else if(RegGetDWord(L"SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v4\\Client", L"Install", &installVal))
	{
		int installValInt = (int)installVal;
		jobject installObject = env->NewObject(intClass, intConID, (jint)installValInt);
		env->CallObjectMethod(properties, hashPutID, env->NewStringUTF("is4.5Install"),  installObject);
	}
	else if(RegGetDWord(L"SOFTWARE\\Microsoft\\NET Framework Setup\\NDP\\v4\\Full", L"Install", &installVal))
	{
		int installValInt = (int)installVal;
		jobject installObject = env->NewObject(intClass, intConID, (jint)installValInt);
		env->CallObjectMethod(properties, hashPutID, env->NewStringUTF("is4.5Install"),  installObject);
	}
//Deleting intClass and hashClass here will make them unavailable to other cpp files.So do not delete these global references.
	//env->DeleteGlobalRef(hashClass);
	//env->DeleteGlobalRef(intClass);
	return properties;
}


BOOL RegGetDWord(LPWSTR RegistryPath, LPWSTR KeyName, DWORD *value)
{
	HKEY keyHandle;
	DWORD type = 0;
	DWORD dwDataSize = sizeof(DWORD);
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, RegistryPath, 0, KEY_QUERY_VALUE, &keyHandle) == ERROR_SUCCESS)
	{
		long returnValue = RegQueryValueEx(keyHandle, KeyName, 0, &type, (LPBYTE)value, &dwDataSize);
		if(returnValue != ERROR_SUCCESS)
		{
			return false;
		}
		RegCloseKey(keyHandle);
	}
	else
	{
		return false;
	}
	return true;
}
