#include <util/AllDCs.h>
#include <RMPNative.h>

jobject getAllDCs(JNIEnv *env,jstring domain, jstring juserDomain, jstring user, jstring pass, jstring dcToBind)
{
    //jobject prop = env->NewObject(propClass, propConID);
	log(env, 1, "getAllDCs Start 2");
//list<wstring> dcList;
jobject domainController = env->NewObject(listClass, listConID);
	LPWSTR domainName,userName = NULL,password = NULL,dcToBindWith = NULL,userDomain=NULL;
	
	//if(domain == NULL)	{ return prop;	}
	domainName = (LPWSTR)env->GetStringChars(domain, NULL);

	DWORD res;
	HANDLE hDS = NULL;
	RPC_AUTH_IDENTITY_HANDLE pAuthIdentity = NULL; 
	
	if(user == NULL || pass == NULL || dcToBind == NULL)
	{
		res = DsBind(NULL,domainName,&hDS);
	}
	else
	{
		userName = (LPWSTR)env->GetStringChars(user, NULL);
		password = (LPWSTR)env->GetStringChars(pass, NULL);
		userDomain = (LPWSTR)env->GetStringChars(juserDomain, NULL);
		dcToBindWith = (LPWSTR)env->GetStringChars(dcToBind, NULL);

		DsMakePasswordCredentials(userName,userDomain,password,&pAuthIdentity);
		res = DsBindWithCred(dcToBindWith,domainName,pAuthIdentity,&hDS);
	}
	if (res == NO_ERROR )
	{
		DWORD tCount; 
		DS_DOMAIN_CONTROLLER_INFO_2 * pInfo = NULL;
		res = DsGetDomainControllerInfo(hDS,domainName,2,&tCount,(VOID**)&pInfo);
		DsUnBind(&hDS);
		if (res == NO_ERROR )
		{
			for ( DWORD i = 0 ; i < tCount ; i++ )
			{
                                        jobject roleprop = env->NewObject(propClass, propConID);
                                        LPWSTR netbios = pInfo[i].NetbiosName; 
                                        if(netbios == NULL){
                                            log(env, 1, "netbios name is NULL");
                                            netbios = L"-";
                                        }
                                        jstring netbiosName = env->NewString((jchar*)netbios,wcslen(netbios));
					env->CallObjectMethod(roleprop, propPutID, env->NewStringUTF("NETBIOS_NAME"), netbiosName);   
                                        LPWSTR dnsName = pInfo[i].DnsHostName; 
                                        if(dnsName == NULL){
                                            log(env, 1, "dnsName is NULL");
                                            dnsName = L"";
                                        }
                                        jstring domain = env->NewString((jchar*)dnsName,wcslen(dnsName));
					env->CallObjectMethod(roleprop, propPutID, env->NewStringUTF("DNSHOST_NAME"), domain);
			                GUID ntdsGuid = pInfo[i].NtdsDsaObjectGuid; 
                                        LPWSTR guid = new WCHAR[39];
                                        StringFromGUID2(ntdsGuid, guid, 39);
                                        jstring dcGuid = env->NewString((jchar*)guid,wcslen(guid));
					env->CallObjectMethod(roleprop, propPutID, env->NewStringUTF("GUID"), dcGuid);
                                        delete[] guid;
                                        env->CallBooleanMethod(domainController, listAddID,roleprop );
			}
			DsFreeDomainControllerInfo(2,tCount,pInfo);
			
	/*for(list<wstring>::iterator it = dcList.begin(); it!= dcList.end(); it++)
	{
		env->CallBooleanMethod(domainController, listAddID, env->NewString((jchar*)it->c_str(), wcslen(it->c_str())));
	}*/
		}
	}
	if(pAuthIdentity) DsFreePasswordCredentials(pAuthIdentity);
	if(userName) env->ReleaseStringChars(user, (const jchar*)userName);
	if(password) env->ReleaseStringChars(pass, (const jchar*)password);
	if(dcToBindWith) env->ReleaseStringChars(dcToBind, (const jchar*)dcToBindWith);
	if(domainName) env->ReleaseStringChars(domain, (const jchar*)domainName);
	return domainController;
}

jobject getDCOsInfo(JNIEnv *env, jstring domain, jstring user, jstring pass, jstring dcToBind) {
    jobject dcsList = env->NewObject(listClass, listConID);

    LPWSTR domainName, userName = NULL, password = NULL, dcToBindWith = NULL;

    LPWSTR protocolUrl = L"LDAP://";
    std::wstring url;


    domainName = (LPWSTR) env->GetStringChars(domain, NULL);

    if (user == NULL || pass == NULL || dcToBind == NULL) {
        url = std::wstring(protocolUrl) + std::wstring(domainName);
    } else {
        userName = (LPWSTR) env->GetStringChars(user, NULL);
        password = (LPWSTR) env->GetStringChars(pass, NULL);
        dcToBindWith = (LPWSTR) env->GetStringChars(dcToBind, NULL);
        url = std::wstring(protocolUrl) + std::wstring(dcToBindWith);
    }

    LPWSTR finalUrl = &url[0];

    HRESULT hr = NULL;
    IDirectorySearch *IPtrResult = NULL;

    CoInitialize(0);

    hr = ADsOpenObject(finalUrl, userName, password, ADS_SECURE_AUTHENTICATION, IID_IDirectorySearch, (void **) &IPtrResult);

    if (hr == S_OK) {
        // Bind succeeded

        LPWSTR filter = NULL;
        DWORD noOfAtrrs;
        ADS_SEARCH_HANDLE pHandle = NULL;

        filter = L"(&(objectCategory=computer)(operatingSystem=Windows Serv*))";
        LPWSTR attrs[] = {L"operatingSystem", L"sAMAccountName"};
        noOfAtrrs = sizeof (attrs) / sizeof (LPWSTR);

        hr = IPtrResult->ExecuteSearch(filter, attrs, noOfAtrrs, &pHandle);

        if (SUCCEEDED(hr)) {

            LPWSTR columnName;
            LPWSTR columnValue;
            ADS_SEARCH_COLUMN col;

            jstring jColumnValue;
            jstring jColumnName;


            while ((hr = IPtrResult->GetNextRow(pHandle)) != S_ADS_NOMORE_ROWS) {

                if (hr == S_OK) {

                    jobject roleprop = env->NewObject(propClass, propConID);

                    while (IPtrResult->GetNextColumnName(pHandle, &columnName) != S_ADS_NOMORE_COLUMNS) {
                        hr = IPtrResult->GetColumn(pHandle, columnName, &col);

                        if (SUCCEEDED(hr)) {
                            switch (col.dwADsType) {
                                case ADSTYPE_CASE_IGNORE_STRING:
                                {
                                    columnValue = (col.pADsValues)->CaseIgnoreString;
                                    jColumnValue = env->NewString((jchar*) columnValue, wcslen(columnValue));
                                    jColumnName = env->NewString((jchar*) columnName, wcslen(columnName));
                                    env->CallObjectMethod(roleprop, propPutID, jColumnName, jColumnValue);
                                }
                                break;
                            }
                        }
                    }
                    env->CallBooleanMethod(dcsList, listAddID, roleprop);
                } else {
                    break;
                }
            }

        }

        if (pHandle)
            IPtrResult->CloseSearchHandle(pHandle);
    }


    if (IPtrResult)
        IPtrResult->Release();

    if (userName) env->ReleaseStringChars(user, (const jchar*) userName);
    if (password) env->ReleaseStringChars(pass, (const jchar*) password);
    if (dcToBindWith) env->ReleaseStringChars(dcToBind, (const jchar*) dcToBindWith);
    if (domainName) env->ReleaseStringChars(domain, (const jchar*) domainName);

    return dcsList;
}

jobject getAllServers(JNIEnv *env, jstring domain, jstring user, jstring pass, jstring dcToBind) {
    jobject server = env->NewObject(listClass, listConID);

    LPWSTR domainName, userName = NULL, password = NULL, dcToBindWith = NULL;

    LPWSTR protocolUrl = L"LDAP://";
    std::wstring url;


    domainName = (LPWSTR) env->GetStringChars(domain, NULL);

    if (user == NULL || pass == NULL || dcToBind == NULL) {
        url = std::wstring(protocolUrl) + std::wstring(domainName);
    } else {
        userName = (LPWSTR) env->GetStringChars(user, NULL);
        password = (LPWSTR) env->GetStringChars(pass, NULL);
        dcToBindWith = (LPWSTR) env->GetStringChars(dcToBind, NULL);
        url = std::wstring(protocolUrl) + std::wstring(dcToBindWith);
    }

    LPWSTR finalUrl = &url[0];

    HRESULT hr = NULL;
    IDirectorySearch *IPtrResult = NULL;

    CoInitialize(0);

    hr = ADsOpenObject(finalUrl, userName, password, ADS_SECURE_AUTHENTICATION, IID_IDirectorySearch, (void **) &IPtrResult);

    if (hr == S_OK) {
        // Bind succeeded

        LPWSTR filter = NULL;
        DWORD noOfAtrrs;
        ADS_SEARCH_HANDLE pHandle = NULL;

        filter = L"(&(objectCategory=computer)(operatingSystem=Windows *Serv*)(!userAccountControl=532480))";

        LPWSTR attrs[] = {L"distinguishedName", L"cn", L"dNSHostName", L"objectGUID", L"operatingSystemVersion"};
        noOfAtrrs = sizeof (attrs) / sizeof (LPWSTR);

        hr = IPtrResult->ExecuteSearch(filter, attrs, noOfAtrrs, &pHandle);

        if (SUCCEEDED(hr)) {

            LPWSTR columnName;
            LPWSTR columnValue;
            ADS_SEARCH_COLUMN col;

            jstring jColumnValue;
            jstring jColumnName;


            while ((hr = IPtrResult->GetNextRow(pHandle)) != S_ADS_NOMORE_ROWS) {

                if (hr == S_OK) {

                    jobject roleprop = env->NewObject(propClass, propConID);

                    while (IPtrResult->GetNextColumnName(pHandle, &columnName) != S_ADS_NOMORE_COLUMNS) {

                        hr = IPtrResult->GetColumn(pHandle, columnName, &col);

                        if (SUCCEEDED(hr)) {
                            switch (col.dwADsType) {
                                case ADSTYPE_CASE_IGNORE_STRING:
                                {
                                    columnValue = (col.pADsValues)->CaseIgnoreString;
                                    jColumnValue = env->NewString((jchar*) columnValue, wcslen(columnValue));
                                    jColumnName = env->NewString((jchar*) columnName, wcslen(columnName));
                                    env->CallObjectMethod(roleprop, propPutID, jColumnName, jColumnValue);
                                }
                                    break;

                                case ADSTYPE_DN_STRING:
                                {
                                    columnValue = (col.pADsValues)->DNString;
                                    jColumnValue = env->NewString((jchar*) columnValue, wcslen(columnValue));
                                    jColumnName = env->NewString((jchar*) columnName, wcslen(columnName));
                                    env->CallObjectMethod(roleprop, propPutID, jColumnName, jColumnValue);
                                }
                                    break;

                                case ADSTYPE_OCTET_STRING:
                                {
                                    LPGUID pObjectGUID = (LPGUID) (col.pADsValues->OctetString.lpValue);
                                    LPWSTR columnValue = new WCHAR[39];
                                    ::StringFromGUID2(*pObjectGUID, columnValue, 39);
                                    jColumnValue = env->NewString((jchar*) columnValue, wcslen(columnValue));
                                    jColumnName = env->NewString((jchar*) columnName, wcslen(columnName));
                                    env->CallObjectMethod(roleprop, propPutID, jColumnName, jColumnValue);
                                }
                                    break;
                            }
                        }
                    }
                    env->CallBooleanMethod(server, listAddID, roleprop);
                } else {
                    break;
                }
            }

        }

        if (pHandle)
            IPtrResult->CloseSearchHandle(pHandle);
    }


    if (IPtrResult)
        IPtrResult->Release();

    if (userName) env->ReleaseStringChars(user, (const jchar*) userName);
    if (password) env->ReleaseStringChars(pass, (const jchar*) password);
    if (dcToBindWith) env->ReleaseStringChars(dcToBind, (const jchar*) dcToBindWith);
    if (domainName) env->ReleaseStringChars(domain, (const jchar*) domainName);

    return server;
}

jobject getAllEndPoints(JNIEnv *env, jstring domain, jstring user, jstring pass, jstring dcToBind) {
    jobject endPoints = env->NewObject(listClass, listConID);

    LPWSTR domainName, userName = NULL, password = NULL, dcToBindWith = NULL;

    LPWSTR protocolUrl = L"LDAP://";
    std::wstring url;


    domainName = (LPWSTR) env->GetStringChars(domain, NULL);

    if (user == NULL || pass == NULL || dcToBind == NULL) {
        url = std::wstring(protocolUrl) + std::wstring(domainName);
    } else {
        userName = (LPWSTR) env->GetStringChars(user, NULL);
        password = (LPWSTR) env->GetStringChars(pass, NULL);
        dcToBindWith = (LPWSTR) env->GetStringChars(dcToBind, NULL);
        url = std::wstring(protocolUrl) + std::wstring(dcToBindWith);
    }

    LPWSTR finalUrl = &url[0];

    HRESULT hr = NULL;
    IDirectorySearch *IPtrResult = NULL;

    CoInitialize(0);

    hr = ADsOpenObject(finalUrl, userName, password, ADS_SECURE_AUTHENTICATION, IID_IDirectorySearch, (void **) &IPtrResult);

    if (hr == S_OK) {
        // Bind succeeded

        LPWSTR filter = NULL;
        DWORD noOfAtrrs;
        ADS_SEARCH_HANDLE pHandle = NULL;

        filter = L"(&(objectCategory=computer)(!userAccountControl=532480))";

        LPWSTR attrs[] = {L"distinguishedName", L"cn", L"dNSHostName", L"objectGUID", L"operatingSystemVersion", L"operatingSystem"};
        noOfAtrrs = sizeof (attrs) / sizeof (LPWSTR);

        hr = IPtrResult->ExecuteSearch(filter, attrs, noOfAtrrs, &pHandle);

        if (SUCCEEDED(hr)) {

            LPWSTR columnName;
            LPWSTR columnValue;
            ADS_SEARCH_COLUMN col;

            jstring jColumnValue;
            jstring jColumnName;


            while ((hr = IPtrResult->GetNextRow(pHandle)) != S_ADS_NOMORE_ROWS) {

                if (hr == S_OK) {

                    jobject roleprop = env->NewObject(propClass, propConID);

                    while (IPtrResult->GetNextColumnName(pHandle, &columnName) != S_ADS_NOMORE_COLUMNS) {

                        hr = IPtrResult->GetColumn(pHandle, columnName, &col);

                        if (SUCCEEDED(hr)) {
                            switch (col.dwADsType) {
                                case ADSTYPE_CASE_IGNORE_STRING:
                                {
                                    columnValue = (col.pADsValues)->CaseIgnoreString;
                                    jColumnValue = env->NewString((jchar*) columnValue, wcslen(columnValue));
                                    jColumnName = env->NewString((jchar*) columnName, wcslen(columnName));
                                    env->CallObjectMethod(roleprop, propPutID, jColumnName, jColumnValue);
                                }
                                    break;

                                case ADSTYPE_DN_STRING:
                                {
                                    columnValue = (col.pADsValues)->DNString;
                                    jColumnValue = env->NewString((jchar*) columnValue, wcslen(columnValue));
                                    jColumnName = env->NewString((jchar*) columnName, wcslen(columnName));
                                    env->CallObjectMethod(roleprop, propPutID, jColumnName, jColumnValue);
                                }
                                    break;

                                case ADSTYPE_OCTET_STRING:
                                {
                                    LPGUID pObjectGUID = (LPGUID) (col.pADsValues->OctetString.lpValue);
                                    LPWSTR columnValue = new WCHAR[39];
                                    ::StringFromGUID2(*pObjectGUID, columnValue, 39);
                                    jColumnValue = env->NewString((jchar*) columnValue, wcslen(columnValue));
                                    jColumnName = env->NewString((jchar*) columnName, wcslen(columnName));
                                    env->CallObjectMethod(roleprop, propPutID, jColumnName, jColumnValue);
                                }
                                    break;
                            }
                        }
                    }
                    env->CallBooleanMethod(endPoints, listAddID, roleprop);
                } else {
                    break;
                }
            }

        }

        if (pHandle)
            IPtrResult->CloseSearchHandle(pHandle);
    }


    if (IPtrResult)
        IPtrResult->Release();

    if (userName) env->ReleaseStringChars(user, (const jchar*) userName);
    if (password) env->ReleaseStringChars(pass, (const jchar*) password);
    if (dcToBindWith) env->ReleaseStringChars(dcToBind, (const jchar*) dcToBindWith);
    if (domainName) env->ReleaseStringChars(domain, (const jchar*) domainName);

    return endPoints;
}