//$Id: RemoteFileAccess.cpp,v 1.0 2015/10/14 12:07:09 lucky.k Exp $
#include <util/RemoteFileAccess.h>
#include <windows.h>
#include <tchar.h>
#include <Winnetwk.h>
#include <stdlib.h>
#include <RMPNative.h>

jint RemoteFileAccessAdd(JNIEnv *env, jstring remotePath, jstring userName, jstring password)
{
	int isSuccess = -1;
    log(env, 1, "Java_com_manageengine_rmp_jni_RMPNativeManager_RemoteFileAccessAdd called . . .");

    DWORD dwRetVal;
    NETRESOURCE nr;
    DWORD dwFlags;
    const jchar* utfRemotePath=env->GetStringChars(remotePath, 0);
    const jchar* utfUserName=env->GetStringChars(userName, 0);
    const jchar* utfPassword=env->GetStringChars(password, 0);

    memset(&nr, 0, sizeof (NETRESOURCE));
    nr.dwType = RESOURCETYPE_ANY;
    nr.lpLocalName = NULL;
    nr.lpRemoteName = (LPWSTR) utfRemotePath;
    nr.lpProvider = NULL;
    dwFlags = CONNECT_UPDATE_PROFILE;
    dwRetVal = WNetAddConnection2(&nr, (LPWSTR) utfPassword, (LPWSTR) utfUserName, dwFlags);
    isSuccess = dwRetVal;

    env->ReleaseStringChars(remotePath, utfRemotePath);
    env->ReleaseStringChars(userName, utfUserName);
    env->ReleaseStringChars(password, utfPassword);
    return isSuccess;
}

jint RemoteFileAccessClose(JNIEnv *env, jstring remotePath)
{
	int isSuccess = -1;
    log(env, 1, "Java_com_manageengine_rmp_jni_RMPNativeManager_RemoteFileAccessClose called . . .");

    DWORD dwRetVal;
    DWORD dwFlags;
    const jchar* utfRemotePath=env->GetStringChars(remotePath, 0);
    dwFlags = CONNECT_UPDATE_PROFILE;
    dwRetVal = WNetCancelConnection2((LPWSTR) utfRemotePath, dwFlags, FALSE);
    isSuccess = dwRetVal;
    env->ReleaseStringChars(remotePath, utfRemotePath);
    return isSuccess;
}
