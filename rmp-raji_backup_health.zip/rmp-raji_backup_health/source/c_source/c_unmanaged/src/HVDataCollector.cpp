#include <jni/com_manageengine_rmp_virtual_HVNativeHandler.h>
#include <fstream>
#include <iostream>
#include <util/HVDataCollector.h>
#include <stdio.h>
#include <Windows.h>
#include <iostream>
#include <string.h>
#include <stdint.h>
#include "util/zlib.h"
#include <fcntl.h>  
#include <sys/types.h>  
#include <sys/stat.h>

#include <initguid.h>
#include <string>
#define WINVER _WIN32_WINNT_WIN7
#include <winioctl.h>
#include <virtdisk.h>


#define ENCRYPT_BLOCK_SIZE 16
#define KEYLENGTH  0x00800000
#define ENCRYPT_ALGORITHM CALG_AES_128 

using namespace std;

jclass    hashClass=0;
jmethodID hashConID=0;
jmethodID hashPutID=0;

jclass    intClass=0;
jmethodID intConID=0;
jmethodID intValueID=0;

jclass    propClass=0;
jmethodID propConID=0;
jmethodID propPutID=0;
jmethodID propGetPropertyID=0;
jmethodID propGetID=0;
jmethodID containsKeyID=0;

jclass    listClass=0;
jmethodID listGetID=0;
jmethodID listSizeID=0;
jmethodID listConID=0;
jmethodID listSizeConID=0;
jmethodID listAddID=0;
jmethodID listRemoveID=0;
jmethodID listAddIndexID=0;

jclass    gClLogger=0;
jclass    LogClass=0;
jmethodID LogID=0;
jmethodID gMtdFine=0;		
jclass    gClWinAccessProvider=0;

//for building idx file
#define SPAN 10485760L       /* desired distance between access points */
#define WINSIZE 32768U      /* sliding window size */
#define CHUNK 65536         /* file input buffer size */
/* access point entry */
struct point {
    __int64 out; /* corresponding offset in uncompressed data */
    __int64 in; /* offset in input file of first full byte */
    int bits; /* number of bits (1-7) from byte at in - 1, or 0 */
    unsigned char window[WINSIZE]; /* preceding 32K of uncompressed data */
};

/* access point list */
struct access {
    int have; /* number of list entries filled in */
    int size; /* number of list entries allocated */
    struct point *list; /* allocated list */
};
uint32_t read_uint32(gzFile gz)
{
	uint32_t v;
	gzread(gz, &v, sizeof(v));
	return v;
}

/* Deallocate an index built by build_index() */
void free_index(struct access *index) {
	if (index != NULL) {
		free(index->list);
		free(index);
	}
}

/* Add an entry to the access point list.  If out of memory, deallocate the
existing list and return NULL. */
struct access *addpoint(struct access *index, int bits,
	__int64 in, __int64 out, unsigned left, unsigned char *window) {
	struct point *next;

	/* if list is empty, create it (start with eight points) */
	if (index == NULL) {
		index = (struct access*) malloc(sizeof(struct access));
		if (index == NULL) return NULL;
		index->list = (point*)malloc(sizeof(struct point) << 3);
		if (index->list == NULL) {
			free(index);
			return NULL;
		}
		index->size = 8;
		index->have = 0;
	}/* if list is full, make it bigger */
	else if (index->have == index->size) {
		index->size <<= 1;
		next = (point*)realloc(index->list, sizeof(struct point) * index->size);
		if (next == NULL) {
			free_index(index);
			return NULL;
		}
		index->list = next;
	}

	/* fill in entry and increment how many we have */
	next = index->list + index->have;
	next->bits = bits;
	next->in = in;
	next->out = out;
	if (left)
		memcpy(next->window, window + WINSIZE - left, left);
	if (left < WINSIZE)
		memcpy(next->window + left, window, WINSIZE - left);
	index->have++;

	/* return list, possibly reallocated */
	return index;
}

/* Make one entire pass through the compressed stream and build an index, with
access points about every span bytes of uncompressed output -- span is
chosen to balance the speed of random access against the memory requirements
of the list, about 32K bytes per access point.  Note that data after the end
of the first zlib or gzip stream in the file is ignored.  build_index()
returns the number of access points on success (>= 1), Z_MEM_ERROR for out
of memory, Z_DATA_ERROR for an error in the input file, or Z_ERRNO for a
file read error.  On success, *built points to the resulting index. */
int build_index(FILE *in, __int64 span, struct access **built) {
	int ret;
	__int64 totin, totout; /* our own total counters to avoid 4GB limit */
	__int64 last; /* totout value of last access point */
	struct access *index; /* access points being generated */
	z_stream strm;
	unsigned char input[CHUNK];
	unsigned char window[WINSIZE];

	/* initialize inflate */
	strm.zalloc = Z_NULL;
	strm.zfree = Z_NULL;
	strm.opaque = Z_NULL;
	strm.avail_in = 0;
	strm.next_in = Z_NULL;
	ret = inflateInit2(&strm, 47); /* automatic zlib or gzip decoding */
	if (ret != Z_OK)
		return ret;

	/* inflate the input, maintain a sliding window, and build an index -- this
	also validates the integrity of the compressed data using the check
	information at the end of the gzip or zlib stream */
	totin = totout = last = 0;
	index = NULL; /* will be allocated by first addpoint() */
	strm.avail_out = 0;
	do {
		/* get some compressed data from input file */
		strm.avail_in = fread(input, 1, CHUNK, in);
		if (ferror(in)) {
			ret = Z_ERRNO;
			goto build_index_error;
		}
		if (strm.avail_in == 0) {
			ret = Z_DATA_ERROR;
			goto build_index_error;
		}
		strm.next_in = input;

		/* process all of that, or until end of stream */
		do {
			/* reset sliding window if necessary */
			if (strm.avail_out == 0) {
				strm.avail_out = WINSIZE;
				strm.next_out = window;
			}

			/* inflate until out of input, output, or at end of block --
			update the total input and output counters */
			totin += strm.avail_in;
			totout += strm.avail_out;
			ret = inflate(&strm, Z_BLOCK); /* return at end of block */
			totin -= strm.avail_in;
			totout -= strm.avail_out;
			if (ret == Z_NEED_DICT)
				ret = Z_DATA_ERROR;
			if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
				goto build_index_error;
			if (ret == Z_STREAM_END)
				break;

			/* if at end of block, consider adding an index entry (note that if
			data_type indicates an end-of-block, then all of the
			uncompressed data from that block has been delivered, and none
			of the compressed data after that block has been consumed,
			except for up to seven bits) -- the totout == 0 provides an
			entry point after the zlib or gzip header, and assures that the
			index always has at least one access point; we avoid creating an
			access point after the last block by checking bit 6 of data_type
			*/
			if ((strm.data_type & 128) && !(strm.data_type & 64) &&
				(totout == 0 || totout - last > span)) {
				index = addpoint(index, strm.data_type & 7, totin,
					totout, strm.avail_out, window);
				if (index == NULL) {
					ret = Z_MEM_ERROR;
					goto build_index_error;
				}
				last = totout;
			}
		} while (strm.avail_in != 0);
	} while (ret != Z_STREAM_END);

	/* clean up and return index (release unused entries in list) */
	(void)inflateEnd(&strm);
	index->list = (point*)realloc(index->list, sizeof(struct point) * index->have);
	index->size = index->have;
	*built = index;
	return index->size;

	/* return error */
build_index_error:
	(void)inflateEnd(&strm);
	if (index != NULL)
		free_index(index);
	return ret;
}

int write_uint32(gzFile gz, uint32_t v) {
	return gzwrite(gz, &v, sizeof(v));
}

/* Demonstrate the use of build_index() and extract() by processing the file
provided on the command line, and the extracting 16K from about 2/3rds of
the way through the uncompressed output, and writing that to stdout. */
int indexCreation(JNIEnv *env, wstring backupFile) {
	size_t pos = backupFile.rfind(L".");
	wstring indexName = backupFile.substr(0, pos) + L".idx";
	string fileName(backupFile.begin(), backupFile.end());
	string indexFile(indexName.begin(), indexName.end());
	int len;
	__int64 offset;
	FILE *in;
	struct access *index = NULL;
	unsigned char buf[CHUNK];

	in = fopen(fileName.c_str(), "rb");
	if (in == NULL) {
		log(env, 1, "zran: could not open %ws for reading\n", backupFile.c_str());
		return 1;
	}

	/* build index */
	len = build_index(in, SPAN, &index);
	if (len < 0) {
		fclose(in);
		switch (len) {
		case Z_MEM_ERROR:
			log(env, 1, "zran: out of memory\n");
			break;
		case Z_DATA_ERROR:
			log(env, 1, "zran: compressed data error in %ws\n", backupFile.c_str());
			break;
		case Z_ERRNO:
			log(env, 1, "zran: read error on %ws\n", backupFile.c_str());
			break;
		default:
			log(env, 1, "zran: error %d while building index\n", len);
		}
		return 1;
	}
	log(env, 1,  "zran: built index with %d access points\n", len);
	fclose(in);

	gzFile gz = gzopen(indexFile.c_str(), "wb");
	if (gz == NULL) {
		log(env, 1, "gz null\n");
	}

	// Write a header.
	write_uint32(gz, (uint32_t)index->have);

	// Write out entry points.
	for (int i = 0; i < index->have; ++i) {
		gzwrite(gz, &index->list[i].out, sizeof(__int64));
		gzwrite(gz, &index->list[i].in, sizeof(__int64));
		gzwrite(gz, &index->list[i].bits, sizeof(int));
		gzwrite(gz, index->list[i].window, WINSIZE);
	}

	if (gz != NULL) {
		gzclose(gz);
	}
	if (index != NULL) {
		free_index(index);
	}
	return 0;
}
//functions for building idx file ends

void log(JNIEnv *env, int level,const char* message, ...)
{
    va_list args;
    int len;
    jint jlevel=(jint)level;
    char * buffer;
    va_start(args, message);
    len = _vscprintf(message, args) + 1;
    buffer = (char*)malloc(len * sizeof(char));
    vsprintf(buffer, message, args);
    jstring jsMessage = env->NewStringUTF(buffer);
    env->CallStaticVoidMethod(LogClass,LogID,jlevel,jsMessage);
    free(buffer);
}

void hypervJNIInitializeClassIDs(JNIEnv *env)
{
    jclass LReflistClass = env->FindClass("java/util/ArrayList"); 
    listClass = (jclass)env->NewGlobalRef(LReflistClass);   
    listSizeID = env->GetMethodID(listClass, "size", "()I");
    listGetID = env->GetMethodID(listClass, "get", "(I)Ljava/lang/Object;");
    listConID = env->GetMethodID(listClass, "<init>", "()V");
    listSizeConID = env->GetMethodID(listClass, "<init>", "(I)V");
    listAddID = env->GetMethodID(listClass, "add", "(Ljava/lang/Object;)Z");
    listAddIndexID = env->GetMethodID(listClass, "add", "(ILjava/lang/Object;)V");
    listRemoveID = env->GetMethodID(listClass, "remove", "(I)Ljava/lang/Object;");
    
    jclass LRefpropClass = env->FindClass("java/util/Properties"); 
    propClass = (jclass)env->NewGlobalRef(LRefpropClass);
    propConID = env->GetMethodID(propClass, "<init>", "()V");
    propPutID = env->GetMethodID(propClass, "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
    propGetPropertyID = env->GetMethodID(propClass, "getProperty", "(Ljava/lang/String;)Ljava/lang/String;");
    propGetID = env->GetMethodID(propClass, "get", "(Ljava/lang/Object;)Ljava/lang/Object;");
    containsKeyID =env->GetMethodID(propClass, "containsKey", "(Ljava/lang/Object;)Z");
    
    jclass LRefhashClass = env->FindClass("java/util/Hashtable");
    hashClass = (jclass)env->NewGlobalRef(LRefhashClass);
    hashConID = env->GetMethodID(hashClass, "<init>", "()V");
    hashPutID = env->GetMethodID(hashClass, "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");

    jclass LRefintClass = env->FindClass("java/lang/Integer");
    intClass = (jclass)env->NewGlobalRef(LRefintClass);
    intConID = env->GetMethodID(intClass, "<init>", "(I)V");
    intValueID = env->GetMethodID(intClass, "intValue", "()I");

    jclass LRefgClLogger = env->FindClass("java/util/logging/Logger");
    gClLogger = (jclass)env->NewGlobalRef(LRefgClLogger);
    if (gClLogger == NULL)
    {
            printf("Could not find class java.util.logging.Logger!\n");
    }

    jclass LRefLogClass = env->FindClass("com/manageengine/rmp/jni/NativeLogger");
    LogClass = (jclass)(env)->NewGlobalRef(LRefLogClass);
    if (LogClass == NULL)
    {
            printf("Could not find class LogClass!\n");
    }
    LogID = env->GetStaticMethodID(LogClass, "log", "(ILjava/lang/String;)V");
    gMtdFine = env->GetMethodID(gClLogger, "info", "(Ljava/lang/String;)V");
    if (gMtdFine == NULL)
    {
        printf("Could not find method 'void fine(String)' method in java.util.logging.Logger!\n");
    }

    jclass LRefgClWinAccessProvider = env->FindClass("com/manageengine/rmp/jni/RMPNativeManager");
    gClWinAccessProvider = (jclass)env->NewGlobalRef(LRefgClWinAccessProvider);
    if (gClWinAccessProvider == NULL)
    {
        printf("Could not find class com/manageengine/rmp/jni/RMPNativeManager!\n");
    }
    log(env, 1, "Java_com_manageengine_rmp_virtual_HVNativeHandler_hypervJNIInitializeClassIDs cpp initialized");
}


//Hyper-V methods
  JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_virtual_HVNativeHandler_jNIHyperVBackup(JNIEnv *env,jclass obj,jstring domain, jstring user, jstring pwd, jstring jhypervHostName,
                            jstring fullbackupVMs, jstring incrementalbackupVMs, jstring jrepositoryPath, jstring jbackupName, jstring jscheduleName, 
                            jstring repositoryDetailsJson, jstring jisanyVHDchanged)
{
	hypervJNIInitializeClassIDs(env);
	return HyperVBackupC(env,domain, user, pwd, jhypervHostName, fullbackupVMs, incrementalbackupVMs, jrepositoryPath, jbackupName, jscheduleName, repositoryDetailsJson, jisanyVHDchanged);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_virtual_HVNativeHandler_jNIdoCBToperationsforschedule(JNIEnv *env,jclass obj,jstring jdomainName, jstring juserName, jstring jpassword, jstring jhostServer, jstring jbackupId, jstring jallVMIds)
{
	hypervJNIInitializeClassIDs(env);
	return doCBToperationsforscheduleC(env, jdomainName, juserName, jpassword, jhostServer, jbackupId, jallVMIds);
}

 JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_virtual_HVNativeHandler_jNIHyperVRestore(JNIEnv *env, jclass obj, jstring domain, jstring user, jstring pwd, jstring jhypervHostName, jstring vmName, jstring vmfullbackupPath, jstring vmincrementalbackupPaths, jstring ischangeVMName, jstring newVMName,
  jstring VHDnewstorageLocation, jstring repositoryDetailsJson, jstring isPowerOn, jstring isEncrypted, jstring encryptPassword, jstring vmId, jstring restoreId, jstring paramsjson, jstring restoreFormatString)
 {
	  hypervJNIInitializeClassIDs(env);
	  return HyperVRestoreC(env,domain, user, pwd, jhypervHostName, vmName, vmfullbackupPath, vmincrementalbackupPaths, ischangeVMName, newVMName, VHDnewstorageLocation, repositoryDetailsJson, isPowerOn, isEncrypted, encryptPassword, vmId, restoreId, paramsjson, restoreFormatString);
 }

 JNIEXPORT jint JNICALL Java_com_manageengine_rmp_virtual_HVNativeHandler_jNIinstallandstartHypervdriver(JNIEnv *env,jclass obj,jstring jdomainName, jstring juserName, jstring jpassword, jstring jhostServer, jstring isInstall)
 {
 	hypervJNIInitializeClassIDs(env);
 	return InstallandstartHypervdriverC(env,jdomainName, juserName, jpassword, jhostServer, isInstall);
 }

 JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_virtual_HVNativeHandler_jNIcopyVMfilesfromVSSSnapshot(JNIEnv *env,jclass obj,jstring domain, jstring user, jstring password, jstring hostServer, jstring hypervVMId, jstring newbackupType, jstring repositoryPath, jstring backupIdentifier,
             jstring backupId, jstring repositoryDetailsJson, jstring isEncrypted, jstring encryptPassword, jstring vmId, jstring generateHash)
 {
    hypervJNIInitializeClassIDs(env);
    return copyVMfilesfromVSSSnapshotC(env,domain, user, password, hostServer, hypervVMId, newbackupType, repositoryPath, backupIdentifier, backupId, repositoryDetailsJson, isEncrypted, encryptPassword, vmId, generateHash);
 }

 JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_virtual_HVNativeHandler_jNIHyperVHealthCheck(JNIEnv *env,jclass obj,jstring domain, jstring user, jstring pwd, jstring jhypervHostName, jstring healthCheckParametersJson, jstring vmBackupDetailsJson)
  {
   	hypervJNIInitializeClassIDs(env);
   	return HyperVHealthCheckC(env, domain, user, pwd, jhypervHostName, healthCheckParametersJson, vmBackupDetailsJson);
  }























int encryptdecryptFile(JNIEnv *env, LPTSTR pszPassword, int oper, wchar_t* filePath)//0->Encrypt, 1-> Decrypt
{ 
    log(env, 1, "HVDataCollector.cpp encryptdecryptFile started..");
    HCRYPTPROV hCryptProv = NULL;
    HCRYPTKEY hKey = NULL;
    HCRYPTKEY hXchgKey = NULL;
    HCRYPTHASH hHash = NULL;
    wchar_t secure[]  = L"_secure";
    wchar_t* wtextSource = new wchar_t[wcslen(filePath) + 1];
    wcscpy(wtextSource, filePath);
    wcscat(wtextSource, L"\0");
    wchar_t* wtextDest = new wchar_t[wcslen(filePath) + wcslen(L"_secure") + 1];
    wcscpy(wtextDest, filePath);
    wcscat(wtextDest, L"_secure");
    wcscat(wtextDest, L"\0");
    LPTSTR pszSourceFile,psZDestFile;
    if(oper == 0){
        pszSourceFile = wtextSource;
        psZDestFile = wtextDest;
    }else if(oper == 1){
        pszSourceFile = wtextDest;
        psZDestFile = wtextSource;
    }
    log(env, 1, "HVDataCollector.cpp encryptdecryptFile pszSourceFile -> %ws",pszSourceFile);
    log(env, 1, "HVDataCollector.cpp encryptdecryptFile psZDestFile -> %ws",psZDestFile);
    HANDLE hSourceFile = CreateFile(pszSourceFile, FILE_READ_DATA, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hSourceFile == INVALID_HANDLE_VALUE)
    {
        log(env, 1, "HVDataCollector.cpp encryptdecryptFile hSourceFile is INVALID..!");
        return 1; 
    }
    HANDLE hDestinationFile = CreateFile(psZDestFile, FILE_WRITE_DATA, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hDestinationFile == INVALID_HANDLE_VALUE)
    {
        log(env, 1, "HVDataCollector.cpp encryptdecryptFile hDestinationFile is INVALID..!");
        if(hSourceFile)
        {
            CloseHandle(hSourceFile);
        }
        return 1; 
    }
        bool CryptAcquireContextStatus = false;
    if(CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, 0))
    {
        log(env, 1, "HVDataCollector.cpp CryptAcquireContext success on first try");
                CryptAcquireContextStatus = true;
    }
    else
    {
        log(env, 1, "HVDataCollector.cpp encryptdecryptFile CryptAcquireContext FAILED..-> %d",GetLastError());
                if(CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, CRYPT_NEWKEYSET)) {
                        log(env, 1, "HVDataCollector.cpp CryptAcquireContext success on second try");
            CryptAcquireContextStatus = true;
        } else {
                        log(env, 1, "HVDataCollector.cpp Could not create a new key container. %d",(int) GetLastError());
                        if(hSourceFile)
                        {
                                CloseHandle(hSourceFile);
                        }
                        if(hDestinationFile)
                        {
                                CloseHandle(hDestinationFile);
                        }
                        return 1;
        }
        
    }
        
        if(CryptAcquireContextStatus){
            if(CryptCreateHash(hCryptProv, CALG_MD5, 0, 0, &hHash))
        {
            if(CryptHashData(hHash, (BYTE *)pszPassword, lstrlen(pszPassword), 0))
            {
                if(CryptDeriveKey(hCryptProv, ENCRYPT_ALGORITHM, hHash, KEYLENGTH, &hKey))
                {
                    log(env, 1, "HVDataCollector.cpp encryptdecryptFile Inside CryptDeriveKey..");
                    DWORD dwBlockLen;
                    DWORD dwBufferLen;
                    DWORD dwCount;
                    PBYTE pbBuffer = NULL;
                    dwBlockLen = 1000 - 1000 % ENCRYPT_BLOCK_SIZE;
                    if(ENCRYPT_BLOCK_SIZE > 1)
                    {
                        dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
                    }
                    else
                    {
                        dwBufferLen = dwBlockLen;
                    }
                    if(pbBuffer = (BYTE *)malloc(dwBufferLen))
                    {
                        bool fEOF = FALSE;
                        do
                        {
                            //log(env, 1, "HVDataCollector.cpp encryptdecryptFile Running..!");
                            if(ReadFile(hSourceFile, pbBuffer, dwBlockLen, &dwCount, NULL))
                            {
                                if(dwCount < dwBlockLen)
                                {
                                    log(env, 1, "HVDataCollector.cpp encryptdecryptFile EOF reached..!");
                                    fEOF = TRUE;
                                }
                                if(oper==0)
                                {
                                    if(CryptEncrypt(hKey, NULL, fEOF, 0, pbBuffer, &dwCount, dwBufferLen))
                                    {
                                        if(WriteFile(hDestinationFile, pbBuffer, dwCount, &dwCount, NULL))
                                        {
                                        }
                                        else
                                        {
                                            log(env, 1, "HVDataCollector.cpp encryptdecryptFile oper 0 WriteFile returned FALSE..!-> %d",GetLastError());
                                        }
                                    }
                                    else
                                    {
                                        log(env, 1, "HVDataCollector.cpp encryptdecryptFile CryptEncrypt returned FALSE..!-> %d",GetLastError());
                                    }
                                }
                                else if(oper==1)
                                {
                                    if(CryptDecrypt(hKey, NULL, fEOF, 0, pbBuffer, &dwCount))
                                    {
                                        if(WriteFile(hDestinationFile, pbBuffer, dwCount, &dwCount, NULL))
                                        {
                                        }
                                        else
                                        {
                                            log(env, 1, "HVDataCollector.cpp encryptdecryptFile oper 0 WriteFile returned FALSE..!-> %d",GetLastError());
                                        }
                                    }
                                    else
                                    {
                                        log(env, 1, "HVDataCollector.cpp encryptdecryptFile CryptDecrypt returned FALSE..!-> %d",GetLastError());
                                    }
                                }
                            }
                            else
                            {
                                log(env, 1, "HVDataCollector.cpp encryptdecryptFile ReadFile returned FALSE..-> %d",GetLastError());
                            }
                        } while(!fEOF);
                        if(hSourceFile)
                        {
                            log(env, 1, "HVDataCollector.cpp encryptdecryptFile Success case Closing hSourceFile..");
                            CloseHandle(hSourceFile);
                        }
                        if(hDestinationFile)
                        {
                            log(env, 1, "HVDataCollector.cpp encryptdecryptFile Success case Closing hDestinationFile..");
                            CloseHandle(hDestinationFile);
                        }
                        if(pbBuffer)
                        {
                            free(pbBuffer);
                        }
                        if(hHash)
                        {
                            if((CryptDestroyHash(hHash)))
                            {
                            }
                        }
                        if(hCryptProv)
                        {
                            if((CryptReleaseContext(hCryptProv, 0)))
                            {
                            }
                        }
                    }
                    else
                    {
                        log(env, 1, "HVDataCollector.cpp encryptdecryptFile malloc FAILED..-> %d",GetLastError());
                    }
                }
                else
                {
                    log(env, 1, "HVDataCollector.cpp encryptdecryptFile CryptDeriveKey FAILED..-> %d",GetLastError());
                    if(hSourceFile)
                    {
                        CloseHandle(hSourceFile);
                    }
                    if(hDestinationFile)
                    {
                        CloseHandle(hDestinationFile);
                    }
                    return 1;
                }
            }
            else
            {
                log(env, 1, "HVDataCollector.cpp encryptdecryptFile CryptHashData FAILED..-> %d",GetLastError());
                if(hSourceFile)
                {
                    CloseHandle(hSourceFile);
                }
                if(hDestinationFile)
                {
                    CloseHandle(hDestinationFile);
                }
                return 1;
            }
        }
        else
        {
            log(env, 1, "HVDataCollector.cpp encryptdecryptFile CryptCreateHash FAILED..-> %d",GetLastError());
            if(hSourceFile)
            {
                CloseHandle(hSourceFile);
            }
            if(hDestinationFile)
            {
                CloseHandle(hDestinationFile);
            }
            return 1;
        }
        }
        
    if(oper == 0)
    {
        log(env, 1, "HVDataCollector.cpp encryptdecryptFile ENCRYPTION OPERATION. Deleting File -> %ws",pszSourceFile);
        bool isDeleted = DeleteFile(pszSourceFile);
        if(!isDeleted)
        {
            log(env, 1, "HVDataCollector.cpp encryptdecryptFile Deleting File Failed -> %d",GetLastError());
            Sleep(5000);
            isDeleted = DeleteFile(pszSourceFile);
            if(!isDeleted)
            {
                log(env, 1, "HVDataCollector.cpp encryptdecryptFile Deleting File Failed second time also -> %d",GetLastError());
            }

        }
    } 
    else
    {
        log(env, 1, "HVDataCollector.cpp encryptdecryptFile DECRYPTION OPERATION. NOT Deleting File -> %ws",pszSourceFile);
    }
    return 0;
}


bool CompressFileDirectly(JNIEnv *env, BSTR filetoCompress, BSTR backupFolderpath)
{
    log(env, 1, "CompressFileDirectly PowershellHandler.cpp Input File -> %ws", filetoCompress);
    log(env, 1, "CompressFileDirectly PowershellHandler.cpp Destination File -> %ws", backupFolderpath);

    size_t bufSize;
    BYTE *buf;
    bufSize = 16777216;
    buf = new BYTE[bufSize];
    HANDLE VHDpathwheredatatobereadHandle = CreateFile(filetoCompress, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
    if (VHDpathwheredatatobereadHandle == INVALID_HANDLE_VALUE)
    {
        log(env, 1, "Handle failed for VHD file.File not found");
        return false;
    }

    int compressedFiletemp = _wopen(backupFolderpath, _O_CREAT|_O_WRONLY|_O_BINARY);
    if(compressedFiletemp==-1){
        log(env, 1, "CompressFileDirectly compressedFiletemp is NULL");
        CloseHandle(VHDpathwheredatatobereadHandle);
        if (buf != NULL){ delete[](buf); }
        return false;
    }


    gzFile compressedFile = gzdopen(compressedFiletemp, "wb");

    if(!compressedFile){
        log(env, 1, "CompressFileDirectly gzdopen compressedFile is NULL");
        CloseHandle(VHDpathwheredatatobereadHandle);
        if (buf != NULL){ delete[](buf); }
        return false;
    }

    while (1)
    {       
        DWORD lpNumberOfBytesRead;
        BOOL bReadFile = ReadFile(VHDpathwheredatatobereadHandle, buf, bufSize, &lpNumberOfBytesRead, NULL);
        if (!bReadFile)
        {
            DWORD error = GetLastError();
            log(env, 1, "CompressFile -> Issue with fread. Error: %d", error);
            if (buf != NULL){ delete[](buf); }
            if (compressedFile){ gzclose(compressedFile); }
            CloseHandle(VHDpathwheredatatobereadHandle);
            return false;
        }
        if (lpNumberOfBytesRead == 0) //TODO have to control loop iterations based on filesize/bufSize
        {
            log(env, 1, "CompressFile -> end of file reached. ");
            break;
        }
        //buf contains len bytes of decompressed data
        DWORD nWrote;
        nWrote = gzwrite(compressedFile, buf, lpNumberOfBytesRead);
        if (nWrote<=0)
        {
            DWORD error = GetLastError();
            log(env, 1, "CompressFile -> Issue with gzwrite. Error: %d", error);
            if (buf != NULL){ delete[](buf); }
            if (compressedFile){ gzclose(compressedFile); }
            CloseHandle(VHDpathwheredatatobereadHandle);
            return false;
        }
    }
    if (buf != NULL){ delete[](buf); }
    if (compressedFile){ gzclose(compressedFile); }
    CloseHandle(VHDpathwheredatatobereadHandle);
    log(env, 1, "File compression finished successfully! ");
    return true;
}

bool DecompressFileDirectly(JNIEnv *env, BSTR filetoDeCompress, BSTR backupFolderpath)
{
    log(env, 1, "DecompressFileDirectly PowershellHandler.cpp Decompressed File -> %ws", filetoDeCompress);
    log(env, 1, "DecompressFileDirectly PowershellHandler.cpp Destination File -> %ws", backupFolderpath);

    size_t bufSize;
    BYTE *buf;
    bufSize = 16777216;
    buf = new BYTE[bufSize];
    HANDLE VHDpathwheredatatobewrittenHandle = CreateFile(backupFolderpath, GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_FLAG_BACKUP_SEMANTICS, NULL);
    if (VHDpathwheredatatobewrittenHandle == INVALID_HANDLE_VALUE)
    {
        log(env, 1, "PowershellHandler.cpp DecompressFileDirectly INVALID HANDLE VALUE...");
        return false;
    }

    int backedupFiletemp = _wopen(filetoDeCompress, _O_RDONLY|_O_BINARY);
    if(backedupFiletemp==-1){
        log(env, 1, "DeCompressFileDirectly compressedFiletemp is NULL");
        CloseHandle(VHDpathwheredatatobewrittenHandle);
        if (buf != NULL){ delete[](buf); }
        return false;
    }


    gzFile backedupFile = gzdopen(backedupFiletemp, "rb");

    if(!backedupFile){
        log(env, 1, "DeCompressFileDirectly gzdopen compressedFile is NULL");
        CloseHandle(VHDpathwheredatatobewrittenHandle);
        if (buf != NULL){ delete[](buf); }
        return false;
    }

    DWORD bytesread;
    while (1)
    {       
        bytesread = gzread(backedupFile, buf, bufSize);
        if (bytesread <0)
        {
            DWORD error = GetLastError();
            log(env, 1, "DecompressFile -> Issue with gzread. Error: %d", error);
            if (buf != NULL){ delete[](buf); }
            if (backedupFile){ gzclose(backedupFile); }
            CloseHandle(VHDpathwheredatatobewrittenHandle);
            return false;
        }
        if (bytesread == 0)
        {
            log(env, 1, "PowershellHandler.cpp buf read equal zero...");
            break;
        }
        //buf contains len bytes of decompressed data
        DWORD lpNumberOfBytesWritten;
        BOOL writeresult = WriteFile(VHDpathwheredatatobewrittenHandle, buf, bytesread, &lpNumberOfBytesWritten, NULL);
        if (!writeresult)
        {
            DWORD error = GetLastError();
            log(env, 1, "DecompressFile -> Issue with fwrite. Error: %d", error);
            if (buf != NULL){ delete[](buf); }
            if (backedupFile){ gzclose(backedupFile); }
            CloseHandle(VHDpathwheredatatobewrittenHandle);
            return false;
        }
    }
    log(env, 1, "PowershellHandler.cpp buf read equal zero...");

    if (buf != NULL){ delete[](buf); }
    if (backedupFile){ gzclose(backedupFile); }
    CloseHandle(VHDpathwheredatatobewrittenHandle);
    
    log(env, 1, "File decompression finished successfully! ");
    return true;
}


bool compressFiles(JNIEnv *env, LPWSTR vmName, LPWSTR repositoryPath, LPWSTR isEncrypt, LPWSTR encryptPassword, LPWSTR backupType)
{
    log(env, 1, "compressFiles started..!");
    wchar_t* backupFolderCopy = new wchar_t[wcslen(repositoryPath) + wcslen(L"Virtual Hard Disks") + 6];
    wchar_t* compressedfiledestinationFolder = new wchar_t[wcslen(repositoryPath) + wcslen(L"Virtual Hard Disks") + 6];         
    wcscpy(backupFolderCopy, repositoryPath);   
    wcscat(backupFolderCopy, L"\\");
    wcscat(backupFolderCopy, L"Virtual Hard Disks");
    wcscat(backupFolderCopy, L"\\");    
    wcscpy(compressedfiledestinationFolder, backupFolderCopy);
    wcscat(compressedfiledestinationFolder, L"\0");
    wcscat(backupFolderCopy, L"*");
    wcscat(backupFolderCopy, L"\0");
    log(env, 1, "compressFiles backupFolderCopy -> %ws", backupFolderCopy);
    log(env, 1, "compressFiles compressedfiledestinationFolder -> %ws", compressedfiledestinationFolder);

    HANDLE hFind;
    WIN32_FIND_DATA data;

    hFind = FindFirstFile(backupFolderCopy, &data);
    if (hFind != INVALID_HANDLE_VALUE) 
    {
        do 
        {
            log(env, 1, "compressFiles Found file -> %ws", data.cFileName);

            wchar_t* compressedfilesourcePath = new wchar_t[wcslen(compressedfiledestinationFolder) + wcslen(data.cFileName) + 2];          
            wcscpy(compressedfilesourcePath, compressedfiledestinationFolder);  
            wcscat(compressedfilesourcePath, data.cFileName);
            wcscat(compressedfilesourcePath, L"\0");    
            log(env, 1, "compressFiles compressedfilesourcePath -> %ws", compressedfilesourcePath);


            wchar_t* compressedfiledestinationPath = new wchar_t[wcslen(compressedfiledestinationFolder) + wcslen(data.cFileName) + wcslen(L"_compress") + 2];          
            wcscpy(compressedfiledestinationPath, compressedfiledestinationFolder); 
            wcscat(compressedfiledestinationPath, L"\\");
            wcscat(compressedfiledestinationPath, data.cFileName);
            wcscat(compressedfiledestinationPath, L"_compress");
            wcscat(compressedfiledestinationPath, L"\0");   
            log(env, 1, "compressFiles compressedfiledestinationPath -> %ws", compressedfiledestinationPath);

            if ((wcsstr(compressedfilesourcePath, L".vhd") != NULL) || (wcsstr(compressedfilesourcePath, L".avhd") != NULL))
            {
                log(env, 1, "compressFiles Calling CompressFileDirectly..");
                bool isCompressed = CompressFileDirectly(env, compressedfilesourcePath, compressedfiledestinationPath);
                if(isCompressed)
                {
                    log(env, 1, "compressFiles Successfully compressed..Going to delete file!");
                    BOOL isDeleted = DeleteFile(compressedfilesourcePath);
                    if(isDeleted)
                    {
                        log(env, 1, "compressFiles DeleteFile successful..!");

                        log(env, 1, "compressFiles Going to call indexCreation for file -> %ws", compressedfiledestinationPath);
                        int indexCreationStatus = indexCreation(env, compressedfiledestinationPath);
                        log(env, 1, "compressFiles indexCreation status -> %d", indexCreationStatus);

                        log(env, 1, "compressFiles isEncrypt -> %ws", isEncrypt);
                        if(wcsstr(isEncrypt, L"true")!=NULL && wcsstr(backupType, L"FullBackup")!=NULL)
                        {
                            log(env, 1, "compressFiles Going to call encryptdecryptFile for file -> %ws", compressedfiledestinationPath);
                            int encryptStatus = encryptdecryptFile(env, encryptPassword, 0, compressedfiledestinationPath);
                            log(env, 1, "compressFiles Encryption status -> %d", encryptStatus);
                        }
                    }

                    else
                    {
                        log(env, 1, "compressFiles DeleteFile failure..!");
                    }
                }
                else
                {
                    log(env, 1, "compressFiles Failure compressed..!");
                }
            }
            
        } while (FindNextFile(hFind, &data));
        FindClose(hFind);
    }
    return true;
}


bool decompressordeleteFiles(JNIEnv *env, LPWSTR vmName, LPWSTR repositoryPath, LPWSTR isfullPath, LPWSTR operation, LPWSTR isEncrypt, LPWSTR encryptPassword)
{

    /*
    Operation decompress:
    if isEncrypt is true
    {
    Iterate through all files
    If filename has _secure, decrypt that file.
    }
    Iterate through all files
    If filename has _compress and does not have _secure, decompress that file.

    Operation delete:
    Iterate through all files
    If isEncrypt is false and filename has .vhd or .avhd and does not have _compress, delete it
    If isEncrypt is true and filename has .vhd or .avhd or _compress and does not have _secure, delete it
    */

    
    log(env, 1, "decompressFiles started..! repositoryPath -> %ws", repositoryPath);
    log(env, 1, "decompressFiles started..! operation -> %ws", operation);
    wchar_t* backupFolderCopy = new wchar_t[wcslen(repositoryPath) + wcslen(vmName) + wcslen(L"Virtual Hard Disks") + 6];
    wchar_t* compressedfiledestinationFolder = new wchar_t[wcslen(repositoryPath) + wcslen(vmName) + wcslen(L"Virtual Hard Disks") + 6];            
    wcscpy(backupFolderCopy, repositoryPath);   

    if(wcsstr(isfullPath, L"false") != NULL)
    {
        wcscat(backupFolderCopy, L"\\");
        wcscat(backupFolderCopy, vmName);   
        wcscat(backupFolderCopy, L"\\");
        wcscat(backupFolderCopy, L"Virtual Hard Disks");
    }

    wcscat(backupFolderCopy, L"\\");    
    wcscpy(compressedfiledestinationFolder, backupFolderCopy);
    wcscat(compressedfiledestinationFolder, L"\0");
    wcscat(backupFolderCopy, L"*");
    wcscat(backupFolderCopy, L"\0");
    log(env, 1, "decompressFiles backupFolderCopy -> %ws", backupFolderCopy);
    log(env, 1, "decompressFiles compressedfiledestinationFolder -> %ws", compressedfiledestinationFolder);

    HANDLE hFind;
    WIN32_FIND_DATA data;

    if (wcsstr(isEncrypt, L"true") != NULL && wcsstr(operation, L"decompress") != NULL)
    {
        hFind = FindFirstFile(backupFolderCopy, &data);
        if (hFind != INVALID_HANDLE_VALUE) 
        {
            do 
            {
                log(env, 1, "First iteration Found file -> %ws", data.cFileName);
                wchar_t* compressedfilesourcePath = new wchar_t[wcslen(compressedfiledestinationFolder) + wcslen(data.cFileName) + 2];          
                wcscpy(compressedfilesourcePath, compressedfiledestinationFolder);  
                wcscat(compressedfilesourcePath, data.cFileName);
                wcscat(compressedfilesourcePath, L"\0");    
                log(env, 1, "decompressFiles First iteration compressedfiledestinationPath -> %ws", compressedfilesourcePath);


                wchar_t* compressedfiledestinationPath = new wchar_t[wcslen(compressedfiledestinationFolder) + wcslen(data.cFileName) + 2];         
                wcscpy(compressedfiledestinationPath, compressedfiledestinationFolder); 
                wcscat(compressedfiledestinationPath, L"\\");
                wcscat(compressedfiledestinationPath, data.cFileName);
                wcscat(compressedfiledestinationPath, L"\0");//todo remove _compress    
                log(env, 1, "decompressFiles First iteration compressedfiledestinationPath -> %ws", compressedfiledestinationPath);
                if (wcsstr(compressedfilesourcePath, L"_secure") != NULL)
                {
                    log(env, 1, "decompressFiles First iteration Calling encryptdecryptFile");
                    //Remove _secure from destination filename
                    wchar_t* fileNamewithoutextensiontemp =  new wchar_t[wcslen(compressedfiledestinationPath) + 1];
                    wcscpy(fileNamewithoutextensiontemp, compressedfiledestinationPath);
                    wchar_t* tempPointer = wcsrchr(fileNamewithoutextensiontemp, L'_');
                    if(tempPointer)
                    {
                        log(env, 1, "Removing _secure from vhd filename..->%ws", tempPointer);
                        *tempPointer=L'\0';
                    }
                    wchar_t* fileNamewithoutextension = new wchar_t[wcslen(fileNamewithoutextensiontemp) + 1];
                    wcscpy(fileNamewithoutextension, fileNamewithoutextensiontemp);
                    wcscat(fileNamewithoutextension, L"\0");

                    log(env, 1, "fileNamewithoutextensionsecure: %ws", fileNamewithoutextension);
                    int decryptStatus = encryptdecryptFile(env, encryptPassword, 1, fileNamewithoutextension);
                    log(env, 1, "decryptStatus: %d", decryptStatus);
                }

            }while (FindNextFile(hFind, &data));
            FindClose(hFind);
        }
    }

    hFind = FindFirstFile(backupFolderCopy, &data);
    if (hFind != INVALID_HANDLE_VALUE) 
    {
        do 
        {
            log(env, 1, "decompressFiles Found file -> %ws", data.cFileName);

            wchar_t* compressedfilesourcePath = new wchar_t[wcslen(compressedfiledestinationFolder) + wcslen(data.cFileName) + 2];          
            wcscpy(compressedfilesourcePath, compressedfiledestinationFolder);  
            wcscat(compressedfilesourcePath, data.cFileName);
            wcscat(compressedfilesourcePath, L"\0");    
            log(env, 1, "decompressFiles compressedfiledestinationPath -> %ws", compressedfilesourcePath);


            wchar_t* compressedfiledestinationPath = new wchar_t[wcslen(compressedfiledestinationFolder) + wcslen(data.cFileName) + 2];         
            wcscpy(compressedfiledestinationPath, compressedfiledestinationFolder); 
            wcscat(compressedfiledestinationPath, L"\\");
            wcscat(compressedfiledestinationPath, data.cFileName);
            wcscat(compressedfiledestinationPath, L"\0");//todo remove _compress    
            log(env, 1, "decompressFiles compressedfiledestinationPath -> %ws", compressedfiledestinationPath);

            if ((wcsstr(compressedfilesourcePath, L"_compress") != NULL) && wcsstr(operation, L"decompress") != NULL && wcsstr(compressedfilesourcePath, L"_secure") == NULL)
            {
                log(env, 1, "decompressFiles Calling DeCompressFileDirectly..");

                //Remove _compress from destination filename
                wchar_t* fileNamewithoutextensiontemp =  new wchar_t[wcslen(compressedfiledestinationPath) + 1];
                wcscpy(fileNamewithoutextensiontemp, compressedfiledestinationPath);
                wchar_t* tempPointer = wcsrchr(fileNamewithoutextensiontemp, L'_');
                if(tempPointer)
                {
                    log(env, 1, "Removing _compress from vhd filename..->%ws", tempPointer);
                    *tempPointer=L'\0';
                }
                wchar_t* fileNamewithoutextension = new wchar_t[wcslen(fileNamewithoutextensiontemp) + 1];
                wcscpy(fileNamewithoutextension, fileNamewithoutextensiontemp);
                wcscat(fileNamewithoutextension, L"\0");
                
                log(env, 1, "fileNamewithoutextension: %ws", fileNamewithoutextension);

                bool isDecompressed = DecompressFileDirectly(env, compressedfilesourcePath, fileNamewithoutextension);
                if(isDecompressed)
                {
                    log(env, 1, "decompressFiles Successfully decompressed..");                 
                }
                else
                {
                    log(env, 1, "decompressFiles Failure compressed..!");
                    return false;
                }
            }
            else if (((wcsstr(compressedfilesourcePath, L".vhd") != NULL || wcsstr(compressedfilesourcePath, L".avhd") != NULL) && wcsstr(operation, L"delete") != NULL && wcsstr(compressedfilesourcePath, L"_compress") == NULL) ||
                ((wcsstr(compressedfilesourcePath, L".vhd") != NULL || wcsstr(compressedfilesourcePath, L".avhd") != NULL) && wcsstr(operation, L"delete") != NULL && wcsstr(compressedfilesourcePath, L"_compress") != NULL && wcsstr(compressedfilesourcePath, L"_secure") == NULL && wcsstr(isEncrypt, L"true") != NULL))
            {
                log(env, 1, "decompressFiles Calling DeleteFile..-> %ws", compressedfilesourcePath);

                BOOL isDeleted = DeleteFile(compressedfilesourcePath);
                if(isDeleted)
                {
                    log(env, 1, "decompressFiles Successfully deleted..");                  
                }
                else
                {
                    log(env, 1, "decompressFiles Failure deleting..!");                 
                }
            }
            
        }while (FindNextFile(hFind, &data));
        FindClose(hFind);
    }
    return true;
}


JNIEXPORT jint JNICALL Java_com_manageengine_rmp_virtual_HVNativeHandler_zlibHandler
(JNIEnv *env ,jclass, jstring vmName, jstring repositoryPath, jstring isEncrypt, jstring encryptPassword, jstring backupType, jstring isfullPath, jstring operation, jstring previousbackuprepositoryPaths)
{

/*
operation:
1 - compress
2 - decompress
3 - delete
*/
        hypervJNIInitializeClassIDs(env);
        int returnValue = 0;
        log(env, 1, "Java_com_manageengine_rmp_virtual_HVNativeHandler_zlibHandler called . . .");        
        const jchar* utfvmName = env->GetStringChars(vmName, 0);
        const jchar* utfbackupType = env->GetStringChars(backupType, 0);
        const jchar* utfrepositoryPath = env->GetStringChars(repositoryPath, 0);      
        const jchar* utfisEncrypt = env->GetStringChars(isEncrypt, 0);
        const jchar* utfencryptPassword = env->GetStringChars(encryptPassword, 0);
        const jchar* utfisfullPath = env->GetStringChars(isfullPath, 0);
        const jchar* utfoperation = env->GetStringChars(operation, 0);  
        const jchar* utfpreviousbackuprepositoryPaths = env->GetStringChars(previousbackuprepositoryPaths, 0);  
        

        log(env, 1, "Java_com_manageengine_rmp_virtual_HVNativeHandler_zlibHandler operation -> %ws", (LPWSTR)utfoperation);
       if(wcscmp((LPWSTR)utfoperation, L"compress")==0)
       {
            log(env, 1, "Java_com_manageengine_rmp_virtual_HVNativeHandler_zlibHandler Operation - > compression");
            bool isCompressed = compressFiles(env, (LPWSTR)utfvmName, (LPWSTR)utfrepositoryPath, (LPWSTR)utfisEncrypt, (LPWSTR)utfencryptPassword, (LPWSTR)utfbackupType);
            if(isCompressed)
            {
                log(env, 1, "performhvcheckpointbacku Compression successful!");
            }
            else
            {
                log(env, 1, "performhvcheckpointbacku Compression failure!");
            }
       }
       else if(wcscmp((LPWSTR)utfoperation, L"decompress")==0)
       {
            log(env, 1, "Java_com_manageengine_rmp_virtual_HVNativeHandler_zlibHandler Operation - > decompression");
            bool isDecompressed = decompressordeleteFiles(env, (LPWSTR)utfvmName, (LPWSTR)utfrepositoryPath, (LPWSTR)utfisfullPath, (LPWSTR)utfoperation, (LPWSTR)utfisEncrypt, (LPWSTR)utfencryptPassword);
            if(isDecompressed)
            {
                log(env, 1, "performhvcheckpointbacku isDecompressed successful!");
                log(env, 1, "performhvcheckpointbacku DeCompression successful!");
                wchar_t *vmbackupPathswstring = new wchar_t[wcslen((LPWSTR)utfpreviousbackuprepositoryPaths) + 1];
                wcscpy(vmbackupPathswstring, (LPWSTR)utfpreviousbackuprepositoryPaths);

            if(wcscmp(vmbackupPathswstring, L"-")!=0)
            {
                wchar_t *backupPath = NULL;
                wchar_t *nextbackupPath = NULL;
                backupPath = wcstok_s(vmbackupPathswstring, L";", &nextbackupPath);
                while (backupPath != NULL)
                {
                    log(env, 1, "performhvcheckpointrestore previous backup path ->  %ws", backupPath);
                    isDecompressed = decompressordeleteFiles(env, (LPWSTR)utfvmName, (LPWSTR)backupPath, L"true", L"decompress", (LPWSTR)utfisEncrypt, (LPWSTR)utfencryptPassword);
                    if(!isDecompressed)
                    {
                        log(env, 1, "performhvcheckpointbacku DeCompression previous backup path failure!");
                        return 856;
                    }
                    backupPath = wcstok_s(NULL, L";", &nextbackupPath);
                }               
            }

            }
            else
            {
                log(env, 1, "performhvcheckpointbacku isDecompressed failure!");
            }
       }
       else if(wcscmp((LPWSTR)utfoperation, L"delete")==0)
       {
            log(env, 1, "Java_com_manageengine_rmp_virtual_HVNativeHandler_zlibHandler Operation - > delete");
            bool isDeleted = decompressordeleteFiles(env, (LPWSTR)utfvmName, (LPWSTR)utfrepositoryPath, (LPWSTR)utfisfullPath, (LPWSTR)utfoperation, (LPWSTR)utfisEncrypt, (LPWSTR)utfencryptPassword);
            wchar_t *vmbackupPathswstring = new wchar_t[wcslen((LPWSTR)utfpreviousbackuprepositoryPaths) + 1];
            wcscpy(vmbackupPathswstring, (LPWSTR)utfpreviousbackuprepositoryPaths);

            if(wcscmp(vmbackupPathswstring, L"-")!=0)
            {
                wchar_t *backupPath = NULL;
                wchar_t *nextbackupPath = NULL;
                backupPath = wcstok_s(vmbackupPathswstring, L";", &nextbackupPath);
                while (backupPath != NULL)
                {
                    log(env, 1, "performhvcheckpointrestore previous backup path to delete->  %ws", backupPath);
                    isDeleted = decompressordeleteFiles(env, (LPWSTR)utfvmName, (LPWSTR)backupPath, L"true", L"delete", (LPWSTR)utfisEncrypt, (LPWSTR)utfencryptPassword);

                    backupPath = wcstok_s(NULL, L";", &nextbackupPath);
                }               
            }

       }

        log(env, 1, "performhvcheckpointbackup Powershell Cmdlet : Release StringChars");
       
        env->ReleaseStringChars(vmName, utfvmName);
        env->ReleaseStringChars(backupType, utfbackupType);        
        env->ReleaseStringChars(repositoryPath, utfrepositoryPath);
        env->ReleaseStringChars(isEncrypt, utfisEncrypt);
        env->ReleaseStringChars(encryptPassword, utfencryptPassword);
        env->ReleaseStringChars(isfullPath, utfisfullPath);
        env->ReleaseStringChars(operation, utfoperation);
        log(env, 1, "performhvcheckpointbackup Powershell Cmdlet : Released StringChars");

        return returnValue;

}

//FLR methods

int getDiskNumberFromDriveLetter(LPCWSTR drive) {
	HANDLE hDeviceHandle = NULL;
	hDeviceHandle = CreateFile(drive, 0, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hDeviceHandle != (HANDLE)-1) {
		STORAGE_DEVICE_NUMBER sdn;
		DWORD returned;
		if (DeviceIoControl(hDeviceHandle, IOCTL_STORAGE_GET_DEVICE_NUMBER, NULL, 0, &sdn, sizeof(sdn), &returned, NULL));
		{
	        CloseHandle(hDeviceHandle);
			return sdn.DeviceNumber;
		}
	}
	CloseHandle(hDeviceHandle);
	return -1;
}

std::string ListVHDDrives(int deviceNumber){
	wchar_t *buffer = new wchar_t[1024];
	//log(env, 1, "deviceNumber" + deviceNumber);
	std::string driveLetters = "";
	for (wchar_t letter = L'C'; letter <= L'Z'; letter++) {
		std::wstring drive;
		drive = letter;
		drive += L":\\";
		if (GetVolumeNameForVolumeMountPoint(drive.c_str(), buffer, 1000)) {
			std::wstring volume = buffer;
			std::wstring param = L"\\??\\" + volume.substr(4, volume.length() - 5);
			std::wstring volumeLink = L"\\\\.\\";
			volumeLink += letter;
			volumeLink += L":";
			if (getDiskNumberFromDriveLetter(volumeLink.c_str())==deviceNumber){
				//log(env, 1, "Letter->" + drive + L"<-param->" + param + L"<-diskNumber->" + getDiskNumberFromDriveLetter(volumeLink.c_str()) + L"\n");
				driveLetters += letter;
			}
		}
	}
	delete[] buffer;
	return driveLetters;
}

std::string attachOrDetach(JNIEnv *env,LPCWSTR vhdPath, bool attach){
    log(env, 1, "attachOrDetach called...");
	std::string driveLetters = "";

	OPEN_VIRTUAL_DISK_PARAMETERS openParameters;
	openParameters.Version = OPEN_VIRTUAL_DISK_VERSION_1;
	openParameters.Version1.RWDepth = OPEN_VIRTUAL_DISK_RW_DEPTH_DEFAULT;

	VIRTUAL_STORAGE_TYPE storageType;
	int vhdPathLength = wcslen(vhdPath);
    if (vhdPath[vhdPathLength-1] == 'x'){
        storageType.DeviceId = VIRTUAL_STORAGE_TYPE_DEVICE_VHDX;
    }
    else{
        storageType.DeviceId = VIRTUAL_STORAGE_TYPE_DEVICE_VHD;
    }
	//storageType.DeviceId = VIRTUAL_STORAGE_TYPE_DEVICE_UNKNOWN;
	storageType.VendorId = VIRTUAL_STORAGE_TYPE_VENDOR_MICROSOFT;

	HANDLE vhdHandle;
	int err = OpenVirtualDisk(&storageType, vhdPath,                            //L"E:\\win8.vhd",
		VIRTUAL_DISK_ACCESS_ALL, OPEN_VIRTUAL_DISK_FLAG_NONE,
		NULL, &vhdHandle);
	if (err != ERROR_SUCCESS) {
		log(env, 1, "Error while opening vhd file ->%d<-",err);
		goto close_VHD_handle;
	}
	log(env, 1, "Opening vhd Handle successful, logical drives value before mount->%d",GetLogicalDrives());
	if (attach){
		err = AttachVirtualDisk(vhdHandle, 0, ATTACH_VIRTUAL_DISK_FLAG_PERMANENT_LIFETIME, 0, 0, 0);//ATTACH_VIRTUAL_DISK_FLAG_READ_ONLY | commented for querying registry
		if (err != ERROR_SUCCESS) {
			log(env, 1, "Error while attaching vhd file(mount) ->%d<-",err);
			goto close_VHD_handle;
		}
		log(env, 1, "Attach completed, logical drives value after mount->%d",GetLogicalDrives());
		wchar_t   physicalDriveName[MAX_PATH];
		DWORD   physicalDriveNameSize = MAX_PATH;
		err = GetVirtualDiskPhysicalPath(vhdHandle, &physicalDriveNameSize, physicalDriveName);
		if (err != ERROR_SUCCESS) {
			log(env, 1, "Error while Getting PhysicalPath vhd file(mount) ->%d<-",err);
			goto close_VHD_handle;
		}
		log(env, 1, "GetVirtualDiskPhysicalPath obtained...");
		//std::wcout << "disk phsyical path->" << physicalDriveName << "<-\n";
		//std::wcout << physicalDriveName[17];
		int driveNumber = physicalDriveName[17]-'0';
		driveLetters = ListVHDDrives(driveNumber);
		if (driveLetters.size() == 0){
            log(env, 1, "unable to find drive letters...");
            log(env, 1, "detachVirtualDisk called...drives present->%d",GetLogicalDrives());
            err = DetachVirtualDisk(vhdHandle, DETACH_VIRTUAL_DISK_FLAG_NONE, NULL);
            log(env, 1, "detachVirtualDisk returned...drives present->%d",GetLogicalDrives());
            goto close_VHD_handle;
		}
		log(env, 1, "obtained driveLetters...");
		CloseHandle(vhdHandle);
		//std::cout<<"drivesletters-> "<<driveLetters<<"<-lasterror->"<<GetLastError();
		return driveLetters;
	}
	else{
		log(env, 1, "detachVirtualDisk called...drives present->%d",GetLogicalDrives());
		err = DetachVirtualDisk(vhdHandle, DETACH_VIRTUAL_DISK_FLAG_NONE, NULL);
		log(env, 1, "detachVirtualDisk returned...drives present->%d",GetLogicalDrives());
	}

	if (err != ERROR_SUCCESS) {
		log(env, 1, "Error while detaching vhd file(mount)>%d<-",err);
	}
close_VHD_handle:

    if (vhdHandle != INVALID_HANDLE_VALUE)
    {
        CloseHandle(vhdHandle);
    }
	return std::to_string(err);
}

JNIEXPORT jstring JNICALL Java_com_manageengine_rmp_virtual_HVNativeHandler_attachOrDetachVHD(JNIEnv *env,jclass obj, jstring jVHDPathToMount, jstring doAttach){
    hypervJNIInitializeClassIDs(env);
    log(env, 1, "Java_com_manageengine_rmp_virtual_HVManagedNative_attachVHD started..!");
    LPCWSTR lVHDPathToMount = (LPWSTR)env->GetStringChars( jVHDPathToMount, NULL);
    bool isAttach = (strcmp(env->GetStringUTFChars(doAttach,0), "ATTACH") == 0);
    std::string driveLetters = attachOrDetach(env,lVHDPathToMount,isAttach);
    jstring jDriveLetters = env->NewStringUTF(driveLetters.c_str());
    log(env, 1, "Java_com_manageengine_rmp_virtual_HVManagedNative_attachVHD Returning...!");
    return jDriveLetters;
}