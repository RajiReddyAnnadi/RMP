#include "jni/HealthCheck.h"

//int add(int a,int b){
//    return (a+b);
//}
//
//JNIEXPORT jint JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_sampleMethod(JNIEnv *env, jclass obj, jstring sample, jthrowable exceptionObject)
//{
//    VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
//    vmd->printJNI(sample);
//    vmd->log(env, 1, "Sample printed");
//    int a = add(10, 20);
//    vmd->log(env, 1, "%d",a);
//    vmd->log(env, 1, "listSizeID %d",listSizeID);
//    return jint(1);
//}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_generateHashValuesForFiles(JNIEnv *env, jclass obj,jstring backupIdentifier, jstring directoryPath, jboolean isFullBackup, jboolean isBackupHash, jboolean isEncrypted, jstring password, jthrowable nativeException)
{
    VMDataCollector* vmd = new VMDataCollector(env, nativeException);
    vmd->log(env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_generateHashValuesForFiles() started");
    vmd->printJNI(directoryPath);

    int returnVal = generateHashForFilesInDirectory(vmd,backupIdentifier,directoryPath, isFullBackup, L"backuphash", isEncrypted, password);
    delete vmd;

    vmd->log(env,1,"generateHashValuesForFiles %d...\n",__LINE__);
    return returnVal;
}

int generateHashForFilesInDirectory(VMDataCollector* vmd,jstring backupIdentifier,jstring directoryPath, bool isFullBackup, wstring hashType, bool isEncrypted, jstring encryptPassword)
{
    vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() ");
    //wstring hashType;
    wstring fileType = L"vmdk";
    wstring mode = L"a";
    int returnVal = 0;
    //check mode of files
    vmd->printJNI(backupIdentifier);
    vmd->printJNI(directoryPath);
    //vmd->printJNI(hashType);
    vmd->printJNI(encryptPassword);
    if(isFullBackup){
        vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() isFullBackup: true");
    }else{
        vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() isFullBackup: false");
    }

    if(isEncrypted){
        vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() isEncrypted: true");
    }else{
        vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() isEncrypted: false");
    }

    map<wstring, BOOL> *filesListMap = new map<wstring, BOOL>();
    LPWSTR ldirectoryPath = (LPWSTR) vmd->env->GetStringChars(directoryPath, NULL);
    wstring wdirectoryPath = ldirectoryPath;
    LPWSTR lbackupIdentifier = (LPWSTR) vmd->env->GetStringChars(backupIdentifier, NULL);
    wstring wbackupIdentifier = lbackupIdentifier;
    vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
    LPWSTR lencryptPassword = (LPWSTR)vmd->env->GetStringChars(encryptPassword, NULL);
    wstring wencryptPassword = lencryptPassword;
    BOOL isSuccess;
    vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() wencryptPassword : %ws\n",wencryptPassword);

    //for deleting the content in previous single hash file
    FILE *singlehashFile;
    wchar_t* singlehashfilepath = new wchar_t[wcslen((wchar_t*) wdirectoryPath.c_str()) + wcslen((wchar_t*)hashType.c_str()) +  wcslen(L"_single_") + wcslen((wchar_t*)wbackupIdentifier.c_str()) + wcslen(L".txt") + 2];
    wcscpy(singlehashfilepath, (wchar_t*) wdirectoryPath.c_str());
    wcscat(singlehashfilepath, L"\\");
    wcscat(singlehashfilepath, (wchar_t*)wbackupIdentifier.c_str());
    wcscat(singlehashfilepath, L"_");
    wcscat(singlehashfilepath, (wchar_t*)hashType.c_str());
    wcscat(singlehashfilepath, L"_single");
    wcscat(singlehashfilepath, L".txt");
    wcscat(singlehashfilepath, L"\0");
    _wfopen_s(&singlehashFile, singlehashfilepath, L"w");
    vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() singlehashfilepath : %ws\n",singlehashfilepath);
    if(singlehashFile){ fclose(singlehashFile);}
    wstring vmSummaryFile = wdirectoryPath + L"\\" + L"VirtualMachine_Summary.xml";
    returnVal = generateHashforFile(vmd,(wchar_t*)vmSummaryFile.c_str(),(wchar_t*) wdirectoryPath.c_str(), (wchar_t*)wbackupIdentifier.c_str(), (wchar_t*)hashType.c_str(), L"True", (wchar_t*)mode.c_str(), L"xml");
    if(returnVal){
        vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() Generating hash for VirtualMachineSummmary.xml file Failed at %d\n",__LINE__);
    }
    vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
    isSuccess = listFiles(vmd,wdirectoryPath, L"*.idx", filesListMap);
    vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
    if(isSuccess){
        for (std::map<wstring, BOOL>::iterator it = filesListMap->begin(); it != filesListMap->end(); ++it)
        {
            vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
            wstring fileName = it->first;
            if(!it->second) //TRUE if directory, else file
            {
                wchar_t* wcharFileName = (wchar_t*)  fileName.c_str();
                vmd->log(vmd->env, 1, "wcharFileName %ws",wcharFileName);
                returnVal = generateHashforFile(vmd,wcharFileName,(wchar_t*) wdirectoryPath.c_str(), (wchar_t*)wbackupIdentifier.c_str(), (wchar_t*)hashType.c_str(), L"True", (wchar_t*)mode.c_str(), L"idx");
                //returnVal = generateSingleHashandBlockbyBlockHashforDisk((wchar_t*) wdirectoryPath.c_str(), wcharFileName, destFileName,(wchar_t*)wbackupIdentifier.c_str(), true,(wchar_t*) wencryptPassword.c_str(), (wchar_t*)hashType.c_str(), L"idx");
                if(returnVal){
                    goto generate_hash_for_file_error;
                }
            }

        }
    }

    filesListMap->clear();
    if(isFullBackup){
        vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
        if(isEncrypted){
            vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
            isSuccess = listFiles(vmd,wdirectoryPath, L"*.vmdk_secure", filesListMap);
            vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
            if(isSuccess){
                for (std::map<wstring, BOOL>::iterator it = filesListMap->begin(); it != filesListMap->end(); ++it)
                {
                    vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
                    wstring fileName = it->first;
                    if(!it->second) //TRUE if directory, else file
                    {
                        wchar_t* wcharFileName = (wchar_t*)  fileName.c_str();
                        int length = fileName.length();
                        int pos = fileName.find_last_of(L".");
                        vmd->log(vmd->env, 1, "wcharFileName %ws",wcharFileName);
                        wchar_t* destFileName = (wchar_t*)fileName.erase(pos,length-pos).c_str();
                        returnVal = generateSingleHashandBlockbyBlockHashforDisk(vmd,(wchar_t*) wdirectoryPath.c_str(), wcharFileName, destFileName,(wchar_t*)wbackupIdentifier.c_str(), true,(wchar_t*) wencryptPassword.c_str(), (wchar_t*)hashType.c_str(), (wchar_t*)fileType.c_str());
                        if(returnVal){
                            goto generate_hash_for_file_error;
                        }
                    }

                }
            }

            filesListMap->clear();
        }
            isSuccess = listFiles(vmd,wdirectoryPath, L"*.vmdk", filesListMap);
            if(isSuccess){
                for (std::map<wstring, BOOL>::iterator it = filesListMap->begin(); it != filesListMap->end(); ++it)
                {
                    wstring fileName = it->first;
                    if(!it->second) //TRUE if directory, else file
                    {
                        wchar_t* wcharFileName = (wchar_t*)  fileName.c_str();
                        int pos = fileName.find_last_of(L".");
                        int length = fileName.length();
                        vmd->log(vmd->env, 1, "wcharFileName %ws",wcharFileName);
                        wchar_t* destFileName = (wchar_t*)fileName.erase(pos,length-pos).c_str();
                        //Check for isEncrypted in this case
                        returnVal = generateSingleHashandBlockbyBlockHashforDisk(vmd, (wchar_t*) wdirectoryPath.c_str(), wcharFileName, destFileName,(wchar_t*)wbackupIdentifier.c_str(), false, (wchar_t*) wencryptPassword.c_str(), (wchar_t*)hashType.c_str(), (wchar_t*)fileType.c_str());
                        vmd->log(vmd->env, 1, "generateSingleHashandBlockbyBlockHashforDisk() done for %ws %d\n",wcharFileName,__LINE__);
                        if(returnVal){
                            goto generate_hash_for_file_error;
                        }
                    }

                }
            }

            vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
    }else{
        isSuccess = listFiles(vmd,wdirectoryPath, L"*.vmdk__incrementalDetails.txt", filesListMap);
        if(isSuccess){
            for (std::map<wstring, BOOL>::iterator it = filesListMap->begin(); it != filesListMap->end(); ++it)
            {
                wstring fileName = it->first;
                if(!it->second) //TRUE if directory, else file
                {
                    wchar_t* wcharFileName = (wchar_t*)fileName.c_str();
                    vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
                    returnVal = generateHashforFile(vmd,wcharFileName,(wchar_t*) wdirectoryPath.c_str(), (wchar_t*)wbackupIdentifier.c_str(), (wchar_t*)hashType.c_str(), L"True", (wchar_t*)mode.c_str(), L"metadata");
                    vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
                    if(returnVal){
                        goto generate_hash_for_file_error;
                    }
//                    int pos = fileName.find_last_of(L".");
//                    int length = fileName.length();
//                    vmd->log(vmd->env, 1, "wcharFileName %ws",wcharFileName);
//                    wchar_t* destFileName = (wchar_t*)fileName.erase(pos,length-pos).c_str();
//                    generateSingleHashandBlockbyBlockforIncrementalDisk((wchar_t*) wdirectoryPath.c_str(), wcharFileName, destFileName,(wchar_t*)wbackupIdentifier.c_str(), (wchar_t*)hashType.c_str(), (wchar_t*)fileType.c_str(),isEncrypted,encryptPassword);
                }
            }
        }
        filesListMap->clear();
        if(isEncrypted){
            isSuccess = listFiles(vmd,wdirectoryPath, L"*.vmdk_secure", filesListMap);
            if(isSuccess){
                for (std::map<wstring, BOOL>::iterator it = filesListMap->begin(); it != filesListMap->end(); ++it)
                {
                    wstring fileName = it->first;
                    if(!it->second) //TRUE if directory, else file
                    {
                        wchar_t* wcharFileName = (wchar_t*)  fileName.c_str();
                        int pos = fileName.find_last_of(L".");
                        int length = fileName.length();
                        vmd->log(vmd->env, 1, "wcharFileName %ws %d\n",wcharFileName,__LINE__);
                        wchar_t* destFileName = (wchar_t*)fileName.erase(pos,length-pos).c_str();
                        vmd->log(vmd->env, 1, "(wchar_t*) wencryptPassword.c_str() %ws\n",(wchar_t*) wencryptPassword.c_str());
                        returnVal = generateSingleHashandBlockbyBlockforIncrementalDisk(vmd, (wchar_t*) wdirectoryPath.c_str(), wcharFileName, destFileName,(wchar_t*)wbackupIdentifier.c_str(), (wchar_t*)hashType.c_str(), L"vmdkInc",isEncrypted,(wchar_t*) wencryptPassword.c_str());
                        if(returnVal){
                            goto generate_hash_for_file_error;
                        }
                    }

                }
            }
        }
        filesListMap->clear();
        isSuccess = listFiles(vmd,wdirectoryPath, L"*.vmdk", filesListMap);
        if(isSuccess){
            for (std::map<wstring, BOOL>::iterator it = filesListMap->begin(); it != filesListMap->end(); ++it)
            {
                wstring fileName = it->first;
                if(!it->second) //TRUE if directory, else file
                {
                    wchar_t* wcharFileName = (wchar_t*)  fileName.c_str();
                    int pos = fileName.find_last_of(L".");
                    int length = fileName.length();
                    vmd->log(vmd->env, 1, "wcharFileName %ws %d",wcharFileName,__LINE__);
                    wchar_t* destFileName = (wchar_t*)fileName.erase(pos,length-pos).c_str();
                    //Check for isEncrypted in this case
                    //check if encryptPasswd is NULL
                    returnVal = generateSingleHashandBlockbyBlockforIncrementalDisk(vmd, (wchar_t*) wdirectoryPath.c_str(), wcharFileName, destFileName,(wchar_t*)wbackupIdentifier.c_str(), (wchar_t*)hashType.c_str(), L"vmdkInc",false,(wchar_t*) wencryptPassword.c_str());
                    if(returnVal){
                        goto generate_hash_for_file_error;
                    }
                }

            }
        }
        vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
    }
    vmd->env->ReleaseStringChars(directoryPath, (jchar*)ldirectoryPath);
    vmd->env->ReleaseStringChars(backupIdentifier, (jchar*)lbackupIdentifier);
    vmd->env->ReleaseStringChars(encryptPassword, (jchar*)lencryptPassword);
    vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
    return 0;

    generate_hash_for_file_error:
    vmd->env->ReleaseStringChars(directoryPath, (jchar*)ldirectoryPath);
    vmd->env->ReleaseStringChars(backupIdentifier, (jchar*)lbackupIdentifier);
    vmd->env->ReleaseStringChars(encryptPassword, (jchar*)lencryptPassword);
    vmd->log(vmd->env, 1, "generateHashForFilesInDirectory() %d\n",__LINE__);
    return returnVal;
}

/*  gets list of Files in the directoryPath; mask for getting specific type of files; list of files assigned to filesList  */
BOOL listFiles(VMDataCollector* vmd,wstring directoryPath, wstring mask, map<wstring, BOOL> *filesList) {
    // vmd->log(vmd->env,1,"listFiles called with  directoryPath : %ws , mask : %ws \n",directoryPath,mask);
	WIN32_FIND_DATA findData;
	BOOL isSuccess = FALSE;

	wstring directoryPathWithMask = directoryPath + L"\\" + mask;

	HANDLE firstFileHandle = FindFirstFile(directoryPathWithMask.c_str(), &findData);

	if (firstFileHandle != INVALID_HANDLE_VALUE) {
		do {
			if (wcscmp(findData.cFileName, L".") != 0 && wcscmp(findData.cFileName, L"..") != 0) {
				wstring foundFileName = findData.cFileName;
				wstring foundFilePath = directoryPath + L"\\" + foundFileName;
				BOOL isDirectory = findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ? TRUE : FALSE;

				filesList->insert(std::pair<wstring, BOOL>(foundFilePath, isDirectory));
			}
		} while (FindNextFile(firstFileHandle, &findData) != 0);

		DWORD errorCode = (int)GetLastError();

		if (errorCode != ERROR_NO_MORE_FILES) {
		    vmd->log(vmd->env,1,"FindNextFile failed with error : %d\n",errorCode);
			isSuccess = FALSE;
		}
		isSuccess = TRUE;
		FindClose(firstFileHandle);
	}
	else {
		isSuccess = FALSE;
		vmd->log(vmd->env,1,"listFiles : FindFirstFile failed with error : %d\n", (int)GetLastError());
	}

	return isSuccess;
}

int generateHashforFile(VMDataCollector* vmd,wchar_t* sourceFilePath, wchar_t* destFilePath, wchar_t* backupIdentifier,  wchar_t* hashType, wchar_t* isSingleHash, wchar_t* mode, wchar_t* fileType)
{
    vmd->log(vmd->env,1,"generateHashForFile started for file->%ws...\n",sourceFilePath);
	DWORD bytesread = 0, tRead = 0, cbHash = 0;
	DWORD64 itr = 0, bufSizetoHash = BUFSIZETOHASH;
    HCRYPTPROV hProv = 0;
    HCRYPTHASH hHash = 0;
    HANDLE hFile = NULL;
    FILE * hashFile;
    BYTE * buffer;
    int returnVal =  0;
    buffer = new BYTE[BUFSIZE];
    BYTE rgbHash[MD5LEN];
    CHAR rgbDigits[] = "0123456789abcdef";
    BOOL readResult = FALSE;
    wchar_t* wtextDest;
    wchar_t* wtextSource = new wchar_t[wcslen(sourceFilePath) + 1];
    wcscpy(wtextSource, sourceFilePath);
    wcscat(wtextSource, L"\0");
    LPCWSTR LsourceFile = wtextSource;
    //vmd->log(vmd->env,1,"generateHashForFile %d...\n",__LINE__);
    LPTSTR DestFile;
    if(wcscmp(isSingleHash, L"True") == 0) {
        wtextDest = new wchar_t[wcslen(destFilePath) + wcslen(backupIdentifier) + wcslen(hashType) +  wcslen(L"_single.txt") + 3];
        wcscpy(wtextDest, destFilePath);
        wcscat(wtextDest, L"\\");
    	wcscat(wtextDest, backupIdentifier);
    	wcscat(wtextDest, L"_");
        wcscat(wtextDest, hashType);
        wcscat(wtextDest, L"_single.txt");
        wcscat(wtextDest, L"\0");
        DestFile = wtextDest;
	}else {
	    wtextDest = new wchar_t[wcslen(destFilePath) + wcslen(backupIdentifier) + wcslen(hashType) + wcslen(L".txt") + 3];
    	wcscpy(wtextDest, destFilePath);
    	wcscat(wtextDest, L"_");
    	wcscat(wtextDest, backupIdentifier);
    	wcscat(wtextDest, L"_");
    	wcscat(wtextDest, hashType);
    	wcscat(wtextDest, L".txt");
    	wcscat(wtextDest, L"\0");
    	DestFile = wtextDest;
	}
   // vmd->log(vmd->env,1,"generateHashForFile %d...\n",__LINE__);
    _wfopen_s(&hashFile, DestFile, mode);
    if (!hashFile) {
        vmd->log(vmd->env,1,"generateHashForFile _wfopen_s error %d...\n", GetLastError());
        returnVal =  444;
        goto generate_hash_for_file_error;
    }
   // vmd->log(vmd->env,1,"generateHashForFile %d...\n",__LINE__);
    hFile = CreateFile(LsourceFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	if (INVALID_HANDLE_VALUE == hFile) {
		vmd->log(vmd->env, 1, "generateHashForFile() CreateFile failed Error: %d\n", GetLastError());
		if (hashFile) {
                fclose(hashFile);
            }
        returnVal =  458;
		goto generate_hash_for_file_error;
	}
	if(wcscmp(isSingleHash, L"True") == 0) {
	    ULARGE_INTEGER fileSize;
        DWORD error;
        fileSize.LowPart = GetFileSize(hFile, &fileSize.HighPart);
        if (fileSize.LowPart == INVALID_SET_FILE_POINTER && (error = GetLastError()) != ERROR_SUCCESS) {
            bufSizetoHash = 0; //If not able to get fileSize set bufSizetoHash as a fileSize. this case also it works fine.
        }else {
            bufSizetoHash = fileSize.QuadPart; //For single hash of a file set bufSizetoHash as a fileSize.
        }
	}
    // Get handle to the crypto provider
   // vmd->log(vmd->env,1,"generateHashForFile %d...\n",__LINE__);
	if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
	//vmd->log(vmd->env,1,"generateHashForFile %d...\n",__LINE__);
        if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
  //  vmd->log(vmd->env,1,"generateHashForFile %d...\n",__LINE__);
                while(1) {
   //                 vmd->log(vmd->env,1,"generateHashForFile %d...\n",__LINE__);
                    readResult = ReadFile(hFile, buffer, BUFSIZE, &bytesread, NULL);
                    if(readResult) {
                        tRead += bytesread;
                        if (bytesread == 0 && tRead == 0) {
                            break;
                        }else {
                            if (CryptHashData(hHash, buffer, bytesread, 0)) {
                                if (tRead == bufSizetoHash || bytesread < BUFSIZE) {
                                    tRead = 0;
                                    cbHash = MD5LEN;
                                    if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0)) {
                                        if((wcscmp(mode, L"a") == 0) && (wcscmp(isSingleHash, L"True") == 0)) {
                                            if(wcscmp(mode, L"-") == 0){
                                                fwprintf_s(hashFile, L"%ws\t", wtextSource);
                                            }else{
                                                fwprintf_s(hashFile, L"%ws\t%ws\t", wtextSource, fileType);
                                            }
                                        }else {
                                            fwprintf_s(hashFile, L"%lld\t", itr * bufSizetoHash );
                                        }
                                        for (DWORD i = 0; i < cbHash; i++)
                                        {
                                            fwprintf_s(hashFile, L"%c%c", rgbDigits[rgbHash[i] >> 4], rgbDigits[rgbHash[i] & 0xf]);
                                        }
                                        fwprintf(hashFile ,L"\t");
                                    }
                                    else {
                                        //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptGetHashParam failed Error: %d\n", GetLastError());
                                        if(hHash){
                                            CryptDestroyHash(hHash);
                                        }
                                        if(hProv) {
                                            CryptReleaseContext(hProv, 0);
                                        }
                                        if(hFile) {
                                            CloseHandle(hFile);
                                        }
                                        if (hashFile) {
                                            fclose(hashFile);
                                        }
                                        returnVal =  463;
                                        goto generate_hash_for_file_error;
                                    }
                                    if(hHash){
                                        CryptDestroyHash(hHash);
                                    }
                                    if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
                                        //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash failed Error: %d\n", GetLastError());
                                        if(hProv) {
                                            CryptReleaseContext(hProv, 0);
                                        }
                                        if(hFile) {
                                            CloseHandle(hFile);
                                        }
                                        if (hashFile) {
                                            fclose(hashFile);
                                        }
                                        returnVal =  461;
                                        goto generate_hash_for_file_error;
                                    }
                                    itr++;
                                }
                            }else {
                                //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptHashData failed Error: %d\n", GetLastError());
                                if(hHash){
                                    CryptDestroyHash(hHash);
                                }
                                if(hProv) {
                                    CryptReleaseContext(hProv, 0);
                                }
                                if(hFile) {
                                    CloseHandle(hFile);
                                }
                                if (hashFile) {
                                    fclose(hashFile);
                                }
                                returnVal =  462;
                                goto generate_hash_for_file_error;
                            }
                        }
                    }else {
                        //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Reading Backup File failed Error: %d\n", GetLastError());
                        if(hHash){
                            CryptDestroyHash(hHash);
                        }
                        if(hProv) {
                            CryptReleaseContext(hProv, 0);
                        }
                        if(hFile) {
                            CloseHandle(hFile);
                        }
                        if (hashFile) {
                            fclose(hashFile);
                        }
                        returnVal =  459;
                        goto generate_hash_for_file_error;
                    }
                }
                if(hHash){
                    CryptDestroyHash(hHash);
                }
                if(hProv) {
                    CryptReleaseContext(hProv, 0);
                }
        }else {
            //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash failed Error: %d\n", GetLastError());
            if(hProv) {
            	CryptReleaseContext(hProv, 0);
            }
            if(hFile) {
                CloseHandle(hFile);
            }
        	if (hashFile) {
        		fclose(hashFile);
        	}
        	returnVal =  461;
            goto generate_hash_for_file_error;
        }
	}else {
		//healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptAcquireContext failed Error: %d\n", GetLastError());
        if(hFile) {
            CloseHandle(hFile);
        }
        if (hashFile) {
            fclose(hashFile);
        }
        returnVal =  460;
		goto generate_hash_for_file_error;
	}
	if(hFile) {
	    CloseHandle(hFile);
	}
    if (hashFile) {
        fclose(hashFile);
    }
	//healthcheckLogger->log(NORMAL, L"HealthCheck.cpp generateHashForFile Ended...\n");
	delete[] buffer;
    delete[] wtextDest;
    delete[] wtextSource;
	//vmd->log(vmd->env,1,"generateHashForFile %d...\n",__LINE__);
	return 0;

	generate_hash_for_file_error:
	delete[] buffer;
	delete[] wtextDest;
	delete[] wtextSource;
	return returnVal;
}

bool isIdxCorrupted(wchar_t* wtextindexFile, wchar_t* wtextBackupSingleHash, wchar_t* wtextDestofSingleHash, wchar_t* destFileDir ){
    //vmd->log(vmd->env,1,"isIdxCorrupted destFileDir->%ws\nwtextindexFile : %ws\nwtextDestofSingleHash: %ws",destFileDir, wtextindexFile,wtextBackupSingleHash,wtextDestofSingleHash);
    wstring windexFile(wtextindexFile);
    wstring wBackupSingleHash(wtextBackupSingleHash);
    wstring wDestofSingleHash(wtextDestofSingleHash);
    wstring wdestFileDir(destFileDir);
    string sindexFile(windexFile.begin(), windexFile.end());
    string sBackupSingleHash(wBackupSingleHash.begin(), wBackupSingleHash.end());
    string sDestofSingleHash(wDestofSingleHash.begin(), wDestofSingleHash.end());
    string sdestFileDir(wdestFileDir.begin(), wdestFileDir.end());
    string hcHashline;
    string backupHashline;
    bool returnVal = true;
    ifstream backupHashfile(sBackupSingleHash);
    ifstream hcHashfile(sDestofSingleHash);
    std::getline(hcHashfile,hcHashline);
    string name, type, value;
    std::stringstream line_ss(hcHashline);
    unsigned int index = 0;
    int i = 0;
    //string filename = "F:\\ManageEngine\\raji_backup_health\\RecoveryManagerPlus\\bin\\virtual_backup\\13201\\1502\\[datastore1 1] raji multi disk_raji multi disk_1.idx";
    string requiredHashValue;
    queue<string*>* hcFilesInfo = new queue<string*>();
    while (getline(line_ss, name, '\t')) {
        getline(line_ss, type, '\t');
        getline(line_ss, value, '\t');
        cout << name << ", " << type << ", " << value << endl;
        string *eachFileInfo = new string[3];
        eachFileInfo[0] = name;
        eachFileInfo[1] = type;
        eachFileInfo[2] = value;
        if (sindexFile.compare(eachFileInfo[0]) == 0) {
            requiredHashValue = eachFileInfo[2];
        }
        hcFilesInfo->push(eachFileInfo);
    }

    cout << "--------------------------------------\n\n";
    std::getline(backupHashfile, backupHashline);
    std::stringstream bline_ss(backupHashline);

    while (getline(bline_ss, name, '\t')) {
        getline(bline_ss, type, '\t');
        getline(bline_ss, value, '\t');
        if (sindexFile.compare(name) == 0) {
            if (requiredHashValue.compare(value) == 0) {
                returnVal = false;
            }
        }
    }
    string* eachFile;
    if (returnVal) {
        cout << "-----------------corrputed-----------------\n\n";
        ofstream ofile(sDestofSingleHash + "Temp");
        while (!hcFilesInfo->empty()) {
            eachFile = hcFilesInfo->front();
            hcFilesInfo->pop();
            if (sindexFile.compare(eachFile[0])) {
                ofile << eachFile[0] << "\t" << eachFile[1] << "\t" << eachFile[2] << "\t";
                cout << eachFile[0] << "\t" << eachFile[1] << "\t" << eachFile[2] << "\n";
            }
            delete[] eachFile;
        }
        cout << "-----------------corrputed writing done-----------------\n\n";
        ofile.close();
        hcHashfile.close();
        remove(sDestofSingleHash.c_str());
        rename((sDestofSingleHash + "Temp").c_str(),sDestofSingleHash.c_str());
    }
    else {
        while (!hcFilesInfo->empty()) {
            eachFile = hcFilesInfo->front();
            hcFilesInfo->pop();
            delete[] eachFile;
        }
        hcHashfile.close();
    }
    delete hcFilesInfo;
    backupHashfile.close();
    return returnVal;
}

int generateSingleHashandBlockbyBlockHashforDisk(VMDataCollector* vmd,wchar_t* destFileDir, wchar_t* sourceFilePath, wchar_t* destFilePath, wchar_t* backupIdentifier,bool isEncrypted, wchar_t* encryptPassword, wchar_t* hashType, wchar_t* fileType)
{
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk started for destFileDir->%ws\nsourceFilePath : %ws\ndestFilePath: %ws",destFileDir,sourceFilePath,destFilePath);
	DWORD bytesread = 0, tRead = 0, cbHash = 0;
	DWORD64 itr = 0;
    HCRYPTPROV hProv = 0;
    HCRYPTHASH hHash = 0;
    HCRYPTHASH hHashNew = 0;
    FILE* hashFile;
    FILE* hashFileNew;
    FILE* sourceFile;
    BYTE *buffer;
    //gzFile sourceFile;
    struct access *index = NULL;
    int isfileopened = 0;
    buffer= new BYTE[BUFSIZE];
    BYTE rgbHash[MD5LEN];
    CHAR rgbDigits[] = "0123456789abcdef";
    LONGLONG offset = 0;
    int returnVal = 0;
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk encryptPassword %ws\n", encryptPassword);
    wchar_t* wtextSource;
    if(isEncrypted){
        wtextSource = new wchar_t[wcslen(sourceFilePath) + 13];
        wcscpy(wtextSource, sourceFilePath);
        wcscat(wtextSource, L".vmdk_secure");
    }else{
        wtextSource = new wchar_t[wcslen(sourceFilePath) + 6];
        wcscpy(wtextSource, sourceFilePath);
        wcscat(wtextSource, L".vmdk");
    }
    wcscat(wtextSource, L"\0");
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk wtextSource %ws\n", wtextSource);
    LPCWSTR LsourceFile = wtextSource;
  //  vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk _LsourceFile :   %ws\n", LsourceFile);
	wchar_t* wtextDest = new wchar_t[wcslen(destFilePath) + wcslen(backupIdentifier) + wcslen(hashType) + wcslen(L".txt") + 3];
	wcscpy(wtextDest, destFilePath);
	wcscat(wtextDest, L"_");
	wcscat(wtextDest, backupIdentifier);
	wcscat(wtextDest, L"_");
	wcscat(wtextDest, hashType);
	wcscat(wtextDest, L".txt");
	wcscat(wtextDest, L"\0");
	LPTSTR DestFile = wtextDest;
   // vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk DestFile %ws\n", DestFile);
    wchar_t* wtextDestofSingleHash = new wchar_t[wcslen(destFileDir) + wcslen(backupIdentifier) + wcslen(hashType) +  wcslen(L"_single.txt") + 3];
    wcscpy(wtextDestofSingleHash, destFileDir);
    wcscat(wtextDestofSingleHash, L"\\");
	wcscat(wtextDestofSingleHash, backupIdentifier);
	wcscat(wtextDestofSingleHash, L"_");
    wcscat(wtextDestofSingleHash, hashType);
    wcscat(wtextDestofSingleHash, L"_single.txt");
    wcscat(wtextDestofSingleHash, L"\0");
    LPTSTR DestFileofSingleHash = wtextDestofSingleHash;
   // vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk DestFileofSingleHash %ws\n", DestFileofSingleHash);
    wchar_t* wtextindexFile = new wchar_t[wcslen(destFilePath)+ wcslen(L".idx") + 1];
    wcscpy(wtextindexFile, destFilePath);
    wcscat(wtextindexFile, L".idx");
    wcscat(wtextindexFile, L"\0");
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk wtextindexFile %ws\n", wtextindexFile);
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__);
    int indexCreationResult;
    if (!PathFileExists(wtextindexFile)){
        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__);
        if(isEncrypted){
            indexCreationResult = vmd->indexCreation(wtextSource, true, encryptPassword);
        }else{
            indexCreationResult = vmd->indexCreation(wtextSource, false, NULL);
        }
        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk indexCreationResult %d at %d\n",indexCreationResult, __LINE__);
        if(indexCreationResult){//index not generated
            return 444;
        }
    }else if(wcscmp(hashType,L"backuphash")){
        wchar_t* wtextBackupSingleHash = new wchar_t[wcslen(destFileDir) + wcslen(backupIdentifier) + wcslen(L"backuphash") +  wcslen(L"_single.txt") + 3];
        wcscpy(wtextBackupSingleHash, destFileDir);
        wcscat(wtextBackupSingleHash, L"\\");
        wcscat(wtextBackupSingleHash, backupIdentifier);
        wcscat(wtextBackupSingleHash, L"_");
        wcscat(wtextBackupSingleHash, L"backuphash");
        wcscat(wtextBackupSingleHash, L"_single.txt");
        wcscat(wtextBackupSingleHash, L"\0");
        if(isIdxCorrupted(wtextindexFile,wtextBackupSingleHash,wtextDestofSingleHash,destFileDir )){
            vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk isIdxCorrupted returned TRUE. Generating hash again");
            if(isEncrypted){
                indexCreationResult = vmd->indexCreation(wtextSource, true, encryptPassword);
            }else{
                indexCreationResult = vmd->indexCreation(wtextSource, false, NULL);
            }
        }
    }
    //LPTSTR DestFileofSingleHash = wtextDestofSingleHash;
    _wfopen_s(&hashFile, DestFile, L"w");
    if (!hashFile) {
        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk _wfopen_s error %d...\n", GetLastError());
        returnVal = 464;
        goto generate_hash_for_file_error;
    }
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__);
    // Get handle to the crypto provider
	if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
	vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
        if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
            if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHashNew)) {
            vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                int sourceFiletemp = _wopen(LsourceFile, _O_RDONLY | _O_BINARY);
                if (sourceFiletemp != -1) {
                        cout<<__LINE__<<endl;  vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__);
                        index = vmd->getIndexforFile(index, wtextindexFile);
                        sourceFile = fdopen(sourceFiletemp, "rb");
                        cout<<sourceFile<<"  "<<__LINE__<<endl;  vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__);
                    if(sourceFile) {
                        while(1) {
                            if(isEncrypted) {
                                bytesread = extractDecrypt(sourceFile, index, offset, buffer, BUFSIZE, encryptPassword);
                            }else{
                                //bytesread = gzread(sourceFile, buffer, BUFSIZE);
                                bytesread = extract(sourceFile, index, offset, buffer, BUFSIZE);
                               // vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk bytesread %d\n", bytesread);
                            }
  //                          vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk bytesread %d\n", bytesread);
                            offset += BUFSIZE;
                            if (bytesread == 0 && tRead == 0 && feof(sourceFile)) { //why tRead == 0 condition
                                break;
                            }else if((int)bytesread >= 0) {
  //                          vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__);
                                tRead += bytesread;
                                if (CryptHashData(hHash, buffer, bytesread, 0)) {
  //                              vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__);
                                    if (CryptHashData(hHashNew, buffer, bytesread, 0)) {
                                //    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__);
                                        if (tRead == BUFSIZETOHASH || bytesread < BUFSIZE) {
                                  //      vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__);
                                            tRead = 0;
                                            cbHash = MD5LEN;
                                            if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0)) {
                                                    fwprintf_s(hashFile, L"%lld\t", itr * BUFSIZETOHASH);
                                                for (DWORD i = 0; i < cbHash; i++)
                                                {
                                                    fwprintf_s(hashFile, L"%c%c", rgbDigits[rgbHash[i] >> 4], rgbDigits[rgbHash[i] & 0xf]);
                                                }
                                                fwprintf(hashFile ,L"\t");
                                            }
                                            else {
                                                //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptGetHashParam failed Error: %d\n", GetLastError());
//                                                if(sourceFile) {
//                                                    gzclose(sourceFile);
//                                                }
                                                vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                                                if(sourceFile) {
                                                    fclose(sourceFile);
                                                }
                                                if(hHashNew){
                                                    CryptDestroyHash(hHashNew);
                                                }
                                                if(hHash){
                                                    CryptDestroyHash(hHash);
                                                }
                                                if(hProv) {
                                                    CryptReleaseContext(hProv, 0);
                                                }
                                                if (hashFile) {
                                                    fclose(hashFile);
                                                }
                                                returnVal = 463;
                                                goto generate_hash_for_file_error;
                                            }
                                            if(hHash){
                                                CryptDestroyHash(hHash);
                                            }
                                            if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
                                                vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                                                if(sourceFile) {
                                                    fclose(sourceFile);
                                                }
                                                if(hHashNew){
                                                    CryptDestroyHash(hHashNew);
                                                }
                                                if(hProv) {
                                                    CryptReleaseContext(hProv, 0);
                                                }
                                                if (hashFile) {
                                                    fclose(hashFile);
                                                }
                                                returnVal = 461;
                                                goto generate_hash_for_file_error;
                                            }
                                            itr++;
                                        }
                                        continue;
                                    }
                                }
                               // healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash failed Error: %d\n", GetLastError());
//                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Failed at offset : %lld : %lld : %d\n", itr * BUFSIZETOHASH, offset, bytesread);
                                  vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                                    if(sourceFile) {
                                        fclose(sourceFile);
                                    }
                                    if(hHashNew){
                                        CryptDestroyHash(hHashNew);
                                    }
                                    if(hHash){
                                        CryptDestroyHash(hHash);
                                    }
                                    if(hProv) {
                                        CryptReleaseContext(hProv, 0);
                                    }
                                    if (hashFile) {
                                        fclose(hashFile);
                                    }
                                    returnVal = 462;
                                    goto generate_hash_for_file_error;
                            }else {
//                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Reading Backup File failed Error: %d\n", GetLastError());
//                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Failed at offset : %lld : %lld\n", itr * BUFSIZETOHASH, offset);
                                vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                                if(wcscmp(hashType, L"healthcheckhash") == 0) {
                                        tRead = 0;
                                        fwprintf_s(hashFile, L"%lld\t%ws\t", itr * BUFSIZETOHASH, L"00000000000000000000000000000000");
                                        itr++;
                                        continue;
                                }
                                    if(sourceFile) {
                                        fclose(sourceFile);
                                    }
                                    if(hHashNew){
                                        CryptDestroyHash(hHashNew);
                                    }
                                    if(hHash){
                                        CryptDestroyHash(hHash);
                                    }
                                    if(hProv) {
                                        CryptReleaseContext(hProv, 0);
                                    }
                                    if (hashFile) {
                                        fclose(hashFile);
                                    }
                                    returnVal = 459;
                                    goto generate_hash_for_file_error;
                                //}
                            }
                        }
                        cbHash = MD5LEN;
                        if (CryptGetHashParam(hHashNew, HP_HASHVAL, rgbHash, &cbHash, 0)) {
                            _wfopen_s(&hashFileNew, DestFileofSingleHash, L"a");
                            fwprintf_s(hashFileNew, L"%ws\t%ws\t", wtextSource, fileType);
                            for (DWORD i = 0; i < cbHash; i++)
                            {
                                fwprintf_s(hashFileNew, L"%c%c", rgbDigits[rgbHash[i] >> 4], rgbDigits[rgbHash[i] & 0xf]);
                            }
                            fwprintf(hashFileNew ,L"\t");
                        }
                        else {
//                            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptGetHashParam failed Error: %d\n", GetLastError());
                            vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                            if (hashFileNew) {
                                fclose(hashFileNew);
                            }
                            if(sourceFile) {
                                fclose(sourceFile);
                            }
                            if(hHashNew){
                                CryptDestroyHash(hHashNew);
                            }
                            if(hHash){
                                CryptDestroyHash(hHash);
                            }
                            if(hProv) {
                                CryptReleaseContext(hProv, 0);
                            }
                            if(hashFile) {
                                fclose(hashFile);
                            }
                            returnVal = 463;
                            goto generate_hash_for_file_error;
                        }
                        if(sourceFile) {
                            fclose(sourceFile);
                        }
                        if(hHashNew){
                            CryptDestroyHash(hHashNew);
                        }
                        if(hHash){
                            CryptDestroyHash(hHash);
                        }
                        if(hProv) {
                            CryptReleaseContext(hProv, 0);
                        }
                    }else {
//                        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp unable open file. Error: %d\n", GetLastError());
                        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                        if(hHashNew){
                            CryptDestroyHash(hHashNew);
                        }
                        if(hHash){
                           CryptDestroyHash(hHash);
                        }
                        if(hProv) {
                            CryptReleaseContext(hProv, 0);
                        }
                        if (hashFile) {
                            fclose(hashFile);
                        }
                        returnVal = 458;
                        goto generate_hash_for_file_error;
                    }
                }else {
//                    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp SourceFileTemp NULL: \n");
                    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                    if(hHashNew){
                        CryptDestroyHash(hHashNew);
                    }
                    if(hHash){
                       CryptDestroyHash(hHash);
                    }
                    if(hProv) {
                        CryptReleaseContext(hProv, 0);
                    }
                    if (hashFile) {
                        fclose(hashFile);
                    }
                    returnVal = 458;
                    goto generate_hash_for_file_error;
                }
            }else {
//                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash for SingleHash failed Error: %d\n", GetLastError());
                vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                if(hHash){
                    CryptDestroyHash(hHash);
                }
                if(hProv) {
                    CryptReleaseContext(hProv, 0);
                }
                if (hashFile) {
                    fclose(hashFile);
                }
                returnVal = 461;
                goto generate_hash_for_file_error;
            }
        }else {
//            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash for MultiHash failed Error: %d\n", GetLastError());
            vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
            if(hProv) {
            	CryptReleaseContext(hProv, 0);
            }
        	if (hashFile) {
        		fclose(hashFile);
        	}
        	returnVal = 461;
            goto generate_hash_for_file_error;
        }
	}else {
//		healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptAcquireContext failed Error: %d\n", GetLastError());
    	vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
    	if (hashFile) {
    		fclose(hashFile);
    	}
    	returnVal = 460;
		goto generate_hash_for_file_error;
	}
	if (hashFile) {
		fclose(hashFile);
	}
	if(hashFileNew) {
	    fclose(hashFileNew);
	}
//	healthcheckLogger->log(NORMAL, L"HealthCheck.cpp generateHashforFileCombined Ended...\n");
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
    delete[] wtextDestofSingleHash;
    delete[] wtextSource;
    delete[] wtextDest;
    delete[] wtextindexFile;
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
	return 0;

	generate_hash_for_file_error:
	vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
    delete[] wtextDestofSingleHash;
    delete[] wtextSource;
    delete[] wtextDest;
    delete[] wtextindexFile;
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
    return returnVal;
}


int generateSingleHashandBlockbyBlockforIncrementalDisk(VMDataCollector* vmd,wchar_t* destFileDir, wchar_t* sourceFilePath, wchar_t* destFilePath, wchar_t* backupIdentifier,  wchar_t* hashType, wchar_t* fileType,bool isEncrypted, wchar_t* encryptPassword)
{
	vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk started for file->%ws %d\n",sourceFilePath,__LINE__);
	DWORD cbHash = 0;
    HCRYPTPROV hProv = 0;
    HCRYPTPROV hProv1 = 0;
    HCRYPTHASH hHash = 0;
    HCRYPTHASH hHashNew = 0;
    int returnVal = 0;
    FILE * hashFile;
    FILE * hashFileNew;
    BYTE rgbHash[MD5LEN];
    CHAR rgbDigits[] = "0123456789abcdef";
    BOOL readResult = FALSE;
    struct access *index = NULL;
	ULONG byteCountvalue;
	const char *lengthcstr;
    uint64 length;
	LONGLONG byteOffsetvalue;
	DWORD byteOffsetlowvalue;
	LONG byteOffsethighvalue;
    DWORD64 binFileOffsetvalue = 0;
    BYTE *buffer = NULL;
    DWORD bytesread;
    FILE* sourceFile;
    wchar_t* wtextSource;
    if(isEncrypted){
        wtextSource = new wchar_t[wcslen(sourceFilePath) + 13];
        wcscpy(wtextSource, sourceFilePath);
        wcscat(wtextSource, L".vmdk_secure");
        //wcscat(wtextSource, L"\0");
    }else{
        wtextSource = new wchar_t[wcslen(sourceFilePath) + 6];
        wcscpy(wtextSource, sourceFilePath);
        wcscat(wtextSource, L".vmdk");
        //wcscat(wtextSource, L"\0");
    }
    wcscat(wtextSource, L"\0");
    wchar_t* wtextindexFile = new wchar_t[wcslen(destFilePath)+ wcslen(L".idx") + 1];
    wcscpy(wtextindexFile, destFilePath);
    wcscat(wtextindexFile, L".idx");
    wcscat(wtextindexFile, L"\0");
    wchar_t* wtextDest = new wchar_t[wcslen(destFilePath) + wcslen(backupIdentifier) + wcslen(hashType) + wcslen(L".txt") + 3];
    wcscpy(wtextDest, destFilePath);
    wcscat(wtextDest, L"_");
    wcscat(wtextDest, backupIdentifier);
    wcscat(wtextDest, L"_");
    wcscat(wtextDest, hashType);
    wcscat(wtextDest, L".txt");
    wcscat(wtextDest, L"\0");
    LPTSTR DestFile = wtextDest;
//healthcheckLogger->log(NORMAL, L"HealthCheck.cpp 0001-----------");
    wchar_t* wtextDestofSingleHash = new wchar_t[wcslen(destFileDir) + wcslen(backupIdentifier) + wcslen(hashType) +  wcslen(L"_single.txt") + 2];
    wcscpy(wtextDestofSingleHash, destFileDir);
    wcscat(wtextDestofSingleHash, L"\\");
    wcscat(wtextDestofSingleHash, backupIdentifier);
    wcscat(wtextDestofSingleHash, L"_");
    wcscat(wtextDestofSingleHash, hashType);
    wcscat(wtextDestofSingleHash, L"_single.txt");
    wcscat(wtextDestofSingleHash, L"\0");
    LPTSTR DestFileofSingleHash = wtextDestofSingleHash;
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk wtextDestofSingleHash->%ws\n",wtextDestofSingleHash);
    int indexCreationResult;
    if (!PathFileExists(wtextindexFile)){
        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n", __LINE__);
        if(isEncrypted){
            indexCreationResult = vmd->indexCreation(wtextSource, true, encryptPassword);
        }else{
            indexCreationResult = vmd->indexCreation(wtextSource, false, NULL);
        }
        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk indexCreationResult %d at %d\n",indexCreationResult, __LINE__);
        if(indexCreationResult){//index not generated
            return 444;
        }
    }else if(wcscmp(hashType,L"backuphash")){ // if hashType is healthcheck, NOT backuphash
        wchar_t* wtextBackupSingleHash = new wchar_t[wcslen(destFileDir) + wcslen(backupIdentifier) + wcslen(L"backuphash") +  wcslen(L"_single.txt") + 3];
        wcscpy(wtextBackupSingleHash, destFileDir);
        wcscat(wtextBackupSingleHash, L"\\");
        wcscat(wtextBackupSingleHash, backupIdentifier);
        wcscat(wtextBackupSingleHash, L"_");
        wcscat(wtextBackupSingleHash, L"backuphash");
        wcscat(wtextBackupSingleHash, L"_single.txt");
        wcscat(wtextBackupSingleHash, L"\0");
        if(isIdxCorrupted(wtextindexFile,wtextBackupSingleHash,wtextDestofSingleHash,destFileDir )){
            vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk isIdxCorrupted returned TRUE. Generating hash again");
            if(isEncrypted){
                indexCreationResult = vmd->indexCreation(wtextSource, true, encryptPassword);
            }else{
                indexCreationResult = vmd->indexCreation(wtextSource, false, NULL);
            }
            vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk indexCreationResult %d at %d\n",indexCreationResult, __LINE__);
            if(indexCreationResult){//index not generated
                return 444;
            }
        }
    }
    wcscat(wtextSource, L"\0");
    LPCWSTR LsourceFile = wtextSource;
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk wtextSource->%ws\n",wtextSource);
    //getting incremental details
    wchar_t* incrementaltxtFile = new wchar_t[wcslen(sourceFilePath) + 30];
    wcscpy(incrementaltxtFile, sourceFilePath);
    wcscat(incrementaltxtFile, L".vmdk__incrementalDetails.txt");
    wcscat(incrementaltxtFile, L"\0");
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk incrementaltxtFile->%ws\n",incrementaltxtFile);
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk wcslen(sourceFilePath) %d\n",wcslen(sourceFilePath));
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk wcslen(incrementaltxtFile) %d\n",wcslen(incrementaltxtFile));
    char* charPath = new char[wcslen(sourceFilePath) + 30];
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk strlen(charPath) %d\n",strlen(charPath));
    wcstombs(charPath, incrementaltxtFile, wcslen(sourceFilePath) + 30);
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk strlen(charPath) %d\n",strlen(charPath));
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk (charPath) %s\n",charPath);
    jclass backupServerUtilClass = vmd->env->FindClass("com/manageengine/rmp/virtual/backup/VirtualBackupServerUtil");
    jmethodID loadIncMethodId = vmd->env->GetStaticMethodID(backupServerUtilClass, "loadIncBackupDetails", "(Ljava/lang/String;)Ljava/util/ArrayList;");
    jstring path = vmd->env->NewStringUTF(charPath);
    jobject incrementalArrayList = vmd->env->CallStaticObjectMethod(backupServerUtilClass, loadIncMethodId, path);
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk %d ",__LINE__);
    delete[] charPath;
    delete[] incrementaltxtFile;
    jobject incDetailsObject;
    jstring jlength;
    jstring joffset;
    char* ptr;
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk %d ",__LINE__);
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk listSizeID %d ",listSizeID);
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk %d ",__LINE__);
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk incrementalArrayList %d ",incrementalArrayList);
    int incrementalArrayListSize = (jint)vmd->env->CallIntMethod(incrementalArrayList, listSizeID);
    //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp 0000-----------");
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk %d ",__LINE__);
//healthcheckLogger->log(NORMAL, L"HealthCheck.cpp 0002-----------");
    _wfopen_s(&hashFile, DestFile, L"w");
    if (!hashFile) {
        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk _wfopen_s error %d...\n", GetLastError());
        returnVal =  464;
        goto generate_hash_for_file_error;
    }
    // Get handle to the crypto provider

    if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
        if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
            if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHashNew)) {
//            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp 0005-----------");
                    int sourceFiletemp = _wopen(LsourceFile, _O_RDONLY | _O_BINARY);
                    if(sourceFiletemp == -1){
                        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                        if(hHashNew){
                            CryptDestroyHash(hHashNew);
                        }
                        if(hHash){
                           CryptDestroyHash(hHash);
                        }
                        if(hProv) {
                            CryptReleaseContext(hProv, 0);
                        }
                        if (hashFile) {
                            fclose(hashFile);
                        }
                        returnVal =  464; //check for value
                        goto generate_hash_for_file_error;
                    }
                    index = vmd->getIndexforFile(index, wtextindexFile);
                    sourceFile = fdopen(sourceFiletemp, "rb");
                    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
                    //HANDLE hFile = CreateFile(wtextSource, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
//            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp 0006-----------");
                    if (sourceFile) {
                    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
                        for (int i = 0; i < incrementalArrayListSize; i++)
                        {
                            incDetailsObject = vmd->env->CallObjectMethod(incrementalArrayList, listGetID, (jint)i);
                            joffset = (jstring)vmd->env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, vmd->env->NewStringUTF("OFFSET"));
                            jlength = (jstring)vmd->env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, vmd->env->NewStringUTF("LENGTH"));
                            lengthcstr = vmd->env->GetStringUTFChars(jlength, 0);
                            length = _strtoui64(lengthcstr, NULL, 0);
                         //   vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk length: %d for i: %d \n",length,i);
                            buffer = new BYTE[length];
                            if(isEncrypted){
                                //vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk buffer : %d\n",buffer);
                                //vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk sourceFile : %d index :%d  binFileOffsetvalue : %d length : %d encryptPassword %ws\n",sourceFile,index,binFileOffsetvalue,length,encryptPassword);
                                bytesread = extractDecrypt(sourceFile, index, binFileOffsetvalue, buffer, length, encryptPassword);
                            }else{
                                //bytesread = gzread(sourceFile, buffer, BUFSIZE);
                                bytesread = extract(sourceFile, index, binFileOffsetvalue, buffer, length);
                               // vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk bytesread : %d\n",bytesread);
                            }
                            //readResult = ReadFile(hFile, buffer, length, &bytesread, NULL);
//                            if(readResult) {
                                if(bytesread == 0) {
                                    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
                                     delete[] buffer;
                                     break;
                                }else if((int)bytesread > 0) {
                                  //  vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk bytesread : %d %d\n",bytesread,__LINE__);
                                  //  vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk hHashNew : %d %d\n",hHashNew,__LINE__);
                                    if (CryptHashData(hHash, buffer, bytesread, 0)) {
                                        if (CryptHashData(hHashNew, buffer, bytesread, 0)) {
                                            cbHash = MD5LEN;
                                            if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0)) {
                                                fwprintf_s(hashFile, L"%lld\t", binFileOffsetvalue);
                                                for (DWORD i = 0; i < cbHash; i++)
                                                {
                                                    fwprintf_s(hashFile, L"%c%c", rgbDigits[rgbHash[i] >> 4], rgbDigits[rgbHash[i] & 0xf]);
                                                }
                                                fwprintf(hashFile ,L"\t");
                                            }
                                            else {
                                                if(sourceFile) {
                                                    fclose(sourceFile);
                                                }
                                                vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                                                if(hHashNew){
                                                    CryptDestroyHash(hHashNew);
                                                }
                                                if(hHash){
                                                    CryptDestroyHash(hHash);
                                                }
                                                if(hProv) {
                                                    CryptReleaseContext(hProv, 0);
                                                }
                                                if (hashFile) {
                                                    fclose(hashFile);
                                                }
                                                delete[] buffer;
                                                vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
                                                returnVal =  463;
                                                goto generate_hash_for_file_error;
                                            }
                                            if(hHash){
                                                CryptDestroyHash(hHash);
                                            }
                                            if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
//                                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash for failed Error: %d\n", GetLastError());
//                                                if(hFile){
//                                                    CloseHandle(hFile);
//                                                }
                                                if(sourceFile) {
                                                    fclose(sourceFile);
                                                }
                                                vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                                                if(hHashNew){
                                                    CryptDestroyHash(hHashNew);
                                                }
                                                if (hashFile) {
                                                    fclose(hashFile);
                                                }
                                                if(hProv) {
                                                    CryptReleaseContext(hProv, 0);
                                                }
                                                vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
                                                returnVal =  461;
                                                goto generate_hash_for_file_error;
                                            }
                                        }else {
//                                            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptHashData failed Error: %d\n", GetLastError());
//                                            if(hFile){
//                                                CloseHandle(hFile);
//                                            }
                                            if(sourceFile) {
                                                fclose(sourceFile);
                                            }
                                            vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                                            if(hHashNew){
                                                CryptDestroyHash(hHashNew);
                                            }
                                            if(hHash){
                                                CryptDestroyHash(hHash);
                                            }
                                            if(hProv) {
                                                CryptReleaseContext(hProv, 0);
                                            }
                                            if (hashFile) {
                                                fclose(hashFile);
                                            }
                                            delete[] buffer;
                                            vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
                                            returnVal =  462;
                                            goto generate_hash_for_file_error;
                                        }
                                    }else {
//                                        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptHashData failed Error: %d\n", GetLastError());
//                                        if(hFile){
//                                            CloseHandle(hFile);
//                                        }
                                        if(sourceFile) {
                                            fclose(sourceFile);
                                        }
                                        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                                        if(hHashNew){
                                            CryptDestroyHash(hHashNew);
                                        }
                                        if(hHash){
                                            CryptDestroyHash(hHash);
                                        }
                                        if(hProv) {
                                            CryptReleaseContext(hProv, 0);
                                        }
                                        if (hashFile) {
                                            fclose(hashFile);
                                        }
                                        delete[] buffer;
                                        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
                                        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk GetLastError %d\n",GetLastError());
                                        returnVal =  462;
                                        goto generate_hash_for_file_error;
                                    }
                                }else{
                                    //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Reading Backup File failed Error: %d\n", GetLastError());
                                    //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Failed at offset : %lld : %lld\n", itr * BUFSIZETOHASH, offset);
                                    if(wcscmp(hashType, L"healthcheckhash") == 0) {
                                            //tRead = 0;
                                            fwprintf_s(hashFile, L"%lld\t%ws\t", binFileOffsetvalue, L"00000000000000000000000000000000");
                                            binFileOffsetvalue = binFileOffsetvalue + length;
                                            continue;
                                    }
                                        if(sourceFile) {
                                            fclose(sourceFile);
                                        }
                                        if(hHashNew){
                                            CryptDestroyHash(hHashNew);
                                        }
                                        if(hHash){
                                            CryptDestroyHash(hHash);
                                        }
                                        if(hProv) {
                                            CryptReleaseContext(hProv, 0);
                                        }
                                        if (hashFile) {
                                            fclose(hashFile);
                                        }
                                        returnVal =  459;
                                        goto generate_hash_for_file_error;
                                }
                                 binFileOffsetvalue = binFileOffsetvalue + length;
                                 delete[] buffer;

                        }
                        cbHash = MD5LEN;
                        if (CryptGetHashParam(hHashNew, HP_HASHVAL, rgbHash, &cbHash, 0)) {
                            vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
                            _wfopen_s(&hashFileNew, DestFileofSingleHash, L"a");
                            fwprintf_s(hashFileNew, L"%ws\t%ws\t", wtextSource, fileType);
                            for (DWORD i = 0; i < cbHash; i++)
                            {
                                fwprintf_s(hashFileNew, L"%c%c", rgbDigits[rgbHash[i] >> 4], rgbDigits[rgbHash[i] & 0xf]);
                            }
                                fwprintf(hashFileNew ,L"\t");
                        }
                        else {
//                            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptGetHashParam failed Error: %d\n", GetLastError());
                            vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
                            if (hashFileNew) {
                                fclose(hashFileNew);
                            }
//                            if(hFile){
//                                CloseHandle(hFile);
//                            }
                            if(sourceFile) {
                                fclose(sourceFile);
                            }
                            if(hHashNew){
                                CryptDestroyHash(hHashNew);
                            }
                            if(hHash){
                                CryptDestroyHash(hHash);
                            }
                            if(hProv) {
                                CryptReleaseContext(hProv, 0);
                            }
                            if (hashFile) {
                                fclose(hashFile);
                            }
                            vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
                            returnVal =  463;
                            goto generate_hash_for_file_error;
                        }
//                        if(hFile){
//                            CloseHandle(hFile);
//                        }
                        //vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;

                        if(sourceFile) {
                            fclose(sourceFile);
                        }
                        if(hHashNew){
                            CryptDestroyHash(hHashNew);
                        }
                        if(hHash){
                            CryptDestroyHash(hHash);
                        }
                        if(hProv) {
                            CryptReleaseContext(hProv, 0);
                        }
                    }else {
//                        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp  Opening file Error: %d\n", GetLastError());
                        if(hHashNew){
                            CryptDestroyHash(hHashNew);
                        }
                        if(hHash){
                            CryptDestroyHash(hHash);
                        }
                        if(hProv) {
                            CryptReleaseContext(hProv, 0);
                        }
                        if (hashFile) {
                            fclose(hashFile);
                        }
                        vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
                        returnVal =  458;
                        goto generate_hash_for_file_error;
                    }
            }else {
//                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash for SingleHash failed Error: %d\n", GetLastError());
                if(hHash){
                    CryptDestroyHash(hHash);
                }
                if(hProv) {
                    CryptReleaseContext(hProv, 0);
                }
                if (hashFile) {
                    fclose(hashFile);
                }
                vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
                returnVal =  461;
                goto generate_hash_for_file_error;
            }
        }else {
//            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash for MultiHash failed Error: %d\n", GetLastError());
            if(hProv) {
            	CryptReleaseContext(hProv, 0);
            }
        	if (hashFile) {
        		fclose(hashFile);
        	}
        	vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
        	returnVal =  461;
            goto generate_hash_for_file_error;
        }
	}else {
//		healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptAcquireContext failed Error: %d\n", GetLastError());
		if (hashFile) {
    		fclose(hashFile);
    	}
    	vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
    	returnVal =  460;
		goto generate_hash_for_file_error;
	}
	if (hashFile) {
		fclose(hashFile);
	}
	if(hashFileNew) {
	    fclose(hashFileNew);
	}
	vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
//	healthcheckLogger->log(NORMAL, L"HealthCheck.cpp generateHashforBinFileCombined Ended...\n");
    delete[] wtextDestofSingleHash;
    delete[] wtextSource;
    delete[] wtextDest;
    vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
	return 0;

	generate_hash_for_file_error:
	vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockforIncrementalDisk  %d\n",__LINE__);
	delete[] wtextDestofSingleHash;
	delete[] wtextSource;
	delete[] wtextDest;
	vmd->log(vmd->env,1,"generateSingleHashandBlockbyBlockHashforDisk  %d\n", __LINE__); cout<<__LINE__<<endl;
	return returnVal;

}

int compareHashValues(VMDataCollector* vmd,wchar_t* backupIdentifier,jlong vmid,bool isvmdkSecured, wchar_t* repoPath, wchar_t* fileNameStr, wchar_t* backuphashFile, wchar_t* healthcheckhashFile, wchar_t* backupType, wchar_t* backupmetadata)
{
//    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp compareHashValues0 started for File->#%ws#%ws#%ws#%ws#%ws#%ws#%ws#...\n",vmName, scheduleName, fileNameStr, backuphashFile, healthcheckhashFile, backupType, backupmetadata);
    vmd->log(vmd->env, 1, "compareHashValues() fileNameStr %ws",fileNameStr);
    vmd->log(vmd->env, 1, "compareHashValues() backuphashFile %ws",backuphashFile);
    vmd->log(vmd->env, 1, "compareHashValues() healthcheckhashFile %ws",healthcheckhashFile);
    vmd->log(vmd->env, 1, "compareHashValues() backupType %ws",backupType);
    vmd->log(vmd->env, 1, "compareHashValues() backupmetadata %ws",backupmetadata);
    wchar_t* scheduleName;
    FILE* mFile;
    LONGLONG backuphashFilebyteOffsetvalue;
    LONGLONG healthcheckhashFileByteOffsetvalue;
    char backuphashFileHashvalue[33];
    char healthcheckhashFileHashvalue[33];

    jstring jlength;
    jstring joffset;
    jobject incDetailsObject;
    const char* offsetcstr;
    const char* lengthcstr;
    uint64 offset;
    uint64 length;
    ULONG byteCountvalue;
    LONGLONG byteOffsetvalue;
  	DWORD byteOffsetlowvalue;
    LONG byteOffsethighvalue;

    wchar_t* fileNamewithExtn ;
    jlong jbackupIdentifier = (jlong) _wtol(backupIdentifier);
    fileNamewithExtn = new  wchar_t[wcslen(fileNameStr)+wcslen(L".vmdk")+1];
    wcscpy(fileNamewithExtn,fileNameStr);
    wcscat(fileNamewithExtn,L".vmdk");
    wcscat(fileNamewithExtn,L"\0");
    vmd->log(vmd->env, 1, "compareHashValues() fileNamewithExtn %ws",fileNamewithExtn);
    jclass vmbackupServerclass = vmd->env->FindClass("com/manageengine/rmp/virtual/backup/VMBackupServer");
    cout<<vmbackupServerclass<<" "<<__LINE__<<endl;
    jmethodID getRootDiskMethodId = vmd->env->GetStaticMethodID(vmbackupServerclass, "getDiskID", "(JJLjava/lang/String;)Ljava/lang/String;");
    cout<<getRootDiskMethodId<<" "<<__LINE__<<endl;
    jstring jfileNamewithExtn = vmd->env->NewString((jchar*)fileNamewithExtn, wcslen(fileNamewithExtn));
    jstring diskId = (jstring)vmd->env->CallStaticObjectMethod(vmbackupServerclass, getRootDiskMethodId, jbackupIdentifier, vmid, jfileNamewithExtn);
    vmd->printJNI(diskId);
    LPWSTR ldiskId = (LPWSTR)(vmd->env)->GetStringChars( diskId, NULL);
    wstring wdiskId = ldiskId;
    DWORD noOfHashes = 0, corrupted = 0;

//    wchar_t* mFilePath = new wchar_t[wcslen(L"D:\\ManageEngine\\raji_backup_health\\RecoveryManagerPlus\\bin\\virtual_backup\\99999\\") + wcslen(scheduleName) + wcslen(vmName) + wcslen(fileNameStr) + wcslen(L"_healthcheck.txt") + 3];
//    wcscpy(mFilePath, L"D:\\ManageEngine\\raji_backup_health\\RecoveryManagerPlus\\bin\\virtual_backup\\99999\\");
    wchar_t* mFilePath = new wchar_t[wcslen(repoPath) + wcslen(wdiskId.c_str()) + wcslen(L"_healthcheck.txt") + 1];
    wcscpy(mFilePath, repoPath);
    wcscat(mFilePath, wdiskId.c_str());
    wcscat(mFilePath, L"_healthcheck.txt");
    wcscat(mFilePath, L"\0");
    vmd->log(vmd->env, 1, "compareHashValues() mFilePath %ws",mFilePath);

//    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp compareHashValues1 started for File->%ws...\n",mFilePath);
	_wfopen_s(&mFile, mFilePath, L"a");

	if(!mFile) {
//        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp unable open MetaData File: %d...\n",GetLastError());
        delete[] mFilePath;
        return 458;
	}
	ifstream backuphashFileIterator(backuphashFile);
    ifstream healthcheckhashFileIterator(healthcheckhashFile);
	if(wcscmp(backupType, L"FullBackup")==0) {
	    while(backuphashFileIterator >> backuphashFilebyteOffsetvalue >> backuphashFileHashvalue) {
            noOfHashes += 1;
	        ULARGE_INTEGER offsetValue;
	        offsetValue.QuadPart = backuphashFilebyteOffsetvalue;
	        if(healthcheckhashFileIterator >> healthcheckhashFileByteOffsetvalue >> healthcheckhashFileHashvalue) {
	            if(strcmp(backuphashFileHashvalue, healthcheckhashFileHashvalue) != 0){
	                fwprintf_s(mFile, L"%lu\t%I64d\t", BUFSIZETOHASH, backuphashFilebyteOffsetvalue);
	                corrupted += 1;
	                vmd->log(vmd->env, 1, "compareHashValues() 1  %d",__LINE__);
	            }
	        }else {
	            fwprintf_s(mFile, L"%lu\t%I64d\t", BUFSIZETOHASH, backuphashFilebyteOffsetvalue);
	            corrupted += 1;
                vmd->log(vmd->env, 1, "compareHashValues() 2 %d",__LINE__);
	            break;
	        }
	    }
	    while(backuphashFileIterator>>backuphashFilebyteOffsetvalue>>backuphashFileHashvalue) {
	        noOfHashes += 1;
	        ULARGE_INTEGER offsetValue;
	        offsetValue.QuadPart = backuphashFilebyteOffsetvalue;
	        fwprintf_s(mFile, L"%lu\t%I64d\t", BUFSIZETOHASH, backuphashFilebyteOffsetvalue);
	        corrupted += 1;
	        vmd->log(vmd->env, 1, "compareHashValues() 3 %d",__LINE__);
	    }
	    if(corrupted > noOfHashes/2) {
//	        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Corruption detected in More than Half of File.%d.%d..\n",noOfHashes, corrupted);
            backuphashFileIterator.close();
            healthcheckhashFileIterator.close();
            fclose(mFile);
	        return 1;
	    }
	}else {

	    //ifstream metaDataFileIterator(backupmetadata);
	    //if incrDetails.txt is corrupted can't fetch list. Check the case
//	    wchar_t* incrementaltxtFile = new wchar_t[wcslen(fileNameStr) + 30];
//        wcscpy(incrementaltxtFile, fileNameStr);
//        wcscat(incrementaltxtFile, L".vmdk__incrementalDetails.txt");
//        wcscat(incrementaltxtFile, L"\0");
         vmd->log(vmd->env, 1, "compareHashValues() wcslen(backupmetadata) %d",wcslen(backupmetadata));
         char* charPath = new char[wcslen(backupmetadata)*2];
         wcstombs(charPath, backupmetadata, wcslen(backupmetadata)*2);
         //strcat(charPath,"\0");
         vmd->log(vmd->env, 1, "compareHashValues() charPath %s",charPath);
         vmd->log(vmd->env, 1, "compareHashValues() strlen(charPath) %d",strlen(charPath));
         if (FILE* file = fopen(charPath, "r")) {
            fclose(file);
         }else{
            backuphashFileIterator.close();
            healthcheckhashFileIterator.close();
            fclose(mFile);
            delete[] charPath;
            delete[] mFilePath;
            vmd->log(vmd->env, 1, "compareHashValues() vmdk__incrementalDetails.txt not found. Hence returning 1");
            return 1;
         }
//        vmd->log(vmd->env, 1, "compareHashValues() incrementaltxtFile %ws",incrementaltxtFile);
//        char* charPath = new char[wcslen(fileNameStr) + 30];
//        wcstombs(charPath, incrementaltxtFile, wcslen(fileNameStr) + 30);
//        strcat(charPath,".vmdk__incrementalDetails.txt");
//        strcat(charPath,"\0");



        jclass backupServerUtilClass = vmd->env->FindClass("com/manageengine/rmp/virtual/backup/VirtualBackupServerUtil");
        jmethodID loadIncMethodId = vmd->env->GetStaticMethodID(backupServerUtilClass, "loadIncBackupDetails", "(Ljava/lang/String;)Ljava/util/ArrayList;");
        jstring path = vmd->env->NewStringUTF(charPath);
        jobject incrementalArrayList = vmd->env->CallStaticObjectMethod(backupServerUtilClass, loadIncMethodId, path);
        vmd->log(vmd->env, 1, "compareHashValues() %d",__LINE__);
      //  delete[] incrementaltxtFile;
        int incrementalArrayListSize = (jint)vmd->env->CallIntMethod(incrementalArrayList, listSizeID);
        vmd->log(vmd->env, 1, "compareHashValues() incrementalArrayListSize %d",incrementalArrayListSize);
        int i = 0;
        vmd->log(vmd->env, 1, "compareHashValues() %d",__LINE__);



        while(backuphashFileIterator >> backuphashFilebyteOffsetvalue >> backuphashFileHashvalue) {
            vmd->log(vmd->env, 1, "compareHashValues() %d",__LINE__);
            //if(metaDataFileIterator >> byteCountvalue >> byteOffsetvalue >> byteOffsetlowvalue >> byteOffsethighvalue) {
            if(i<incrementalArrayListSize) {
                incDetailsObject = vmd->env->CallObjectMethod(incrementalArrayList, listGetID, (jint)i);
                joffset = (jstring)vmd->env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, vmd->env->NewStringUTF("OFFSET"));
                jlength = (jstring)vmd->env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, vmd->env->NewStringUTF("LENGTH"));
                lengthcstr = vmd->env->GetStringUTFChars(jlength, 0);
                length = _strtoui64(lengthcstr, NULL, 0);
                offsetcstr = vmd->env->GetStringUTFChars(joffset, 0);
                offset = _strtoui64(offsetcstr, NULL, 0);
                if(healthcheckhashFileIterator >> healthcheckhashFileByteOffsetvalue >> healthcheckhashFileHashvalue) {
                    if(strcmp(backuphashFileHashvalue, healthcheckhashFileHashvalue) != 0){
                        vmd->log(vmd->env, 1, "compareHashValues()  %d   %d",__LINE__,i);
                        fwprintf_s(mFile, L"%I64d\t%I64d\t", length, offset);  //check the format specifier
                    }
                }else {
//                    fwprintf_s(mFile, L"%lu\t%I64d\t%lu\t%ld\t", byteCountvalue, byteOffsetvalue, byteOffsetlowvalue, byteOffsethighvalue);
                      fwprintf_s(mFile, L"%I64d\t%I64d\t", length, offset);
                      vmd->log(vmd->env, 1, "compareHashValues()  %d",__LINE__);
                      i++;
                    break;
                }
                vmd->log(vmd->env, 1, "compareHashValues()  %d   %d",__LINE__,i);
                i++;
            }else {
                vmd->log(vmd->env, 1, "compareHashValues() data missing in MetaData File %d",__LINE__);
                backuphashFileIterator.close();
                healthcheckhashFileIterator.close();
                fclose(mFile);
                delete[] charPath;
                delete[] mFilePath;
                return 1;
            }
	    }
	    //delete these lines
//	    backuphashFileIterator.close();
//        healthcheckhashFileIterator.close();
//        fclose(mFile);
//	    return 0;
	    vmd->log(vmd->env, 1, "compareHashValues() %d   %d",__LINE__,i);
	    while(backuphashFileIterator>>backuphashFilebyteOffsetvalue>>backuphashFileHashvalue) {
	        //if(metaDataFileIterator >> byteCountvalue >> byteOffsetvalue >> byteOffsetlowvalue >> byteOffsethighvalue) {
	        if(i<incrementalArrayListSize) {
	            vmd->log(vmd->env, 1, "compareHashValues() %d   %d",__LINE__,i);
	            incDetailsObject = vmd->env->CallObjectMethod(incrementalArrayList, listGetID, (jint)i);
                joffset = (jstring)vmd->env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, vmd->env->NewStringUTF("OFFSET"));
                jlength = (jstring)vmd->env->CallObjectMethod(incDetailsObject, jMtdGetHashtable, vmd->env->NewStringUTF("LENGTH"));
                lengthcstr = vmd->env->GetStringUTFChars(jlength, 0);
                length = _strtoui64(lengthcstr, NULL, 0);
                offsetcstr = vmd->env->GetStringUTFChars(joffset, 0);
                offset = _strtoui64(offsetcstr, NULL, 0);
	            fwprintf_s(mFile, L"%I64d\t%I64d\t", length, offset);
	            i++;
	        }else {
	            vmd->log(vmd->env, 1, "compareHashValues() %d   %d",__LINE__,i);
//                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp data missing in MetaData File...\n");
              //  metaDataFileIterator.close();
                backuphashFileIterator.close();
                healthcheckhashFileIterator.close();
                fclose(mFile);
                delete[] charPath;
                delete[] mFilePath;
                return 1;
	        }
	    }
	    delete[] charPath;
	   // metaDataFileIterator.close();D:\ManageEngine\raji_backup_health\RecoveryManagerPlus\bin\virtual_backup\99999\1501\1501
	}
    backuphashFileIterator.close();
    healthcheckhashFileIterator.close();
    fclose(mFile);
    delete[] mFilePath;
//    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp compareHashValues ended......\n");
    vmd->log(vmd->env, 1, "compareHashValues() %d ",__LINE__);
    return 0;

}

int checkHash(VMDataCollector* vmd,wchar_t* destFilesDir,wchar_t* repoPath, wchar_t* vmName, wchar_t* backupIdentifier,jlong vmid, wchar_t* backupType,bool isEncrypted, LPWSTR encryptPassword)
{
    vmd->log(vmd->env,1,"checkHash  started %d", __LINE__);
    vmd->log(vmd->env,1,"checkHash  destFilesDir %ws", destFilesDir);
    vmd->log(vmd->env,1,"checkHash  backupIdentifier %ws", backupIdentifier);
    vmd->log(vmd->env,1,"checkHash  backupType %ws", backupType);
    vmd->log(vmd->env,1,"checkHash  repoPath %ws", repoPath);
    FILE * backuphashsingle;
    FILE * healthcheckhashsingle;
    int size = 1024, pos, c;
    DWORD retVal = 0;
    char *fileName; //= (char *)malloc(size);
    char *hashVal;// = (char *)malloc((MD5LEN*2)+1);
    char *fileType;// = (char *)malloc(10);

    std::vector<std::vector<char *>> hashDetailList;
	wchar_t* wtexthealthcheckhashsingle = new wchar_t[wcslen(destFilesDir) + wcslen(backupIdentifier) + wcslen(L"_healthcheckhash_single.txt") + 2];
	wcscpy(wtexthealthcheckhashsingle, destFilesDir);
	wcscat(wtexthealthcheckhashsingle, L"\\");
	wcscat(wtexthealthcheckhashsingle, backupIdentifier);
	wcscat(wtexthealthcheckhashsingle, L"_healthcheckhash_single.txt");
	wcscat(wtexthealthcheckhashsingle, L"\0");
    _wfopen_s(&healthcheckhashsingle, wtexthealthcheckhashsingle, L"rb");
    vmd->log(vmd->env,1,"checkHash  wtexthealthcheckhashsingle %ws", wtexthealthcheckhashsingle);
    if(healthcheckhashsingle) {
        vmd->log(vmd->env,1,"checkHash  started %d", __LINE__);
        while(1)
        {
            vmd->log(vmd->env,1,"checkHash  started %d", __LINE__);
            fileName = (char *)malloc(size);
            fileName[0] = '\0';
            hashVal = (char *)malloc((MD5LEN*2)+1);
            fileType = (char *)malloc(10);
            pos = 0;
            vmd->log(vmd->env,1,"checkHash  started %d", __LINE__);
            do
            {
                c = fgetc(healthcheckhashsingle);
                if (c != EOF && c != '\n' && c != '\t')
                {
                    fileName[pos++] = (char)c;
                }
                if (pos >= size - 1)
                {
                    size += 1024;
                    fileName = (char*)realloc(fileName, size);
                }
                if(c == EOF){
                    break;
                }
            }while (c != '\t');
            vmd->log(vmd->env,1,"checkHash  started %d", __LINE__);
            if (pos != 0)
            {
                fileName[pos++] = '\0';
            }
            pos = 0;
            vmd->log(vmd->env,1,"checkHash  started %d", __LINE__);
            do
            {
                c = fgetc(healthcheckhashsingle);
                if (c != EOF && c != '\n' && c != '\t')
                {
                    fileType[pos++] = (char)c;
                }
                if (pos >= size - 1)
                {
                    size += 32;
                    fileType = (char*)realloc(fileType, size);
                }
                if(c == EOF){
                    break;
                }
            }while (c != '\t');
            vmd->log(vmd->env,1,"checkHash  started %d", __LINE__);
            if (pos != 0)
            {
                fileType[pos++] = '\0';
            }
            pos = 0;
            vmd->log(vmd->env,1,"checkHash  started %d", __LINE__);
            do
            {
                c = fgetc(healthcheckhashsingle);
                if (c != EOF && c != '\n' && c != '\t')
                {
                    hashVal[pos++] = (char)c;
                }
                if (pos >= size - 1)
                {
                    size += 32;
                    hashVal = (char*)realloc(hashVal, size);
                }
                if(c == EOF){
                    break;
                }
            }while (c != '\t');
            vmd->log(vmd->env,1,"checkHash  started %d", __LINE__);
            if (pos != 0)
            {
                hashVal[pos++] = '\0';
            }
            if(strcmp(fileName,"\0")==0){
                break;
            }
            vmd->log(vmd->env,1,"checkHash  started %d", __LINE__);
            std::vector<char *> hashDetail;
            hashDetail.push_back(fileName);
            hashDetail.push_back(fileType);
            hashDetail.push_back(hashVal);
            hashDetailList.push_back(hashDetail);
            //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp healthcheckhashSingle Info...FileName:%S  Filetype:%S  HashVal:%S\n",fileName,fileType,hashVal);
            vmd->log(vmd->env,1,"checkHash  healthcheckhashSingle Info...FileName:%s  Filetype:%s  HashVal:%s\n",fileName,fileType,hashVal);
            c = fgetc(healthcheckhashsingle);
            if (c == EOF)
            {
                break;
            }
            else
            {
                fseek(healthcheckhashsingle, -1, SEEK_CUR);
            }
        }
	}else {
	    //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp unable open healthcheckhash File: %d...\n",GetLastError());
	    vmd->log(vmd->env,1,"checkHash unable open healthcheckhash File: %d",GetLastError());
	    return 458;
	}
	if(healthcheckhashsingle) {
        fclose(healthcheckhashsingle);
    }
//    if(hashDetailList.empty()) {
//	    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp No Backup Files are present...\n");
//	    return 3;
//    }
	wchar_t* wtextbackuphashsingle = new wchar_t[wcslen(destFilesDir) + wcslen(backupIdentifier) + wcslen(L"_backuphash_single.txt") + 2];
	wcscpy(wtextbackuphashsingle, destFilesDir);
	wcscat(wtextbackuphashsingle, L"\\");
	wcscat(wtextbackuphashsingle, backupIdentifier);
	wcscat(wtextbackuphashsingle, L"_backuphash_single.txt");
	wcscat(wtextbackuphashsingle, L"\0");
	vmd->log(vmd->env,1,"checkHash  wtextbackuphashsingle %ws", wtextbackuphashsingle);
    _wfopen_s(&backuphashsingle, wtextbackuphashsingle, L"rb");

    if(backuphashsingle) {
        while(1)
        {
            fileName = (char *)malloc(size);
            fileName[0] = '\0';
            hashVal = (char *)malloc((MD5LEN*2)+1);
            fileType = (char *)malloc(10);
            pos = 0;
            do
            {
                c = fgetc(backuphashsingle);
                if (c != EOF && c != '\n' && c != '\t')
                {
                    fileName[pos++] = (char)c;
                }
                if (pos >= size - 1)
                {
                    size += 1024;
                    fileName = (char*)realloc(fileName, size);
                }
                if(c == EOF){
                    break;
                }
            }while (c != '\t');
            if (pos != 0)
            {
                fileName[pos++] = '\0';
            }
            pos = 0;
            do
            {
                c = fgetc(backuphashsingle);
                if (c != EOF && c != '\n' && c != '\t')
                {
                    fileType[pos++] = (char)c;
                }
                if (pos >= size - 1)
                {
                    size += 32;
                    fileType = (char*)realloc(fileType, size);
                }
                if(c == EOF){
                    break;
                }
            }while (c != '\t');
            if (pos != 0)
            {
                fileType[pos++] = '\0';
            }
            pos = 0;
            do
            {
                c = fgetc(backuphashsingle);
                if (c != EOF && c != '\n' && c != '\t')
                {
                    hashVal[pos++] = (char)c;
                }
                if (pos >= size - 1)
                {
                    size += 32;
                    hashVal = (char*)realloc(hashVal, size);
                }
                if(c == EOF){
                    break;
                }
            }while (c != '\t');
            if (pos != 0)
            {
                hashVal[pos++] = '\0';
            }
            if(strcmp(fileName,"\0")==0){
                break;
            }
            string sfileName = fileName;
            wstring fileNamePathStr(sfileName.begin(), sfileName.end());
            wstring fileNameStr;
            bool isvmdkSecured = false;
            wchar_t* backupmetadata = L"-";
            vmd->log(vmd->env,1,"checkHash %ws %d\n", fileNamePathStr.c_str(), __LINE__);
            wstring tempFileNameStr = fileNamePathStr;
            vmd->log(vmd->env,1,"checkHash %ws %d\n", tempFileNameStr.c_str(), __LINE__);
            vmd->log(vmd->env,1,"checkHash %ws %d\n", fileNamePathStr.c_str(), __LINE__);

            if(wcscmp(backupType, L"IncrBackup")==0 && strcmp(fileType,"metadata") != 0) {
                if(isEncrypted){
                    wstring fileEnd = L"_secure";
                    /*      Test whether file name ends with _secure; To build correct __incrementalDetails.txt path    */
                    if(tempFileNameStr.length() >= fileEnd.length()){
                        if(tempFileNameStr.compare(tempFileNameStr.length() - fileEnd.length(), fileEnd.length(), fileEnd) == 0){
                            isvmdkSecured = true;
                            tempFileNameStr = tempFileNameStr.substr(0, tempFileNameStr.rfind(fileEnd));
                            vmd->log(vmd->env,1,"checkHash tempFileNameStr.c_str() %ws %d\n", tempFileNameStr.c_str(), __LINE__);
                        }
                    }
                }
                backupmetadata = new wchar_t[tempFileNameStr.length() + wcslen(L"__incrementalDetails.txt") + 1];
                wcscpy(backupmetadata, tempFileNameStr.c_str());
                wcscat(backupmetadata, L"__incrementalDetails.txt");
                wcscat(backupmetadata, L"\0");
                vmd->log(vmd->env,1,"checkHash %d\n",  __LINE__);
            }
            vmd->log(vmd->env,1,"checkHash %ws %d\n", tempFileNameStr.c_str(), __LINE__);
            vmd->log(vmd->env,1,"checkHash %ws %d\n", fileNamePathStr.c_str(), __LINE__);
            fileNamePathStr = fileNamePathStr.substr(0, fileNamePathStr.rfind(L"."));
            fileNameStr = fileNamePathStr;
            vmd->log(vmd->env,1,"checkHash %ws %d\n", fileNamePathStr.c_str(), __LINE__);
            vmd->log(vmd->env,1,"checkHash %ws %d\n", fileNameStr.c_str(), __LINE__);
            fileNameStr = fileNameStr.substr(fileNameStr.rfind(L"\\") + 1);
            wchar_t* fileNameNoExten = new wchar_t[fileNameStr.length() + 1];
            wcscpy(fileNameNoExten, fileNameStr.c_str());
            wcscat(fileNameNoExten, L"\0");
            vmd->log(vmd->env,1,"checkHash fileNameNoExten %ws %d", fileNameNoExten, __LINE__);

            wchar_t* backuphashFile = new wchar_t[fileNamePathStr.length() + wcslen(backupIdentifier) + wcslen(L"_backuphash.txt") + 2];
            wcscpy(backuphashFile, fileNamePathStr.c_str());
            wcscat(backuphashFile, L"_");
            wcscat(backuphashFile, backupIdentifier);
            wcscat(backuphashFile, L"_backuphash.txt");
            wcscat(backuphashFile, L"\0");
            vmd->log(vmd->env,1,"checkHash %ws %d\n", backuphashFile, __LINE__);
            wchar_t* healthcheckhashFile = new wchar_t[fileNamePathStr.length() + wcslen(backupIdentifier) + wcslen(L"_healthcheckhash.txt") + 2];
            wcscpy(healthcheckhashFile, fileNamePathStr.c_str());
            wcscat(healthcheckhashFile, L"_");
            wcscat(healthcheckhashFile, backupIdentifier);
            wcscat(healthcheckhashFile, L"_healthcheckhash.txt");
            wcscat(healthcheckhashFile, L"\0");
            vmd->log(vmd->env,1,"checkHash %ws %d\n", healthcheckhashFile, __LINE__);
            //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp backuphashSingle Info...FileName:%S  Filetype:%S  HashVal:%S\n",fileName,fileType,hashVal);
          //  vmd->log(vmd->env,1,"checkHash backuphashSingle Info...FileName:%S  Filetype:%S  HashVal:%S",fileName,fileType,hashVal);
            vmd->log(vmd->env,1,"checkHash  %d\n", __LINE__);
            //hashDetailList contains hashValues at Healthcheck operation
            if(hashDetailList.empty())
            {
                vmd->log(vmd->env,1,"checkHash  %d\n", __LINE__);
                if(strcmp(fileType, "vmdkInc") == 0) {
                    vmd->log(vmd->env,1,"checkHash calling compareHashValues from %d\n", __LINE__);
                    retVal = compareHashValues(vmd, backupIdentifier,vmid,isvmdkSecured, repoPath, fileNameNoExten, backuphashFile, healthcheckhashFile, backupType, backupmetadata);
                   vmd->log(vmd->env,1,"checkHash compareHashValues return value %d",retVal);
                    if(retVal != 0) {
                    	if(backuphashsingle) {
                            fclose(backuphashsingle);
                        }
                        return retVal;
                    }
                    retVal = 2;
                }else if(strcmp(fileType, "idx") == 0){
                    int indexCreationResult = 1;
                    vmd->log(vmd->env,1,"checkHash %ws %d\n", fileNamePathStr.c_str(), __LINE__);
                    int fd = _wopen((fileNamePathStr+L".idx").c_str(), _O_RDONLY | _O_BINARY);
                    if(fd == -1){// index not generated even at the time of disk hash generating
                        wstring vmdkFileName = fileNamePathStr + L".vmdk";
                        int fd = _wopen(vmdkFileName.c_str(), _O_RDONLY | _O_BINARY);
                        if(fd == -1){ // disk is secured
                             vmdkFileName = vmdkFileName + L"_secure";
                             vmd->log(vmd->env,1,"checkHash %ws %d\n", vmdkFileName.c_str(), __LINE__);
                             indexCreationResult = vmd->indexCreation(vmdkFileName, true, encryptPassword);
                             vmd->log(vmd->env, 1, "indexCreationResult : %d", indexCreationResult);
                        }else{
                            vmd->log(vmd->env,1,"checkHash %ws %d\n", vmdkFileName.c_str(), __LINE__);
                             indexCreationResult = vmd->indexCreation(vmdkFileName, false, NULL);
                             vmd->log(vmd->env, 1, "indexCreationResult : %d", indexCreationResult);
                        }
                    }else{// index generated at the time of disk hash generating
                        indexCreationResult = 0;
                    }
                    if(indexCreationResult){ // index creation failed
                        if(backuphashsingle) {
                            fclose(backuphashsingle);
                        }
                        return 1;
                    }else{
                        int returnVal = generateHashforFile(vmd,(wchar_t*)(fileNamePathStr+L".idx").c_str(),destFilesDir, backupIdentifier, L"healthcheckhash", L"True", L"a", L"idx");
                        if(returnVal){
                            if(backuphashsingle) {
                                fclose(backuphashsingle);
                            }
                            return 444;
                        }
                    }
                }else {
                    //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Missing of File: %S...\n",fileName);
                    vmd->log(vmd->env,1,"checkHash  %d\n", __LINE__);
                    vmd->log(vmd->env,1,"checkHash missing MetaData File: %s",fileName);
                    if(backuphashsingle) {
                        fclose(backuphashsingle);
                    }
                    return 1;
                }
            }
            vmd->log(vmd->env,1,"checkHash  %d\n", __LINE__);
            for(int i = 0; i < hashDetailList.size(); i++) {
                if(strcmp(hashDetailList[i][0], fileName) == 0) {
                    if(strcmp(hashDetailList[i][2], hashVal) == 0) {
                        hashDetailList.erase(hashDetailList.begin()+i);
                        vmd->log(vmd->env,1,"checkHash  %d\n", __LINE__);
                        break;
                    }else{
                        if(strcmp(fileType, "metadata") == 0 || strcmp(fileType, "xml") == 0) {
                            //healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Couruption in MetaData File: %S...\n",fileName);
                            vmd->log(vmd->env,1,"checkHash Couruption in MetaData File: %s",fileName);
                            if(backuphashsingle) {
                                fclose(backuphashsingle);
                            }
                            return 1;
                        }else if(strcmp(fileType, "idx") == 0){
                             int indexCreationResult;
                             //size_t pos = fileName.rfind(L".");
                             vmd->log(vmd->env,1,"checkHash %ws %d\n", fileNamePathStr.c_str(), __LINE__);
                             wstring vmdkFileName = fileNamePathStr + L".vmdk";
                             int fd = _wopen(vmdkFileName.c_str(), _O_RDONLY | _O_BINARY);
                             if(fd == -1){ // disk is secured
                                  vmdkFileName = vmdkFileName + L"_secure";
                                  vmd->log(vmd->env,1,"checkHash %ws %d\n", vmdkFileName.c_str(), __LINE__);
                                  indexCreationResult = vmd->indexCreation(vmdkFileName, true, encryptPassword);
                                  vmd->log(vmd->env, 1, "indexCreationResult : %d at %d", indexCreationResult, __LINE__);
                             }else{
                                 vmd->log(vmd->env,1,"checkHash %ws %d\n", vmdkFileName.c_str(), __LINE__);
                                  indexCreationResult = vmd->indexCreation(vmdkFileName, false, NULL);
                                  vmd->log(vmd->env, 1, "indexCreationResult : %d at %d", indexCreationResult, __LINE__);
                             }
                             if(indexCreationResult){
                                if(backuphashsingle) {
                                    fclose(backuphashsingle);
                                }
                                 return 1;
                             }
                         }
                        vmd->log(vmd->env,1,"checkHash calling compareHashValues from %d\n", __LINE__);
                        retVal =  compareHashValues(vmd, backupIdentifier,vmid,isvmdkSecured, repoPath, fileNameNoExten, backuphashFile, healthcheckhashFile, backupType, backupmetadata); //  add fn and uncomment this
                        vmd->log(vmd->env,1,"checkHash retVal %d %d",retVal, __LINE__);
                        if(retVal != 0) {
                        	if(backuphashsingle) {
                                fclose(backuphashsingle);
                            }
                            return retVal;
                        }
                        retVal = 2;
                    }
                }else {
                    if(hashDetailList.size()-1 == i) {
                        if(strcmp(fileType, "vmdkInc") == 0) {
                        vmd->log(vmd->env,1,"checkHash calling compareHashValues from %d\n", __LINE__);
                            retVal = compareHashValues(vmd, backupIdentifier,vmid,isvmdkSecured, repoPath, fileNameNoExten, backuphashFile, healthcheckhashFile, backupType, backupmetadata);
                            vmd->log(vmd->env,1,"checkHash retVal %d %d",retVal, __LINE__);
                            if(retVal != 0) {
                            	if(backuphashsingle) {
                                    fclose(backuphashsingle);
                                }
                                return retVal;
                            }
                            retVal = 2;
                        }else if(strcmp(fileType, "idx") == 0){
                             int indexCreationResult = 1;
                             vmd->log(vmd->env,1,"checkHash %ws %d\n", fileNamePathStr.c_str(), __LINE__);
                             int fd = _wopen((fileNamePathStr+L".idx").c_str(), _O_RDONLY | _O_BINARY);
                             if(fd == -1){// index not generated even at the time of disk hash generating
                                 wstring vmdkFileName = fileNamePathStr + L".vmdk";
                                 int fd = _wopen(vmdkFileName.c_str(), _O_RDONLY | _O_BINARY);
                                 if(fd == -1){ // disk is secured
                                      vmdkFileName = vmdkFileName + L"_secure";
                                      vmd->log(vmd->env,1,"checkHash %ws %d\n", vmdkFileName.c_str(), __LINE__);
                                      indexCreationResult = vmd->indexCreation(vmdkFileName, true, encryptPassword);
                                      vmd->log(vmd->env, 1, "indexCreationResult : %d", indexCreationResult);
                                 }else{
                                     vmd->log(vmd->env,1,"checkHash %ws %d\n", vmdkFileName.c_str(), __LINE__);
                                      indexCreationResult = vmd->indexCreation(vmdkFileName, false, NULL);
                                      vmd->log(vmd->env, 1, "indexCreationResult : %d", indexCreationResult);
                                 }
                             }else{// index generated at the time of disk hash generating
                                 indexCreationResult = 0;
                             }
                             if(indexCreationResult){ // index creation failed
                                if(backuphashsingle) {
                                    fclose(backuphashsingle);
                                }
                                 return 1;
                             }else{
                                 int returnVal = generateHashforFile(vmd,(wchar_t*)(fileNamePathStr+L".idx").c_str(),destFilesDir, backupIdentifier, L"healthcheckhash", L"True", L"a", L"idx");
                                 if(returnVal){
                                    if(backuphashsingle) {
                                        fclose(backuphashsingle);
                                    }
                                     return 444;
                                 }
                             }
                         }else {
                            vmd->log(vmd->env,1,"checkHash  %d\n", __LINE__);
                            if(backuphashsingle) {
                                fclose(backuphashsingle);
                            }
                            return 1;
                        }
                    }
                }
            }
            c = fgetc(backuphashsingle);
            if (c == EOF)
            {
                break;
            }
            else
            {
                fseek(backuphashsingle, -1, SEEK_CUR);
            }
        }
	}else {
	    vmd->log(vmd->env,1,"checkHash  %d\n", __LINE__);
	    return 458;
	}
	if(backuphashsingle) {
        fclose(backuphashsingle);
    }
    delete[] wtextbackuphashsingle;
    delete[] wtexthealthcheckhashsingle;

    vmd->log(vmd->env,1,"checkHash  %d\n", __LINE__);
    return retVal;
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_virtual_VMNativeHandler_performHealthCheck(JNIEnv *env, jclass obj, jobject vmBackedUpDetailsList, jlong vmid, jlong backupId,jstring healtchCheckRepoPath, jthrowable exceptionObject){
    //wstring vmdkpath = L"F:\\ManageEngine\\raji_backup_health\\RecoveryManagerPlus\\bin\\virtual_backup\\9301\\[datastore1 1] raji multi disk_raji multi disk.vmdk_secure";
    VMDataCollector* vmd = new VMDataCollector(env, exceptionObject);
    vmd->log(vmd->env, 1, "Java_com_manageengine_rmp_virtual_VMNativeHandler_performHealthCheck() started");

//    int indexCreationResult = vmd->indexCreation(vmdkpath, true, L"l;'");
//    vmd->log(vmd->env, 1, "indexCreationResult : %d", indexCreationResult);
//    return 404;
    bool isFullBackup;
    jobject backupDetailsObj;
    jstring userName,password,repoPath,backupPath,backupType,backupIdentifier,encryptPassword,isEncrypted;
    int generateHashResult = 0, hcBkupType = 0, returnVal = 0;
    vmd->printJNI(healtchCheckRepoPath);
    LPWSTR lrepoPath = (LPWSTR)vmd->env->GetStringChars(healtchCheckRepoPath, NULL);
    wstring wrepoPath = lrepoPath;
    int numberOfBackups = (jint)env->CallIntMethod(vmBackedUpDetailsList, listSizeID);
    jclass ref = (jclass)env->FindClass("java/util/ArrayList");
    jmethodID listGetString = vmd->env->GetMethodID(ref, "toString", "()Ljava/lang/String;");
    jstring strinnng = (jstring)env->CallObjectMethod(vmBackedUpDetailsList, listGetString);
    vmd->printJNI(strinnng);
    for(int i=0; i<numberOfBackups; i++){
        backupDetailsObj = vmd->env->CallObjectMethod(vmBackedUpDetailsList, listGetID, (jint)i);
        userName = (jstring)env->CallObjectMethod(backupDetailsObj, jMtdGetHashtable, vmd->env->NewStringUTF("userName"));
        password = (jstring)env->CallObjectMethod(backupDetailsObj, jMtdGetHashtable, vmd->env->NewStringUTF("password"));
        repoPath = (jstring)env->CallObjectMethod(backupDetailsObj, jMtdGetHashtable, vmd->env->NewStringUTF("repoPath"));
        backupPath = (jstring)env->CallObjectMethod(backupDetailsObj, jMtdGetHashtable, vmd->env->NewStringUTF("BACKUP_PATH"));
        backupType = (jstring)env->CallObjectMethod(backupDetailsObj, jMtdGetHashtable, vmd->env->NewStringUTF("BACKUP_TYPE"));
        backupIdentifier = (jstring)env->CallObjectMethod(backupDetailsObj, jMtdGetHashtable, vmd->env->NewStringUTF("BACKUP_IDENTIFIER"));
        isEncrypted = (jstring)env->CallObjectMethod(backupDetailsObj, jMtdGetHashtable, vmd->env->NewStringUTF("IS_ENCRYPTED"));
        encryptPassword = (jstring)env->CallObjectMethod(backupDetailsObj, jMtdGetHashtable, vmd->env->NewStringUTF("ENCRYPT_PASSWORD"));
        LPWSTR backupTypeChar = (LPWSTR)(vmd->env)->GetStringChars( backupType, NULL);
        wstring wbackupTypeChar = backupTypeChar;

        if(wcscmp((wchar_t*)wbackupTypeChar.c_str(),L"FullBackup") == 0){
            isFullBackup = true;
            vmd->log(vmd->env, 1, "isFullBackup : true\n");
        }else{
            isFullBackup = false;
            vmd->log(vmd->env, 1, "isFullBackup : false\n");
        }
        vmd->printJNI(userName);
        vmd->printJNI(password);
        vmd->printJNI(repoPath);
        vmd->printJNI(backupPath);
        vmd->printJNI(backupType);
        vmd->printJNI(backupIdentifier);
        vmd->printJNI(encryptPassword);
        vmd->printJNI(isEncrypted);
      //  cout<<isFullBackup<<__LINE__<<endl;
        vmd->log(vmd->env, 1, "%d\n",__LINE__);
        const char *str = vmd->env->GetStringUTFChars(isEncrypted, NULL);
        bool isEncryptedBool = false;
        if(strcmp(str,"true") == 0){
            isEncryptedBool = true;
            vmd->log(vmd->env, 1, "isEncryptedBool : true\n");
        }else{
            vmd->log(vmd->env, 1, "isEncryptedBool : false\n");
        }
        (vmd->env)->ReleaseStringUTFChars( isEncrypted, str);
        LPWSTR lvmbackupPath = (LPWSTR)env->GetStringChars(backupPath, NULL);
        wstring vmbackupPath = lvmbackupPath;
        vmd->log(vmd->env, 1, "%d\n",__LINE__);

        generateHashResult = generateHashForFilesInDirectory(vmd,backupIdentifier,backupPath, isFullBackup, L"healthcheckhash",  isEncryptedBool, encryptPassword);
        vmd->log(vmd->env, 1, "%d\n",__LINE__);
        vmd->log(vmd->env, 1, "generateHashResult : %d",generateHashResult);
        if(generateHashResult) {
            if(hcBkupType) {
                hcBkupType = 1;
                returnVal = 0;
            }
            break;
        }
        LPWSTR lbackupIdentifier = (LPWSTR)env->GetStringChars(backupIdentifier, NULL);
        wstring wbackupIdentifier = lbackupIdentifier;



        cout<<"printing values"<<endl;
        wcout << vmbackupPath << wbackupIdentifier << wbackupTypeChar << endl;
        wcout << (wchar_t*)vmbackupPath.c_str() << (wchar_t*)wbackupIdentifier.c_str() << (wchar_t*)wbackupTypeChar.c_str() << endl;
        cout<<__LINE__<<endl;
        //need to change second and third argument
        LPWSTR lencryptPassword = (LPWSTR)env->GetStringChars(encryptPassword, NULL);
        returnVal = checkHash(vmd, (wchar_t*)vmbackupPath.c_str(), (wchar_t*)wrepoPath.c_str(), (wchar_t*)wbackupIdentifier.c_str(), (wchar_t*)wbackupIdentifier.c_str(),vmid, (wchar_t*)wbackupTypeChar.c_str(),isEncryptedBool,lencryptPassword);
        vmd->log(vmd->env, 1, "returnVal for checkHash : %d",returnVal);
        if(returnVal) {
             if(returnVal <= 2) {
                 if(hcBkupType == 0) {
                      jclass backupServerUtilClass = vmd->env->FindClass("com/manageengine/rmp/virtual/backup/VirtualBackupServerUtil");
                      jmethodID updateCorruptMethodId = vmd->env->GetStaticMethodID(backupServerUtilClass, "updateCorruptedBackupPoints", "(Ljava/lang/String;Ljava/lang/String;)V");
                      jclass stringClass = vmd->env->FindClass("java/lang/String");
                      jmethodID valueOfMethodId = vmd->env->GetStaticMethodID(stringClass,"valueOf","(J)Ljava/lang/String;");
                      jstring vmidString = (jstring) vmd->env->CallStaticObjectMethod(stringClass,valueOfMethodId,vmid);
                      vmd->printJNI(vmidString);
                      vmd->env->CallStaticObjectMethod(backupServerUtilClass, updateCorruptMethodId, backupIdentifier,vmidString);
                 }
                 hcBkupType = returnVal;
                 returnVal = 0;
                 if(hcBkupType == 1){
                     break;
                 }
             }else{
                 if(hcBkupType) {
                     hcBkupType = 1;
                     returnVal = 0;
                 }
                 break;
             }
        }

        (vmd->env)->ReleaseStringChars( backupPath, (jchar*)lvmbackupPath);
        (vmd->env)->ReleaseStringChars( backupType,(jchar*) backupTypeChar);
        (vmd->env)->ReleaseStringChars( backupIdentifier,(jchar*) lbackupIdentifier);
        vmd->log(vmd->env, 1, "%d\n",__LINE__);
        //break;
    }
      jclass backupServerUtilClass = vmd->env->FindClass("com/manageengine/rmp/virtual/backup/VirtualBackupServerUtil");
      jclass stringClass = vmd->env->FindClass("java/lang/String");
      jmethodID valueOfMethodId = vmd->env->GetStaticMethodID(stringClass,"valueOf","(J)Ljava/lang/String;");
      jstring vmidString = (jstring) vmd->env->CallStaticObjectMethod(stringClass,valueOfMethodId,vmid);
      jstring backupIdString = (jstring) vmd->env->CallStaticObjectMethod(stringClass,valueOfMethodId,backupId);
      vmd->printJNI(backupIdString);
      jmethodID updateHcBackupTypeMethodId = vmd->env->GetStaticMethodID(backupServerUtilClass, "updateHcBackupTypeofVM", "(Ljava/lang/String;Ljava/lang/String;I)V");
      vmd->env->CallStaticObjectMethod(backupServerUtilClass, updateHcBackupTypeMethodId, backupIdString,vmidString,(jint)hcBkupType);
    vmd->log(vmd->env, 1, "%d\n",__LINE__);
    return returnVal;
}

