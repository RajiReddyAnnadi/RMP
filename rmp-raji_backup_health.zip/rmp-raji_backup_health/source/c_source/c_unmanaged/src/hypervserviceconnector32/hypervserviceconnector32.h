

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 8.01.0622 */
/* at Tue Jan 19 08:44:07 2038
 */
/* Compiler settings for .\hypervserviceconnector32.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 8.01.0622 
    protocol : dce , ms_ext, app_config, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif /* __RPCNDR_H_VERSION__ */


#ifndef __hypervserviceconnector32_h__
#define __hypervserviceconnector32_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __hypervserviceconnector_INTERFACE_DEFINED__
#define __hypervserviceconnector_INTERFACE_DEFINED__

/* interface hypervserviceconnector */
/* [implicit_handle][version][uuid] */ 

int HyperVBackup( 
    /* [string][in] */ wchar_t *userName,
    /* [string][in] */ wchar_t *password,
    /* [string][in] */ wchar_t *hypervHostName,
    /* [string][in] */ wchar_t *fullbackupVMs,
    /* [string][in] */ wchar_t *incrementalbackupVMs,
    /* [string][in] */ wchar_t *repositoryPath,
    /* [string][in] */ wchar_t *backupName,
    /* [string][in] */ wchar_t *scheduleName,
    /* [string][in] */ wchar_t *repositoryDetailsJson,
    /* [string][in] */ wchar_t *isanyVHDchanged);

int HyperVdoCBToperationsforschedule( 
    /* [string][in] */ wchar_t *domainuserName,
    /* [string][in] */ wchar_t *password,
    /* [string][in] */ wchar_t *hypervHostName,
    /* [string][in] */ wchar_t *scheduleName,
    /* [string][in] */ wchar_t *allVMIds);

int HyperVRestore( 
    /* [string][in] */ wchar_t *domainuserName,
    /* [string][in] */ wchar_t *password,
    /* [string][in] */ wchar_t *hypervHostName,
    /* [string][in] */ wchar_t *vmtoRestore,
    /* [string][in] */ wchar_t *vmfullbackupPathstring,
    /* [string][in] */ wchar_t *vmincrementalbackupPathsList,
    /* [string][in] */ wchar_t *LischangeVMName,
    /* [string][in] */ wchar_t *LnewVMName,
    /* [string][in] */ wchar_t *LVHDnewstorageLocation,
    /* [string][in] */ wchar_t *repositoryDetailsJson,
    /* [string][in] */ wchar_t *isPowerOnstring,
    /* [string][in] */ wchar_t *isEncrypted,
    /* [string][in] */ wchar_t *encryptString,
    /* [string][in] */ wchar_t *vmid,
    /* [string][in] */ wchar_t *restoreid,
    /* [string][in] */ wchar_t *paramsjson,
    /* [string][in] */ wchar_t *restoreFormatString);

int HyperVinstallandstartDriver( 
    /* [string][in] */ wchar_t *domainuserName,
    /* [string][in] */ wchar_t *password,
    /* [string][in] */ wchar_t *hypervHostName,
    /* [string][in] */ wchar_t *isInstallstring);

int copyVMfilesfromVSSSnapshot( 
    /* [string][in] */ wchar_t *domainuserName,
    /* [string][in] */ wchar_t *password,
    /* [string][in] */ wchar_t *hypervHostName,
    /* [string][in] */ wchar_t *vmName,
    /* [string][in] */ wchar_t *backupType,
    /* [string][in] */ wchar_t *lrepositoryPath,
    /* [string][in] */ wchar_t *lbackupName,
    /* [string][in] */ wchar_t *lscheduleName,
    /* [string][in] */ wchar_t *repositoryDetailsJson,
    /* [string][in] */ wchar_t *isEncrypted,
    /* [string][in] */ wchar_t *encryptString,
    /* [string][in] */ wchar_t *vmid,
    /* [string][in] */ wchar_t *generateHash);

int HyperVHealthCheck( 
    /* [string][in] */ wchar_t *domainuserName,
    /* [string][in] */ wchar_t *password,
    /* [string][in] */ wchar_t *hypervHostName,
    /* [string][in] */ wchar_t *healthCheckParametersJson,
    /* [string][in] */ wchar_t *vmBackupDetailsJson);

/* [callback] */ long long CallbackProc( 
    /* [string][in] */ wchar_t *processType,
    /* [string][in] */ wchar_t *stepId,
    /* [string][in] */ wchar_t *processIdentifier,
    /* [string][in] */ wchar_t *vmId,
    /* [string][in] */ wchar_t *fileName,
    /* [string][in] */ wchar_t *progressStatus,
    /* [string][in] */ wchar_t *value,
    /* [string][in] */ wchar_t *executionTime);

/* [string][callback] */ wchar_t *CallbackCommon( 
    /* [string][in] */ wchar_t *functionName,
    /* [string][in] */ wchar_t *parameters);

void HVShutdown( void);


extern handle_t hypervserviceconnector_IfHandle;


extern RPC_IF_HANDLE hypervserviceconnector_v1_0_c_ifspec;
extern RPC_IF_HANDLE hypervserviceconnector_v1_0_s_ifspec;
#endif /* __hypervserviceconnector_INTERFACE_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


