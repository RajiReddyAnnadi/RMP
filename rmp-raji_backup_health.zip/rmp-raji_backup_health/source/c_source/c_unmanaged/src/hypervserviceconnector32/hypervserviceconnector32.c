#include "hypervserviceconnector32.h"
#include <jni.h>
#include <util/HVDataCollector.h>
#include <time.h>

jclass progressCls = 0;
jclass progressManager = 0;
jclass hvRestoreServerCls = 0;
jclass virtualBackupServerUtilCls = 0;
jclass virtualRestoreServerUtilCls = 0;
jclass longclass = 0;
jclass ProgressClass = 0;
jclass BackupCollectionManagerClass = 0;
jclass virtualMachineUtilCls = 0;
jmethodID addorRemoveDiskDetailsMethodID = 0;
jmethodID progressInit = 0;
jmethodID updateRestoreStep = 0;
jmethodID getFileCapacity = 0;
jmethodID updateBackupStep = 0;
jmethodID getProgressManagerMethod = 0;
jmethodID registerProcessMethod = 0;
jmethodID getProgressMethod = 0;
jmethodID processCompletedMethod = 0;
jmethodID longclasscons = 0;
jmethodID setProgressMethodID = 0;
jmethodID setMaximumMethodID = 0;
jmethodID javaCommonCallBackMethod = 0;
JNIEnv *javaEnv = 0;

static bool isIntialized = false;
static JavaVM *g_vm;

CRITICAL_SECTION cs1;

jboolean initializeVariables(JNIEnv *env){
    log(env, 1, "hypervserviceconnector32.c initializeStaticVariables.%d..",isIntialized);
    if(!isIntialized){
        isIntialized = true;
        int status = (*env).GetJavaVM(&g_vm);
        if(status != 0) {
             log(env, 1, "Unable to get jvm");
        }
        javaEnv=env;    
        jclass progressClsRef = (jclass)javaEnv->FindClass("com/manageengine/rmp/virtual/progressbar/diskreadwrite/DiskReadWriteProgress");
        progressCls = (jclass)javaEnv->NewGlobalRef(progressClsRef);
        progressInit = javaEnv->GetMethodID(progressCls, "<init>", "()V");

        jclass virtualBackupServerUtilRef = (jclass)javaEnv->FindClass("com/manageengine/rmp/virtual/backup/VirtualBackupServerUtil");
        virtualBackupServerUtilCls = (jclass)javaEnv->NewGlobalRef(virtualBackupServerUtilRef);
        updateBackupStep = javaEnv->GetStaticMethodID(virtualBackupServerUtilCls, "updateSteps", "(Ljava/lang/Long;Ljava/lang/String;Ljava/lang/Long;ILjava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Z)J");

        jclass virtualRestoreServerUtilRef = (jclass)javaEnv->FindClass("com/manageengine/rmp/virtual/restore/VirtualRestoreServerUtil");
        virtualRestoreServerUtilCls = (jclass)javaEnv->NewGlobalRef(virtualRestoreServerUtilRef);
        updateRestoreStep = javaEnv->GetStaticMethodID(virtualRestoreServerUtilCls, "addRestoreHistorySteps", "(Ljava/lang/Long;Ljava/lang/String;Ljava/lang/Long;ILjava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Z)J");
    
        jclass hvRestoreServerRef = (jclass)javaEnv->FindClass("com/manageengine/rmp/virtual/restore/HVRestoreServer");
        hvRestoreServerCls = (jclass)javaEnv->NewGlobalRef(hvRestoreServerRef);
        getFileCapacity = javaEnv->GetStaticMethodID(hvRestoreServerCls, "getFileCapacity", "(Ljava/lang/Long;Ljava/lang/String;)J");

        jclass progressManagerRef = (jclass)javaEnv->FindClass("com/manageengine/rmp/virtual/progressbar/ProgressManager");
        progressManager = (jclass)javaEnv->NewGlobalRef(progressManagerRef);
        getProgressManagerMethod = javaEnv->GetStaticMethodID(progressManager, "getProgressManager", "()Lcom/manageengine/rmp/virtual/progressbar/ProgressManager;");
        registerProcessMethod = javaEnv->GetMethodID(progressManager, "registerProcess", "(Ljava/lang/String;Ljava/lang/Long;Lcom/manageengine/rmp/virtual/progressbar/ProgressBar;)Lcom/manageengine/rmp/virtual/progressbar/ProgressBar;");
        getProgressMethod = javaEnv->GetMethodID(progressManager, "getProcess", "(Ljava/lang/String;Ljava/lang/Long;)Lcom/manageengine/rmp/virtual/progressbar/ProgressBar;");
        processCompletedMethod = javaEnv->GetMethodID(progressManager, "processCompleted", "(Ljava/lang/String;Ljava/lang/Long;)V");

        jclass longClassRef = javaEnv->FindClass("java/lang/Long");
        longclass = (jclass)javaEnv->NewGlobalRef(longClassRef);
        longclasscons = javaEnv->GetMethodID(longclass,"<init>","(J)V");

        jclass ProgressClassRef = (jclass)env->FindClass("com/manageengine/rmp/virtual/progressbar/ProgressBar");
        ProgressClass = (jclass)env->NewGlobalRef(ProgressClassRef);
        setProgressMethodID = env->GetMethodID(ProgressClass, "setProgress", "(J)V");
        setMaximumMethodID = env->GetMethodID(ProgressClass, "setMaximum", "(J)V");

        jclass BackupCollectionManagerClassRef = (jclass)env->FindClass("com/manageengine/rmp/virtual/flowhandler/schedule/BackupCollectionManager");
        BackupCollectionManagerClass = (jclass)env->NewGlobalRef(BackupCollectionManagerClassRef);
        addorRemoveDiskDetailsMethodID = env->GetStaticMethodID(BackupCollectionManagerClass, "addorRemoveDiskDetails", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Z)V");
        if(!addorRemoveDiskDetailsMethodID){
            log(env, 1, "test addorRemoveDiskDetailsMethodID failed");
        }

        jclass virtualMachineUtilRef = (jclass)javaEnv->FindClass("com/manageengine/rmp/virtual/VirtualMachineUtil");
        virtualMachineUtilCls = (jclass)javaEnv->NewGlobalRef(virtualMachineUtilRef);
        javaCommonCallBackMethod = javaEnv->GetStaticMethodID(virtualMachineUtilCls, "javaCommonCallBackMethod", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");

        InitializeCriticalSection(&cs1);

    }
    return JNI_TRUE;
}
jobject HyperVBackupC(JNIEnv *env,jstring domain, jstring user, jstring pwd, jstring jhypervHostName, jstring jfullbackupVMs, 
                            jstring jincrementalbackupVMs, jstring jrepositoryPath, jstring jbackupName, jstring jscheduleName, jstring jrepositoryDetailsJson, jstring jisanyVHDchanged)
{
    log(env, 1, "hypervserviceconnector32.c HyperVBackupC Starts...");
    jobject properties = env->NewObject(propClass, propConID);
    LPWSTR hypervHostName = NULL,domainName=NULL,userName = NULL,password = NULL, fullbackupVMs=NULL,incrementalbackupVMs=NULL;
    hypervHostName= (LPWSTR)env->GetStringChars(jhypervHostName, NULL);
    domainName= (LPWSTR)env->GetStringChars(domain, NULL);
	userName = (LPWSTR)env->GetStringChars(user, NULL);
	password = (LPWSTR)env->GetStringChars(pwd, NULL);
    
    LPWSTR repositoryPath=NULL,backupName=NULL,scheduleName=NULL, repositoryDetailsJson=NULL, isanyVHDchanged=NULL;
    repositoryPath = (LPWSTR)env->GetStringChars(jrepositoryPath, NULL);
    backupName = (LPWSTR)env->GetStringChars(jbackupName, NULL);
    scheduleName = (LPWSTR)env->GetStringChars(jscheduleName, NULL);
    incrementalbackupVMs = (LPWSTR)env->GetStringChars(jincrementalbackupVMs, NULL);
    fullbackupVMs = (LPWSTR)env->GetStringChars(jfullbackupVMs, NULL);
    repositoryDetailsJson = (LPWSTR)env->GetStringChars(jrepositoryDetailsJson, NULL);
    isanyVHDchanged = (LPWSTR)env->GetStringChars(jisanyVHDchanged, NULL);
         
    RPC_STATUS status;
    RPC_WSTR pszUuid             = NULL;
    RPC_WSTR pszProtocolSequence = (unsigned short *)L"ncacn_np";
    RPC_WSTR pszNetworkAddress   = (unsigned short *)hypervHostName;
    RPC_WSTR pszEndpoint         = (unsigned short *)L"\\pipe\\HV_RPCAgent";//todo
    RPC_WSTR pszOptions          = NULL;
    RPC_WSTR pszStringBinding    = NULL;
    unsigned long ulCode;
    boolean ret = TRUE;
	
    if(wcscmp(userName,L"-")!=0)
    {
        log(env, 1,"hypervserviceconnector32.c HyperVBackupC EXPLICIT Credentials");
        HANDLE lTokenHandle = NULL; 
        ret = LogonUser(userName, domainName, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &lTokenHandle);
        if(ret)
        {
            ret = ImpersonateLoggedOnUser(lTokenHandle);
             if(!ret)
             {
               log(env, 1,"hypervserviceconnector32.c HyperVBackupC Hyper-V ERROR while calling ImpersonateLoggedOnUser API");
              }
            CloseHandle(lTokenHandle);
        }
        else
        {
            log(env, 1,"hypervserviceconnector32.c HyperVBackupC Hyper-V ERROR while calling LogonUser API, err code"); 
        }
    }
    else
    {
        log(env, 1,"hypervserviceconnector32.c HyperVBackupC NULL Credentials");
    }

    status = RpcStringBindingCompose(pszUuid,
                                     pszProtocolSequence,
                                     pszNetworkAddress,
                                     pszEndpoint,
                                     pszOptions,
                                     &pszStringBinding);
    if (status) return properties;
    status = RpcBindingFromStringBinding(pszStringBinding, &hypervserviceconnector_IfHandle);
 if(status==RPC_S_OK){
     log(env, 1,"HyperVBackupC success");
 }else if(status==RPC_S_INVALID_STRING_BINDING){
     log(env, 1,"HyperVBackupC invalid binding");
 }else if(status==RPC_S_PROTSEQ_NOT_SUPPORTED){
     log(env, 1,"HyperVBackupC prot seq not supported");
 }else if(status==RPC_S_INVALID_RPC_PROTSEQ){
     log(env, 1,"HyperVBackupC prot seq invalid");
 }else if(status==RPC_S_INVALID_ENDPOINT_FORMAT){
     log(env, 1,"HyperVBackupC endpoint format invalid");
 }else if(status==RPC_S_STRING_TOO_LONG){
     log(env, 1,"HyperVBackupC string too long");
 }else if(status==RPC_S_INVALID_NET_ADDR){
     log(env, 1,"HyperVBackupC netwrk addr invalid");
 }else if(status==RPC_S_INVALID_ARG){
     log(env, 1,"HyperVBackupC argument invalid");
 }else if(status==RPC_S_INVALID_NAF_ID){
     log(env, 1,"HyperVBackupC naf invalid");
 }
  
    if (status) return properties;


    RpcTryExcept  
    {
        log(env, 1,"hypervserviceconnector32.c HyperVBackupC Going to call HyperVBackupC using RPC");

        LPWSTR domainuserName;
        if(wcscmp(userName,L"-")!=0)
        {
            domainuserName = SysAllocStringLen(L"", wcslen(domainName) + wcslen(L"\\") + wcslen(userName));
            wcscpy(domainuserName, domainName);
            wcscat(domainuserName, L"\\");
            wcscat(domainuserName, userName);
        }
        else
        {
            domainuserName = SysAllocStringLen(L"", wcslen(L"-"));
            wcscpy(domainuserName, L"-");
        }

        //need to connect domainname and username
        int retValInt = HyperVBackup(domainuserName, password, hypervHostName, fullbackupVMs, incrementalbackupVMs, repositoryPath, backupName, scheduleName, repositoryDetailsJson, isanyVHDchanged);
        jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
        env->CallObjectMethod(properties, propPutID, env->NewStringUTF("BackupReturnValue"),  installObject);
        //HVShutdown();
    }
    RpcExcept(1) 
    {
        ulCode = RpcExceptionCode();
        log(env, 1,"hypervserviceconnector32.c HyperVBackupC Hyper-V Runtime reported the  exception...%ld",ulCode);
        jobject installObject = env->NewObject(intClass, intConID, (jint) ulCode);
        env->CallObjectMethod(properties, propPutID, env->NewStringUTF("RPCExceptionCode"), installObject);
        log(env, 1,"hypervserviceconnector32.c HyperVBackupC exception end");
    }
    RpcEndExcept
 
    status = RpcStringFree(&pszStringBinding); 
    log(env, 1,"hypervserviceconnector32.c HyperVBackup completed...");
    if (status) return properties;
 
    status = RpcBindingFree(&hypervserviceconnector_IfHandle);
 
    if (status) return properties;

    if(wcscmp(userName,L"-")!=0)
    {
        boolean isSelfReverted = RevertToSelf();
        if(isSelfReverted)
        {
            log(env, 1,"RevertToSelf Successful!");
        }
        else
        {
            log(env, 1,"RevertToSelf Failure!");
        }
    }

    log(env, 1,"hypervserviceconnector32.c HyperVBackupC ended...");
    return properties;
}

jint doCBToperationsforscheduleC(JNIEnv* env, jstring jdomainName, jstring juserName, jstring jpassword, jstring jhostServer, jstring jbackupId, jstring jallVMIds)
{
    int returnStatus = 0;
    log(env, 1, "hypervserviceconnector32.c doCBToperationsforschedule Starts...");
    LPWSTR hypervHostName = NULL,domainName=NULL,userName = NULL,password = NULL, scheduleName=NULL;
    hypervHostName= (LPWSTR)env->GetStringChars(jhostServer, NULL);
    domainName= (LPWSTR)env->GetStringChars(jdomainName, NULL);
    userName = (LPWSTR)env->GetStringChars(juserName, NULL);
    password = (LPWSTR)env->GetStringChars(jpassword, NULL);
    scheduleName = (LPWSTR)env->GetStringChars(jbackupId, NULL);

    LPWSTR allVMIds = NULL;
    allVMIds = (LPWSTR)env->GetStringChars(jallVMIds, NULL);
    
    RPC_STATUS status;
    RPC_WSTR pszUuid             = NULL;
    RPC_WSTR pszProtocolSequence = (unsigned short *)L"ncacn_np";
    RPC_WSTR pszNetworkAddress   = (unsigned short *)hypervHostName;
    RPC_WSTR pszEndpoint         = (unsigned short *)L"\\pipe\\HV_RPCAgent";//todo
    RPC_WSTR pszOptions          = NULL;
    RPC_WSTR pszStringBinding    = NULL;
    unsigned long ulCode;
    boolean ret = TRUE;

    if(wcscmp(userName,L"-")!=0)
    {
        log(env, 1,"hypervserviceconnector32.c doCBToperationsforscheduleC EXPLICIT Credentials");
        HANDLE lTokenHandle = NULL; 
        ret = LogonUser(userName, domainName, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &lTokenHandle);
        if(ret)
        {
            ret = ImpersonateLoggedOnUser(lTokenHandle);
             if(!ret)
             {
               log(env, 1,"hypervserviceconnector32.c doCBToperationsforscheduleC Hyper-V ERROR while calling ImpersonateLoggedOnUser API");
              }
            CloseHandle(lTokenHandle);
        }
        else
        {
            log(env, 1,"hypervserviceconnector32.c doCBToperationsforscheduleC Hyper-V ERROR while calling LogonUser API, err code"); 
        }
    }
    else
    {
        log(env, 1,"hypervserviceconnector32.c doCBToperationsforscheduleC NULL Credentials");
    }

    status = RpcStringBindingCompose(pszUuid,
                                     pszProtocolSequence,
                                     pszNetworkAddress,
                                     pszEndpoint,
                                     pszOptions,
                                     &pszStringBinding);
    if (status) return 1;
    status = RpcBindingFromStringBinding(pszStringBinding, &hypervserviceconnector_IfHandle);
 if(status==RPC_S_OK){
     log(env, 1,"doCBToperationsforscheduleC success");
 }else if(status==RPC_S_INVALID_STRING_BINDING){
     log(env, 1,"doCBToperationsforscheduleC invalid binding");
 }else if(status==RPC_S_PROTSEQ_NOT_SUPPORTED){
     log(env, 1,"doCBToperationsforscheduleC prot seq not supported");
 }else if(status==RPC_S_INVALID_RPC_PROTSEQ){
     log(env, 1,"doCBToperationsforscheduleC prot seq invalid");
 }else if(status==RPC_S_INVALID_ENDPOINT_FORMAT){
     log(env, 1,"doCBToperationsforscheduleC endpoint format invalid");
 }else if(status==RPC_S_STRING_TOO_LONG){
     log(env, 1,"doCBToperationsforscheduleC string too long");
 }else if(status==RPC_S_INVALID_NET_ADDR){
     log(env, 1,"doCBToperationsforscheduleC netwrk addr invalid");
 }else if(status==RPC_S_INVALID_ARG){
     log(env, 1,"doCBToperationsforscheduleC argument invalid");
 }else if(status==RPC_S_INVALID_NAF_ID){
     log(env, 1,"doCBToperationsforscheduleC naf invalid");
 }
  
    if (status) return 2;


    RpcTryExcept  
    {
        log(env, 1,"hypervserviceconnector32.c doCBToperationsforscheduleC Going to call doCBToperationsforschedule using RPC");


        LPWSTR domainuserName;
        if(wcscmp(userName,L"-")!=0)
        {
            domainuserName = SysAllocStringLen(L"", wcslen(domainName) + wcslen(L"\\") + wcslen(userName));
            wcscpy(domainuserName, domainName);
            wcscat(domainuserName, L"\\");
            wcscat(domainuserName, userName);
        }
        else
        {
            domainuserName = SysAllocStringLen(L"", wcslen(L"-"));
            wcscpy(domainuserName, L"-");
        }

        //need to connect domainname and username
        int retValInt = HyperVdoCBToperationsforschedule(domainuserName, password, hypervHostName, scheduleName, allVMIds); 
        returnStatus = retValInt;
        //HVShutdown();
    }
    RpcExcept(1) 
    {
        ulCode = RpcExceptionCode();
        log(env, 1,"hypervserviceconnector32.c doCBToperationsforscheduleC Hyper-V Runtime reported exception...%ld",ulCode);
        returnStatus = 1;
    }
    RpcEndExcept
 
    status = RpcStringFree(&pszStringBinding); 
 
    if (status) return 3;
 
    status = RpcBindingFree(&hypervserviceconnector_IfHandle);
 
    if (status) return 4;
    if(wcscmp(userName,L"-")!=0)
    {
        boolean isSelfReverted = RevertToSelf();
        if(isSelfReverted)
        {
            log(env, 1,"RevertToSelf Successful!");
        }
        else
        {
            log(env, 1,"RevertToSelf Failure!");
        }
    }
    return (jint)returnStatus;

}


jint InstallandstartHypervdriverC(JNIEnv* env, jstring jdomainName, jstring juserName, jstring jpassword, jstring jhostServer, jstring isInstall)
{
    int returnStatus = 0;
    log(env, 1, "hypervserviceconnector32.c InstallandstartHypervdriverC Starts...");
    LPWSTR hypervHostName = NULL,domainName=NULL,userName = NULL,password = NULL, isInstallstring=NULL;
    hypervHostName= (LPWSTR)env->GetStringChars(jhostServer, NULL);
    domainName= (LPWSTR)env->GetStringChars(jdomainName, NULL);
    userName = (LPWSTR)env->GetStringChars(juserName, NULL);
    password = (LPWSTR)env->GetStringChars(jpassword, NULL);
    isInstallstring = (LPWSTR)env->GetStringChars(isInstall, NULL);
    
    
    RPC_STATUS status;
    RPC_WSTR pszUuid             = NULL;
    RPC_WSTR pszProtocolSequence = (unsigned short *)L"ncacn_np";
    RPC_WSTR pszNetworkAddress   = (unsigned short *)hypervHostName;
    RPC_WSTR pszEndpoint         = (unsigned short *)L"\\pipe\\HV_RPCAgent";//todo
    RPC_WSTR pszOptions          = NULL;
    RPC_WSTR pszStringBinding    = NULL;
    unsigned long ulCode;
    boolean ret = TRUE;
    HANDLE lTokenHandle = NULL; 

    
    if(wcscmp(userName,L"-")!=0)
    {
        log(env, 1,"hypervserviceconnector32.c InstallandstartHypervdriverC EXPLICIT Credentials");
        HANDLE lTokenHandle = NULL; 
        ret = LogonUser(userName, domainName, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &lTokenHandle);
        if(ret)
        {
            ret = ImpersonateLoggedOnUser(lTokenHandle);
             if(!ret)
             {
               log(env, 1,"hypervserviceconnector32.c InstallandstartHypervdriverC Hyper-V ERROR while calling ImpersonateLoggedOnUser API");
              }
            CloseHandle(lTokenHandle);
        }
        else
        {
            log(env, 1,"hypervserviceconnector32.c InstallandstartHypervdriverC Hyper-V ERROR while calling LogonUser API, err code"); 
        }
    }
    else
    {
        log(env, 1,"hypervserviceconnector32.c InstallandstartHypervdriverC NULL Credentials");
    }

    status = RpcStringBindingCompose(pszUuid,
                                     pszProtocolSequence,
                                     pszNetworkAddress,
                                     pszEndpoint,
                                     pszOptions,
                                     &pszStringBinding);
    if (status) return 1;
    status = RpcBindingFromStringBinding(pszStringBinding, &hypervserviceconnector_IfHandle);
 if(status==RPC_S_OK){
     log(env, 1,"InstallandstartHypervdriverC success");
 }else if(status==RPC_S_INVALID_STRING_BINDING){
     log(env, 1,"InstallandstartHypervdriverC invalid binding");
 }else if(status==RPC_S_PROTSEQ_NOT_SUPPORTED){
     log(env, 1,"InstallandstartHypervdriverC prot seq not supported");
 }else if(status==RPC_S_INVALID_RPC_PROTSEQ){
     log(env, 1,"InstallandstartHypervdriverC prot seq invalid");
 }else if(status==RPC_S_INVALID_ENDPOINT_FORMAT){
     log(env, 1,"InstallandstartHypervdriverC endpoint format invalid");
 }else if(status==RPC_S_STRING_TOO_LONG){
     log(env, 1,"InstallandstartHypervdriverC string too long");
 }else if(status==RPC_S_INVALID_NET_ADDR){
     log(env, 1,"InstallandstartHypervdriverC netwrk addr invalid");
 }else if(status==RPC_S_INVALID_ARG){
     log(env, 1,"InstallandstartHypervdriverC argument invalid");
 }else if(status==RPC_S_INVALID_NAF_ID){
     log(env, 1,"InstallandstartHypervdriverC naf invalid");
 }
  
    if (status) return 2;


    RpcTryExcept  
    {
        log(env, 1,"hypervserviceconnector32.c InstallandstartHypervdriverC Going to call HyperVinstallandstartDriver using RPC");


       LPWSTR domainuserName;
        if(wcscmp(userName,L"-")!=0)
        {
            domainuserName = SysAllocStringLen(L"", wcslen(domainName) + wcslen(L"\\") + wcslen(userName));
            wcscpy(domainuserName, domainName);
            wcscat(domainuserName, L"\\");
            wcscat(domainuserName, userName);
        }
        else
        {
            domainuserName = SysAllocStringLen(L"", wcslen(L"-"));
            wcscpy(domainuserName, L"-");
        }

        //need to connect domainname and username
        int retValInt = HyperVinstallandstartDriver(domainuserName, password, hypervHostName, isInstallstring); 
        returnStatus = retValInt;
        //HVShutdown();
    }
    RpcExcept(1) 
    {
        ulCode = RpcExceptionCode();
        log(env, 1,"hypervserviceconnector32.c InstallandstartHypervdriverC Hyper-V Runtime reported exception...%ld",ulCode);
        returnStatus = 1;
    }
    RpcEndExcept
 
    status = RpcStringFree(&pszStringBinding); 
 
    if (status) return 3;
 
    status = RpcBindingFree(&hypervserviceconnector_IfHandle);
 
    if (status) return 4;
    if(wcscmp(userName,L"-")!=0)
    {
        boolean isSelfReverted = RevertToSelf();
        if(isSelfReverted)
        {
            log(env, 1,"RevertToSelf Successful!");
        }
        else
        {
            log(env, 1,"RevertToSelf Failure!");
        }
    }
    return (jint)returnStatus;

}



jobject HyperVRestoreC(JNIEnv *env, jstring domain, jstring user, jstring pwd, jstring jhypervHostName, jstring vmName, jstring vmfullbackupPath, jstring vmincrementalbackupPaths, jstring ischangeVMName, jstring newVMName,
  jstring VHDnewstorageLocation, jstring repositoryDetailsJson, jstring isPowerOn, jstring isEncrypted, jstring encryptPassword, jstring vmId, jstring restoreId, jstring paramsjson, jstring restoreFormat)
{
    initializeVariables(env);
    log(env, 1, "hypervserviceconnector32.c HyperVRestoreC Starts0...");
    
    jobject properties = env->NewObject(propClass, propConID);
    LPWSTR hypervHostName = NULL,domainName=NULL,userName = NULL,password = NULL, vmtoRestore=NULL,vmfullbackupPathstring=NULL, isPowerOnstring=NULL,vmid=NULL,restoreid=NULL,restoreFormatString=NULL;
    hypervHostName= (LPWSTR)env->GetStringChars(jhypervHostName, NULL);
    domainName= (LPWSTR)env->GetStringChars(domain, NULL);
    userName = (LPWSTR)env->GetStringChars(user, NULL);
    password = (LPWSTR)env->GetStringChars(pwd, NULL);
    vmid = (LPWSTR)env->GetStringChars(vmId, NULL);
    restoreid = (LPWSTR)env->GetStringChars(restoreId, NULL);
    
    LPWSTR vmincrementalbackupPathsList=NULL,lisEncrypted=NULL, lencryptPassword=NULL;
    vmtoRestore = (LPWSTR)env->GetStringChars(vmName, NULL);
    vmfullbackupPathstring = (LPWSTR)env->GetStringChars(vmfullbackupPath, NULL);
    vmincrementalbackupPathsList = (LPWSTR)env->GetStringChars(vmincrementalbackupPaths, NULL);
    isPowerOnstring = (LPWSTR)env->GetStringChars(isPowerOn, NULL);
    lisEncrypted = (LPWSTR)env->GetStringChars(isEncrypted, NULL);
    lencryptPassword = (LPWSTR)env->GetStringChars(encryptPassword, NULL);
    restoreFormatString = (LPWSTR)env->GetStringChars(restoreFormat, NULL);


    LPWSTR LischangeVMName=NULL, LnewVMName=NULL, LVHDnewstorageLocation=NULL, LrepositoryDetailsJson=NULL, Lparamsjson=NULL;
    LischangeVMName = (LPWSTR)env->GetStringChars(ischangeVMName, NULL);
    LnewVMName = (LPWSTR)env->GetStringChars(newVMName, NULL);
    LVHDnewstorageLocation = (LPWSTR)env->GetStringChars(VHDnewstorageLocation, NULL);
    LrepositoryDetailsJson = (LPWSTR)env->GetStringChars(repositoryDetailsJson, NULL);
    Lparamsjson = (LPWSTR)env->GetStringChars(paramsjson, NULL);

    RPC_STATUS status;
    RPC_WSTR pszUuid             = NULL;
    RPC_WSTR pszProtocolSequence = (unsigned short *)L"ncacn_np";
    RPC_WSTR pszNetworkAddress   = (unsigned short *)hypervHostName;
    RPC_WSTR pszEndpoint         = (unsigned short *)L"\\pipe\\HV_RPCAgent";//todo
    RPC_WSTR pszOptions          = NULL;
    RPC_WSTR pszStringBinding    = NULL;
    unsigned long ulCode;
    boolean ret = TRUE;

     if(wcscmp(userName,L"-")!=0)
    {
        log(env, 1,"hypervserviceconnector32.c HyperVRestoreC EXPLICIT Credentials");
        HANDLE lTokenHandle = NULL; 
        ret = LogonUser(userName, domainName, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &lTokenHandle);
        if(ret)
        {
            ret = ImpersonateLoggedOnUser(lTokenHandle);
             if(!ret)
             {
               log(env, 1,"hypervserviceconnector32.c HyperVRestoreC Hyper-V ERROR while calling ImpersonateLoggedOnUser API");
              }
            CloseHandle(lTokenHandle);
        }
        else
        {
            log(env, 1,"hypervserviceconnector32.c HyperVRestoreC Hyper-V ERROR while calling LogonUser API, err code"); 
        }
    }
    else
    {
        log(env, 1,"hypervserviceconnector32.c HyperVRestoreC NULL Credentials");
    }

    status = RpcStringBindingCompose(pszUuid,
                                     pszProtocolSequence,
                                     pszNetworkAddress,
                                     pszEndpoint,
                                     pszOptions,
                                     &pszStringBinding);
    if (status) return properties;
    status = RpcBindingFromStringBinding(pszStringBinding, &hypervserviceconnector_IfHandle);
 if(status==RPC_S_OK){
     log(env, 1,"HyperVRestoreC success");
 }else if(status==RPC_S_INVALID_STRING_BINDING){
     log(env, 1,"HyperVRestoreC invalid binding");
 }else if(status==RPC_S_PROTSEQ_NOT_SUPPORTED){
     log(env, 1,"HyperVRestoreC prot seq not supported");
 }else if(status==RPC_S_INVALID_RPC_PROTSEQ){
     log(env, 1,"HyperVRestoreC prot seq invalid");
 }else if(status==RPC_S_INVALID_ENDPOINT_FORMAT){
     log(env, 1,"HyperVRestoreC endpoint format invalid");
 }else if(status==RPC_S_STRING_TOO_LONG){
     log(env, 1,"HyperVRestoreC string too long");
 }else if(status==RPC_S_INVALID_NET_ADDR){
     log(env, 1,"HyperVRestoreC netwrk addr invalid");
 }else if(status==RPC_S_INVALID_ARG){
     log(env, 1,"HyperVRestoreC argument invalid");
 }else if(status==RPC_S_INVALID_NAF_ID){
     log(env, 1,"HyperVRestoreC naf invalid");
 }
  
    if (status) return properties;


    RpcTryExcept  
    {
        log(env, 1,"hypervserviceconnector32.c Going to call HyperVRestoreC using RPC");



        LPWSTR domainuserName;
        if(wcscmp(userName,L"-")!=0)
        {
            domainuserName = SysAllocStringLen(L"", wcslen(domainName) + wcslen(L"\\") + wcslen(userName));
            wcscpy(domainuserName, domainName);
            wcscat(domainuserName, L"\\");
            wcscat(domainuserName, userName);
        }
        else
        {
            domainuserName = SysAllocStringLen(L"", wcslen(L"-"));
            wcscpy(domainuserName, L"-");
        }


      
        int retValInt = HyperVRestore(domainuserName, password, hypervHostName, vmtoRestore, vmfullbackupPathstring, vmincrementalbackupPathsList, LischangeVMName, LnewVMName,
                                    LVHDnewstorageLocation, LrepositoryDetailsJson, isPowerOnstring, lisEncrypted, lencryptPassword, vmid, restoreid, Lparamsjson, restoreFormatString);
        jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
        env->CallObjectMethod(properties, propPutID, env->NewStringUTF("RestoreReturnValue"),  installObject);
        //HVShutdown();
    }
    RpcExcept(1) 
    {
        ulCode = RpcExceptionCode();
        log(env, 1,"hypervserviceconnector32.c HyperVRestoreC Hyper-V Runtime reported exception...%ld",ulCode);
        jobject installObject = env->NewObject(intClass, intConID, (jint) ulCode);
        env->CallObjectMethod(properties, propPutID, env->NewStringUTF("RPCExceptionCode"), installObject);
    }
    RpcEndExcept
 
    status = RpcStringFree(&pszStringBinding); 
     log(env, 1,"hypervserviceconnector32.c HyperVRestoreC ended...");
    if (status) return properties;
 
    status = RpcBindingFree(&hypervserviceconnector_IfHandle);
 
    if (status) return properties;
    if(wcscmp(userName,L"-")!=0)
    {
        boolean isSelfReverted = RevertToSelf();
        if(isSelfReverted)
        {
            log(env, 1,"RevertToSelf Successful!");
        }
        else
        {
            log(env, 1,"RevertToSelf Failure!");
        }
    }
   
    return properties;
}

jobject copyVMfilesfromVSSSnapshotC(JNIEnv *env,jstring domain, jstring user, jstring password, jstring hostServer, jstring hypervVMId, jstring newbackupType, jstring repositoryPath, jstring backupIdentifier, 
   jstring backupId, jstring repositoryDetailsJson, jstring isEncrypted, jstring encryptPassword, jstring vmId, jstring generateHash)
{
    initializeVariables(env);
    log(env, 1, "hypervserviceconnector32.c copyVMfilesfromVSSSnapshotC Starts0...%d...");
    jobject properties = env->NewObject(propClass, propConID);
    log(env, 1, "hypervserviceconnector32.c copyVMfilesfromVSSSnapshotC Starts1...%d...");
    LPWSTR hypervHostName = NULL,domainName=NULL,userName = NULL,lpassword = NULL, backupType=NULL,vmName=NULL, vmid=NULL;
    hypervHostName= (LPWSTR)env->GetStringChars(hostServer, NULL);
    domainName= (LPWSTR)env->GetStringChars(domain, NULL);
    userName = (LPWSTR)env->GetStringChars(user, NULL);
    lpassword = (LPWSTR)env->GetStringChars(password, NULL);
    vmid = (LPWSTR)env->GetStringChars(vmId, NULL);
     vmName = (LPWSTR)env->GetStringChars(hypervVMId, NULL);
    backupType = (LPWSTR)env->GetStringChars(newbackupType, NULL);
    
    LPWSTR lrepositoryPath=NULL,lbackupName=NULL,lscheduleName=NULL, lrepositoryDetailsJson=NULL,
            lisEncrypted=NULL, lencryptPassword=NULL, lgenerateHash = NULL;
    lrepositoryPath = (LPWSTR)env->GetStringChars(repositoryPath, NULL);
    lbackupName = (LPWSTR)env->GetStringChars(backupIdentifier, NULL);
    lscheduleName = (LPWSTR)env->GetStringChars(backupId, NULL);
    lrepositoryDetailsJson = (LPWSTR)env->GetStringChars(repositoryDetailsJson, NULL);
    lisEncrypted = (LPWSTR)env->GetStringChars(isEncrypted, NULL);
    lencryptPassword = (LPWSTR)env->GetStringChars(encryptPassword, NULL);
    lgenerateHash = (LPWSTR)env->GetStringChars(generateHash, NULL);
         
    RPC_STATUS status;
    RPC_WSTR pszUuid             = NULL;
    RPC_WSTR pszProtocolSequence = (unsigned short *)L"ncacn_np";
    RPC_WSTR pszNetworkAddress   = (unsigned short *)hypervHostName;
    RPC_WSTR pszEndpoint         = (unsigned short *)L"\\pipe\\HV_RPCAgent";//todo
    RPC_WSTR pszOptions          = NULL;
    RPC_WSTR pszStringBinding    = NULL;
    unsigned long ulCode;
    boolean ret = TRUE;
    
    if(wcscmp(userName,L"-")!=0)
    {
        log(env, 1,"hypervserviceconnector32.c copyVMfilesfromVSSSnapshotC EXPLICIT Credentials");
        HANDLE lTokenHandle = NULL; 
        ret = LogonUser(userName, domainName, lpassword, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &lTokenHandle);
        if(ret)
        {
            ret = ImpersonateLoggedOnUser(lTokenHandle);
             if(!ret)
             {
               log(env, 1,"hypervserviceconnector32.c copyVMfilesfromVSSSnapshotC Hyper-V ERROR while calling ImpersonateLoggedOnUser API");
              }
            CloseHandle(lTokenHandle);
        }
        else
        {
            log(env, 1,"hypervserviceconnector32.c copyVMfilesfromVSSSnapshotC Hyper-V ERROR while calling LogonUser API, err code"); 
        }
    }
    else
    {
        log(env, 1,"hypervserviceconnector32.c copyVMfilesfromVSSSnapshotC NULL Credentials");
    }

    status = RpcStringBindingCompose(pszUuid,
                                     pszProtocolSequence,
                                     pszNetworkAddress,
                                     pszEndpoint,
                                     pszOptions,
                                     &pszStringBinding);
    if (status) return properties;
    status = RpcBindingFromStringBinding(pszStringBinding, &hypervserviceconnector_IfHandle);
 if(status==RPC_S_OK){
     log(env, 1,"copyVMfilesfromVSSSnapshotC success");
 }else if(status==RPC_S_INVALID_STRING_BINDING){
     log(env, 1,"copyVMfilesfromVSSSnapshotC invalid binding");
 }else if(status==RPC_S_PROTSEQ_NOT_SUPPORTED){
     log(env, 1,"copyVMfilesfromVSSSnapshotC prot seq not supported");
 }else if(status==RPC_S_INVALID_RPC_PROTSEQ){
     log(env, 1,"copyVMfilesfromVSSSnapshotC prot seq invalid");
 }else if(status==RPC_S_INVALID_ENDPOINT_FORMAT){
     log(env, 1,"copyVMfilesfromVSSSnapshotC endpoint format invalid");
 }else if(status==RPC_S_STRING_TOO_LONG){
     log(env, 1,"copyVMfilesfromVSSSnapshotC string too long");
 }else if(status==RPC_S_INVALID_NET_ADDR){
     log(env, 1,"copyVMfilesfromVSSSnapshotC netwrk addr invalid");
 }else if(status==RPC_S_INVALID_ARG){
     log(env, 1,"copyVMfilesfromVSSSnapshotC argument invalid");
 }else if(status==RPC_S_INVALID_NAF_ID){
     log(env, 1,"copyVMfilesfromVSSSnapshotC naf invalid");
 }
  
    if (status) return properties;


    RpcTryExcept  
    {
        log(env, 1,"hypervserviceconnector32.c copyVMfilesfromVSSSnapshotC Going to call copyVMfilesfromVSSSnapshotC using RPC");

        LPWSTR domainuserName;
        if(wcscmp(userName,L"-")!=0)
        {
            domainuserName = SysAllocStringLen(L"", wcslen(domainName) + wcslen(L"\\") + wcslen(userName));
            wcscpy(domainuserName, domainName);
            wcscat(domainuserName, L"\\");
            wcscat(domainuserName, userName);
        }
        else
        {
            domainuserName = SysAllocStringLen(L"", wcslen(L"-"));
            wcscpy(domainuserName, L"-");
        }

        //need to connect domainname and username
        int retValInt = copyVMfilesfromVSSSnapshot(domainuserName, lpassword, hypervHostName, vmName, backupType, lrepositoryPath, lbackupName, lscheduleName, lrepositoryDetailsJson, lisEncrypted, lencryptPassword, vmid, lgenerateHash);
        jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt); 
        env->CallObjectMethod(properties, propPutID, env->NewStringUTF("BackupReturnValue"),  installObject);
        //HVShutdown();
    }
    RpcExcept(1) 
    {
        ulCode = RpcExceptionCode();
        log(env, 1,"hypervserviceconnector32.c copyVMfilesfromVSSSnapshotC Hyper-V Runtime reported the  exception...%ld",ulCode);
        jobject installObject = env->NewObject(intClass, intConID, (jint) ulCode);
        env->CallObjectMethod(properties, propPutID, env->NewStringUTF("RPCExceptionCode"), installObject);
        log(env, 1,"hypervserviceconnector32.c copyVMfilesfromVSSSnapshotC exception end");
    }
    RpcEndExcept
 
    status = RpcStringFree(&pszStringBinding); 
    log(env, 1,"hypervserviceconnector32.c copyVMfilesfromVSSSnapshotC completed...");
    if (status) return properties;
 
    status = RpcBindingFree(&hypervserviceconnector_IfHandle);
 
    if (status) return properties;
    if(wcscmp(userName,L"-")!=0)
    {
        boolean isSelfReverted = RevertToSelf();
        if(isSelfReverted)
        {
            log(env, 1,"RevertToSelf Successful!");
        }
        else
        {
            log(env, 1,"RevertToSelf Failure!");
        }
    }
    log(env, 1,"hypervserviceconnector32.c copyVMfilesfromVSSSnapshotC ended...");
    return properties;
}

jobject HyperVHealthCheckC(JNIEnv *env,jstring domain, jstring user, jstring pwd, jstring jhypervHostName, jstring healthCheckParametersJson, jstring vmBackupDetailsJson)
{
        initializeVariables(env);
        log(env, 1, "hypervserviceconnector64.c HealthCheckC Starts...");

        jobject properties = env->NewObject(propClass, propConID);
        LPWSTR hypervHostName = NULL, domainName=NULL, userName = NULL, password = NULL, lhealthCheckParametersJson = NULL, lvmBackupDetailsJson = NULL;
        hypervHostName= (LPWSTR)env->GetStringChars(jhypervHostName, NULL);
        domainName= (LPWSTR)env->GetStringChars(domain, NULL);
        userName = (LPWSTR)env->GetStringChars(user, NULL);
        password = (LPWSTR)env->GetStringChars(pwd, NULL);
        lhealthCheckParametersJson = (LPWSTR)env->GetStringChars(healthCheckParametersJson, NULL);
        lvmBackupDetailsJson = (LPWSTR)env->GetStringChars(vmBackupDetailsJson, NULL);

	RPC_STATUS status;
	RPC_WSTR pszUuid             = NULL;
	RPC_WSTR pszProtocolSequence = (unsigned short *)L"ncacn_np";
	RPC_WSTR pszNetworkAddress   = (unsigned short *)hypervHostName;
	RPC_WSTR pszEndpoint         = (unsigned short *)L"\\pipe\\HV_RPCAgent";//todo
	RPC_WSTR pszOptions          = NULL;
	RPC_WSTR pszStringBinding    = NULL;
	unsigned long ulCode;
	boolean ret = TRUE;

	if(wcscmp(userName,L"-")!=0)
	{
		log(env, 1,"hypervserviceconnector64.c HealthCheckC EXPLICIT Credentials");
		HANDLE lTokenHandle = NULL;
		ret = LogonUser(userName, domainName, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &lTokenHandle);
		if(ret)
		{
			ret = ImpersonateLoggedOnUser(lTokenHandle);
			if(!ret)
			{
				log(env, 1,"hypervserviceconnector64.c HealthCheckC Hyper-V ERROR while calling ImpersonateLoggedOnUser API");
			}
			CloseHandle(lTokenHandle);
		}
		else
		{
			log(env, 1,"hypervserviceconnector64.c HealthCheckC Hyper-V ERROR while calling LogonUser API, err code");
		}
	}
	else
	{
		log(env, 1,"hypervserviceconnector64.c HealthCheckC NULL Credentials");
	}

	status = RpcStringBindingCompose(pszUuid,
			pszProtocolSequence,
			pszNetworkAddress,
			pszEndpoint,
			pszOptions,
			&pszStringBinding);
	if (status) return properties;
	status = RpcBindingFromStringBinding(pszStringBinding, &hypervserviceconnector_IfHandle);
	if(status==RPC_S_OK){
		log(env, 1,"HealthCheckC success");
	}else if(status==RPC_S_INVALID_STRING_BINDING){
		log(env, 1,"HealthCheckC invalid binding");
	}else if(status==RPC_S_PROTSEQ_NOT_SUPPORTED){
		log(env, 1,"HealthCheckC prot seq not supported");
	}else if(status==RPC_S_INVALID_RPC_PROTSEQ){
		log(env, 1,"HealthCheckC prot seq invalid");
	}else if(status==RPC_S_INVALID_ENDPOINT_FORMAT){
		log(env, 1,"HealthCheckC endpoint format invalid");
	}else if(status==RPC_S_STRING_TOO_LONG){
		log(env, 1,"HealthCheckC string too long");
	}else if(status==RPC_S_INVALID_NET_ADDR){
		log(env, 1,"HealthCheckC netwrk addr invalid");
	}else if(status==RPC_S_INVALID_ARG){
		log(env, 1,"HealthCheckC argument invalid");
	}else if(status==RPC_S_INVALID_NAF_ID){
		log(env, 1,"HealthCheckC naf invalid");
	}

	if (status) return properties;


	RpcTryExcept
	{
		log(env, 1,"hypervserviceconnector64.c Going to call HealthCheckC using RPC");



		LPWSTR domainuserName;
		if(wcscmp(userName,L"-")!=0)
		{
			domainuserName = SysAllocStringLen(L"", wcslen(domainName) + wcslen(L"\\") + wcslen(userName));
			wcscpy(domainuserName, domainName);
			wcscat(domainuserName, L"\\");
			wcscat(domainuserName, userName);
		}
		else
		{
			domainuserName = SysAllocStringLen(L"", wcslen(L"-"));
			wcscpy(domainuserName, L"-");
		}
        int retValInt = HyperVHealthCheck(domainuserName, password, hypervHostName, lhealthCheckParametersJson, lvmBackupDetailsJson);
        log(env, 1,"hypervserviceconnector64.c test-13000...#%d#",retValInt);
        jobject installObject = env->NewObject(intClass, intConID, (jint)retValInt);
        env->CallObjectMethod(properties, propPutID, env->NewStringUTF("HealthCheckReturnValue"),  installObject);
        }
        RpcExcept(1)
        {
            ulCode = RpcExceptionCode();
            log(env, 1,"hypervserviceconnector64.c HealthCheckC Hyper-V Runtime reported exception...%ld",ulCode);
            jobject installObject = env->NewObject(intClass, intConID, (jint) ulCode);
            env->CallObjectMethod(properties, propPutID, env->NewStringUTF("RPCExceptionCode"), installObject);
        }
        RpcEndExcept

        status = RpcStringFree(&pszStringBinding);
         log(env, 1,"hypervserviceconnector64.c HealthCheckC ended...");
        if (status) return properties;

        status = RpcBindingFree(&hypervserviceconnector_IfHandle);

        if (status) return properties;
        if(wcscmp(userName,L"-")!=0)
        {
            boolean isSelfReverted = RevertToSelf();
            if(isSelfReverted)
            {
                log(env, 1,"RevertToSelf Successful!");
            }
            else
            {
                log(env, 1,"RevertToSelf Failure!");
            }
        }

        return properties;
}

long long CallbackProc(wchar_t *processType, wchar_t *stepId, wchar_t *processIdentifier, wchar_t *vmId, wchar_t *fileName, wchar_t *progressStatus, wchar_t *value, wchar_t *executionTime)
{   
    EnterCriticalSection(&cs1);
    //printf("Call back value : %ws : %ws : %ws : %ws : %ws : %ws : %ws : %ws\n",processType,stepId,processIdentifier,vmId,fileName,progressStatus,value,executionTime);
     bool isAttached = false;
    int getEnvStat = g_vm->GetEnv((void **)&javaEnv, JNI_VERSION_1_4);
	if (getEnvStat == JNI_EDETACHED) {
//            log(javaEnv, 1,"GetEnv: not attached");
		if (g_vm->AttachCurrentThread((void **) &javaEnv, NULL) != 0) {
//                    log(javaEnv, 1,"Failed to attach");
                    return -1L;
		}
                else{
                    isAttached = true;
		}
	} else if (getEnvStat == JNI_OK) {
//            log(javaEnv, 1,"before file capcity add");
        } else if (getEnvStat == JNI_EVERSION) {
//            log(javaEnv, 1,"GetEnv: version not supported");
            return -1L;
        }

//    log(javaEnv, 1,"File Name : %ws ProcessId: %ws", fileName, processIdentifier);
    if (wcscmp(progressStatus, L"MaximumRead") == 0){
        log(javaEnv, 1,"Maximum Read");
        jobject progressObject = javaEnv->NewObject(progressCls, progressInit);
        jlong stepid;
        jobject vmid = javaEnv->NewObject(longclass, longclasscons, _wtoll(vmId));
        jobject processidentifier = javaEnv->NewObject(longclass, longclasscons, _wtoll(processIdentifier));
        jstring processtype = javaEnv->NewString((jchar*)processType,wcslen(processType));
        jobject zeroLongValue = javaEnv->NewObject(longclass, longclasscons, _wtoll(L"0"));
        if (wcscmp(processType, L"BACKUP") == 0){
            wchar_t *stepMsg = (wchar_t *)malloc((wcslen(L"Copying file :")+wcslen(fileName) + 1) * sizeof(wchar_t));
            wcscpy(stepMsg, L"Copying file :");
            wcscat(stepMsg, fileName);
            jstring stepMessage = javaEnv->NewString((jchar*)stepMsg,wcslen(stepMsg));
            jstring executiontime = javaEnv->NewString((jchar*)executionTime,wcslen(executionTime));
            if(wcscmp(executionTime, L"-2") != 0){   // executionTime used as a check for setting only the size and excluding the progressbar
                stepid = javaEnv->CallStaticLongMethod(virtualBackupServerUtilCls, updateBackupStep, processidentifier, stepMessage, zeroLongValue, -1, stepMessage, vmid, zeroLongValue, true);
                //to add file name and capacity to backed up details return value
            }
            jstring jcapacity = javaEnv->NewString((jchar*)value,wcslen(value));
            jstring jfileName = javaEnv->NewString((jchar*)fileName,wcslen(fileName));
            
                if(!addorRemoveDiskDetailsMethodID){
                    log(javaEnv, 1,"addorRemoveDiskDetailsMethodID not found");
                }else{
                    if(!BackupCollectionManagerClass){
                        log(javaEnv, 1,"BackupCollectionManagerClass not found");
                    }else{
                        javaEnv->CallStaticVoidMethod(BackupCollectionManagerClass,addorRemoveDiskDetailsMethodID,jfileName,jcapacity,vmid,true);
                    }
                }
                if (javaEnv->ExceptionCheck()) {
                    log(javaEnv, 1,"java exception caught addorRemoveDiskDetailsMethodID");
                }
		if(wcscmp(executionTime, L"-2") != 0){   // executionTime used as a check for setting only the size and excluding the progressbar
                    jobject stepIdLong = javaEnv->NewObject(longclass, longclasscons, stepid);
                    jobject progressManagerObject = javaEnv->CallStaticObjectMethod(progressManager, getProgressManagerMethod);        
                    javaEnv->CallObjectMethod(progressManagerObject, registerProcessMethod, processtype, stepIdLong, progressObject);
                    javaEnv->CallObjectMethod(progressObject, setMaximumMethodID, _wtoll(value));
		}

        }else if (wcscmp(processType, L"RESTORE") == 0){
            wchar_t *stepMsg = (wchar_t *)malloc((wcslen(L"Restoring file :")+wcslen(fileName) + 1) * sizeof(wchar_t));
            wcscpy(stepMsg, L"Restoring file :");
            wcscat(stepMsg, fileName);
            jstring stepMessage = javaEnv->NewString((jchar*)stepMsg,wcslen(stepMsg));
            jstring executiontime = javaEnv->NewString((jchar*)executionTime,wcslen(executionTime));
            //to get the actual capacity of the file
            if(!getFileCapacity){
                log(javaEnv, 1,"getFileCapacity not found");
                            stepid = javaEnv->CallStaticLongMethod(virtualRestoreServerUtilCls, updateRestoreStep, processidentifier, stepMessage, zeroLongValue, -1, stepMessage, vmid, zeroLongValue, false);
            }else{
                jlong actualCapacity = javaEnv->CallStaticLongMethod(hvRestoreServerCls, getFileCapacity, vmid,stepMessage);
                if(wcscmp(executionTime, L"-2") == 0){  // executionTime used as a check for obtaining the size and excluding the progressbar
                    log(javaEnv, 1,"Going to return actual capacity");
                    if (javaEnv->ExceptionCheck()) {
                        log(javaEnv, 1,"java exception caught before detach");
                    }
                    g_vm->DetachCurrentThread();
                    LeaveCriticalSection(&cs1);
                    return (long long)actualCapacity;
                }
                if(actualCapacity == _wtoll(L"-1")){
                    log(javaEnv, 1,"negative value obtained");
                    stepid = javaEnv->CallStaticLongMethod(virtualRestoreServerUtilCls, updateRestoreStep, processidentifier, stepMessage, zeroLongValue, -1, stepMessage, vmid, zeroLongValue, false);
                }else{
                    stepid = javaEnv->CallStaticLongMethod(virtualRestoreServerUtilCls, updateRestoreStep, processidentifier, stepMessage, zeroLongValue, -1, stepMessage, vmid, zeroLongValue, true);
                    jobject stepIdLong = javaEnv->NewObject(longclass, longclasscons, stepid);
                    jobject progressManagerObject = javaEnv->CallStaticObjectMethod(progressManager, getProgressManagerMethod);        
                    javaEnv->CallObjectMethod(progressManagerObject, registerProcessMethod, processtype, stepIdLong, progressObject);
                    javaEnv->CallObjectMethod(progressObject, setMaximumMethodID,actualCapacity); 
                }
                            
            }
           
        } 

        if (javaEnv->ExceptionCheck()) {
            log(javaEnv, 1,"java exception caught before detach");
        }
    
        g_vm->DetachCurrentThread();
        LeaveCriticalSection(&cs1);
        return (long long)stepid;
    }else if(wcscmp(progressStatus, L"CurrentRead") == 0){
//        log(javaEnv, 1,"Current Read");
         jobject progressManagerObject = javaEnv->CallStaticObjectMethod(progressManager, getProgressManagerMethod);        
         jstring processtype = javaEnv->NewString((jchar*)processType,wcslen(processType));
         jobject stepIdLong = javaEnv->NewObject(longclass, longclasscons, _wtoll(stepId));

        //get the progressobject from stepid
        
         jobject progressObjectGbl;
//        log(javaEnv, 1,"Step id sent : %ws", stepId);
        progressObjectGbl = javaEnv->CallObjectMethod(progressManagerObject, getProgressMethod, processtype, stepIdLong);
        if(progressObjectGbl != nullptr){
//            log(javaEnv, 1,"current read... %ws",value);
            javaEnv->CallObjectMethod(progressObjectGbl, setProgressMethodID, _wtoll(value));
        }else{
            log(javaEnv, 1,"null value");
        }
    }else if(wcscmp(progressStatus, L"ReadCompleted") == 0){
        log(javaEnv, 1,"Read completed");
        jobject vmid = javaEnv->NewObject(longclass, longclasscons, _wtoll(vmId));
        jobject executiontime = javaEnv->NewObject(longclass, longclasscons, _wtoll(executionTime));
        jobject processidentifier = javaEnv->NewObject(longclass, longclasscons, _wtoll(processIdentifier));
        jobject stepIdLong = javaEnv->NewObject(longclass, longclasscons, _wtoll(stepId));
        jstring processtype = javaEnv->NewString((jchar*)processType,wcslen(processType));
        jobject progressManagerObject = javaEnv->CallStaticObjectMethod(progressManager, getProgressManagerMethod);  
        javaEnv->CallObjectMethod(progressManagerObject, processCompletedMethod, processtype, stepIdLong);
        if (wcscmp(processType, L"BACKUP") == 0){
            wchar_t *stepMsg = (wchar_t *)malloc((wcslen(L"Copying completed for file:")+wcslen(fileName) + 1) * sizeof(wchar_t));
            wcscpy(stepMsg, L"Copying completed for file:");
            wcscat(stepMsg, fileName);
            jstring stepMessage = javaEnv->NewString((jchar*)stepMsg,wcslen(stepMsg));
            javaEnv->CallStaticLongMethod(virtualBackupServerUtilCls, updateBackupStep, processidentifier, stepMessage, executiontime, 1, stepMessage, vmid, stepIdLong, true);
        }else if (wcscmp(processType, L"RESTORE") == 0){
            wchar_t *stepMsg = (wchar_t *)malloc((wcslen(L"Restoring completed for file:")+wcslen(fileName) + 1) * sizeof(wchar_t));
            wcscpy(stepMsg, L"Restoring completed for file:");
            wcscat(stepMsg, fileName);
            jstring stepMessage = javaEnv->NewString((jchar*)stepMsg,wcslen(stepMsg));
            javaEnv->CallStaticLongMethod(virtualRestoreServerUtilCls, updateRestoreStep, processidentifier, stepMessage, executiontime, 1, stepMessage, vmid, stepIdLong, true);
        }
        LeaveCriticalSection(&cs1);
        return 0L;
    }
    if (javaEnv->ExceptionCheck()) {
        log(javaEnv, 1,"java exception caught before detach");
    }

    if(isAttached){
        g_vm->DetachCurrentThread();
    }
    LeaveCriticalSection(&cs1);
    return 0L;
}

wchar_t* CallbackCommon(wchar_t *functionName, wchar_t *parameters)
{
	EnterCriticalSection(&cs1);
    bool isAttached = false;
    int getEnvStat = g_vm->GetEnv((void **)&javaEnv, JNI_VERSION_1_4);
	if (getEnvStat == JNI_EDETACHED) {
            //log(javaEnv, 1,"GetEnv: not attached");
		if (g_vm->AttachCurrentThread((void **) &javaEnv, NULL) != 0) {
            //log(javaEnv, 1,"Failed to attach");
            return L"-1";
		}
		else{
            isAttached = true;
		}
	} else if (getEnvStat == JNI_OK) {
        //log(javaEnv, 1,"before file capcity add");
    } else if (getEnvStat == JNI_EVERSION) {
        //log(javaEnv, 1,"GetEnv: version not supported");
        return L"-1";
    }
    log(javaEnv, 1,"CallBack Callled : %ws-%ws\n", functionName, parameters);
    jstring jfunctionName = javaEnv->NewString((jchar*)functionName, wcslen(functionName));
    jstring jparameters = javaEnv->NewString((jchar*)parameters, wcslen(parameters));
    jstring jcallbackret = (jstring)javaEnv->CallStaticObjectMethod(virtualMachineUtilCls, javaCommonCallBackMethod, jfunctionName, jparameters);
    LPWSTR callbackret= (LPWSTR)javaEnv->GetStringChars(jcallbackret, NULL);
    log(javaEnv, 1,"CallBack success. Return value : %ws\n", callbackret);
    if (javaEnv->ExceptionCheck()) {
        log(javaEnv, 1,"Caught java exception before Detach");
    }
    if(isAttached){
        g_vm->DetachCurrentThread();
    }
	int size = wcslen(callbackret) + 1;
    wchar_t * retVal = (wchar_t *)malloc(size * sizeof(wchar_t));
    wcscpy(retVal, callbackret);
    wcscat(retVal, L"\0");
    LeaveCriticalSection(&cs1);
    return retVal;
}

/******************************************************/
/*         MIDL allocate and free                     */
/******************************************************/
 
void __RPC_FAR * __RPC_USER midl_user_allocate(size_t len)
{
    return(malloc(len));
}
 
void __RPC_USER midl_user_free(void __RPC_FAR * ptr)
{
    free(ptr);
}
