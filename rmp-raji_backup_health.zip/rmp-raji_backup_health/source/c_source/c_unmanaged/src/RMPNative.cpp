//$Id: RMPNative.cpp,v 1.0 2015/10/14 12:07:09 lucky.k Exp $

#include <RMPNative.h>
#include <jni/com_manageengine_rmp_jni_RMPNativeManager.h>
#include <fstream>
#include <iostream>
#include <util/BMRFileLevelRestore.h>
#include <util/DLLVersionCheck.h>
#include <util/RemoteFileAccess.h>
#include <util/AllDCs.h>
#include <util/CheckCredentials.h>
#include <util/BMR_RPCAgentc.h>

using namespace std;

void log(JNIEnv *env, int level, const char* message, ...) {
    va_list args;
    int len;
    jint jlevel = (jint) level;
    char * buffer;
    va_start(args, message);
    len = _vscprintf(message, args) + 1;
    buffer = (char*) malloc(len * sizeof (char));
    vsprintf(buffer, message, args);
    jstring jsMessage = env->NewStringUTF(buffer);
    env->CallStaticVoidMethod(LogClass, LogID, jlevel, jsMessage);
    free(buffer);
}

JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_jni_RMPNativeManager_GetDotNetFrameworkRegValue(JNIEnv *env, jclass obj) {
    log(env, 1, "GetDotNetFrameworkRegValue Start 1");
    return GetDotNetFrameworkRegValue(env);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPNativeManager_RemoteFileAccessAdd(JNIEnv *env, jclass obj, jstring remotePath, jstring userName, jstring password) {
    log(env, 1, "RemoteFileAccessAdd Start 1");
    return RemoteFileAccessAdd(env, remotePath, userName, password);
}

JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_jni_RMPNativeManager_checkCredentials(JNIEnv *env, jclass obj, jstring loc, jstring user, jstring pass, jstring connDisconn) {
    log(env, 1, "checkCredentials Start 1");
    return checkCredentials(env, loc, user, pass, connDisconn);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPNativeManager_RemoteFileAccessClose(JNIEnv *env, jclass obj, jstring remotePath) {
    log(env, 1, "RemoteFileAccessAdd Start 1");
    return RemoteFileAccessClose(env, remotePath);
}

JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_jni_RMPNativeManager_getAllDCs(JNIEnv *env, jclass obj, jstring domain, jstring juserDomain, jstring user, jstring pass, jstring dcToBind) {
    log(env, 1, "getAllDCs Start 1");
    return getAllDCs(env, domain, juserDomain, user, pass, dcToBind);
}

JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_jni_RMPNativeManager_getAllServers(JNIEnv *env, jclass obj, jstring domain, jstring user, jstring pass, jstring dcToBind) {
    log(env, 1, "getAllServers Start 1");
    return getAllServers(env, domain, user, pass, dcToBind);
}

JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_jni_RMPNativeManager_getAllEndPoints(JNIEnv *env, jclass obj, jstring domain, jstring user, jstring pass, jstring dcToBind) {
    log(env, 1, "getAllEndPoints Start 1");
    return getAllEndPoints(env, domain, user, pass, dcToBind);
}

JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_jni_RMPNativeManager_triggerBackup(JNIEnv *env, jclass obj, jstring dc, jstring domain, jstring user, jstring pwd, jstring loc, jstring locUser, jstring locPwd, jstring code, jstring filesList, jint encypted, jstring encrPwd) {
    log(env, 1, "triggerBackup Start 1");
    return triggerBackup(env, dc, domain, user, pwd, loc, locUser, locPwd, code, filesList, encypted, encrPwd);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPNativeManager_getCurrentDiskCnt(JNIEnv *env, jclass obj, jstring dcName, jstring domain, jstring user, jstring pwd) {
    log(env, 1, "getCurrentDiskCnt Start 1");
    return getCurrentDiskCnt(env, dcName, domain, user, pwd);
}

JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_jni_RMPNativeManager_getDCOsInfo(JNIEnv *env, jclass obj, jstring domain, jstring user, jstring pass, jstring dcToBind) {
	log(env, 1, "getDCOsInfo Start 1");
    return getDCOsInfo(env, domain, user, pass, dcToBind);
}

JNIEXPORT jint JNICALL Java_com_manageengine_rmp_jni_RMPNativeManager_performFLR(JNIEnv *env, jclass obj, jint type, jint mode, jstring dc, jstring domUser, jstring domPwd, jstring rep, jstring repUser, jstring repPwd, jstring filesList,jstring ibFilesList, jstring driveMap, jstring dwnld, jstring restoreFile, jstring fbUser, jstring fbPwd, jstring renameFilesList, jboolean encypted, jstring encrPwd) {
    log(env, 1, "performFLR Start 1");
    return performFLR(env, type, mode, dc, domUser, domPwd, rep, repUser, repPwd, filesList, ibFilesList, driveMap, dwnld, restoreFile, fbUser, fbPwd, renameFilesList, encypted, encrPwd);
}

JNIEXPORT jobject JNICALL Java_com_manageengine_rmp_jni_RMPNativeManager_performVLR(JNIEnv *env, jclass obj, jstring dc, jstring domain, jstring user, jstring pwd, jstring loc, jstring locUser, jstring locPwd, jstring jFilesList, jint type, jstring mergePath, jstring mergeUser, jstring mergePwd,jstring restoreLog, jint encypted, jstring encrPwd) {
    log(env, 1, "performVLR Start 1");
    return performVLR(env, dc, domain, user, pwd, loc, locUser, locPwd, jFilesList, type, mergePath, mergeUser, mergePwd,restoreLog, encypted, encrPwd);
}
