﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Net;
using System.IO;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;
using BOOL = System.Boolean;
using DWORD = System.UInt32;
using LPWSTR = System.String;
using NET_API_STATUS = System.UInt32;

namespace HVService64
{
    public partial class HVService64Service : ServiceBase
    {
        private Thread thread;
        string[] details = new string[6];
        Process p1 = new Process();
       

        [DllImport("HVRPC64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void call_start();
        [DllImport("HVRPC64.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void call_stop();
        
        public HVService64Service()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            thread = new Thread(executeCode);
            thread.Start();           
            Library.WriteErrorLog("RMPHVBackup Service started");
        }

        private void executeCode()
        {
            try
            {
                call_start();
            }
            catch (Exception e)
            {
                Library.WriteErrorLog(e.ToString());
            }
        }
        

        protected override void OnStop()
        {
            try
            {
                call_stop();
                Library.WriteErrorLog("RMPHVBackup Service stopped");
            }
            catch (Exception e)
            {
                Library.WriteErrorLog(e.ToString());
            }
        }
    }
}
