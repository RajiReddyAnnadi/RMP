#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <Shlwapi.h>
#include "hypervserviceconnector64.h"
#include <windows.h>
#include <sys/timeb.h>
#include <tchar.h>

typedef int(*connecttoRepository)(wchar_t *repositoryDetailsJson, wchar_t *connectStatus);
typedef int(*encryptdecrypt)(wchar_t *repositoryPath, wchar_t *scheduleName, wchar_t *backupName, wchar_t *vmName, int operation, wchar_t *pszPassword);
typedef int(*copyVMfilesfromVSSSnapshotCall)(wchar_t *hypervHostName, wchar_t *backupVM, wchar_t* backupType, wchar_t *repositoryPath, wchar_t *backupName, wchar_t *scheduleName, wchar_t *vmId,
            long long(*callBackMethod)(wchar_t, wchar_t, wchar_t, wchar_t, wchar_t, wchar_t, wchar_t, wchar_t));
typedef int(*PerformHypervbackup)(wchar_t *hypervHostName, wchar_t *fullbackupVMs, wchar_t* incrementalbackupVMs, wchar_t *repositoryPath, wchar_t *backupName, wchar_t *scheduleName, wchar_t* isanyVHDchanged);
typedef int(*PerformHypervrestore)(wchar_t* hypervHostName, wchar_t* vmName, wchar_t* vmfullbackupPath, wchar_t* vmincrementalbackupPaths, wchar_t* ischangeVMName, wchar_t* newVMName, 
	wchar_t* VHDnewstorageLocation, wchar_t* isPowerOn, wchar_t* isEncrypted, wchar_t* isdecryptionSuccessful, wchar_t* vmid, long long(*callBackMethod)(wchar_t, wchar_t, wchar_t, wchar_t, wchar_t, wchar_t, wchar_t, wchar_t), wchar_t* paramsjson, wchar_t *restoreFormatString);
typedef int(*generateHash)(wchar_t *repositoryPath, wchar_t *scheduleName, wchar_t *backupName, wchar_t *vmName, wchar_t *backupType, wchar_t *isEncrypted, wchar_t* encryptPassword);
typedef int(*PerformHyperVHealthCheck)(wchar_t* hypervHostName, wchar_t* healthCheckParametersJson, wchar_t* vmBackupDetailsJson, wchar_t*(*commonCallBackMethod)(wchar_t*, wchar_t*));
void loggerwrite(FILE* logFile, const wchar_t* message, va_list* args)
{
	int len;
	wchar_t* buffer;

	len = _vscwprintf(message, *args) + 1;
	len += 40; // some more space for timestamp and thread ID
	buffer = (wchar_t*)malloc(len * sizeof(wchar_t));
	struct __timeb64 timebuffer;
	_ftime64(&timebuffer);
	wchar_t* timeline = _wctime64(&timebuffer.time);
	fwprintf(logFile, L"%.15ws: ", (timeline + 4));
	fwprintf(logFile, L"%ld -> ", GetCurrentThreadId());

	vswprintf(buffer, len, message, *args);
	fwprintf(logFile, L"%ws\n", buffer);
	//fwprintf(logFile, L"%ws\n", message);
	fflush(logFile);
	free(buffer);
}

void logger(LPWSTR logFileName, const wchar_t* message, ...)
{
	FILE* logFile;
	if (!(logFile = _wfopen(logFileName, L"a+")))
	{
		WCHAR drive[_MAX_DRIVE], dir[_MAX_DIR];
		_tsplitpath(logFileName, drive, dir, NULL, NULL);
		wchar_t *dirFullPath = (wchar_t *)malloc(wcslen(drive) + wcslen(dir) + 1);
		_tcscpy(dirFullPath, drive);
		_tcscat(dirFullPath, dir);
		if (_tcscmp(dirFullPath, L"") != 0)
		if (GetFileAttributes(dirFullPath) == INVALID_FILE_ATTRIBUTES)							//if the given log file dir doesn't exists
			CreateDirectory(dirFullPath, NULL);												//create one
		logFile = _wfopen(logFileName, L"a+");

		if (dirFullPath != NULL)	free(dirFullPath);
	}

	if (NULL == logFile)
	{
		return;
	}
	va_list args;
	va_start(args, message);
	loggerwrite(logFile, message, &args);
	fclose(logFile);
}

long long callBackFunction(wchar_t *processType, wchar_t *stepId, wchar_t *processIdentifier, wchar_t *vmId, wchar_t *fileName, wchar_t *progressStatus, wchar_t *value, wchar_t *executionTime)
{
	long long retStepId = 0L;
	wchar_t* logFile = L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\RPCLogger.txt";
	//logger(logFile, L"callBackFunction called0...%ws : %ws : %ws : %ws : %ws : %ws : %ws : %ws", processType, stepId, processIdentifier, vmId, fileName, progressStatus, value, executionTime);
	retStepId = CallbackProc(processType, stepId, processIdentifier, vmId, fileName, progressStatus, value, executionTime);
	//logger(logFile, L"callBackFunction called1...: %lld", retStepId);
	return retStepId;
}

wchar_t* commonCallBackFunction(wchar_t *id, wchar_t *parameters)
{
	//int retVal = 0;
	wchar_t* logFile = L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\RPCLogger.txt";
	//logger(logFile, L"commonCallBackFunction called0...%ws : %ws\n", id, parameters);
	wchar_t* retVal = CallbackCommon(id, parameters);
	//logger(logFile, L"commonCallBackFunction called1...%ws\n", retVal);
	return retVal;
}

int connecttobackupRepository(LPWSTR logFile, LPWSTR repositoryDetailsJson, LPWSTR connectStatus)
{
	int retVal = 0;
	logger(logFile, L"Going to call connecttorepository");
	connecttoRepository repoConnection;
	HINSTANCE hGetProcIDDLL = LoadLibrary(L"HVBackup.dll");
	if (!hGetProcIDDLL)
	{
		logger(logFile, L"connecttorepository Load DLL failed..!");
		return -1;
	}
	repoConnection = (connecttoRepository)GetProcAddress(hGetProcIDDLL, "connecttoRepository");
	if (!repoConnection)
	{
		FreeLibrary(hGetProcIDDLL);
		logger(logFile, L"connecttorepository connecting to connecttoRepository method FAILED..!");
		return -1;
	}
	retVal = repoConnection(repositoryDetailsJson, connectStatus);
	if (retVal != 0)
	{
		FreeLibrary(hGetProcIDDLL);
		logger(logFile, L"connecttorepository connecting to connecttoRepository FAILED..!retVal -> %d", retVal);
		return -1;
	}
	FreeLibrary(hGetProcIDDLL);
	logger(logFile, L"connecttorepository connecting to connecttoRepository Return value -> %d..!", retVal);
	return retVal;
}

int encryptdecryptRPC(LPWSTR logFile, LPWSTR repositoryPath, LPWSTR scheduleName, LPWSTR backupName, LPWSTR vmName, int operation, LPWSTR pszPassword)
{
	int retVal = 0;
	logger(logFile, L"Going to call encryptdecrypt");
	encryptdecrypt encryptdecryptpointer;
	HINSTANCE hGetProcIDDLL = LoadLibrary(L"HVBackup.dll");
	if (!hGetProcIDDLL)
	{
		logger(logFile, L"encryptdecrypt Load DLL failed..!");
		return -1;
	}
	encryptdecryptpointer = (encryptdecrypt)GetProcAddress(hGetProcIDDLL, "encryptdecrypt");
	if (!encryptdecryptpointer)
	{
		FreeLibrary(hGetProcIDDLL);
		logger(logFile, L"encryptdecrypt connecting to encryptdecrypt method FAILED..!");
		return -1;
	}
	retVal = encryptdecryptpointer(repositoryPath, scheduleName, backupName, vmName, operation, pszPassword);
	if (retVal != 0)
	{
		FreeLibrary(hGetProcIDDLL);
		logger(logFile, L"encryptdecrypt connecting to encryptdecrypt FAILED..!retVal -> %d", retVal);
		return -1;
	}
	FreeLibrary(hGetProcIDDLL);
	logger(logFile, L"encryptdecrypt connecting to encryptdecrypt Return value -> %d..!", retVal);
	return retVal;
}

int generateHashforBackupRepository(LPWSTR logFile, LPWSTR repositoryPath, LPWSTR scheduleName, LPWSTR backupName, LPWSTR vmName, LPWSTR backupType, LPWSTR isEncrypted, LPWSTR encryptPassword)
{
	int retVal = 0;
	logger(logFile, L"Going to call generateHash");
	generateHash generateHashpointer;
	HINSTANCE hGetProcIDDLL = LoadLibrary(L"HVBackup.dll");
	if (!hGetProcIDDLL)
	{
		logger(logFile, L"generateHash Load DLL failed..!");
		return 457;
	}
	generateHashpointer = (generateHash)GetProcAddress(hGetProcIDDLL, "generateHash");
	if (!generateHashpointer)
	{
		FreeLibrary(hGetProcIDDLL);
		logger(logFile, L"generateHashforBackupRepository connecting to generateHash method FAILED..!");
		return 457;
	}
	retVal = generateHashpointer(repositoryPath, scheduleName, backupName, vmName, backupType, isEncrypted, encryptPassword);
	FreeLibrary(hGetProcIDDLL);
	logger(logFile, L"generateHashforBackupRepository calling generateHash Method Return value -> %d..!", retVal);
	return retVal;
}

int callPerformHyperVHealthCheck(LPWSTR logFile, LPWSTR hypervHostName, LPWSTR healthCheckParametersJson, LPWSTR vmBackupDetailsJson)
{
	int retVal = 0;
	logger(logFile, L"Going to call PerformHealthCheck");
	PerformHyperVHealthCheck PerformHyperVHealthCheckpointer;
	HINSTANCE hGetProcIDDLL = LoadLibrary(L"HVBackup.dll");
	if (!hGetProcIDDLL)
	{
		logger(logFile, L"PerformHealthCheck Load DLL failed..!");
		return 464;
	}
	PerformHyperVHealthCheckpointer = (PerformHyperVHealthCheck)GetProcAddress(hGetProcIDDLL, "PerformHyperVHealthCheck");
	if (!PerformHyperVHealthCheckpointer)
	{
		FreeLibrary(hGetProcIDDLL);
		logger(logFile, L"callPerformHealthCheck connecting to PerformHealthCheck method FAILED..!");
		return 464;
	}
	retVal = PerformHyperVHealthCheckpointer(hypervHostName, healthCheckParametersJson, vmBackupDetailsJson, commonCallBackFunction);
	FreeLibrary(hGetProcIDDLL);
	logger(logFile, L"callPerformHealthCheck calling PerformHealthCheck Method Return value -> %d..!", retVal);
	return retVal;
}

void performstartOperationsonDriver()
{
	wchar_t* logFile = L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\RPCLogger.txt";
	logger(logFile, L"performstartOperationsonDriver started...");
	wchar_t *operation = L"startDriver";
	int length = wcslen(L"HVDriverManager.exe ") + wcslen(operation);
	length = length + 5;
	wchar_t *cmdbuf = (wchar_t *)malloc(length * sizeof(wchar_t));

	wcscpy(cmdbuf, L"HVDriverManager.exe ");
	wcscat(cmdbuf, L"\"");
	wcscat(cmdbuf, operation);
	wcscat(cmdbuf, L"\"");
	wcscat(cmdbuf, L"\0");
	STARTUPINFO info = { sizeof(info) };
	PROCESS_INFORMATION processInfo;
	BOOL isProcessCreated = CreateProcess(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\HVDriverManager.exe", cmdbuf, NULL, NULL, TRUE, 0, NULL, NULL, &info, &processInfo);
	if (isProcessCreated)
	{
		logger(logFile, L"CreateProcess completed TRUE...");
	}
	else
	{
		logger(logFile, L"CreateProcess completed FALSE...");
	}

}

void startServer()
{
	RPC_STATUS status;
	RPC_WSTR pszProtocolSequence = (unsigned short *)L"ncacn_np";
	RPC_WSTR pszSecurity = NULL;
	RPC_WSTR pszEndpoint = (unsigned short *)L"\\pipe\\HV_RPCAgent";
	unsigned int    cMinCalls = 1;
	unsigned int    fDontWait = FALSE;

	performstartOperationsonDriver();

	status = RpcServerUseProtseqEp(pszProtocolSequence,
		RPC_C_LISTEN_MAX_CALLS_DEFAULT,
		pszEndpoint,
		pszSecurity);

	if (status) return;

	status = RpcServerRegisterIfEx(hypervserviceconnector_v1_0_s_ifspec,
		NULL,
		NULL,
		RPC_IF_ALLOW_CALLBACKS_WITH_NO_AUTH,
		RPC_C_LISTEN_MAX_CALLS_DEFAULT, NULL);


	if (status) return;
	status = RpcServerListen(cMinCalls,
		RPC_C_LISTEN_MAX_CALLS_DEFAULT,
		fDontWait);

	if (status) return;
}

void HVShutdown()
{
	RPC_STATUS status;

	status = RpcMgmtStopServerListening(NULL);

	if (status)
	{
		return;
	}

	status = RpcServerUnregisterIf(NULL, NULL, FALSE);

	if (status)
	{
		return;
	}
}

/******************************************************/
/*         MIDL allocate and free                     */
/******************************************************/

void __RPC_FAR * __RPC_USER midl_user_allocate(size_t len)
{
	return(malloc(len));
}

void __RPC_USER midl_user_free(void __RPC_FAR * ptr)
{
	free(ptr);
}


int HyperVBackup(
	wchar_t *userName,
	wchar_t *password,
	wchar_t *hypervHostName,
	wchar_t *fullbackupVMs,
	wchar_t *incrementalbackupVMs,
	wchar_t *repositoryPath,
	wchar_t *backupName,
	wchar_t *scheduleName,
	wchar_t *repositoryDetailsJson,
	wchar_t *isanyVHDchanged)
{
	wchar_t* logFile = L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\RPCLogger.txt";
	logger(logFile, L"HyperVBackup started...");
	logger(logFile, L"Details:\nUsername: %ws\nHostName: %ws\nfullbackupVMs: %ws\nincrementalbackupVMs: %ws\nrepositoryPath: %ws\nbackupName: %ws\nscheduleName: %ws\nisanyVHDchanged: %ws\n", userName, hypervHostName, fullbackupVMs, incrementalbackupVMs, repositoryPath, backupName, scheduleName, isanyVHDchanged);
	DWORD dwRetVal;
	NETRESOURCE nr;
	DWORD dwFlags;
	int retVal=0;
	int fFreeDLL;
	//wchar_t buffer[MAX_PATH];

	memset(&nr, 0, sizeof (NETRESOURCE));

	nr.dwType = RESOURCETYPE_ANY;
	nr.lpRemoteName = hypervHostName;
	nr.lpProvider = NULL;
	dwFlags = CONNECT_TEMPORARY;
	if (wcscmp(userName, L"-") == 0)
	{
		dwRetVal = WNetAddConnection2(&nr, NULL, NULL, dwFlags);
	}
	else
	{
		dwRetVal = WNetAddConnection2(&nr, password, userName, dwFlags);
	}
	
	if (dwRetVal == NO_ERROR || dwRetVal == 1219)
	{
		logger(logFile, L"WNetAddConnection2 No error");

		wchar_t *operation = L"performBackup";
		int length = wcslen(L"HVDriverManager.exe ") + wcslen(operation) + wcslen(hypervHostName) + wcslen(fullbackupVMs) + wcslen(incrementalbackupVMs) + wcslen(repositoryPath) + wcslen(backupName) + wcslen(scheduleName) + wcslen(isanyVHDchanged);
		length = length + 40;
		wchar_t *cmdbuf = (wchar_t *)malloc(length * sizeof(wchar_t));
		
		wcscpy(cmdbuf, L"HVDriverManager.exe ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, operation);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L" ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, hypervHostName);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L" ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, fullbackupVMs);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L" ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, incrementalbackupVMs);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L" ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, repositoryPath);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L" ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, backupName);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L" ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, scheduleName);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L" ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, isanyVHDchanged);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L"\0");

		
		STARTUPINFO info = { sizeof(info) };
		PROCESS_INFORMATION processInfo;

		BOOL isProcessCreated = TRUE;
		if (wcscmp(userName, L"-") == 0)
		{
			logger(logFile, L"Going to call connecttobackupRepository..!");
			int repoStatus = connecttobackupRepository(logFile, repositoryDetailsJson, L"connect");
			if (repoStatus != 0)
			{
				free(cmdbuf);
				logger(logFile, L"connecttobackupRepository returned ERROR -> %d..!", repoStatus);
				return 401;
			}
			else
			{
				logger(logFile, L"connecttobackupRepository returned SUCCESS -> .!");
			}
			logger(logFile, L"Finished calling connecttobackupRepository..!");
			logger(logFile, L"CreateProcess with NULL credentials...");
			isProcessCreated = CreateProcess(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\HVDriverManager.exe", cmdbuf, NULL, NULL, TRUE, 0, NULL, NULL, &info, &processInfo);
			logger(logFile, L"CreateProcess STATUS -> %d", isProcessCreated);
		}
		else
		{
			logger(logFile, L"CreateProcess with EXPLICIT credentials...");
			wchar_t *domainalone = NULL;
			wchar_t *useralone = NULL;			
			domainalone = wcstok_s(userName, L"\\", &useralone);
			logger(logFile, L"Username: %ws, Domain Name: %ws", useralone, domainalone);
			HANDLE hToken;
			LPVOID lpvEnv;
			DWORD dwSize;
			WCHAR szUserProfile[256] = L"";
			if (!LogonUser(useralone, domainalone, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &hToken))
			{
				logger(logFile, L"LogonUser FAILED -> %d", GetLastError());
			}
			else
			{
				logger(logFile, L"LogonUser SUCCESS!!!");
			}
			if (!ImpersonateLoggedOnUser(hToken))
			{
				logger(logFile, L"ImpersonateLoggedOnUser FAILED -> %d", GetLastError());
			}
			else
			{
				logger(logFile, L"ImpersonateLoggedOnUser SUCCESS!!!");
			}
			logger(logFile, L"Going to call connecttobackupRepository..!");
			int repoStatus = connecttobackupRepository(logFile, repositoryDetailsJson, L"connect");
			if (repoStatus != 0)
			{
				free(cmdbuf);
				logger(logFile, L"connecttobackupRepository returned ERROR -> %d..!", repoStatus);
				return 401;
			}
			else
			{
				logger(logFile, L"connecttobackupRepository returned SUCCESS -> .!");
			}
			logger(logFile, L"Finished calling connecttobackupRepository..!");
			isProcessCreated = CreateProcessAsUser(hToken, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\HVDriverManager.exe", cmdbuf, NULL, NULL, TRUE, 0, NULL, NULL, &info, &processInfo);
			logger(logFile, L"CreateProcess STATUS -> %d", isProcessCreated);
		}
		if (isProcessCreated)
		{
			logger(logFile, L"CreateProcess Waiting...........................");
			WaitForSingleObject(processInfo.hProcess, INFINITE);
			LPDWORD exitCode=0;
			GetExitCodeProcess(processInfo.hProcess, &exitCode);
			retVal = (int)exitCode;
			logger(logFile, L"CreateProcess return value from method -> %d", retVal);
			/*if (retVal == 255)
			{
				retVal = 0;
			}*/
			CloseHandle(processInfo.hProcess);
			CloseHandle(processInfo.hThread);
		}
		else
		{
			logger(logFile, L"CreateProcess actual error -> %d, Returning 601", GetLastError());
			retVal = 601;
		}
		if (wcscmp(userName, L"-") != 0)
		{
			logger(logFile, L"Reverting to self since Impersonation was used..!");
			BOOL isSelfReverted = RevertToSelf();
			if (isSelfReverted)
			{
				logger(logFile, L"RevertToSelf Successful!");
			}
			else
			{
				logger(logFile, L"RevertToSelf Failure!");
			}
		}
		free(cmdbuf);
		dwRetVal = WNetCancelConnection2(hypervHostName, 0, TRUE);
	}
	else
	{
		logger(logFile, L"WNetAddConnection2 error -> %ld", dwRetVal);
		retVal = 602;
	}
	logger(logFile, L"Rpc Return Value ->  %d", retVal);
	return retVal;
}

int HyperVdoCBToperationsforschedule(wchar_t *userName, wchar_t *password, wchar_t *hypervHostName, wchar_t *scheduleName, wchar_t *allVMIds)
{
	wchar_t* logFile = L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\RPCLogger.txt";

	logger(logFile, L"Rpc HyperVdoCBToperationsforschedule started");
	logger(logFile, L"HyperVdoCBToperationsforschedule Details:\nUsername: %ws\nHostName: %ws\nscheduleName: %ws\nallVMIds: %ws", userName, hypervHostName, scheduleName, allVMIds);

	DWORD dwRetVal;
	NETRESOURCE nr;
	DWORD dwFlags;
	int retVal=0;
	int fFreeDLL;
	//wchar_t buffer[MAX_PATH];

	memset(&nr, 0, sizeof (NETRESOURCE));
	nr.dwType = RESOURCETYPE_ANY;
	nr.lpRemoteName = hypervHostName;
	nr.lpProvider = NULL;
	dwFlags = CONNECT_TEMPORARY;
	if (wcscmp(userName, L"-") == 0)
	{
		dwRetVal = WNetAddConnection2(&nr, NULL, NULL, dwFlags);
	}
	else
	{
		dwRetVal = WNetAddConnection2(&nr, password, userName, dwFlags);
	}
	if (dwRetVal == NO_ERROR || dwRetVal == 1219)
	{
		logger(logFile, L"WNetAddConnection2 No error");

		wchar_t *operation = L"newSchedule";
		int length = wcslen(L"HVDriverManager.exe ") + wcslen(operation) + wcslen(hypervHostName) + wcslen(scheduleName) + wcslen(allVMIds) + 20;
		wchar_t *cmdbuf = (wchar_t *)malloc(length * sizeof(wchar_t));
		

		wcscpy(cmdbuf, L"HVDriverManager.exe ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, operation);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L" ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, hypervHostName);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L" ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, scheduleName);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L" ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, allVMIds);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L"\0");

		

		STARTUPINFO info = { sizeof(info) };
		PROCESS_INFORMATION processInfo;
		BOOL isProcessCreated = TRUE;
		if (wcscmp(userName, L"-") == 0)
		{
			logger(logFile, L"CreateProcess with NULL credentials...");
			isProcessCreated = CreateProcess(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\HVDriverManager.exe", cmdbuf, NULL, NULL, TRUE, 0, NULL, NULL, &info, &processInfo);
			logger(logFile, L"CreateProcess STATUS -> %d", isProcessCreated);
		}
		else
		{
			logger(logFile, L"CreateProcess with EXPLICIT credentials...");
			wchar_t *domainalone = NULL;
			wchar_t *useralone = NULL;
			domainalone = wcstok_s(userName, L"\\", &useralone);
			logger(logFile, L"Username: %ws, Domain Name: %ws", useralone, domainalone);
			HANDLE hToken;
			LPVOID lpvEnv;
			DWORD dwSize;
			WCHAR szUserProfile[256] = L"";
			if (!LogonUser(useralone, domainalone, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &hToken))
			{
				logger(logFile, L"LogonUser FAILED -> %d", GetLastError());
			}
			else
			{
				logger(logFile, L"LogonUser SUCCESS!!!");
			}
			if (!ImpersonateLoggedOnUser(hToken))
			{
				logger(logFile, L"ImpersonateLoggedOnUser FAILED -> %d", GetLastError());
			}
			else
			{
				logger(logFile, L"ImpersonateLoggedOnUser SUCCESS!!!");
			}
			//isProcessCreated = CreateProcessWithLogonW(useralone, domainalone, password, 0, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\HVDriverManager.exe", cmdbuf, 0, 0, NULL, &info, &processInfo);
			isProcessCreated = CreateProcessAsUser(hToken, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\HVDriverManager.exe", cmdbuf, NULL, NULL, TRUE, 0, NULL, NULL, &info, &processInfo);
			logger(logFile, L"CreateProcess STATUS -> %d", isProcessCreated);
		}

		if (isProcessCreated)
		{
			logger(logFile, L"CreateProcess Waiting...........................%ws", cmdbuf);
			WaitForSingleObject(processInfo.hProcess, INFINITE);
			LPDWORD exitCode = 0;
			GetExitCodeProcess(processInfo.hProcess, &exitCode);
			retVal = (int)exitCode;
			logger(logFile, L"CreateProcess return value from method -> %d", retVal);
			CloseHandle(processInfo.hProcess);
			CloseHandle(processInfo.hThread);
		}
		else
		{
			logger(logFile, L"CreateProcess error 601");
			retVal = 601;
		}
		if (wcscmp(userName, L"-") != 0)
		{
			logger(logFile, L"Reverting to self since Impersonation was used..!");
			BOOL isSelfReverted = RevertToSelf();
			if (isSelfReverted)
			{
				logger(logFile, L"RevertToSelf Successful!");
			}
			else
			{
				logger(logFile, L"RevertToSelf Failure!");
			}
		}
		free(cmdbuf);
		dwRetVal = WNetCancelConnection2(hypervHostName, 0, TRUE);
	}
	else
	{
		logger(logFile, L"Error in  WNetAddConnection2-> %ld", dwRetVal);
		retVal = 602;
	}
	logger(logFile, L"Rpc Return Value ->  %d", retVal);
	return retVal;

}

int HyperVRestore(
	wchar_t *domainuserName,
	wchar_t *password,
	wchar_t *hypervHostName,
	wchar_t *vmtoRestore,
	wchar_t *vmfullbackupPathstring,
	wchar_t *vmincrementalbackupPathsList,
	wchar_t *LischangeVMName,
	wchar_t *LnewVMName,
	wchar_t *LVHDnewstorageLocation,
	wchar_t *LrepositoryDetailsJson,
	wchar_t *isPowerOnString,
	wchar_t *isEncrypted,
	wchar_t *encryptPassword,
	wchar_t *vmId,
	wchar_t *restoreId,
	wchar_t *Lparamsjson,
	wchar_t *restoreFormatString)
{
	wchar_t* logFile = L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\RPCLogger.txt";
	logger(logFile, L"HyperVRestore started...");
	logger(logFile, L"Details:\nUsername: %ws\nhypervHostName: %ws\nvmtoRestore: %ws\nvmfullbackupPathstring: %ws\nvmincrementalbackupPathsList: %ws\nLischangeVMName: %ws\nLnewVMName: %ws\nLVHDnewstorageLocation: %ws\nisEncrypted->%ws\nrestoreFormatString: %ws\n",
		domainuserName, hypervHostName, vmtoRestore, vmfullbackupPathstring, vmincrementalbackupPathsList, LischangeVMName, LnewVMName, LVHDnewstorageLocation, isEncrypted, restoreFormatString);

	DWORD dwRetVal;
	NETRESOURCE nr;
	DWORD dwFlags;
	int retVal=0;
	int fFreeDLL;
	//wchar_t buffer[MAX_PATH];

	memset(&nr, 0, sizeof (NETRESOURCE));

	nr.dwType = RESOURCETYPE_ANY;
	nr.lpRemoteName = hypervHostName;
	nr.lpProvider = NULL;
	dwFlags = CONNECT_TEMPORARY;
	if (wcscmp(domainuserName, L"-") == 0)
	{
		dwRetVal = WNetAddConnection2(&nr, NULL, NULL, dwFlags);
	}
	else
	{
		dwRetVal = WNetAddConnection2(&nr, password, domainuserName, dwFlags);
	}
	if (dwRetVal == NO_ERROR || dwRetVal == 1219)
	{
		logger(logFile, L"WNetAddConnection2 No error");
		wchar_t* isDecryptionsuccess = L"true";
		if (wcscmp(domainuserName, L"-") == 0)
		{
			logger(logFile, L"Going to call connecttobackupRepository..!");
			int repoStatus = connecttobackupRepository(logFile, LrepositoryDetailsJson, L"connect");
			if (repoStatus != 0)
			{
				logger(logFile, L"connecttobackupRepository returned ERROR -> %d..!", repoStatus);
				return 801;
			}
			else
			{
				logger(logFile, L"connecttobackupRepository returned SUCCESS -> .!");
			}
			logger(logFile, L"Finished calling connecttobackupRepository..!");
			if (wcscmp(isEncrypted, L"true") == 0)
			{
				logger(logFile, L"NEED TO DO DECRYPTION..!");
				int encryptStatus = encryptdecryptRPC(logFile, vmfullbackupPathstring, L"-", L"-", vmtoRestore, 1, encryptPassword);
				if (encryptStatus != 0)
				{
					logger(logFile, L"Decryption. SOME ISSUE WITH DECRYPTION. dON'T DELETE DECRYPTED FILE..!");
					isDecryptionsuccess = L"false";
				}
				logger(logFile, L"DONE DECRYPTION..Return value -> %d!", encryptStatus);
			}
			logger(logFile, L"Going to call PerformHypervrestore  with NULL credentials...");
		}
		else
		{
			wchar_t *domainalone = NULL;
			wchar_t *useralone = NULL;
			domainalone = wcstok_s(domainuserName, L"\\", &useralone);
			logger(logFile, L"Username: %ws, Domain Name: %ws", useralone, domainalone);
			HANDLE hToken;
			LPVOID lpvEnv;
			DWORD dwSize;
			WCHAR szUserProfile[256] = L"";
			if (!LogonUser(useralone, domainalone, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &hToken))
			{
				logger(logFile, L"LogonUser FAILED -> %d", GetLastError());
			}
			else
			{
				logger(logFile, L"LogonUser SUCCESS!!!");
			}
			if (!ImpersonateLoggedOnUser(hToken))
			{
				logger(logFile, L"ImpersonateLoggedOnUser FAILED -> %d", GetLastError());
			}
			else
			{
				logger(logFile, L"ImpersonateLoggedOnUser SUCCESS!!!");
			}
			logger(logFile, L"Going to call connecttobackupRepository..!");
			int repoStatus = connecttobackupRepository(logFile, LrepositoryDetailsJson, L"connect");
			if (repoStatus != 0)
			{
				logger(logFile, L"connecttobackupRepository returned ERROR -> %d..!", repoStatus);
				return 801;
			}
			else
			{
				logger(logFile, L"connecttobackupRepository returned SUCCESS -> .!");
			}
			logger(logFile, L"Finished calling connecttobackupRepository..!"); 
			if (wcscmp(isEncrypted, L"true") == 0)
			{
				logger(logFile, L"NEED TO DO DECRYPTION..!");
				int encryptStatus = encryptdecryptRPC(logFile, vmfullbackupPathstring, L"-", L"-", vmtoRestore, 1, encryptPassword);
				if (encryptStatus != 0)
				{
					logger(logFile, L"Decryption. SOME ISSUE WITH DECRYPTION. dON'T DELETE DECRYPTED FILE..!");
					isDecryptionsuccess = L"false";
				}
				logger(logFile, L"DONE DECRYPTION..Return value -> %d!", encryptStatus);
			}
			logger(logFile, L"Going to call PerformHypervrestore  with EXPLICIT credentials...");
		}

		PerformHypervrestore PerformHypervrestorecall;	
		HINSTANCE hGetProcIDDLL = LoadLibrary(L"HVBackup.dll");
		if (!hGetProcIDDLL)
		{
			logger(logFile, L"PerformHypervrestore Load DLL failed..!");
			return 601;
		}
		PerformHypervrestorecall = (PerformHypervrestore)GetProcAddress(hGetProcIDDLL, "PerformHypervrestore");
		if (!PerformHypervrestorecall)
		{
			FreeLibrary(hGetProcIDDLL);
			logger(logFile, L"connecting to PerformHypervrestore method FAILED..!");
			return 601;
		}
		retVal = PerformHypervrestorecall(hypervHostName, vmtoRestore, vmfullbackupPathstring, vmincrementalbackupPathsList, 
			LischangeVMName, LnewVMName, LVHDnewstorageLocation, isPowerOnString, isEncrypted, isDecryptionsuccess, vmId, restoreId, callBackFunction, Lparamsjson, restoreFormatString);
		FreeLibrary(hGetProcIDDLL);
		logger(logFile, L"connecting to PerformHypervrestore method Return value -> %d..!", retVal);

		if (wcscmp(domainuserName, L"-") != 0)
		{
			logger(logFile, L"Reverting to self since Impersonation was used..!");
			BOOL isSelfReverted = RevertToSelf();
			if (isSelfReverted)
			{
				logger(logFile, L"RevertToSelf Successful!");
			}
			else
			{
				logger(logFile, L"RevertToSelf Failure!");
			}
		}
		dwRetVal = WNetCancelConnection2(hypervHostName, 0, TRUE);
	}
	else
	{
		logger(logFile, L"WNetAddConnection2 error -> %ld", dwRetVal);
		retVal = 602;
	}
	logger(logFile, L"Rpc Return Value ->  %d", retVal);
	return retVal;
}



int HyperVinstallandstartDriver(wchar_t *userName, wchar_t *password, wchar_t *hypervHostName, wchar_t *isInstallstring)
{
	wchar_t* logFile = L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\RPCLogger.txt";
	logger(logFile, L"HyperVinstallandstartDriver started...");
	logger(logFile, L"Details:\nUsername: %ws\nHostName: %ws", userName, hypervHostName);

	DWORD dwRetVal;
	NETRESOURCE nr;
	DWORD dwFlags;
	int retVal=0;
	int fFreeDLL;
	//wchar_t buffer[MAX_PATH];

	memset(&nr, 0, sizeof (NETRESOURCE));
	nr.dwType = RESOURCETYPE_ANY;
	nr.lpRemoteName = hypervHostName;
	nr.lpProvider = NULL;
	dwFlags = CONNECT_TEMPORARY;
	if (wcscmp(userName, L"-") == 0)
	{
		dwRetVal = WNetAddConnection2(&nr, NULL, NULL, dwFlags);
	}
	else
	{
		dwRetVal = WNetAddConnection2(&nr, password, userName, dwFlags);
	}
	if (dwRetVal == NO_ERROR || dwRetVal == 1219)
	{
		logger(logFile, L"WNetAddConnection2 No error");

		wchar_t *operation = L"startListener";
		int length = wcslen(L"HVDriverManager.exe ") + wcslen(operation) + wcslen(isInstallstring) + 20;
		wchar_t *cmdbuf = (wchar_t *)malloc(length * sizeof(wchar_t));
		wcscpy(cmdbuf, L"HVDriverManager.exe ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, operation);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L" ");
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, isInstallstring);
		wcscat(cmdbuf, L"\"");
		wcscat(cmdbuf, L"\0");
		
		STARTUPINFO info = { sizeof(info) };
		PROCESS_INFORMATION processInfo;
		BOOL isProcessCreated = TRUE;
		if (wcscmp(userName, L"-") == 0)
		{
			logger(logFile, L"CreateProcess with NULL credentials...");
			isProcessCreated = CreateProcess(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\HVDriverManager.exe", cmdbuf, NULL, NULL, TRUE, 0, NULL, NULL, &info, &processInfo);
			logger(logFile, L"CreateProcess STATUS -> %d", isProcessCreated);
		}
		else
		{
			logger(logFile, L"CreateProcess with EXPLICIT credentials...");
			wchar_t *domainalone = NULL;
			wchar_t *useralone = NULL;
			domainalone = wcstok_s(userName, L"\\", &useralone);
			logger(logFile, L"Username: %ws, Domain Name: %ws", useralone, domainalone);
			HANDLE hToken;
			LPVOID lpvEnv;
			DWORD dwSize;
			WCHAR szUserProfile[256] = L"";
			if (!LogonUser(useralone, domainalone, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &hToken))
			{
				logger(logFile, L"LogonUser FAILED -> %d", GetLastError());
			}
			else
			{
				logger(logFile, L"LogonUser SUCCESS!!!");
			}
			if (!ImpersonateLoggedOnUser(hToken))
			{
				logger(logFile, L"ImpersonateLoggedOnUser FAILED -> %d", GetLastError());
			}
			else
			{
				logger(logFile, L"ImpersonateLoggedOnUser SUCCESS!!!");
			}
			//isProcessCreated = CreateProcessWithLogonW(useralone, domainalone, password, 0, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\HVDriverManager.exe", cmdbuf, 0, 0, NULL, &info, &processInfo);
			isProcessCreated = CreateProcessAsUser(hToken, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\HVDriverManager.exe", cmdbuf, NULL, NULL, TRUE, 0, NULL, NULL, &info, &processInfo);
			logger(logFile, L"CreateProcess STATUS -> %d", isProcessCreated);
		}

		if (isProcessCreated)
		{
			logger(logFile, L"CreateProcess Waiting...........................");
			WaitForSingleObject(processInfo.hProcess, 10000);//todo
			LPDWORD exitCode = 0;
			GetExitCodeProcess(processInfo.hProcess, &exitCode);
			retVal = (int)exitCode;
			logger(logFile, L"CreateProcess return value from method -> %d",retVal);
			CloseHandle(processInfo.hProcess);
			CloseHandle(processInfo.hThread);
		}
		else
		{
			logger(logFile, L"CreateProcess error 601");
			retVal = 601;
		}
		if (wcscmp(userName, L"-") != 0)
		{
			logger(logFile, L"Reverting to self since Impersonation was used..!");
			BOOL isSelfReverted = RevertToSelf();
			if (isSelfReverted)
			{
				logger(logFile, L"RevertToSelf Successful!");
			}
			else
			{
				logger(logFile, L"RevertToSelf Failure!");
			}
		}
		free(cmdbuf);
		dwRetVal = WNetCancelConnection2(hypervHostName, 0, TRUE);
	}
	else
	{
		logger(logFile, L"WNetAddConnection2 error -> %ld", dwRetVal);
		retVal = 602;
	}
	logger(logFile, L"Rpc Return Value ->  %d", retVal);
	return retVal;
}

int copyVMfilesfromVSSSnapshot(
	/* [string][in] */ wchar_t *domainuserName,
	/* [string][in] */ wchar_t *password,
	/* [string][in] */ wchar_t *hypervHostName,
	/* [string][in] */ wchar_t *vmName,
	/* [string][in] */ wchar_t *backupType,
	/* [string][in] */ wchar_t *lrepositoryPath,
	/* [string][in] */ wchar_t *lbackupName,
	/* [string][in] */ wchar_t *lscheduleName,
	/* [string][in] */ wchar_t *lrepositoryDetailsJson,
	/* [string][in] */ wchar_t *isEncrypted,
	/* [string][in] */ wchar_t *encryptPassword,
	/* [string][in] */ wchar_t *vmId,
	/* [string][in] */ wchar_t *generateHash)
{
	wchar_t* logFile = L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\RPCLogger.txt";
	logger(logFile, L"copyVMfilesfromVSSSnapshot started.%ws..",vmId);
	//logger(logFile, L"Details:\nUsername: %ws\nHostName: %ws\nfullbackupVMs: %ws\nincrementalbackupVMs: %ws\nrepositoryPath: %ws\nbackupName: %ws\nscheduleName: %ws", userName, hypervHostName, fullbackupVMs, incrementalbackupVMs, repositoryPath, backupName, scheduleName);

	//todo -> check the parameters
	//todo -> check return values

	DWORD dwRetVal;
	NETRESOURCE nr;
	DWORD dwFlags;
	int retVal = 0;
	int fFreeDLL;
	//wchar_t buffer[MAX_PATH];

	memset(&nr, 0, sizeof (NETRESOURCE));

	nr.dwType = RESOURCETYPE_ANY;
	nr.lpRemoteName = hypervHostName;
	nr.lpProvider = NULL;
	dwFlags = CONNECT_TEMPORARY;
	if (wcscmp(domainuserName, L"-") == 0)
	{
		dwRetVal = WNetAddConnection2(&nr, NULL, NULL, dwFlags);
	}
	else
	{
		dwRetVal = WNetAddConnection2(&nr, password, domainuserName, dwFlags);
	}

	if (dwRetVal == NO_ERROR || dwRetVal == 1219)
	{
		logger(logFile, L"WNetAddConnection2 No error");
		if (wcscmp(domainuserName, L"-") == 0)
		{
			logger(logFile, L"Going to call connecttobackupRepository..!");
			int repoStatus = connecttobackupRepository(logFile, lrepositoryDetailsJson, L"connect");
			if (repoStatus != 0)
			{
				logger(logFile, L"connecttobackupRepository returned ERROR -> %d..!", repoStatus);
				return 401;
			}
			else
			{
				logger(logFile, L"connecttobackupRepository returned SUCCESS -> .!");
			}
			logger(logFile, L"Finished calling connecttobackupRepository..!");
			logger(logFile, L"Going to call copyVMfilesfromVSSSnapshot  with NULL credentials...");			
		}
		else
		{
			wchar_t *domainalone = NULL;
			wchar_t *useralone = NULL;
			domainalone = wcstok_s(domainuserName, L"\\", &useralone);
			logger(logFile, L"Username: %ws, Domain Name: %ws", useralone, domainalone);
			HANDLE hToken;
			LPVOID lpvEnv;
			DWORD dwSize;
			WCHAR szUserProfile[256] = L"";
			if (!LogonUser(useralone, domainalone, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &hToken))
			{
				logger(logFile, L"LogonUser FAILED -> %d", GetLastError());
			}
			else
			{
				logger(logFile, L"LogonUser SUCCESS!!!");
			}
			if (!ImpersonateLoggedOnUser(hToken))
			{
				logger(logFile, L"ImpersonateLoggedOnUser FAILED -> %d", GetLastError());
			}
			else
			{
				logger(logFile, L"ImpersonateLoggedOnUser SUCCESS!!!");
			}
			logger(logFile, L"Going to call connecttobackupRepository..!");
			int repoStatus = connecttobackupRepository(logFile, lrepositoryDetailsJson, L"connect");
			if (repoStatus != 0)
			{
				logger(logFile, L"connecttobackupRepository returned ERROR -> %d..!", repoStatus);
				return 401;
			}
			else
			{
				logger(logFile, L"connecttobackupRepository returned SUCCESS -> .!");
			}
			logger(logFile, L"Finished calling connecttobackupRepository..!");
			logger(logFile, L"Going to call copyVMfilesfromVSSSnapshot  with EXPLICIT credentials...");
		}

		copyVMfilesfromVSSSnapshotCall copyVMfilesfromVSSSnapshotcall;	
		HINSTANCE hGetProcIDDLL = LoadLibrary(L"HVBackup.dll");
		if (!hGetProcIDDLL)
		{
			logger(logFile, L"copyVMfilesfromVSSSnapshot Load DLL failed..!");
			return 601;
		}
		copyVMfilesfromVSSSnapshotcall = (copyVMfilesfromVSSSnapshotCall)GetProcAddress(hGetProcIDDLL, "copyVMfilesfromVSSSnapshot");
		if (!copyVMfilesfromVSSSnapshotcall)
		{
			FreeLibrary(hGetProcIDDLL);
			logger(logFile, L"connecting to copyVMfilesfromVSSSnapshot method FAILED..!");
			return 601;
		}
		retVal = copyVMfilesfromVSSSnapshotcall(hypervHostName, vmName, backupType, lrepositoryPath, lbackupName, lscheduleName, vmId, callBackFunction);
		FreeLibrary(hGetProcIDDLL);
		logger(logFile, L"connecting to copyVMfilesfromVSSSnapshot method Return value -> %d..!", retVal);

		if (retVal == 0 && wcscmp(isEncrypted, L"true") == 0 && wcscmp(backupType, L"FullBackup")==0)
		{
			logger(logFile, L"NEED TO DO ENCRYPTION..!");
			int encryptStatus = encryptdecryptRPC(logFile, lrepositoryPath, lscheduleName, lbackupName, vmName, 0, encryptPassword);
			logger(logFile, L"DONE ENCRYPTION..Return value -> %d!",encryptStatus);
		}
		if(retVal == 0 && wcscmp(generateHash, L"true") == 0) {
            logger(logFile, L"GOING TO GENERATE HASH FOR BACKUP FILES..!");
            int generateHashStatus = generateHashforBackupRepository(logFile, lrepositoryPath, lscheduleName, lbackupName, vmName, backupType, isEncrypted, encryptPassword);
            //retVal = generateHashStatus;
            logger(logFile, L"GENERATE HASH DONE FOR BACKUP FILES..Return value -> %d!",generateHashStatus);
		}

		if (wcscmp(domainuserName, L"-") != 0)
		{
			logger(logFile, L"Reverting to self since Impersonation was used..!");
			BOOL isSelfReverted = RevertToSelf();
			if (isSelfReverted)
			{
				logger(logFile, L"RevertToSelf Successful!");
			}
			else
			{
				logger(logFile, L"RevertToSelf Failure!");
			}
		}
		dwRetVal = WNetCancelConnection2(hypervHostName, 0, TRUE);
	}
	else
	{
		logger(logFile, L"WNetAddConnection2 error -> %ld", dwRetVal);
		retVal = 602;
	}
	logger(logFile, L"Rpc Return Value ->  %d", retVal);
	return retVal;	
}

int HyperVHealthCheck(
	/* [string][in] */ wchar_t *domainuserName,
	/* [string][in] */ wchar_t *password,
	/* [string][in] */ wchar_t *hypervHostName,
	/* [string][in] */ wchar_t *healthCheckParametersJson,
	/* [string][in] */ wchar_t *vmBackupDetailsJson)
{
	wchar_t* logFile = L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\RPCLogger.txt";
	logger(logFile, L"healthCheck started...");
	logger(logFile, L"Details:\nUsername: %ws\nhypervHostName: %ws\n",
		domainuserName, hypervHostName);

	DWORD dwRetVal;
	NETRESOURCE nr;
	DWORD dwFlags;
	int retVal = 0;
	int fFreeDLL;

	memset(&nr, 0, sizeof(NETRESOURCE));

	nr.dwType = RESOURCETYPE_ANY;
	nr.lpRemoteName = hypervHostName;
	nr.lpProvider = NULL;
	dwFlags = CONNECT_TEMPORARY;
	if (wcscmp(domainuserName, L"-") == 0)
	{
		dwRetVal = WNetAddConnection2(&nr, NULL, NULL, dwFlags);
	}
	else
	{
		dwRetVal = WNetAddConnection2(&nr, password, domainuserName, dwFlags);
	}

	if (dwRetVal == NO_ERROR || dwRetVal == 1219)
	{
		logger(logFile, L"WNetAddConnection2 No error");
		if (wcscmp(domainuserName, L"-") == 0)
		{
			logger(logFile, L"Going to call connecttobackupRepository..!");
			int repoStatus = connecttobackupRepository(logFile, vmBackupDetailsJson, L"connect");
			if (repoStatus != 0)
			{
				logger(logFile, L"connecttobackupRepository returned ERROR -> %d..!", repoStatus);
				return 401;
			}
			else
			{
				logger(logFile, L"connecttobackupRepository returned SUCCESS -> .!");
			}
			logger(logFile, L"Finished calling connecttobackupRepository..!");
			logger(logFile, L"Going to call PerformHealthCheck with NULL credentials...");
		}
		else
		{
			logger(logFile, L"CreateProcess with EXPLICIT credentials..%ws..",domainuserName);
			wchar_t *domainalone = NULL;
			wchar_t *useralone = NULL;
//			logger(logFile, L"CreateProcess with EXPLICIT credentials3..#%ws#%ws#%ws#..",userName,domainalone,useralone);
			domainalone = wcstok_s(domainuserName, L"\\", &useralone);
//			logger(logFile, L"CreateProcess with EXPLICIT credentials4..#%ws#%ws#%ws#..",userName,domainalone,useralone);
			logger(logFile, L"Username: %ws, Domain Name: %ws", useralone, domainalone);
			HANDLE hToken;
			LPVOID lpvEnv;
			DWORD dwSize;
			WCHAR szUserProfile[256] = L"";
			if (!LogonUser(useralone, domainalone, password, LOGON32_LOGON_NEW_CREDENTIALS, LOGON32_PROVIDER_WINNT50, &hToken))
			{
				logger(logFile, L"LogonUser FAILED -> %d", GetLastError());
			}
			else
			{
				logger(logFile, L"LogonUser SUCCESS!!!");
			}
			if (!ImpersonateLoggedOnUser(hToken))
			{
				logger(logFile, L"ImpersonateLoggedOnUser FAILED -> %d", GetLastError());
			}
			else
			{
				logger(logFile, L"ImpersonateLoggedOnUser SUCCESS!!!");
			}
			logger(logFile, L"Going to call connecttobackupRepository..!");
			int repoStatus = connecttobackupRepository(logFile, vmBackupDetailsJson, L"connect");
			if (repoStatus != 0)
			{
				logger(logFile, L"connecttobackupRepository returned ERROR -> %d..!", repoStatus);
				return 401;
			}
			else
			{
				logger(logFile, L"connecttobackupRepository returned SUCCESS -> .!");
			}
			logger(logFile, L"Finished calling connecttobackupRepository..!");
			logger(logFile, L"Going to call PerformHealthCheck with EXPLICIT credentials...");
		}
		retVal = callPerformHyperVHealthCheck(logFile, hypervHostName, healthCheckParametersJson, vmBackupDetailsJson);
		if (wcscmp(domainuserName, L"-") != 0)
		{
			logger(logFile, L"Reverting to self since Impersonation was used..!");
			BOOL isSelfReverted = RevertToSelf();
			if (isSelfReverted)
			{
				logger(logFile, L"RevertToSelf Successful!");
			}
			else
			{
				logger(logFile, L"RevertToSelf Failure!");
			}
		}
		dwRetVal = WNetCancelConnection2(hypervHostName, 0, TRUE);
	}
	else
	{
		logger(logFile, L"WNetAddConnection2 error -> %ld", dwRetVal);
		return 602;
	}
	logger(logFile, L"Rpc Return Value ->  %d", retVal);
	return retVal;
}
