//#include "stdafx.h"
#include "conio.h"
#include <atlbase.h>
#include <string>
#include <unordered_set>
#include <list>
#include <map>
#include <iostream>
#include <vector>
#include <comdef.h>
#include <windows.h>
#include "Loggerclass.h"


using namespace std;

#define ENCRYPT_BLOCK_SIZE 16 
#define KEYLENGTH  0x00800000
#define ENCRYPT_ALGORITHM CALG_AES_128

void CheckHRESULT(HRESULT hr, const wchar_t* COMcall);
void WriteFile(wstring fileName, wstring contents);
HRESULT ModifyPrivilege(IN LPCTSTR szPrivilege, IN BOOL fEnable);
int backup_file_exists(wchar_t *filePath, WIN32_FIND_DATA *lpFindFileData, HANDLE *handle);
BOOL create_directory(wchar_t *filePath);
int backup_file(wchar_t *dirpath, WIN32_FIND_DATA lpFindFileData, wchar_t *vscpath, wchar_t *destinationPath);
int backup_directory(wchar_t *sourcePath, WIN32_FIND_DATA lpFindFileData, wchar_t *vssSnapshotPath, wchar_t *destinationPath);
int data_backup(HANDLE handle, wchar_t *sourcePath, WIN32_FIND_DATA lpFindFileData, wchar_t *vssSnapshotPath, wchar_t *destinationPath);
int data_backup_initialization(wchar_t *VssSnapshotPath, wchar_t *destination, wchar_t *filePath);

int file_size(FILE *f);
int create_restore_directory(wchar_t *destinationPath);
DWORD restore_file_exists(wchar_t *sourcePath);
int restore_file(wchar_t *sourcePath, WIN32_FIND_DATA lpFindFileData, wchar_t *destinationPath, wchar_t *tempPath);
int restore_directory(wchar_t *sourcePath, WIN32_FIND_DATA lpFindFileData, wchar_t *destinationPath, wchar_t *tempPath);
int restore_data(HANDLE hFile, wchar_t *sourcePath, wchar_t *destinationPath, WIN32_FIND_DATA lpFindFileData, wchar_t *tempPath);
int restore_data_disk_restore(HANDLE hFile, wchar_t *sourcePath, wchar_t *destinationPath, WIN32_FIND_DATA lpFindFileData, wchar_t *tempPath);
int restore_data_initialization(wchar_t *path, wchar_t *destinyPath, bool isDiskRestore);
int checkCredentials(LPWSTR location, LPWSTR userName, LPWSTR password, LPWSTR connectDisconnect);
void initializeCommonUtilvariables(Loggerclass *loggerclass);
bool CompressFileDirectly(BSTR filePathinsnapshot, BSTR backupFolderpath, BSTR backupName, BSTR vmId, Loggerclass *fileCopylogger, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *));
bool DecompressFileDirectly(BSTR filePathinsnapshot, BSTR backupFolderpath, BSTR restoreId, BSTR vmId, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *));
int encryptdecryptFile(LPTSTR pszPassword, int oper, wchar_t* filePath);