#ifndef Info_VSS
#define Info_VSS
#include "CommonUtil.h"
#include "HealthCheck.h"
#include <vss.h>
#include <vswriter.h>
#include <vsbackup.h>
#include "Loggerclass.h"
#include <time.h>
#include <msclr\marshal.h>
#include <msclr\marshal_cppstd.h>
#include <vector>
#include <algorithm>

using namespace std;
using namespace System;
using namespace System::IO;
using namespace msclr::interop;
using namespace System::Runtime::InteropServices;

class WriterComp
{
public:
	wstring compPath;
	wstring compName; 
	WriterComp* compParent;
	bool isSelectable; 
	VSS_COMPONENT_TYPE compType; 
	int writer; 
	WriterComp::WriterComp()
	{
		compParent = NULL; 
	}
	bool isAncestorSelectable(void)
	{
		if (compParent == NULL)
		{
			return false; 
		}

		if (compParent->isSelectable)
		{
			return true; 
		}

		return compParent->isAncestorSelectable(); 
	}

	bool IsParentOf(WriterComp& potentialParent)
	{
		// The other component is our parent if our logical path is equal to 
		// their logical path plus their name. 
		wstring pathToCompare = potentialParent.compPath; 

		if (pathToCompare.length() > 0)
		{
			pathToCompare.append(TEXT("\\")); 
		}

		pathToCompare.append(potentialParent.compName); 

		return compPath.compare(pathToCompare) == 0; 
	}
};


bool ShouldAddComponent(WriterComp& component);
BSTR GetSnapshotDeviceName(char volumeName, BSTR backupName, Loggerclass *fileCopylogger);
std::list<IVssWMComponent*> DoVSSSnapshot(std::list<BSTR> vmList, BSTR repositoryPath, BSTR scheduleName, BSTR backupName, std::list<BSTR> fullbackupVMList, std::list<BSTR> incrementalbackupVMList);
int copyfilesfromSnapshot(BSTR repositoryPath, BSTR backupType, BSTR backupName, BSTR scheduleName, BSTR vmNametobackup, BSTR vmId, Loggerclass *fileCopylogger, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *));
int  InitVssforBackup();
void CloseVss();
bool VssSupport(wstring name);
bool Is32BitProcessRunningInWow64();
int SetBackupCompletedstatus(std::list<IVssWMComponent*> componentList, bool wasAborted);
void SetComponentBackupStatus(std::list<IVssWMComponent*> componentList);
int VssCleanup();
void InitializeGlobalvariables(Loggerclass *logger);
int  LoadVSSLibrary();

int restorefilesfromFullBackup(std::list<IVssWMComponent*> componentListtoRestore, BSTR vmbackedupPath, BSTR vmName, bool isDiskRestore, bool isoldVMdeletebool, BSTR vmId, BSTR restoreId, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *));
int restorefilesfromIncrementalBackup(std::list<IVssWMComponent*> componentListtoRestore, BSTR vmIncrementalbackedupPath, BSTR vmName, bool isOverwrite, BSTR destinationPath, BSTR vmId, BSTR restoreId, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *));
std::list<IVssWMComponent*> GetComponentsToRestore(BSTR vmName, bool isoldVMdeletebool);
int LoadBackupCompandWriterMetadatadocs(BSTR vmbackedupPath, BSTR vmName, Loggerclass *fileCopylogger);
int doIncrementalBackupforcomponents(BSTR repositoryPath, BSTR backupName, BSTR scheduleName, BSTR vmName, BSTR vmId, Loggerclass *fileCopylogger, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *));
char* getVMNamefromvhdxName(char* vhdxfileName);
void readanddistributeMasterCBTfile(LPWSTR schedulesList);
std::list<IVssWMComponent*> GetHyperVComponents(BSTR vmName, BSTR repositoryPath, BSTR backupName, BSTR scheduleName, Loggerclass *fileCopylogger);
//int LoadsnapshotdetailsfiletoMap(BSTR backupName);
String^ getsnapshotNamefromFile(BSTR backupName, String^ volumeName, Loggerclass *fileCopylogger);
void ProcessCBTFilesforbackupVMs(std::list<BSTR> fullbackupVMList, std::list<BSTR> incrementalbackupVMList, BSTR scheduleName, BSTR backupName, std::list<IVssWMComponent*> componentListbackedUp);
//void deleteVSSSnapshot(wchar_t* backupName);
#endif