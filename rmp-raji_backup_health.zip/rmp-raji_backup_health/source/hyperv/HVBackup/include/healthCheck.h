//#include "conio.h"
//#include <atlbase.h>
//#include <string>
//#include <unordered_set>
//#include <list>
//#include <map>
#include <iostream>
#include <vector>
//#include <comdef.h>
#include <fstream>
#include <windows.h>
#include "Shlwapi.h"
#include "Loggerclass.h"
#include <locale>
#include <codecvt>

using namespace std;

#define BUFSIZE 1024*1024*16
#define BUFSIZETOHASH 1024*1024*16
#define MD5LEN 16

void initializeHealthCheckvariables(Loggerclass *healthcheckLoggerclass);
int generateHashforFile(wchar_t* sourceFilePath, wchar_t* destFilePath, wchar_t* backupIdentifier, wchar_t* hashType, wchar_t* isSingleHash, wchar_t* mode, wchar_t* fileType);
int generateSingleHashandBloackbyBlockHashforFile(wchar_t* destFileDir, wchar_t* sourceFilePath, wchar_t* destFilePath, wchar_t* backupIdentifier, wchar_t* isEncrypted, wchar_t* encryptPassword, wchar_t* hashType, wchar_t* fileType);
int generateSingleHashandBlockbyBlockforBinFile(wchar_t* destFileDir, wchar_t* sourceFilePath, wchar_t* destFilePath, wchar_t* backupIdentifier, wchar_t* hashType, wchar_t* fileType);
int checkHash(wchar_t* destFilesDir, wchar_t* scheduleName, wchar_t* vmName, wchar_t* backupIdentifier, wchar_t* backupType);