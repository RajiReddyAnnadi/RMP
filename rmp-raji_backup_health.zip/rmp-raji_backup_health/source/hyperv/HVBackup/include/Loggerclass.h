#ifndef Loggerclass_H_INCLUDED
#define Loggerclass_H_INCLUDED
#include <sys/timeb.h>
#include <tchar.h>
#include <stdio.h>
#include <windows.h>

#define		NORMAL	L"NORMAL"
#define		DEBUG	L"DEBUG"

class Loggerclass
{
private:
	FILE*		logFile;
	LPWSTR		level;
	void log(LPWSTR writeLevel, const wchar_t* message, va_list* args);
	void logchar(LPWSTR writeLevel, const char* message, va_list* args);
	void checkLogFile(LPWSTR logFileName);

public:
	Loggerclass(LPWSTR logFile, LPWSTR loglevel);
	void log(LPWSTR writeLevel, const wchar_t* message, ...);
	void logchar(LPWSTR writeLevel, const char* message, ...);
	~Loggerclass(void);
};

#endif