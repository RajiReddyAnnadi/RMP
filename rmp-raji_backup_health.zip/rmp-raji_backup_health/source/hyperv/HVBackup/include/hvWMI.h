#pragma managed

#include "CommonUtil.h"
#include "Vssbackup.h"
#include <msclr\marshal.h>
#include <msclr\marshal_cppstd.h>

using namespace std;
using namespace System;
using namespace System::Management;
using namespace msclr::interop;
using namespace System::Collections::Generic;
using namespace System::IO;
using namespace System::Xml;
using namespace System::Runtime::InteropServices; 
using namespace Newtonsoft::Json;

public ref class WMIconnectiondetails
{
	public:
		static String^ hypervHostName;
		static ManagementScope^ scope;
		static String^ osVersion;
		static String^ logFilePath;
		static bool is2008Server;
};

public ref class HVVirtualMachine
{
public:
	bool isDynamicmemoryenabled;
	int reservationMemory;
	int RAMmemory;
	int maxMemory;
	
	int processorCount;
	String^ originalvmName;
	String^ switchName;
	String^ switchName2008;
	String^ hvvmId;
	String^ hvGeneration;
	Dictionary<Dictionary<String^, String^>^, List<Dictionary<String^, String^>^>^>^ controllerdriveDetails;	

	HVVirtualMachine();
	HVVirtualMachine(String^ configurationXMLfileName);	
};

public ref class repoCredentials
{
public:
   String^ userName;
   String^ password; 
   String^ repoPath;
};

public ref class additionalParameters 
{
public:
   String^ vmDisksSize;
};

public ref class backupDetails
{
public:
//    String^ repoPath;
//    String^ userName;
//    String^ password;
    String^ backupPath;
    String^ backupType;
    String^ backupIdentifier;
};

public ref class healthCheckParameters
{
public:
    String^ hypervVMID;
    String^ backupId;
    String^ vmId;
    String^ isEncrypted;
    String^ encryptPassword;
};

bool InitializeWMIGlobalvariables(LPWSTR hvHostName, LPWSTR logpath);
ManagementObject^ getManagementObjectInstance(String^ className);
bool ValidateOutput(ManagementBaseObject^ outputParameters, ManagementScope^ scope);
bool shutdownVM(String^ vmtoTurnoff);
List<String^>^ GetlistofResources(ManagementObject^ settingData, UInt16 resourceType, String^ resourceSubType, String^ storageclassName);
void writeVHDtoVMfile();
bool IsJobComplete(UInt16 jobState);
bool IsJobSuccessful(UInt16 jobState);
void WMILog(String^ message);
void CopyVHDfilestotargetDirectory(String^ sourceDirName, String^ destDirName, BSTR restoreId, BSTR vmId, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *));
ManagementObject^ GetResourceAllocationsettingData(ManagementObject^ settingData, UInt16 resourceType, String^ resourceSubType, String^ otherResourceType);
ManagementObject^ GetResourceAllocationsettingDataDefault(ManagementScope^ scope, UInt16 resourceType, String^ resourceSubType, String^ otherResourceType);
int attachdrivesandVHDfiles(ManagementObject^ settings, ManagementObject^ vmManagementService, Dictionary<Dictionary<String^, String^>^, List<Dictionary<String^, String^>^>^>^ controllerdriveDetails, String^ VHDnewlocation);
String^ DefinenewVirtualSystem(String^ configurationXMLfileNameString);
int createnewVirtualMachinefromXMLfile(String^ xmlFilePath, String^ ischangeVMName, String^ newVMName, String^ VHDnewstorageLocation, String^ newVMhvID);
String^ getdefaultVHDLocation();

String^ Definenew2008VirtualSystem(String^ configurationXMLfileNameString);
int attachdrivesandVHDfiles2008(ManagementObject^ settings, ManagementObject^ vmManagementService, Dictionary<Dictionary<String^, String^>^, List<Dictionary<String^, String^>^>^>^ controllerdriveDetails, String^ VHDnewlocation, String^ newVMhvID);
int createnewVirtualMachinefromXMLfile2008(String^ xmlFilePath, String^ ischangeVMName, String^ newVMName, String^ VHDnewstorageLocation, String^ newVMhvID);
ManagementObject^ GetTargetComputer(String^ vmInstanceID, ManagementScope^ scope);
void checkifVHDtoVMfileexists();
bool RequestStateChange(String^ vmtoChangeState, UInt16^ requestedState);
bool checkifVMPresent(String^ vmNameString);
int checkifBackupFilesPresent(String^ fullbackupvmPathString, String^ vmNameString);
void DeletedecryptedFiles(String^ fullbackupvmPathString, String^ vmNameString);
int createnetworkAdapter(ManagementObject^ settings, ManagementObject^ vmManagementService, String^ switchName);
int createnetworkAdapter2008(ManagementObject^ settings, ManagementObject^ vmManagementService, String^ switchName, String^ newVMhvID);
bool moveVMtoSavedState(String^ vmtoChangeState);
bool checkifVMRunning(String^ vmName);
bool mergeVHDFIles(String^ vhdPath);
