#include <stdio.h>
#include <windows.h>
#include <iostream>
#include <string.h>
#include <stdint.h>
#include <zlib.h>
#include "Loggerclass.h"

using namespace std;
#define SPAN 10485760L       /* desired distance between access points */
#define WINSIZE 32768U      /* sliding window size */
#define CHUNK 65536         /* file input buffer size */

#define ENCRYPT_BLOCK_SIZE 16
#define KEYLENGTH 0x00800000
#define ENCRYPT_ALGORITHM CALG_AES_128

/* access point entry */
struct point {
    __int64 out; /* corresponding offset in uncompressed data */
    __int64 in; /* offset in input file of first full byte */
    int bits; /* number of bits (1-7) from byte at in - 1, or 0 */
    unsigned char window[WINSIZE]; /* preceding 32K of uncompressed data */
};

/* access point list */
struct access {
    int have; /* number of list entries filled in */
    int size; /* number of list entries allocated */
    struct point *list; /* allocated list */
};

struct access *addpoint(struct access *index, int bits, __int64 in, __int64 out, unsigned left, unsigned char *window);
int build_index(FILE *in, __int64 span, struct access **built);
int build_indexForEncryptedFile(FILE *in, __int64 span, struct access **built, LPTSTR pszPassword);
int write_uint32(gzFile gz, uint32_t v);
int indexCreation(wstring backupFile, boolean isEncrypted, LPWSTR secretKey, Loggerclass *logidx);
struct access *getIndexforFile(struct access *index, wchar_t* indexFile, Loggerclass *logdrive);
int extract(FILE *in, struct access *index, __int64 offset,unsigned char *buf, int len);
int extractDecrypt(FILE* in, struct access *index, __int64 offset, unsigned char *buf, int len, LPTSTR secretKey);
HCRYPTKEY generateHashKey(LPTSTR pszPassword);
unsigned decryptBuffer(HCRYPTKEY hKey, PBYTE pbBuffer, DWORD dwCount, bool fEOF);