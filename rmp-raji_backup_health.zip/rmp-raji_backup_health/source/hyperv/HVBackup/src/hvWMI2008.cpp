#include "hvWMI.h"

String^ Definenew2008VirtualSystem(String^ configurationXMLfileNameString)
{	
	//for 2008, all vms are generation1. by default, gen1 vms are created. so that parameter is not set
	WMILog("hvWMI2008.cpp Definenew2008VirtualSystem started...");
	String^ hvvmId = "-";
	try
	{
		ManagementObject^ vmManagementService = getManagementObjectInstance("MsVM_VirtualSystemManagementService");
		ManagementBaseObject^ definition = vmManagementService->InvokeMethod("DefineVirtualSystem", vmManagementService->GetMethodParameters("DefineVirtualSystem"), nullptr);
		WMILog("DefinenewVirtualSystem Return Value STATE -> " + Convert::ToUInt16(definition["ReturnValue"]));
		bool result = ValidateOutput(definition, WMIconnectiondetails::scope);
		if (!result)
		{
			WMILog("DefinenewVirtualSystem failed...");
			return nullptr;
		}
		WMILog("DefinenewVirtualSystem succeeded...");

		String^ vmPath = definition["DefinedSystem"]->ToString();
		ManagementObject^ computerSystemTemplate = gcnew ManagementObject(vmPath);
		computerSystemTemplate->Scope = WMIconnectiondetails::scope;
		hvvmId = computerSystemTemplate["Name"]->ToString(); //this is the unique GUID of the new VM
	}
	catch (Exception^ ex)
	{
		WMILog(L"DefinenewVirtualSystem Exception thrown: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
		return nullptr;
	}
	return hvvmId;
}

int createnetworkAdapter2008(ManagementObject^ settings, ManagementObject^ vmManagementService, String^ switchName, String^ newVMhvID)
{
	WMILog("hvWMI.cpp createnetworkAdapter2008 started...");
	try
	{
		ManagementObject^ synthetic;
		synthetic = GetResourceAllocationsettingDataDefault(WMIconnectiondetails::scope, 10, "Microsoft Synthetic Ethernet Port", "-");
		synthetic = (ManagementObject^)synthetic->Clone();
		array<String^>^ ff = gcnew array<String^>(1);
		ff[0] = Guid::NewGuid().ToString("B");
		synthetic["VirtualSystemIdentifiers"] = ff;
		synthetic["ElementName"] = "Network Adapter";
		synthetic["StaticMacAddress"] = false;

		ManagementObject^ newVM = GetTargetComputer(newVMhvID, WMIconnectiondetails::scope);

		array<String^>^ nwAdapter = gcnew array<String^>(1);
		nwAdapter[0] = synthetic->GetText(TextFormat::WmiDtd20);
		ManagementBaseObject^ syntheticinParams = vmManagementService->GetMethodParameters("AddVirtualSystemResources");
		syntheticinParams["TargetSystem"] = newVM;
		syntheticinParams["ResourceSettingData"] = nwAdapter;
		ManagementBaseObject^ syntheticoutParams = vmManagementService->InvokeMethod("AddVirtualSystemResources", syntheticinParams, nullptr);

		WMILog("nwAdapter Return Value STATE -> " + Convert::ToUInt16(syntheticoutParams["ReturnValue"]));

		bool result = ValidateOutput(syntheticoutParams, WMIconnectiondetails::scope);
		if (!result)
		{
			WMILog("nwAdapter attachment failed...");
//			return 822;
		}
                else
                {
                        WMILog("nwAdapter attachment succeeded");
                }

		if(switchName==nullptr || switchName->Equals(""))
		{
			WMILog("SwitchName is NULL. Probably network adapter not connected..!");
			return 0;
		}

		ManagementObject^ addednwAdapter;
		if (syntheticoutParams["NewResources"] != nullptr)
		{
			WMILog("Reading synthetic output parameters...");
			addednwAdapter = gcnew ManagementObject(((array<String^>^)syntheticoutParams["NewResources"])[0]);
			addednwAdapter->Get();
		}

		
		String^ query = "select * from Msvm_VirtualSwitch where ElementName='"+ switchName +"'";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(WMIconnectiondetails::scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ settingsCollection = searcher->Get();
		ManagementObject^ virtualSwitch = gcnew ManagementObject();
		for each (ManagementObject^ temp in settingsCollection)
		{
			WMILog("Got switch..!");
			virtualSwitch = temp;
		}	
		
		
		ManagementObject^ nic;
		nic = GetResourceAllocationsettingDataDefault(WMIconnectiondetails::scope, 33, "Microsoft:Hyper-V:Ethernet Connection", "-");
		nic = (ManagementObject^)nic->Clone();

		array<String^>^ sw = gcnew array<String^>(1);
		sw[0] = virtualSwitch->Path->Path;
		nic["Parent"] = addednwAdapter->Path->Path;
		nic["Connection"] = sw;//check
		
		array<String^>^ networkSwitch = gcnew array<String^>(1);
		networkSwitch[0] = nic->GetText(TextFormat::WmiDtd20);
		syntheticinParams = vmManagementService->GetMethodParameters("AddVirtualSystemResources");
		syntheticinParams["TargetSystem"] = newVM;
		syntheticinParams["ResourceSettingData"] = networkSwitch;
		syntheticoutParams = vmManagementService->InvokeMethod("AddVirtualSystemResources", syntheticinParams, nullptr);

		WMILog("networkSwitch Return Value STATE -> " + Convert::ToUInt16(syntheticoutParams["ReturnValue"]));

		result = ValidateOutput(syntheticoutParams, WMIconnectiondetails::scope);
		if (!result)
		{
			WMILog("Switch attachment failed...");
//			return 823;
		}
                else
                {
                        WMILog("Switch attachment succeeded");
                }
	}
	catch (Exception^ ex)
	{
		WMILog(L"createnetworkAdapter2008 Exception thrown: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
//		return 824;
                return 0;
	}
	WMILog("createnetworkAdapter2008 completed..!");
	return 0;
}

int attachdrivesandVHDfiles2008(ManagementObject^ settings, ManagementObject^ vmManagementService, Dictionary<Dictionary<String^, String^>^, List<Dictionary<String^, String^>^>^>^ controllerdriveDetails, String^ VHDnewlocation, String^ newVMhvID)
{
	WMILog("hvWMI2008.cpp  attachdrivesandVHDfiles2008 started...");
	try
	{
		for each(Dictionary<String^, String^>^ controllerInformation in controllerdriveDetails->Keys)
		{
			String^ controllerName, ^isScsi;
			controllerInformation->TryGetValue("controllerName", controllerName);
			controllerInformation->TryGetValue("isScsi", isScsi);
			WMILog("hvWMI2008.cpp  attachdrivesandVHDfiles controllerName..." + controllerName + "isScsi-> " + isScsi);
			//create controller
			ManagementObject^ controllerObject;

			if (isScsi->Equals("false"))
			{
				controllerObject = GetResourceAllocationsettingData(settings, 5, "Microsoft Emulated IDE Controller", "-");//public const UInt16 IDEController = 5;
			}
			else
			{
				controllerObject = GetResourceAllocationsettingData(settings, 6, "Microsoft Synthetic SCSI Controller", "-");//public const UInt16 IDEController = 5; //-> todo(done. need to check)
			}

			List<Dictionary<String^, String^>^>^ driveDetails;
			controllerdriveDetails->TryGetValue(controllerInformation, driveDetails);
			WMILog("hvWMI2008.cpp  attachdrivesandVHDfiles Going to loop through driveDetails");

			//Loop for creating drives
			for each(Dictionary<String^, String^>^ driveInfo in driveDetails)
			{

				String^ driveName, ^pathName, ^type;
				driveInfo->TryGetValue("driveName", driveName);
				driveInfo->TryGetValue("pathName", pathName);
				driveInfo->TryGetValue("type", type);
				WMILog("hvWMI2008.cpp  attachdrivesandVHDfiles driveName..." + driveName + "pathName-> " + pathName);


				//create the drive here and attach vhd specified in pathName
				//Add synthetic disk
				String^ pre = "drive";
				String^ driveNumber = driveName->Substring(driveName->IndexOf(pre) + pre->Length);
				WMILog("Drive number -> " + driveNumber);

				ManagementObject^ synthetic = GetResourceAllocationsettingDataDefault(WMIconnectiondetails::scope, 22, "Microsoft Synthetic Disk Drive", " - ");//ResourceType.Disk=17, public const string DiskSynthetic = "Microsoft Synthetic Disk Drive";
				synthetic = (ManagementObject^)synthetic->Clone();
				synthetic["Parent"] = controllerObject->Path->Path; //or SCSI controller path (WMI path)
				synthetic["Address"] = Convert::ToInt32(driveNumber); //0 or 1 for IDE 
				
				array<String^>^ RASDs = gcnew array<String^>(1);
				RASDs[0] = synthetic->GetText(TextFormat::WmiDtd20);
				ManagementObject^ newVM = GetTargetComputer(newVMhvID, WMIconnectiondetails::scope);
				ManagementBaseObject^ syntheticinParams = vmManagementService->GetMethodParameters("AddVirtualSystemResources");
				syntheticinParams["TargetSystem"] = newVM;
				syntheticinParams["ResourceSettingData"] = RASDs;
				ManagementBaseObject^ syntheticoutParams = vmManagementService->InvokeMethod("AddVirtualSystemResources", syntheticinParams, nullptr);
				
				WMILog("SYNTHETIC Return Value STATE -> " + Convert::ToUInt16(syntheticoutParams["ReturnValue"]));

				bool result = ValidateOutput(syntheticoutParams, WMIconnectiondetails::scope);
				if (!result)
				{
					WMILog("Synthetic attachment failed...");
					return 819;
				}
				WMILog("Synthetic attachment succeeded");

				ManagementObject^ addedSynthetic;
				if (syntheticoutParams["NewResources"] != nullptr)
				{
					WMILog("Reading synthetic output parameters...");
					addedSynthetic = gcnew ManagementObject(((array<String^>^)syntheticoutParams["NewResources"])[0]);
					addedSynthetic->Get();
				}


				//Add VHD
				String^ vhdNewpath = VHDnewlocation + pathName->Substring(pathName->LastIndexOf("\\"));
				WMILog("vhdNewpath ->  " + vhdNewpath);
				if(!File::Exists(vhdNewpath))
				{
					WMILog("vhdNewpath NOT FOUND. Trying to connect to available VHDX file..!");//todo
					array<String^> ^ vhdxFiles = Directory::GetFiles(VHDnewlocation, "*.vhd*");
					for each(String^ existingVHD in vhdxFiles)
					{
						vhdNewpath = existingVHD;
					}
					WMILog("vhdNewpath NOT FOUND. NEW NEW VHD PATH ->" + vhdNewpath);
				}

				ManagementObject^ hardDisk = GetResourceAllocationsettingDataDefault(WMIconnectiondetails::scope, 21, "Microsoft Virtual Hard Disk", "-");//public const UInt16 Logicaldrive = 31;public const string VHD = "Microsoft Virtual Hard Disk";	
				hardDisk = (ManagementObject^)hardDisk->Clone();
				array<String^>^ connection = gcnew array<String^>(1);
				connection[0] = vhdNewpath;

				hardDisk["Parent"] = addedSynthetic->Path->Path; //WMI path
				hardDisk["Connection"] = connection;

				array<String^> ^ HDs = gcnew array<String^>(1);
				HDs[0] = hardDisk->GetText(TextFormat::WmiDtd20);
				ManagementBaseObject^ VHDinParams = vmManagementService->GetMethodParameters("AddVirtualSystemResources");
				VHDinParams["TargetSystem"] = newVM;
				VHDinParams["ResourceSettingData"] = HDs;
				ManagementBaseObject^ VHDoutParams = vmManagementService->InvokeMethod("AddVirtualSystemResources", VHDinParams, nullptr);

				WMILog("HD STATE return value-> " + Convert::ToUInt16(VHDoutParams["ReturnValue"]));

				result = ValidateOutput(VHDoutParams, WMIconnectiondetails::scope);
				if (!result)
				{
					WMILog("HD attachment failed");
					return 820;
				}
				WMILog("HD attachment succeeded");
			}
		}
	}
	catch (Exception^ ex)
	{
		WMILog(L"hvWMI2008.cpp attachdrivesandVHDfiles Exception thrown: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
		return 821;
	}
	WMILog("attachdrivesandVHDfiles2008 completed..!");
	return 0;
}

int createnewVirtualMachinefromXMLfile2008(String^ xmlFilePath, String^ ischangeVMName, String^ newVMName, String^ VHDnewstorageLocation, String^ newVMhvID)//checked
{
	try
	{
		WMILog("createnewVirtualMachinefromXMLfile2008 started...");
		//Create virtual machine object
		HVVirtualMachine^ hvvm = gcnew HVVirtualMachine(xmlFilePath);
		//for 2008, all vms are generation1. by default, gen1 vms are created. so that parameter is not set
		ManagementObject^ vmManagementService = getManagementObjectInstance("MsVM_VirtualSystemManagementService");

		//Get Msvm_VirtualSystemSettingData object
		String^ query = "select * from Msvm_VirtualSystemSettingData where InstanceID='Microsoft:" + newVMhvID + "'";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(WMIconnectiondetails::scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ settingsCollection = searcher->Get();
		ManagementObject^ settings = gcnew ManagementObject();
		for each (ManagementObject^ temp in settingsCollection)
		{
			settings = temp;
		}

		WMILog("createnewVirtualMachinefromXMLfile2008 Got the settings object of the newly created machine...");

		//Change the necessary settings		
		if (ischangeVMName->Equals("true"))
		{
			settings["ElementName"] = newVMName; //this is the new display name for the VM
		}
		else
		{
			settings["ElementName"] = hvvm->originalvmName;
		}

		WMILog("Finished setting system settings");
		/*if (isPreserveUUID->Equals("true"))
		{
		settings["VirtualSystemIdentifier"] = originalVMId;
		}*/


		//Memory Settings
		ManagementObjectCollection^ memorySettingsCollection = settings->GetRelated("Msvm_MemorySettingData");
		ManagementObject^ memorySettings;
		for each(ManagementObject^ managementObject in memorySettingsCollection)
		{
			memorySettings = managementObject;
		}

		//DynamicMemoryEnabled property is not available in Windows server 2008, it is only availble in 2008 r2. for 2008 server, isDynamicmemoryenabled will always be false
		if (hvvm->isDynamicmemoryenabled)
		{ //https://blogs.msdn.microsoft.com/taylorb/2013/11/08/memory-configuration-utilizing-the-hyper-v-wmi-v2-namespace/
			WMILog(L"Dynamic memory enabled. Setting dynamic memory..!");
			memorySettings["DynamicMemoryEnabled"] = true;
			memorySettings["Reservation"] = hvvm->reservationMemory;
			memorySettings["VirtualQuantity"] = hvvm->RAMmemory;
			memorySettings["Limit"] = hvvm->maxMemory;
		}
		else
		{
			WMILog(L"Dynamic memory NOT enabled. Setting fixed memory..!");
			if(!(WMIconnectiondetails::osVersion->StartsWith("6.0")))//if not 2008 server -> maybe 2008 r2
			{
				WMILog(L"This is 2008 r2 server. So setting DynamicMemoryEnabled to FALSE!");
				memorySettings["DynamicMemoryEnabled"] = false;
			}
			else
			{
				WMILog(L"This is 2008 server. So NOT setting DynamicMemoryEnabled. We are setting only VirtualQuantity");
			}
			memorySettings["VirtualQuantity"] = hvvm->RAMmemory;
		}
		WMILog("Finished setting memory settings");

		//Drive and VHD configuration settings
		int returnValue = attachdrivesandVHDfiles2008(settings, vmManagementService, hvvm->controllerdriveDetails, VHDnewstorageLocation, newVMhvID);
		if(returnValue){
			return returnValue;
		}
		//Network adapter settings
		WMILog(L"GOING TO CALL createnetworkAdapter0......!!!!!!!!!!!!" + hvvm->switchName2008);
		returnValue = createnetworkAdapter2008(settings, vmManagementService, hvvm->switchName2008, newVMhvID);
//		if(returnValue){
//			return returnValue;
//		}
		settings->Put();
		memorySettings->Put();

		//ModifySystemSettings call
		WMILog(L"VM details: Name ->  " + settings["ElementName"]->ToString());

		WMILog(L"Calling ModifyVirtualSystem");
		ManagementBaseObject^ inParams = vmManagementService->GetMethodParameters("ModifyVirtualSystem");
		String^ settingsText = settings->GetText(TextFormat::WmiDtd20);
		inParams["SystemSettingData"] = settingsText;
		ManagementObject^ newVM = GetTargetComputer(newVMhvID, WMIconnectiondetails::scope);
		inParams["ComputerSystem"] = newVM;
		ManagementBaseObject^ resultToCheck = vmManagementService->InvokeMethod("ModifyVirtualSystem", inParams, nullptr);
		WMILog("ModifySystemSettings Return Value STATE -> " + Convert::ToUInt16(resultToCheck["ReturnValue"]));
		bool result = ValidateOutput(resultToCheck, WMIconnectiondetails::scope);
		if (!result)
		{
			WMILog("ModifySystemSettings 2008 server failed...");
//			return 825;
		}
                else
                {
                        WMILog("ModifySystemSettings 2008 server DONE!!!!!!!!!!");	
                }
		
		WMILog(L"Calling ModifyVirtualSystemResources");
		inParams = vmManagementService->GetMethodParameters("ModifyVirtualSystemResources");
		array<String^>^ memorySettingsarray = gcnew array<String^>(1);
		settingsText = memorySettings->GetText(TextFormat::WmiDtd20);
		memorySettingsarray[0] = settingsText;
		inParams["ResourceSettingData"] = memorySettingsarray;
		newVM = GetTargetComputer(newVMhvID, WMIconnectiondetails::scope);
		inParams["ComputerSystem"] = newVM;
		resultToCheck = vmManagementService->InvokeMethod("ModifyVirtualSystemResources", inParams, nullptr);
		WMILog("ModifyVirtualSystemResources Return Value STATE -> " + Convert::ToUInt16(resultToCheck["ReturnValue"]));
		result = ValidateOutput(resultToCheck, WMIconnectiondetails::scope);
		if (!result)
		{
			WMILog("ModifyVirtualSystemResources 2008 server failed...");
//			return 826;
		}
                else
                {
                        WMILog("ModifyVirtualSystemResources 2008 server DONE!!!!!!!!!!");
                }

	}
	catch (Exception^ ex)
	{
		WMILog(L"createnewVirtualMachine2008 Exception thrown: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
		return 810;
	}
	WMILog(L"createnewVirtualMachine2008 COMPLETED..!");
	return 0;

}