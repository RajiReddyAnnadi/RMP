#include "hvWMI.h"


HVVirtualMachine::HVVirtualMachine()
{
	WMILog("Empty constructor...");
}

HVVirtualMachine::HVVirtualMachine(String^ configurationXMLfileName)
{
	try
	{
		WMILog("HVVirtualMachine constructor XML File name -> " + configurationXMLfileName);
		XmlDocument^ doc = gcnew XmlDocument();
		doc->Load(configurationXMLfileName);

		XmlNodeList^ xnList = doc->SelectNodes("configuration/settings/memory/bank/size");
		for each(XmlNode^ xn in xnList)
		{
			WMILog("Memory -> " + xn->InnerText);
			this->RAMmemory = Convert::ToInt32(xn->InnerText);
		}

		xnList = doc->SelectNodes("configuration/properties/global_id");
		for each(XmlNode^ xn in xnList)
		{
			WMILog("global_id -> " + xn->InnerText);
			this->hvvmId = xn->InnerText;
			WMILog("global_id -> " + this->hvvmId);
		}

		//Generation
		xnList = doc->SelectNodes("configuration/properties/subtype");
		this->hvGeneration = "0";
		if(xnList!=nullptr)
		{
			for each(XmlNode^ xn in xnList)
			{
				WMILog("subtype -> " + xn->InnerText);
				this->hvGeneration = xn->InnerText;
				WMILog("subtype -> " + this->hvvmId);
			}
		}
		
		//memory
		this->isDynamicmemoryenabled = false;
		xnList = doc->SelectNodes("configuration/settings/memory/bank/dynamic_memory_enabled");
		for each(XmlNode^ xn in xnList)
		{	
			WMILog("dynamic_memory_enabled -> " + xn->InnerText);
			this->isDynamicmemoryenabled = xn->InnerText->Equals("True") ? true : false;
			WMILog("dynamic_memory_enabled -> " + this->isDynamicmemoryenabled);
		}

		xnList = doc->SelectNodes("configuration/settings/memory/bank/limit");
		for each(XmlNode^ xn in xnList)
		{
			WMILog("limit -> " + xn->InnerText);
			this->maxMemory = Convert::ToInt32(xn->InnerText);
		}

		xnList = doc->SelectNodes("configuration/settings/memory/bank/reservation");
		for each(XmlNode^ xn in xnList)
		{
			WMILog("reservation -> " + xn->InnerText);
			this->reservationMemory = Convert::ToInt32(xn->InnerText);
		}

		xnList = doc->SelectNodes("configuration/properties/name");
		for each(XmlNode^ xn in xnList)
		{
			WMILog("Name -> " + xn->InnerText);
			this->originalvmName = xn->InnerText;
		}

		xnList = doc->SelectNodes("configuration/settings/processors/count");
		for each(XmlNode^ xn in xnList)
		{
			WMILog("Processor Count -> " + xn->InnerText);
			this->processorCount = Convert::ToInt32(xn->InnerText);
		}

		xnList = doc->SelectNodes("//AltSwitchName");
		this->switchName="";
		for each(XmlNode^ xn in xnList)
		{
			WMILog("AltSwitchName -> " + xn->InnerText);
			this->switchName = xn->InnerText;
		}

		xnList = doc->SelectNodes("//SwitchName");
		this->switchName2008="";
		for each(XmlNode^ xn in xnList)
		{
			WMILog("switchName2008 -> " + xn->InnerText);
			this->switchName2008 = xn->InnerText;
		}


		this->controllerdriveDetails = gcnew Dictionary<Dictionary<String^, String^>^, List<Dictionary<String^, String^>^>^>();

		xnList = doc->SelectNodes("//*[starts-with(name(.),'controller')]");
		for each(XmlNode^ controllerNode in xnList)
		{
			WMILog("Node name -> " + controllerNode->Name);
			Dictionary<String^, String^>^ controllerInfo = gcnew Dictionary<String^, String^>();
			bool isScsi = false;
			for each(XmlNode^ child in controllerNode->ParentNode->ChildNodes)
			{
				if (child->Name->Contains("ChannelInstanceGuid"))
				{
					isScsi = true;
					break;
				}
			}
			WMILog("isScsi -> " + isScsi);

			controllerInfo->Add("controllerName", controllerNode->Name);
			if (isScsi)
			{
				controllerInfo->Add("isScsi", "true");
			}
			else
			{
				controllerInfo->Add("isScsi", "false");
			}

			List<Dictionary<String^, String^>^>^ driveInfoList = gcnew List<Dictionary<String^, String^>^>();

			for each(XmlNode^ driveNode in controllerNode->ChildNodes)
			{
				Dictionary<String^, String^>^ driveInfo = gcnew Dictionary<String^, String^>();

				WMILog("Drive name -> " + driveNode->Name);
				driveInfo->Add("driveName", driveNode->Name);
				bool isDriveEmpty = false;

				for each(XmlNode^ drivePropNode in driveNode->ChildNodes)
				{
					if (drivePropNode->Name->Equals("pathname"))
					{
						if (drivePropNode->InnerText->Equals("") || !(drivePropNode->InnerText->Contains("vhd")))
						{
							WMILog("DRIVE IS EMPTY!");
							isDriveEmpty = true;
							break;
						}
						driveInfo->Add("pathName", drivePropNode->InnerText);
						WMILog("Path Name -> " + drivePropNode->InnerText);
					}
					if (drivePropNode->Name->Equals("type"))
					{
						driveInfo->Add("type", drivePropNode->InnerText);
						WMILog("Type -> " + drivePropNode->InnerText);
					}
				}

				if (!isDriveEmpty)
				{
					driveInfoList->Add(driveInfo);
				}
			}
			controllerdriveDetails->Add(controllerInfo, driveInfoList);


		}
	}
	catch (Exception^ ex)
	{
		WMILog(L"Exception thrown in Constructor: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
	}
}
