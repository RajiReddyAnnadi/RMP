#include "BuildIndex.h"
#include <fcntl.h>

/* Deallocate an index built by build_index() */
void free_index(struct access *index) {
    if (index != NULL) {
        free(index->list);
        free(index);
    }
}
uint32_t read_uint32(gzFile gz)
{
    uint32_t v;
    gzread(gz, &v, sizeof(v));
    return v;
}
/* Add an entry to the access point list.  If out of memory, deallocate the
existing list and return NULL. */
struct access *addpoint(struct access *index, int bits,
        __int64 in, __int64 out, unsigned left, unsigned char *window) {
    struct point *next;

    /* if list is empty, create it (start with eight points) */
    if (index == NULL) {
        index = (struct access*) malloc(sizeof (struct access));
        if (index == NULL) return NULL;
        index->list = (point*) malloc(sizeof (struct point) << 3);
        if (index->list == NULL) {
            free(index);
            return NULL;
        }
        index->size = 8;
        index->have = 0;
    }/* if list is full, make it bigger */
    else if (index->have == index->size) {
        index->size <<= 1;
        next = (point*) realloc(index->list, sizeof (struct point) * index->size);
        if (next == NULL) {
            free_index(index);
            return NULL;
        }
        index->list = next;
    }

    /* fill in entry and increment how many we have */
    next = index->list + index->have;
    next->bits = bits;
    next->in = in;
    next->out = out;
    if (left)
        memcpy(next->window, window + WINSIZE - left, left);
    if (left < WINSIZE)
        memcpy(next->window + left, window, WINSIZE - left);
    index->have++;

    /* return list, possibly reallocated */
    return index;
}

/* Make one entire pass through the compressed stream and build an index, with
access points about every span bytes of uncompressed output -- span is
chosen to balance the speed of random access against the memory requirements
of the list, about 32K bytes per access point.  Note that data after the end
of the first zlib or gzip stream in the file is ignored.  build_index()
returns the number of access points on success (>= 1), Z_MEM_ERROR for out
of memory, Z_DATA_ERROR for an error in the input file, or Z_ERRNO for a
file read error.  On success, *built points to the resulting index. */
int build_index(FILE *in, __int64 span, struct access **built) {
    int ret;
    __int64 totin, totout; /* our own total counters to avoid 4GB limit */
    __int64 last; /* totout value of last access point */
    struct access *index; /* access points being generated */
    z_stream strm;
    unsigned char input[CHUNK];
    unsigned char window[WINSIZE];

    /* initialize inflate */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = inflateInit2(&strm, 47); /* automatic zlib or gzip decoding */
    if (ret != Z_OK)
        return ret;

    /* inflate the input, maintain a sliding window, and build an index -- this
    also validates the integrity of the compressed data using the check
    information at the end of the gzip or zlib stream */
    totin = totout = last = 0;
    index = NULL; /* will be allocated by first addpoint() */
    strm.avail_out = 0;
    do {
        /* get some compressed data from input file */
        strm.avail_in = fread(input, 1, CHUNK, in);
        if (ferror(in)) {
            ret = Z_ERRNO;
            goto build_index_error;
        }
        if (strm.avail_in == 0) {
            ret = Z_DATA_ERROR;
            goto build_index_error;
        }
        strm.next_in = input;

        /* process all of that, or until end of stream */
        do {
            /* reset sliding window if necessary */
            if (strm.avail_out == 0) {
                strm.avail_out = WINSIZE;
                strm.next_out = window;
            }

            /* inflate until out of input, output, or at end of block --
            update the total input and output counters */
            totin += strm.avail_in;
            totout += strm.avail_out;
            ret = inflate(&strm, Z_BLOCK); /* return at end of block */
            totin -= strm.avail_in;
            totout -= strm.avail_out;
            if (ret == Z_NEED_DICT)
                ret = Z_DATA_ERROR;
            if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
                goto build_index_error;
            if (ret == Z_STREAM_END)
                break;

            /* if at end of block, consider adding an index entry (note that if
            data_type indicates an end-of-block, then all of the
            uncompressed data from that block has been delivered, and none
            of the compressed data after that block has been consumed,
            except for up to seven bits) -- the totout == 0 provides an
            entry point after the zlib or gzip header, and assures that the
            index always has at least one access point; we avoid creating an
            access point after the last block by checking bit 6 of data_type
             */
            if ((strm.data_type & 128) && !(strm.data_type & 64) &&
                    (totout == 0 || totout - last > span)) {
                index = addpoint(index, strm.data_type & 7, totin,
                        totout, strm.avail_out, window);
                if (index == NULL) {
                    ret = Z_MEM_ERROR;
                    goto build_index_error;
                }
                last = totout;
            }
        } while (strm.avail_in != 0);
    } while (ret != Z_STREAM_END);

    /* clean up and return index (release unused entries in list) */
    (void) inflateEnd(&strm);
    index->list = (point*) realloc(index->list, sizeof (struct point) * index->have);
    index->size = index->have;
    *built = index;
    return index->size;

    /* return error */
build_index_error:
    (void) inflateEnd(&strm);
    if (index != NULL)
        free_index(index);
    return ret;
}

int build_indexForEncryptedFile(FILE *in, __int64 span, struct access **built, LPTSTR pszPassword)
{
	HCRYPTKEY hKey = generateHashKey(pszPassword);
	int ret;
	__int64 totin, totout;        /* our own total counters to avoid 4GB limit */
	__int64 last;                 /* totout value of last access point */
	struct access *index;       /* access points being generated */
	z_stream strm;
	unsigned char input[CHUNK];
	unsigned char window[WINSIZE];

	/* initialize inflate */
	strm.zalloc = Z_NULL;
	strm.zfree = Z_NULL;
	strm.opaque = Z_NULL;
	strm.avail_in = 0;
	strm.next_in = Z_NULL;
	ret = inflateInit2(&strm, 47);      /* automatic zlib or gzip decoding */
	if (ret != Z_OK)
		return ret;

	/* inflate the input, maintain a sliding window, and build an index -- this
	also validates the integrity of the compressed data using the check
	information at the end of the gzip or zlib stream */
	totin = totout = last = 0;
	index = NULL;               /* will be allocated by first addpoint() */
	strm.avail_out = 0;
	do {
		//printf("in build_index\n");
		/* get some compressed data from input file */
		strm.avail_in = fread(input, 1, CHUNK, in);
		if (ferror(in)) {
			ret = Z_ERRNO;
			goto build_index_error;
		}
		if (strm.avail_in == 0) {
			ret = Z_DATA_ERROR;
			goto build_index_error;
		}

		//decrypt logic
		DWORD dwBlockLen;
		DWORD dwBufferLen;
		dwBlockLen = strm.avail_in;
		dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
		bool fEOF = FALSE;
		if (dwBlockLen < CHUNK) {
			fEOF = TRUE;
		}
		strm.avail_in = decryptBuffer(hKey, input, dwBlockLen, fEOF);

		strm.next_in = input;

		/* process all of that, or until end of stream */
		do {
			/* reset sliding window if necessary */
			if (strm.avail_out == 0) {
				strm.avail_out = WINSIZE;
				strm.next_out = window;
			}

			/* inflate until out of input, output, or at end of block --
			update the total input and output counters */
			totin += strm.avail_in;
			totout += strm.avail_out;
			ret = inflate(&strm, Z_BLOCK);      /* return at end of block */
			totin -= strm.avail_in;
			totout -= strm.avail_out;
			if (ret == Z_NEED_DICT)
				ret = Z_DATA_ERROR;
			if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
				goto build_index_error;
			if (ret == Z_STREAM_END)
				break;

			/* if at end of block, consider adding an index entry (note that if
			data_type indicates an end-of-block, then all of the
			uncompressed data from that block has been delivered, and none
			of the compressed data after that block has been consumed,
			except for up to seven bits) -- the totout == 0 provides an
			entry point after the zlib or gzip header, and assures that the
			index always has at least one access point; we avoid creating an
			access point after the last block by checking bit 6 of data_type
			*/
			if ((strm.data_type & 128) && !(strm.data_type & 64) &&
				(totout == 0 || totout - last > span)) {
				index = addpoint(index, strm.data_type & 7, totin,
					totout, strm.avail_out, window);
				if (index == NULL) {
					ret = Z_MEM_ERROR;
					goto build_index_error;
				}
				last = totout;
			}
		} while (strm.avail_in != 0);
	} while (ret != Z_STREAM_END);

	/* clean up and return index (release unused entries in list) */
	(void)inflateEnd(&strm);
	index->list = (point*)realloc(index->list, sizeof(struct point) * index->have);
	index->size = index->have;
	*built = index;
	return index->size;

	/* return error */
build_index_error:
	(void)inflateEnd(&strm);
	if (index != NULL)
		free_index(index);
	return ret;
}

int write_uint32(gzFile gz, uint32_t v) {
    return gzwrite(gz, &v, sizeof (v));
}

/* Demonstrate the use of build_index() and extract() by processing the file
provided on the command line, and the extracting 16K from about 2/3rds of
the way through the uncompressed output, and writing that to stdout. */
int indexCreation(wstring backupFile, boolean isEncrypted, LPWSTR secretKey, Loggerclass *logidx) {
    size_t pos = backupFile.rfind(L".");
    wstring indexName = backupFile.substr(0, pos) + L".idx";
    int len;
    off_t offset;
    FILE *in;
    struct access *index = NULL;
    unsigned char buf[CHUNK];

//    in = fopen(fileName.c_str(), "rb");
    int fd = _wopen(backupFile.c_str(), _O_RDONLY | _O_BINARY);
    if (fd == -1) {
        int errsv = errno;
        logidx->log(NORMAL, L"source file: could not open for reading\n");
        return 1;
    }
    else {
        logidx->log(NORMAL, L"source file : fd ok\n");
    }
    in = _fdopen(fd, "rb");
    if (in == NULL) {
        logidx->log(NORMAL, L"zran: could not open %ws for reading\n", backupFile.c_str());
        return 1;
    }

    /* build index */
	if (isEncrypted) {
		len = build_indexForEncryptedFile(in, SPAN, &index, secretKey);
	}else {
        len = build_index(in, SPAN, &index);
    }
    if (len < 0) {
        fclose(in);
        switch (len) {
            case Z_MEM_ERROR:
                logidx->log(NORMAL, L"zran: out of memory\n");
                break;
            case Z_DATA_ERROR:
                logidx->log(NORMAL, L"zran: compressed data error in %ws\n", backupFile.c_str());
                break;
            case Z_ERRNO:
                logidx->log(NORMAL, L"zran: read error on %ws\n", backupFile.c_str());
                break;
            default:
                logidx->log(NORMAL, L"zran: error %d while building index\n", len);
        }
        return 1;
    }
    logidx->log(NORMAL, L"zran: built index with %d access points\n", len);
    fclose(in);

//    gzFile gz = gzopen(indexFile.c_str(), "wb");
    fd = _wopen(indexName.c_str(), _O_CREAT | _O_WRONLY | _O_BINARY);
    if (fd == -1) {
        int errsv = errno;
        logidx->log(NORMAL, L"index file: could not open for writing\n");
        return 1;
    }
    else {
        logidx->log(NORMAL, L"index file : fd ok\n");
    }
    gzFile gz = gzdopen(fd, "wb");
    if (gz == NULL) {
        logidx->log(NORMAL, L"gz null\n");
    }

    // Write a header.
    write_uint32(gz, (uint32_t) index->have);

    // Write out entry points.
    for (int i = 0; i < index->have; ++i) {
        gzwrite(gz, &index->list[i].out, sizeof (__int64));
        gzwrite(gz, &index->list[i].in, sizeof (__int64));
        gzwrite(gz, &index->list[i].bits, sizeof (int));
        gzwrite(gz, index->list[i].window, WINSIZE);
    }

    if (gz != NULL) {
        gzclose(gz);
    }
    if (index != NULL) {
        free_index(index);
    }
    return 0;
}
struct access *getIndexforFile(struct access *index, wchar_t* indexFile, Loggerclass *logdrive)
{
    logdrive->log(NORMAL, L"BuildIndex.cpp Loading Index for index file : %ws\n", indexFile);
    int fd = _wopen(indexFile, _O_RDONLY | _O_BINARY);
    if (fd == -1) {
        int errsv = errno;
        logdrive->log(NORMAL, L"BuildIndex.cpp _wopen index error : %d\n", errsv);
        return NULL;
    }
    else {
        logdrive->log(NORMAL, L"BuildIndex.cpp fd not -1 : A-OK [%d]\n", __LINE__);
    }
    gzFile gz = gzdopen(fd, "rb");
    if (gz == NULL) {
        logdrive->log(NORMAL, L"BuildIndex.cpp gzdopen index error at %d\n", __LINE__);
    }

    // Allocate a seekgzip_t instance.
    index = (struct access *)malloc(sizeof(struct access));
    if (index == NULL) {
        logdrive->log(NORMAL, L"BuildIndex.cpp Index null.out of memory\n");
        return NULL;
    }
    memset(index, 0, sizeof(*index));

    // Read the number of entry points.
    index->have = index->size = read_uint32(gz);

    // Allocate an array for entry points.
    index->list = (struct point *)malloc(sizeof(struct point) * index->have);
    if (index->list == NULL) {
        logdrive->log(NORMAL, L"BuildIndex.cpp Index->list empty");
    }
    logdrive->log(NORMAL, L"BuildIndex.cpp Index size : %d\n", index->have);
    // Read entry points.
    for (int m = 0; m < index->have; ++m) {
        gzread(gz, &index->list[m].out, sizeof(__int64));
        gzread(gz, &index->list[m].in, sizeof(__int64));
        gzread(gz, &index->list[m].bits, sizeof(int));
        gzread(gz, index->list[m].window, WINSIZE);
    }
    if (gz != NULL) {
        gzclose(gz);
    }
    logdrive->log(NORMAL, L"BuildIndex.cpp Building Index for file is completed..\n");
    return index;
}

int extract(FILE *in, struct access *index, __int64 offset,
            unsigned char *buf, int len)
{
    int ret, skip;
    z_stream strm;
    struct point *here;
    unsigned char input[CHUNK];
    unsigned char discard[WINSIZE];

    //clock_t t1, t2;
    /* proceed only if something reasonable to do */
    if (len < 0)
        return 0;

    /* find where in stream to start */
    here = index->list;
    ret = index->have;

    //t1 = clock();
    while (--ret && here[1].out <= offset)
    {
        //fprintf(outputFile, "in while\n");
        here++;
    }
    //t2 = clock();
    //long timediff = ((long)t2 - (long)t1);
    //long seconds = timediff;
    //fprintf(outputFile, "while Time diff %ld", seconds);
    //cout << "while Time diff " << seconds << endl;

    /* initialize file and inflate state to start there */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = inflateInit2(&strm, -15); /* raw inflate */
    if (ret != Z_OK)
        return ret;
    long long seekValue = here->in - (here->bits ? 1 : 0);
    ret = _fseeki64(in, seekValue, SEEK_SET);
    if (ret == -1)
        goto extract_ret;
    if (here->bits)
    {
        ret = getc(in);
        if (ret == -1)
        {
            ret = ferror(in) ? Z_ERRNO : Z_DATA_ERROR;
            goto extract_ret;
        }
        (void)inflatePrime(&strm, here->bits, ret >> (8 - here->bits));
    }
    (void)inflateSetDictionary(&strm, here->window, WINSIZE);

    /* skip uncompressed bytes until offset reached, then satisfy request */
    offset -= here->out;
    strm.avail_in = 0;
    skip = 1; /* while skipping to offset */
    do
    {
        /* define where to put uncompressed data, and how much */
        if (offset == 0 && skip)
        { /* at offset now */
            strm.avail_out = len;
            strm.next_out = buf;
            skip = 0; /* only do this once */
        }
        if (offset > WINSIZE)
        { /* skip WINSIZE bytes */
            strm.avail_out = WINSIZE;
            strm.next_out = discard;
            offset -= WINSIZE;
        }
        else if (offset != 0)
        { /* last skip */
            strm.avail_out = (unsigned)offset;
            strm.next_out = discard;
            offset = 0;
        }

        /* uncompress until avail_out filled, or end of stream */
        do
        {
            if (strm.avail_in == 0)
            {
                strm.avail_in = fread(input, 1, CHUNK, in);
                if (ferror(in))
                {
                    ret = Z_ERRNO;
                    goto extract_ret;
                }
                if (strm.avail_in == 0)
                {
                    ret = Z_DATA_ERROR;
                    goto extract_ret;
                }
                strm.next_in = input;
            }
            ret = inflate(&strm, Z_NO_FLUSH); /* normal inflate */
            if (ret == Z_NEED_DICT)
                ret = Z_DATA_ERROR;
            if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
                goto extract_ret;
            if (ret == Z_STREAM_END)
                break;
        } while (strm.avail_out != 0);

        /* if reach end of stream, then don't keep trying to get more */
        if (ret == Z_STREAM_END)
            break;

        /* do until offset reached and requested data read, or stream ends */
    } while (skip);

    /* compute number of uncompressed bytes read after offset */
    ret = skip ? 0 : len - strm.avail_out;
//    if(!ret && !feof(in))
//        ret = Z_DATA_ERROR;
    /* clean up and return bytes read or error */
extract_ret:
    (void)inflateEnd(&strm);
    return ret;
}

int extractDecrypt(FILE* in, struct access *index, __int64 offset, unsigned char *buf, int len, LPTSTR secretKey)
{
    int ret, skip;
    z_stream strm;
    struct point *here;
    unsigned char input[CHUNK];
    unsigned char discard[WINSIZE];
    HCRYPTKEY hKey = generateHashKey(secretKey);
    /* proceed only if something reasonable to do */
    if (len < 0)
        return 0;

    /* find where in stream to start */
    here = index->list;
    ret = index->have;
    while (--ret && here[1].out <= offset)
    {
        here++;
    }

    /* initialize file and inflate state to start there */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    strm.avail_in = 0;
    strm.next_in = Z_NULL;
    ret = inflateInit2(&strm, -15); /* raw inflate */
    if (ret != Z_OK)
    {
        return ret;
    }
    int remainder = (here->in - (here->bits ? 1 : 0)) % CHUNK;
    uint64_t seekValue = (here->in - (here->bits ? 1 : 0)) / CHUNK * CHUNK;
    if (here->in < CHUNK)
    {
        seekValue = 0;
        remainder = here->in - (here->bits ? 1 : 0);
    }
    ret = _fseeki64(in, seekValue, SEEK_SET); //replace this after decryption
    if (ret == -1)
    {
        goto extract_ret;
    }

    /* skip uncompressed bytes until offset reached, then satisfy request */
    offset -= here->out;
    strm.avail_in = 0;
    skip = 1; /* while skipping to offset */
    boolean alreadyMoved = false;
    boolean tempBuf = false;
    do
    {
        /* define where to put uncompressed data, and how much */
        if (offset == 0 && skip)
        { /* at offset now */
            strm.avail_out = len;
            strm.next_out = buf;
            skip = 0; /* only do this once */
        }
        if (offset > WINSIZE)
        { /* skip WINSIZE bytes */
            strm.avail_out = WINSIZE;
            strm.next_out = discard;
            offset -= WINSIZE;
        }
        else if (offset != 0)
        { /* last skip */
            strm.avail_out = (unsigned)offset;
            strm.next_out = discard;
            offset = 0;
        }

        /* uncompress until avail_out filled, or end of stream */
        unsigned char tempBuffer[CHUNK];
        do
        {
            if (strm.avail_in == 0)
            {
                //to handle the next decryption
//                if (!tempBuf && seekValue != 0)
//                {
//                    fseek(in, -CHUNK, SEEK_CUR);
//                    int test = fread(tempBuffer, 1, CHUNK, in);
//                    tempBuf = true;
//                    bool fEOF = FALSE;
//                    if (test < CHUNK)
//                    {
//                        fEOF = TRUE;
//                    }
//                    test = decryptBuffer(hKey, tempBuffer, test, fEOF);
//                }

                strm.avail_in = fread(input, 1, CHUNK, in);
                if (ferror(in))
                {
                    ret = Z_ERRNO;
                    goto extract_ret;
                }
                if (strm.avail_in == 0)
                {
                    ret = Z_DATA_ERROR;
                    goto extract_ret;
                }
                strm.next_in = input;

                //decrypt logic
                DWORD dwBlockLen;
                DWORD dwBufferLen;
                dwBlockLen = strm.avail_in;
                dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
                bool fEOF = FALSE;
                if (dwBlockLen < CHUNK)
                {
                    fEOF = TRUE;
                }

                strm.avail_in = decryptBuffer(hKey, input, dwBlockLen, fEOF);

                strm.next_in = input;

                //remove bits before inflate
                int moverCount = remainder; //here->in - (here->bits ? 1 : 0);

                for (int testMove = 0; testMove < moverCount && !alreadyMoved; testMove++)
                {
                    strm.next_in++;
                    strm.avail_in--;
                }

                int getcValue = 0;
                if (here->bits && !alreadyMoved)
                { //getc logic
                    getcValue = strm.next_in[0];
                    strm.next_in++;
                    strm.avail_in--;
                }

                //logic for bits inflate prime
                if (!alreadyMoved)
                {
                    uInt avail_in_temp = strm.avail_in;
                    z_const Bytef *next_in_temp = strm.next_in;
                    if (here->bits)
                    {
                        ret = getcValue; //need to add logic for this code
                        if (ret == -1)
                        {
                            ret = ferror(in) ? Z_ERRNO : Z_DATA_ERROR;
                            goto extract_ret;
                        }
                        (void)inflatePrime(&strm, here->bits, ret >> (8 - here->bits));
                    }
                    (void)inflateSetDictionary(&strm, here->window, WINSIZE);
                    strm.next_in = next_in_temp;
                    strm.avail_in = avail_in_temp;
                }
                alreadyMoved = true;
            }

            ret = inflate(&strm, Z_NO_FLUSH); /* normal inflate */
            if (ret == Z_NEED_DICT)
            {
                ret = Z_DATA_ERROR;
            }
            if (ret == Z_MEM_ERROR || ret == Z_DATA_ERROR)
                goto extract_ret;
            if (ret == Z_STREAM_END)
                break;
        } while (strm.avail_out != 0);

        /* if reach end of stream, then don't keep trying to get more */
        if (ret == Z_STREAM_END)
            break;

        /* do until offset reached and requested data read, or stream ends */
    } while (skip);
    /* compute number of uncompressed bytes read after offset */
    ret = skip ? 0 : len - strm.avail_out;

    /* clean up and return bytes read or error */
    extract_ret:
    (void)inflateEnd(&strm);
    return ret;
}
HCRYPTKEY generateHashKey(LPTSTR pszPassword)
{
    HCRYPTPROV hCryptProv = NULL;
    HCRYPTKEY hKey = NULL;
    HCRYPTHASH hHash = NULL;
    if (CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, 0)) {
        if (CryptCreateHash(hCryptProv, CALG_MD5, 0, 0, &hHash)) {
            if (CryptHashData(hHash, (BYTE *)pszPassword, lstrlen(pszPassword), 0)) {
                if (CryptDeriveKey(hCryptProv, ENCRYPT_ALGORITHM, hHash, KEYLENGTH, &hKey)) {
                    return hKey;
                }else {
                    //cout << "\n CryptDeriveKey failed" << endl;
                    return -1;
                }
            }else{
                //cout << "\n CryptHashData failed" << endl;
                return -1;
            }
        }else {
            //cout << "\n CryptCreateHash failed" << endl;
            return -1;
        }
    }else {
        //cout << "\n CryptAcquireContext failed" << endl;
        return -1;
    }
}
unsigned decryptBuffer(HCRYPTKEY hKey, PBYTE pbBuffer, DWORD dwCount, bool fEOF)
{
    if (pbBuffer != NULL) {
        if (CryptDecrypt(hKey, NULL, fEOF, 0, pbBuffer, &dwCount)) {
            return dwCount; //return encrypted buffer
        }else {
            DWORD dw = GetLastError();
        }
    }else {
        //cout << "\n pbBuffer null" << endl;
    }
}