#pragma once
#include "hvWMI.h"
#include "Loggerclass.h"


Loggerclass *logdrive;
LPWSTR level = NORMAL;
int PerformVSSSnapshot(LPWSTR fullbackupVMs, LPWSTR incrementalbackupVMs, BSTR repositoryPath, BSTR backupName, BSTR scheduleName)
{
	logdrive->log(NORMAL, L"hvbackup.cpp PerformVSSSnapshot started...\n");
	try
	{
		HRESULT  result;
		result = ModifyPrivilege(SE_BACKUP_NAME, TRUE);
		CheckHRESULT(result, L"ModifyPrivilege");

		/*	bool testvss = VssSupport(location);
		if (!testvss)
		{
		return 404;
		}*/

		CComBSTR bstrss;
		bstrss.Attach(SysAllocString(repositoryPath));
		BSTR temp = SysAllocString(L"\\");
		bstrss.AppendBSTR(temp);
		BSTR repositoryPathNew = bstrss.Detach();
		repositoryPathNew = SysAllocString(repositoryPathNew);

		std::list<BSTR> fullvmList;
		std::list<BSTR> incrementalvmList;
		std::list<BSTR> allvmList;
		//std::list<BSTR> runningvmList;

		logdrive->log(NORMAL, L"hvbackup.cpp PerformVSSSnapshot fullbackupVMs ->  %ws\n", fullbackupVMs);

		wchar_t *backupVM = NULL;
		wchar_t *nextbackupVM = NULL;

		if (wcscmp(fullbackupVMs, L"-") != 0)
		{
			wchar_t *fullbackupVMswstring = new wchar_t[wcslen(fullbackupVMs) + 1];
			wcscpy(fullbackupVMswstring, fullbackupVMs);

			logdrive->log(NORMAL, L"hvbackup.cpp There are some VMs for full backup...\n");
			backupVM = wcstok_s(fullbackupVMswstring, L";", &nextbackupVM);
			while (backupVM != NULL)
			{
				logdrive->log(NORMAL, L"VM to full backup ->  %ws\n", backupVM);
				fullvmList.push_back(backupVM);
				/*logdrive->log(NORMAL, L"hvbackup.cpp PerformVSSSnapshot Moving VM to Paused State..\n");
				String^ fullVM = gcnew String(backupVM, 0, wcslen(backupVM));
				bool isVMRunning = checkifVMRunning(fullVM);
				if(isVMRunning)
				{
					runningvmList.push_back(backupVM);
				}
				bool isVMpaused = moveVMtoSavedState(fullVM);*/
				backupVM = wcstok_s(NULL, L";", &nextbackupVM);
			}
		}

		if (wcscmp(incrementalbackupVMs, L"-") != 0)
		{
			wchar_t *incrementalbackupVMswstring = new wchar_t[wcslen(incrementalbackupVMs) + 1];
			wcscpy(incrementalbackupVMswstring, incrementalbackupVMs);

			logdrive->log(NORMAL, L"hvbackup.cpp There are some VMs for incremental backup...\n");
			backupVM = wcstok_s(incrementalbackupVMswstring, L";", &nextbackupVM);
			while (backupVM != NULL)
			{
				logdrive->log(NORMAL, L"hvbackup.cpp PerformVSSSnapshot VM to incremental backup ->  %ws\n", backupVM);
				incrementalvmList.push_back(backupVM);
				/*logdrive->log(NORMAL, L"hvbackup.cpp PerformVSSSnapshot Moving VM to Paused State..\n");
				String^ incrVM = gcnew String(backupVM, 0, wcslen(backupVM));
				bool isVMRunning = checkifVMRunning(incrVM);
				if(isVMRunning)
				{
					runningvmList.push_back(backupVM);
				}
				bool isVMpaused = moveVMtoSavedState(incrVM);*/
				backupVM = wcstok_s(NULL, L";", &nextbackupVM);
			}
		}
			
		//attach both lists for doing snapshots
		if (fullvmList.empty())
		{
			allvmList = incrementalvmList;
		}
		else
		{
			allvmList = fullvmList;
			std::list<BSTR>::iterator it = allvmList.end();
			allvmList.splice(it, incrementalvmList);
		}

		logdrive->log(NORMAL, L"hvbackup.cpp PerformVSSSnapshot allvmList built. Size ->  %d\n", allvmList.size());

		if (allvmList.empty())
		{
			logdrive->log(NORMAL, L"HVBackup.cpp PerformVSSSnapshot allvmList empty");
			return 405;
		}

		//take snapshot
		std::list<IVssWMComponent*> componentListtoBackup = DoVSSSnapshot(allvmList, repositoryPathNew, scheduleName, backupName, fullvmList, incrementalvmList);

		//after snapshot, move all incremetnal vms back to running state
		/*for (auto itr = runningvmList.begin(); itr != runningvmList.end(); ++itr)
		{
			BSTR vmName = *itr;
			String^ incrVM = gcnew String(vmName, 0, wcslen(vmName));
			logdrive->log(NORMAL, L"hvbackup.cpp PerformVSSSnapshot Moving VM back to STARTED State..\n");
			bool isVMstarted = RequestStateChange(incrVM, Convert::ToUInt16(2));
		}	*/	
		if (componentListtoBackup.empty())
		{
			logdrive->log(NORMAL, L"hvbackup.cpp PerformVSSSnapshot componentListtoBackup is empty\n");
			return 406;
		}

		//SetBackupCompletedstatus(componentListtoBackup, false);
		CloseVss();
		logdrive->log(NORMAL, L"hvbackup.cpp PerformVSSSnapshot ends...\n");
		return 0;//success

	}
	catch (exception& ex)
	{
		logdrive->log(NORMAL, L"hvbackup.cpp PerformVSSSnapshot HVFullBackup Exception message: %ws\n", ex.what());
		return 400;
	}
}

int connecttoRepositories(List<repoCredentials^>^ repoCredentialslist, LPWSTR connectStatus)
{
	for each(repoCredentials^ obj in repoCredentialslist)
	{
		String^ user = obj->userName;
		String^ pass = obj->password;
		String^ repoPathString = obj->repoPath;		

		std::wstring userwstring = msclr::interop::marshal_as<std::wstring>(user);
		std::wstring passwstring = msclr::interop::marshal_as<std::wstring>(pass);
		std::wstring repowstring = msclr::interop::marshal_as<std::wstring>(repoPathString);

		logdrive->log(NORMAL, L"hvbackup.cpp connecttoRepositories Connecting to repo path -> %ws\n",(LPWSTR)repowstring.c_str());
		int repositoryConnectionDetails = checkCredentials((LPWSTR)repowstring.c_str(), (LPWSTR)userwstring.c_str(), (LPWSTR)passwstring.c_str(), connectStatus);
		if(repositoryConnectionDetails!=-99)
		{
			logdrive->log(NORMAL, L"hvbackup.cpp connecttoRepositories Repository Connection Failed -> %d for path -> %ws...\n",repositoryConnectionDetails, repoPathString);
					//todo -> log error based on returned value and exit
			return -1;
		}
	}
	logdrive->log(NORMAL, L"hvbackup.cpp connecttoRepositories Repository Connecting SUCCESSFUL returning 0..\n");
	return 0;
}

int generateHashforDirectory(wchar_t* backupFolder, wchar_t* backupType, wchar_t* backupIdentifier, wchar_t* isEncrypted, wchar_t* encryptPassword, wchar_t* hashType)
{
    logdrive->log(NORMAL, L"hvbackup.cpp generateHashforDirectory for backupFolder: %ws\n", backupFolder);
    try{
        int retVal = 0;
        String^ protectFolder = gcnew String(backupFolder, 0, wcslen(backupFolder));
        DirectoryInfo^ dir = gcnew DirectoryInfo(protectFolder);
        if (!dir->Exists)
        {
            logdrive->log(NORMAL, L"hvbackup.cpp generateHashforDirectory backup Directory not found..\n");
            throw gcnew DirectoryNotFoundException("hvbackup.cpp generateHashforDirectory backup Directory not found");
        }
        else
        {
            if (Directory::GetFiles(protectFolder)->Length == 0)
            {
                logdrive->log(NORMAL, L"hvbackup.cpp generateHashforDirectory backup Directory found but empty!..\n");
                throw gcnew DirectoryNotFoundException("hvbackup.cpp generateHashforDirectory backup Directory found but empty!");
            }
        }
        //Just create a empty single hash file to avoid unable to open file error during health check - The incremental backup might not contain any backup files, if there is no reads for the VM.
        FILE *singlehashFile;
        wchar_t* singlehashfilepath = new wchar_t[wcslen(backupFolder) + wcslen(hashType) +  wcslen(L"_single_") + wcslen(backupIdentifier) + wcslen(L".txt") + 2];
        wcscpy(singlehashfilepath, backupFolder);
        wcscat(singlehashfilepath, L"\\");
        wcscat(singlehashfilepath, hashType);
        wcscat(singlehashfilepath, L"_single_");
        wcscat(singlehashfilepath, backupIdentifier);
        wcscat(singlehashfilepath, L".txt");
        wcscat(singlehashfilepath, L"\0");
        _wfopen_s(&singlehashFile, singlehashfilepath, L"a");
        if(singlehashFile){ fclose(singlehashFile);}

        array<String^> ^ backupFiles;
        if(wcscmp(backupType, L"FullBackup")==0) {
            if(wcscmp(isEncrypted, L"true") == 0) {
                backupFiles = Directory::GetFiles(protectFolder, "*_secure");
            }else {
                backupFiles = Directory::GetFiles(protectFolder, "*vhd?");
            }
            for each(String^ backupFile in backupFiles)
            {
                String^ backupFileTemp = backupFile->Substring(0, backupFile->LastIndexOf("."));//remove extension for Name of Hash File
                IntPtr ip = Marshal::StringToBSTR(backupFile);
                BSTR sourceFilePath = static_cast<BSTR>(ip.ToPointer());
                ip = Marshal::StringToBSTR(backupFileTemp);
                BSTR destFilePath = static_cast<BSTR>(ip.ToPointer());
                //logdrive->log(NORMAL, L"hvbackup.cpp generateHashforDirectory Calling generateSingleHashandBloackbyBlockHashforFile...\n");
                retVal = generateSingleHashandBloackbyBlockHashforFile(backupFolder, sourceFilePath, destFilePath, backupIdentifier, isEncrypted, encryptPassword, hashType, L"vhd");
                logdrive->log(NORMAL, L"hvbackup.cpp generateSingleHashandBloackbyBlockHashforFile return value -> %d\n", retVal);
                if(retVal) {
                    return retVal;
                }
            }
        }else {
            backupFiles = Directory::GetFiles(protectFolder, "*metadata.txt");
            for each(String^ backupFile in backupFiles)
            {
                String^ backupFileTemp = backupFile->Substring(0, backupFile->LastIndexOf("metadata.txt"));//remove extension for Name of Hash File
                //String^ backupFileTemp = backupFileTemp->Substring(0, backupFile->IndexOf("."));
                IntPtr ip = Marshal::StringToBSTR(backupFile);
                BSTR sourceFilePath = static_cast<BSTR>(ip.ToPointer());
                //logdrive->log(NORMAL, L"hvbackup.cpp generateHashforDirectory Calling generateHashforFile...\n");
                retVal = generateHashforFile(sourceFilePath, backupFolder, backupIdentifier, hashType, L"True", L"a", L"metadata");
                logdrive->log(NORMAL, L"hvbackup.cpp generateHashforFile return value -> %d\n", retVal);
                if(retVal) {
                    return retVal;
                }
            }

            backupFiles = Directory::GetFiles(protectFolder, "*.bin");
            for each(String^ backupFile in backupFiles)
            {
                String^ backupFileTemp = backupFile->Substring(0, backupFile->LastIndexOf("backup.bin"));//remove extension for Name of Hash File
                //String^ backupFileTemp = backupFileTemp->Substring(0, backupFile->IndexOf("."));
                IntPtr ip = Marshal::StringToBSTR(backupFile);
                BSTR sourceFilePath = static_cast<BSTR>(ip.ToPointer());
                ip = Marshal::StringToBSTR(backupFileTemp);
                BSTR destFilePath = static_cast<BSTR>(ip.ToPointer());
                //logdrive->log(NORMAL, L"hvbackup.cpp generateHashforDirectory Calling generateSingleHashandBlockbyBlockforBinFile...\n");
                retVal = generateSingleHashandBlockbyBlockforBinFile(backupFolder, sourceFilePath, destFilePath, backupIdentifier, hashType, L"bin");
                logdrive->log(NORMAL, L"hvbackup.cpp generateSingleHashandBlockbyBlockforBinFile return value -> %d\n", retVal);
                if(retVal) {
                    return retVal;
                }
            }
        }
        logdrive->log(NORMAL, L"hvbackup.cpp generateHashforDirectory Finished...\n");
        return retVal;
    }
	catch (exception& ex)
	{
		logdrive->log(NORMAL, L"hvbackup.cpp generateHashforDirectory. Exception message: %ws\n", ex.what());
		return 457;
	}
}

int performHealthCheck(List<backupDetails^>^ backupDetailsList, wchar_t* hypervVMID, wchar_t* backupId, wchar_t* vmId, wchar_t* isEncrypted, wchar_t* encryptPassword,  wchar_t*(*commonCallBackMethod)(wchar_t*, wchar_t*))
{
    logdrive->log(NORMAL, L"hvbackup.cpp performHealthCheck...\n");
    int hcBkupType = 0, returnVal = 0;
    wchar_t *parameter = L"", *callbackRet = NULL;
        try {
            for each(backupDetails^ backupDetail in backupDetailsList) {
                String^ vmbackupPathString = backupDetail->backupPath;
                std::wstring vmbackupPathWstring = msclr::interop::marshal_as<std::wstring>(vmbackupPathString);
                wchar_t *vmbackupPath = new wchar_t[vmbackupPathWstring.length() + 1];
                wcscpy(vmbackupPath, vmbackupPathWstring.c_str());
                wcscat(vmbackupPath, L"\0");

                String^ backupTypeString = backupDetail->backupType;
                std::wstring backupTypeWstring = msclr::interop::marshal_as<std::wstring>(backupTypeString);
                wchar_t *backupType = new wchar_t[backupTypeWstring.length() + 1];
                wcscpy(backupType, backupTypeWstring.c_str());
                wcscat(backupType, L"\0");

                String^ backupIdentifierString = backupDetail->backupIdentifier;
                std::wstring backupIdentifierWstring = msclr::interop::marshal_as<std::wstring>(backupIdentifierString);
                wchar_t *backupIdentifier = new wchar_t[backupIdentifierWstring.length() + 1];
                wcscpy(backupIdentifier, backupIdentifierWstring.c_str());
                wcscat(backupIdentifier, L"\0");

                //logdrive->log(NORMAL, L"hvbackup.cpp performHealthCheck calling generateHashforDirectory for BackupFiles...\n");
                returnVal = generateHashforDirectory(vmbackupPath, backupType, backupIdentifier, isEncrypted, encryptPassword, L"healthcheckhash");
                logdrive->log(NORMAL, L"hvbackup.cpp  generateHashforDirectory for BackupFiles. return value : %d\n", returnVal);
                if(returnVal) {
                    if(hcBkupType) {
                        hcBkupType = 1;
                        returnVal = 0;
                    }
                    break;
                }
                returnVal = checkHash(vmbackupPath, backupId, hypervVMID, backupIdentifier, backupType);
                logdrive->log(NORMAL, L"hvbackup.cpp  checkHash for Backup Files. return value :%d\n", returnVal);
                if(returnVal) {
                    if(returnVal <= 2) {
                        if(hcBkupType == 0) {
                            parameter = new wchar_t[wcslen(backupIdentifier) + wcslen(vmId) + 2];
                            wcscpy(parameter, backupIdentifier);
                            wcscat(parameter, L";");
                            wcscat(parameter, vmId);
                            wcscat(parameter, L"\0");
                            callbackRet = commonCallBackMethod(L"updateCorrutedBackupPoints", parameter);
                            logdrive->log(NORMAL, L"hvbackup.cpp callback return value :%ws\n",callbackRet);
                        }
                        hcBkupType = returnVal;
                        returnVal = 0;
                        if(hcBkupType == 1){
                            break;
                        }
                    }else{
                        if(hcBkupType) {
                            hcBkupType = 1;
                            returnVal = 0;
                        }
                        break;
                    }
                }
            }

			logdrive->log(NORMAL, L"hvbackup.cpp  PerformHealthCheck ended...!!\n");

		    wchar_t whcBkupType[11];
            _itow(hcBkupType, whcBkupType, 10);
            parameter = new wchar_t[wcslen(backupId) + wcslen(vmId) + wcslen(whcBkupType) + 3];
            wcscpy(parameter, backupId);
            wcscat(parameter, L";");
            wcscat(parameter, vmId);
            wcscat(parameter, L";");
            wcscat(parameter, whcBkupType);
            wcscat(parameter, L"\0");
            callbackRet = commonCallBackMethod(L"updateHcBackupTypeofVM", parameter);
            logdrive->log(NORMAL, L"hvbackup.cpp callback return value:%ws\n",callbackRet);
            return returnVal;
     	}catch (exception& ex) {
     		logdrive->log(NORMAL, L"hvbackup.cpp performHealthCheck. Exception message: %ws\n", ex.what());
     		return 460;
     	}

}

extern "C"
{
	__declspec(dllexport) int encryptdecrypt(LPWSTR repositoryPath, LPWSTR scheduleName, LPWSTR backupName, LPWSTR vmName, int operation, LPWSTR pszPassword)
	{
		int encryptResult=0, encryptTemp=0;
		HRESULT  result = CoInitialize(NULL);
		wstring logfileLoc = std::wstring(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\EncryptionLog.txt");
		LPWSTR logfileLocation = (LPWSTR)logfileLoc.c_str();
		logdrive = new Loggerclass(logfileLocation, (LPWSTR)level);
		InitializeGlobalvariables(logdrive);

		logdrive->log(NORMAL, L"hvbackup.cpp encryptdecrypt started for location %ws...\n", repositoryPath);

		//constructing path variable
		wchar_t* backupFolder;
		if(wcscmp(scheduleName, L"-")==0)
		{ 
			backupFolder = new wchar_t[wcslen(repositoryPath) + wcslen(vmName) +3];
			wcscpy(backupFolder, repositoryPath);
			wcscat(backupFolder, L"\\");
			wcscat(backupFolder, vmName);
			wcscat(backupFolder, L"\\");
			wcscat(backupFolder, L"\0");
			logdrive->log(NORMAL, L"EncryptionDecryption IF case So RESTORE backupFolder: %ws\n", backupFolder);
		}
		else
		{
			backupFolder = new wchar_t[wcslen(repositoryPath) + wcslen(scheduleName) + wcslen(backupName) + wcslen(vmName) +5];				
			wcscpy(backupFolder, repositoryPath);
			wcscat(backupFolder, L"\\");
			wcscat(backupFolder, scheduleName);
			wcscat(backupFolder, L"\\");
			wcscat(backupFolder, backupName);
			wcscat(backupFolder, L"\\");
			wcscat(backupFolder, vmName);
			wcscat(backupFolder, L"\\");
			wcscat(backupFolder, L"\0");
			logdrive->log(NORMAL, L"EncryptionDecryption ELSE case so BACKUP backupFolder: %ws\n", backupFolder);
		}

		try
		{
			logdrive->log(NORMAL, L"EncryptionDecryption Checking Prerequisites..!\n");
			String^ protectFolder = gcnew String(backupFolder, 0, wcslen(backupFolder));
			DirectoryInfo^ dir = gcnew DirectoryInfo(protectFolder);
			if (!dir->Exists)
			{
				logdrive->log(NORMAL, L"EncryptionDecryption protectFolder Directory not found..\n");
				throw gcnew DirectoryNotFoundException("EncryptionDecryption protectFolder Directory not found");
			}
			else
			{
				if (Directory::GetFiles(protectFolder)->Length == 0)
				{
					logdrive->log(NORMAL, L"EncryptionDecryption protectFolder Directory found but empty!..\n");
					throw gcnew DirectoryNotFoundException("EncryptionDecryption vmbackupPath Directory found but empty!");
				}
			}
			logdrive->log(NORMAL, L"EncryptionDecryption Going to perform operation -> %d\n",operation);
			array<String^> ^ vhdxFiles;
			if(operation==0)
			{
				logdrive->log(NORMAL, L"EncryptionDecryption Encryption VHD files..!\n");
				vhdxFiles = Directory::GetFiles(protectFolder, "*.vhd*");
			}
			else
			{
				logdrive->log(NORMAL, L"EncryptionDecryption Decrypting encrypted files..!\n");
				vhdxFiles = Directory::GetFiles(protectFolder, "*_secure*");
			} 
			for each(String^ existingVHD in vhdxFiles)
			{
				if(existingVHD->Contains("_secure"))//for decryption, need to remove this suffix
				{
					existingVHD = existingVHD->Substring(0, existingVHD->LastIndexOf("_secure"));
				}
				if(File::Exists(existingVHD) && operation==1)
				{
					//Some error in encryption. decrypted file already present. don't have to decrypt again
					logdrive->log(NORMAL, L"EncryptionDecryption Some error in encryption. decrypted file already present. don't have to decrypt again..\n");
					encryptResult = 1;
					continue;
				} 
				IntPtr ip = Marshal::StringToBSTR(existingVHD);  
				BSTR vhdPath = static_cast<BSTR>(ip.ToPointer());
				logdrive->log(NORMAL, L"EncryptionDecryption Calling encryptdecryptFile for file -> %ws\n", vhdPath);
				encryptTemp = encryptdecryptFile(pszPassword, operation, vhdPath);
				if(encryptTemp!=0)
				{
					logdrive->log(NORMAL, L"EncryptionDecryption encryptdecryptFile encryptTemp!=0 setting encryptResult as 1..\n");
					encryptResult = 1;
				}
				logdrive->log(NORMAL, L"EncryptionDecryption Done encryptdecryptFile for file -> %ws\n", vhdPath);
			}
			delete[] backupFolder;
			return encryptResult;
		}
		catch(Exception^ ex)
		{
			delete[] backupFolder;
			return 1;
		}
		//delete[] backupFolder;
		//return 0;
	}

	__declspec(dllexport) int connecttoRepository(LPWSTR repositoryDetailsJson, LPWSTR connectStatus)
	{
		HRESULT  result = CoInitialize(NULL);
		wstring logfileLoc = std::wstring(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\RepositoryConnectionLog.txt");
		LPWSTR logfileLocation = (LPWSTR)logfileLoc.c_str();
		logdrive = new Loggerclass(logfileLocation, (LPWSTR)level);
		InitializeGlobalvariables(logdrive);

		logdrive->log(NORMAL, L"hvbackup.cpp connecttoRepository started for location...\n");


            if(wcscmp(repositoryDetailsJson, L"-") != 0) {
                List<repoCredentials^>^ repoCredentialslist;
                try
                {				
                    String^ repositoryDetailsJsonString = gcnew String(repositoryDetailsJson, 0, wcslen(repositoryDetailsJson));
                    repositoryDetailsJsonString = repositoryDetailsJsonString->Replace("###", "\"");
                    logdrive->log(NORMAL, L"hvbackup.cpp connecttoRepository Going to parse JSON repository details string...\n");
                    repoCredentialslist = Newtonsoft::Json::JsonConvert::DeserializeObject<List<repoCredentials^>^>(repositoryDetailsJsonString);
                    logdrive->log(NORMAL, L"hvbackup.cpp connecttoRepository Done parsing JSON repository details string...\n");
                }
                catch (Exception^ ex)
                {	
                    String^ message = "HVBackup.cpp PerformHypervrestore Before connecttoRepositoriesforincrementalbackup Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace;
                    try
                    {
                        String^ path = "C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\WMIRepositoryConnectionLog.txt";
                        if (!File::Exists(path))
                        {
                            StreamWriter^ sw = File::CreateText(path);
                            sw->Close();
                        }
                        StreamWriter^ sw = File::AppendText(path);
                        try
                        {
                            sw->Write(DateTime::Now +" : " + message + Environment::NewLine);						
                        }
                        finally
                        {
                            sw->Flush();
                            sw->Close();
                        }				
                    }
                    catch (Exception^ e)
                    {
                        logdrive->log(NORMAL, L"hvbackup.cpp Exception occurred wihile writing exception to file..\n");
                    }
                    CoUninitialize();
                    return -1;
                }
    
                logdrive->log(NORMAL, L"hvbackup.cpp connecttoRepositories calling...\n");
                int incrStatus = connecttoRepositories(repoCredentialslist, connectStatus);
                logdrive->log(NORMAL, L"hvbackup.cpp connecttoRepositories ended...Return value -> %d\n", incrStatus);
                CoUninitialize();
                return incrStatus; 			
			}
		CoUninitialize();
		logdrive->log(NORMAL, L"hvbackup.cpp connecttoRepository ended...\n");		
		return 0;

	}

    __declspec(dllexport) int generateHash(LPWSTR repositoryPath, LPWSTR scheduleName, LPWSTR backupName, LPWSTR vmName, LPWSTR backupType, LPWSTR isEncrypted, LPWSTR encryptPassword)
	{
        try
		{
            HRESULT  result = CoInitialize(NULL);
            wstring logfileLoc = std::wstring(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\HealthCheckLog.txt");
            LPWSTR logfileLocation = (LPWSTR)logfileLoc.c_str();
            logdrive = new Loggerclass(logfileLocation, (LPWSTR)level);
            InitializeGlobalvariables(logdrive);

            logdrive->log(NORMAL, L"hvbackup.cpp construct backup files directory...\n");
            //constructing path variable
            wchar_t* backupFolder;
            backupFolder = new wchar_t[wcslen(repositoryPath) + wcslen(scheduleName) + wcslen(backupName) + wcslen(vmName) +4];
            wcscpy(backupFolder, repositoryPath);
            wcscat(backupFolder, L"\\");
            wcscat(backupFolder, scheduleName);
            wcscat(backupFolder, L"\\");
            wcscat(backupFolder, backupName);
            wcscat(backupFolder, L"\\");
            wcscat(backupFolder, vmName);
            wcscat(backupFolder, L"\0");
            int generateHashResult = generateHashforDirectory(backupFolder, backupType, backupName, isEncrypted, encryptPassword, L"backuphash");
            logdrive->log(NORMAL, L"hvbackup.cpp  generateHashforDirectory return value : %d\n",generateHashResult);

			CoUninitialize();
			return generateHashResult;
		}
		catch(Exception^ ex)
		{
		    logdrive->log(NORMAL, L"hvbackup.cpp generateHash Exception -> %ws\n", ex->Message);
			CoUninitialize();
			return 457;
		}
	}

	__declspec(dllexport) int copyVMfilesfromVSSSnapshot(wchar_t *hypervHostName, wchar_t *backupVM, wchar_t* backupType, wchar_t *repositoryPath, 
		wchar_t *backupName, wchar_t *scheduleName, wchar_t *vmId, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *))
	{
		HRESULT  result = CoInitialize(NULL);
		int returnValue = 0;
		wstring logfileLoc = std::wstring(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\FileCopyLogs\\");
		logfileLoc = logfileLoc + L"FileCopyLog_" + backupName + L"_" + backupVM + L".txt";
		wstring wmilogfileLoc = std::wstring(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\FileCopyLogs\\"); 
		wmilogfileLoc = wmilogfileLoc + L"WMIFileCopyLog_" + backupName + L"_" + backupVM + L".txt";

		LPWSTR logfileLocation = (LPWSTR)logfileLoc.c_str();
		Loggerclass *fileCopylogger;
		fileCopylogger = new Loggerclass(logfileLocation, (LPWSTR)level);
		//InitializeGlobalvariables(logdrive);

		int val = LoadVSSLibrary();
		if (val!=0)
		{
			fileCopylogger->log(NORMAL, L"HVBackup.cpp copyVMfilesfromVSSSnapshot LoadVSSLibrary failed");
			CoUninitialize();
			return 402;
		}

		LPWSTR wmilogfileLocation = (LPWSTR)wmilogfileLoc.c_str();
		bool WMIstatus = InitializeWMIGlobalvariables(hypervHostName, wmilogfileLocation);
		if(!WMIstatus)
		{
			fileCopylogger->log(NORMAL, L"copyVMfilesfromVSSSnapshot started...WMI Initialization failed...!\n");
			CoUninitialize();
			return 408;
		}

		fileCopylogger->log(NORMAL, L"HVBackup.cpp copyVMfilesfromVSSSnapshot ..Checking if VM Present\n");
		String^ vmNameString = gcnew String(backupVM, 0, wcslen(backupVM));
		bool isVMPresent = checkifVMPresent(vmNameString);
		if(!isVMPresent)
		{
			fileCopylogger->log(NORMAL, L"HVBackup.cpp copyVMfilesfromVSSSnapshot VM Not Found!\n");
			CoUninitialize();
			return 410;
		}

		CComBSTR bstrss;
		bstrss.Attach(SysAllocString(repositoryPath));
		BSTR temp = SysAllocString(L"\\");
		bstrss.AppendBSTR(temp);
		BSTR repositoryPathNew = bstrss.Detach();
		repositoryPathNew = SysAllocString(repositoryPathNew);

		/*returnValue = LoadsnapshotdetailsfiletoMap(backupName);
		if(returnValue!=0)
		{
			fileCopylogger->log(NORMAL, L"copyVMfilesfromVSSSnapshot LoadsnapshotdetailsfiletoMap Failed -> %d\n", returnValue);
			return 409;
		}*/
                fileCopylogger->log(NORMAL, L"hvbackup.cpp copyVMfilesfromVSSSnapshot backupType...%ws\n", backupType);
		if ((wcscmp(backupType, L"FullBackup") == 0) || (wcscmp(backupType, L"MigrBackup") == 0))//full backup
		{
			//std::list<BSTR> fullvmList;
			//fullvmList.push_back(backupVM);
			fileCopylogger->log(NORMAL, L"hvbackup.cpp copyVMfilesfromVSSSnapshot Calling copyfilesfromSnapshot - Full backup for VM...%ws\n", backupVM);
			returnValue = copyfilesfromSnapshot(repositoryPathNew, backupType, backupName, scheduleName, backupVM, vmId, fileCopylogger,callBackMethod);
		}
		else
		{
			//std::list<BSTR> incrementalvmList;
			//incrementalvmList.push_back(backupVM);
			fileCopylogger->log(NORMAL, L"hvbackup.cpp copyVMfilesfromVSSSnapshot Calling doIncrementalBackupforcomponents - Incremental backup for VM...%ws\n", backupVM);
			//iterate components. for each component(vm), get it's vhds, access that vhd's cbt file and backup the required bytes to the repository
			returnValue = doIncrementalBackupforcomponents(repositoryPathNew, backupName, scheduleName, backupVM, vmId, fileCopylogger, callBackMethod);
		}
		CloseVss();
		CoUninitialize();
		fileCopylogger->log(NORMAL, L"hvbackup.cpp copyVMfilesfromVSSSnapshot THE END Return value ..-> %d\n", returnValue);
		return returnValue;

	}

	__declspec(dllexport) int PerformHypervbackup(wchar_t *hypervHostName, wchar_t *fullbackupVMs, wchar_t* incrementalbackupVMs, wchar_t *repositoryPath, 
		wchar_t *backupName, wchar_t *scheduleName, wchar_t* isanyVHDchanged)
	{
		HRESULT  result = CoInitialize(NULL);

		wstring logfileLoc = std::wstring(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\BackupLogFile.txt");
		wstring wmilogfileLoc = std::wstring(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\WMILogFile.txt"); 

		LPWSTR logfileLocation = (LPWSTR)logfileLoc.c_str();
		logdrive = new Loggerclass(logfileLocation, (LPWSTR)level);
		InitializeGlobalvariables(logdrive);

		/*if(wcscmp(isanyVHDchanged, L"hello") == 0)
		{
			logdrive->log(NORMAL, L"hvbackup.cpp PerformHypervbackup Going to delete VSS Snapshot..\n");
			deleteVSSSnapshot(backupName);
			logdrive->log(NORMAL, L"hvbackup.cpp PerformHypervbackup Finished deleting VSS Snapshot..\n");
			return 0;
		}*/

		//Create Directory
		BSTR createdDirectory = SysAllocStringLen(L"", wcslen(repositoryPath) + wcslen(scheduleName) + wcslen(backupName) + 2);
		wcscpy(createdDirectory, repositoryPath);
		wcscat(createdDirectory, L"\\");
		wcscat(createdDirectory, scheduleName);
		
		logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervbackup Creating directory 1->%ws\n",createdDirectory);
		
		CreateDirectory(createdDirectory, NULL);
		DWORD error = GetLastError();
		if (error != ERROR_ALREADY_EXISTS) 
		{
           logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervbackup CreateDirectory1  failed with error %d\n", GetLastError());
       	}          

		wcscat(createdDirectory, L"\\");
		wcscat(createdDirectory, backupName);
		logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervbackup Creating directory 2->%ws\n",createdDirectory);
		CreateDirectory(createdDirectory, NULL);
		error = GetLastError();
		if (error != ERROR_ALREADY_EXISTS) 
		{
           logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervbackup CreateDirectory2  failed with error %d\n", GetLastError());
       	}
		SysFreeString(createdDirectory);
		
		Directory::CreateDirectory("C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\FileCopyLogs");

		int val = LoadVSSLibrary();
		if (val!=0)
		{
			logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervbackup LoadVSSLibrary failed");
			CoUninitialize();
			return 402;
		}
		LPWSTR wmilogfileLocation = (LPWSTR)wmilogfileLoc.c_str();
		bool WMIstatus = InitializeWMIGlobalvariables(hypervHostName, wmilogfileLocation);
		if(!WMIstatus)
		{
			logdrive->log(NORMAL, L"PerformHypervbackup started...WMI Initialization failed...!\n");
			CoUninitialize();
			return 408;
		}

		if(wcscmp(isanyVHDchanged, L"true") == 0)
		{
			logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervbackup VHDchanged is TRUE. Updating vhdtovm file...\n");
			writeVHDtoVMfile();
			logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervbackup. WRITTEN vhdtovm file...\n");
		}
		else
		{
			logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervbackup Calling checkifVHDtoVMfileexists...\n");
			checkifVHDtoVMfileexists();
			logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervbackup Completed checkifVHDtoVMfileexists...\n");
		}

		logdrive->log(NORMAL, L"PerformHypervbackup started...THE BEGINNING OF ALL BEGINNINGS!\n");
		int returnValue = -1;

		returnValue = PerformVSSSnapshot(fullbackupVMs, incrementalbackupVMs, repositoryPath, backupName, scheduleName);

		CoUninitialize();
		logdrive->log(NORMAL, L"hvbackup.cpp PerformHypervbackup THE END Return value ..-> %d\n", returnValue);
		return returnValue;
	}

	__declspec(dllexport) int PerformHypervrestore(wchar_t* hypervHostName, wchar_t* vmName, wchar_t* vmfullbackupPath, wchar_t* vmincrementalbackupPaths, wchar_t* ischangeVMName, 
		wchar_t* newVMName, wchar_t* VHDnewstorageLocation, wchar_t* isPowerOn, wchar_t* isEncrypted, wchar_t* isdecryptionSuccessful, wchar_t* vmId, wchar_t* restoreId, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *), wchar_t* paramsjson, wchar_t *restoreFormatString) //vmfullbackupPath -> repositoryopath+scheduleName+backupName(without end slash)
	{
		try
		{
			HRESULT  result = CoInitialize(NULL);

			String^ newhvVMid;
			String^ VHDnewstorageLocationString;
                        int restoreFormatInt = _wtoi(restoreFormatString);
			result = ModifyPrivilege(SE_RESTORE_NAME, TRUE);
			CheckHRESULT(result, L"ModifyPrivilege");
			

			wstring logfileLoc = std::wstring(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\BackupLogFile.txt");
			wstring wmilogfileLoc = std::wstring(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\WMILogFile.txt"); //todo


			LPWSTR logfileLocation = (LPWSTR)logfileLoc.c_str();
			logdrive = new Loggerclass(logfileLocation, (LPWSTR)level);
			logdrive->log(NORMAL, L"HVBackup.cpp  PerformHypervrestore started...THE BEGINNING OF ALL BEGINNINGS!!\n");
			InitializeGlobalvariables(logdrive);
                        logdrive->log(NORMAL, L"HVBackup.cpp  PerformHypervrestore restoreFormatInt -> %d\n",restoreFormatInt);

			int val = LoadVSSLibrary();
			if (val)
			{
				logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervrestore LoadVSSLibrary failed");
				CoUninitialize();
				return 802;
			}

			LPWSTR wmilogfileLocation = (LPWSTR)wmilogfileLoc.c_str();
			logdrive->log(NORMAL, L"HVBackup.cpp  PerformHypervrestore Initializing Global WMI variables...\n");
			bool WMIstatus = InitializeWMIGlobalvariables(hypervHostName, wmilogfileLocation);
			if(!WMIstatus)
			{
				logdrive->log(NORMAL, L"PerformHypervbackup started...WMI Initialization failed...!\n");
				CoUninitialize();
				return 808;
			}

            if(restoreFormatInt == 1 || restoreFormatInt == 2 || restoreFormatInt == 5 || restoreFormatInt == 6 || restoreFormatInt == 7)
            {
				if(wcscmp(VHDnewstorageLocation, L"-")==0)
				{
					//default location
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore VHDnewstorageLocationString default location\n");
					VHDnewstorageLocationString = getdefaultVHDLocation();
				}
				else
				{
					//user given location
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore VHDnewstorageLocationString user given location\n");
					VHDnewstorageLocationString = gcnew String(VHDnewstorageLocation, 0, wcslen(VHDnewstorageLocation));
					VHDnewstorageLocationString = VHDnewstorageLocationString->Replace("\\\'", "\'");
					VHDnewstorageLocationString = VHDnewstorageLocationString->Replace("\\\\", "\\");
                    if(!Directory::Exists( VHDnewstorageLocationString ))
                    {
                        Directory::CreateDirectory(VHDnewstorageLocationString);
                    }
				}
                if(wcscmp(paramsjson, L"{}")!=0)
                {
                    additionalParameters^ paramsList;
                    try
                    {
                        String^ paramsjsonString = gcnew String(paramsjson, 0, wcslen(paramsjson));
                        paramsjsonString = paramsjsonString->Replace("###", "\"");
                        paramsList = Newtonsoft::Json::JsonConvert::DeserializeObject <additionalParameters^> (paramsjsonString);
                    }
                    catch (Exception^ ex)
                    {
                        String^ message = "HVBackup.cpp PerformHypervrestore json parsing Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace;
                        try
                        {
                            String^ path = "C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\BackupLogFile.txt";
                            if (!File::Exists(path))
                            {
                                StreamWriter^ sw = File::CreateText(path);
                                sw->Close();
                            }
                            StreamWriter^ sw = File::AppendText(path);
                            try
                            {
                                sw->Write(DateTime::Now +" : " + message + Environment::NewLine);
                            }
                            finally
                            {
                                sw->Flush();
                                sw->Close();
                            }
                        }
                        catch (Exception^ e)
                        {
                            logdrive->log(NORMAL, L"hvbackup.cpp Exception occurred wihile writing exception to file..\n");
                        }
                        CoUninitialize();
                        return -1;
                    }
                    String^ size = paramsList->vmDisksSize;
                    std::string sizestring = msclr::interop::marshal_as<std::string>(size);
                    long long vmDisksSize = strtoll(sizestring.c_str(), NULL, 0);
                    __int64 lpFreeBytesAvailable, lpTotalNumberOfBytes, lpTotalNumberOfFreeBytes;
                    BOOL test;
                    std::wstring VHDLocationwstring = msclr::interop::marshal_as<std::wstring>(VHDnewstorageLocationString);
                    LPWSTR VHDLocation = (LPWSTR)VHDLocationwstring.c_str();
                    logdrive->log(NORMAL, L"hvbackup.cpp HVRestore VHDnewstorageLocationString -%ls-\n",VHDLocationwstring.c_str());
                    test = GetDiskFreeSpaceEx(VHDLocation,
                            (PULARGE_INTEGER)&lpFreeBytesAvailable,
                            (PULARGE_INTEGER)&lpTotalNumberOfBytes,
                            (PULARGE_INTEGER)&lpTotalNumberOfFreeBytes
                            );
                    long long freeSpaceAvailable = lpFreeBytesAvailable;
                    logdrive->log(NORMAL, L"hvbackup.cpp vmDiskssize:%lld, available Space:%lld\n",vmDisksSize,freeSpaceAvailable);
                    if(vmDisksSize > freeSpaceAvailable){
                        logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervrestore Not enough space to restore the vm!\n");
                        CoUninitialize();
                        return 827;
                    }
                }
			}
			
			int returnValue = -1;

			/*bool testvss = VssSupport(location);
			if (!testvss)
			{
			return 1;
			}*/	

			String^ vmNameString = gcnew String(vmName, 0, wcslen(vmName));
			
			if((restoreFormatInt == 3 || restoreFormatInt == 4))
			{
				logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervrestore Disk Restore..Checking if VM Present\n");
				bool isVMPresent = checkifVMPresent(vmNameString);
				if(!isVMPresent)
				{
					//Disk restore. VM not found. Returning error
					logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervrestore Disk Restore VM Not Found!\n");
					CoUninitialize();
					return 811;
				}
			}	
			
			//splitting incremental backup paths and connecting to repositories
			wchar_t *vmincrementalbackupPathswstring = new wchar_t[wcslen(vmincrementalbackupPaths) + 1];
			wcscpy(vmincrementalbackupPathswstring, vmincrementalbackupPaths);

			std::list<BSTR> incrementalPathlist;
			if(wcscmp(vmincrementalbackupPathswstring, L"-")!=0)
			{
				wchar_t *incrPath = NULL;
				wchar_t *nextincrPath = NULL;
				incrPath = wcstok_s(vmincrementalbackupPathswstring, L";", &nextincrPath);
				while (incrPath != NULL)
				{
					logdrive->log(NORMAL, L"Incremental backup path ->  %ws\n", incrPath);
					incrementalPathlist.push_back(incrPath);
					incrPath = wcstok_s(NULL, L";", &nextincrPath);
				}				
			}
			logdrive->log(NORMAL, L"HVBackup.cpp  PerformHypervrestore started...vmfullbackupPath -> %ws, vmincrementalbackupPaths-> %ws\n",vmfullbackupPath,vmincrementalbackupPaths);

			//Check if repository files present for restore
			String^ fullbackupvmPathString = gcnew String(vmfullbackupPath, 0, wcslen(vmfullbackupPath));
			int isBackupFilespresent = checkifBackupFilesPresent(fullbackupvmPathString, vmNameString);
			if(isBackupFilespresent!=0)
			{
				logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervrestore Backup Files missing..! Return code -> %d\n", isBackupFilespresent);
				CoUninitialize();
				return isBackupFilespresent;
			}


			if (restoreFormatInt == 1 || restoreFormatInt == 2 || restoreFormatInt == 3 || restoreFormatInt == 4)//don't have to shutdown vm when creating new vm
			{				
				logdrive->log(NORMAL, L"HVBackup.cpp  PerformHypervrestore Going to shutdown VM -> %ws\n",vmName);
				//bool isVMshutDown = shutdownVM(vmNameString);
				bool isVMshutDown = RequestStateChange(vmNameString, Convert::ToUInt16(3));//turnoff vm to delete saved state before incremental restore
				if(!isVMshutDown)
				{
					logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervrestore Shutdown failed\n");
					CoUninitialize();
					return 803;
				}
			}
			else
			{
				logdrive->log(NORMAL, L"HVBackup.cpp  PerformHypervrestore Not necessary to shutdown VM\n");
			}

			//LoadBackupCompandWriterMetadatadocs
			logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervrestore LoadBackupCompandWriterMetadatadocs calling\n");
			val = LoadBackupCompandWriterMetadatadocs(vmfullbackupPath, vmName, logdrive); //vmbackepuppath is sent to find writer metadata sn backup components doc
			if (val)
			{
				logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervrestore LoadBackupCompandWriterMetadatadocs failed\n");
				CoUninitialize();
				return 804;
			}

			//GetComponentsToRestore
			logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervrestore GetComponentsToRestore calling\n");
			bool isoldVMdeletebool = false;
			if(restoreFormatInt == 1 || restoreFormatInt == 2)
			{
				isoldVMdeletebool=true;
			}
			else
			{
				isoldVMdeletebool=false;
			}
			
			std::list<IVssWMComponent*> componentListtoRestore = GetComponentsToRestore(vmName, isoldVMdeletebool);
			if (componentListtoRestore.empty())
			{
				logdrive->log(NORMAL, L"HVBackup.cpp PerformHypervrestore GetComponentsToRestore failed\n");
				CoUninitialize();
				return 805;
			}

			int restore;

			/* available restores:
			full restore
				full restore all files restore overwrite
				full restore disk restore overwrite
				full restore different host
			incremental restore
				incremental restore all files restore overwrite
				incremental restore disk restore overwrite
				incremental restore different host
			*/
                        bool isrestoreVMPresent = false, isVMshutDown = false ,startVM = false;
			BSTR incrementalbackupPath,temp,temp1,configurationXMLfileName,VHDnewstorageLocationwstring;
			CComBSTR bstrss;
			IntPtr ip;
			String^ configurationXMLfileNameString;
			String^ fullbackupvmPathStringwithvmName;
			String^ newVMNameString;
			String^ ischangeVMNameString;
                        int count = 0;
                        logdrive->log(NORMAL, L"HVBackup.cpp performHypervrestore going for switch case!\n");
                         /*
                        1 -> Full restore from full backup
                        2 -> Full restore from incr backup
                        3 -> Disk restore from full backup
                        4 -> Disk restore from incr backup
                        5 -> New VM restore from full backup
                        6 -> New VM restore from incr backup
                        7 -> Live VM Migration
                        */
			
			//Restore modules
			switch(restoreFormatInt)
			{
                            case 1:
				//full restore all files restore overwrite
				//todo -> if files not present -> create from scratch
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Restore module -> full restore overwrite. VM Name : %ws \n", vmName);
				restore = restorefilesfromFullBackup(componentListtoRestore, vmfullbackupPath, vmName, false, isoldVMdeletebool, vmId, restoreId, callBackMethod); 
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore restorefilesfromFullBackup ends with return value -> %d\n",restore);
				if(!restore)
				{	
					logdrive->log(NORMAL, L"HVBackup.cpp HVRestore ..Checking if VM Present after full restore overwrite\n");
					isrestoreVMPresent = checkifVMPresent(vmNameString);
					if(!isrestoreVMPresent)
					{
						logdrive->log(NORMAL, L"HVBackup.cpp HVRestore VM Not Found after full restore overwrite!\n");
						restore = 816;
					}
					else
					{
						logdrive->log(NORMAL, L"HVBackup.cpp HVRestore VM SUCCESSFULLY Found after full restore overwrite!\n");
						logdrive->log(NORMAL, L"HVBackup.cpp HVRestore Full restore successful. Deleting saved state if any..!\n");
						isVMshutDown = RequestStateChange(vmNameString, Convert::ToUInt16(3));//turnoff vm to delete saved state before incremental restore
					}
				}
                                break;
                            case 2:
				//incremental restore all files restore overwrite
				//todo -> if files not present -> create from scratch
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Restore module -> incremental full restore overwrite. VM Name : %ws \n", vmName);
				restore = restorefilesfromFullBackup(componentListtoRestore, vmfullbackupPath, vmName, false, isoldVMdeletebool, vmId, restoreId, callBackMethod); 
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore restorefilesfromFullBackup in INCREMENTAL RESTORE ends with return value -> %d\n",restore);
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Going to start and shutdown VM after full restore...\n");	
				startVM = RequestStateChange(vmNameString, Convert::ToUInt16(2));//start vm after full restore so that any pending merges will be completed
				logdrive->log(NORMAL, L"hvbackup.cpp turnig off VM after full restore..!\n");
				isVMshutDown = RequestStateChange(vmNameString, Convert::ToUInt16(3));//turnoff vm to delete saved state before incremental restore
				if(!restore && !incrementalPathlist.empty())
				{
					for (auto incritr = incrementalPathlist.begin(); incritr != incrementalPathlist.end(); ++incritr)
					{
						incrementalbackupPath = *incritr;
						logdrive->log(NORMAL, L"hvbackup.cpp HVRestore restorefilesfromIncrementalBackup. Calling restorefilesfromIncrementalBackup VM incr backup path : %ws. \n", incrementalbackupPath);
						restore = restorefilesfromIncrementalBackup(componentListtoRestore, incrementalbackupPath, vmName, true, L"-", vmId, restoreId, callBackMethod); 
						logdrive->log(NORMAL, L"hvbackup.cpp HVRestore restorefilesfromIncrementalBackup in INCREMENTAL RESTORE ends with return value -> %d\n",restore);	
					}
				}
				if(!restore)
				{
					logdrive->log(NORMAL, L"HVBackup.cpp HVRestore ..Checking if VM Present after incremental restore overwrite\n");
					isrestoreVMPresent = checkifVMPresent(vmNameString);
					if(!isrestoreVMPresent)
					{
						logdrive->log(NORMAL, L"HVBackup.cpp HVRestore VM Not Found after incremental restore overwrite!\n");
						restore = 816;
					}
					else
					{
						logdrive->log(NORMAL, L"HVBackup.cpp HVRestore VM SUCCESSFULLY Found after incremental restore overwrite!\n");
					}
				}
                                break;
                            case 3:
				//full restore disk restore overwrite
				//todo -> if files not present -> show error
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Restore module -> full restore disk restore overwrite. VM Name : %ws \n", vmName);
				restore = restorefilesfromFullBackup(componentListtoRestore, vmfullbackupPath, vmName, true, isoldVMdeletebool, vmId, restoreId, callBackMethod); 
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore restorefilesfromFullBackup ends with return value -> %d\n",restore);	
                                break;
                            case 4:
				//incremental restore disk restore overwrite
				//todo -> if files not present -> show error
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Restore module -> incremental restore disk restore overwrite. VM Name : %ws \n", vmName);
				restore = restorefilesfromFullBackup(componentListtoRestore, vmfullbackupPath, vmName, true, isoldVMdeletebool, vmId, restoreId, callBackMethod); 
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore restorefilesfromFullBackup in INCREMENTAL RESTORE ends with return value -> %d\n",restore);	
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Going to start and shutdown VM after full restore...\n");	
				startVM = RequestStateChange(vmNameString, Convert::ToUInt16(2));//start vm after full restore so that any pending merges will be completed
				logdrive->log(NORMAL, L"hvbackup.cpp turnig off VM after full restore..!\n");
				isVMshutDown = RequestStateChange(vmNameString, Convert::ToUInt16(3));//turnoff vm to delete saved state before incremental restore
				if(!restore && !incrementalPathlist.empty())
				{
					for (auto incritr = incrementalPathlist.begin(); incritr != incrementalPathlist.end(); ++incritr)
					{
						incrementalbackupPath = *incritr;
						logdrive->log(NORMAL, L"hvbackup.cpp HVRestore restorefilesfromIncrementalBackup. VM incr backup path : %ws. Calling restorefilesfromIncrementalBackup\n", incrementalbackupPath);
						restore = restorefilesfromIncrementalBackup(componentListtoRestore, incrementalbackupPath, vmName, true, L"-", vmId, restoreId, callBackMethod); 
						logdrive->log(NORMAL, L"hvbackup.cpp HVRestore restorefilesfromIncrementalBackup in INCREMENTAL RESTORE ends with return value -> %d\n",restore);	
					}

				}
                                break;
                            case 5:
				//full restore different host - create from scratch
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Restore module -> full restore different host - create from scratch. VM Name : %ws \n", vmName);

				//Full restore first
				//String^ fullbackupvmPathString = gcnew String(vmfullbackupPath, 0, wcslen(vmfullbackupPath));
				// String^ VHDnewstorageLocationString;
				// if(wcscmp(VHDnewstorageLocation, L"-")==0)
				// {
				// 	//default location
				//	logdrive->log(NORMAL, L"hvbackup.cpp HVRestore VHDnewstorageLocationString default location\n");
				//	VHDnewstorageLocationString = getdefaultVHDLocation();
				// }
				// else
				// {
				//	//user given location
				//	logdrive->log(NORMAL, L"hvbackup.cpp HVRestore VHDnewstorageLocationString user given location\n");
				//	VHDnewstorageLocationString = gcnew String(VHDnewstorageLocation, 0, wcslen(VHDnewstorageLocation)); 
				//	VHDnewstorageLocationString = VHDnewstorageLocationString->Replace("\\\'", "\'");
				//	VHDnewstorageLocationString = VHDnewstorageLocationString->Replace("\\\\", "\\");
				// }

				bstrss.Attach(SysAllocString(vmfullbackupPath));		
				temp = SysAllocString(L"\\");
				temp1 = SysAllocString(L".xml");
				bstrss.AppendBSTR(temp);
				bstrss.AppendBSTR(SysAllocString(vmName));
				bstrss.AppendBSTR(SysAllocString(L"\\"));
				bstrss.AppendBSTR(SysAllocString(vmName));
				bstrss.AppendBSTR(temp1);
				configurationXMLfileName = bstrss.Detach();	
				configurationXMLfileNameString = gcnew String(configurationXMLfileName, 0, wcslen(configurationXMLfileName));	
				if(WMIconnectiondetails::is2008Server)
				{
					newhvVMid = Definenew2008VirtualSystem(configurationXMLfileNameString);
				}
				else
				{
					newhvVMid = DefinenewVirtualSystem(configurationXMLfileNameString);
				}
                                if(String::IsNullOrEmpty(newhvVMid)){
                                        CoUninitialize();
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore DefinenewVirtualSystem Failed...\n");
					return 817;
				}
				if(!(VHDnewstorageLocationString->Trim()->EndsWith("\\"))){
					VHDnewstorageLocationString = VHDnewstorageLocationString + "\\";
				}
				VHDnewstorageLocationString = VHDnewstorageLocationString + newhvVMid;               //+ "\\" + newhvVMid;
				Directory::CreateDirectory(VHDnewstorageLocationString);

				fullbackupvmPathStringwithvmName = fullbackupvmPathString + "\\" + vmNameString;

				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling CopyVHDfilestotargetDirectory  fullbackupPathString -> %ws VHDnewstorageLocationString-> %ws \n", vmfullbackupPath, VHDnewstorageLocation);
				CopyVHDfilestotargetDirectory(fullbackupvmPathStringwithvmName, VHDnewstorageLocationString, restoreId, vmId, callBackMethod); 

				//call createnewVirtualMachinefromXMLfile
				newVMNameString = gcnew String(newVMName, 0, wcslen(newVMName));	
				ischangeVMNameString = gcnew String(ischangeVMName, 0, wcslen(ischangeVMName));					

				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile configurationXMLfileNameString -> %ws newVMNameString-> %ws \n", configurationXMLfileName, newVMName);
				if(WMIconnectiondetails::is2008Server)
				{
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile2008...\n");
					restore = createnewVirtualMachinefromXMLfile2008(configurationXMLfileNameString, ischangeVMNameString, newVMNameString, VHDnewstorageLocationString, newhvVMid);
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile2008 ENDED...\n");					
				}
				else
				{
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile...\n");
					restore = createnewVirtualMachinefromXMLfile(configurationXMLfileNameString, ischangeVMNameString, newVMNameString, VHDnewstorageLocationString, newhvVMid);
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile ENDED...\n");					
				}
				if(restore){
                                        CoUninitialize();
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore createnewVirtualMachinefromXMLfile failed...\n");	
					return restore;
				}
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore createnewVirtualMachinefromXMLfile ENDED...\n");
                                
                                break;
                            case 6:
				//incremental restore different host - create from scratch
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Restore module -> incremental restore different host - create from scratch. VM Name : %ws \n", vmName);
				
				//full restore first
				//String^ fullbackupvmPathString = gcnew String(vmfullbackupPath, 0, wcslen(vmfullbackupPath));
				// String^ VHDnewstorageLocationString;
				// if(wcscmp(VHDnewstorageLocation, L"-")==0)
				// {
				// 	//default location
				// 	logdrive->log(NORMAL, L"hvbackup.cpp HVRestore VHDnewstorageLocationString default location\n");
				// 	VHDnewstorageLocationString = getdefaultVHDLocation();
				// }
				// else
				// {
				// 	//user given location
				// 	logdrive->log(NORMAL, L"hvbackup.cpp HVRestore VHDnewstorageLocationString user given location\n");
				// 	VHDnewstorageLocationString = gcnew String(VHDnewstorageLocation, 0, wcslen(VHDnewstorageLocation)); 
				// 	VHDnewstorageLocationString = VHDnewstorageLocationString->Replace("\\\'", "\'");
				// 	VHDnewstorageLocationString = VHDnewstorageLocationString->Replace("\\\\", "\\");
				// }

				
				bstrss.Attach(SysAllocString(vmfullbackupPath));	
				temp = SysAllocString(L"\\");
				temp1 = SysAllocString(L".xml");
				bstrss.AppendBSTR(temp);
				bstrss.AppendBSTR(SysAllocString(vmName));
				bstrss.AppendBSTR(SysAllocString(L"\\"));
				bstrss.AppendBSTR(SysAllocString(vmName));
				bstrss.AppendBSTR(temp1);
				configurationXMLfileName = bstrss.Detach();
				configurationXMLfileNameString = gcnew String(configurationXMLfileName, 0, wcslen(configurationXMLfileName));

				if(WMIconnectiondetails::is2008Server)
				{
					newhvVMid = Definenew2008VirtualSystem(configurationXMLfileNameString);
				}
				else
				{
					newhvVMid = DefinenewVirtualSystem(configurationXMLfileNameString);
				}
                                if(String::IsNullOrEmpty(newhvVMid)){
                                        CoUninitialize();
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore DefinenewVirtualSystem Failed...\n");
					return 817;
				}
				if(!(VHDnewstorageLocationString->Trim()->EndsWith("\\"))){
					VHDnewstorageLocationString = VHDnewstorageLocationString + "\\";
				}
				VHDnewstorageLocationString = VHDnewstorageLocationString + newhvVMid;              // "\\" + newhvVMid;
				Directory::CreateDirectory(VHDnewstorageLocationString);

				fullbackupvmPathStringwithvmName = fullbackupvmPathString + "\\" + vmNameString;

				ip = Marshal::StringToBSTR(VHDnewstorageLocationString);  
				VHDnewstorageLocationwstring = static_cast<BSTR>(ip.ToPointer());  

				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling CopyVHDfilestotargetDirectory  fullbackupPathString -> %ws VHDnewstorageLocationString-> %ws \n", vmfullbackupPath, VHDnewstorageLocationwstring);
				CopyVHDfilestotargetDirectory(fullbackupvmPathStringwithvmName, VHDnewstorageLocationString, restoreId, vmId, callBackMethod);
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore	CopyVHDfilestotargetDirectory over. calling createnewxml. then starting and stopping..\n");

				//next subsequent incremental restores
				if(!incrementalPathlist.empty())
				{
					logdrive->log(NORMAL, L"hvbackup.cpp incrementalPathlist Not empty!Going to start and turn OFF VM\n");
					startVM = RequestStateChange(newhvVMid, Convert::ToUInt16(2));//start vm after full restore so that any pending merges will be completed
					logdrive->log(NORMAL, L"hvbackup.cpp turnig off Vm after full restore..!\n");
					isVMshutDown = RequestStateChange(newhvVMid, Convert::ToUInt16(3));//turnoff vm to delete saved state before incremental restore
					for (auto incritr = incrementalPathlist.begin(); incritr != incrementalPathlist.end(); ++incritr)
					{
						incrementalbackupPath = *incritr;
						logdrive->log(NORMAL, L"hvbackup.cpp HVRestore restorefilesfromIncrementalBackup. VM incr backup path : %ws. Calling restorefilesfromIncrementalBackup\n", incrementalbackupPath);
						restore = restorefilesfromIncrementalBackup(componentListtoRestore, incrementalbackupPath, vmName, false, VHDnewstorageLocationwstring, vmId, restoreId, callBackMethod);
						logdrive->log(NORMAL, L"hvbackup.cpp HVRestore restorefilesfromIncrementalBackup in INCREMENTAL RESTORE ends with return value -> %d\n",restore);	
					}
					if(restore){
                                                CoUninitialize();
						logdrive->log(NORMAL, L"hvbackup.cpp Incremental restore failure!\n");	
						return restore;
					}                                        
				}
				//call createnewVirtualMachinefromXMLfile
				newVMNameString = gcnew String(newVMName, 0, wcslen(newVMName));
				ischangeVMNameString = gcnew String(ischangeVMName, 0, wcslen(ischangeVMName));
				logdrive->log(NORMAL, L"hvbackup.cpp Restoring Incremental files done!\n");

				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile configurationXMLfileNameString -> %ws newVMNameString-> %ws \n", configurationXMLfileName, newVMName);
				if(WMIconnectiondetails::is2008Server)
				{
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile2008...\n");
					restore = createnewVirtualMachinefromXMLfile2008(configurationXMLfileNameString, ischangeVMNameString, newVMNameString, VHDnewstorageLocationString, newhvVMid);
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile2008 ENDED...\n");
				}
				else
				{
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile...\n");
					restore = createnewVirtualMachinefromXMLfile(configurationXMLfileNameString, ischangeVMNameString, newVMNameString, VHDnewstorageLocationString, newhvVMid);
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile ENDED...\n");
				}
				if(restore){
                                        CoUninitialize();
					logdrive->log(NORMAL, L"hvbackup.cpp HVRestore createnewVirtualMachinefromXMLfile failed...\n");
					return restore;
				}
				logdrive->log(NORMAL, L"hvbackup.cpp HVRestore createnewVirtualMachinefromXMLfile ENDED...\n");
				logdrive->log(NORMAL, L"hvbackup.cpp Full and Incremental restore done!\n");
                                break;
                            case 7:
                                //live migration different host - create from scratch
                                logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Restore module -> live migration different host - create from scratch. VM Name : %ws \n", vmName);

                                bstrss.Attach(SysAllocString(vmfullbackupPath));		
                                temp = SysAllocString(L"\\");
                                temp1 = SysAllocString(L".xml");
                                bstrss.AppendBSTR(temp);
                                bstrss.AppendBSTR(SysAllocString(vmName));
                                bstrss.AppendBSTR(SysAllocString(L"\\"));
                                bstrss.AppendBSTR(SysAllocString(vmName));
                                bstrss.AppendBSTR(temp1);
                                configurationXMLfileName = bstrss.Detach();	
                                configurationXMLfileNameString = gcnew String(configurationXMLfileName, 0, wcslen(configurationXMLfileName));					
                                if(WMIconnectiondetails::is2008Server)
                                {
                                        newhvVMid = Definenew2008VirtualSystem(configurationXMLfileNameString);
                                }
                                else
                                {
                                        newhvVMid = DefinenewVirtualSystem(configurationXMLfileNameString);
                                }
                                if(String::IsNullOrEmpty(newhvVMid))
                                {
                                        CoUninitialize();
                                        logdrive->log(NORMAL, L"hvbackup.cpp HVRestore DefinenewVirtualSystem Failed...\n");
                                        return 817;
                                }
                                if(!(VHDnewstorageLocationString->Trim()->EndsWith("\\"))){
                                        VHDnewstorageLocationString = VHDnewstorageLocationString + "\\";
                                }

//					fullbackupvmPathStringwithvmName = fullbackupvmPathString + "\\" + vmNameString;
//                                      logdrive->log(NORMAL, L"hvbackup.cpp fullbackupvmPathStringwithvmName-> %s \n", fullbackupvmPathStringwithvmName);
                                VHDnewstorageLocationString = VHDnewstorageLocationString  + vmNameString;
                                logdrive->log(NORMAL, L"hvbackup.cpp VHDnewstorageLocationString-> %s \n", VHDnewstorageLocationString);

                                std::wstring VHDnewstorageLocationStringNamenew = msclr::interop::marshal_as<std::wstring>(VHDnewstorageLocationString);
                                LPWSTR VHDnewstorageLocationStringNamenewn = (LPWSTR)VHDnewstorageLocationStringNamenew.c_str();
                                logdrive->log(NORMAL, L"hvbackup.cpp VHDnewstorageLocationStringNamenewn -%ls-\n",VHDnewstorageLocationStringNamenewn);


                                newVMNameString = gcnew String(newVMName, 0, wcslen(newVMName));	
                                ischangeVMNameString = gcnew String(ischangeVMName, 0, wcslen(ischangeVMName));					

                                logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile configurationXMLfileNameString -> %ws newVMNameString-> %ws \n", configurationXMLfileName, newVMName);
                                if(WMIconnectiondetails::is2008Server)
                                {
                                        logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile2008...\n");
                                        restore = createnewVirtualMachinefromXMLfile2008(configurationXMLfileNameString, ischangeVMNameString, newVMNameString, VHDnewstorageLocationString, newhvVMid);
                                        logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile2008 ENDED...\n");					
                                }
                                else
                                {
                                        logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile...\n");
                                        restore = createnewVirtualMachinefromXMLfile(configurationXMLfileNameString, ischangeVMNameString, newVMNameString, VHDnewstorageLocationString, newhvVMid);
                                        logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Calling createnewVirtualMachinefromXMLfile ENDED...\n");					
                                }
                                if(restore){
                                                                                CoUninitialize();
                                        logdrive->log(NORMAL, L"hvbackup.cpp HVRestore createnewVirtualMachinefromXMLfile failed...\n");	
                                        return restore;
                                }
                                logdrive->log(NORMAL, L"hvbackup.cpp HVRestore createnewVirtualMachinefromXMLfile ENDED...\n");
                                break;
				
			}

			logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Closing VSS...\n");
			CloseVss();

			logdrive->log(NORMAL, L"hvbackup.cpp HVRestore over..\n");

			//Delete decrypted files if any
			if(wcscmp(isEncrypted,L"true")==0 && wcscmp(isdecryptionSuccessful, L"true")==0)
			{
				logdrive->log(NORMAL, L"hvbackup.cpp Going to delete decrypted files..\n");
				DeletedecryptedFiles(fullbackupvmPathString, vmNameString);
				logdrive->log(NORMAL, L"hvbackup.cpp DeletedecryptedFiles completed..\n");
			}
			else
			{
				logdrive->log(NORMAL, L"hvbackup.cpp No decryption done OR decryption FAILURE..!\n");
			}

			if(wcscmp(isPowerOn,L"true")==0)
			{
				logdrive->log(NORMAL, L"hvbackup.cpp GOING TO TURN ON VM...\n");
				//Power on restored machine
                                bool isVMturnOn;
				if (restoreFormatInt == 5 || restoreFormatInt == 6 || restoreFormatInt == 7) //new vm created
				{
					isVMturnOn = RequestStateChange(newhvVMid, Convert::ToUInt16(2));
				}
				else//overwrite
				{
					isVMturnOn = RequestStateChange(vmNameString, Convert::ToUInt16(2));
				}
                                if(isVMturnOn == false && restore == 0)
				{
					logdrive->log(NORMAL, L"returning 828 because VM failed to turn on...\n");
					restore = 828;
				}

			}
			CoUninitialize();
			logdrive->log(NORMAL, L"hvbackup.cpp HVRestore THE END! Return value -> %d\n", restore);
			return restore;

		}
		catch (exception& ex)
		{
			logdrive->log(NORMAL, L"hvbackup.cpp HVRestore Exception message: %ws\n", ex.what());
			return 800;
		}
	}

    __declspec(dllexport) int PerformHyperVHealthCheck(wchar_t* hypervHostName, wchar_t* healthCheckParametersJson, wchar_t *vmBackupDetailsJson, wchar_t*(*commonCallBackMethod)(wchar_t*, wchar_t*))
	{
		try
		{
			HRESULT  result = CoInitialize(NULL);
            wstring logfileLoc = std::wstring(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\HealthCheckLog.txt");
			LPWSTR logfileLocation = (LPWSTR)logfileLoc.c_str();
			logdrive = new Loggerclass(logfileLocation, (LPWSTR)level);
			InitializeGlobalvariables(logdrive);
			logdrive->log(NORMAL, L"hvbackup.cpp  PerformHyperVHealthCheck started...THE BEGINNING OF ALL BEGINNINGS!!\n");

            healthCheckParameters^ parameters;
            try {
                String^ healthCheckParametersString = gcnew String(healthCheckParametersJson, 0, wcslen(healthCheckParametersJson));
                healthCheckParametersString = healthCheckParametersString->Replace("###", "\"");
                logdrive->log(NORMAL, L"hvbackup.cpp PerformHyperVHealthCheck Going to parse healthCheckParameters JSON string...\n");
                parameters = Newtonsoft::Json::JsonConvert::DeserializeObject <healthCheckParameters^> (healthCheckParametersString);
                logdrive->log(NORMAL, L"hvbackup.cpp PerformHyperVHealthCheck Done parsing healthCheckParameters JSON string...\n");
            }catch (Exception ^ ex) {
                logdrive->log(NORMAL, L"exception caught while parsing healthCheckParameters.\n");
                std::string exceptionString = msclr::interop::marshal_as<std::string>(ex->Message);
                logdrive->log(NORMAL, (LPWSTR)exceptionString.c_str());
            }
            String^ hypervVMIDString = parameters->hypervVMID;
            std::wstring hypervVMIDWstring = msclr::interop::marshal_as<std::wstring>(hypervVMIDString);
            wchar_t *hypervVMID = new wchar_t[hypervVMIDWstring.length() + 1];
            wcscpy(hypervVMID, hypervVMIDWstring.c_str());
            wcscat(hypervVMID, L"\0");

            String^ backupIdString = parameters->backupId;
            std::wstring backupIdWstring = msclr::interop::marshal_as<std::wstring>(backupIdString);
            wchar_t *backupId = new wchar_t[backupIdWstring.length() + 1];
            wcscpy(backupId, backupIdWstring.c_str());
            wcscat(backupId, L"\0");

            String^ vmIdString = parameters->vmId;
            std::wstring vmIdWstring = msclr::interop::marshal_as<std::wstring>(vmIdString);
            wchar_t *vmId = new wchar_t[vmIdWstring.length() + 1];
            wcscpy(vmId, vmIdWstring.c_str());
            wcscat(vmId, L"\0");

            String^ isEncryptedString = parameters->isEncrypted;
            std::wstring isEncryptedWstring = msclr::interop::marshal_as<std::wstring>(isEncryptedString);
            wchar_t *isEncrypted = new wchar_t[isEncryptedWstring.length() + 1];
            wcscpy(isEncrypted, isEncryptedWstring.c_str());
            wcscat(isEncrypted, L"\0");

            String^ encryptPasswordString= parameters->encryptPassword;
            std::wstring encryptPasswordWstring = msclr::interop::marshal_as<std::wstring>(encryptPasswordString);
            wchar_t *encryptPassword = new wchar_t[encryptPasswordWstring.length() + 1];
            wcscpy(encryptPassword, encryptPasswordWstring.c_str());
            wcscat(encryptPassword, L"\0");

            List<backupDetails^>^ backupDetailsList;
            try {
                String^ backupDetailsString = gcnew String(vmBackupDetailsJson, 0, wcslen(vmBackupDetailsJson));
				backupDetailsString = backupDetailsString->Replace("###", "\"");
				logdrive->log(NORMAL, L"hvbackup.cpp PerformHyperVHealthCheck Going to parse backupDetails JSON string...\n");
				backupDetailsList = Newtonsoft::Json::JsonConvert::DeserializeObject<List<backupDetails^>^>(backupDetailsString);
				logdrive->log(NORMAL, L"hvbackup.cpp PerformHyperVHealthCheck Done parsing backupDetails JSON string...\n");
            }catch (Exception ^ ex) {
                logdrive->log(NORMAL, L"exception caught while parsing backupDetails.\n");
                std::string exceptionString = msclr::interop::marshal_as<std::string>(ex->Message);
                logdrive->log(NORMAL, (LPWSTR)exceptionString.c_str());
            }
            int returnVal = performHealthCheck(backupDetailsList, hypervVMID, backupId, vmId, isEncrypted, encryptPassword, commonCallBackMethod);

            CoUninitialize();
            return returnVal;

        }
        catch (exception& ex)
		{
			logdrive->log(NORMAL, L"hvbackup.cpp PerformHyperVHealthCheck Exception message: %ws\n", ex.what());
			CoUninitialize();
			return 460;
		}
	}

}
