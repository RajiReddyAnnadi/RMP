#include "hvWMI.h"

void WMILog(String^ message)
{
	try
	{
		String^ path = WMIconnectiondetails::logFilePath;
		if (!File::Exists(path))
		{
			StreamWriter^ sw = File::CreateText(path);
			sw->Close();
		}
		StreamWriter^ sw = File::AppendText(path);
		try
		{
			sw->Write(DateTime::Now +" : " + message + Environment::NewLine);						
		}
		finally
		{
			sw->Flush();
			sw->Close();
		}				
	}
	catch (Exception^ e)
	{
        //Console.WriteLine("CS WMILogger : " + e.Message + e.StackTrace);
	}
}

bool mergeVHDFIles(String^ vhdPath)
{
	try
	{
		WMILog("mergeVHDFIles started");
		ManagementObject^ vmImageManagementService = getManagementObjectInstance("Msvm_ImageManagementService");

		ManagementBaseObject^ inParams = vmImageManagementService->GetMethodParameters("GetVirtualHardDiskSettingData");
		inParams["Path"] = vhdPath;
		ManagementBaseObject^ outParams = vmImageManagementService->InvokeMethod("GetVirtualHardDiskSettingData", inParams, nullptr);
		String^ vhdsettingxmlString = outParams["SettingData"]->ToString();
		XmlDocument^ doc = gcnew XmlDocument();
		WMILog("mergeVHDFIles vhdsettingxmlString -> " + vhdsettingxmlString);
		try
		{
			doc->LoadXml(vhdsettingxmlString);
		}
		catch (Exception^ ex)
		{
			WMILog("mergeVHDFIles LoadXML Exception.." + ex->Message);
		}
		XmlNodeList^ nodelist = doc->SelectNodes("//PROPERTY[@NAME = 'ParentPath']/VALUE/child::text()");
		String^ parentPath = "";
		for each(XmlNode^ xn in nodelist)
		{
			parentPath = xn->InnerText;
		}
		WMILog("mergeVHDFIles Parent Path -> " + parentPath);

		if (parentPath == nullptr || parentPath->Equals(""))
		{
			WMILog("mergeVHDFIles Parent Path is NULL. Hence returning..");
			return true;
		}
		else
		{
			String^ vhdactualpathName = vhdPath->Substring(0, vhdPath->LastIndexOf("\\"));
			WMILog("mergeVHDFIles vhdactualpathName -> " + vhdactualpathName);
			String^ vhdDiskName = parentPath->Substring(parentPath->LastIndexOf("\\"), parentPath->Length - parentPath->LastIndexOf("\\"));
			WMILog("mergeVHDFIles vhdDiskName before-> " + vhdDiskName);
			vhdDiskName = vhdactualpathName + vhdDiskName;
			WMILog("vhdDiskName after-> " + vhdDiskName);
			
			WMILog("mergeVHDFIles ChildPath -> " + vhdPath);
			WMILog("mergeVHDFIles ParentPath -> " + vhdDiskName);

			inParams = vmImageManagementService->GetMethodParameters("SetParentVirtualHardDisk");
			inParams["ChildPath"] = vhdPath;
			inParams["ParentPath"] = vhdDiskName;
			if(vhdPath->Equals(vhdDiskName))
			{
				WMILog("mergeVHDFIles ChildPath  and ParentPath are EQUAL!!!!!!!!!!");
				return true;
			}
			inParams["LeafPath"] = nullptr;
			inParams["IgnoreIDMismatch"] = true;
			ManagementBaseObject^ outParams = vmImageManagementService->InvokeMethod("SetParentVirtualHardDisk", inParams, nullptr);
			bool test = ValidateOutput(outParams, WMIconnectiondetails::scope);
			WMILog("mergeVHDFIles Done  SetParentVirtualHardDisk");

			inParams = vmImageManagementService->GetMethodParameters("MergeVirtualHardDisk");
			inParams["SourcePath"] = vhdPath;
			inParams["DestinationPath"] = vhdDiskName;
			outParams = vmImageManagementService->InvokeMethod("MergeVirtualHardDisk", inParams, nullptr);
			test = ValidateOutput(outParams, WMIconnectiondetails::scope);
			WMILog("mergeVHDFIles Done  MergeVirtualHardDisk. Calling mergeVHDFIles again");
			return mergeVHDFIles(vhdDiskName);
		}

	}
	catch (Exception^ ex)
	{
		WMILog("MergeVirtualHardDisk Exception.." + ex->Message);
		return false;
	}
}

void DeletedecryptedFiles(String^ fullbackupvmPathString, String^ vmNameString)
{
	try
	{
		WMILog("DeletedecryptedFiles started.. fullbackupvmPathString -> " + fullbackupvmPathString + "vmNameString -> " + vmNameString);
		String^ vmbackupPath = fullbackupvmPathString + "\\" + vmNameString;
		DirectoryInfo^ dir = gcnew DirectoryInfo(vmbackupPath);
		array<String^> ^ encryptedFiles = Directory::GetFiles(vmbackupPath, "*_secure*");
		for each(String^ encFile in encryptedFiles)
		{
			if(encFile->Contains("_secure"))//find all encrypted files, remove the suffix and delete the file if present
			{
				encFile = encFile->Substring(0, encFile->LastIndexOf("_secure"));
				if(File::Exists(encFile))
				{
					WMILog("DeletedecryptedFiles found file. Deleting -> " + encFile);
					File::Delete(encFile);
					WMILog("DeletedecryptedFiles Deleted " + encFile);
				}
			}
		}
	}
	catch (Exception^ ex)
	{
		WMILog("DeletedecryptedFiles Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace + "VM Name -> " + vmNameString);		
	}
}

int checkifBackupFilesPresent(String^ fullbackupvmPathString, String^ vmNameString)
{
	int isBackupFilespresent = 815;
	try
	{
		WMILog("checkifBackupFilesPresent started.. fullbackupvmPathString -> " + fullbackupvmPathString + "vmNameString -> " + vmNameString);
		String^ vmbackupPath = fullbackupvmPathString + "\\" + vmNameString;
		String^ vmconfigurationXMLFilePath = vmbackupPath + "\\" + vmNameString + ".xml";
		DirectoryInfo^ dir = gcnew DirectoryInfo(vmbackupPath);
		if (!dir->Exists)
		{
			isBackupFilespresent = 812;
			throw gcnew DirectoryNotFoundException("checkifBackupFilesPresent vmbackupPath Directory not found");
		}
		else
		{
			if (Directory::GetFiles(vmbackupPath)->Length == 0)
			{
				isBackupFilespresent = 812;
				throw gcnew DirectoryNotFoundException("checkifBackupFilesPresent vmbackupPath Directory found but empty!");
			}
		}
		if (!(File::Exists(vmconfigurationXMLFilePath)))
		{
			isBackupFilespresent = 813;
			throw gcnew DirectoryNotFoundException("checkifBackupFilesPresent vmconfigurationXMLFilePath file not found");					
		}
		if (((Directory::GetFiles(vmbackupPath, "*.vhd"))->Length == 0) && ((Directory::GetFiles(vmbackupPath, "*.avhd"))->Length == 0) && ((Directory::GetFiles(vmbackupPath, "*.vhdx"))->Length == 0) && ((Directory::GetFiles(vmbackupPath, "*.avhdx"))->Length == 0))
		{
			isBackupFilespresent = 814;
			throw gcnew DirectoryNotFoundException("checkifBackupFilesPresent vhdx file not found");					
		}
		isBackupFilespresent=0;
	}
	catch (Exception^ ex)
	{
		WMILog("checkifBackupFilesPresent Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace + "VM Name -> " + vmNameString);		
	}
	return isBackupFilespresent;
}

bool checkifVMPresent(String^ vmNameString)
{
	try
	{
		WMILog("checkifVMPresent VM Name -> " + vmNameString);
		String^ query = "select * from Msvm_ComputerSystem where Name='"+vmNameString+"'";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(WMIconnectiondetails::scope, gcnew ObjectQuery(query));		
		ManagementObjectCollection^ vms = searcher->Get();
		if (vms->Count > 0)
		{
			WMILog("checkifVMPresent VM Found -> " + vmNameString);
			return true;
		}
		else
		{
			WMILog("checkifVMPresent VM Not Found -> " + vmNameString);
			return false;
		}
	}
	catch (Exception^ ex)
	{
		WMILog("checkifVMPresent Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace + "VM Name -> " + vmNameString);
		return true;//don't have to fail disk restore for this simple exception. so can try to restore
	}
}

bool moveVMtoSavedState(String^ vmtoChangeState)
{
	bool result = true;
	WMILog("moveVMtoSavedState VM Name -> " + vmtoChangeState);
	try
	{
		if(WMIconnectiondetails::is2008Server)
		{
			WMILog("moveVMtoSavedState 2008 server..!!");
			result = RequestStateChange(vmtoChangeState, Convert::ToUInt16(32769));
		}
		else
		{
			WMILog("moveVMtoSavedState NOT 2008 server..!!");
			result = RequestStateChange(vmtoChangeState, Convert::ToUInt16(6));
		}
	}
	catch (Exception^ ex)
	{
		WMILog("moveVMtoSavedState Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace + "VM Name -> " + vmtoChangeState);	
		return false;	
	}
	return result;
}



bool checkifVMRunning(String^ vmName)
{
	bool result = true;
	WMILog("checkifVMRunning VM Name -> " + vmName);	
	try
	{
		String^ query = "SELECT * FROM Msvm_ComputerSystem WHERE Name = '" + vmName + "'";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(WMIconnectiondetails::scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ vms = searcher->Get();

		for each (ManagementObject^ vm in vms)
		{
			if((Convert::ToUInt16(vm["EnabledState"])).Equals(Convert::ToUInt16(2)))
			{
				WMILog("checkifVMRunning VM in Running state...");
				return true;
			}
		}
	}
	catch (Exception^ ex)
	{
		WMILog("checkifVMRunning Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace + "VM Name -> " + vmName);	
		return false;	
	}
	return result;
}

bool RequestStateChange(String^ vmtoChangeState, UInt16^ requestedState)
{
	bool result = true;
	WMILog("RequestStateChange VM Name -> " + vmtoChangeState + "Requested State -> " + requestedState);	
	try
	{
		String^ query = "SELECT * FROM Msvm_ComputerSystem WHERE Name = '" + vmtoChangeState + "'";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(WMIconnectiondetails::scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ vms = searcher->Get();

		for each (ManagementObject^ vm in vms)
		{
			if((Convert::ToUInt16(vm["EnabledState"])).Equals(requestedState))
			{
				WMILog("RequestStateChange VM already in requested state...");
				return true;
			}

			ManagementBaseObject^ inParams = vm->GetMethodParameters("RequestStateChange");
			inParams["RequestedState"] = requestedState; //2-> Enabled state, 3->turn off

			ManagementBaseObject^ outParams = vm->InvokeMethod("RequestStateChange", inParams, nullptr);	
			bool result = ValidateOutput(outParams, WMIconnectiondetails::scope);
			if (result)
			{
				WMILog("RequestStateChange Request Success");
				WMILog("Waiting for RequestStateChange...!");
				ManagementObject^ vmtocheck = vm;
				int counter = 0;
				while (!((Convert::ToUInt16(vmtocheck["EnabledState"])).Equals(requestedState)))
				{
					ManagementObjectCollection^ vmss = searcher->Get();
					for each (ManagementObject^ vmt in vmss)
					{
						vmtocheck = vmt;
					}
					WMILog("Still Waiting...!");
					counter++;
					if (counter > 15)
					{
						WMILog("RequestStateChange Timeout!");
						return false;	
						break;
					}
					System::Threading::Thread::Sleep(3000);
				}
				WMILog("RequestStateChange Completed");
				return true;				
			}				
			else
			{
				WMILog("RequestStateChange Failed");
				return false;			
			}	
		}
	}
	catch (Exception^ ex)
	{
		WMILog("RequestStateChange Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace + "VM Name -> " + vmtoChangeState);	
		return false;	
	}
	return result;
}

bool InitializeWMIGlobalvariables(LPWSTR hvHostName, LPWSTR WMILogpath)//checked
{
	marshal_context^ context = gcnew marshal_context();
	try
	{
		WMIconnectiondetails::hypervHostName = context->marshal_as<String^>(hvHostName);
		WMIconnectiondetails::logFilePath = context->marshal_as<String^>(WMILogpath);

		/*ConnectionOptions^ co = gcnew ConnectionOptions();
		co->Username = WMIconnectiondetails::userName;
		co->Password = WMIconnectiondetails::password;
		co->EnablePrivileges = true;*/		

		WMILog("Going to get OS version...");
		String^ cimV2Path = WMIconnectiondetails::hypervHostName + "\\root\\cimv2";
		WMILog("CIMV2 path -> " + cimV2Path);
		ManagementScope^ osVersionScope = gcnew ManagementScope(cimV2Path);

		String^ query = "select * from Win32_OperatingSystem";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(osVersionScope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ instances = searcher->Get();
		for each (ManagementObject^ mo in instances)
		{
			if(mo["Version"]!=nullptr)
			{
				WMIconnectiondetails::osVersion = mo["Version"]->ToString();
			}
			else
			{
				WMILog("Error: Cannot get OS Version...");
				return false;
			}			
		}
		WMILog("OS Version GOT ...-> " + WMIconnectiondetails::osVersion);

		String^ managementPath;
		if (WMIconnectiondetails::osVersion->StartsWith("6.1") || WMIconnectiondetails::osVersion->StartsWith("6.0"))
		{
			WMIconnectiondetails::is2008Server = true;
			managementPath = WMIconnectiondetails::hypervHostName + "\\root\\virtualization";
		}
		else if (WMIconnectiondetails::osVersion->StartsWith("6.2") || WMIconnectiondetails::osVersion->StartsWith("6.3") || WMIconnectiondetails::osVersion->StartsWith("10.0"))
		{
			WMIconnectiondetails::is2008Server = false;
			managementPath = WMIconnectiondetails::hypervHostName + "\\root\\virtualization\\v2";
		}
		WMILog("HyperV HostName: " + WMIconnectiondetails::hypervHostName + " Path: " + managementPath);
		//WMIconnectiondetails::scope = gcnew ManagementScope(managementPath, co);
		WMIconnectiondetails::scope = gcnew ManagementScope(managementPath);
		WMILog("Virtualization scope created...");
		return true;

	}
	catch (Exception^ ex)
	{
		WMILog("InitializeWMIGlobalvariables Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace);
		return false;
	}
	if (context != nullptr)
	{
		delete context; context = nullptr;
	}

}


ManagementObject^ GetTargetComputer(String^ vmInstanceID, ManagementScope^ scope)
{
	String^ query = "select * from Msvm_ComputerSystem Where Name = '" + vmInstanceID + "'";
	ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(scope, gcnew ObjectQuery(query));
	ManagementObjectCollection^ computers = searcher->Get();
	ManagementObject^ computer = nullptr;
	for each(ManagementObject^ instance in computers)
	{
		computer = instance;
		break;
	}
	return computer;
}

ManagementObject^ getManagementObjectInstance(String^ className)
{
		String^ query = "select * from " + className;
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(WMIconnectiondetails::scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ collection = searcher->Get();
		ManagementObject^ returnObject = gcnew ManagementObject();

		for each (ManagementObject^ mo in collection)
		{
			returnObject = mo;
		}
		return returnObject;
}

bool IsJobComplete(UInt16 jobState)
{
	return ((jobState == 7) || (jobState == 8) || (jobState == 10) || (jobState == 9));
	// return (jobState == JobState.Completed) || jobState == JobState.CompletedWithWarnings) ||(jobState == JobState.Terminated) ||jobstate == JobState.Exception) || (jobState == JobState.Killed);
}

bool IsJobSuccessful(UInt16 jobState)
{
	return (jobState == 7);
	// return (jobState == JobState.Completed) || jobState == JobState.CompletedWithWarnings) ||(jobState == JobState.Terminated) ||jobstate == JobState.Exception) || (jobState == JobState.Killed);
}

bool ValidateOutput(ManagementBaseObject^ outputParameters, ManagementScope^ scope)//todo
{
	bool succeeded = true;
	String^ errorMessage = "The method call failed.";

	if (Convert::ToUInt16(outputParameters["ReturnValue"]) == 4096)
	{
		ManagementObject^ job = gcnew ManagementObject(outputParameters["Job"]->ToString());
		{
			job->Scope = scope;
			WMILog("JOB STATE before while: -> " + Convert::ToUInt16(job["JobState"]));
			while (!IsJobComplete(Convert::ToUInt16(job["JobState"])))
			{
				//WMILog("JOB STATE: -> " + Convert::ToUInt16(job["JobState"]));
				//Thread.Sleep(TimeSpan.FromSeconds(1));
				job->Get();
			}

			//if (Convert::ToUInt16(job["JobState"]) != 7 && Convert::ToUInt16(job["JobState"]) != 32768)//7 is completed, 32768 warnings
			if (!IsJobSuccessful(Convert::ToUInt16(job["JobState"])))
			{
				succeeded = false;
				WMILog("Job failed not completed no warnings");
				if (job["ErrorDescription"] != nullptr)
				{
					errorMessage = job["ErrorDescription"]->ToString();
					WMILog("Job ErrorDescription: -> " + errorMessage);
					WMILog("Job ErrorCode: -> " + job["ErrorCode"]);
					WMILog("Job State: -> " + Convert::ToUInt16(job["JobState"]));
				}
			}
		}
	}
	else if (Convert::ToUInt16(outputParameters["ReturnValue"]) != 0)
	{
		WMILog("ValidateOutput RETURN VALUE IN ValidateOutput METHOD: -> " + Convert::ToUInt16(outputParameters["ReturnValue"]));		
		succeeded = false;

	}
	else
	{
		WMILog("ValidateOutput Successful execution..." + Convert::ToUInt16(outputParameters["ReturnValue"]));

	}

	return succeeded;
}

List<String^>^ GetlistofResources(ManagementObject^ settingData, UInt16 resourceType, String^ resourceSubType, String^ storageclassName)
{
	List<String^>^ VHDlist = gcnew List<String^>();
	try
	{
	//retrieve the rasd

		ManagementObjectCollection^ RASDs = settingData->GetRelated(storageclassName); 
		for each(ManagementObject^ rasdInstance in RASDs)
		{
			if (Convert::ToUInt16(rasdInstance["ResourceType"]) == resourceType) 
			{
				if (rasdInstance["ResourceSubType"]->ToString()->Equals(resourceSubType))
				{
					array<String^>^ VHDarray = gcnew array<String^>(10);
					if(WMIconnectiondetails::osVersion->StartsWith("5") || WMIconnectiondetails::osVersion->StartsWith("6.0") || WMIconnectiondetails::osVersion->StartsWith("6.1"))
					{
						VHDarray = (array<String^>^)rasdInstance["Connection"];
					}
					else
					{
						VHDarray = (array<String^>^)rasdInstance["HostResource"];
					}
					for each(String^ VHD in VHDarray)
					{
						WMILog("VHD Path" + VHD);
						VHDlist->Add(VHD);
					}
				}
			}


		}
	}
	catch (Exception^ ex)
	{	
		WMILog("GetlistofResources Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace);
	}
	return VHDlist;

}

bool shutdownVM(String^ vmtoTurnoff)
{
	bool result = true;
	try
	{
		WMILog("hvWMI.cpp Going to turn off VM -> " + vmtoTurnoff);
		String^ query = "SELECT * FROM Msvm_ComputerSystem WHERE Name = '" + vmtoTurnoff + "'";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(WMIconnectiondetails::scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ vms = searcher->Get();

		for each (ManagementObject^ vm in vms)
		{
			ManagementObject^ msvm_computersystem = vm;
			ManagementObjectCollection^ collection = msvm_computersystem->GetRelated("Msvm_ShutdownComponent");
			for each (ManagementObject^ mo in collection)
			{
				ManagementObject^ msvm_shutdowncomponent = mo;
				ManagementBaseObject^ inParams = msvm_shutdowncomponent->GetMethodParameters("InitiateShutdown");
				inParams["Force"] = true;
				inParams["Reason"] = "RMP Restore";
				ManagementBaseObject^ outParams = msvm_shutdowncomponent->InvokeMethod("InitiateShutdown", inParams, nullptr);
				result = ValidateOutput(outParams, WMIconnectiondetails::scope);
				if (result)
				{
					WMILog("SHUTDOWN Request Success");
					WMILog("Waiting for shutdown...!");
					ManagementObject^ vmtocheck = vm;
					int counter = 0;
					while (Convert::ToUInt16(vmtocheck["EnabledState"]) != 3)
					{
						ManagementObjectCollection^ vmss = searcher->Get();
						for each (ManagementObject^ vmt in vmss)
						{
							vmtocheck = vmt;
						}
						WMILog("Still Waiting...!");
						counter++;
						if (counter > 15)
						{
							WMILog("SHUTDOWN Timeout!");
							result=false;
							break;
						}
						System::Threading::Thread::Sleep(3000);
					}
					WMILog("SHUTDOWN Completed");
					result=true;
				}				
				else
				{
					WMILog("SHUTDOWN Failed");
					result=false;
				}
			}
		}
	}
	catch (Exception^ ex)
	{
		WMILog("shutdownVM Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace);
		result=false;
	}
	WMILog("shutdownVM Return value -> " + result);
	return result;
}

String^ getdefaultVHDLocation()
{
	String^ VHDdefaultLocation = "-";
	try
	{
		ManagementObject^ mo = getManagementObjectInstance("Msvm_VirtualSystemManagementServiceSettingData");
		VHDdefaultLocation = (String^)mo["DefaultVirtualHardDiskPath"];
	}
	catch (Exception^ ex)
	{	
		WMILog("getdefaultVHDLocation Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace);
	}
	return VHDdefaultLocation;
}

void CopyVHDfilestotargetDirectory(String^ sourceDirName, String^ destDirName, BSTR restoreId, BSTR vmId, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *))
{
	// Get the subdirectories for the specified directory.
	DirectoryInfo^ dir = gcnew DirectoryInfo(sourceDirName);
	WMILog("CopyVHDfilestotargetDirectory starts. sourceDirName-> " + sourceDirName + "  destDirName: " + destDirName);
	if (!dir->Exists)
	{
		throw gcnew DirectoryNotFoundException("Source directory does not exist or could not be found: " + sourceDirName);
	}

	//DirectoryInfo[^]^ dirs = dir->GetDirectories();
	int count = dir->GetDirectories()->Length;
	array<DirectoryInfo^>^ dirs = gcnew array<DirectoryInfo^>(count);
	dirs = dir->GetDirectories();

	// Get the files in the directory and copy them to the new location.
	count = dir->GetFiles()->Length;
	array<FileInfo^>^ files = gcnew array<FileInfo^>(count);
	files = dir->GetFiles();
	for each(FileInfo^ file in files)
	{
		//check if VHD file here
		if (!(file->Name->Contains(".vhd") || file->Name->Contains(".avhd")))
		{
			continue;
		}
		if(file->Name->Contains("_secure"))
		{
			continue;
		}
		String^ temppath = Path::Combine(destDirName, file->Name);
		String^ sourcePath = file->FullName;

		std::wstring wssourcePath = msclr::interop::marshal_as<std::wstring>(sourcePath);
		wchar_t* backupFolderpath = (wchar_t*)malloc((wcslen(wssourcePath.c_str()) + 1) * sizeof(wchar_t));
		wcscpy(backupFolderpath, wssourcePath.c_str());
		wcscat(backupFolderpath, L"\0");

		std::wstring wstemppath = msclr::interop::marshal_as<std::wstring>(temppath);
		wchar_t* actualFilepath = (wchar_t*)malloc((wcslen(wstemppath.c_str()) + 1) * sizeof(wchar_t));
		wcscpy(actualFilepath, wstemppath.c_str());
		wcscat(actualFilepath, L"\0");

		WMILog("WMIUtil.cpp CopyVHDfilestotargetDirectory DecompressFileDirectly:  \n");
		BOOL b = DecompressFileDirectly(backupFolderpath, actualFilepath,restoreId,vmId,callBackMethod);

		if (b) {
			WMILog("WMIUtil.cpp CopyVHDfilestotargetDirectory Decompressing VHD file Success!\n");
		}
		else {
			WMILog("WMIUtil.cpp CopyVHDfilestotargetDirectory Decompressing VHD file Failure: " + GetLastError() + "! \n");
		}
		if (backupFolderpath != nullptr){ delete[] backupFolderpath; }
		if (actualFilepath != nullptr){ delete[] actualFilepath; }
		//file->CopyTo(temppath, false);
	}

	for each(DirectoryInfo^ subdir in dirs)
	{
		CopyVHDfilestotargetDirectory(subdir->FullName, destDirName, restoreId, vmId, callBackMethod);
	}
}

ManagementObject^ GetResourceAllocationsettingData(ManagementObject^ settingData, UInt16 resourceType, String^ resourceSubType, String^ otherResourceType)
{
	ManagementObject^ RASD = nullptr;
	ManagementObjectCollection^ RASDs = settingData->GetRelated("Msvm_ResourceAllocationSettingData");
	for each(ManagementObject^ rasdInstance in RASDs)
	{
		if (rasdInstance["ResourceType"] != nullptr)
		{
			WMILog("Restype:" + Convert::ToUInt16(rasdInstance["ResourceType"]));
		}
		if (rasdInstance["ResourceSubType"] != nullptr)
		{
			WMILog("Ressubtype:" + rasdInstance["ResourceSubType"]->ToString());
		}
		if (Convert::ToUInt16(rasdInstance["ResourceType"]) == resourceType)
		{
				//found the matching type
				if (resourceType == 1)//ResourceType::Other=1
				{
					if (rasdInstance["OtherResourceType"]->ToString() == otherResourceType)
					{
						RASD = rasdInstance;
						break;
					}
				}
				else
				{

					if (rasdInstance["ResourceSubType"]->ToString() == resourceSubType)
					{
						WMILog("rasdInstance[Address]" + rasdInstance["Address"]);
						RASD = rasdInstance;
						break;
					}
				}
		}

			
	}
	return RASD;
}

ManagementObject^ GetResourceAllocationsettingDataDefault(ManagementScope^ scope, UInt16 resourceType, String^ resourceSubType, String^ otherResourceType)
{
	ManagementObject^ RASD = nullptr;

	String^ query = "select * from Msvm_ResourcePool where ResourceType = '" + resourceType + "' and ResourceSubType ='" + resourceSubType + "' and OtherResourceType = '" + otherResourceType + "'";

	if (resourceType == 1)//ResourceType.Other=1
	{
		query = "select * from Msvm_ResourcePool where ResourceType = '" + resourceType + "' and ResourceSubType = null and OtherResourceType = '" + otherResourceType + "'";
	}
	else
	{
		query = "select * from Msvm_ResourcePool where ResourceType = '" + resourceType + "' and ResourceSubType ='" + resourceSubType + "' and OtherResourceType = null";
	}

	ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(scope, gcnew ObjectQuery(query));

	ManagementObjectCollection^ poolResources = searcher->Get();

	//Get pool resource allocation ability
	if (poolResources->Count == 1)
	{
		for each(ManagementObject^ poolResource in poolResources)
		{
			ManagementObjectCollection^ allocationCapabilities = poolResource->GetRelated("Msvm_AllocationCapabilities");
			for each(ManagementObject^ allocationCapability in allocationCapabilities)
			{
				ManagementObjectCollection^ settingDatas = allocationCapability->GetRelationships("Msvm_SettingsDefineCapabilities");
				for each(ManagementObject^ settingData in settingDatas)
				{

					if (Convert::ToInt16(settingData["ValueRole"]) == 0)//Default = 0
					{
						RASD = gcnew ManagementObject(settingData["PartComponent"]->ToString());
						break;
					}
				}
			}
		}
	}
	return RASD;
}