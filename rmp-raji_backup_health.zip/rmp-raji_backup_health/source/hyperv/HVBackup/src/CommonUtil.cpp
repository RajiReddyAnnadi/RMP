#pragma once
#include "CommonUtil.h"
#include "zlib.h" 
#include <fcntl.h>  
#include <sys/types.h>  
#include <sys/stat.h>  
#include <io.h>  
#include <stdio.h>
#include <time.h>
#include <BuildIndex.h>

Loggerclass *commonutilLogger; 

void initializeCommonUtilvariables(Loggerclass *commonutilLoggerclass)
{
	commonutilLogger = commonutilLoggerclass;	
}

void CheckHRESULT(HRESULT hr, const wchar_t* COMcall)
{
	if (hr != S_OK)
	{		
		commonutilLogger->log(NORMAL, L"Hyper-V Backup EXCEPTION HRESULT: 0x%08lx In Method -> %ws !!!!!!!!!\n",hr,COMcall);	
		throw(hr);
	}
}

void WriteFile(wstring fileName, wstring contents)
{
	HANDLE hFile = CreateFile((LPWSTR)fileName.c_str(), GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, 0, NULL);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		//_tprintf(_T("Invalid filename\n"));
	}

	// Write the file contents
	DWORD dwWritten;
	DWORD cbWrite = (DWORD)((contents.length() + 1) * sizeof(WCHAR));
	WriteFile(hFile, (LPWSTR)contents.c_str(), cbWrite, &dwWritten, NULL);
}

int encryptdecryptFile(LPTSTR pszPassword, int oper, wchar_t* filePath)//0->Encrypt, 1-> Decrypt
{ 
	commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile started..\n");
	HCRYPTPROV hCryptProv = NULL;
	HCRYPTKEY hKey = NULL;
	HCRYPTKEY hXchgKey = NULL;
	HCRYPTHASH hHash = NULL;
	wchar_t secure[]  = L"_secure";
	wchar_t* wtextSource = new wchar_t[wcslen(filePath) + 1];
	wcscpy(wtextSource, filePath);
	wcscat(wtextSource, L"\0");
	wchar_t* wtextDest = new wchar_t[wcslen(filePath) + wcslen(L"_secure") + 1];
	wcscpy(wtextDest, filePath);
	wcscat(wtextDest, L"_secure");
	wcscat(wtextDest, L"\0");
	LPTSTR pszSourceFile,psZDestFile;
	if(oper == 0){
		pszSourceFile = wtextSource;
		psZDestFile = wtextDest;
	}else if(oper == 1){
		pszSourceFile = wtextDest;
		psZDestFile = wtextSource;
	}
	commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile pszSourceFile -> %ws\n",pszSourceFile);
	commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile psZDestFile -> %ws\n",psZDestFile);
	HANDLE hSourceFile = CreateFile(pszSourceFile, FILE_READ_DATA, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hSourceFile == INVALID_HANDLE_VALUE)
	{
		commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile hSourceFile is INVALID..!\n");
		return 1; 
	}
	HANDLE hDestinationFile = CreateFile(psZDestFile, FILE_WRITE_DATA, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hDestinationFile == INVALID_HANDLE_VALUE)
	{
		commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile hDestinationFile is INVALID..!\n");
		if(hSourceFile)
		{
			CloseHandle(hSourceFile);
		}
		return 1; 
	}
        bool CryptAcquireContextStatus = false;
	if(CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, 0))
	{
            commonutilLogger->log(NORMAL, L"CommonUtil.cpp CryptAcquireContext success on first try\n");
            CryptAcquireContextStatus = true;
	}
	else
	{
		commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile CryptAcquireContext FAILED..-> %d\n",GetLastError());
                if(CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, CRYPT_NEWKEYSET)) {
                        commonutilLogger->log(NORMAL, L"CommonUtil.cpp CryptAcquireContext success on second try");
			CryptAcquireContextStatus = true;
		} else {
                    commonutilLogger->log(NORMAL, L"Could not create a new key container. %d\n",(int) GetLastError());
                    if(hSourceFile)
                    {
                            CloseHandle(hSourceFile);
                    }
                    if(hDestinationFile)
                    {
                            CloseHandle(hDestinationFile);
                    }
                    return 1;
		}
		
	}
        
        if(CryptAcquireContextStatus){
            if(CryptCreateHash(hCryptProv, CALG_MD5, 0, 0, &hHash))
		{
			if(CryptHashData(hHash, (BYTE *)pszPassword, lstrlen(pszPassword), 0))
			{
				if(CryptDeriveKey(hCryptProv, ENCRYPT_ALGORITHM, hHash, KEYLENGTH, &hKey))
				{
					commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile Inside CryptDeriveKey..\n");
					DWORD dwBlockLen;
					DWORD dwBufferLen;
					DWORD dwCount;
					PBYTE pbBuffer = NULL;
					dwBlockLen = 1000 - 1000 % ENCRYPT_BLOCK_SIZE;
					if(ENCRYPT_BLOCK_SIZE > 1)
					{
						dwBufferLen = dwBlockLen + ENCRYPT_BLOCK_SIZE;
					}
					else
					{
						dwBufferLen = dwBlockLen;
					}
					if(pbBuffer = (BYTE *)malloc(dwBufferLen))
					{
						bool fEOF = FALSE;
						do
						{
                        	//commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile Running..!\n");
							if(ReadFile(hSourceFile, pbBuffer, dwBlockLen, &dwCount, NULL))
							{
								if(dwCount < dwBlockLen)
								{
									commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile EOF reached..!\n");
									fEOF = TRUE;
								}
								if(oper==0)
								{
									if(CryptEncrypt(hKey, NULL, fEOF, 0, pbBuffer, &dwCount, dwBufferLen))
									{
										if(WriteFile(hDestinationFile, pbBuffer, dwCount, &dwCount, NULL))
										{
										}
										else
										{
											commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile oper 0 WriteFile returned FALSE..!-> %d\n",GetLastError());
										}
									}
									else
									{
										commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile CryptEncrypt returned FALSE..!-> %d\n",GetLastError());
									}
								}
								else if(oper==1)
								{
									if(CryptDecrypt(hKey, NULL, fEOF, 0, pbBuffer, &dwCount))
									{
										if(WriteFile(hDestinationFile, pbBuffer, dwCount, &dwCount, NULL))
										{
										}
										else
										{
											commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile oper 0 WriteFile returned FALSE..!-> %d\n",GetLastError());
										}
									}
									else
									{
										commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile CryptDecrypt returned FALSE..!-> %d\n",GetLastError());
									}
								}
							}
							else
							{
								commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile ReadFile returned FALSE..-> %d\n",GetLastError());
							}
						} while(!fEOF);
						if(hSourceFile)
						{
							commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile Success case Closing hSourceFile..\n");
							CloseHandle(hSourceFile);
						}
						if(hDestinationFile)
						{
							commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile Success case Closing hDestinationFile..\n");
							CloseHandle(hDestinationFile);
						}
						if(pbBuffer)
						{
							free(pbBuffer);
						}
						if(hHash)
						{
							if((CryptDestroyHash(hHash)))
							{
							}
						}
						if(hCryptProv)
						{
							if((CryptReleaseContext(hCryptProv, 0)))
							{
							}
						}
					}
					else
					{
						commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile malloc FAILED..-> %d\n",GetLastError());
					}
				}
				else
				{
					commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile CryptDeriveKey FAILED..-> %d\n",GetLastError());
					if(hSourceFile)
					{
						CloseHandle(hSourceFile);
					}
					if(hDestinationFile)
					{
						CloseHandle(hDestinationFile);
					}
					return 1;
				}
			}
			else
			{
				commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile CryptHashData FAILED..-> %d\n",GetLastError());
				if(hSourceFile)
				{
					CloseHandle(hSourceFile);
				}
				if(hDestinationFile)
				{
					CloseHandle(hDestinationFile);
				}
				return 1;
			}
		}
		else
		{
			commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile CryptCreateHash FAILED..-> %d\n",GetLastError());
			if(hSourceFile)
			{
				CloseHandle(hSourceFile);
			}
			if(hDestinationFile)
			{
				CloseHandle(hDestinationFile);
			}
			return 1;
		}
        }
        
	if(oper == 0)
	{
		commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile ENCRYPTION OPERATION. Deleting File -> %ws\n",pszSourceFile);
		bool isDeleted = DeleteFile(pszSourceFile);
		if(!isDeleted)
		{
		    DWORD error = GetLastError();
		    commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile Deleting File Failed -> %d\n", error);
		    if((int)error == 5) {//access dined - may due to read only file. So removing read only.
                int result = SetFileAttributes( pszSourceFile,  GetFileAttributes(pszSourceFile) & ~FILE_ATTRIBUTE_READONLY);
                commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile setFileAttributes result -> %d-%d\n", result, GetLastError());
		    }
			Sleep(5000);
			isDeleted = DeleteFile(pszSourceFile);
			if(!isDeleted)
			{
				commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile Deleting File Failed second time also -> %d\n",GetLastError());
			}

		}
	} 
	else
	{
		commonutilLogger->log(NORMAL, L"CommonUtil.cpp encryptdecryptFile DECRYPTION OPERATION. NOT Deleting File -> %ws\n",pszSourceFile);
	}
	return 0;
}

HRESULT ModifyPrivilege(IN LPCTSTR szPrivilege, IN BOOL fEnable)
{
	HRESULT hr = S_OK;
	TOKEN_PRIVILEGES NewState;
	LUID             luid;
	HANDLE hToken = NULL;

	// Open the process token for this process.
	if (!OpenProcessToken(GetCurrentProcess(),
		TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
		&hToken))
	{
		commonutilLogger->log(NORMAL, L"Failed OpenProcessToken\n");
		return ERROR_FUNCTION_FAILED;
	}

	// Get the local unique ID for the privilege.
	if (!LookupPrivilegeValue(NULL,
		szPrivilege,
		&luid))
	{
		CloseHandle(hToken);
		commonutilLogger->log(NORMAL, L"Failed LookupPrivilegeValue\n");
		return ERROR_FUNCTION_FAILED;
	}

	// Assign values to the TOKEN_PRIVILEGE structure.
	NewState.PrivilegeCount = 1;
	NewState.Privileges[0].Luid = luid;
	NewState.Privileges[0].Attributes =
		(fEnable ? SE_PRIVILEGE_ENABLED : 0);

	// Adjust the token privilege.
	if (!AdjustTokenPrivileges(hToken,
		FALSE,
		&NewState,
		0,
		NULL,
		NULL))
	{
		commonutilLogger->log(NORMAL, L"Failed AdjustTokenPrivileges\n");
		hr = ERROR_FUNCTION_FAILED;
	}

	// Close the handle.
	CloseHandle(hToken);

	return hr;
}

int backup_file_exists(wchar_t *filePath, WIN32_FIND_DATA *lpFindFileData, HANDLE *handle)
{

	*handle = FindFirstFile(filePath, _Out_ lpFindFileData);
	if (*handle == INVALID_HANDLE_VALUE)
	{
		commonutilLogger->log(NORMAL, L"\nFile not found\n");
		return 1;
	}
	return 0;
}

BOOL create_directory(wchar_t *filePath)
{

	BOOL result = CreateDirectory(filePath, NULL);
	if (result)
		return 0;
	else
	{
		if (GetLastError() == ERROR_ALREADY_EXISTS)
			return 0;
		return 1;
	}
}


int backup_file(wchar_t *dirpath, WIN32_FIND_DATA lpFindFileData, wchar_t *vscpath, wchar_t *destinationPath)
{
	if (dirpath[wcslen(dirpath) - 1] == '*')
		dirpath[wcslen(dirpath) - 1] = '\0';
	commonutilLogger->log(NORMAL, L"\nfile name %ls, type is %ld\n", lpFindFileData.cFileName, lpFindFileData.dwFileAttributes);
	DWORD file_attributes = lpFindFileData.dwFileAttributes;
	wchar_t *path = new wchar_t[wcslen(dirpath) + wcslen(lpFindFileData.cFileName) + 2];
	wcscpy_s(path, wcslen(dirpath) + wcslen(lpFindFileData.cFileName) + 1, dirpath);
	size_t pathlen = wcslen(path) + wcslen(lpFindFileData.cFileName) + 1;
	wcscat_s(path, pathlen, lpFindFileData.cFileName);
	commonutilLogger->log(NORMAL, L"\n\nPATH:...%ls", path);
	size_t len = wcslen(vscpath);
	int i = 0;
	wchar_t *temp_path = new wchar_t[wcslen(path) - len + 2];
	temp_path = &path[len - 2];
	commonutilLogger->log(NORMAL, L"\n");
	wprintf(temp_path);
	commonutilLogger->log(NORMAL, L"\n");
	wchar_t *backup_path = new wchar_t[wcslen(destinationPath) + wcslen(temp_path) + 1];
	wcscpy_s(backup_path, wcslen(destinationPath) + wcslen(temp_path) + 1, destinationPath);
	wcscat_s(backup_path, wcslen(backup_path) + wcslen(temp_path) + 1, temp_path);
	//commonutilLogger->log(NORMAL, L"\nbackup file path is %ls\n",backup_path);
	int j = 0;
	int index = -1;
	while (backup_path[j] != '\0')
	{
		if (backup_path[j] == '\\')
			index = j;
		j = j + 1;
	}
	//commonutilLogger->log(NORMAL, L"\nLast index of \\ is %d\n",index);
	wchar_t *directorypath = new wchar_t[index + 1];
	int k = 0;
	for (k = 0; k<index; k++)
	{
		directorypath[k] = backup_path[k];
	}
	directorypath[k] = '\0';
	commonutilLogger->log(NORMAL, L"\nDirectory path is %ls\n", directorypath);
	
	DWORD dwAttrib = GetFileAttributes(directorypath);
	if (dwAttrib == INVALID_FILE_ATTRIBUTES)
	{
		BOOL result = CreateDirectory(directorypath, NULL);
	}

	//rmp
	commonutilLogger->log(NORMAL, L"\n\PATH ABOUT TO READ:%ls", path);
	commonutilLogger->log(NORMAL, L"\n\nBackup path is %ls\n", backup_path);
	HANDLE hFile = CreateFile(path, GENERIC_READ | ACCESS_SYSTEM_SECURITY, 0, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);

	if (hFile == INVALID_HANDLE_VALUE)
	{
		commonutilLogger->log(NORMAL, L"\nFile not found %ld\n", GetLastError());
		return 1;
	}
	LPVOID  lpContext = NULL;
	DWORD lpFileSizeHigh;
	LARGE_INTEGER sz;
	sz.LowPart = lpFindFileData.nFileSizeLow;
	sz.HighPart = lpFindFileData.nFileSizeHigh;
	DWORD filesize = sz.QuadPart;
	BYTE *buffer = new BYTE[filesize];
	DWORD   nNumberOfBytesToRead = filesize;
	DWORD lpNumberOfBytesRead;
	BOOL resultBackup = BackupRead(hFile, buffer, nNumberOfBytesToRead, &lpNumberOfBytesRead, FALSE, TRUE, &lpContext);
	if (resultBackup)
	{
		commonutilLogger->log(NORMAL, L"\nData has been totally read %ld.size of file is %ld bytes\n", nNumberOfBytesToRead, lpNumberOfBytesRead);
		BOOL resultBackupTemp = BackupRead(hFile, buffer, nNumberOfBytesToRead, &lpNumberOfBytesRead, TRUE, TRUE, &lpContext);
		commonutilLogger->log(NORMAL, L"\n2.Data has been totally read %ld.size of file is %ld bytes\n", nNumberOfBytesToRead, lpNumberOfBytesRead);
	}
	else
	{
		commonutilLogger->log(NORMAL, L"\n %ld Error in reading data\n", lpNumberOfBytesRead);
		commonutilLogger->log(NORMAL, L"\nError no is %ld\n", GetLastError());
		return 1;
	}
	CloseHandle(hFile);
	
	commonutilLogger->log(NORMAL, L"\nBackup path is %ls\n", backup_path);
	LPCTSTR lpFileName = backup_path;
	HANDLE hBackupFile = CreateFile(backup_path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		commonutilLogger->log(NORMAL, L"\nFile not created\n");
		return 1;
	}
	BOOL result = SetFileAttributes(backup_path, file_attributes);
	if (result)
		commonutilLogger->log(NORMAL, L"\nFile attributes are set\n");
	HANDLE hBackupPath = FindFirstFile(backup_path, _Out_ &lpFindFileData);
	if (hBackupPath == INVALID_HANDLE_VALUE)
	{
		commonutilLogger->log(NORMAL, L"\nBackup File not found\n", GetLastError());
		return 1;
	}
	DWORD lpNumberOfBytesWritten;
	BOOL finalresult = WriteFile(hBackupFile, buffer, lpNumberOfBytesRead, &lpNumberOfBytesWritten, NULL);
	if (!finalresult)
	{
		commonutilLogger->log(NORMAL, L"\nBackup unsuccessfull %ld\n", GetLastError());
		return 1;
	}
	CloseHandle(hBackupFile);
	delete[] buffer;
	return 1;
}

int backup_directory(wchar_t *sourcePath, WIN32_FIND_DATA lpFindFileData, wchar_t *vssSnapshotPath, wchar_t *destinationPath)
{
	commonutilLogger->log(NORMAL, L"\directory name %ls, type is %ld\n", lpFindFileData.cFileName, lpFindFileData.dwFileAttributes);
	wchar_t *dirpath = new wchar_t[300];
	int p = 0;
	dirpath = sourcePath;
	DWORD file_attributes = lpFindFileData.dwFileAttributes;
	if (dirpath[wcslen(dirpath) - 1] == '*')
		dirpath[wcslen(dirpath) - 1] = '\0';
	size_t pathlen = wcslen(dirpath) + wcslen(lpFindFileData.cFileName) + 3;
	wcscat_s(dirpath, pathlen, lpFindFileData.cFileName);

	wcscat_s(dirpath, pathlen, L"\\*");
	wchar_t *dirtemp = new wchar_t[500];
	dirtemp = dirpath;
	size_t len = wcslen(vssSnapshotPath);
	int i = 0;
	wchar_t *temp_path = new wchar_t[wcslen(dirtemp) - len + 2];
	temp_path = &dirtemp[len - 2];
	int temp = len;
	i = 0;
	/*while(dirtemp[temp]!='\0')
	{
	temp_path[i]=dirtemp[temp];
	temp=temp+1;
	i=i+1;
	}*/
	commonutilLogger->log(NORMAL, L"\n");
	wprintf(dirtemp);
	commonutilLogger->log(NORMAL, L"\n");
	wprintf(temp_path);
	commonutilLogger->log(NORMAL, L"\n");
	wchar_t *backup_path = new wchar_t[wcslen(destinationPath) + wcslen(temp_path) + 1];
	wcscpy_s(backup_path, wcslen(destinationPath) + wcslen(temp_path) + 1, destinationPath);
	wcscat_s(backup_path, wcslen(backup_path) + wcslen(temp_path) + 1, temp_path);
	int j = 0;
	int index = -1;
	while (backup_path[j] != '\0')
	{
		if (backup_path[j] == '\\')
			index = j;
		j = j + 1;
	}
	wchar_t *directorypath = new wchar_t[index + 1];
	int k = 0;
	for (k = 0; k<index; k++)
	{
		directorypath[k] = backup_path[k];
	}
	directorypath[k] = '\0';
	commonutilLogger->log(NORMAL, L"\nDirectory path is %ls\n", directorypath);
	DWORD dwAttrib = GetFileAttributes(directorypath);
	if (dwAttrib == INVALID_FILE_ATTRIBUTES)
	{
		BOOL result = CreateDirectory(directorypath, NULL);
	}
	BOOL result = SetFileAttributes(directorypath, file_attributes);
	if (result)
		commonutilLogger->log(NORMAL, L"\File attributes are set\n");
	commonutilLogger->log(NORMAL, L"\nDirectory path is %ls\n", dirpath);
	HANDLE hDirpath = FindFirstFile(dirpath, _Out_ &lpFindFileData);
	if (hDirpath != INVALID_HANDLE_VALUE)
	{
		dirpath[wcslen(dirpath) - 1] = '\0';
		if (GetFileAttributes(dirpath) & FILE_ATTRIBUTE_HIDDEN)
			SetFileAttributes(backup_path, FILE_ATTRIBUTE_HIDDEN);
		if (GetFileAttributes(dirpath) & FILE_ATTRIBUTE_SYSTEM)
			SetFileAttributes(backup_path, FILE_ATTRIBUTE_SYSTEM);
		data_backup(hDirpath, dirpath, lpFindFileData, vssSnapshotPath, destinationPath);
	}
	commonutilLogger->log(NORMAL, L"\n\nReturned from sub directory\n\n");
	commonutilLogger->log(NORMAL, L"\n");
	int dirlen = wcslen(dirpath);
	temp = 0;
	int itemp = dirlen;
	for (itemp = dirlen; itemp >= 0; itemp--)
	{
		if (dirpath[itemp] == '\\')
			temp = temp + 1;
		if (temp == 2)
			break;
	}
	dirpath[itemp + 1] = '\0';
	return 0;
}


int data_backup(HANDLE handle, wchar_t *sourcePath, WIN32_FIND_DATA lpFindFileData, wchar_t *vssSnapshotPath, wchar_t *destinationPath)
{
	do
	{
		if (!wcscmp(lpFindFileData.cFileName, L"."));
		else if (!wcscmp(lpFindFileData.cFileName, L".."));
		else if (!wcscmp(lpFindFileData.cFileName, L"$RECYCLE.BIN") || !(wcscmp(lpFindFileData.cFileName, L"Application Data")));
		else if (!wcscmp(lpFindFileData.cFileName, L"System Volume Information"));
		else if (!wcscmp(lpFindFileData.cFileName, L"Documents and Settings"));
		else
		{
			wchar_t *dirpath = new wchar_t[500];
			int p = 0;
			dirpath = sourcePath;

			if (lpFindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
				//commonutilLogger->log(NORMAL, L"\nDirectory name is %ls and type is %ld\n",lpFindFileData.cFileName,lpFindFileData.dwFileAttributes); 
				//sourcePath[wcslen(sourcePath)-1]='\0';

				backup_directory(sourcePath, lpFindFileData, vssSnapshotPath, destinationPath);
			}
			else
			{
				backup_file(dirpath, lpFindFileData, vssSnapshotPath, destinationPath);
				//commonutilLogger->log(NORMAL, L"\nfile name is %ls and type is %ld\n",lpFindFileData.cFileName,lpFindFileData.dwFileAttributes);
			}
		}
	} while (FindNextFile(handle, &lpFindFileData));
	CloseHandle(handle);
	return 0;
}


int data_backup_initialization(wchar_t *VssSnapshotPath, wchar_t *destination, wchar_t *filePath)
{
	WIN32_FIND_DATA lpFindFileData;
	HANDLE handle;
	int result;
	wchar_t *sourcePath = new wchar_t[500];
	wcscpy_s(sourcePath, 500, VssSnapshotPath);
	wchar_t *destinationPath = new wchar_t[500];
	wcscpy_s(destinationPath, 500, destination);
	commonutilLogger->log(NORMAL, L"\n\nSource: %ls", sourcePath);
	wchar_t appendedPath[300];
	wcscpy_s(appendedPath, 300, filePath);
	size_t len = wcslen(sourcePath) + wcslen(appendedPath) + 1;
	wcscat_s(sourcePath, len, appendedPath);
	commonutilLogger->log(NORMAL, L"\n\n sourcePath: %ls", sourcePath);
	wcscat_s(VssSnapshotPath, wcslen(VssSnapshotPath) + wcslen(filePath) + 1, filePath);
	result = create_directory(destinationPath);
	if (result == 1)
	{
		commonutilLogger->log(NORMAL, L"\nunable to create directory\n");
		return 1;
	}
	//wcscat_s(destinationPath, wcslen(destinationPath) + wcslen(filePath) + 2, filePath);
	if (destinationPath[wcslen(destinationPath) - 1] == '*')
		destinationPath[wcslen(destinationPath) - 1] = '\0';
	commonutilLogger->log(NORMAL, L"\n\nSP:....%ls\n\nDP:...%ls", sourcePath, destinationPath);
	result = backup_file_exists(sourcePath, &lpFindFileData, &handle);
	if (result == 1)
	{
		commonutilLogger->log(NORMAL, L"\nbackup file did not found\n");
		return 1;
	}
	result = create_directory(destinationPath);
	if (result == 1)
	{
		commonutilLogger->log(NORMAL, L"\nunable to create directory\n");
		return 1;
	}
	result = data_backup(handle, sourcePath, lpFindFileData, VssSnapshotPath, destinationPath);
	if (result != 0)
		commonutilLogger->log(NORMAL, L"\nBackup was not successful\n");
	else
		commonutilLogger->log(NORMAL, L"\nBackup was successful\n");

	return result;
}

int file_size(FILE *f)
{
	int size = 1;
	wchar_t temp;
	temp = fgetwc(f);

	while (temp != WEOF)
	{

		temp = fgetwc(f);
		size = size + 1;
	}
	return size;
}

int create_restore_directory(wchar_t *destinationPath)
{
	BOOL bResult = CreateDirectory(destinationPath, NULL);
	if (bResult)
		return 0;
	else
	{
		if (GetLastError() == ERROR_ALREADY_EXISTS)
			return 0;
		else
			return 1;
	}
}


DWORD restore_file_exists(wchar_t *sourcePath)
{
	DWORD file_type = GetFileAttributes(sourcePath);
	return file_type;
}


int restore_file(wchar_t *sourcePath, WIN32_FIND_DATA lpFindFileData, wchar_t *destinationPath, wchar_t *tempPath)
{
	wchar_t *dirpath = new wchar_t[300];
	int p = 0;
	dirpath = sourcePath;
	DWORD file_attibutes = lpFindFileData.dwFileAttributes;
	if (dirpath[wcslen(dirpath) - 1] == '*')
		dirpath[wcslen(dirpath) - 1] = '\0';
	commonutilLogger->log(NORMAL, L"file name %ls, type is %ld\n", lpFindFileData.cFileName, lpFindFileData.dwFileAttributes);
	wchar_t *path = new wchar_t[wcslen(dirpath) + wcslen(lpFindFileData.cFileName) + 2];
	wcscpy_s(path, wcslen(dirpath) + wcslen(lpFindFileData.cFileName) + 1, dirpath);
	size_t pathlen = wcslen(path) + wcslen(lpFindFileData.cFileName) + 1;
	wcscat_s(path, pathlen, lpFindFileData.cFileName);
	commonutilLogger->log(NORMAL, L"retrieving file from %ls and its type is %ld\n", path, lpFindFileData.dwFileAttributes);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////
	int len = wcslen(tempPath);
	int i = 0;
	wchar_t *temp_path = new wchar_t[wcslen(path) - len + 2];
	temp_path = &path[len - 1];
	commonutilLogger->log(NORMAL, L"\n");
	wprintf(temp_path);
	commonutilLogger->log(NORMAL, L"\n");
	wchar_t *backup_path = new wchar_t[wcslen(destinationPath) + wcslen(temp_path) + 1];
	wcscpy_s(backup_path, wcslen(destinationPath) + wcslen(temp_path) + 1, destinationPath);
	wcscat_s(backup_path, wcslen(backup_path) + wcslen(temp_path) + 1, temp_path);
	commonutilLogger->log(NORMAL, L"\\restore file path is %ls\n", backup_path);
	int j = 0;
	int index = -1;
	while (backup_path[j] != '\0')
	{
		if (backup_path[j] == '\\')
			index = j;
		j = j + 1;
	}
	commonutilLogger->log(NORMAL, L"\nLast index of \\ is %d\n", index);
	wchar_t *directorypath = new wchar_t[index + 1];
	int k = 0;
	for (k = 0; k<index; k++)
	{
		directorypath[k] = backup_path[k];
	}
	directorypath[k] = '\0';
	commonutilLogger->log(NORMAL, L"\nDirectory path is %ls\n", directorypath);
	dirpath = directorypath;
	DWORD dwAttrib = GetFileAttributes(directorypath);
	if (dwAttrib == INVALID_FILE_ATTRIBUTES)
	{
		BOOL result = CreateDirectory(directorypath, NULL);
	}
	HANDLE hFile = CreateFile(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		commonutilLogger->log(NORMAL, L"\nFile not found\n");
		return 1;
	}
	commonutilLogger->log(NORMAL, L"\nGot access to specified file\n");
	LPVOID  lpContext = NULL;
	DWORD lpFileSizeHigh;
	LARGE_INTEGER sz;
	sz.LowPart = lpFindFileData.nFileSizeLow;
	sz.HighPart = lpFindFileData.nFileSizeHigh;
	DWORD filesize = sz.QuadPart;
	BYTE *buffer = new BYTE[filesize];
	DWORD   nNumberOfBytesToRead = filesize;
	DWORD lpNumberOfBytesRead;
	BOOL bReadFile = ReadFile(hFile, buffer, nNumberOfBytesToRead, &lpNumberOfBytesRead, NULL);
	if (!bReadFile)
	{
		commonutilLogger->log(NORMAL, L"\nError in reading backup file %d\n", GetLastError());
		return 1;
	}
	HANDLE hCreateRestore = CreateFile(backup_path, GENERIC_WRITE | WRITE_OWNER | WRITE_DAC, 0, NULL, CREATE_ALWAYS, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (hCreateRestore == INVALID_HANDLE_VALUE)
	{
		commonutilLogger->log(NORMAL, L"\nError in creating restore file %ld\n", GetLastError());
		return 1;
	}
	SetFileAttributes(backup_path, file_attibutes);
	DWORD lpNumberOfBytesWritten;
	BOOL bWriteFile = BackupWrite(hCreateRestore, buffer, lpNumberOfBytesRead, &lpNumberOfBytesWritten, FALSE, TRUE, &lpContext);
	if (bWriteFile)
	{
		commonutilLogger->log(NORMAL, L"\nData has been totally written %ld.size of file is %ld bytes\n", nNumberOfBytesToRead, lpNumberOfBytesRead);
		BOOL bWriteFileTemp = BackupWrite(hCreateRestore, buffer, lpNumberOfBytesRead, &lpNumberOfBytesWritten, TRUE, TRUE, &lpContext);
		commonutilLogger->log(NORMAL, L"\n2.Data has been totally written %ld.size of file is %ld bytes\n", nNumberOfBytesToRead, lpNumberOfBytesRead);
		commonutilLogger->log(NORMAL, L"\nRestoration successfull\n");
	}
	else
	{
		commonutilLogger->log(NORMAL, L"\n %ld Error in reading data %ld\n", lpNumberOfBytesRead, lpNumberOfBytesWritten);
		commonutilLogger->log(NORMAL, L"\nError no is %ld\n", GetLastError());
		return 1;
	}
	return 0;
}


int restore_directory(wchar_t *sourcePath, WIN32_FIND_DATA lpFindFileData, wchar_t *destinationPath, wchar_t *tempPath)
{
	commonutilLogger->log(NORMAL, L"\nfile name %ls, type is %ld\n", lpFindFileData.cFileName, lpFindFileData.dwFileAttributes);
	wchar_t *dirpath = new wchar_t[300];
	int p = 0;
	dirpath = sourcePath;
	DWORD file_attributes = lpFindFileData.dwFileAttributes;
	if (dirpath[wcslen(dirpath) - 1] == '*')
		dirpath[wcslen(dirpath) - 1] = '\0';
	wchar_t *subDir = new wchar_t[200];
	wcscpy_s(subDir, 200, lpFindFileData.cFileName);
	commonutilLogger->log(NORMAL, L"\nSubdirectory %ls\n", subDir);
	size_t pathlen = wcslen(dirpath) + wcslen(lpFindFileData.cFileName) + 3;
	wcscat_s(dirpath, pathlen, lpFindFileData.cFileName);
	wcscat_s(dirpath, pathlen, L"\\*");
	commonutilLogger->log(NORMAL, L"\n%ls\n", dirpath);

	wchar_t *destPath = new wchar_t[500];
	destPath = destinationPath;
	wcscat_s(destPath, wcslen(destPath) + wcslen(lpFindFileData.cFileName) + 1, lpFindFileData.cFileName);
	wcscat_s(destPath, wcslen(destPath) + wcslen(lpFindFileData.cFileName) + 2, L"\\");
	commonutilLogger->log(NORMAL, L"\nrestore path is %ls\n", destPath);
	DWORD dwAttrib = GetFileAttributes(destPath);
	if (dwAttrib == INVALID_FILE_ATTRIBUTES)
	{
		BOOL result = CreateDirectory(destPath, NULL);
	}
	SetFileAttributes(destPath, file_attributes);
	commonutilLogger->log(NORMAL, L"\nDirectory path to get backup file is %ls\n", dirpath);
	HANDLE hSource;
	hSource = FindFirstFile(dirpath, &lpFindFileData);
	if (hSource == INVALID_HANDLE_VALUE)
	{
		commonutilLogger->log(NORMAL, L"\nInvalid backup directory or file\n");
		return 1;
	}
	//dirpath[wcslen(dirpath)-1]='\0';

	wcscpy_s(tempPath, 300, dirpath);
	restore_data(hSource, dirpath, destPath, lpFindFileData, tempPath);
	commonutilLogger->log(NORMAL, L"\nReturned from sub directory\n");
	int cutLen = wcslen(destPath) - wcslen(subDir);
	commonutilLogger->log(NORMAL, L"\n%ls\n", subDir);
	destPath[cutLen - 1] = '\0';
	wprintf(destPath);

	commonutilLogger->log(NORMAL, L"\n%ls\n", subDir);
	if (dirpath[wcslen(dirpath) - 1] == '*')
		dirpath[wcslen(dirpath) - 1] = '\0';
	cutLen = wcslen(dirpath) - wcslen(subDir);
	dirpath[cutLen - 1] = '\0';
	wprintf(dirpath);
	wcscpy_s(tempPath, 300, dirpath);
	return 0;
}

int restore_data(HANDLE hFile, wchar_t *sourcePath, wchar_t *destinationPath, WIN32_FIND_DATA lpFindFileData, wchar_t *tempPath)
{
	do
	{
		if (!wcscmp(lpFindFileData.cFileName, L"."))
		{

		}
		else if (!wcscmp(lpFindFileData.cFileName, L".."))
		{

		}
		else if (!wcscmp(lpFindFileData.cFileName, L"$RECYCLE.BIN"))
		{
		}
		else if (!wcscmp(lpFindFileData.cFileName, L"$Recycle.Bin"))
		{
		}
		else
		{
			wchar_t *dirpath = new wchar_t[300];
			int p = 0;
			dirpath = sourcePath;
			if (lpFindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
				//sourcePath[wcslen(sourcePath)-1]='\0';
				restore_directory(sourcePath, lpFindFileData, destinationPath, tempPath);
			}
			else
			{
				int result = restore_file(dirpath, lpFindFileData, destinationPath, tempPath);
				if (result == 1)
				{
					commonutilLogger->log(NORMAL, L"\nError %ld \n", GetLastError());
					return 1;
				}


			}
		}
	} while (FindNextFile(hFile, &lpFindFileData));
	return 0;
}

int restore_data_disk_restore(HANDLE hFile, wchar_t *sourcePath, wchar_t *destinationPath, WIN32_FIND_DATA lpFindFileData, wchar_t *tempPath)
{
	do
	{
		if ((wcsstr(lpFindFileData.cFileName, L".vhd") == NULL) && (wcsstr(lpFindFileData.cFileName, L".avhd") == NULL))
		{
			commonutilLogger->log(NORMAL, L"CommonUtil.cpp restore_data isDiskrestore true Filename -> %ws : Not a VHD. Continuing...\n", lpFindFileData.cFileName);
			continue;
		}
		
		if (!wcscmp(lpFindFileData.cFileName, L"."))
		{

		}
		else if (!wcscmp(lpFindFileData.cFileName, L".."))
		{

		}
		else if (!wcscmp(lpFindFileData.cFileName, L"$RECYCLE.BIN"))
		{
		}
		else if (!wcscmp(lpFindFileData.cFileName, L"$Recycle.Bin"))
		{
		}
		else
		{
			wchar_t *dirpath = new wchar_t[300];
			int p = 0;
			dirpath = sourcePath;
			if (lpFindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
				//sourcePath[wcslen(sourcePath)-1]='\0';
				restore_directory(sourcePath, lpFindFileData, destinationPath, tempPath);
			}
			else
			{
				int result = restore_file(dirpath, lpFindFileData, destinationPath, tempPath);
				if (result == 1)
				{
					commonutilLogger->log(NORMAL, L"\nError %ld \n", GetLastError());
					return 1;
				}


			}
		}
	} while (FindNextFile(hFile, &lpFindFileData));
	return 0;
}

int restore_data_initialization(wchar_t *path, wchar_t *destinyPath, bool isDiskRestore)
{
	WIN32_FIND_DATA lpFindFileData;
	wchar_t *sourcePath = new wchar_t[300];
	wchar_t *destinationPath = new wchar_t[300];
	wcscpy_s(sourcePath, 300, path);
	wcscpy_s(destinationPath, 300, destinyPath);
	int result = create_restore_directory(destinationPath);
	if (result == 1)
	{
		commonutilLogger->log(NORMAL, L"\nError in creating destination directory.It already exists\n");
	}
	DWORD file_type = restore_file_exists(sourcePath);
	if (file_type == INVALID_FILE_ATTRIBUTES)
	{
		commonutilLogger->log(NORMAL, L"\nSource path is invalid\n");
		return 1;
	}
	if (file_type == FILE_ATTRIBUTE_DIRECTORY)
		wcscat_s(sourcePath, wcslen(sourcePath) + 3, L"\\*");
	HANDLE hFile = FindFirstFile(sourcePath, &lpFindFileData);
	//sourcePath[wcslen(sourcePath)-1]='\0';
	wchar_t *temp_path_for_source = new wchar_t[300];
	wcscpy_s(temp_path_for_source, 300, sourcePath);
	if(isDiskRestore)
	{
		result = restore_data_disk_restore(hFile, sourcePath, destinationPath, lpFindFileData, temp_path_for_source);
	}
	else
	{
		result = restore_data(hFile, sourcePath, destinationPath, lpFindFileData, temp_path_for_source);
	}
	if (result == 0)
		commonutilLogger->log(NORMAL, L"\nRestore successfull\n");
	else
	{
		commonutilLogger->log(NORMAL, L"\nRestore Unsuccessfull\n");
		return 1;
	}
	return 0;
}



int checkCredentials(LPWSTR location, LPWSTR userName, LPWSTR password, LPWSTR connectDisconnect)
{
	//std::map<char, int> properties;

	if(wcscmp(userName,L"-")==0)
	{
		commonutilLogger->log(NORMAL, L"checkCredentials No authentication required\n");
		return -99;
	}
	
	DWORD dwRetVal;
	int retValInt;
	if (wcscmp(connectDisconnect, L"connect") == 0)
	{
		commonutilLogger->log(NORMAL, L"Connecting to repository -> %ws\n",location);
		NETRESOURCE nr;
		DWORD dwFlags;

		memset(&nr, 0, sizeof (NETRESOURCE));

		nr.dwType = RESOURCETYPE_ANY;
		nr.lpRemoteName = location;
		nr.lpProvider = NULL;
		dwFlags = CONNECT_TEMPORARY;

		dwRetVal = WNetAddConnection2(&nr, password, userName, dwFlags);
		if (dwRetVal == NO_ERROR)
		{
			commonutilLogger->log(NORMAL, L"Repository connection succeeded without error!\n");
			retValInt = -99;		
		}
		else if (dwRetVal == 5)
		{
			retValInt = (int)dwRetVal;	
			commonutilLogger->log(NORMAL, L"checkCredentials WNetAddConnection2 Return value -> %d\n",retValInt);		
		}
		else if (dwRetVal == 53)
		{
			retValInt = (int)dwRetVal;		
			commonutilLogger->log(NORMAL, L"checkCredentials WNetAddConnection2 Return value -> %d\n",retValInt);		
		}
		else if (dwRetVal == 67)
		{
			retValInt = (int)dwRetVal;
			commonutilLogger->log(NORMAL, L"checkCredentials WNetAddConnection2 Return value -> %d\n",retValInt);	
		}
		else if (dwRetVal == 86)
		{
			retValInt = (int)dwRetVal;
			commonutilLogger->log(NORMAL, L"checkCredentials WNetAddConnection2 Return value -> %d\n",retValInt);	
		}
		else if (dwRetVal == 1203)
		{
			retValInt = (int)dwRetVal;
			commonutilLogger->log(NORMAL, L"checkCredentials WNetAddConnection2 Return value -> %d\n",retValInt);	
		}
		else if (dwRetVal == 1326)
		{
			retValInt = (int)dwRetVal;
			commonutilLogger->log(NORMAL, L"checkCredentials WNetAddConnection2 Return value -> %d\n",retValInt);	
		}
		else if (dwRetVal == 2202)
		{
			retValInt = (int)dwRetVal;
			commonutilLogger->log(NORMAL, L"checkCredentials WNetAddConnection2 Return value -> %d\n",retValInt);	
		}
		else if (dwRetVal == 1219)
		{
			commonutilLogger->log(NORMAL, L"Connect Actual Return value -> %d\n",dwRetVal);
			retValInt = -99;			
		}
		else
		{
			commonutilLogger->log(NORMAL, L"Repository connection else part. Return value -> %d!",retValInt);
			retValInt = (int)dwRetVal;
		}
		commonutilLogger->log(NORMAL, L"Connect Return value -> %d\n",retValInt);
	}
	else
	{
		dwRetVal = WNetCancelConnection2(location, 0, TRUE);
		retValInt = (int)dwRetVal;
		commonutilLogger->log(NORMAL, L"DisConnect Return value -> %d\n",retValInt);
	}
	return retValInt;
}

bool CompressFileDirectly(BSTR filePathinsnapshot, BSTR backupFolderpath, BSTR backupName, BSTR vmId, Loggerclass *fileCopylogger, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *))
{
	fileCopylogger->log(NORMAL, L"CompressFileDirectly CommonUtil.cpp Input File -> %ws\n", filePathinsnapshot);
	fileCopylogger->log(NORMAL, L"CompressFileDirectly CommonUtil.cpp Destination File -> %ws\n", backupFolderpath);
	
	size_t bufSize;
	_bstr_t stepId, value, executionTime;	
	time_t starttime = time (NULL);
	time_t endtime;
	BYTE *buf;
	DWORD higherBytes;
	bufSize = 16777216;
	buf = new BYTE[bufSize];
	HANDLE VHDpathwheredatatobereadHandle = CreateFile(filePathinsnapshot, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (VHDpathwheredatatobereadHandle == INVALID_HANDLE_VALUE)
	{
		DWORD error = GetLastError();
		fileCopylogger->log(NORMAL, L"CompressFile -> Issue with gzwrite. Error: %d\n", error);
		fileCopylogger->log(NORMAL, L"Handle failed for VHD file.File not found\n");
		return false;
	}
	DWORD lowerBytes = GetFileSize(VHDpathwheredatatobereadHandle, &higherBytes);
	long long filesize = (((long long) higherBytes) << 32) | lowerBytes;
	_bstr_t fileSize = (long long)filesize;
	fileCopylogger->log(NORMAL, L"Total File Size : %lld\n", fileSize);	
	BSTR type = SysAllocStringLen(L"", 16);
	wcscpy(type, L"MaximumRead");
	long long stepid = (*callBackMethod)(L"BACKUP", L"", backupName, vmId, filePathinsnapshot, type, fileSize, L"");
	stepId = (long long)stepid;
	int compressedFiletemp = _wopen(backupFolderpath, _O_CREAT|_O_WRONLY|_O_BINARY);
	if(compressedFiletemp==-1){
		fileCopylogger->log(NORMAL, L"CompressFileDirectly compressedFiletemp is NULL\n");
		CloseHandle(VHDpathwheredatatobereadHandle);
		if (buf != nullptr){ delete[](buf); }
		return false;
	}


	gzFile compressedFile = gzdopen(compressedFiletemp, "wb");

	if(!compressedFile){
		fileCopylogger->log(NORMAL, L"CompressFileDirectly gzdopen compressedFile is NULL\n");
		CloseHandle(VHDpathwheredatatobereadHandle);
		if (buf != nullptr){ delete[](buf); }
		return false;
	}
	long long read = 0;
	long long percent = 10;	
	wcscpy(type, L"CurrentRead");
	while (1)
	{		
		//fileCopylogger->log(NORMAL, L"CompressFile -> compress going on...\n");
		DWORD lpNumberOfBytesRead;		
		BOOL bReadFile = ReadFile(VHDpathwheredatatobereadHandle, buf, bufSize, &lpNumberOfBytesRead, NULL);	
		if (!bReadFile)
		{
			DWORD error = GetLastError();
			fileCopylogger->log(NORMAL, L"CompressFile -> Issue with fread. Error: %d\n", error);
			if (buf != nullptr){ delete[](buf); }
			if (compressedFile){ gzclose(compressedFile); }
			CloseHandle(VHDpathwheredatatobereadHandle);
			return false;
		}
		if (lpNumberOfBytesRead == 0) //TODO have to control loop iterations based on filesize/bufSize
		{
			wcscpy(type, L"ReadCompleted");
			value = (long long)read; 
			endtime = time (NULL);
                        executionTime = (long long)(endtime - starttime);
			(*callBackMethod)(L"BACKUP", stepId, backupName, vmId, filePathinsnapshot, type, value, executionTime);	
			fileCopylogger->log(NORMAL, L"CompressFile -> end of file reached. \n");
			fileCopylogger->log(NORMAL, L"CompressFile -> Total read file size : %lld\n",read);
			break;
		}
		//buf contains len bytes of decompressed data
		DWORD nWrote;
		nWrote = gzwrite(compressedFile, buf, lpNumberOfBytesRead);
		read += nWrote;
		value = (long long)read;
		if(read%percent == 0){
			(*callBackMethod)(L"BACKUP", stepId, backupName, vmId, filePathinsnapshot, type, value, L"");
			//fileCopylogger->log(NORMAL, L"CompressFile -> current Read of file : %lld\n",read);
		}
		if (nWrote<=0)
		{
			DWORD error = GetLastError();
			fileCopylogger->log(NORMAL, L"CompressFile -> Issue with gzwrite. Error: %d\n", error);
			if (buf != nullptr){ delete[](buf); }
			if (compressedFile){ gzclose(compressedFile); }
			CloseHandle(VHDpathwheredatatobereadHandle);
			return false;
		}
	}	
	if (buf != nullptr){ delete[](buf); }
	if (compressedFile){ gzclose(compressedFile); }
	CloseHandle(VHDpathwheredatatobereadHandle);
	fileCopylogger->log(NORMAL, L"File compression finished successfully!\n");;
    commonutilLogger->log(NORMAL, L"Creating an idx file for this (a)vhd(x)...");
    indexCreation(backupFolderpath, false, L"", commonutilLogger);
    commonutilLogger->log(NORMAL, L"Returning back after compression and idx file generation...");
	return true;
}


bool DecompressFileDirectly(BSTR filePathinsnapshot, BSTR backupFolderpath, BSTR restoreId, BSTR vmId, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *))
{
	commonutilLogger->log(NORMAL, L"DecompressFileDirectly CommonUtil.cpp Decompressed File -> %ws\n", filePathinsnapshot);
	commonutilLogger->log(NORMAL, L"DecompressFileDirectly CommonUtil.cpp Destination File -> %ws\n", backupFolderpath);

	_bstr_t stepId, value, executionTime;
	time_t starttime = time (NULL);
	time_t endtime;
	DWORD higherBytes;
	size_t bufSize;
	BYTE *buf;
	bufSize = 16777216;
	buf = new BYTE[bufSize];
	DWORD bytesread;
	long long read = 0;
	LARGE_INTEGER loffSet, filePointer;
	int itr  = -1;
	HANDLE VHDpathwheredatatobewrittenHandle = CreateFile(backupFolderpath, GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (VHDpathwheredatatobewrittenHandle == INVALID_HANDLE_VALUE)
	{
		commonutilLogger->log(NORMAL, L"CommonUtil.cpp DecompressFileDirectly INVALID HANDLE VALUE...\n");
		return false;
	}

	int backedupFiletemp = _wopen(filePathinsnapshot, _O_RDONLY|_O_BINARY);
	if(backedupFiletemp==-1){
		commonutilLogger->log(NORMAL, L"CommonUtil.cpp DecompressFileDirectly compressedFiletemp is NULL\n");
		CloseHandle(VHDpathwheredatatobewrittenHandle);
		if (buf != nullptr){ delete[](buf); }
		return false;
	}

    wstring indexFilepath = filePathinsnapshot;
    indexFilepath = indexFilepath.substr(0, indexFilepath.rfind(L".")) + L".idx";
    wchar_t *windexFilepath = new wchar_t[indexFilepath.length() + 1];
    wcscpy(windexFilepath, indexFilepath.c_str());
    wcscat(windexFilepath, L"\0");
//    commonutilLogger->log(NORMAL, L"DecompressFileDirectly Index File : %ws\n",windexFilepath);
    if (!PathFileExists(windexFilepath)){
        commonutilLogger->log(NORMAL, L"CommonUtil.cpp DecompressFileDirectly Index File Not available, Index Creation started...\n");
        int indexCreationResult = indexCreation(filePathinsnapshot, false, L"", commonutilLogger);
        commonutilLogger->log(NORMAL, L"CommonUtil.cpp DecompressFileDirectly Index Creation result : %d.\n",indexCreationResult);
    }
    commonutilLogger->log(NORMAL, L"CommonUtil.cpp DecompressFileDirectly getting index of compressed file...\n");
    struct access *index = getIndexforFile(index, windexFilepath, commonutilLogger);
    FILE *backedupFile = fdopen(backedupFiletemp, "rb");

	if(!backedupFile){
		commonutilLogger->log(NORMAL, L"CommonUtil.cpp DecompressFileDirectly fdopen compressedFile is NULL\n");
		CloseHandle(VHDpathwheredatatobewrittenHandle);
		if (buf != nullptr){ delete[](buf); }
		return false;
	}


	BSTR type = SysAllocStringLen(L"", 16);
	wcscpy(type, L"MaximumRead");
	long long stepid = (*callBackMethod)(L"RESTORE", L"", restoreId, vmId, filePathinsnapshot, type, L"-1", L"");
	//commonutilLogger->log(NORMAL, L"Total File Size Restore : %lld\n", fileSize);
	stepId = (long long)stepid;

	wcscpy(type, L"CurrentRead");
	while (1)
	{
		bytesread = extract(backedupFile, index, read, buf, bufSize);
		itr++;
		if((int)bytesread > 0)
		{
            DWORD lpNumberOfBytesWritten;
            BOOL writeresult = WriteFile(VHDpathwheredatatobewrittenHandle, buf, bytesread, &lpNumberOfBytesWritten, NULL);
            if (!writeresult)
            {
                commonutilLogger->log(NORMAL, L"CommonUtil.cpp DecompressFile -> Issue with fwrite. Error: %d : %d : %lld\n", GetLastError(), bytesread, read);
                read += bufSize;
                loffSet.QuadPart = read;
                BOOL isFilePointermoved = SetFilePointerEx(VHDpathwheredatatobewrittenHandle, loffSet, &filePointer, FILE_BEGIN);
                if (!isFilePointermoved) {
                    commonutilLogger->log(NORMAL, L"CommonUtil.cpp SetFilePointerEx Error :%d\n", GetLastError());
                }else {
                    commonutilLogger->log(NORMAL, L"CommonUtil.cpp SetFilePointerEx success \n");
                    continue;
                }
                if (buf != nullptr){ delete[](buf); }
                if (backedupFile){ fclose(backedupFile); }
                CloseHandle(VHDpathwheredatatobewrittenHandle);
                return false;
            }
            //read +=bytesread;
            value = (long long)(read + bytesread);
            (*callBackMethod)(L"RESTORE", stepId, restoreId, vmId, filePathinsnapshot, type, value, L"");
            if( bytesread < bufSize && !feof(backedupFile)) {
                commonutilLogger->log(NORMAL, L"CommonUtil.cpp buf read is less then buf size but not end of file..%d : %lld : %d : %d\n",GetLastError(), read, itr, bytesread);
                loffSet.QuadPart = bufSize - bytesread;
            }else{
                read += bytesread;
                continue;
            }
		}else if(feof(backedupFile)) {
			wcscpy(type, L"ReadCompleted");
			value = (long long)read;
			endtime = time (NULL);
            executionTime = (long long)(endtime - starttime);
			(*callBackMethod)(L"RESTORE", stepId, restoreId, vmId, filePathinsnapshot, type, value, executionTime);
			commonutilLogger->log(NORMAL, L"CommonUtil.cpp DecompressFile -> current Read of file : %lld\n",read);
			commonutilLogger->log(NORMAL, L"CommonUtil.cpp buf read equal zero...\n");
			break;
		}else {
		    DWORD error = GetLastError();
		    if((int)bytesread < 0) {
                commonutilLogger->log(NORMAL, L"CommonUtil.cpp Issue while read from source file. Error: %d : %lld : %d : %d\n", error, read, itr, (int)bytesread);
		    }else if((int)bytesread == 0 && !feof(backedupFile)) {
                commonutilLogger->log(NORMAL, L"CommonUtil.cpp buf read equal zero but size is not met..%d : %lld : %d\n", error, read, itr);
		    }
            loffSet.QuadPart = bufSize;
		}
		read += bufSize;
        BOOL isFilePointermoved = SetFilePointerEx(VHDpathwheredatatobewrittenHandle, loffSet, &filePointer, FILE_CURRENT);
        commonutilLogger->log(NORMAL, L"CommonUtil.cpp %d\n", GetLastError());
        if (!isFilePointermoved) {
            commonutilLogger->log(NORMAL, L"CommonUtil.cpp SetFilePointerEx Error :%d\n", GetLastError());
        }else {
            commonutilLogger->log(NORMAL, L"CommonUtil.cpp SetFilePointerEx success %d \n", GetLastError());
            continue;
        }
		if (buf != nullptr){ delete[](buf); }
		if (backedupFile){ fclose(backedupFile); }
		CloseHandle(VHDpathwheredatatobewrittenHandle);
		return false;
    }
	if (buf != nullptr){ delete[](buf); }
	if (backedupFile){ fclose(backedupFile); }
	CloseHandle(VHDpathwheredatatobewrittenHandle);

	commonutilLogger->log(NORMAL, L"CommonUtil.cpp File decompression finished successfully! \n");
	return true;
}

