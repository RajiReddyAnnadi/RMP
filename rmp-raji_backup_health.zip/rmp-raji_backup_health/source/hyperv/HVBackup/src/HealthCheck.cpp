#pragma once
#include "HealthCheck.h"
#include <BuildIndex.h>
#include <fcntl.h>

Loggerclass *healthcheckLogger;
void initializeHealthCheckvariables(Loggerclass *healthcheckLoggerclass)
{
	healthcheckLogger = healthcheckLoggerclass;
}

int generateHashforFile(wchar_t* sourceFilePath, wchar_t* destFilePath, wchar_t* backupIdentifier, wchar_t* hashType, wchar_t* isSingleHash, wchar_t* mode, wchar_t* fileType)
{
	healthcheckLogger->log(NORMAL, L"HealthCheck.cpp generateHashForFile started for File->%ws...\n",sourceFilePath);
	DWORD bytesread = 0, tRead = 0, cbHash = 0;
	DWORD64 itr = 0, bufSizetoHash = BUFSIZETOHASH;
    HCRYPTPROV hProv = 0;
    HCRYPTHASH hHash = 0;
    HANDLE hFile = NULL;
    BYTE * buffer;
    buffer = new BYTE[BUFSIZE];
    BYTE rgbHash[MD5LEN];
    CHAR rgbDigits[] = "0123456789abcdef";
    BOOL readResult = FALSE;

    wchar_t* wtextSource = new wchar_t[wcslen(sourceFilePath) + 1];
    wcscpy(wtextSource, sourceFilePath);
    wcscat(wtextSource, L"\0");
    LPCWSTR LsourceFile = wtextSource;

    LPTSTR DestFile;
    if(wcscmp(isSingleHash, L"True") == 0) {
        wchar_t* wtextDest = new wchar_t[wcslen(destFilePath) + wcslen(hashType) +  wcslen(L"_single_") + wcslen(backupIdentifier) + wcslen(L".txt") + 2];
        wcscpy(wtextDest, destFilePath);
        wcscat(wtextDest, L"\\");
        wcscat(wtextDest, hashType);
        wcscat(wtextDest, L"_single_");
        wcscat(wtextDest, backupIdentifier);
        wcscat(wtextDest, L".txt");
        wcscat(wtextDest, L"\0");
        DestFile = wtextDest;
	}else {
	    wchar_t* wtextDest = new wchar_t[wcslen(destFilePath) + wcslen(hashType) + wcslen(backupIdentifier) +  wcslen(L".txt") + 3];
    	wcscpy(wtextDest, destFilePath);
    	wcscat(wtextDest, L"_");
    	wcscat(wtextDest, hashType);
    	wcscat(wtextDest, L"_");
    	wcscat(wtextDest, backupIdentifier);
    	wcscat(wtextDest, L".txt");
    	wcscat(wtextDest, L"\0");
    	DestFile = wtextDest;
	}

    wofstream hashFile;
    if(wcscmp(mode, L"a") == 0) {
        hashFile.open(DestFile, ios::app);
    }else {
        hashFile.open(DestFile);
    }
	hashFile.imbue(locale(locale(), new codecvt_utf8_utf16<wchar_t, 0x10ffff, codecvt_mode(consume_header | generate_header)>));

    hFile = CreateFile(LsourceFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	if (INVALID_HANDLE_VALUE == hFile) {
		healthcheckLogger->log(NORMAL, L"HealthCheck.cpp  Opening file Error: %d\n", GetLastError());
		return 458;
	}
	if(wcscmp(isSingleHash, L"True") == 0) {
	    ULARGE_INTEGER fileSize;
        DWORD error;
        fileSize.LowPart = GetFileSize(hFile, &fileSize.HighPart);
        if (fileSize.LowPart == INVALID_SET_FILE_POINTER && (error = GetLastError()) != ERROR_SUCCESS) {
            bufSizetoHash = 0; //If not able to get fileSize set bufSizetoHash as a fileSize. this case also it works fine.
        }else {
            bufSizetoHash = fileSize.QuadPart; //For single hash of a file set bufSizetoHash as a fileSize.
        }
	}
	//CloseHandle(hFile);
    // Get handle to the crypto provider
	if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
        if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
                while(1) {
                    readResult = ReadFile(hFile, buffer, BUFSIZE, &bytesread, NULL);
                    if(readResult) {
                        tRead += bytesread;
                        if (bytesread == 0 && tRead == 0) {
                            break;
                        }else {
                            if (CryptHashData(hHash, buffer, bytesread, 0)) {
                                if (tRead == bufSizetoHash || bytesread < BUFSIZE) {
                                    tRead = 0;
                                    cbHash = MD5LEN;
                                    if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0)) {
                                        if((wcscmp(mode, L"a") == 0) && (wcscmp(isSingleHash, L"True") == 0)) {
                                            if(wcscmp(mode, L"-") == 0){
                                                hashFile << wtextSource << L"\t";
                                            }else{
                                                hashFile << wtextSource << L"\t" << fileType << L"\t";
                                            }
                                        }else {
                                            hashFile << itr * bufSizetoHash << L"\t";
                                        }
                                        for (DWORD i = 0; i < cbHash; i++)
                                        {
                                            hashFile << (rgbDigits[rgbHash[i] >> 4]) << rgbDigits[rgbHash[i] & 0xf];
                                        }
                                        hashFile << L"\t";
                                    }
                                    else {
                                        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptGetHashParam failed Error: %d\n", GetLastError());
                                        if(hHash){
                                            CryptDestroyHash(hHash);
                                        }
                                        if(hProv) {
                                            CryptReleaseContext(hProv, 0);
                                        }
                                        if(hFile) {
                                            CloseHandle(hFile);
                                        }
                                        if (hashFile) {
                                            hashFile.close();
                                        }
                                        return 457;
                                    }
                                    if(hHash){
                                        CryptDestroyHash(hHash);
                                    }
                                    if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
                                        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash failed Error: %d\n", GetLastError());
                                        if(hProv) {
                                            CryptReleaseContext(hProv, 0);
                                        }
                                        if(hFile) {
                                            CloseHandle(hFile);
                                        }
                                        if (hashFile) {
                                            hashFile.close();
                                        }
                                        return 457;
                                    }
                                    itr++;
                                }
                            }else {
                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptHashData failed Error: %d\n", GetLastError());
                                if(hHash){
                                    CryptDestroyHash(hHash);
                                }
                                if(hProv) {
                                    CryptReleaseContext(hProv, 0);
                                }
                                if(hFile) {
                                    CloseHandle(hFile);
                                }
                                if (hashFile) {
                                    hashFile.close();
                                }
                                return 457;
                            }
                        }
                    }else {
                        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Reading Backup File failed Error: %d\n", GetLastError());
                        if(hHash){
                            CryptDestroyHash(hHash);
                        }
                        if(hProv) {
                            CryptReleaseContext(hProv, 0);
                        }
                        if(hFile) {
                            CloseHandle(hFile);
                        }
                        if (hashFile) {
                            hashFile.close();
                        }
                        return 459;
                    }
                }
                if(hHash){
                    CryptDestroyHash(hHash);
                }
                if(hProv) {
                    CryptReleaseContext(hProv, 0);
                }
        }else {
            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash failed Error: %d\n", GetLastError());
            if(hProv) {
            	CryptReleaseContext(hProv, 0);
            }
            if(hFile) {
                CloseHandle(hFile);
            }
        	if (hashFile) {
        	    hashFile.close();
        	}
            return 457;
        }
	}else {
		healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptAcquireContext failed Error: %d\n", GetLastError());
        if(hFile) {
            CloseHandle(hFile);
        }
        if (hashFile) {
            hashFile.close();
        }
		return 457;
	}
	if(hFile) {
	    CloseHandle(hFile);
	}
    hashFile.close();
	healthcheckLogger->log(NORMAL, L"HealthCheck.cpp generateHashForFile Ended...\n");
	return 0;
}

int generateSingleHashandBloackbyBlockHashforFile(wchar_t* destFileDir, wchar_t* sourceFilePath, wchar_t* destFilePath, wchar_t* backupIdentifier, wchar_t* isEncrypted, wchar_t* encryptPassword, wchar_t* hashType, wchar_t* fileType)
{
	healthcheckLogger->log(NORMAL, L"HealthCheck.cpp generateSingleHashandBloackbyBlockHashforFile started for file->%ws...\n",sourceFilePath);
	DWORD bytesread = 0, tRead = 0, cbHash = 0;
	DWORD64 itr = 0;
    HCRYPTPROV hProv = 0;
    HCRYPTHASH hHash = 0;
    HCRYPTHASH hHashNew = 0;
    FILE* hashFile;
    FILE* sourceFile;
    BYTE *buffer;
    //gzFile sourceFile;
    struct access *index = NULL;
    int isfileopened = 0;
    buffer= new BYTE[BUFSIZE];
    BYTE rgbHash[MD5LEN];
    CHAR rgbDigits[] = "0123456789abcdef";
    LONGLONG offset = 0;

    wchar_t* wtextSource = new wchar_t[wcslen(sourceFilePath) + 1];
    wcscpy(wtextSource, sourceFilePath);
    wcscat(wtextSource, L"\0");
    LPCWSTR LsourceFile = wtextSource;

	wchar_t* wtextDest = new wchar_t[wcslen(destFilePath) + wcslen(hashType) + wcslen(backupIdentifier) + wcslen(L".txt") + 3];
	wcscpy(wtextDest, destFilePath);
	wcscat(wtextDest, L"_");
	wcscat(wtextDest, hashType);
	wcscat(wtextDest, L"_");
	wcscat(wtextDest, backupIdentifier);
	wcscat(wtextDest, L".txt");
	wcscat(wtextDest, L"\0");
	LPTSTR DestFile = wtextDest;

    wchar_t* wtextDestofSingleHash = new wchar_t[wcslen(destFileDir) + wcslen(hashType) +  wcslen(L"_single_") + wcslen(backupIdentifier) + wcslen(L".txt") + 2];
    wcscpy(wtextDestofSingleHash, destFileDir);
    wcscat(wtextDestofSingleHash, L"\\");
    wcscat(wtextDestofSingleHash, hashType);
    wcscat(wtextDestofSingleHash, L"_single_");
    wcscat(wtextDestofSingleHash, backupIdentifier);
    wcscat(wtextDestofSingleHash, L".txt");
    wcscat(wtextDestofSingleHash, L"\0");
    LPTSTR DestFileofSingleHash = wtextDestofSingleHash;

    wchar_t* wtextindexFile = new wchar_t[wcslen(destFilePath)+ wcslen(L".idx") + 1];
    wcscpy(wtextindexFile, destFilePath);
    wcscat(wtextindexFile, L".idx");
    wcscat(wtextindexFile, L"\0");

    if (!PathFileExists(wtextindexFile)){
        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp generateSingleHashandBloackbyBlockHashforFile Index File Not available, Index Creation started...\n");
        int indexCreationResult;
        if(wcscmp(isEncrypted, L"true") == 0) {
            indexCreationResult = indexCreation(sourceFilePath, true, encryptPassword, healthcheckLogger);
        }else {
            indexCreationResult = indexCreation(sourceFilePath, false, L"", healthcheckLogger);
        }
        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp generateSingleHashandBloackbyBlockHashforFile Index Creation result : %d.\n",indexCreationResult);
    }
    _wfopen_s(&hashFile, DestFile, L"w");

    // Get handle to the crypto provider
	if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
        if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
            if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHashNew)) {
                int sourceFiletemp = _wopen(LsourceFile, _O_RDONLY | _O_BINARY);
                if (sourceFiletemp != -1) {
                        index = getIndexforFile(index, wtextindexFile, healthcheckLogger);
                        sourceFile = _fdopen(sourceFiletemp, "rb");
                    if(sourceFile != NULL) {
                        while(1) {
                            if(wcscmp(isEncrypted, L"true") == 0) {
                                bytesread = extractDecrypt(sourceFile, index, offset, buffer, BUFSIZE, encryptPassword);
                            }else{
                                bytesread = extract(sourceFile, index, offset, buffer, BUFSIZE);
                            }
                            offset += BUFSIZE;
                            if (bytesread == 0 && tRead == 0 && feof(sourceFile) || ((int)bytesread < 0 && feof(sourceFile))) {
                                break;
                            }else if((int)bytesread >= 0) {
                                tRead += bytesread;
                                if (CryptHashData(hHash, buffer, bytesread, 0)) {
                                    if (CryptHashData(hHashNew, buffer, bytesread, 0)) {
                                        if (tRead == BUFSIZETOHASH || bytesread < BUFSIZE) {
                                            tRead = 0;
                                            cbHash = MD5LEN;
                                            if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0)) {
                                                    fwprintf_s(hashFile, L"%lld\t", itr * BUFSIZETOHASH);
                                                for (DWORD i = 0; i < cbHash; i++)
                                                {
                                                    fwprintf_s(hashFile, L"%c%c", rgbDigits[rgbHash[i] >> 4], rgbDigits[rgbHash[i] & 0xf]);
                                                }
                                                fwprintf(hashFile ,L"\t");
                                            }
                                            else {
                                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptGetHashParam failed Error: %d\n", GetLastError());
                                                if(sourceFile) {
                                                    fclose(sourceFile);
                                                }
                                                if(hHashNew){
                                                    CryptDestroyHash(hHashNew);
                                                }
                                                if(hHash){
                                                    CryptDestroyHash(hHash);
                                                }
                                                if(hProv) {
                                                    CryptReleaseContext(hProv, 0);
                                                }
                                                if (hashFile) {
                                                    fclose(hashFile);
                                                }
                                                return 457;
                                            }
                                            if(hHash){
                                                CryptDestroyHash(hHash);
                                            }
                                            if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
                                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash failed Error: %d\n", GetLastError());
                                                if(sourceFile) {
                                                    fclose(sourceFile);
                                                }
                                                if(hHashNew){
                                                    CryptDestroyHash(hHashNew);
                                                }
                                                if(hProv) {
                                                    CryptReleaseContext(hProv, 0);
                                                }
                                                if (hashFile) {
                                                    fclose(hashFile);
                                                }
                                                return 457;
                                            }
                                            itr++;
                                        }
                                        continue;
                                    }
                                }
                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptHashData failed Error: %d\n", GetLastError());
                                    if(sourceFile) {
                                        fclose(sourceFile);
                                    }
                                    if(hHashNew){
                                        CryptDestroyHash(hHashNew);
                                    }
                                    if(hHash){
                                        CryptDestroyHash(hHash);
                                    }
                                    if(hProv) {
                                        CryptReleaseContext(hProv, 0);
                                    }
                                    if (hashFile) {
                                        fclose(hashFile);
                                    }
                                    return 457;
                            }else {
                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Reading Backup File failed Error: %d\n", GetLastError());
                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Failed at offset : %lld : %lld\n", itr * BUFSIZETOHASH, offset);
                                tRead = 0;
                                fwprintf_s(hashFile, L"%lld\t%ws\t", itr * BUFSIZETOHASH, L"00000000000000000000000000000000");
                                itr++;
                                continue;
                            }
                        }
                        cbHash = MD5LEN;
                        if (CryptGetHashParam(hHashNew, HP_HASHVAL, rgbHash, &cbHash, 0)) {
                            wofstream hashFileSingle(DestFileofSingleHash, ios::app);
                            hashFileSingle.imbue(locale(locale(), new codecvt_utf8_utf16<wchar_t, 0x10ffff, codecvt_mode(consume_header | generate_header)>));
                            hashFileSingle << wtextSource << L"\t" << fileType << L"\t";
                            for (DWORD i = 0; i < cbHash; i++)
                            {
                                hashFileSingle << (rgbDigits[rgbHash[i] >> 4]) << rgbDigits[rgbHash[i] & 0xf];
                            }
                            hashFileSingle << L"\t";
                            hashFileSingle.close();
                        }
                        else {
                            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptGetHashParam failed Error: %d\n", GetLastError());
                            if(sourceFile) {
                                fclose(sourceFile);
                            }
                            if(hHashNew){
                                CryptDestroyHash(hHashNew);
                            }
                            if(hHash){
                                CryptDestroyHash(hHash);
                            }
                            if(hProv) {
                                CryptReleaseContext(hProv, 0);
                            }
                            if(hashFile) {
                                fclose(hashFile);
                            }
                            return 457;
                        }
                        if(sourceFile) {
                            fclose(sourceFile);
                        }
                        if(hHashNew){
                            CryptDestroyHash(hHashNew);
                        }
                        if(hHash){
                            CryptDestroyHash(hHash);
                        }
                        if(hProv) {
                            CryptReleaseContext(hProv, 0);
                        }
                    }else {
                        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp unable open file. Error: %d\n", GetLastError());
                        if(hHashNew){
                            CryptDestroyHash(hHashNew);
                        }
                        if(hHash){
                           CryptDestroyHash(hHash);
                        }
                        if(hProv) {
                            CryptReleaseContext(hProv, 0);
                        }
                        if (hashFile) {
                            fclose(hashFile);
                        }
                        return 458;
                    }
                }else {
                    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp SourceFileTemp NULL: \n");
                    if(hHashNew){
                        CryptDestroyHash(hHashNew);
                    }
                    if(hHash){
                       CryptDestroyHash(hHash);
                    }
                    if(hProv) {
                        CryptReleaseContext(hProv, 0);
                    }
                    if (hashFile) {
                        fclose(hashFile);
                    }
                    return 458;
                }
            }else {
                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash for SingleHash failed Error: %d\n", GetLastError());
                if(hHash){
                    CryptDestroyHash(hHash);
                }
                if(hProv) {
                    CryptReleaseContext(hProv, 0);
                }
                if (hashFile) {
                    fclose(hashFile);
                }
                return 457;
            }
        }else {
            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash for MultiHash failed Error: %d\n", GetLastError());
            if(hProv) {
            	CryptReleaseContext(hProv, 0);
            }
        	if (hashFile) {
        		fclose(hashFile);
        	}
            return 457;
        }
	}else {
		healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptAcquireContext failed Error: %d\n", GetLastError());
    	if (hashFile) {
    		fclose(hashFile);
    	}
		return 457;
	}
	if (hashFile) {
		fclose(hashFile);
	}
	healthcheckLogger->log(NORMAL, L"HealthCheck.cpp generateSingleHashandBloackbyBlockHashforFile Ended...\n");
	return 0;
}

int generateSingleHashandBlockbyBlockforBinFile(wchar_t* destFileDir, wchar_t* sourceFilePath, wchar_t* destFilePath, wchar_t* backupIdentifier, wchar_t* hashType, wchar_t* fileType)
{
	healthcheckLogger->log(NORMAL, L"HealthCheck.cpp generateSingleHashandBlockbyBlockforBinFile started for File->%ws...\n",sourceFilePath);
	DWORD cbHash = 0;
    HCRYPTPROV hProv = 0;
    HCRYPTPROV hProv1 = 0;
    HCRYPTHASH hHash = 0;
    HCRYPTHASH hHashNew = 0;
    FILE * hashFile;
    BYTE rgbHash[MD5LEN];
    CHAR rgbDigits[] = "0123456789abcdef";
    BOOL readResult = FALSE;

	ULONG byteCountvalue;
	LONGLONG byteOffsetvalue;
	DWORD byteOffsetlowvalue;
	LONG byteOffsethighvalue;
    DWORD64 binFileOffsetvalue = 0;
    //size_t bufSize;
    BYTE *buffer;
    DWORD bytesread;

    wchar_t* wtextSource = new wchar_t[wcslen(sourceFilePath) + 1];
    wcscpy(wtextSource, sourceFilePath);
    wcscat(wtextSource, L"\0");
	wchar_t* wtextDest = new wchar_t[wcslen(destFilePath) + wcslen(hashType) + wcslen(backupIdentifier) + wcslen(L".txt") + 3];
	wcscpy(wtextDest, destFilePath);
	wcscat(wtextDest, L"_");
	wcscat(wtextDest, hashType);
	wcscat(wtextDest, L"_");
	wcscat(wtextDest, backupIdentifier);
	wcscat(wtextDest, L".txt");
	wcscat(wtextDest, L"\0");
	LPTSTR DestFile = wtextDest;

    wchar_t* wtextDestofSingleHash = new wchar_t[wcslen(destFileDir) + wcslen(hashType) +  wcslen(L"_single_") + wcslen(backupIdentifier) + wcslen(L".txt") + 2];
    wcscpy(wtextDestofSingleHash, destFileDir);
    wcscat(wtextDestofSingleHash, L"\\");
    wcscat(wtextDestofSingleHash, hashType);
    wcscat(wtextDestofSingleHash, L"_single_");
    wcscat(wtextDestofSingleHash, backupIdentifier);
    wcscat(wtextDestofSingleHash, L".txt");
    wcscat(wtextDestofSingleHash, L"\0");
    LPTSTR DestFileofSingleHash = wtextDestofSingleHash;

    wchar_t* wtextMetaDataFile = new wchar_t[wcslen(destFilePath) + wcslen(L"metadata.txt") + 1];
    wcscpy(wtextMetaDataFile, destFilePath);
    wcscat(wtextMetaDataFile, L"metadata.txt");
    wcscat(wtextMetaDataFile, L"\0");

    _wfopen_s(&hashFile, DestFile, L"w");

    // Get handle to the crypto provider
    if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) {
        if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
            if (CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHashNew)) {
                    HANDLE hFile = CreateFile(wtextSource, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
                    if (hFile != INVALID_HANDLE_VALUE) {
                        ifstream metaDataFileIterator(wtextMetaDataFile);
                        while(metaDataFileIterator>>byteCountvalue>>byteOffsetvalue>>byteOffsetlowvalue>>byteOffsethighvalue)
                        {
                            buffer = new BYTE[byteCountvalue];
                            readResult = ReadFile(hFile, buffer, byteCountvalue, &bytesread, NULL);
                            if(readResult) {
                                if(bytesread == 0) {
                                     break;
                                }else if(bytesread > 0) {
                                    if (CryptHashData(hHash, buffer, bytesread, 0)) {
                                        if (CryptHashData(hHashNew, buffer, bytesread, 0)) {
                                            cbHash = MD5LEN;
                                            if (CryptGetHashParam(hHash, HP_HASHVAL, rgbHash, &cbHash, 0)) {
                                                fwprintf_s(hashFile, L"%lld\t", binFileOffsetvalue);
                                                for (DWORD i = 0; i < cbHash; i++)
                                                {
                                                    fwprintf_s(hashFile, L"%c%c", rgbDigits[rgbHash[i] >> 4], rgbDigits[rgbHash[i] & 0xf]);
                                                }
                                                fwprintf(hashFile ,L"\t");
                                            }
                                            else {
                                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptGetHashParam failed Error: %d\n", GetLastError());
                                                if(hFile){
                                                    CloseHandle(hFile);
                                                }
                                                if(hHashNew){
                                                    CryptDestroyHash(hHashNew);
                                                }
                                                if(hHash){
                                                    CryptDestroyHash(hHash);
                                                }
                                                if(hProv) {
                                                    CryptReleaseContext(hProv, 0);
                                                }
                                                if (hashFile) {
                                                    fclose(hashFile);
                                                }
                                                return 457;
                                            }
                                            if(hHash){
                                                CryptDestroyHash(hHash);
                                            }
                                            if (!CryptCreateHash(hProv, CALG_MD5, 0, 0, &hHash)) {
                                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash for failed Error: %d\n", GetLastError());
                                                if(hFile){
                                                    CloseHandle(hFile);
                                                }
                                                if(hHashNew){
                                                    CryptDestroyHash(hHashNew);
                                                }
                                                if (hashFile) {
                                                    fclose(hashFile);
                                                }
                                                if(hProv) {
                                                    CryptReleaseContext(hProv, 0);
                                                }
                                                return 457;
                                            }
                                        }else {
                                            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptHashData failed Error: %d\n", GetLastError());
                                            if(hFile){
                                                CloseHandle(hFile);
                                            }
                                            if(hHashNew){
                                                CryptDestroyHash(hHashNew);
                                            }
                                            if(hHash){
                                                CryptDestroyHash(hHash);
                                            }
                                            if(hProv) {
                                                CryptReleaseContext(hProv, 0);
                                            }
                                            if (hashFile) {
                                                fclose(hashFile);
                                            }
                                            return 457;
                                        }
                                    }else {
                                        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptHashData failed Error: %d\n", GetLastError());
                                        if(hFile){
                                            CloseHandle(hFile);
                                        }
                                        if(hHashNew){
                                            CryptDestroyHash(hHashNew);
                                        }
                                        if(hHash){
                                            CryptDestroyHash(hHash);
                                        }
                                        if(hProv) {
                                            CryptReleaseContext(hProv, 0);
                                        }
                                        if (hashFile) {
                                            fclose(hashFile);
                                        }
                                        return 457;
                                    }
                                }
                            }
                            else {
                                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Reading Backup File failed Error: %d\n", GetLastError());
                                if(hFile){
                                    CloseHandle(hFile);
                                }
                                if(hHashNew){
                                    CryptDestroyHash(hHashNew);
                                }
                                if(hHash){
                                    CryptDestroyHash(hHash);
                                }
                                if(hProv) {
                                    CryptReleaseContext(hProv, 0);
                                }
                                if (hashFile) {
                                    fclose(hashFile);
                                }
                                return 459;
                            }
                             binFileOffsetvalue = binFileOffsetvalue + byteCountvalue;
                        }
                        metaDataFileIterator.close();
                        cbHash = MD5LEN;
                        if (CryptGetHashParam(hHashNew, HP_HASHVAL, rgbHash, &cbHash, 0)) {
	                        wofstream hashFileSingle(DestFileofSingleHash, ios::app);
	                        hashFileSingle.imbue(locale(locale(), new codecvt_utf8_utf16<wchar_t, 0x10ffff, codecvt_mode(consume_header | generate_header)>));
                            hashFileSingle << wtextSource << L"\t" << fileType << L"\t";
                            for (DWORD i = 0; i < cbHash; i++)
                            {
                                hashFileSingle << (rgbDigits[rgbHash[i] >> 4]) << rgbDigits[rgbHash[i] & 0xf];
                            }
                            hashFileSingle << L"\t";
                            hashFileSingle.close();
                        }
                        else {
                            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptGetHashParam failed Error: %d\n", GetLastError());
                            if(hFile){
                                CloseHandle(hFile);
                            }
                            if(hHashNew){
                                CryptDestroyHash(hHashNew);
                            }
                            if(hHash){
                                CryptDestroyHash(hHash);
                            }
                            if(hProv) {
                                CryptReleaseContext(hProv, 0);
                            }
                            if (hashFile) {
                                fclose(hashFile);
                            }
                            return 457;
                        }
                        if(hFile){
                            CloseHandle(hFile);
                        }
                        if(hHashNew){
                            CryptDestroyHash(hHashNew);
                        }
                        if(hHash){
                            CryptDestroyHash(hHash);
                        }
                        if(hProv) {
                            CryptReleaseContext(hProv, 0);
                        }
                    }else {
                        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp  Opening file Error: %d\n", GetLastError());
                        if(hHashNew){
                            CryptDestroyHash(hHashNew);
                        }
                        if(hHash){
                            CryptDestroyHash(hHash);
                        }
                        if(hProv) {
                            CryptReleaseContext(hProv, 0);
                        }
                        if (hashFile) {
                            fclose(hashFile);
                        }
                        return 458;
                    }
            }else {
                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash for SingleHash failed Error: %d\n", GetLastError());
                if(hHash){
                    CryptDestroyHash(hHash);
                }
                if(hProv) {
                    CryptReleaseContext(hProv, 0);
                }
                if (hashFile) {
                    fclose(hashFile);
                }
                return 457;
            }
        }else {
            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptCreateHash for MultiHash failed Error: %d\n", GetLastError());
            if(hProv) {
            	CryptReleaseContext(hProv, 0);
            }
        	if (hashFile) {
        		fclose(hashFile);
        	}
            return 457;
        }
	}else {
		healthcheckLogger->log(NORMAL, L"HealthCheck.cpp CryptAcquireContext failed Error: %d\n", GetLastError());
		if (hashFile) {
    		fclose(hashFile);
    	}
		return 457;
	}
	if (hashFile) {
		fclose(hashFile);
	}
	healthcheckLogger->log(NORMAL, L"HealthCheck.cpp generateSingleHashandBlockbyBlockforBinFile Ended...\n");
	return 0;
}

int compareHashValues(wchar_t* vmName, wchar_t* scheduleName, wchar_t* fileNameStr, wchar_t* backuphashFile, wchar_t* healthcheckhashFile, wchar_t* backupType, wchar_t* backupmetadata)
{
    FILE* mFile;
    LONGLONG backuphashFilebyteOffsetvalue;
    LONGLONG healthcheckhashFileByteOffsetvalue;
    char backuphashFileHashvalue[33];
    char healthcheckhashFileHashvalue[33];

    ULONG byteCountvalue;
    LONGLONG byteOffsetvalue;
  	DWORD byteOffsetlowvalue;
    LONG byteOffsethighvalue;

    wchar_t* mFilePath = new wchar_t[wcslen(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\") + wcslen(scheduleName) + wcslen(vmName) + wcslen(fileNameStr) + wcslen(L"_healthcheck.txt") + 3];
    wcscpy(mFilePath, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\");
    wcscat(mFilePath, scheduleName);
    wcscat(mFilePath, L"\\");
    wcscat(mFilePath, vmName);
    wcscat(mFilePath, L"\\");
    wcscat(mFilePath, fileNameStr);
    wcscat(mFilePath, L"_healthcheck.txt");
    wcscat(mFilePath, L"\0");
    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp compareHashValues started for File->%ws...\n",mFilePath);
	_wfopen_s(&mFile, mFilePath, L"a");
	if(!mFile) {
        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp unable open MetaData File: %d...\n",GetLastError());
        return 461;
	}
	ifstream backuphashFileIterator(backuphashFile);
	if(!backuphashFileIterator) {
        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp unable open backuphash File: %d...\n",GetLastError());
        return 461;
	}
    ifstream healthcheckhashFileIterator(healthcheckhashFile);
    if(!healthcheckhashFileIterator) {
        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp unable open healthcheckhash File: %d...\n",GetLastError());
        backuphashFileIterator.close();
        return 461;
    }
	if(wcscmp(backupType, L"FullBackup")==0) {
	    while(backuphashFileIterator >> backuphashFilebyteOffsetvalue >> backuphashFileHashvalue) {
	        ULARGE_INTEGER offsetValue;
	        offsetValue.QuadPart = backuphashFilebyteOffsetvalue;
	        if(healthcheckhashFileIterator >> healthcheckhashFileByteOffsetvalue >> healthcheckhashFileHashvalue) {
	            if(strcmp(backuphashFileHashvalue, healthcheckhashFileHashvalue) != 0){
	                fwprintf_s(mFile, L"%lu\t%I64d\t%lu\t%lu\t", BUFSIZETOHASH, backuphashFilebyteOffsetvalue, offsetValue.LowPart, offsetValue.HighPart);
	            }
	        }else {
	            fwprintf_s(mFile, L"%lu\t%I64d\t%lu\t%lu\t", BUFSIZETOHASH, backuphashFilebyteOffsetvalue, offsetValue.LowPart, offsetValue.HighPart);
	            break;
	        }
	    }
	    while(backuphashFileIterator>>backuphashFilebyteOffsetvalue>>backuphashFileHashvalue) {
	        ULARGE_INTEGER offsetValue;
	        offsetValue.QuadPart = backuphashFilebyteOffsetvalue;
	        fwprintf_s(mFile, L"%lu\t%I64d\t%lu\t%lu\t", BUFSIZETOHASH, backuphashFilebyteOffsetvalue, offsetValue.LowPart, offsetValue.HighPart);
	    }
	}else {
	    ifstream metaDataFileIterator(backupmetadata);
        while(backuphashFileIterator >> backuphashFilebyteOffsetvalue >> backuphashFileHashvalue) {
            if(metaDataFileIterator >> byteCountvalue >> byteOffsetvalue >> byteOffsetlowvalue >> byteOffsethighvalue) {
                if(healthcheckhashFileIterator >> healthcheckhashFileByteOffsetvalue >> healthcheckhashFileHashvalue) {
                    if(strcmp(backuphashFileHashvalue, healthcheckhashFileHashvalue) != 0){
                        fwprintf_s(mFile, L"%lu\t%I64d\t%lu\t%ld\t", byteCountvalue, byteOffsetvalue, byteOffsetlowvalue, byteOffsethighvalue);
                    }
                }else {
                    fwprintf_s(mFile, L"%lu\t%I64d\t%lu\t%ld\t", byteCountvalue, byteOffsetvalue, byteOffsetlowvalue, byteOffsethighvalue);
                    break;
                }
            }else {
                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp data missing in MetaData File...\n");
                metaDataFileIterator.close();
                backuphashFileIterator.close();
                healthcheckhashFileIterator.close();
                fclose(mFile);
                return 1;
            }
	    }
	    while(backuphashFileIterator>>backuphashFilebyteOffsetvalue>>backuphashFileHashvalue) {
	        if(metaDataFileIterator >> byteCountvalue >> byteOffsetvalue >> byteOffsetlowvalue >> byteOffsethighvalue) {
	            fwprintf_s(mFile, L"%lu\t%I64d\t%lu\t%ld\t", byteCountvalue, byteOffsetvalue, byteOffsetlowvalue, byteOffsethighvalue);
	        }else {
                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp data missing in MetaData File...\n");
                metaDataFileIterator.close();
                backuphashFileIterator.close();
                healthcheckhashFileIterator.close();
                fclose(mFile);
                return 1;
	        }
	    }
	    metaDataFileIterator.close();
	}
    backuphashFileIterator.close();
    healthcheckhashFileIterator.close();
    fclose(mFile);
    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp compareHashValues ended......\n");
    return 0;

}

int checkHash(wchar_t* destFilesDir,wchar_t* scheduleName, wchar_t* vmName, wchar_t* backupIdentifier, wchar_t* backupType)
{
    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp checkHash started...%ws...\n",destFilesDir);
    int size = 1024, pos;
    wchar_t c;
    DWORD retVal = 0;
    wchar_t *fileName;
    wchar_t *hashVal;
    wchar_t *fileType;
    std::vector<std::vector<wchar_t *>> hashDetailList;
	wchar_t* wtexthealthcheckhashsingle = new wchar_t[wcslen(destFilesDir) + wcslen(L"healthcheckhash_single_") + wcslen(backupIdentifier) + wcslen(L".txt") + 2];
	wcscpy(wtexthealthcheckhashsingle, destFilesDir);
	wcscat(wtexthealthcheckhashsingle, L"\\");
	wcscat(wtexthealthcheckhashsingle, L"healthcheckhash_single_");
	wcscat(wtexthealthcheckhashsingle, backupIdentifier);
	wcscat(wtexthealthcheckhashsingle, L".txt");
	wcscat(wtexthealthcheckhashsingle, L"\0");
    wifstream healthcheckhashsingle(wtexthealthcheckhashsingle, ios::binary);
    if(healthcheckhashsingle) {
        healthcheckhashsingle.imbue(locale(locale(), new codecvt_utf8_utf16<wchar_t, 0x10ffff, codecvt_mode(consume_header | generate_header)>));
        while(1)
        {
            fileName = (wchar_t *)malloc(size*sizeof(wchar_t));
            fileName[0] = '\0';
            hashVal = (wchar_t *)malloc(((MD5LEN*2)+1)*sizeof(wchar_t));
            fileType = (wchar_t *)malloc(10*sizeof(wchar_t));
            pos = 0;
            while(healthcheckhashsingle.get(c)) {
                if (c != '\n' && c != '\t') {
                    fileName[pos++] = c;
                }else {
                    break;
                }
                if (pos >= size - 1) {
                    size += 1024;
                    fileName = (wchar_t*)realloc(fileName, size*sizeof(wchar_t));
                }
            }
            if (pos != 0) {
                fileName[pos++] = '\0';
            }
            pos = 0;
            while(healthcheckhashsingle.get(c)) {
                if (c != '\n' && c != '\t') {
                    fileType[pos++] = c;
                }else {
                    break;
                }
                if (pos >= size - 1) {
                    size += 32;
                    fileType = (wchar_t*)realloc(fileType, size*sizeof(wchar_t));
                }
            }
            if (pos != 0) {
                fileType[pos++] = '\0';
            }
            pos = 0;
            while(healthcheckhashsingle.get(c)) {
                if (c != '\n' && c != '\t') {
                    hashVal[pos++] = c;
                }else {
                    break;
                }
                if (pos >= size - 1) {
                    size += 32;
                    hashVal = (wchar_t*)realloc(hashVal, size*sizeof(wchar_t));
                }
            }
            if (pos != 0) {
                hashVal[pos++] = '\0';
            }
            if(wcscmp(fileName, L"\0")==0){
                break;
            }
            std::vector<wchar_t *> hashDetail;
            hashDetail.push_back(fileName);
            hashDetail.push_back(fileType);
            hashDetail.push_back(hashVal);
            hashDetailList.push_back(hashDetail);
            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp healthcheckhashSingle Info...Filetype:%ws  HashVal:%ws FileName:%ws\n",fileType,hashVal,fileName);
        }
	}else {
	    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp unable open healthcheckhash File: %d...\n",GetLastError());
	    return 461;
	}
	healthcheckhashsingle.close();
//    if(hashDetailList.empty()) {
//	    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp No Backup Files are present...\n");
//	    return 3;
//    }
    std::vector<std::vector<wchar_t *>> checkedFilesList;
	wchar_t* wtextbackuphashsingle = new wchar_t[wcslen(destFilesDir) + wcslen(backupIdentifier) + wcslen(L"backuphash_single_") + wcslen(backupIdentifier) + wcslen(L".txt") + 2];
	wcscpy(wtextbackuphashsingle, destFilesDir);
	wcscat(wtextbackuphashsingle, L"\\");
	wcscat(wtextbackuphashsingle, L"backuphash_single_");
	wcscat(wtextbackuphashsingle, backupIdentifier);
	wcscat(wtextbackuphashsingle, L".txt");
	wcscat(wtextbackuphashsingle, L"\0");
    wifstream backuphashsingle(wtextbackuphashsingle, ios::binary);
    if(backuphashsingle) {
        backuphashsingle.imbue(locale(locale(), new codecvt_utf8_utf16<wchar_t, 0x10ffff, codecvt_mode(consume_header | generate_header)>));
        while(1)
        {
            fileName = (wchar_t *)malloc(size*sizeof(wchar_t));
            fileName[0] = '\0';
            hashVal = (wchar_t *)malloc(((MD5LEN*2)+1)*sizeof(wchar_t));
            fileType = (wchar_t *)malloc(10*sizeof(wchar_t));
            pos = 0;
            while(backuphashsingle.get(c)) {
                if (c != '\n' && c != '\t') {
                    fileName[pos++] = c;
                }else {
                    break;
                }
                if (pos >= size - 1) {
                    size += 1024;
                    fileName = (wchar_t*)realloc(fileName, size*sizeof(wchar_t));
                }
            }
            if (pos != 0) {
                fileName[pos++] = '\0';
            }
            pos = 0;
            while(backuphashsingle.get(c)) {
                if (c != '\n' && c != '\t')
                {
                    fileType[pos++] = c;
                }else {
                    break;
                }
                if (pos >= size - 1) {
                    size += 32;
                    fileType = (wchar_t*)realloc(fileType, size*sizeof(wchar_t));
                }
            }
            if (pos != 0) {
                fileType[pos++] = '\0';
            }
            pos = 0;
            while(backuphashsingle.get(c)) {
                if (c != '\n' && c != '\t') {
                    hashVal[pos++] = c;
                }else {
                    break;
                }
                if (pos >= size - 1) {
                    size += 32;
                    hashVal = (wchar_t*)realloc(hashVal, size*sizeof(wchar_t));
                }
            }
            if (pos != 0) {
                hashVal[pos++] = '\0';
            }
            if(wcscmp(fileName, L"\0")==0){
                break;
            }
            wstring fileNamePathStr = fileName;
            fileNamePathStr = fileNamePathStr.substr(fileNamePathStr.find(L"\\"));//to remove junk value infront of fileName, junk value added while append into file in wofstream configured for unicode
            wstring fileNameStr;
            wchar_t* backupmetadata = L"-";
            if(wcscmp(backupType, L"IncrBackup")==0) {
                fileNamePathStr = fileNamePathStr.substr(0, fileNamePathStr.rfind(L"backup.bin"));
                backupmetadata = new wchar_t[fileNamePathStr.length() + wcslen(L"metadata.txt") + 1];
                wcscpy(backupmetadata, fileNamePathStr.c_str());
                wcscat(backupmetadata, L"metadata.txt");
                wcscat(backupmetadata, L"\0");
                fileNameStr = fileNamePathStr.substr(0, fileNamePathStr.rfind(L"."));
            }else {
                fileNamePathStr = fileNamePathStr.substr(0, fileNamePathStr.rfind(L"."));
                fileNameStr = fileNamePathStr;
            }
            fileNameStr = fileNameStr.substr(fileNameStr.rfind(L"\\") + 1);
            wchar_t* fileNameNoExten = new wchar_t[fileNameStr.length() + 1];
            wcscpy(fileNameNoExten, fileNameStr.c_str());
            wcscat(fileNameNoExten, L"\0");
            wchar_t* backuphashFile = new wchar_t[fileNamePathStr.length() + wcslen(L"_backuphash_") + wcslen(backupIdentifier) + wcslen(L".txt") + 2];
            wcscpy(backuphashFile, fileNamePathStr.c_str());
            wcscat(backuphashFile, L"_backuphash_");
            wcscat(backuphashFile, backupIdentifier);
            wcscat(backuphashFile, L".txt");
            wcscat(backuphashFile, L"\0");
            wchar_t* healthcheckhashFile = new wchar_t[fileNamePathStr.length() + wcslen(L"_healthcheckhash_") + wcslen(backupIdentifier) + wcslen(L".txt") + 2];
            wcscpy(healthcheckhashFile, fileNamePathStr.c_str());
            wcscat(healthcheckhashFile, L"_healthcheckhash_");
            wcscat(healthcheckhashFile, backupIdentifier);
            wcscat(healthcheckhashFile, L".txt");
            wcscat(healthcheckhashFile, L"\0");
            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp backuphashSingle Info... Filetype:%ws  HashVal:%ws  FileName:%ws\n",fileType,hashVal,fileName);
            if(hashDetailList.empty())
            {
                if(wcscmp(fileType, L"bin") == 0) {
                    retVal = compareHashValues(vmName, scheduleName, fileNameNoExten, backuphashFile, healthcheckhashFile, backupType, backupmetadata);
                    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp compareHashValues return value : %d...\n",retVal);
                    if(retVal) {
                        backuphashsingle.close();
                        return 1;
                    }
                    retVal = 2;
                }else {
                    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Missing of File: %ws...\n",fileName);
                    backuphashsingle.close();
                    return 1;
                }
            }
            for(int i = 0; i < hashDetailList.size(); i++) {
                if(wcscmp(hashDetailList[i][0], fileName) == 0) {
                    if(wcscmp(hashDetailList[i][2], hashVal) != 0) {
                        if(wcscmp(fileType, L"metadata") == 0) {
                            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Couruption in MetaData File: %ws...\n",fileName);
                            backuphashsingle.close();
                            return 1;
                        }
                        retVal = compareHashValues(vmName, scheduleName, fileNameNoExten, backuphashFile, healthcheckhashFile, backupType, backupmetadata);
                        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp compareHashValues return value : %d...\n",retVal);
                        if(retVal) {
                            backuphashsingle.close();
                            return 1;
                        }
                        retVal = 2;
                    }
                    //hashDetailList.erase(hashDetailList.begin()+i);
                    break;
                }else {
                    if(hashDetailList.size()-1 == i) {
                        if(wcscmp(fileType, L"bin") == 0) {
                            retVal = compareHashValues(vmName, scheduleName, fileNameNoExten, backuphashFile, healthcheckhashFile, backupType, backupmetadata);
                            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp compareHashValues return value : %d...\n",retVal);
                            if(retVal) {
                                backuphashsingle.close();
                                return 1;
                            }
                            retVal = 2;
                        }else {
                            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp Missing of File: %ws...\n",fileName);
                            backuphashsingle.close();
                            return 1;
                        }
                    }
                }
            }
            if(wcscmp(fileType, L"vhd") == 0 || wcscmp(fileType, L"bin") == 0) {
                std::vector<wchar_t *> checkedFileDetail;
                checkedFileDetail.push_back(backuphashFile);
                checkedFileDetail.push_back(healthcheckhashFile);
                checkedFilesList.push_back(checkedFileDetail);
            }
        }
	}else {
	    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp unable read backuphash File: %d...\n",GetLastError());
	    return 461;
	}
    backuphashsingle.close();
    if(retVal == 0 || retVal == 2 ) {
        bool isDeleted; int isrenamed;
        for(int i = 0; i < checkedFilesList.size(); i++) {
            isDeleted = DeleteFile(checkedFilesList[i][0]);
            if(!isDeleted) {
                healthcheckLogger->log(NORMAL, L"HealthCheck.cpp  healthcheckhash file delete Fails :%d\n", GetLastError());
            }
            isrenamed = _wrename(checkedFilesList[i][1], checkedFilesList[i][0]);
            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp healthcheckhash file renamed to backuphash result : %d %d \n", isrenamed, GetLastError());
        }
        isDeleted = DeleteFile(wtextbackuphashsingle);
        if(!isDeleted) {
            healthcheckLogger->log(NORMAL, L"HealthCheck.cpp  healthcheckhash file delete Fails :%d\n", GetLastError());
        }
        isrenamed = _wrename(wtexthealthcheckhashsingle, wtextbackuphashsingle);
        healthcheckLogger->log(NORMAL, L"HealthCheck.cpp healthcheckhash file renamed to backuphash result : %d %d \n", isrenamed, GetLastError());
    }
    healthcheckLogger->log(NORMAL, L"HealthCheck.cpp checkHash ended....\n");
    return retVal;
}
