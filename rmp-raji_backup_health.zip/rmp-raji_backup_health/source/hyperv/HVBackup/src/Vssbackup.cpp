//todo querystatus and wait
#pragma once

#include "hvWMI.h"
#include "Vssbackup.h"
#include <fstream>

LPWSTR levelvss=NORMAL;
LPWSTR vssloc;
Loggerclass *logger;

HMODULE vsshan;
IVssBackupComponents *pBackup;
IVssBackupComponents *pRestore;
IVssExamineWriterMetadata *pWriterMetadata;

std::unordered_set<_TCHAR> volumeNames;
std::map<char, VSS_ID> volumeSnapshotIDmap;

IVssAsync *pRestoreAsync;

VSS_ID writerId;
VSS_ID idInstance = GUID_NULL;


//todo
bool sptcreated;
GUID sptSetId;
bool abnormalStop; 
bool exceptionStop;
String^ getsnapshotNamefromFile(BSTR backupName, String^ volumeName, Loggerclass *fileCopylogger)
{
	wchar_t* snapshotFileName = new wchar_t[wcslen(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\FileCopyLogs\\SnapshotDetails_") + wcslen(backupName) + wcslen(L".txt") + 1];
	wcscpy(snapshotFileName, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\FileCopyLogs\\SnapshotDetails_");
	wcscat(snapshotFileName, backupName);
	wcscat(snapshotFileName, L".txt");
	wcscat(snapshotFileName, L"\0");
	fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp LoadsnapshotdetailsfiletoMap File Path -> %ws\n",snapshotFileName);
	String^ snapshotFileNameString = gcnew String(snapshotFileName, 0, wcslen(snapshotFileName));
	if(!File::Exists(snapshotFileNameString))
	{
		fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp Snapshot File Does Not Exist File Path -> %ws\n",snapshotFileName);
		return nullptr;
	}
	array<String^>^ snapshotdetails = File::ReadAllLines(snapshotFileNameString);
	for(int i = 0; i < snapshotdetails.Length; i += 2)
	{
		
		if(snapshotdetails[i] == nullptr)
		{
			fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp Volumne Name while reading from snapshot details file is NULL..\n");
		}
		else
		{
			fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp Got Volumne Name from snapshot details file \n");
		}
		if(snapshotdetails[i+1] == nullptr)
		{
			fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp Snapshot Name while reading from snapshot details file is NULL..\n");
		}
		else
		{
			fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp Got Snapshot Name for volume name from snapshot details file \n");
		}

		if(snapshotdetails[i]->Equals(volumeName))
		{
			fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp Found matching snapshot name form volume Name..\n");
			return snapshotdetails[i+1];
		}
	}	
	return nullptr;
}

bool VssSupport(wstring name) 
{
	// check if we run or XP or higher
	// check if not run on WIndows PE
	/*
	Basically, the logic can be this:
	-	If the key MiniNT is found in HKLM\System\ControlSet001\Control we are
	running on WinPE
	*/
	vssloc=(LPWSTR)name.c_str();
	//loggervss= new Logger(vssloc,(LPWSTR)levelvss);
	OSVERSIONINFOEX osInfo;
	HKEY hKey = NULL;
	LONG lRet;
	bool xpOrHigher, winPE;

	// check win pe
	lRet = RegOpenKeyEx( HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\MiniNT", 0, KEY_QUERY_VALUE, &hKey );
	if (lRet == ERROR_SUCCESS && hKey != NULL) {
		winPE = true;
		RegCloseKey(hKey);
	} else {
		winPE = false;
	}
	// check version number
	ZeroMemory(&osInfo, sizeof(osInfo));
	osInfo.dwOSVersionInfoSize = sizeof(osInfo);
	BOOL ok = GetVersionEx((LPOSVERSIONINFO)&osInfo);
	if (!ok)
		return false;

	xpOrHigher = osInfo.dwMajorVersion > 5 || (osInfo.dwMajorVersion == 5 && osInfo.dwMinorVersion >= 1);
	bool is32BitRunnninOn64 = Is32BitProcessRunningInWow64();
	return xpOrHigher && !winPE && !is32BitRunnninOn64;

}

bool Is32BitProcessRunningInWow64()
{
	typedef BOOL (WINAPI *LPFN_ISWOW64PROCESS) (HANDLE, PBOOL);
	LPFN_ISWOW64PROCESS fnIsWow64Process;
	BOOL bIsWow64 = FALSE;

	fnIsWow64Process = (LPFN_ISWOW64PROCESS)GetProcAddress(GetModuleHandle(L"kernel32"),"IsWow64Process");
	if (NULL != fnIsWow64Process)
	{
		BOOL ok = fnIsWow64Process(GetCurrentProcess(), &bIsWow64);
		if (!ok)
		{
			logger->log(NORMAL, L"Hyper-V Vssbackup.cpp Is32BitProcessRunningInWow64 not OK\n");
		}
	}
	// else kernel function is missing and we are not in an 64Bit emulator
	return bIsWow64 != 0;
}

void InitializeGlobalvariables(Loggerclass *loggerclass)
{
	pBackup =  NULL; 
	pRestore=NULL;
	sptSetId = GUID_NULL; 
	vsshan = NULL;
	sptcreated = false; 
	abnormalStop = true; 
	logger = loggerclass;
	pRestoreAsync = NULL;
	initializeCommonUtilvariables(loggerclass);
	initializeHealthCheckvariables(loggerclass);
}

int  LoadVSSLibrary()
{
	//load vssapi.dll
	vsshan = LoadLibrary(L"vssapi.dll");  
	if (vsshan==NULL)
	{
		logger->log(NORMAL, L"Hyper-V Loading vssapi.dll failed\n");
		return 1;
	}
	logger->log(NORMAL, L"Hyper-V Loading vssapi.dll successful\n");
	return 0;
}

void CloseVss()
{
	pBackup = NULL;
	if (vsshan)
		FreeLibrary(vsshan);
	vsshan = NULL;
}

std::list<IVssWMComponent*> DoVSSSnapshot(std::list<BSTR> vmList, BSTR repositoryPath, BSTR scheduleName, BSTR backupName, std::list<BSTR> fullbackupVMList, std::list<BSTR> incrementalbackupVMList) 
/*repositorypath,scheudle and backupname is for storing writer and backupcomponents doc
this method will perform necessay snapshots, return the components and save backupcomponents doc and writer doc in backup folder*/
{
	logger->log(NORMAL, L"Vssbackup.cpp DoVSSSnapshot method starts...\n");
	IVssAsync *pAsync = NULL;
	IVssAsync* pPrepare = NULL;
	IVssAsync* pDoShadowCopy = NULL;
	std::list<IVssWMComponent*> componentList;
	std::list<IVssWMComponent*> emptyList;

	HRESULT result;

	try
	{
		result = CreateVssBackupComponents(&pBackup);
		CheckHRESULT(result, L"CreateVssBackupComponents");

		result = pBackup->InitializeForBackup();
		CheckHRESULT(result, L"InitializeForBackup");

		result = pBackup->SetBackupState(true, false, VSS_BT_FULL, false); //vss.SetBackupState(true, true, VssBackupType.Full, false);
		CheckHRESULT(result, L"SetBackupState");

		logger->log(NORMAL, L"Vssbackup.cpp DoVSSSnapshot Calling SetContext method..\n");
		result = pBackup->SetContext(VSS_CTX_APP_ROLLBACK | VSS_VOLSNAP_ATTR_NO_AUTORECOVERY);
		CheckHRESULT(result, L"SetContext");		

		// Add Hyper-V writer
		wchar_t* clsid_str = L"{66841cd4-6ded-4f4b-8f17-fd23f8ddc3de}";
		CLSIDFromString(clsid_str, &writerId);
		pBackup->EnableWriterClasses((const VSS_ID *)&writerId, 1);
		CheckHRESULT(result, L"EnableWriterClasses");

		result = pBackup->GatherWriterMetadata(&pAsync);
		CheckHRESULT(result, L"GatherWriterMetadata");

		logger->log(NORMAL, L"Gathering metadata from writers...\n");
		result = pAsync->Wait();
		CheckHRESULT(result, L"GatherWriterMetadataWait");

		pAsync->QueryStatus(&result, NULL);
		if (result != VSS_S_ASYNC_FINISHED)
		{
			if (SUCCEEDED(result)) 
			{
				logger->log(NORMAL, L"GatherWriterMetadata_QueryStatus Failed..!\n");
				CheckHRESULT(result, L"GatherWriterMetadata_QueryStatus");			
				return emptyList;
			}
		}

		logger->log(NORMAL, L"calling StartSnapshotSet...\n");
		VSS_ID snapshotSetId;
		result = pBackup->StartSnapshotSet(&sptSetId);
		CheckHRESULT(result, L"StartSnapshotSet");

		// Get the list of writers in the metadata  
		unsigned cWriters = 0;
		result = pBackup->GetWriterMetadataCount(&cWriters);
		CheckHRESULT(result, L"GetWriterMetadataCount");


				
		CComBSTR bstr(repositoryPath);
		bstr.AppendBSTR(SysAllocString(scheduleName));
		bstr.AppendBSTR(SysAllocString(L"\\"));
		bstr.AppendBSTR(SysAllocString(backupName));
		bstr.AppendBSTR(SysAllocString(L"\\"));
		BSTR fileName = bstr.Detach();
		std::wstring fileNamews(fileName, SysStringLen(fileName));


		
		// Enumerate writers
		for (unsigned iWriter = 0; iWriter < cWriters; iWriter++)
		{
			logger->log(NORMAL, L"Got writer meta data and writing to file\n");
			CComBSTR bstrXML;

			// Get the metadata for this particular writer
			
			CComPtr<IVssExamineWriterMetadata> pMetadata;
			result = pBackup->GetWriterMetadata(iWriter, &idInstance, &pMetadata);
			CheckHRESULT(result, L"GetWriterMetadata");
			pMetadata->SaveAsXML(&bstrXML);
			std::wstring contentsws(bstrXML, SysStringLen(bstrXML));
						
			BSTR writerName;
			VSS_USAGE_TYPE writerUsage;
			VSS_SOURCE_TYPE writerSource;
			result = pMetadata->GetIdentity(&idInstance, &writerId, &writerName, &writerUsage, &writerSource);//returns details about the writer
			CheckHRESULT(result, L"GetIdentity");

			UINT pcComponents;
			UINT pcIncludeFiles;
			UINT pcExcludeFiles;
			result = pMetadata->GetFileCounts(&pcIncludeFiles, &pcExcludeFiles, &pcComponents);//returns the number of components
			CheckHRESULT(result, L"GetFileCounts");
			
			for (unsigned i = 0; i < pcComponents; i++)
			{
				IVssWMComponent *component;
				result = pMetadata->GetComponent(i, &component);//obtains a Writer Metadata Document for a specified backup component
				CheckHRESULT(result, L"GetComponent");					

				//if (!component.isExplicitlyIncluded)
				//continue;
				
				// Add the component
				PVSSCOMPONENTINFO componentInfo;
				result = component->GetComponentInfo(&componentInfo);//returns information about the component
				CheckHRESULT(result, L"GetComponentInfo");

				bool isBackuprequired = false;
				for (auto itr = vmList.begin(); itr != vmList.end(); ++itr)
				{
					BSTR vmName = *itr;
					if (wcscmp(vmName, componentInfo->bstrComponentName) == 0)
					{
						logger->log(NORMAL, L"VM to backup: %ws\n", vmName);
						isBackuprequired = true;
					}
				}

				if (!isBackuprequired)
				{
					continue;
				}

				//Create Directory and copy writer documents
				BSTR createdDirectory = SysAllocStringLen(L"", wcslen(repositoryPath) + wcslen(scheduleName) + wcslen(backupName) + wcslen(componentInfo->bstrComponentName) + wcslen(L"\\HyperVVSSWriter.xml") + 4);
				wcscpy(createdDirectory, repositoryPath);
				wcscat(createdDirectory, scheduleName);
				wcscat(createdDirectory, L"\\");
				wcscat(createdDirectory, backupName);
				wcscat(createdDirectory, L"\\");
				wcscat(createdDirectory, componentInfo->bstrComponentName);
				CreateDirectory(createdDirectory, NULL);
				logger->log(NORMAL, L"3.Vssbackup.cpp DoVSSSnapshot Directory created with VM Name...%ws\n",createdDirectory);	

				wcscat(createdDirectory, L"\\");
				wcscat(createdDirectory, L"HyperVVSSWriter.xml");
				std::wstring fileNamews(createdDirectory, SysStringLen(createdDirectory));
				logger->log(NORMAL, L"Writer Metadata file path -> %ws\n", createdDirectory);
				WriteFile(fileNamews, contentsws);
				if(createdDirectory!=nullptr){SysFreeString(createdDirectory);}

				componentList.push_back(component);//List containing the components to backup. This list will be used to access files from shadow copy after snapshot is performed


				result = pBackup->AddComponent(idInstance, writerId, componentInfo->type, componentInfo->bstrLogicalPath, componentInfo->bstrComponentName);
				CheckHRESULT(result, L"AddComponent");				

				//Iterate through the files in the component and find the volumes that need to be added to Addtosnapshotset method

				for (unsigned i = 0; i < componentInfo->cFileCount; i++)
				{
					CComPtr<IVssWMFiledesc> pFileDesc;
					result = component->GetFile(i, &pFileDesc);
					CheckHRESULT(result, L"GetFile");
					_TCHAR volumeName[MAX_PATH + 1] = { 0 };
					BSTR filespec, filePath;
					result = pFileDesc->GetFilespec(&filespec);
					result = pFileDesc->GetPath(&filePath);
					DWORD backupTypeMask; 
					result = pFileDesc->GetBackupTypeMask(&backupTypeMask);
					logger->log(NORMAL, L"Vssbackup.cpp DoVSSSnapshot File Name -> %ws, BackupTypeMask -> %d\n", filespec, backupTypeMask);	
					logger->log(NORMAL, L"File properties - filespec: %ws\n", filespec);
					logger->log(NORMAL, L"File properties - filepath: %ws\n", filePath);
					GetVolumePathName(filePath, volumeName, MAX_PATH);//Returns volume name from the file path
					logger->log(NORMAL, L"File properties - Volume name: %ws\n", volumeName);
					char vol = volumeName[0];
					auto isInserted = volumeNames.insert(vol);
					if (isInserted.second) //volumeName is not already present
					{
						logger->log(NORMAL, L"AddToSnapshotSet: %c...\n",vol);
						result = pBackup->AddToSnapshotSet(volumeName, GUID_NULL, &snapshotSetId);
						CheckHRESULT(result, L"AddToSnapshotSet");
						volumeSnapshotIDmap.insert(std::pair<char, VSS_ID>(vol, snapshotSetId));
					}
				}				

				result = component->FreeComponentInfo(componentInfo);
				//CheckHRESULT(result,L"FreeComponentInfo");
			}
			
		}	

		result = pBackup->PrepareForBackup(&pPrepare);
		CheckHRESULT(result, L"PrepareForBackup");

		logger->log(NORMAL, L"Preparing for backup...\n");
		result = pPrepare->Wait();
		CheckHRESULT(result, L"PrepareForBackupWait");

		pPrepare->QueryStatus(&result, NULL);
		if (result != VSS_S_ASYNC_FINISHED)
		{
			if (SUCCEEDED(result)) 
			{
				logger->log(NORMAL, L"PrepareForBackupWait_QueryStatus Failed..!\n");
				CheckHRESULT(result, L"PrepareForBackupWait_QueryStatus");			
				return emptyList;
			}
		}

		result = pBackup->DoSnapshotSet(&pDoShadowCopy);
		CheckHRESULT(result, L"DoSnapshotSet");

		logger->log(NORMAL, L"Taking snapshots...\n\n");
		result = pDoShadowCopy->Wait();
		CheckHRESULT(result, L"DoSnapshotSetWait");

		pDoShadowCopy->QueryStatus(&result, NULL);
		if (result != VSS_S_ASYNC_FINISHED)
		{
			if (SUCCEEDED(result)) 
			{
				logger->log(NORMAL, L"DoSnapshotSet_QueryStatus Failed..!\n");
				CheckHRESULT(result, L"DoSnapshotSet_QueryStatus");			
				return emptyList;
			}
		}

		//delete all cbt files here
		logger->log(NORMAL, L"Going to call ProcessCBTFilesforbackupVMs...!\n");
		ProcessCBTFilesforbackupVMs(fullbackupVMList, incrementalbackupVMList, scheduleName, backupName, componentList);
		logger->log(NORMAL, L"Finished call ProcessCBTFilesforbackupVMs...!\n");
		

		sptcreated = true; 
		
		wchar_t* snapshotFileName = new wchar_t[wcslen(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\FileCopyLogs\\SnapshotDetails_") + wcslen(backupName) + wcslen(L".txt") + 1];
		wcscpy(snapshotFileName, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\FileCopyLogs\\SnapshotDetails_");
		wcscat(snapshotFileName, backupName);
		wcscat(snapshotFileName, L".txt");
		wcscat(snapshotFileName, L"\0");
		FILE *snapshotdetailsFile = _wfopen(snapshotFileName, L"a");
		if (snapshotdetailsFile == NULL)
		{
			logger->log(NORMAL, L"VssBackup.cpp DoVSSSnapshot Cannot open file to dump snapshot data...\n");
			return emptyList;
		}

		//volumeSnapshotpathmap -> Map between volumename for which snapshot is taken and the corresponding deviceobject path in the snapshot
		for (auto itr = volumeNames.begin(); itr != volumeNames.end(); ++itr)
		{
			logger->log(NORMAL, L"Get the snapshot device object from the properties...\n");
			VSS_SNAPSHOT_PROP snapshotProp = { 0 };
			std::map<char, VSS_ID>::iterator it = volumeSnapshotIDmap.find(*itr);
			snapshotSetId = it->second;
			char tempVol = it->first;
			result = pBackup->GetSnapshotProperties(snapshotSetId, &snapshotProp);
			CheckHRESULT(result, L"GetSnapshotProperties");

			if (snapshotProp.m_pwszSnapshotDeviceObject != NULL) 
			{
				logger->log(NORMAL, L"DeviceObject : %ls\n", snapshotProp.m_pwszSnapshotDeviceObject);
				fwprintf(snapshotdetailsFile, L"%c\n%ls\n", tempVol, snapshotProp.m_pwszSnapshotDeviceObject);				
			}			
		}

		fclose(snapshotdetailsFile);
		if(snapshotFileName!=nullptr){delete[] snapshotFileName;}		

		//set backup succeeded here
		logger->log(NORMAL, L"Vssbackup.coo Dovsssnapshot going to call SetBackupSucceeded..!\n");
		for (auto itr = componentList.begin(); itr != componentList.end(); ++itr)
		{
			IVssWMComponent *component = *itr;
			PVSSCOMPONENTINFO componentInfo;
			result = component->GetComponentInfo(&componentInfo);//returns information about the component
			//CheckHRESULT(result, L"GetComponentInfoBackupComplete");
			logger->log(NORMAL, L"Hyper-V Vssbackup.cpp Dovsssnapshot DONE Calling GetComponentInfo.HRESULT-> 0x%08lx..!\n",result);

			result = pBackup->SetBackupSucceeded(idInstance, writerId, componentInfo->type, componentInfo->bstrLogicalPath, componentInfo->bstrComponentName, TRUE);
			//CheckHRESULT(result, L"SetBackupSucceededBackupComplete");
			logger->log(NORMAL, L"Hyper-V Vssbackup.cpp Dovsssnapshot DONE Calling SetBackupSucceeded.HRESULT-> 0x%08lx..!\n",result);
			result = component->FreeComponentInfo(componentInfo);
		}
		logger->log(NORMAL, L"Vssbackup.coo Dovsssnapshot going to call BackupComplete..!\n");
		result = pBackup->BackupComplete(&pAsync);
		logger->log(NORMAL, L"Hyper-V Vssbackup.cpp Dovsssnapshot DONE Calling BackupComplete.HRESULT-> 0x%08lx..!\n",result);
		result = pAsync->Wait();
		result = pBackup->GatherWriterStatus(&pAsync);
		logger->log(NORMAL, L"Hyper-V Vssbackup.cpp Dovsssnapshot DONE Calling GatherWriterStatus.HRESULT-> 0x%08lx..!\n",result);

		logger->log(NORMAL, L"Saving the backup components document...\n");
		CComBSTR bstrXML;
		result = pBackup->SaveAsXML(&bstrXML);
		CheckHRESULT(result, L"SaveAsXMLbackupcomponents");
		std::wstring contentsws(bstrXML, SysStringLen(bstrXML));
		//wstring backupComponentsfilename = fileNamews + L"BackupComponents.xml";
		//logger->log(NORMAL, L"Backup COmponents file path -> %ws\n", backupComponentsfilename);
		//WriteFile(backupComponentsfilename, contentsws);

		for (auto itr = vmList.begin(); itr != vmList.end(); ++itr)
		{
			logger->log(NORMAL, L"Saving the backup components document for each VM...\n");
			BSTR vmName = *itr;
			BSTR backupComponentsfilename = SysAllocStringLen(L"", wcslen(repositoryPath) + wcslen(scheduleName) + wcslen(backupName) + wcslen(vmName) + wcslen(L"\\BackupComponents.xml") + 4);
			wcscpy(backupComponentsfilename, repositoryPath);
			wcscat(backupComponentsfilename, scheduleName);
			wcscat(backupComponentsfilename, L"\\");
			wcscat(backupComponentsfilename, backupName);
			wcscat(backupComponentsfilename, L"\\");
			wcscat(backupComponentsfilename, vmName);
			wcscat(backupComponentsfilename, L"\\");
			wcscat(backupComponentsfilename, L"BackupComponents.xml");
			std::wstring backupComponentsfilenamews(backupComponentsfilename, SysStringLen(backupComponentsfilename));
			WriteFile(backupComponentsfilenamews, contentsws);
			logger->log(NORMAL, L"Backup COmponents file path -> %ws\n", backupComponentsfilename);
			if(backupComponentsfilename!=nullptr){SysFreeString(backupComponentsfilename);}
		}

		logger->log(NORMAL, L"Vssbackup.coo Dovsssnapshot going to call FreeWriterMetadata..!\n");
		pBackup->FreeWriterMetadata();

	}
	catch (exception& e) 
	{
		//int clean = VssCleanup();
		logger->log(NORMAL, L"Hyper-V Vssbackup.cpp DoVSSSnapshot Exception...\n");
		return emptyList;
	}
	if (pDoShadowCopy != NULL)
	{
		pDoShadowCopy->Release();
	}
	if (pPrepare != NULL)
	{
		pPrepare->Release();
	}
	if (pAsync != NULL)
	{
		pAsync->Release();
	}
	logger->log(NORMAL, L"Hyper-V Vssbackup.cpp DoVSSSnapshot Completed...\n");
	return componentList;
}

void ProcessCBTFilesforbackupVMs(std::list<BSTR> fullbackupVMList, std::list<BSTR> incrementalbackupVMList, BSTR scheduleName, BSTR backupName, std::list<IVssWMComponent*> componentListbackedUp)
{
	logger->log(NORMAL, L"Hyper-V Vssbackup.cpp ProcessCBTFilesforbackupVMs started...\n");
	HRESULT  result;
	
	for (auto itr = componentListbackedUp.begin(); itr != componentListbackedUp.end(); ++itr)
	{
		IVssWMComponent *component = *itr;

		PVSSCOMPONENTINFO componentInfo;
		result = component->GetComponentInfo(&componentInfo);//returns information about the component
		CheckHRESULT(result, L"GetComponentInfo");

		bool isFullbackup = false;
		for (auto itr = fullbackupVMList.begin(); itr != fullbackupVMList.end(); ++itr)
		{
			BSTR vmName = *itr;
			if (wcscmp(vmName, componentInfo->bstrComponentName) == 0)
			{
				logger->log(NORMAL, L"VM to full backup. Deleting CBT file: %ws\n", vmName);
				isFullbackup = true;
			}
		}

		for (unsigned i = 0; i < componentInfo->cFileCount; i++)
		{
			CComPtr<IVssWMFiledesc> pFileDesc;
			result = component->GetFile(i, &pFileDesc);
			CheckHRESULT(result, L"GetFile");
			_TCHAR volumeName[MAX_PATH + 1] = { 0 };
			BSTR fileName, filePath;
			result = pFileDesc->GetFilespec(&fileName);
			result = pFileDesc->GetPath(&filePath);
			if ((wcsstr(fileName, L".vhd") != NULL) || (wcsstr(fileName, L".avhd") != NULL))
			{
				wchar_t* fileNamewithoutextension = (wchar_t *)malloc((wcslen(fileName) + 1) *sizeof(wchar_t));
				wcscpy(fileNamewithoutextension, fileName);
				wcscat(fileNamewithoutextension, L"\0");
				wchar_t* tempPointer = wcsrchr(fileNamewithoutextension, '.');
				if (tempPointer)
				{
					logger->log(NORMAL, L"Removing extension from vhd filename..->%ws\n", tempPointer);
					*tempPointer = '\0';
				}
				BSTR vhdcbtFileName = SysAllocStringLen(L"", wcslen(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\") + wcslen(scheduleName) + wcslen(componentInfo->bstrComponentName) + wcslen(fileNamewithoutextension) + wcslen(L".txt") + 1);
				wcscpy(vhdcbtFileName, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\");
				wcscat(vhdcbtFileName, scheduleName);
				wcscat(vhdcbtFileName, L"\\");
				wcscat(vhdcbtFileName, componentInfo->bstrComponentName);
				wcscat(vhdcbtFileName, L"\\");
				wcscat(vhdcbtFileName, fileNamewithoutextension);
				wcscat(vhdcbtFileName, L".txt");
                    BSTR vhdcbtFileName_hc = SysAllocStringLen(L"", wcslen(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\") + wcslen(scheduleName) + wcslen(componentInfo->bstrComponentName) + wcslen(fileNamewithoutextension) + wcslen(L"_healthcheck.txt") + 3);
                    wcscpy(vhdcbtFileName_hc, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\");
                    wcscat(vhdcbtFileName_hc, scheduleName);
                    wcscat(vhdcbtFileName_hc, L"\\");
                    wcscat(vhdcbtFileName_hc, componentInfo->bstrComponentName);
                    wcscat(vhdcbtFileName_hc, L"\\");
                    wcscat(vhdcbtFileName_hc, fileNamewithoutextension);
                    wcscat(vhdcbtFileName_hc, L"_healthcheck.txt");
                    wcscat(vhdcbtFileName_hc, L"\0");
				if(isFullbackup)
				{
                    //Full backup. So deleting CBT file
					logger->log(NORMAL, L"Hyper-V Vssbackup.cpp ProcessCBTFilesforbackupVMs Processing CBT file for FULL backup..!\n");
					logger->log(NORMAL, L"Hyper-V Vssbackup.cpp ProcessCBTFilesforbackupVMs CBT file to delete: %ws\n", vhdcbtFileName);
					bool isDeleted = DeleteFile(vhdcbtFileName);  //todo
                    if(vhdcbtFileName!=nullptr){SysFreeString(vhdcbtFileName);}
					isDeleted = DeleteFile(vhdcbtFileName_hc);
					if(vhdcbtFileName_hc!=nullptr){SysFreeString(vhdcbtFileName_hc);}
				}
				else
				{
					//Incremental backup. So copying CBT file and deleting old file
					logger->log(NORMAL, L"Hyper-V Vssbackup.cpp ProcessCBTFilesforbackupVMs Processing CBT file for INCR backup..!\n");
					BSTR vhdcbttempFileName = SysAllocStringLen(L"", wcslen(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\") + wcslen(scheduleName) + wcslen(componentInfo->bstrComponentName) + wcslen(fileNamewithoutextension) + wcslen(L"_.txt") + wcslen(backupName) + 1);
					wcscpy(vhdcbttempFileName, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\");
					wcscat(vhdcbttempFileName, scheduleName);
					wcscat(vhdcbttempFileName, L"\\");
					wcscat(vhdcbttempFileName, componentInfo->bstrComponentName);
					wcscat(vhdcbttempFileName, L"\\");
					wcscat(vhdcbttempFileName, fileNamewithoutextension);
					wcscat(vhdcbttempFileName, L"_");
					wcscat(vhdcbttempFileName, backupName);
					wcscat(vhdcbttempFileName, L".txt");
					logger->log(NORMAL, L"Hyper-V Vssbackup.cpp ProcessCBTFilesforbackupVMs CBT file to Move: %ws\n", vhdcbttempFileName);
					
					BOOL rename = MoveFile(vhdcbtFileName, vhdcbttempFileName);
					logger->log(NORMAL, L"Hyper-V Vssbackup.cpp ProcessCBTFilesforbackupVMs VHDCBTfilepath Original path: %ws\n", vhdcbtFileName);
					if(vhdcbttempFileName!=nullptr){SysFreeString(vhdcbttempFileName);}
					if(!rename)
					{
						logger->log(NORMAL, L"Vssbackup.cpp ProcessCBTFilesforbackupVMs No such VHD CBT file exists...\n");
						continue;
					}

				}
				
			}
		}
	}
	logger->log(NORMAL, L"Hyper-V Vssbackup.cpp ProcessCBTFilesforbackupVMs completed...\n");
}



int copyfilesfromSnapshot(BSTR repositoryPath, BSTR backupType, BSTR backupName, BSTR scheduleName, BSTR vmNametobackup, BSTR vmId, Loggerclass *fileCopylogger, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *))
{
	try
	{
		fileCopylogger->log(NORMAL, L"copyfilesfromSnapshot VM Name: %ws...\n", vmNametobackup);
		
		HRESULT  result;
		//auto vmiter = vmList.begin();		
		//BSTR vmNametobackup = *vmiter;
		std::list<IVssWMComponent*> componentList = GetHyperVComponents(vmNametobackup, repositoryPath, backupName, scheduleName, fileCopylogger);
		if (componentList.empty())
		{
			fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot GetHyperVComponents returned Empty List...\n");
			return 412;
		}
		for (auto itr = componentList.begin(); itr != componentList.end(); ++itr)
		{
			IVssWMComponent *component = *itr;
			PVSSCOMPONENTINFO componentInfo;
			result = component->GetComponentInfo(&componentInfo);//returns information about the component
			CheckHRESULT(result, L"GetComponentInfo");

			fileCopylogger->log(NORMAL, L"copyfilesfromSnapshot got vm to backup. Going to check if full backup required: %ws\n", componentInfo->bstrComponentName);
			bool isBackuprequired = false;
			if (wcscmp(vmNametobackup, componentInfo->bstrComponentName) == 0)
			{
				fileCopylogger->log(NORMAL, L"VM to full backup in copyfilesfromSnapshot: %ws\n", vmNametobackup);
				isBackuprequired = true;
			}
			

			if (!isBackuprequired)
			{
				continue;
			}

			fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot Component Name: %ws\n", componentInfo->bstrComponentName);
			fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot no of files to be copy: %wd\n", componentInfo->cFileCount);
			
			

			for (unsigned i = 0; i < componentInfo->cFileCount; i++)
			{
				_TCHAR volumeName[MAX_PATH + 1] = { 0 };
				CComPtr<IVssWMFiledesc> pFileDesc;
				result = component->GetFile(i, &pFileDesc);
				CheckHRESULT(result, L"GetFile");
				wchar_t* path;
				BSTR fileName, filePath;
				bool isRecursive;
				result = pFileDesc->GetFilespec(&fileName);
				result = pFileDesc->GetPath(&filePath);
				result = pFileDesc->GetRecursive(&isRecursive);
				if (isRecursive)
				{
					fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp copyfilesfromSnapshot recursive so continuing..!");
					continue;
				}
				wchar_t* fileNamew = (wchar_t *)malloc((SysStringLen(fileName)+1) * sizeof(wchar_t));
				wchar_t* filePathw = (wchar_t *)malloc((SysStringLen(filePath)+1) * sizeof(wchar_t));
				wcscpy(fileNamew, fileName);
				wcscat(fileNamew, L"\0");
				wcscpy(filePathw, filePath);
				wcscat(filePathw, L"\0");
				
				if (isRecursive)
				{
					fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp copyfilesfromSnapshot Freeing ComponentInfo for recursive structure..!");
					if(fileNamew!=nullptr){delete[] fileNamew;}
					if(filePathw!=nullptr){delete[] filePathw;}
					continue;
					//path = filePath;
				}
				else
				{	
					if(filePathw[wcslen(filePathw)-1]=='\\')
					{
						fileCopylogger->log(NORMAL, L"No need to add slash\n");
						path = (wchar_t *)malloc((wcslen(filePathw) + 2 + wcslen(fileNamew)) * sizeof(wchar_t));	
						wcscpy(path, filePathw);					
					}
					else
					{
						fileCopylogger->log(NORMAL, L"Adding slash retro\n");
						path = (wchar_t *)malloc((wcslen(filePathw) + 3 + wcslen(fileNamew)) * sizeof(wchar_t));	
						wcscpy(path, filePathw);
						wchar_t* app = (wchar_t *)malloc((wcslen(L"\\")+1) * sizeof(wchar_t));
						wcscpy(app, L"\\");
						wcscat(app, L"\0");
						wcscat(path, app);
					}
					wcscat(path, fileNamew);
					wcscat(path, L"\0");
					fileCopylogger->log(NORMAL, L"Path variable -> %ws\n", path);
				}
				//path = SysAllocString(path);
				//Copying files - filepath in snapshot
				GetVolumePathName(filePathw, volumeName, MAX_PATH);//Returns volume name from the file path
				long vollength = wcslen(volumeName);
				char vol = volumeName[0];
				BSTR snapshotPathforvolume = GetSnapshotDeviceName(vol, backupName, fileCopylogger);
				//BSTR snapshotPathforvolume = SysAllocString(L"test");
				if(snapshotPathforvolume==NULL)
				{
					fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot snapshotPathforvolume is NULL..\n");
					continue;
				}
				else
				{
					fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot snapshotPathforvolume -> %ws..\n", snapshotPathforvolume);
				}

				//Copying files - source folder in snapshot
				BSTR pathwithoutvolumeName = path + vollength;
				BSTR filePathinsnapshot = SysAllocStringLen(L"", wcslen(snapshotPathforvolume) + wcslen(pathwithoutvolumeName) + 2);
				wcscpy(filePathinsnapshot, snapshotPathforvolume);
				wcscat(filePathinsnapshot, L"\\");
				wcscat(filePathinsnapshot, pathwithoutvolumeName);
				wcscat(filePathinsnapshot, L"\0");
				fileCopylogger->log(NORMAL, L"SNAPSHOT PATH: %ws\n", filePathinsnapshot);

				//Copying files - destination folder
				BSTR backupFolderpath = SysAllocStringLen(L"", wcslen(repositoryPath) + wcslen(scheduleName) + wcslen(backupName) + wcslen(componentInfo->bstrComponentName) + wcslen(fileName) + 40);
				wcscpy(backupFolderpath, repositoryPath);
				wcscat(backupFolderpath, scheduleName);
				wcscat(backupFolderpath, L"\\");
				wcscat(backupFolderpath, backupName);
				wcscat(backupFolderpath, L"\\");
				wcscat(backupFolderpath, componentInfo->bstrComponentName);
				wcscat(backupFolderpath, L"\\");
				wcscat(backupFolderpath, fileName);
				wcscat(backupFolderpath, L"\0");


				if (isRecursive)
				{
					fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot isRecursive-> TRUE..!\n");
					/*backupFolder = bstr.Detach();
					fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot BACKUP FOLDER PATH: %ws\n", backupFolder);
					BSTR folderName = wcsrchr(filePathinsnapshot, '\\');
					fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot Folder Name: %ws\n", folderName);

					CComBSTR bstrss(SysAllocString(backupFolder));
					BSTR folder = SysAllocString(folderName);
					bstrss.AppendBSTR(folder);
					BSTR backupFolderPath = bstrss.Detach();
					backupFolderPath = SysAllocString(backupFolderPath);
					filePathinsnapshot = SysAllocString(filePathinsnapshot);

					int status = data_backup_initialization(filePathinsnapshot, backupFolderPath, SysAllocString(L"\\*"));*/

					/*SysFreeString(folder);
					SysFreeString(backupFolderPath);	*/				
					
				}
				else
				{
					/*bstr.AppendBSTR(SysAllocString(L"\\"));				
					bstr.AppendBSTR(SysAllocString(fileName));
					BSTR backupFolderpath = bstr.Detach();
					backupFolderpath = SysAllocString(backupFolderpath);*/
					fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot BACKUP FOLDER PATH: %ws\n", backupFolderpath);
					fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot backupType: %ws\n", backupType);
                                                                                        BOOL b;
					if (((wcsstr(fileName, L".vhd") != NULL) || (wcsstr(fileName, L".avhd") != NULL)) && ((wcscmp(backupType, L"MigrBackup") != 0)))
					{
						//Compress the vhd files
						fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot Going to COMPRESS the VHD File -> %ws!\n", backupFolderpath);
						bool b = CompressFileDirectly(filePathinsnapshot, backupFolderpath, backupName, vmId, fileCopylogger, callBackMethod);
						if (b)
						{
							fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot  COMPRESSION successful.............!\n");
						}
						else
						{
							fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot  COMPRESSION !!!!!!FAILURE!!!!!!!\n");
							if ((wcsstr(fileName, L".vhd") != NULL))
							{
								fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot  RETURNING ERROR SINCE IT IS A VHD FILE..!!!\n");
								return 411;
							}
						}
					}
					else
					{
						fileCopylogger->log(NORMAL, L"Vssbackup.cpp copying file FILE NAME: %ws\n", fileName);
						b = CopyFile(filePathinsnapshot, backupFolderpath, false);
						if (b)
						{
							fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot Success!\n");
						}
						else
						{
							fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot Failure: %d!\n", GetLastError());
							//return 411;
						}
					}
					
				}
				fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp copyfilesfromSnapshot Done backup Freeing memory..!\n");
				if(filePathinsnapshot!=nullptr){SysFreeString(filePathinsnapshot);}
				if(fileNamew!=nullptr){delete[] fileNamew;}
				if(filePathw!=nullptr){delete[] filePathw;}
				if(path!=nullptr){delete[] path;}
				if(backupFolderpath!=nullptr){SysFreeString(backupFolderpath);}
				fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp copyfilesfromSnapshot Done backup for file\n");

			}
			fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp copyfilesfromSnapshot Done backup for component -> %ws..\n", componentInfo->bstrComponentName);
			fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp copyfilesfromSnapshot Freeing ComponentInfo..!");
			result = component->FreeComponentInfo(componentInfo);
				
		}
	}
	catch (exception& e)
	{
		fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp copyfilesfromSnapshot Exception..\n");
		return 400;
	}
	fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp copyfilesfromSnapshot Completed...\n");
	return 0;
}

bool sortMetaDataVector(const std::vector<LONGLONG>& v1, const std::vector<LONGLONG>& v2)
{
	return v1[0] < v2[0];
}

//iterate components. for each component(vm), get it's vhds, access that vhd's cbt file and backup the required bytes to the repository
int doIncrementalBackupforcomponents(BSTR repositoryPath, BSTR backupName, BSTR scheduleName, BSTR vmNametobackup, BSTR vmId, Loggerclass *fileCopylogger, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *))
{
	try
	{
		fileCopylogger->log(NORMAL, L"doIncrementalBackupforcomponents Latest API Incr backup VM: %ws...\n", vmNametobackup);
		
		HRESULT  result;
		//auto vmiter = vmList.begin();		
		//BSTR vmNametobackup = *vmiter;
		std::list<IVssWMComponent*> componentList = GetHyperVComponents(vmNametobackup, repositoryPath, backupName, scheduleName, fileCopylogger);
		if (componentList.empty())
		{
			fileCopylogger->log(NORMAL, L"Vssbackup.cpp doIncrementalBackupforcomponents GetHyperVComponents returned Empty List...\n");
			return 412;
		}
		for (auto itr = componentList.begin(); itr != componentList.end(); ++itr)
		{
			IVssWMComponent *component = *itr;
			PVSSCOMPONENTINFO componentInfo;
			result = component->GetComponentInfo(&componentInfo);//returns information about the component
			CheckHRESULT(result, L"GetComponentInfo");

			fileCopylogger->log(NORMAL, L"doIncrementalBackupforcomponents got vm to backup. Going to check if full backup required: %ws\n", componentInfo->bstrComponentName);
			bool isBackuprequired = false;
			//for (auto vmitr = vmList.begin(); vmitr != vmList.end(); ++vmitr)
			//{
				//BSTR vmName = *vmitr;
				if (wcscmp(vmNametobackup, componentInfo->bstrComponentName) == 0)
				{
					fileCopylogger->log(NORMAL, L"VM to full backup in doIncrementalBackupforcomponents: %ws\n", vmNametobackup);
					isBackuprequired = true;
				}
			//}

			if (!isBackuprequired)
			{
				continue;
			}

			fileCopylogger->log(NORMAL, L"Vssbackup.cpp doIncrementalBackupforcomponents Component Name: %ws\n", componentInfo->bstrComponentName);
			fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot no of files to be copy: %wd\n", componentInfo->cFileCount);
			

			for (unsigned i = 0; i < componentInfo->cFileCount; i++)
			{
				_TCHAR volumeName[MAX_PATH + 1] = { 0 };
				CComPtr<IVssWMFiledesc> pFileDesc;
				result = component->GetFile(i, &pFileDesc);
				CheckHRESULT(result, L"GetFile");
				wchar_t* path;
				BSTR fileName, filePath;
				result = pFileDesc->GetFilespec(&fileName);
				result = pFileDesc->GetPath(&filePath);
				DWORD backupTypeMask;
				result = pFileDesc->GetBackupTypeMask(&backupTypeMask);
				wchar_t* fileNamew = (wchar_t *)malloc((SysStringLen(fileName)+10) * sizeof(wchar_t));
				wchar_t* filePathw = (wchar_t *)malloc((SysStringLen(filePath)+10) * sizeof(wchar_t));
				wcscpy(fileNamew, fileName);
				wcscat(fileNamew, L"\0");
				wcscpy(filePathw, filePath);
				wcscat(filePathw, L"\0");
				
				if (!(wcsstr(fileNamew, L".vhd") != nullptr || wcsstr(fileNamew, L".avhd") != nullptr))
				{
					continue;
				}

				if(filePathw[wcslen(filePathw)-1]=='\\')
				{
					fileCopylogger->log(NORMAL, L"No need to add slash\n");
					path = (wchar_t *)malloc((wcslen(filePathw) + 2 + wcslen(fileNamew)) * sizeof(wchar_t));	
					wcscpy(path, filePathw);					
				}
				else
				{
					fileCopylogger->log(NORMAL, L"Adding slash retro\n");
					path = (wchar_t *)malloc((wcslen(filePathw) + 3 + wcslen(fileNamew)) * sizeof(wchar_t));	
					wcscpy(path, filePathw);
					wchar_t* app = (wchar_t *)malloc((wcslen(L"\\")+1) * sizeof(wchar_t));
					wcscpy(app, L"\\");
					wcscat(app, L"\0");
					wcscat(path, app);
				}
				wcscat(path, fileNamew);
				wcscat(path, L"\0");
				fileCopylogger->log(NORMAL, L"Path variable -> %ws\n", path);
				

				//path = SysAllocString(path);
				//Copying files - filepath in snapshot
				GetVolumePathName(filePathw, volumeName, MAX_PATH);//Returns volume name from the file path
				long vollength = wcslen(volumeName);
				char vol = volumeName[0];
				BSTR snapshotPathforvolume = GetSnapshotDeviceName(vol, backupName, fileCopylogger);
				if(snapshotPathforvolume==NULL)
				{
					fileCopylogger->log(NORMAL, L"Vssbackup.cpp doIncrementalBackupforcomponents snapshotPathforvolume is NULL..\n");
					continue;
				}
				else
				{
					fileCopylogger->log(NORMAL, L"Vssbackup.cpp doIncrementalBackupforcomponents snapshotPathforvolume -> %ws..\n", snapshotPathforvolume);
				}

				//Copying files - source folder in snapshot
				BSTR pathwithoutvolumeName = path + vollength;
				BSTR filePathinsnapshot = SysAllocStringLen(L"", wcslen(snapshotPathforvolume) + wcslen(pathwithoutvolumeName) + 2);
				wcscpy(filePathinsnapshot, snapshotPathforvolume);
				wcscat(filePathinsnapshot, L"\\");
				wcscat(filePathinsnapshot, pathwithoutvolumeName);
				wcscat(filePathinsnapshot, L"\0");
				fileCopylogger->log(NORMAL, L"SNAPSHOT PATH: %ws\n", filePathinsnapshot);

				/*char *repositoryPathchar= _com_util::ConvertBSTRToString(repositoryPath);
				char *schedulechar= _com_util::ConvertBSTRToString(scheduleName);
				char *backupchar= _com_util::ConvertBSTRToString(backupName);
				char *fileNamechar= _com_util::ConvertBSTRToString(fileName);
				char *vmNamechar= _com_util::ConvertBSTRToString(componentInfo->bstrComponentName);*/

				//Copying files - destination folder

				wchar_t* backupFolder = new wchar_t[wcslen(repositoryPath) + wcslen(scheduleName) + wcslen(backupName) + wcslen(componentInfo->bstrComponentName) +4];				
				wcscpy(backupFolder, repositoryPath);
				wcscat(backupFolder, scheduleName);
				wcscat(backupFolder, L"\\");
				wcscat(backupFolder, backupName);
				wcscat(backupFolder, L"\\");
				wcscat(backupFolder, componentInfo->bstrComponentName);
				wcscat(backupFolder, L"\\");
				wcscat(backupFolder, L"\0");
				fileCopylogger->log(NORMAL, L"backupFolder: %ws\n", backupFolder);

				//access cbt of this vhd file and process byte-wise operations

				/*
				We have 3 files.
				1. CBT file -> where the data from driver are distributed from master cbt file
				2. bin file -> where the actual bytes of the vhd or the avhd are stored.
				3. metadata file -> stores the cbt data for that vhd for that backup in that schedule
				2 and 3 are in repository path while 1 is in the hyper-v host
				*/

				//Rename CBT file amd open the renamed file
				wchar_t* fileNamewithoutextensiontemp =  new wchar_t[wcslen(fileName) + 1];
				wcscpy(fileNamewithoutextensiontemp, fileName);
				wchar_t* tempPointer = wcsrchr(fileNamewithoutextensiontemp, L'.');
				if(tempPointer)
				{
					fileCopylogger->log(NORMAL, L"Removing extension from vhd filename..->%ws\n", tempPointer);
					*tempPointer=L'\0';
				}
				wchar_t* fileNamewithoutextension = new wchar_t[wcslen(fileNamewithoutextensiontemp) + 1];
				wcscpy(fileNamewithoutextension, fileNamewithoutextensiontemp);
				wcscat(fileNamewithoutextension, L"\0");
				
				fileCopylogger->log(NORMAL, L"fileNamewithoutextension: %ws\n", fileNamewithoutextension);
				FILE* VHDCBTFile;
				wchar_t* VHDCBTtempfilepath = new wchar_t[wcslen(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\") + wcslen(scheduleName) + wcslen(componentInfo->bstrComponentName) + wcslen(fileNamewithoutextension) + wcslen(backupName) + 8];
				wcscpy(VHDCBTtempfilepath, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\");
				wcscat(VHDCBTtempfilepath, scheduleName);
				wcscat(VHDCBTtempfilepath, L"\\");
				wcscat(VHDCBTtempfilepath, componentInfo->bstrComponentName);
				wcscat(VHDCBTtempfilepath, L"\\");
				wcscat(VHDCBTtempfilepath, fileNamewithoutextension);
				wcscat(VHDCBTtempfilepath, L"_");
				wcscat(VHDCBTtempfilepath, backupName);
				wcscat(VHDCBTtempfilepath, L".txt");
				wcscat(VHDCBTtempfilepath, L"\0");
				fileCopylogger->log(NORMAL, L"VHDCBTtempfilepath: %ws\n", VHDCBTtempfilepath);

				_wfopen_s(&VHDCBTFile, VHDCBTtempfilepath, L"rb");

				FILE* VHDCBTFile_hc;
				wchar_t* hcCBTfilepath = NULL;
				logger->log(NORMAL, L"Construct hcCBTpath:\n");
                hcCBTfilepath = new wchar_t[wcslen(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\") + wcslen(scheduleName) + wcslen(componentInfo->bstrComponentName) + wcslen(fileNamewithoutextension) + wcslen(L"_healthcheck.txt") + 3];
                wcscpy(hcCBTfilepath, L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\");
                wcscat(hcCBTfilepath, scheduleName);
                wcscat(hcCBTfilepath, L"\\");
                wcscat(hcCBTfilepath, componentInfo->bstrComponentName);
                wcscat(hcCBTfilepath, L"\\");
                wcscat(hcCBTfilepath, fileNamewithoutextension);
                wcscat(hcCBTfilepath, L"_healthcheck.txt");
                wcscat(hcCBTfilepath, L"\0");
                logger->log(NORMAL, L"hcCBTfilepath: %ws\n", hcCBTfilepath);

                _wfopen_s(&VHDCBTFile_hc, hcCBTfilepath, L"rb");
                                
				wchar_t* mFilePath = new wchar_t[wcslen(backupFolder) + wcslen(fileName) + wcslen(L"metadata.txt") + 1];
				wcscpy(mFilePath, backupFolder);
				wcscat(mFilePath, fileName);
				wcscat(mFilePath, L"metadata.txt");	
				wcscat(mFilePath, L"\0");			
				
				fileCopylogger->log(NORMAL, L"mFilePath: %ws\n", mFilePath);

				wchar_t* backupFolderCopy = new wchar_t[wcslen(repositoryPath) + wcslen(scheduleName) +wcslen(backupName) + wcslen(componentInfo->bstrComponentName) +4];				
				wcscpy(backupFolderCopy, repositoryPath);
				wcscat(backupFolderCopy, scheduleName);
				wcscat(backupFolderCopy, L"\\");
				wcscat(backupFolderCopy, backupName);
				wcscat(backupFolderCopy, L"\\");
				wcscat(backupFolderCopy, componentInfo->bstrComponentName);
				wcscat(backupFolderCopy, L"\\");
				wcscat(backupFolderCopy, L"\0");
				

				wchar_t* backupFilepath = new wchar_t[wcslen(backupFolderCopy)+1 + wcslen(fileName) + wcslen(L"backup.bin")];
				wcscpy(backupFilepath, backupFolderCopy);
				wcscat(backupFilepath, fileName);
				wcscat(backupFilepath, L"backup.bin");
				wcscat(backupFilepath, L"\0");


							
				fileCopylogger->log(NORMAL, L"backupFilepath: %ws\n", backupFilepath);

				int size = 1024, pos;
				int c;
				char *byteCount = (char *)malloc(size);
				char *byteOffset = (char *)malloc(size);
				char *byteOffsetlow = (char *)malloc(size);
				char *byteOffsethigh = (char *)malloc(size);

				ULONG byteCountvalue;
				LONGLONG byteOffsetvalue;
				DWORD byteOffsetlowvalue;
				LONG byteOffsethighvalue;
                                
                if((wcsstr(fileNamew, L".avhd") != nullptr) && (backupTypeMask == 66821))
				{
					//this is a snapshot/checkpoint file. Backup the full file
					fileCopylogger->log(NORMAL, L"snapshot or checkpoint file. Hence backing up the full file..\n");
					wchar_t* backupavhdFilepath = new wchar_t[wcslen(backupFolderCopy)+1 + wcslen(fileName)];
					wcscpy(backupavhdFilepath, backupFolderCopy);
					wcscat(backupavhdFilepath, fileName);
					wcscat(backupavhdFilepath, L"\0");
					bool b = CompressFileDirectly(filePathinsnapshot, backupavhdFilepath, backupName, vmId, fileCopylogger, callBackMethod);
					if (b)
					{
						fileCopylogger->log(NORMAL, L"Vssbackup.cpp doIncrementalbackupforcomponents  COMPRESSION of AVHD file successful.............!\n");
					}
					else
					{
						fileCopylogger->log(NORMAL, L"Vssbackup.cpp doIncrementalbackupforcomponents of AVHD file  COMPRESSION !!!!!!FAILURE!!!!!!!\n");
						/*if ((wcsstr(fileName, L".vhd") != NULL))
						{
							fileCopylogger->log(NORMAL, L"Vssbackup.cpp copyfilesfromSnapshot  RETURNING ERROR SINCE IT IS A VHD FILE..!!!\n");
							return 411;
						}*/
					}

				}
                else
                {
                    HANDLE VHDpathwheredatatobereadHandle = CreateFile(filePathinsnapshot, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
                    if (VHDpathwheredatatobereadHandle == INVALID_HANDLE_VALUE)
                    {
                        fileCopylogger->log(NORMAL, L"File not found for storing the size\n");
                        return 407;
                    }
                    DWORD higherBytes;
                    DWORD lowerBytes = GetFileSize(VHDpathwheredatatobereadHandle, &higherBytes);
                    long long filesize = (((long long) higherBytes) << 32) | lowerBytes;
                    _bstr_t fileSize = (long long)filesize;
                    fileCopylogger->log(NORMAL, L"Total File Size : %lld\n", fileSize);
                    BSTR type = SysAllocStringLen(L"", 16);
                    wcscpy(type, L"MaximumRead");
                    _bstr_t stepid = L"-2";
                    fileCopylogger->log(NORMAL, L"CallBackMethod: to store file size");
                    long long sizeFromDB = (*callBackMethod)(L"BACKUP", stepid, backupName, vmId, filePathinsnapshot, type, fileSize, stepid);
                    CloseHandle(VHDpathwheredatatobereadHandle);

                    std::vector<std::vector<LONGLONG>> metaDataVector;
                    std::vector<LONGLONG> writeEntryFromMetaData;
                    if(VHDCBTFile_hc) {
                            ifstream cbtFileIterator_hc(hcCBTfilepath);
                            while(cbtFileIterator_hc>>byteCountvalue>>byteOffsetvalue>>byteOffsetlowvalue>>byteOffsethighvalue){
                                writeEntryFromMetaData.push_back(byteOffsetvalue);
                                writeEntryFromMetaData.push_back(byteCountvalue);
                                metaDataVector.push_back(writeEntryFromMetaData);
                                writeEntryFromMetaData.clear();
                            }
                            cbtFileIterator_hc.close();
                    }
                    if (VHDCBTFile)
                    {
                        ifstream cbtFileIterator(VHDCBTtempfilepath);
                        while(cbtFileIterator>>byteCountvalue>>byteOffsetvalue>>byteOffsetlowvalue>>byteOffsethighvalue){
                            writeEntryFromMetaData.push_back(byteOffsetvalue);
                            writeEntryFromMetaData.push_back(byteCountvalue);
                            metaDataVector.push_back(writeEntryFromMetaData);
                            writeEntryFromMetaData.clear();
                        }
                        cbtFileIterator.close();
                    }
                    if (!metaDataVector.empty())
                    {
                        fileCopylogger->log(NORMAL, L"Vssbackup.cpp doIncrementalbackupforcomponents VHDCBTFile is NOT NULL..\n");
                        FILE* file;
                        FILE* mFile;
                        fileCopylogger->log(NORMAL, L"Reading from CBT file for VHD file..\n");
                        _wfopen_s(&mFile, mFilePath, L"a");
                        _wfopen_s(&file, backupFilepath, L"ab+");

                        fileCopylogger->log(NORMAL, L"going to call vector sort");
                        std::sort(metaDataVector.begin(), metaDataVector.end(), sortMetaDataVector);

                        fileCopylogger->log(NORMAL, L"metaDataVector size = %lld going to remove duplicates", metaDataVector.size());
                        int metaDataVectorItr = 0;
                        while(metaDataVectorItr<metaDataVector.size()-1){
                            if(metaDataVector[metaDataVectorItr][0]!=metaDataVector[metaDataVectorItr+1][0]){
                                if((metaDataVector[metaDataVectorItr][0] <= metaDataVector[metaDataVectorItr+1][0]) && ((metaDataVector[metaDataVectorItr][1] + metaDataVector[metaDataVectorItr][0]) > metaDataVector[metaDataVectorItr+1][0])){
                                    long long offsetDiffRange = (metaDataVector[metaDataVectorItr+1][1]+metaDataVector[metaDataVectorItr+1][0]) - (metaDataVector[metaDataVectorItr][1] + metaDataVector[metaDataVectorItr][0]);
                                    if(offsetDiffRange<=0){
                                        metaDataVector.erase(metaDataVector.begin() + metaDataVectorItr + 1);
                                        //metaDataVectorItr--;
                                    }
                                    else{
                                        metaDataVector[metaDataVectorItr][1] += offsetDiffRange;
                                        //metaDataVectorItr--;
                                    }
                                }
                                else{
                                    metaDataVectorItr++;
                                }
                            }
                            else{
                                if(!(metaDataVector[metaDataVectorItr][1] >= metaDataVector[metaDataVectorItr+1][1])){
                                    metaDataVector[metaDataVectorItr][1] = metaDataVector[metaDataVectorItr+1][1];
                                }
                                metaDataVector.erase(metaDataVector.begin() + metaDataVectorItr + 1);
                                //metaDataVectorItr--;
                            }
                        }

                        fileCopylogger->log(NORMAL, L"metaDataVector size obtained after removing duplicates -> %lld", metaDataVector.size());

                        HANDLE VHDpathwheredatatobereadHandle = CreateFile(filePathinsnapshot, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
                        if (VHDpathwheredatatobereadHandle == INVALID_HANDLE_VALUE)
                        {
                                fileCopylogger->log(NORMAL, L"File not found\n");
                                return 407;
                        }

                        for (metaDataVectorItr = 0; metaDataVectorItr < metaDataVector.size(); metaDataVectorItr++){
                            LARGE_INTEGER liDistanceToMove;
                            LARGE_INTEGER filePointer;
                            liDistanceToMove.QuadPart =  metaDataVector[metaDataVectorItr][0];//byteOffsetvalue;
                            BOOL isFilePointermoved = SetFilePointerEx(VHDpathwheredatatobereadHandle, liDistanceToMove, &filePointer, FILE_BEGIN);
                            if(!isFilePointermoved)
                            {
                                    fileCopylogger->log(NORMAL, L"Error in SetFilePointerEx..!\n");
                                    return 407;
                            }
                            //read the vhd file
                            BYTE *buffer = new BYTE[metaDataVector[metaDataVectorItr][1]+1];//[byteCountvalue+1];
                            DWORD lpNumberOfBytesRead = NULL;
                            BOOL bReadFile = ReadFile(VHDpathwheredatatobereadHandle, buffer, metaDataVector[metaDataVectorItr][1], &lpNumberOfBytesRead, NULL);
                            if (!bReadFile)
                            {
                                    fileCopylogger->log(NORMAL, L"Error in reading backup file %d\n", GetLastError());
                                    return 407;
                            }

                            if (lpNumberOfBytesRead > 0) //TODO have to control loop iterations based on filesize/bufSize
                            {
                                    //write bytes to bin file
                                    if(file)
                                    {
                                            fwrite(buffer, sizeof(BYTE), lpNumberOfBytesRead, file);
                                    }
                                    //write data to metadata file of this specific backup
                                    if (mFile)
                                    {
                                            fwprintf_s(mFile, L"%lu\t%I64d\t%lu\t%ld\t", lpNumberOfBytesRead,  metaDataVector[metaDataVectorItr][0], metaDataVector[metaDataVectorItr][0], byteOffsethighvalue);
                                    }
                            }
                            else
                            {
                                    logger->log(NORMAL, L"Error in reading lpNumberOfBytesRead <=0..!\n");
                            }
                            if(buffer!=nullptr){delete[] buffer;}
                        }
                        CloseHandle(VHDpathwheredatatobereadHandle);

                        if(mFile)
                        {
                                fclose(mFile);
                        }
                        if(file)
                        {
                                fclose(file);
                        }
                        fileCopylogger->log(NORMAL, L"One file done..!\n");
                        if(VHDCBTFile)
                        {
                            fclose(VHDCBTFile);
                            fileCopylogger->log(NORMAL, L"Closed VHDCBTFile..!\n");
                            //if backup successful, clear CBT file of that vhd of that backup of that schedule. ie, we need to clear yourFilePath
                            //this will delete the CBT file of that specific VM of that specific schedule. make sure that processmasterCBT file creates the CBT file for the VM if not present
                            //wchar_t* fileNametodelete = (wchar_t*)malloc((wcslen(VHDCBTtempfilepath) + 1)*sizeof(wchar_t));
                            //mbstowcs(fileNametodelete, VHDCBTtempfilepath, strlen(VHDCBTtempfilepath)+1);//Plus null
                            LPWSTR filetodelete = VHDCBTtempfilepath;
                            fileCopylogger->log(NORMAL, L"Going to DELETE the CBT FILE -> %ws\n",filetodelete);
                            bool isDeleted = DeleteFile(filetodelete);
                            if(!isDeleted)
                            {
                                    fileCopylogger->log(NORMAL, L"NOT ABLE TO DELETE THE CBT FILE -> %ws\n",filetodelete);
                            }
                        }
                        if(VHDCBTFile_hc) {
                            fclose(VHDCBTFile_hc);
                            logger->log(NORMAL, L"Closed Healthcheck CBTFile_hc..!\n");
                            LPWSTR filetodelete = hcCBTfilepath;
                            fileCopylogger->log(NORMAL, L"Going to DELETE the CBT FILE -> %ws\n",filetodelete);
                            bool isDeleted = DeleteFile(filetodelete);
                            if(!isDeleted) {
                                fileCopylogger->log(NORMAL, L"NOT ABLE TO DELETE THE CBT FILE -> %ws\n",filetodelete);
                            }
                        }
                    }
                }
                fileCopylogger->log(NORMAL, L"Going to delete variables.!\n");
                if(fileNamew!=nullptr){delete[](fileNamew);}
                if(filePathw!=nullptr){delete[](filePathw);}
                if(filePathinsnapshot!=nullptr){SysFreeString(filePathinsnapshot);}
                //SysFreeString(pathwithoutvolumeName);
                if(backupFolder!=nullptr){delete[] backupFolder;}
                if(backupFolderCopy!=nullptr){delete[] backupFolderCopy;}
                //if(schedulechar!=nullptr){delete[] schedulechar;}
                //if(backupchar!=nullptr){delete[] backupchar;}
                //if(vmNamechar!=nullptr){delete[] vmNamechar;}
                //if(fileNamechar!=nullptr){delete[] fileNamechar;}
                //delete[] VHDCBTfilepath;
                if(VHDCBTtempfilepath!=nullptr){delete[] VHDCBTtempfilepath;}
                if(hcCBTfilepath!=nullptr){delete[] hcCBTfilepath;}
                //SysFreeString(VHDCBTfilepathws);
                //SysFreeString(VHDCBTtempfilepathws);
                //if(repositoryPathchar!=nullptr){delete[] repositoryPathchar;}
                if(path!=nullptr){delete[] path;}
                fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp doIncrementalbackupforcomponents Done backup for file\n");
			}
			result = component->FreeComponentInfo(componentInfo);
			//CheckHRESULT(result,L"FreeComponentInfo");
			//SysFreeString(createdDirectory);
		}

		fileCopylogger->log(NORMAL, L"Vssbackup.cpp doIncrementalbackupforcomponents ended successfully...\n");
		return 0;
	}
	catch (exception& e)
	{
		return 400;
	}
}

BSTR GetSnapshotDeviceName(char volumeName, BSTR backupName, Loggerclass *fileCopylogger)
{
	fileCopylogger->log(NORMAL, L"Vssbackup.cpp GetSnapshotDeviceName started..!\n");
	char volumeArray[2];
	volumeArray[0]=volumeName;
	volumeArray[1]='\0';
	String^ volumeNameString = gcnew String(volumeArray, 0, strlen(volumeArray));
	String^ snapshotString = getsnapshotNamefromFile(backupName, volumeNameString, fileCopylogger);
	fileCopylogger->logchar(NORMAL, "Vssbackup.cpp GetSnapshotDeviceName volume for which snpashot name to be found: %s\n", volumeArray);
	if(snapshotString!=nullptr)
	{
		fileCopylogger->log(NORMAL, L"Vssbackup.cpp GetSnapshotDeviceName Snapshot Name is NOT NULL..!\n");
		std::wstring result = msclr::interop::marshal_as<std::wstring>(snapshotString);
		wchar_t* snapshotName = (wchar_t*)malloc((wcslen(result.c_str())+1) * sizeof(wchar_t));
		wcscpy(snapshotName, result.c_str());
		wcscat(snapshotName, L"\0");
		fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp Vssbackup Snapshot Details acquired -> %ws\n",snapshotName);
		return snapshotName;
	}
	else
	{
		fileCopylogger->log(NORMAL, L"Vssbackup.cpp GetSnapshotDeviceName Snapshot Name is NULL..!\n");
		return NULL;
	}

}

bool ShouldAddComponent(WriterComp& component)
{
	// Component should not be added if
	// 1) It is not selectable for backup and 
	// 2) It has a selectable ancestor
	// Otherwise, add it. 

	if (component.isSelectable)
	{
		return true; 
	}

	return !component.isAncestorSelectable();

}

int LoadBackupCompandWriterMetadatadocs(BSTR vmbackedupPath, BSTR vmName, Loggerclass *fileCopylogger)
{
	try
	{
		fileCopylogger->log(NORMAL, L"Vssbackup.cpp LoadBackupCompandWriterMetadatadocs started...\n");

		CComBSTR bstrss(vmbackedupPath);		
		BSTR backupcomponentsdocxmlfilename = SysAllocString(L"\\BackupComponents.xml");
		BSTR slash = SysAllocString(L"\\");
		bstrss.AppendBSTR(slash);
		bstrss.AppendBSTR(SysAllocString(vmName));
		bstrss.AppendBSTR(backupcomponentsdocxmlfilename);
		BSTR backupcomponentsdoc = bstrss.Detach();

		CComBSTR bstrs(vmbackedupPath);		
		BSTR writerdocxmlfilename = SysAllocString(L"\\HyperVVSSWriter.xml");
		bstrs.AppendBSTR(slash);
		bstrs.AppendBSTR(SysAllocString(vmName));
		bstrs.AppendBSTR(writerdocxmlfilename);
		BSTR writerdoc = bstrs.Detach();

		fileCopylogger->log(NORMAL, L"Vssbackup.cpp LoadBackupCompandWriterMetadatadocs backupcomponentsdoc -> %ws\n", backupcomponentsdoc);
		fileCopylogger->log(NORMAL, L"Vssbackup.cpp LoadBackupCompandWriterMetadatadocs writerdoc -> %ws\n", writerdoc);

		HRESULT  result;
		FILE *f1;
		FILE *f2;
		int size;
		_wfopen_s(&f1, backupcomponentsdoc, L"r, ccs=UTF-16LE");
		_wfopen_s(&f2, writerdoc, L"r, ccs=UTF-16LE");
		if (f1 == NULL)
		{
			if(backupcomponentsdoc!=nullptr){SysFreeString(backupcomponentsdoc);}
			if(writerdoc!=nullptr){SysFreeString(writerdoc);}
			fileCopylogger->log(NORMAL, L"Error in reading BackupComponents file\n");
			return 1;
		}
		if (f2 == NULL)
		{
			if(backupcomponentsdoc!=nullptr){SysFreeString(backupcomponentsdoc);}
			if(writerdoc!=nullptr){SysFreeString(writerdoc);}
			fileCopylogger->log(NORMAL, L"Error in reading writer file\n");
			return 1;
		}

		size = file_size(f1);
		fileCopylogger->log(NORMAL, L"Total characters in backup document are %d\n", size);
		wchar_t* backupXML = new wchar_t[size];
		wchar_t temp;
		rewind(f1);
		temp = fgetwc(f1);
		int i = 0;
		while (temp != WEOF)
		{
			backupXML[i] = temp;
			temp = fgetwc(f1);
			i = i + 1;
		}
		size = file_size(f2);
		fileCopylogger->log(NORMAL, L"Total characters in writer metadata document are %d\n", size);
		wchar_t* writerXML = new wchar_t[size];
		rewind(f2);
		temp = fgetwc(f2);
		i = 0;
		while (temp != WEOF)
		{
			writerXML[i] = temp;
			temp = fgetwc(f2);
			i = i + 1;
		}
		if(f2)
		{
			fclose(f2);
		}
		if(f1)
		{
			fclose(f1);
		}
		
		result = CreateVssBackupComponents(&pRestore);
		CheckHRESULT(result, L"CreateVssBackupComponents");

		result = pRestore->InitializeForRestore(backupXML);
		CheckHRESULT(result, L"InitializeForRestore");

		result = CreateVssExamineWriterMetadata(writerXML, &pWriterMetadata);
		CheckHRESULT(result, L"CreateVssExamineWriterMetadata");

		fileCopylogger->log(NORMAL, L"Success in loading backup document and writer metadata document\n");

		if(backupcomponentsdoc!=nullptr){SysFreeString(backupcomponentsdoc);}
		if(writerdoc!=nullptr){SysFreeString(writerdoc);}

		return 0;

	}
	catch (exception& e)
	{
		return 1;
	}
}

std::list<IVssWMComponent*> GetComponentsToRestore(BSTR vmName, bool isoldVMdeletebool)
{
	logger->log(NORMAL, L"VssBackup.cpp GetComponentsToRestore method starts...\n");
	//1. Iterate BackupComp doc and call setselectedforrestore on required components
	//2. Iterate writer metadata doc and add the required components to the list that is to be returned

	std::list<IVssWMComponent*> componentListtorestore;
	std::list<IVssWMComponent*> emptyList;
		
	try
	{	
		if(pRestore == NULL)
		{
			return emptyList;
		}

		HRESULT  result;
		
		if(isoldVMdeletebool)//for disk restore and create new vm, don't need to do the below VSS steps
		{
			// Add Hyper-V writer
			VSS_ID writerIdd;
			wchar_t* clsid_str = L"{66841cd4-6ded-4f4b-8f17-fd23f8ddc3de}";
			CLSIDFromString(clsid_str, &writerIdd);
			result = pRestore->EnableWriterClasses((const VSS_ID *)&writerIdd, 1);
			CheckHRESULT(result, L"EnableWriterClasses");


			result = pRestore->GatherWriterMetadata(&pRestoreAsync);
			CheckHRESULT(result, L"GatherWriterMetadata");

			logger->log(NORMAL, L"Gathering metadata from writers...\n");
			result = pRestoreAsync->Wait();
			CheckHRESULT(result, L"GatherWriterMetadataWait");

			pRestoreAsync->QueryStatus(&result, NULL);
			if (result != VSS_S_ASYNC_FINISHED)
			{
				if (SUCCEEDED(result)) 
				{
					logger->log(NORMAL, L"GatherWriterMetadata_QueryStatus Failed..!\n");
					CheckHRESULT(result, L"GatherWriterMetadata_QueryStatus");			
					return emptyList;
				}
			}

			IVssWriterComponentsExt *backedupComponents;
			result = pRestore->GetWriterComponents(0, &backedupComponents);
			CheckHRESULT(result, L"GetWriterComponents");


			UINT pcComponents;
			result = backedupComponents->GetComponentCount(&pcComponents);
			CheckHRESULT(result, L"GetComponentCount");

			for (unsigned i = 0; i < pcComponents; i++)
			{
				IVssComponent *component;
				result = backedupComponents->GetComponent(i, &component);
				CheckHRESULT(result, L"GetComponent");

				BSTR backedupComponentName;
				VSS_COMPONENT_TYPE backepComponentType;
				BSTR backedupComponentLogicalPath;

				result = component->GetComponentName(&backedupComponentName);
				CheckHRESULT(result, L"GetComponentName");

				result = component->GetComponentType(&backepComponentType);
				CheckHRESULT(result, L"GetComponentType");

				/*result = component->GetLogicalPath(&backedupComponentLogicalPath);
				CheckHRESULT(result, L"GetLogicalPath ");*/


				if (wcscmp(vmName, backedupComponentName) != 0)
				{
					logger->log(NORMAL, L"Vssbackup.cpp GetComponentsToRestore Iterating components from BackupComponents file No need to restore : %ws\n", backedupComponentName);
					continue;
				}

				logger->log(NORMAL, L"Vssbackup.cpp GetComponentsToRestore Component selected for restore : %ws\n", backedupComponentName);
				result = pRestore->SetSelectedForRestore(writerIdd, backepComponentType, NULL, backedupComponentName, true);
				logger->log(NORMAL, L"Hyper-V Vssbackup.cpp GetComponentsToRestore SetSelectedForRestore.HRESULT-> 0x%08lx..!\n",result);
				//CheckHRESULT(result, L"SetSelectedForRestore");
			
			}

			logger->log(NORMAL, L"Calling PreRestore\n");
			result = pRestore->PreRestore(&pRestoreAsync);
			CheckHRESULT(result, L"PreRestore");

			result = pRestoreAsync->Wait();
			CheckHRESULT(result, L"PreRestoreWait");

			pRestoreAsync->QueryStatus(&result, NULL);
			if (result != VSS_S_ASYNC_FINISHED)
			{
				if (SUCCEEDED(result)) 
				{
					logger->log(NORMAL, L"PreRestore_QueryStatus Failed..!\n");
					CheckHRESULT(result, L"PreRestore_QueryStatus");			
					return emptyList;
				}
			}

		}

		UINT writerComponents;
		UINT writerIncludeFiles;
		UINT writerExcludeFiles;
		result = pWriterMetadata->GetFileCounts(&writerIncludeFiles, &writerExcludeFiles, &writerComponents);//returns the number of components
		CheckHRESULT(result, L"GetFileCounts");

		for (unsigned i = 0; i < writerComponents; i++)
		{
			IVssWMComponent *component;
			result = pWriterMetadata->GetComponent(i, &component);//obtains a Writer Metadata Document for a specified backup component
			CheckHRESULT(result, L"GetComponent");

			PVSSCOMPONENTINFO componentInfo;
			result = component->GetComponentInfo(&componentInfo);//returns information about the component
			CheckHRESULT(result, L"GetComponentInfo");


			if (wcscmp(vmName, componentInfo->bstrComponentName) != 0)
			{
				logger->log(NORMAL, L"Vssbackup.cpp GetComponentsToRestore Iterating components from Writer file No need to restore : %ws\n", componentInfo->bstrComponentName);
				continue;
			}

			//add to list
			componentListtorestore.push_back(component);
		}

		pRestore->FreeWriterMetadata();

	}
	catch (exception& ex)
	{
		logger->log(NORMAL, L"Vssbackup.cpp GetComponentsToRestore Exception message: %ws\n",ex.what());
		return emptyList;
	}

	
	return componentListtorestore;

}

int restorefilesfromFullBackup(std::list<IVssWMComponent*> componentListtoRestore, BSTR vmbackedupPath, BSTR vmName, bool isDiskRestore, bool isoldVMdeletebool, BSTR vmId, BSTR restoreId, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *))
{
	try
	{
		logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup started...");
		HRESULT  result;
		for (auto itr = componentListtoRestore.begin(); itr != componentListtoRestore.end(); ++itr)
		{
			IVssWMComponent *component=*itr;
				PVSSCOMPONENTINFO componentInfo;
				result = component->GetComponentInfo(&componentInfo);//returns information about the component
				CheckHRESULT(result, L"GetComponentInfo");


				for (unsigned i = 0; i < componentInfo->cFileCount; i++)
				{
					CComPtr<IVssWMFiledesc> pFileDesc;
					result = component->GetFile(i, &pFileDesc);
					CheckHRESULT(result, L"GetFile");
					_TCHAR volumeName[MAX_PATH + 1] = { 0 };
					BSTR filespec, filePath;
					bool isRecursive;
					result = pFileDesc->GetFilespec(&filespec);
					result = pFileDesc->GetPath(&filePath);
					result = pFileDesc->GetRecursive(&isRecursive);
					
					if(isDiskRestore)
					{
						if ((wcsstr(filespec, L".vhd") == NULL) && (wcsstr(filespec, L".avhd") == NULL))
						{
							//not a harddisk. so continuing
							logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup isDiskrestore true Filename -> %ws : Not a VHD. Continuing...", filespec);
							continue;
						}
					}

					logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup File properties - filespec: %ws\n", filespec);
					logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup File properties - filepath: %ws\n", filePath);

					BSTR backupFolderwithoutslash = SysAllocStringLen(L"", wcslen(vmbackedupPath) + wcslen(vmName) + 2);
					wcscpy(backupFolderwithoutslash, vmbackedupPath);
					wcscat(backupFolderwithoutslash, L"\\");
					wcscat(backupFolderwithoutslash, vmName);
					wcscat(backupFolderwithoutslash, L"\0");

					BSTR backupFolder = SysAllocStringLen(L"", wcslen(vmbackedupPath) + wcslen(vmName) + 3);
					wcscpy(backupFolder, vmbackedupPath);
					wcscat(backupFolder, L"\\");
					wcscat(backupFolder, vmName);
					wcscat(backupFolder, L"\\");
					wcscat(backupFolder, L"\0");

					BSTR backupFolderpath = L"";
					BSTR actualFilepath = L"";
					BSTR backupFilepath = L"";

					if (isRecursive)   
					{
						logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup isRecursive-> TRUE..!\n");
						/*BSTR folderName = wcsrchr(filePath, '\\');
						logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup Folder Name: %ws\n", folderName);

						CComBSTR bstrss(backupFolderwithoutslash);
						
						BSTR folderalloc = SysAllocString(folderName);
						bstrss.AppendBSTR(folderalloc);
						backupFilepath = bstrss.Detach();
						logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup Folder Backup Name: %ws\n", backupFilepath);						

						CComBSTR bstrsss(filePath);
						BSTR append = SysAllocString(L"\\");
						bstrsss.AppendBSTR(append);
						BSTR filePathwithslash = bstrsss.Detach();
						logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup filePathwithslash: %ws\n", filePathwithslash);

						restore_data_initialization(backupFilepath, filePathwithslash, isDiskRestore);*/
					}
					else
					{
						CComBSTR bstrr;
						bstrr.Attach(SysAllocString(filePath));
						if(filePath[SysStringLen(filePath)-1]=='\\')
						{
							logger->log(NORMAL, L"No need to add slash\n");						
						}
						else
						{
							logger->log(NORMAL, L"Adding slash\n");	
							bstrr.AppendBSTR(SysAllocString(L"\\"));
						}
						bstrr.AppendBSTR(SysAllocString(filespec));
						actualFilepath = bstrr.Detach();
						actualFilepath = SysAllocString(actualFilepath);


						CComBSTR bstr;
						bstr.Attach(SysAllocString(backupFolder));
						bstr.AppendBSTR(SysAllocString(filespec));
						backupFolderpath = bstr.Detach();
						backupFolderpath = SysAllocString(backupFolderpath);
						logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup BACKUP FOLDER PATH: %ws\n", backupFolderpath);
						logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup ACTUAL FILE PATH: %ws\n", actualFilepath);
						
                        BOOL b;
						if ((wcsstr(backupFolderpath, L".vhd") != NULL) || (wcsstr(backupFolderpath, L".avhd") != NULL))
						{
							logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup DecompressFileDirectly: %ws\n", backupFolderpath);
							b = DecompressFileDirectly(backupFolderpath, actualFilepath, restoreId, vmId, callBackMethod);
						}
						else
						{
							logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup COPY FILE: %ws\n", backupFolderpath);
							b = CopyFile(backupFolderpath, actualFilepath, false);
						}

						if (b) {
							logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup Success!\n");
						}
						else {
							logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup Failure: %d!\n", GetLastError());
						}
                                                
						if(actualFilepath!=nullptr){SysFreeString(actualFilepath);}
						if(backupFolderpath!=nullptr){SysFreeString(backupFolderpath);}
					}
				}

				result = component->FreeComponentInfo(componentInfo);				

		}

		if(isoldVMdeletebool)//for disk restore and create new vm, don't need to do the below VSS steps
		{
			logger->log(NORMAL, L"Calling PostRestore\n");
			result = pRestore->PostRestore(&pRestoreAsync);
			CheckHRESULT(result, L"PostRestore");

			result = pRestoreAsync->Wait();
			CheckHRESULT(result, L"PostRestoreWait");

			pRestoreAsync->QueryStatus(&result, NULL);
			if (result != VSS_S_ASYNC_FINISHED)
			{
				if (SUCCEEDED(result)) 
				{
					logger->log(NORMAL, L"PostRestore_QueryStatus Failed..!\n");
					CheckHRESULT(result, L"PostRestore_QueryStatus");			
					return 413;
				}
			}
		}
		logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup Releasing pRestoreAsync...\n");	
		if (pRestoreAsync != NULL)
		{
			pRestoreAsync->Release();
		}
		logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup ended...\n");
		return 0;

	}
	catch (exception& ex)
	{
		logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromFullBackup Exception message: %ws\n",ex.what());		
		return 806;
	}

}


int restorefilesfromIncrementalBackup(std::list<IVssWMComponent*> componentListtoRestore, BSTR vmIncrementalbackedupPath, BSTR vmName, bool isOverwrite, BSTR destinationPath, BSTR vmId, BSTR restoreId, long long (*callBackMethod)(wchar_t *,wchar_t *,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t*,wchar_t *))// destinationPath -> without end slash
{
	try
	{
		logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup started...\n");
		HRESULT  result;
		

		for (auto itr = componentListtoRestore.begin(); itr != componentListtoRestore.end(); ++itr)
		{
				IVssWMComponent *component=*itr;
				PVSSCOMPONENTINFO componentInfo;
				result = component->GetComponentInfo(&componentInfo);//returns information about the component
				CheckHRESULT(result, L"GetComponentInfo");


				for (unsigned i = 0; i < componentInfo->cFileCount; i++)
				{
					CComPtr<IVssWMFiledesc> pFileDesc;
					result = component->GetFile(i, &pFileDesc);
					CheckHRESULT(result, L"GetFile");
					_TCHAR volumeName[MAX_PATH + 1] = { 0 };
					BSTR filespec, filePath;
					BSTR VHDpathwheredatatobewritten = L"";
					result = pFileDesc->GetFilespec(&filespec);
					result = pFileDesc->GetPath(&filePath);
					DWORD backupTypeMask; 
				result = pFileDesc->GetBackupTypeMask(&backupTypeMask);
				logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup File Name -> %ws, BackupTypeMask -> %d\n", filespec, backupTypeMask);	
				
					BSTR backupFolderwithoutslash = SysAllocStringLen(L"", wcslen(vmIncrementalbackedupPath) + wcslen(vmName) + 2);
					wcscpy(backupFolderwithoutslash, vmIncrementalbackedupPath);
					wcscat(backupFolderwithoutslash, L"\\");
					wcscat(backupFolderwithoutslash, vmName);
					wcscat(backupFolderwithoutslash, L"\0");

					BSTR backupFolder = SysAllocStringLen(L"", wcslen(vmIncrementalbackedupPath) + wcslen(vmName) + 3);
					wcscpy(backupFolder, vmIncrementalbackedupPath);
					wcscat(backupFolder, L"\\");
					wcscat(backupFolder, vmName);
					wcscat(backupFolder, L"\\");
					wcscat(backupFolder, L"\0");

					logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup backupFolder -> %ws\n", backupFolder);
		
					BSTR backupFolderpath = L"";
					BSTR actualFilepath = L"";
					BSTR backupFilepath = L"";	
					
					
					if ((wcsstr(filespec, L".vhd") == NULL) && (wcsstr(filespec, L".avhd") == NULL))
					{
						//not a harddisk. so continuing
						continue;
					}
					else
					{
						//if overwriting, path is selected from writer metadata. if create new vm, path is selected by value returned from rmp server
						if(isOverwrite)
						{
							CComBSTR bstr;
							bstr.Attach(SysAllocString(filePath));
							if(filePath[SysStringLen(filePath)-1]=='\\')
							{
								logger->log(NORMAL, L"No need to add slash\n");						
							}
							else
							{
								logger->log(NORMAL, L"Adding slash\n");	
								bstr.AppendBSTR(SysAllocString(L"\\"));
							}
							bstr.AppendBSTR(SysAllocString(filespec));
							VHDpathwheredatatobewritten = bstr.Detach();
							VHDpathwheredatatobewritten = SysAllocString(VHDpathwheredatatobewritten);
							logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup VHDpathwheredatatobewritten -> %ws\n", VHDpathwheredatatobewritten);
						}
						else
						{
							CComBSTR bstr;
							bstr.Attach(SysAllocString(destinationPath));
							bstr.AppendBSTR(SysAllocString(L"\\"));	
							bstr.AppendBSTR(SysAllocString(filespec));
							VHDpathwheredatatobewritten = bstr.Detach();
							VHDpathwheredatatobewritten = SysAllocString(VHDpathwheredatatobewritten);
							logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup VHDpathwheredatatobewritten -> %ws\n", VHDpathwheredatatobewritten);
						}
						
					}

					//char *backupFolderchar= _com_util::ConvertBSTRToString(backupFolder);
					//char *vhdxchar= _com_util::ConvertBSTRToString(filespec);

					wchar_t* backupBin = new wchar_t[wcslen(backupFolder) + wcslen(filespec) + wcslen(L"backup.bin") + 1];				
					wcscpy(backupBin, backupFolder);
					wcscat(backupBin, filespec);
					wcscat(backupBin, L"backup.bin");
					wcscat(backupBin, L"\0");
					logger->log(NORMAL, L"backupBin: %ws\n", backupBin);

					wchar_t* backupmetaData = new wchar_t[wcslen(backupFolder) + wcslen(filespec) + wcslen(L"metadata.txt") + 1];				
					wcscpy(backupmetaData, backupFolder);
					wcscat(backupmetaData, filespec);
					wcscat(backupmetaData, L"metadata.txt");
					wcscat(backupmetaData, L"\0");
					logger->log(NORMAL, L"backupmetaData: %ws\n", backupmetaData);

					//Open CBT file in backup repository
					FILE* metadataFilepointer;
					_wfopen_s(&metadataFilepointer, backupmetaData, L"rb");

					//Open actual backup file which contains bytes that are backed up
					FILE* backupBytesfilepointer;
					_wfopen_s(&backupBytesfilepointer,backupBin,L"rb+");//todo -> same as metadata file
					
					int size = 1024, pos;
					int c;
					char *byteCount = (char *)malloc(size);
					char *byteOffset = (char *)malloc(size);
					char *byteOffsetlow = (char *)malloc(size);
					char *byteOffsethigh = (char *)malloc(size);

					ULONG byteCountvalue;
					LONGLONG byteOffsetvalue;
					DWORD byteOffsetlowvalue;
					LONG byteOffsethighvalue;

					if (metadataFilepointer)
					{
						logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup Reading from backed up CBT metadata file -> %ws\n", backupmetaData);											
						do
						{
							pos = 0;
							do
							{
								c = fgetc(metadataFilepointer);
								if (c != EOF && c != '\n' && c != '\t')
								{
									byteCount[pos++] = (char)c;
								}
								if (pos >= size - 1)
								{
									size *= 2;
									byteCount = (char*)realloc(byteCount, size);
								}
							} while (c != '\t');
							if (pos != 0)
							{
								byteCount[pos++] = '\0';
								byteCountvalue = (ULONG)atol(byteCount);
								memset(byteCount, 0, pos);
							}

							pos = 0;
							do
							{
								c = fgetc(metadataFilepointer);
								if (c != EOF && c != '\n' && c != '\t')
								{
									byteOffset[pos++] = (char)c;
								}
								if (pos >= size - 1)
								{
									size *= 2;
									byteOffset = (char*)realloc(byteOffset, size);
								}
							} while (c != '\t');
							if (pos != 0)
							{
								byteOffset[pos++] = '\0';
								byteOffsetvalue = (LONGLONG)strtoull(byteOffset, nullptr, 10);
								memset(byteOffset, 0, pos);
							}

							pos = 0;
							do
							{
								c = fgetc(metadataFilepointer);
								if (c != EOF && c != '\n' && c != '\t')
								{
									byteOffsetlow[pos++] = (char)c;
								}
								if (pos >= size - 1)
								{
									size *= 2;
									byteOffsetlow = (char*)realloc(byteOffsetlow, size);
								}
							} while (c != '\t');
							if (pos != 0)
							{
								byteOffsetlow[pos++] = '\0';
								byteOffsetlowvalue = atol(byteOffsetlow);
								memset(byteOffsetlow, 0, pos);
							}

							pos = 0;
							do
							{
								c = fgetc(metadataFilepointer);
								if (c != EOF && c != '\n' && c != '\t')
								{
									byteOffsethigh[pos++] = (char)c;
								}
								if (pos >= size - 1)
								{
									size *= 2;
									byteOffsethigh = (char*)realloc(byteOffsethigh, size);
								}
							} while (c != '\t');
							if (pos != 0)
							{
								byteOffsethigh[pos++] = '\0';
								byteOffsethighvalue = atol(byteOffsethigh);
								memset(byteOffsethigh, 0, pos);
							}

						//	logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup CBT Values: %I64d\t%ld\t\n", byteOffsetvalue, byteCountvalue);

							
							//read from bin file
							BYTE *buffer = new BYTE[byteCountvalue+1];
							DWORD lpNumberOfBytesRead;								
							lpNumberOfBytesRead = fread(buffer, sizeof(BYTE), byteCountvalue, backupBytesfilepointer);


							//write to vhd file
							HANDLE VHDpathwheredatatobewrittenHandle = CreateFile(VHDpathwheredatatobewritten, GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_FLAG_BACKUP_SEMANTICS, NULL);
							if (VHDpathwheredatatobewrittenHandle == INVALID_HANDLE_VALUE)
							{
								logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup INVALID HANDLE VALUE...\n");
								return 809;
							}
							
							LARGE_INTEGER liDistanceToMove;
							LARGE_INTEGER filePointer;
							liDistanceToMove.QuadPart = byteOffsetvalue;
							BOOL isFilePointermoved = SetFilePointerEx(VHDpathwheredatatobewrittenHandle, liDistanceToMove, &filePointer, FILE_BEGIN);
							if(!isFilePointermoved)
							{
								logger->log(NORMAL, L"Error in SetFilePointerEx..!\n"); 
								return 809;
							}
							DWORD lpNumberOfBytesWritten;
							BOOL finalresult = WriteFile(VHDpathwheredatatobewrittenHandle, buffer, lpNumberOfBytesRead, &lpNumberOfBytesWritten, NULL);
							if (!finalresult)
                                        		{
								logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup WriteFile FAILED...\n");
								return 809;
                            				}
							if(buffer!=nullptr){
                                                                delete[] buffer;
                                                        }
							CloseHandle(VHDpathwheredatatobewrittenHandle);							
							//move to next entry in metadata file
							c = fgetc(metadataFilepointer);
							if (c == EOF)
							{
								break;
							}
							else
							{
								fseek(metadataFilepointer, -1, SEEK_CUR);
							}
						} while (1); //end do reading from cbt file in backup repository
						logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup Closing metadataFilepointer\n");
						if(backupBytesfilepointer)
						{
							fclose(metadataFilepointer);						
						}
						BSTR type = SysAllocStringLen(L"", 16);
						wcscpy(type, L"MaximumRead");
						logger->log(NORMAL, L"CallBackMethod: to get the file capacity");
						_bstr_t stepid = L"-2";
						wchar_t* backupavhd = new wchar_t[wcslen(backupFolder) + wcslen(filespec) + 1];				
						wcscpy(backupavhd, backupFolder);
						wcscat(backupavhd, filespec);
						wcscat(backupavhd, L"\0");
						long long actualCapacity = (*callBackMethod)(L"RESTORE", stepid, restoreId, vmId, backupavhd, type, L"", stepid);
						logger->log(NORMAL, L"backupavhd: %ws; actual capacty: %lld\n", backupavhd, actualCapacity);
						if(actualCapacity>=512){
							HANDLE VHDpathwheredatatobewrittenHandle = CreateFile(VHDpathwheredatatobewritten, GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_FLAG_BACKUP_SEMANTICS, NULL);
							if (VHDpathwheredatatobewrittenHandle == INVALID_HANDLE_VALUE)
							{
								logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup(GetSize) INVALID HANDLE VALUE...\n");
								return 809;
							}
							LARGE_INTEGER liDistanceToMove;
							LARGE_INTEGER filePointer;
							liDistanceToMove.QuadPart = (LONGLONG)actualCapacity - 512;
							BOOL isFilePointermoved = SetFilePointerEx(VHDpathwheredatatobewrittenHandle, liDistanceToMove, &filePointer, FILE_BEGIN);
							if(!isFilePointermoved)
							{
								logger->log(NORMAL, L"Error in SetFilePointerEx..!\n"); 
								return 809;
							}
							DWORD lpNumberOfBytesWritten;
							BYTE emptyBuffer[512] = "";
							BOOL finalresult = WriteFile(VHDpathwheredatatobewrittenHandle, emptyBuffer, 512, &lpNumberOfBytesWritten, NULL);
							if (!finalresult)
							{
								logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup WriteFile FAILED while filling zeros...\n");
								return 809;
							}

							CloseHandle(VHDpathwheredatatobewrittenHandle);	
						}
					}//end if
					else
					{
						logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup metadataFilepointer is NULL. Probably AVHD file. Going to decompress..\n");
						wchar_t* backupavhd = new wchar_t[wcslen(backupFolder) + wcslen(filespec) + 1];				
						wcscpy(backupavhd, backupFolder);
						wcscat(backupavhd, filespec);
						wcscat(backupavhd, L"\0");
						logger->log(NORMAL, L"backupavhd: %ws\n", backupavhd);
						bool b = DecompressFileDirectly(backupavhd, VHDpathwheredatatobewritten, restoreId, vmId, callBackMethod);
						if (b) 
						{
							logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup DecompressFileDirectly AVHD File Success!\n");
						}
						else 
						{
							logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup DecompressFileDirectly AVHD File Failure: %d!\n", GetLastError());
						}
					}

					logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup Closing backupBytesfilepointer\n");
					if(backupBytesfilepointer)
					{
						fclose(backupBytesfilepointer);															
					}
					if(VHDpathwheredatatobewritten!=nullptr){SysFreeString(VHDpathwheredatatobewritten);}
				}

				logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup Freeing componentInfo\n");
				result = component->FreeComponentInfo(componentInfo);				

		}		

		logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup ended...\n");	
		return 0;							

	}
	catch (exception& e)
	{
		logger->log(NORMAL, L"Vssbackup.cpp restorefilesfromIncrementalBackup EXCEPTION...\n");
		return 809;
	}

}

std::list<IVssWMComponent*> GetHyperVComponents(BSTR vmName, BSTR repositoryPath, BSTR backupName, BSTR scheduleName, Loggerclass *fileCopylogger)
{
	fileCopylogger->log(NORMAL, L"Vssbackup.cpp GetHyperVComponents method starts...VM -> %ws\n", vmName);
	IVssAsync *pAsync = NULL;
	std::list<IVssWMComponent*> componentList;
	std::list<IVssWMComponent*> emptyList;
	HRESULT  result;

	try
	{
		BSTR backupFolder = L"";				
				CComBSTR bstr(repositoryPath);
				bstr.AppendBSTR(SysAllocString(scheduleName));
				bstr.AppendBSTR(SysAllocString(L"\\"));
				bstr.AppendBSTR(SysAllocString(backupName));
				backupFolder = bstr.Detach();
				int val = LoadBackupCompandWriterMetadatadocs(backupFolder, vmName, fileCopylogger); //vmbackepuppath is sent to find writer metadata sn backup components doc
			if (val)
			{
				fileCopylogger->log(NORMAL, L"HVBackup.cpp GetHyperVComponents LoadBackupCompandWriterMetadatadocs failed\n");
				return emptyList;
			}
			UINT writerComponents;
		UINT writerIncludeFiles;
		UINT writerExcludeFiles;
		result = pWriterMetadata->GetFileCounts(&writerIncludeFiles, &writerExcludeFiles, &writerComponents);//returns the number of components
		CheckHRESULT(result, L"GetFileCounts");

		for (unsigned i = 0; i < writerComponents; i++)
		{
			IVssWMComponent *component;
			result = pWriterMetadata->GetComponent(i, &component);//obtains a Writer Metadata Document for a specified backup component
			CheckHRESULT(result, L"GetComponent");

			PVSSCOMPONENTINFO componentInfo;
			result = component->GetComponentInfo(&componentInfo);//returns information about the component
			CheckHRESULT(result, L"GetComponentInfo");


			if (wcscmp(vmName, componentInfo->bstrComponentName) != 0)
			{
				fileCopylogger->log(NORMAL, L"Vssbackup.cpp GetHyperVComponents This component is not required : %ws\n", componentInfo->bstrComponentName);
				continue;
			}

			//add to list
			componentList.push_back(component);
		}

		if(pRestore!=NULL)
		{
			pRestore=NULL;
		}
	
		}
		catch (exception& e)
		{
			fileCopylogger->log(NORMAL, L"Hyper-V Vssbackup.cpp GetHyperVComponents Exception...\n");
		}
		return componentList;
	}
