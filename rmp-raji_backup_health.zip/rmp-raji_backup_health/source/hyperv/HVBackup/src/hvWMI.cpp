#include "hvWMI.h"

//WMILogger *WMILogdrive;
//todo -> try catch
extern "C"
{
	__declspec(dllexport) void writeVHDtoVMfilewhennewschedulecreated(wchar_t *hypervHostName)
	{
		wstring wmilogfileLoc = std::wstring(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\WMILogFile.txt");
		LPWSTR wmilogfileLocation = (LPWSTR)wmilogfileLoc.c_str();
		bool WMIstatus = InitializeWMIGlobalvariables(hypervHostName, wmilogfileLocation);
		writeVHDtoVMfile();//todo -> calling this every time new backup created. can think of better logic
	}
}

void checkifVHDtoVMfileexists()
{
	WMILog("checkifVHDtoVMfileexists started...");
	String^ path = "C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\VHDtoVM.txt";
	if (File::Exists(path))
	{
		WMILog("VHDtoVM File already Exists...!");
	}
	else
	{
		WMILog("VHDtoVM File DOES NOT Exist. Calling writeVHDtoVMfile...!");
		writeVHDtoVMfile();
		WMILog("VHDtoVM File DOES NOT Exist. Completed writeVHDtoVMfile...!");
	}
}

void writeVHDtoVMfile()
{
	try
	{
		WMILog("writeVHDtoVMfile started...");
		String^ query = "select * from Msvm_ComputerSystem";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(WMIconnectiondetails::scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ vms = searcher->Get();
		String^ path = "C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\VHDtoVM_temp.txt";
		LPWSTR pathw = L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\VHDtoVM_temp.txt";
		if (File::Exists(path))
		{
			BOOL isDelete = DeleteFile(pathw); 					
		}


		for each (ManagementObject^ vm in vms)
		{
			ManagementObjectCollection^ settingsCollection = vm->GetRelated("Msvm_VirtualSystemSettingData", "Msvm_SettingsDefineState", nullptr, nullptr, nullptr, nullptr, false, nullptr);
			ManagementObject^ virtualMachineSettings;
			if (settingsCollection->Count == 0)
			{
				WMILog("writeVHDtoVMfile NO Settings object found for the VM");
			}
			else
			{
				for each(ManagementObject^ managementObject in settingsCollection)
				{
					virtualMachineSettings = managementObject;
				}
				List<String^>^ VHDlist;

				if(WMIconnectiondetails::osVersion->StartsWith("5") || WMIconnectiondetails::osVersion->StartsWith("6.0") || WMIconnectiondetails::osVersion->StartsWith("6.1"))
				{
					VHDlist = GetlistofResources(virtualMachineSettings, Convert::ToUInt16(21), "Microsoft Virtual Hard Disk", "Msvm_ResourceAllocationSettingData"); //Get all VHDs
				}
				else
				{
					VHDlist = GetlistofResources(virtualMachineSettings, Convert::ToUInt16(31), "Microsoft:Hyper-V:Virtual Hard Disk", "Msvm_StorageAllocationSettingData"); //Get all VHDs

				}

				if (VHDlist!=nullptr && VHDlist->Count > 0)
				{
					for each(String^ VHDpath in VHDlist)
					{
						WMILog("Machine name in writeVHDtoVMfile: " + vm["ElementName"]->ToString());
						WMILog("VHD name in writeVHDtoVMfile: " + VHDpath);							

						if (!File::Exists(path))
						{
							StreamWriter^ sw = File::CreateText(path);
							sw->Close();
						}
						StreamWriter^ sw = File::AppendText(path);
						try
						{
							sw->Write(VHDpath + Environment::NewLine + vm["Name"]->ToString() + Environment::NewLine);												
						}
						finally
						{
							sw->Flush();
							sw->Close();
						}
					}					
				}
				else
				{
					WMILog("writeVHDtoVMfile VHDList is empty");
				}
			}
		}
		//Delete old file and rename new file
		BOOL isDeleted = DeleteFile(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\VHDtoVM.txt"); 
		//if(isDeleted)
		//{
			BOOL isMoved = MoveFile(L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\VHDtoVM_temp.txt", L"C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\VHDtoVM.txt");
		//}
	}
	catch (Exception^ ex)
	{	
		WMILog("writeVHDtoVMfile Exception thrown: " + ex->Message + "  Stacktrace: " + ex->StackTrace);
	}

}

int createnetworkAdapter(ManagementObject^ settings, ManagementObject^ vmManagementService, String^ switchName)
{
	WMILog("hvWMI.cpp createnetworkAdapter started...");
	try
	{
		ManagementObject^ synthetic;
		synthetic = GetResourceAllocationsettingDataDefault(WMIconnectiondetails::scope, 10, "Microsoft:Hyper-V:Synthetic Ethernet Port", "-");//ResourceType.Disk=17, public const string DiskSynthetic = "Microsoft Synthetic Disk Drive";
		synthetic = (ManagementObject^)synthetic->Clone();
		array<String^>^ ff = gcnew array<String^>(1);
		ff[0] = Guid::NewGuid().ToString("B");
		synthetic["VirtualSystemIdentifiers"] = ff;
		synthetic["ElementName"] = "Network Adapter";
		synthetic["StaticMacAddress"] = false;

		array<String^>^ nwAdapter = gcnew array<String^>(1);
		nwAdapter[0] = synthetic->GetText(TextFormat::WmiDtd20);
		ManagementBaseObject^ syntheticinParams = vmManagementService->GetMethodParameters("AddResourceSettings");
		syntheticinParams["AffectedConfiguration"] = settings->Path->Path;
		syntheticinParams["ResourceSettings"] = nwAdapter;
		ManagementBaseObject^ syntheticoutParams = vmManagementService->InvokeMethod("AddResourceSettings", syntheticinParams, nullptr);

		WMILog("nwAdapter Return Value STATE -> " + Convert::ToUInt16(syntheticoutParams["ReturnValue"]));

		bool result = ValidateOutput(syntheticoutParams, WMIconnectiondetails::scope);
		if (!result)
		{
			WMILog("nwAdapter attachment failed...");
//			return 822;
		}
                else
                {
                        WMILog("nwAdapter attachment succeeded");
                }

		if(switchName==nullptr || switchName->Equals(""))
		{
			WMILog("SwitchName is NULL. Probably network adapter not connected..!");
			return 0;
		}

		ManagementObject^ addednwAdapter;
		if (syntheticoutParams["ResultingResourceSettings"] != nullptr)
		{
			WMILog("Reading synthetic output parameters...");
			addednwAdapter = gcnew ManagementObject(((array<String^>^)syntheticoutParams["ResultingResourceSettings"])[0]);
			addednwAdapter->Get();
		}

		
		String^ query = "select * from Msvm_VirtualEthernetSwitch where ElementName='"+ switchName +"'";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(WMIconnectiondetails::scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ settingsCollection = searcher->Get();
		ManagementObject^ virtualSwitch = gcnew ManagementObject();
		for each (ManagementObject^ temp in settingsCollection)
		{
			WMILog("Got switch..!");
			virtualSwitch = temp;
		}	
		
		
		ManagementObject^ nic;
		nic = GetResourceAllocationsettingDataDefault(WMIconnectiondetails::scope, 33, "Microsoft:Hyper-V:Ethernet Connection", "-");//ResourceType.Disk=17, public const string DiskSynthetic = "Microsoft Synthetic Disk Drive";
		nic = (ManagementObject^)nic->Clone();

		array<String^>^ sw = gcnew array<String^>(1);
		sw[0] = virtualSwitch->Path->Path;
		nic["Parent"] = addednwAdapter->Path->Path;
		nic["HostResource"] = sw;
		
		array<String^>^ networkSwitch = gcnew array<String^>(1);
		networkSwitch[0] = nic->GetText(TextFormat::WmiDtd20);
		syntheticinParams = vmManagementService->GetMethodParameters("AddResourceSettings");
		syntheticinParams["AffectedConfiguration"] = settings->Path->Path;
		syntheticinParams["ResourceSettings"] = networkSwitch;
		syntheticoutParams = vmManagementService->InvokeMethod("AddResourceSettings", syntheticinParams, nullptr);

		WMILog("networkSwitch Return Value STATE -> " + Convert::ToUInt16(syntheticoutParams["ReturnValue"]));

		result = ValidateOutput(syntheticoutParams, WMIconnectiondetails::scope);
		if (!result)
		{
			WMILog("Switch attachment failed...");
//			return 823;
		}
                else
                {
                        WMILog("Switch attachment succeeded");
                }
	}
	catch (Exception^ ex)
	{
		WMILog(L"createnetworkAdapter Exception thrown: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
//		return 824;
                return 0;
	}
	WMILog("createnetworkAdapter completed..!");
	return 0;
}

int attachdrivesandVHDfiles(ManagementObject^ settings, ManagementObject^ vmManagementService, Dictionary<Dictionary<String^, String^>^, List<Dictionary<String^, String^>^>^>^ controllerdriveDetails, String^ VHDnewlocation)
{
	WMILog("hvWMI.cpp attachdrivesandVHDfiles started...");
	try
	{
		for each(Dictionary<String^, String^>^ controllerInformation in controllerdriveDetails->Keys)
		{
			String^ controllerName, ^isScsi;
			bool result;
			controllerInformation->TryGetValue("controllerName", controllerName);
			controllerInformation->TryGetValue("isScsi", isScsi);
			WMILog("hvWMI.cpp attachdrivesandVHDfiles controllerName..." + controllerName + "isScsi-> " + isScsi);
			//create controller
			ManagementObject^ controllerObject;
			
			if (isScsi->Equals("false"))
			{
				WMILog("hvWMI.cpp attachdrivesandVHDfiles Attaching IDE Controller..!");
				controllerObject = GetResourceAllocationsettingData(settings, 5, "Microsoft:Hyper-V:Emulated IDE Controller", "-");//public const UInt16 IDEController = 5;
			}
			else
			{
				WMILog("hvWMI.cpp attachdrivesandVHDfiles Attaching SCSI Controller..!");
				controllerObject = GetResourceAllocationsettingDataDefault(WMIconnectiondetails::scope, 6, "Microsoft:Hyper-V:Synthetic SCSI Controller", "-");//public const UInt16 ISCSIController = 6; 

				//Need to add to the VM
				WMILog("Attaching the SCSI controller to the VM..");
				array<String^>^ scsi = gcnew array<String^>(1);
				scsi[0] = controllerObject->GetText(TextFormat::WmiDtd20);
				ManagementBaseObject^ scsiinParamss = vmManagementService->GetMethodParameters("AddResourceSettings");
				scsiinParamss["AffectedConfiguration"] = settings->Path->Path;
				scsiinParamss["ResourceSettings"] = scsi;
				ManagementBaseObject^ scsioutParamss = vmManagementService->InvokeMethod("AddResourceSettings", scsiinParamss, nullptr);
				WMILog("SCSI Return Value STATE -> " + Convert::ToUInt16(scsioutParamss["ReturnValue"]));
				result = ValidateOutput(scsioutParamss, WMIconnectiondetails::scope);
				if (!result)
				{
					WMILog("SCSI controller attachment failed...");
					return 818;
				}
				WMILog("SCSI controller attachment succeeded");

				if (scsioutParamss["ResultingResourceSettings"] != nullptr)
				{
					WMILog("Reading SCSI output parameters...");
					controllerObject = gcnew ManagementObject(((array<String^>^)scsioutParamss["ResultingResourceSettings"])[0]);
					controllerObject->Get();
				}
			}

			List<Dictionary<String^, String^>^>^ driveDetails;
			controllerdriveDetails->TryGetValue(controllerInformation, driveDetails);
			WMILog("hvWMI.cpp attachdrivesandVHDfiles Going to loop through driveDetails");

			//Loop for creating drives
			for each(Dictionary<String^, String^>^ driveInfo in driveDetails)
			{
				
				String^ driveName, ^pathName, ^type;
				driveInfo->TryGetValue("driveName", driveName);
				driveInfo->TryGetValue("pathName", pathName);
				driveInfo->TryGetValue("type", type);
				WMILog("hvWMI.cpp attachdrivesandVHDfiles driveName..." + driveName + "pathName-> " + pathName);
			

				//create the drive here and attach vhd specified in pathName
				//Add synthetic disk
				String^ pre = "drive";
				String^ driveNumber = driveName->Substring(driveName->IndexOf(pre) + pre->Length);
				WMILog("Drive number -> " + driveNumber);

				ManagementObject^ synthetic = GetResourceAllocationsettingDataDefault(WMIconnectiondetails::scope, 17, "Microsoft:Hyper-V:Synthetic Disk Drive", " - ");
				synthetic = (ManagementObject^)synthetic->Clone();
				synthetic["Parent"] = controllerObject->Path->Path; //or SCSI controller path (WMI path)
				synthetic["AddressOnParent"] = Convert::ToInt32(driveNumber); //0 or 1 for IDE 

				array<String^>^ RASDs = gcnew array<String^>(1);
				RASDs[0] = synthetic->GetText(TextFormat::WmiDtd20);
				ManagementBaseObject^ syntheticinParams = vmManagementService->GetMethodParameters("AddResourceSettings");
				syntheticinParams["AffectedConfiguration"] = settings->Path->Path;
				syntheticinParams["ResourceSettings"] = RASDs;
				ManagementBaseObject^ syntheticoutParams = vmManagementService->InvokeMethod("AddResourceSettings", syntheticinParams, nullptr);

				WMILog("SYNTHETIC Return Value STATE -> " + Convert::ToUInt16(syntheticoutParams["ReturnValue"]));

				result = ValidateOutput(syntheticoutParams, WMIconnectiondetails::scope);
				if (!result)
				{
					WMILog("Synthetic attachment failed...");
					return 819;
				}
				WMILog("Synthetic attachment succeeded");

				ManagementObject^ addedSynthetic;
				if (syntheticoutParams["ResultingResourceSettings"] != nullptr)
				{
					WMILog("Reading synthetic output parameters...");
					addedSynthetic = gcnew ManagementObject(((array<String^>^)syntheticoutParams["ResultingResourceSettings"])[0]);
					addedSynthetic->Get();
				}

				
				//Add VHD
				String^ vhdNewpath = VHDnewlocation + pathName->Substring(pathName->LastIndexOf("\\"));
				WMILog("vhdNewpath ->  " + vhdNewpath);
				if(!File::Exists(vhdNewpath))
				{
					WMILog("vhdNewpath NOT FOUND. Trying to connect to available VHDX file..!");//todo
					if (Directory::GetFiles(VHDnewlocation, "*-AutoRecovery*")->Length != 0)
					{
						WMILog("vhdNewpath NOT FOUND. But we have AUTO-RECOVERY AVHDX.Finding actual filepath..");
						array<String^> ^ autorecoveryFiles = Directory::GetFiles(VHDnewlocation, "*-AutoRecovery*");
						String^ autoRecoveryVHD = "-";
						for each(String^ autoVHD in autorecoveryFiles)
						{
							autoRecoveryVHD = autoVHD;
						}
						String^ autoRecoverycut = autoRecoveryVHD->Substring(0, autoRecoveryVHD->LastIndexOf("-AutoRecovery"));
						WMILog("autoRecoverycut -> " + autoRecoverycut);
						String^ autoRecoveryTemp = autoRecoverycut; 
						autoRecoverycut = autoRecoverycut + ".vhdx";
						if (File::Exists(autoRecoverycut))
						{
							vhdNewpath = autoRecoverycut;
						}
						else
						{
							vhdNewpath = autoRecoveryTemp + ".avhdx";
						}
						WMILog("FINAL AUTO_RECOVERY VHD -> " + vhdNewpath);

					}
					else
					{
						array<String^> ^ vhdxFiles = Directory::GetFiles(VHDnewlocation, "*.vhd*");
						for each(String^ existingVHD in vhdxFiles)
						{
							vhdNewpath = existingVHD;
						}
						WMILog("vhdNewpath NOT FOUND. NEW NEW VHD PATH ->" + vhdNewpath);
					}
				}

				ManagementObject^ hardDisk = GetResourceAllocationsettingDataDefault(WMIconnectiondetails::scope, 31, "Microsoft:Hyper-V:Virtual Hard Disk", "-");	
				hardDisk = (ManagementObject^)hardDisk->Clone();
				array<String^>^ connection = gcnew array<String^>(1);
				connection[0] = vhdNewpath;

				hardDisk["Parent"] = addedSynthetic->Path->Path; //WMI path
				hardDisk["HostResource"] = connection;

				array<String^> ^ HDs = gcnew array<String^>(1);
				HDs[0] = hardDisk->GetText(TextFormat::WmiDtd20);
				ManagementBaseObject^ VHDinParams = vmManagementService->GetMethodParameters("AddResourceSettings");
				VHDinParams["AffectedConfiguration"] = settings->Path->Path;
				VHDinParams["ResourceSettings"] = HDs;
				ManagementBaseObject^ VHDoutParams = vmManagementService->InvokeMethod("AddResourceSettings", VHDinParams, nullptr);

				WMILog("HD STATE return value-> " + Convert::ToUInt16(VHDoutParams["ReturnValue"]));

				result = ValidateOutput(VHDoutParams, WMIconnectiondetails::scope);
				if (!result)
				{
					WMILog("HD attachment failed");
					return 820;
				}
				WMILog("HD attachment succeeded");
			}
		}
	}
	catch (Exception^ ex)
	{
		WMILog(L"attachdrivesandVHDfiles Exception thrown: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
		return 821;
	}
	WMILog("attachdrivesandVHDfiles completed..!");
	return 0;
}

String^ DefinenewVirtualSystem(String^ configurationXMLfileNameString)
{
	WMILog("DefinenewVirtualSystem started..!");
	String^ hvvmId = "-";
	try
	{
		ManagementObject^ vmManagementService = getManagementObjectInstance("MsVM_VirtualSystemManagementService");
		ManagementBaseObject^ inParams = vmManagementService->GetMethodParameters("DefineSystem");

		XmlDocument^ doc = gcnew XmlDocument();
		doc->Load(configurationXMLfileNameString);
		String^ hvGen = "0";
		XmlNodeList^ xnList = doc->SelectNodes("configuration/properties/subtype");
		if(xnList!=nullptr)
		{
			for each(XmlNode^ xn in xnList)
			{
				WMILog("subtype -> " + xn->InnerText);
				hvGen = xn->InnerText;
				WMILog("subtype -> " + hvGen);
			}
		}
		if(hvGen!=nullptr && hvGen->Equals("1"))
		{
			WMILog("Creating GENERATION 2 Virtual machine............!!!!!!!!!!!!!");
		}
		else
		{
			WMILog("Creating GENERATION 1 Virtual machine............!!!!!!!!!!!!!");
		}

		if(hvGen!=nullptr && hvGen->Equals("1"))//if generation 2, need to set that parameter before definesystem
		{
			ManagementPath^ settingPath = gcnew ManagementPath("Msvm_VirtualSystemSettingData");
			ManagementClass^ settingClass = gcnew ManagementClass(WMIconnectiondetails::scope, settingPath, nullptr);
			ManagementObject^ settingData = settingClass->CreateInstance();
			settingData["VirtualSystemSubtype"] = "Microsoft:Hyper-V:SubType:2";
			String^ vmSetting = settingData->GetText(TextFormat::WmiDtd20);		
			inParams["SystemSettings"] = vmSetting;
		}

		ManagementBaseObject^ definition = vmManagementService->InvokeMethod("DefineSystem", inParams, nullptr);
		WMILog("DefinenewVirtualSystem Return Value STATE -> " + Convert::ToUInt16(definition["ReturnValue"]));
		bool result = ValidateOutput(definition, WMIconnectiondetails::scope);
		if (!result)
		{
			WMILog("DefinenewVirtualSystem failed...");
			return nullptr;
		}
		WMILog("DefinenewVirtualSystem succeeded");

		String^ vmPath = definition["ResultingSystem"]->ToString();
		ManagementObject^ computerSystemTemplate = gcnew ManagementObject(vmPath);
		computerSystemTemplate->Scope = WMIconnectiondetails::scope;
		hvvmId = computerSystemTemplate["Name"]->ToString(); //this is the unique GUID of the new VM
	}
	catch(Exception^ ex)
	{
		WMILog(L"DefinenewVirtualSystem Exception thrown: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
		return nullptr;
	}
	WMILog("DefinenewVirtualSystem completed..!");
	return hvvmId;
}

int createnewVirtualMachinefromXMLfile(String^ xmlFilePath, String^ ischangeVMName, String^ newVMName, String^ VHDnewstorageLocation, String^ newVMhvID)
{
	try
	{
		WMILog("createnewVirtualMachinefromXMLfile started..!");
		//Create virtual machine object
		HVVirtualMachine^ hvvm = gcnew HVVirtualMachine(xmlFilePath);		

		ManagementObject^ vmManagementService = getManagementObjectInstance("MsVM_VirtualSystemManagementService");

		//Get Msvm_VirtualSystemSettingData object
		String^ query = "select * from Msvm_VirtualSystemSettingData where VirtualSystemIdentifier='" + newVMhvID + "'";
		ManagementObjectSearcher^ searcher = gcnew ManagementObjectSearcher(WMIconnectiondetails::scope, gcnew ObjectQuery(query));
		ManagementObjectCollection^ settingsCollection = searcher->Get();
		ManagementObject^ settings = gcnew ManagementObject();
		for each (ManagementObject^ temp in settingsCollection)
		{
			settings = temp;
		}

		//Change the necessary settings		
		if (ischangeVMName->Equals("true"))
		{
			settings["ElementName"] = newVMName; //this is the new display name for the VM
		}
		else
		{
			settings["ElementName"] = hvvm->originalvmName;
		}
		
		/*if (isPreserveUUID->Equals("true"))
		{
			settings["VirtualSystemIdentifier"] = originalVMId;
		}*/

		
		//Memory Settings
		ManagementObjectCollection^ memorySettingsCollection = settings->GetRelated("Msvm_MemorySettingData");
		ManagementObject^ memorySettings;
		for each(ManagementObject^ managementObject in memorySettingsCollection)
		{
			memorySettings = managementObject;
		}

		if (hvvm->isDynamicmemoryenabled)
		{ //https://blogs.msdn.microsoft.com/taylorb/2013/11/08/memory-configuration-utilizing-the-hyper-v-wmi-v2-namespace/
			settings["VirtualNumaEnabled"] = false;
			memorySettings["DynamicMemoryEnabled"] = true;
			memorySettings["Reservation"] = hvvm->reservationMemory;
			memorySettings["VirtualQuantity"] = hvvm->RAMmemory;
			memorySettings["Limit"] = hvvm->maxMemory;
		}
		else
		{
			settings["VirtualNumaEnabled"] = true;
			memorySettings["DynamicMemoryEnabled"] = false;
			memorySettings["VirtualQuantity"] = hvvm->RAMmemory;
		}


		//Drive and VHD configuration settings		
		int returnValue = attachdrivesandVHDfiles(settings, vmManagementService, hvvm->controllerdriveDetails, VHDnewstorageLocation);
		if(returnValue){
			return returnValue;
		}
		//Network adapter settings
		WMILog(L"GOING TO CALL createnetworkAdapter......!!!!!!!!!!!!");
		returnValue = createnetworkAdapter(settings, vmManagementService, hvvm->switchName);
//		if(returnValue){
//			return returnValue;
//		}
		settings->Put();
		memorySettings->Put();

		//ModifySystemSettings call
		WMILog(L"VM details: Name ->  " + settings["ElementName"]->ToString() + " .. GUID -> " + settings["VirtualSystemIdentifier"]->ToString());

		ManagementBaseObject^ inParams = vmManagementService->GetMethodParameters("ModifySystemSettings");
		String^ settingsText = settings->GetText(TextFormat::WmiDtd20);
		inParams["SystemSettings"] = settingsText;
		ManagementBaseObject^ resultToCheck = vmManagementService->InvokeMethod("ModifySystemSettings", inParams, nullptr);
		WMILog("ModifySystemSettings Return Value STATE -> " + Convert::ToUInt16(resultToCheck["ReturnValue"]));
		bool result = ValidateOutput(resultToCheck, WMIconnectiondetails::scope);
		if (!result)
		{
			WMILog("ModifySystemSettings failed...");
//			return 825;
		}
                else
                {
                        WMILog("ModifySystemSettings DONE!!!!!!!!!!");
                }
		
		inParams = vmManagementService->GetMethodParameters("ModifyResourceSettings");
		array<String^>^ memorySettingsarray = gcnew array<String^>(1);
		settingsText = memorySettings->GetText(TextFormat::WmiDtd20);
		memorySettingsarray[0] = settingsText;
		inParams["ResourceSettings"] = memorySettingsarray;
		resultToCheck = vmManagementService->InvokeMethod("ModifyResourceSettings", inParams, nullptr);
		WMILog("ModifyResourceSettings Return Value STATE -> " + Convert::ToUInt16(resultToCheck["ReturnValue"]));
		result = ValidateOutput(resultToCheck, WMIconnectiondetails::scope);
		if (!result)
		{
			WMILog("ModifyResourceSettings failed...");
//			return 826;
		}
                else
                {
                        WMILog("ModifyResourceSettings DONE!!!!!!!!!!");	
                }
	}
	catch (Exception^ ex)
	{
		WMILog(L"createnewVirtualMachine Exception thrown: " + ex->Message + "\n Stacktrace: " + ex->StackTrace);
		return 810;
	}
	WMILog(L"createnewVirtualMachine COMPLETED..!");
	return 0;

}









