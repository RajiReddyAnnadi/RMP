﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;
using System.Diagnostics;
using System.ServiceProcess;
using Microsoft.Win32;
using System.Runtime.InteropServices;


namespace RMPHVDriver
{
    class RMPHVMonitorService : HVDriverManager
    {
        private const string ServiceName = "RMPHVMonitor";
        private static ServiceController service = new ServiceController(ServiceName);
        private static TimeSpan timeOut = TimeSpan.FromMilliseconds(60000);
        private static int errorCode = 0;
        private const string Dir_x86 = @"\x86";
        private const string Dir_x64 = @"\x64";
        private const string Dir_WXP = @"\WXP";
        private const string Dir_VISTA = @"\VISTA";
        private const string Dir_WIN_7 = @"\Win7";
        private const string Dir_WIN_8 = @"\Win8";
        private const string Dir_WIN_8_1 = @"\Win8.1";
        public static string Dir_Driver = null;
        private const string Env_Path = "Path";
        private const string RMPHVMonitorINF = "FSMonitor.inf";
        public const string PATH_RMPHVMonitor = @"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\RMPHVMonitor";
        public const string KEY_RMPHVMonitor_VERSION = "Version";

        [DllImport("Setupapi.dll", EntryPoint = "InstallHinfSectionW", CallingConvention = CallingConvention.StdCall)]
        public static extern void InstallHinfSection(
            [In] IntPtr hwnd,
            [In] IntPtr ModuleHandle,
            [In, MarshalAs(UnmanagedType.LPWStr)] string CmdLineBuffer,
            int nCmdShow);

        public static void SetEnvironmentandMoveFiles()
        {
            string currentPath = "C:\\Program Files\\ManageEngine\\RMPHVBackup";
            string newPath = null, driverPath = null;
            HypervLog("Setting Environment...");
            if (IntPtr.Size == 4)
            {
                // 32-bit
                HypervLog("Processor Type :: 32 Bit");
                //dllPath = currentPath + Dir_x86;
            }
            else if (IntPtr.Size == 8)
            {
                // 64-bit
                HypervLog("Processor Type :: 64 Bit");
                //dllPath = currentPath + Dir_x64;
            }
            else
            {
                HypervLog("ERROR :: Processor Architecture Unknown");
            }

            int majorVerSion = Environment.OSVersion.Version.Major;
            int revisionNo = Environment.OSVersion.Version.Minor;

            HypervLog("OS VerSion :: " + Environment.OSVersion.Version.Major + "." + Environment.OSVersion.Version.MajorRevision + "." + Environment.OSVersion.Version.Minor + "." + Environment.OSVersion.Version.MinorRevision + ", " + Environment.OSVersion.Version.Build + ", " + Environment.OSVersion.Version.Revision);

            if (majorVerSion == 5)
            {
                HypervLog("Identified OS :: WXP");
                driverPath = currentPath + Dir_WXP;                
            }
            else if (majorVerSion == 6 && revisionNo == 0)
            {
                HypervLog("Identified OS :: VISTA");
                driverPath = currentPath + Dir_WIN_7;//Need to check this
            }
            else if (majorVerSion == 6 && revisionNo == 1)
            {
                HypervLog("Identified OS :: WIN 7");
                driverPath = currentPath + Dir_WIN_7;                
            }
            else if (majorVerSion == 6 && revisionNo == 2)
            {
                HypervLog("Identified OS :: WIN 8");
                driverPath = currentPath + Dir_WIN_8;
            }
            else if (majorVerSion == 6 && revisionNo == 3)
            {
                HypervLog("Identified OS :: WIN 8.1");
                driverPath = currentPath + Dir_WIN_8_1;
            }
            HypervLog(".Net Version : " + Environment.Version.ToString());

            Copyallfilesindirectory(driverPath, currentPath);
            driverPath = currentPath;
            Dir_Driver = driverPath;
           // libPath = currentPath + @"\..\lib";
            newPath = Environment.GetEnvironmentVariable(Env_Path) + ";" + driverPath;  //";" + libPath
            Environment.SetEnvironmentVariable(Env_Path, newPath);
            HypervLog("Current System PATH :: " + Environment.GetEnvironmentVariable(Env_Path));
        }

        public static void Copyallfilesindirectory(string sourceDir, string targetDir)
        {
            Directory.CreateDirectory(targetDir);

            foreach (var file in Directory.GetFiles(sourceDir))
                File.Copy(file, Path.Combine(targetDir, Path.GetFileName(file)), true);

            foreach (var directory in Directory.GetDirectories(sourceDir))
                Copyallfilesindirectory(directory, Path.Combine(targetDir, Path.GetFileName(directory)));
        }

        public static bool StartService()
        {
            bool result = false;
            errorCode = 0;
            try
            {
                if (!(service.Status == ServiceControllerStatus.Running))
                {
                    service.Start();
                    service.WaitForStatus(ServiceControllerStatus.Running, timeOut);
                }
                result = true;
                HypervLog(ServiceName + " driver service STARTED successfully!!");
            }
            catch (Exception ex)
            {
                bool res = ex.InnerException is Win32Exception;
                if (res)
                {
                    Win32Exception win32Exception = (Win32Exception)ex.InnerException;
                    HypervLog("Win32EXCEPTION :: while starting service - " + win32Exception.Message + "Error Code -> " + win32Exception.NativeErrorCode);
                    errorCode = win32Exception.NativeErrorCode;
                }
                else
                {
                    HypervLog("EXCEPTION :: while starting driver service : " + ex);
                }
            }
            return result;
        }

        public static bool StopService()
        {
            bool result = false;
            errorCode = 0;
            try
            {
                if (!(service.Status == ServiceControllerStatus.Stopped))
                {
                    service.Stop();
                    service.WaitForStatus(ServiceControllerStatus.Stopped, timeOut);
                }
                result = true;
                HypervLog(ServiceName + " driver service STOPPED successfully!!");
            }
            catch (Exception ex)
            {
                bool res = ex.InnerException is Win32Exception;
                if (res)
                {
                    Win32Exception win32Exception = (Win32Exception)ex.InnerException;
                    HypervLog("Win32EXCEPTION :: while stopping service - " + win32Exception.Message + "Error Code -> " + win32Exception.NativeErrorCode);
                    errorCode = win32Exception.NativeErrorCode;
                }
                else
                {
                    HypervLog("EXCEPTION :: while stopping service -> " + ex);
                }
            }
            return result;
        }

        public static bool IsServiceRunning()
        {
            bool result = false;
            errorCode = 0;
            try
            {
                result = (service.Status == ServiceControllerStatus.Running);
                HypervLog("STATUS of " + ServiceName + " driver service :: " +  service.Status);
            }
            catch (Exception ex)
            {
                bool res = ex.InnerException is Win32Exception;
                if (res)
                {
                    Win32Exception win32Exception = (Win32Exception)ex.InnerException;
                    HypervLog("Win32EXCEPTION :: while checking service status - " + win32Exception.Message + "Error Code -> " + win32Exception.NativeErrorCode);
                    errorCode = win32Exception.NativeErrorCode;
                }
                else
                {
                    HypervLog("EXCEPTION :: while checking service status -> " + ex);
                }
            }
            return result;
        }

        public static bool IsServiceInstalled()
        {
            bool result = false;
            errorCode = 0;
            try
            {
                ServiceControllerStatus status = service.Status;
                result = true;
            }
            catch (Exception ex)
            {
                if (ex.InnerException is Win32Exception)
                {
                    Win32Exception win32Exception = (Win32Exception)ex.InnerException;
                    errorCode = win32Exception.NativeErrorCode;
                }
            }
            return result;
        }

        public static bool InstallDriverService()
        {
            bool status = true;
            try
            {
                HypervLog("Installing Driver...");
                // Try also using DIFx frame work, because below methodology will not return any status
                HypervLog("INF File Path -> " + Path.GetFullPath(Dir_Driver) + "\\" + RMPHVMonitorINF);
                InstallHinfSection(IntPtr.Zero, IntPtr.Zero, "DefaultInstall 128 " + Path.GetFullPath(Dir_Driver) + "\\" + RMPHVMonitorINF, 0);
            }
            catch (Exception ex)
            {
                status = false;
                HypervLog("EXCEPTION :: RMPHVMonitor.InstallDriverService :: " + ex);
            }
            return status;
        }

        public static bool InstallAndStartService()
        {
            bool status = false;
            InstallDriverService(); // Installing service
            status = StartService();
            if (!status)
            {
                HypervLog("FAILED to start driver service...");
            }
            return status;
        }

        public static bool UninstallService()
        {
            bool status = false;
            StopService();
            status = UninstallDriverService();
            return status;
        }

        public static bool UninstallDriverService()
        {
            bool status = true;
            try
            {
                //RUNDLL32.EXE SETUPAPI.DLL,InstallHinfSection DefaultInstall 128 minispy.inf
                HypervLog("Uninstalling Driver...");
                InstallHinfSection(IntPtr.Zero, IntPtr.Zero, "DefaultUninstall 128 " + "C:\\Program Files\\ManageEngine\\RMPHVBackup\\" + RMPHVMonitorINF, 0);
            }
            catch (Exception ex)
            {
                status = false;
                HypervLog("EXCEPTION :: RMPHVMonitor.UninstallDriverService :: " + ex);
            }
            return status;
        }

        public static int GetErrorCode()
        {
            return errorCode;
        }

        /*
         * This method does the following
         * 1) Checks if RMPHVMonitorService is installed if not, it installs/starts RMPHVMonitorService.
         * 2) Starts RMPHVMonitorServiceservice if it is not in running state
         * 3) Returns Success if RMPHVMonitorService is started and running else false.
         * 
         */

        public static Object RegistryRead(string keyName, string valueName)
        {
            Object value = null;
            try
            {
                value = Registry.GetValue(keyName, valueName, null);
                if (value != null)
                {
                    HypervLog("Registry Key: " + keyName + "\\" + valueName + " = " + value);
                }
                else
                {
                    HypervLog("Registry Key Not Found : " + keyName + "\\" + valueName);
                }
            }
            catch (Exception ex)
            {
                HypervLog("EXCEPTION :: RegistryRead :: " + ex);
            }

            return value;
        }

        public static bool SetupRMPHVMonitorSevice()
        {
            bool status = false;
            try
            {
                HypervLog("CHECKING for already installed " + ServiceName + " driver service...");
                if (IsServiceInstalled())
                {
                    HypervLog(ServiceName + " driver service is already INSTALLED...");
                    string installedVerStr = (string)RegistryRead(PATH_RMPHVMonitor, KEY_RMPHVMonitor_VERSION);

                    string setupImagePath = Dir_Driver + "\\" + ServiceName + ".sys";
                    string setupVerStr = FileVersionInfo.GetVersionInfo(setupImagePath).FileVersion.Replace(" built by: WinDDK", "");

                    if (installedVerStr == null || installedVerStr.Equals(""))
                    {
                        HypervLog("Unable to determine the current driver version, so replacing it with the setup version");
                        UninstallService();
                        InstallDriverService();
                    }
                    else
                    {
                        Version installedVer = new Version(installedVerStr);
                        Version setupVer = new Version(setupVerStr);
                        if (installedVer.CompareTo(setupVer) < 0)
                        {
                            HypervLog("Installed driver version" + installedVer.ToString() + " is OLDER than setup version" + setupVer.ToString());
                            UninstallService();
                            InstallDriverService();
                        }
                        else
                        {
                             HypervLog("Installed driver version" + installedVer.ToString() + " is SAME or NEWER than setup version" + setupVer.ToString());
                        }
                    }
                    if (!(status = IsServiceRunning()))
                    {
                        status = StartService();
                    }
                }
                else
                {
                    HypervLog(ServiceName + " driver service is NOT INSTALLED...");
                    if (GetErrorCode() == 1060) // Service is not installed. ERROR_SERVICE_DOES_NOT_EXIST - 1060
                    {
                        status = InstallAndStartService();
                    }
                    else // Unhandled start up errors
                    {
                        HypervLog("UNKNOWN ERROR occurred during service start!!");
                    }
                }
            }
            catch (Exception ex)
            {
                HypervLog("EXCEPTION :: SetupRMPHVMonitorSevice : " + ex);
            }
            if (status)
            {
                HypervLog(ServiceName + "@@  driver service is UP and READY to attach with Native Client!!!");
            }
            return status;
        }
    }
}
