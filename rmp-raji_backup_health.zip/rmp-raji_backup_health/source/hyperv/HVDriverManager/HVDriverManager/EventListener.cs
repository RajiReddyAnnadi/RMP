﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMPHVDriver
{
    public class EventListener
    {
        public uint ObjectID;
        static EventListener()
        {
            Console.WriteLine("Hey there!");
        }
        public EventListener(uint threadID)
        {
            this.ObjectID = threadID;
        }
        public int EventCallbackFromNative(string eventJSONString)
        {
            try
            {
               // Console.WriteLine("Received event -> " + eventJSONString);
                HVDriverManager.checkifCBTEventRequiredandwritetoCBTFile(eventJSONString);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in EventCallbackFromNative : " + eventJSONString + "\n" + ex.Message);
            }
            return 50;
        }
    }
}
