﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Security.AccessControl;
using System.Diagnostics;

using Newtonsoft.Json;

namespace RMPHVDriver
{
    class HVDriverManager
    {
        private const string FSMonitorClientDll = "FSMonitorClient.dll";

        private const string HVBackupDll = "HVBackup.dll";
        [DllImport(HVBackupDll)]
        private static extern void writeVHDtoVMfilewhennewschedulecreated([MarshalAs(UnmanagedType.LPWStr)]string hypervHostName);

        [DllImport(HVBackupDll)]
        private static extern int PerformHypervbackup([MarshalAs(UnmanagedType.LPWStr)]string hypervHostName,
            [MarshalAs(UnmanagedType.LPWStr)]string fullbackupVMs, [MarshalAs(UnmanagedType.LPWStr)]string incrementalbackupVMs, [MarshalAs(UnmanagedType.LPWStr)]string repositoryPath,
            [MarshalAs(UnmanagedType.LPWStr)]string backupName, [MarshalAs(UnmanagedType.LPWStr)]string scheduleName,
            [MarshalAs(UnmanagedType.LPWStr)]string isanyVHDchanged);

        [DllImport(HVBackupDll)]
        private static extern int copyVMfilesfromVSSSnapshot([MarshalAs(UnmanagedType.LPWStr)]string hypervHostName,
            [MarshalAs(UnmanagedType.LPWStr)]string vmName, [MarshalAs(UnmanagedType.LPWStr)]string backupType, [MarshalAs(UnmanagedType.LPWStr)]string repositoryPath,
            [MarshalAs(UnmanagedType.LPWStr)]string backupName, [MarshalAs(UnmanagedType.LPWStr)]string scheduleName);

        [DllImport(HVBackupDll)]
        private static extern int PerformHypervrestore([MarshalAs(UnmanagedType.LPWStr)]string hypervHostName, 
            [MarshalAs(UnmanagedType.LPWStr)]string vmName, [MarshalAs(UnmanagedType.LPWStr)]string vmfullbackupPath, [MarshalAs(UnmanagedType.LPWStr)]string vmincrementalbackupPaths,
            [MarshalAs(UnmanagedType.LPWStr)]string isOverwrite, [MarshalAs(UnmanagedType.LPWStr)]string ischangeVMName, [MarshalAs(UnmanagedType.LPWStr)]string newVMName,
            [MarshalAs(UnmanagedType.LPWStr)]string isDiskRestore, [MarshalAs(UnmanagedType.LPWStr)]string VHDnewstorageLocation, [MarshalAs(UnmanagedType.LPWStr)]string isPowerOn, [MarshalAs(UnmanagedType.LPWStr)]string isEncrypted, [MarshalAs(UnmanagedType.LPWStr)]string isdecryptionSuccessful);

        private static volatile Dictionary<String, Object> LockObjects = new Dictionary<string, object>();

        public static Dictionary<ulong, EventListener> EventListeners = new Dictionary<ulong, EventListener>();

        public static List<EventCallBack> CallbackList = new List<EventCallBack>();

        public delegate int EventCallBack([In, MarshalAs(UnmanagedType.LPWStr)] string eventJSONString);

        public delegate EventCallBack GetEventCallBack(uint threadID);

        public static GetEventCallBack GetEventCallback = new GetEventCallBack(HVDriverManager.GetCallbackMethod);


        // Native methods imported from FSMonitorClient.dll starts here 
        [DllImport(FSMonitorClientDll)]
        private static extern int startClient([MarshalAs(UnmanagedType.FunctionPtr)]GetEventCallBack GetEventCallback);

        [DllImport(FSMonitorClientDll)]
        private static extern uint attachVolume([MarshalAs(UnmanagedType.LPWStr)]string volumeName);

        [DllImport(FSMonitorClientDll)]
        private static extern uint detachVolume([MarshalAs(UnmanagedType.LPWStr)]string volumeName);

        [DllImport(FSMonitorClientDll)]
        private static extern void ListDevices();

        private static void WritetoFile(string message, string filePath)
        {
            if (!LockObjects.ContainsKey(filePath))
            {
                LockObjects.Add(filePath, new Object());
            }

            lock (LockObjects[filePath])
            {
                if (!File.Exists(filePath))
                {
                    StreamWriter sws = File.CreateText(filePath);
                    sws.Close();
                }
                StreamWriter sw = File.AppendText(filePath);
                try
                {
                    sw.Write(message);
                }
                finally
                {
                    sw.Flush();
                    sw.Close();
                }                

            }          
        }

        public static void checkifCBTEventRequiredandwritetoCBTFile(string eventJson)
        {
            Dictionary<string, string> vhdtovmMap = new Dictionary<string, string>();
            try
            {
                
                //1. Find the matched VHD in vhdtovm doc
                bool isEventRequired = false;
                String eventJSONString1 = eventJson.Replace(@"\", @"\\");
                Dictionary<string, string> convertedDictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>(eventJSONString1);
                string vhdNamefromDriver = "-", matchedVHD = "-";
                if (convertedDictionary.TryGetValue("OldFileName", out vhdNamefromDriver))
                {
                    String[] array = File.ReadAllLines("C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\VHDtoVM.txt");
                   
                    for(int i = 0; i < array.Length; i += 2)
                    {
                        vhdtovmMap.Add(array[i], array[i+1]);
                    }

                    foreach (string vhd in vhdtovmMap.Keys)
                    {
                        string vhdwithoutvolumeName = vhd.Substring(Path.GetPathRoot(vhd).Length);
                       // if (vhdNamefromDriver.Contains(vhdwithoutvolumeName))
                        if (vhdNamefromDriver.IndexOf(vhdwithoutvolumeName, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            isEventRequired = true; //this is to ignore events that occur while backing up vhd
                            matchedVHD = vhd;
                            break;
                        }
                    }
                }

                if(isEventRequired)
                {
                    //2. FInd corresponding vmname from vhdtovm doc
                    string correspondingVMName = "-";
                    if (vhdtovmMap.TryGetValue(matchedVHD, out correspondingVMName))
                    {
                        if(!(correspondingVMName.Equals("-")))
                        {
                            //3. for all schedule files that contain this vm, add the cbt record
                            foreach (string fileName in Directory.EnumerateFiles("C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files", "*.txt"))
                            {
                                if (fileName.Contains("HypervLog") || fileName.Contains("VHDtoVM"))
                               {
                                   continue;
                               }

                               if (File.ReadAllText(fileName).Contains(correspondingVMName)) //if vm present in schedule
                               {
                                   string CBTfilePath = "C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\" + Path.GetFileNameWithoutExtension(fileName) + "\\" + correspondingVMName + "\\" + Path.GetFileNameWithoutExtension(matchedVHD) + ".txt";
                                   string message = ConstructCBTmessage(convertedDictionary);
                                   if (!(message.Equals("")))
                                   {
                                       WritetoFile(message, CBTfilePath);
                                   }
                               }
                            }                   
                            
                        }
                    }                    
                }
            }
            catch (Exception e)
            {
                HypervLog("processCBTEvent Exception : " + e.Message + e.StackTrace);
            }
        }

        public static string ConstructCBTmessage(Dictionary<string,string> convertedDictionary)
        {
            string CBTmessage = "";
            try
            {
                string temp = "";
                if (convertedDictionary.TryGetValue("hvWriteLength", out temp))
                {
                    CBTmessage = CBTmessage + temp + "\t";
                }
                else
                {
                    throw new Exception("ConstructCBTmessage Invalid CBT entry hvWriteLength. hence Quitting...");
                }

                if (convertedDictionary.TryGetValue("hvByteOffsetQuadPart", out temp))
                {
                    CBTmessage = CBTmessage + temp + "\t";
                }
                else
                {
                    throw new Exception("ConstructCBTmessage Invalid CBT entry hvByteOffsetQuadPart. hence Quitting...");
                }

                if (convertedDictionary.TryGetValue("hvByteOffsetLowPart", out temp))
                {
                    CBTmessage = CBTmessage + temp + "\t";
                }
                else
                {
                    throw new Exception("ConstructCBTmessage Invalid CBT entry hvByteOffsetLowPart. hence Quitting...");
                }

                if (convertedDictionary.TryGetValue("hvByteOffsetHighPart", out temp))
                {
                    CBTmessage = CBTmessage + temp + "\t";
                }
                else
                {
                    throw new Exception("ConstructCBTmessage Invalid CBT entry hvByteOffsetHighPart. hence Quitting...");
                }

            }
            catch(Exception e)
            {
                HypervLog("ConstructCBTmessage Exception : " + e.Message + e.StackTrace);
                CBTmessage = "";
            }
            return CBTmessage;
        }

        public static void HypervLog(string message)
        {
            try
            {
                string CBTfolderPath = "C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files";
                Directory.CreateDirectory(CBTfolderPath);
                string logFolderPath = "C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs";
                Directory.CreateDirectory(logFolderPath);
                string path = "C:\\Program Files\\ManageEngine\\RMPHVBackup\\Logs\\HypervLog_" + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
                if (!File.Exists(path))
                {
                    StreamWriter sws = File.CreateText(path);
                    sws.Close();
                }
                StreamWriter sw = File.AppendText(path);
                try
                {
                    sw.Write(DateTime.Now + " : " + message + Environment.NewLine);
                }
                finally
                {
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception e)
            {
                //Console.WriteLine("CS WMILogger : " + e.Message + e.StackTrace);
            }
        }

       public static int installandStartDriver()
        {
            try
            {
                RMPHVMonitorService.SetEnvironmentandMoveFiles();
                bool status = RMPHVMonitorService.SetupRMPHVMonitorSevice();
                if (!status)
                {
                    // If Driver installation or startup fails, report to FAP Server.
                    HypervLog("SetupRMPHVMonitorSevice FAILED");
                    return 1;
                }
                else
                {
                    HypervLog("SetupRMPHVMonitorSevice SUCCESS.");
                    return 0;
                }

            }
            catch (Exception e)
            {
                HypervLog("HVDriverManager installandStartDriver Exception : " + e.Message + e.StackTrace);
                return 1;
            }
        }

        public static int Main(string[] args)
        {
            int returnValue = -1;
            try
            {
                HypervLog("In HVDriverManager exe...operation -> " + args[0]);
                switch (args[0])
                {
                    case "startDriver": HypervLog("HVDriverManager exe Main Going to startDriver");//this case will be useful when machine is restarted. 
                        if (RMPHVMonitorService.IsServiceInstalled())//only start. attach to volumes
                        {
                            HypervLog("HVDriverManager exe Main Going to call StartService()");
                            RMPHVMonitorService.StartService();
                            HypervLog("HVDriverManager exe Main End to call StartService()");
                            HypervLog("HVDriverManager exe Main Going to call StartNativeEventListner()");
                            StartNativeEventListener();
                            HypervLog("HVDriverManager exe Main  StartNativeEventListner() SUCCESSFUL. Listener up and ready!!!");
                            HypervLog("HVDriverManager exe Main Going to call ReadVolumeFileandAttachVolume()");
                            ReadVolumeFileandAttachVolume();
                            HypervLog("HVDriverManager exe Main  ReadVolumeFileandAttachVolume() SUCCESSFUL. Driver up and ready!!!");
                            HypervLog("HVDriverManager exe Main startDriver Going to install dependencies...");
                            Installdependencies();
                            HypervLog("HVDriverManager exe Main  startDriver EVERYTHING READY..........................!!!!!!!!!!!!!");
                        }
                        else
                        {
                            HypervLog("HVDriverManager exe Main IsServiceInstalled-> False..!");
                        }
                        break;
                    case "startListener": HypervLog("HVDriverManager exe Main Going to install or uninstall RMPHVMonitor minifilter driver");//install and start -> no attaching
                        string isInstall = args[1];
                        if (isInstall.Contains("true"))
                        {
                            HypervLog("In HVDriverManager exe...INSTALLING driver");
                            int result = installandStartDriver();
                            if (result == 0)
                            {
                                HypervLog("HVDriverManager exe Main Going to call StartNativeEventListner()");
                                StartNativeEventListener();
                                HypervLog("HVDriverManager exe Main  StartNativeEventListner() SUCCESSFUL. Listener up and ready!!!");
                                HypervLog("HVDriverManager exe Main Going to call ReadVolumeFileandAttachVolume()");
                                ReadVolumeFileandAttachVolume();
                                HypervLog("HVDriverManager exe Main  ReadVolumeFileandAttachVolume() SUCCESSFUL. Driver up and ready and attached to volumes if any!!!");
                                HypervLog("HVDriverManager exe Main  Going to install dependencies...");
                                Installdependencies();
                                HypervLog("HVDriverManager exe Main  EVERYTHING READY..........................!!!!!!!!!!!!!");
                                return 0;
                            }
                            else
                            {
                                HypervLog("HVDriverManager exe Main Error in installing RMPHVMonitor minifilter driver. Return value -> " + result);
                                return 1;
                            }
                        }
                        else
                        {
                            HypervLog("In HVDriverManager exe...UNINSTALLING driver");
                            bool status = RMPHVMonitorService.UninstallService();
                            if (!status)
                            {
                                HypervLog("Uninstall Driver Service FAILED");
                                return 1;
                            }
                            else
                            {
                                HypervLog("Uninstall Driver Service SUCCESS.");
                                return 0;
                            }
                        }                        
                    case "newSchedule": HypervLog("HVDriverManager exe Main Starting doschedulerelatedCBTOperations ....");
                        returnValue = doschedulerelatedCBTOperations(args[1], args[2], args[3]);
                        break;
                    case "performBackup": HypervLog("HVDriverManager exe Main Starting performBackup ....");
                        returnValue = doHyperVBackup(args[1], args[2], args[3], args[4], args[5], args[6], args[7]);
                        break;
                    case "performRestore": HypervLog("HVDriverManager exe Main Starting performRestore ....");
                        returnValue = doHyperVRestore(args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12]);
                        break;
                    case "copyFiles": HypervLog("HVDriverManager exe Main Starting copyFiles ....");
                        returnValue = docopyVMfilesfromVSSSnapshot(args[1], args[2], args[3], args[4], args[5], args[6]);
                        break;
                    default: HypervLog("Invalid argument to HVDriverManager");
                        break;
                }
            }
            catch (Exception e)
            {
                HypervLog("HVDriverManager MAIN Exception : " + e.Message + e.StackTrace);
            }            
            return returnValue;
        }

        public static int doschedulerelatedCBTOperations(string hypervHostName, string scheduleName, string vmList)
        {
            HypervLog("doschedulerelatedCBTOperations starts scheduleName -> " + scheduleName);
            int returnStatus = 0;
            try
            {
                 string schedulepath = "C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\" + scheduleName + ".txt";

                if(vmList.Equals("-"))
                {
                    HypervLog("doschedulerelatedCBTOperations Backup Schedule Delete Operation...");
                    //delete backup schedule
                    if (File.Exists(schedulepath))
                    {
                        File.Delete(schedulepath);
                    }

                    //delete cbt folder
                    string cbtfolderPath = "C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\" + scheduleName;
                    Directory.Delete(cbtfolderPath, true);
                    HypervLog("doschedulerelatedCBTOperations Backup Schedule CBT Files Deleted...");
                    return returnStatus;
                }

                HypervLog("doschedulerelatedCBTOperations Calling writeVHDtoVMfilewhennewschedulecreated...");
                writeVHDtoVMfilewhennewschedulecreated(hypervHostName);
                HypervLog("doschedulerelatedCBTOperations Completed writeVHDtoVMfilewhennewschedulecreated...");

                if (File.Exists(schedulepath))
                {
                    File.Delete(schedulepath);
                }

                string[] allVMList = vmList.Split(';');
                
                for (int k=0;k<allVMList.Length;k++)
                {
                    string temp = allVMList[k];
                    HypervLog("VM Name added to schedule -> " + temp);
                    if(temp.Equals(""))
                    {
                        continue;
                    }               

                    //write schedule file
                    WritetoFile(temp + Environment.NewLine, schedulepath);
                    
                    //create corresponding folder
                    string CBTfolderPath = "C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\" + scheduleName + "\\" + temp;
                    Directory.CreateDirectory(CBTfolderPath);

                    //vhd
                    /* VHDtoVM.txt format
                     * VM1
                     * VHD1
                     * VM1
                     * AVHD1
                     * VM2
                     * VHD2
                     */

                    //find all vhds of the selected vms and attach the volumes to the driver
                    String[] array = File.ReadAllLines("C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\VHDtoVM.txt");
                    Dictionary<string, string> vhdtovmMap = new Dictionary<string, string>();
                    for(int i = 0; i < array.Length; i += 2)
                    {
                        vhdtovmMap.Add(array[i], array[i+1]);
                    }

                    foreach (string vhdpath in vhdtovmMap.Keys)
                    {
                        string driveLetter = Path.GetPathRoot(vhdpath);
                        HypervLog("HVDriverManager doschedulerelatedCBTOperations Attaching to drive -> " + driveLetter);
                        uint result = attachVolume(driveLetter);
                        string path = "C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\VolumeList.txt";
                        if (!File.Exists(path))
                        {
                            StreamWriter sws = File.CreateText(path);
                            sws.Close();
                        }
                        StreamWriter sw = File.AppendText(path);
                        try
                        {
                            sw.Write(driveLetter + Environment.NewLine);
                        }
                        finally
                        {
                            sw.Flush();
                            sw.Close();
                        }
                    }
                    
                }                

                //write vhdtovm file                
            }
            catch (Exception e)
            {
                HypervLog("HVDriverManager doschedulerelatedCBTOperations Exception : " + e.Message + e.StackTrace);
                returnStatus = 1;
            }
            HypervLog("doschedulerelatedCBTOperations ends.... -> ");
            return returnStatus;
        }

        public static void ReadVolumeFileandAttachVolume()
        {
            HypervLog("HVDriverManager ReadVolumeFileandAttachVolume started..!");
            try
            {
                String[] array = File.ReadAllLines("C:\\Program Files\\ManageEngine\\RMPHVBackup\\CBT Files\\VolumeList.txt");
                for (int i = 0; i < array.Length; i ++)
                {
                    string driveLetter = array[i];
                    HypervLog("HVDriverManager ReadVolumeFileandAttachVolume Attaching to drive -> " + driveLetter);
                    uint result = attachVolume(driveLetter);
                }
                HypervLog("HVDriverManager ReadVolumeFileandAttachVolume ended..!");
            }
            catch(Exception e)
            {
                HypervLog("HVDriverManager ReadVolumeFileandAttachVolume Exception : " + e.Message + e.StackTrace);
            }
        }

        public static void StartNativeEventListener()
        {
            Thread thread = new Thread(new ThreadStart(NativeListener));
            thread.Name = "Native Event Listener Thread";
            thread.Start();
        }

        public static void Installdependencies()
        {
            HypervLog("Starting Installdependencies...");
            HypervLog("Going to install vcredist_x64.exe..");
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.Arguments = "/s /v /qn /min";
            psi.CreateNoWindow = true;
            psi.WindowStyle = ProcessWindowStyle.Hidden;
            psi.FileName = "vcredist_x64.exe";
            psi.UseShellExecute = false;
            Process.Start(psi);
            HypervLog("vcredist_x64.exe.. Installation completed");
        }

        private static void NativeListener()
        {
            try
            {
                int result = HVDriverManager.startClient(GetEventCallback);
                //Logger.Driver.Info("FsMonitor NativeListener Thread exited:" + result);
            }
            catch (Exception e)
            {
                HypervLog("NativeListener Exception : " + e.Message + e.StackTrace);
            }
        }

        public static EventCallBack GetCallbackMethod(uint threadID)
        {
            EventCallBack callbackMethod = null;
            Console.WriteLine("Inside GetCallbackMethod()");
            if (EventListeners.ContainsKey(threadID))
            {
                callbackMethod = EventListeners[threadID].EventCallbackFromNative;
            }
            else
            {
                EventListener listenerObject = new EventListener(threadID);
                callbackMethod = new EventCallBack(listenerObject.EventCallbackFromNative);
                CallbackList.Add(callbackMethod);
                EventListeners.Add(threadID, listenerObject);
                Console.WriteLine("Creating New EventListener() for Thread [{0}], Total Count = {1}", threadID, EventListeners.Count);
            }


            /* if (threadID == 9)
             {
                 FsMonitor.attachVolumes(FolderManager.GetVolumesToAttach());
                 //FsMonitor.attachVolumes(DeviceDriverUtil.Drives);
                 FsMonitor.ListVolumeInfo();
             }*/

            return callbackMethod;
        }

        public static void attachVolumes(List<string> volumeList)
        {
            try
            {
                uint result;
                foreach (string volumeName in volumeList)
                {
                    //Logger.Driver.Info("Attaching to " + volumeName);
                    result = attachVolume(volumeName);
                    // Error Handling based on result
                }
            }
            catch (Exception e)
            {
                HypervLog("attachVolumes Exception : " + e.Message + e.StackTrace);
            }
        }

        public static void detachVolumes(List<string> volumeList)
        {
            try
            {
                uint result;
                foreach (string volumeName in volumeList)
                {
                    // Logger.Driver.Info("Detaching from " + volumeName);
                    result = detachVolume(volumeName);
                    // Error Handling based on result
                }
            }
            catch (Exception e)
            {
                HypervLog("detachVolumes Exception : " + e.Message + e.StackTrace);
            }
        }

        public static int doHyperVBackup(string hypervHostName, string fullbackupVMs, string incrementalbackupVMs, 
            string repositoryPath, string backupName, string scheduleName, string isanyVHDchanged)
        {
            int returnValue = 0;
            try
            {
                HypervLog("HVDriverManager.exe doHyperVBackup starts");
                returnValue = PerformHypervbackup(hypervHostName, fullbackupVMs, incrementalbackupVMs, repositoryPath, backupName, scheduleName, isanyVHDchanged);
                HypervLog("doHyperVBackup ends");
            }
            catch (Exception e)
            {
                HypervLog("HVDriverManager.exe doHyperVBackup Exception : " + e.Message + e.StackTrace);
                returnValue = 603;
            }
            return returnValue;
        }

        public static int docopyVMfilesfromVSSSnapshot(string hypervHostName, string vmName, string backupType, 
            string repositoryPath, string backupName, string scheduleName)
        {
            int returnValue = 0;
            try
            {
                HypervLog("HVDriverManager.exe docopyVMfilesfromVSSSnapshot starts");
                returnValue = copyVMfilesfromVSSSnapshot(hypervHostName, vmName, backupType, repositoryPath, backupName, scheduleName);
                HypervLog("docopyVMfilesfromVSSSnapshot ends");
            }
            catch (Exception e)
            {
                HypervLog("HVDriverManager.exe docopyVMfilesfromVSSSnapshot Exception : " + e.Message + e.StackTrace);
                returnValue = 603;
            }
            return returnValue;
        }

        public static int doHyperVRestore(string hypervHostName, string vmName, string vmfullbackupPath, string vmincrementalbackupPaths,string isOverwrite, string ischangeVMName,
            string newVMName, string isDiskRestore, string VHDnewstorageLocation, string isPowerOn, string isEncrypted, string isdecryptionSuccessful)
        {
            int returnValue = 0;
            try
            {
                HypervLog("HVDriverManager.exe doHyperVRestore starts...");
                returnValue = PerformHypervrestore(hypervHostName, vmName, vmfullbackupPath, vmincrementalbackupPaths,isOverwrite, ischangeVMName, newVMName, isDiskRestore,
                    VHDnewstorageLocation, isPowerOn, isEncrypted, isdecryptionSuccessful);
                HypervLog("HVDriverManager.exe doHyperVRestore ends");
            }
            catch (Exception e)
            {
                HypervLog("HVDriverManager.exe doHyperVRestore Exception : " + e.Message + e.StackTrace);
                returnValue = 603;
            }
            return returnValue;
        }


    }
}
