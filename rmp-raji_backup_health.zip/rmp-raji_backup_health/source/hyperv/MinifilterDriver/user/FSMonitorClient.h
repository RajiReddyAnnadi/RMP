/*++

Module Name:

    FSMonitorClient.h

Abstract:

    This module contains the structures and prototypes used by the user
    program to retrieve and see the log records recorded by MiniSpy.sys.

Environment:

    User mode

--*/
#ifndef __MSPYLOG_H__
#define __MSPYLOG_H__

#include <stdio.h>
#include <fltUser.h>
#include "FSMonitor.h"

#define DEFAULT_THREAD_COUNT        10
#define MAX_THREAD_COUNT            64

/* Function Pointer to Send Event to Dot net */
typedef int (*PSEND_EVENT)(LPWSTR);

/* Function Pointer to get Send Event Method() from Dot net */
typedef PSEND_EVENT (*PGET_EVENT_LISTENER)(unsigned int);

typedef int (*PSET_DOS_DEVICE_PATH)(LPWSTR, LPWSTR);

/* Stucture to store Thread Context */
typedef struct _EVENT_RECEIVER_THREAD_CONTEXT {

    	HANDLE Port;
    	HANDLE Completion;
	HANDLE ShutDown;
	BOOLEAN IsInitialized;
	BOOLEAN CleaningUp;
	PGET_EVENT_LISTENER GetEventListener;

} EVENT_RECEIVER_THREAD_CONTEXT, *PEVENT_RECEIVER_THREAD_CONTEXT;

extern  EVENT_RECEIVER_THREAD_CONTEXT evtReceiverContext;
EVENT_RECEIVER_THREAD_CONTEXT evtReceiverContext;

typedef struct _EVENT_THREAD_CONTEXT {

	unsigned int ThreadID;
	PSEND_EVENT SendEvent;

} EVENT_THREAD_CONTEXT, *PEVENT_THREAD_CONTEXT;

HANDLE threads[MAX_THREAD_COUNT];
extern EVENT_THREAD_CONTEXT ClientThreadContext[MAX_THREAD_COUNT];
EVENT_THREAD_CONTEXT ClientThreadContext[MAX_THREAD_COUNT];

//
// External functions
//

__declspec(dllexport) HRESULT _cdecl attachVolume(
	__in LPWSTR volumeName, __in PSET_DOS_DEVICE_PATH setDosDevicePath);

__declspec(dllexport) HRESULT _cdecl detachVolume(
	__in LPWSTR volumeName);

__declspec(dllexport) int _cdecl startClient (
	__in PGET_EVENT_LISTENER getEventListener);

/*__declspec(dllexport) VOID _cdecl ListDevices(
	__in PSET_DOS_DEVICE_PATH setDosDevicePath, __in LPWSTR driveLetter);*/

__declspec(dllexport) VOID _cdecl ListDevices();

__declspec(dllexport) VOID _cdecl shutdownClientThreads(VOID);


//
//  Function prototypes
//

int ulongToJSONFormat(
	__inout LPWSTR buffer,
	__in int bufferSize,
	__in LPWSTR Key,
	__in ULONG value);

PWCHAR toString(const wchar_t* message, ...);

PWCHAR getJSONString(
	__in PCHANGE_NOTIFICATION notification);


//
// Thread Function
//

DWORD
RetrieveEventFromKerneMode(
    __in LPVOID Context
    );


//
//  Values set for the Flags field in a RECORD_DATA structure.
//  These flags come from the FLT_CALLBACK_DATA structure.
//

#define FLT_CALLBACK_DATA_IRP_OPERATION         0x00000001  //  Set for Irp operations
#define FLT_CALLBACK_DATA_FAST_IO_OPERATION     0x00000002  //  Set for Fast Io operations
#define FLT_CALLBACK_DATA_FS_FILTER_OPERATION   0x00000004  //  Set for FsFilter operations

//
//  FltMgr's IRP major codes
//

#define IRP_MJ_ACQUIRE_FOR_SECTION_SYNCHRONIZATION  ((UCHAR)-1)
#define IRP_MJ_RELEASE_FOR_SECTION_SYNCHRONIZATION  ((UCHAR)-2)
#define IRP_MJ_ACQUIRE_FOR_MOD_WRITE                ((UCHAR)-3)
#define IRP_MJ_RELEASE_FOR_MOD_WRITE                ((UCHAR)-4)
#define IRP_MJ_ACQUIRE_FOR_CC_FLUSH                 ((UCHAR)-5)
#define IRP_MJ_RELEASE_FOR_CC_FLUSH                 ((UCHAR)-6)
#define IRP_MJ_NOTIFY_STREAM_FO_CREATION            ((UCHAR)-7)

#define IRP_MJ_FAST_IO_CHECK_IF_POSSIBLE            ((UCHAR)-13)
#define IRP_MJ_NETWORK_QUERY_OPEN                   ((UCHAR)-14)
#define IRP_MJ_MDL_READ                             ((UCHAR)-15)
#define IRP_MJ_MDL_READ_COMPLETE                    ((UCHAR)-16)
#define IRP_MJ_PREPARE_MDL_WRITE                    ((UCHAR)-17)
#define IRP_MJ_MDL_WRITE_COMPLETE                   ((UCHAR)-18)
#define IRP_MJ_VOLUME_MOUNT                         ((UCHAR)-19)
#define IRP_MJ_VOLUME_DISMOUNT                      ((UCHAR)-20)

//
//  Standard IRP Major codes
//

#define IRP_MJ_CREATE                       0x00
#define IRP_MJ_CREATE_NAMED_PIPE            0x01
#define IRP_MJ_CLOSE                        0x02
#define IRP_MJ_READ                         0x03
#define IRP_MJ_WRITE                        0x04
#define IRP_MJ_QUERY_INFORMATION            0x05
#define IRP_MJ_SET_INFORMATION              0x06
#define IRP_MJ_QUERY_EA                     0x07
#define IRP_MJ_SET_EA                       0x08
#define IRP_MJ_FLUSH_BUFFERS                0x09
#define IRP_MJ_QUERY_VOLUME_INFORMATION     0x0a
#define IRP_MJ_SET_VOLUME_INFORMATION       0x0b
#define IRP_MJ_DIRECTORY_CONTROL            0x0c
#define IRP_MJ_FILE_SYSTEM_CONTROL          0x0d
#define IRP_MJ_DEVICE_CONTROL               0x0e
#define IRP_MJ_INTERNAL_DEVICE_CONTROL      0x0f
#define IRP_MJ_SHUTDOWN                     0x10
#define IRP_MJ_LOCK_CONTROL                 0x11
#define IRP_MJ_CLEANUP                      0x12
#define IRP_MJ_CREATE_MAILSLOT              0x13
#define IRP_MJ_QUERY_SECURITY               0x14
#define IRP_MJ_SET_SECURITY                 0x15
#define IRP_MJ_POWER                        0x16
#define IRP_MJ_SYSTEM_CONTROL               0x17
#define IRP_MJ_DEVICE_CHANGE                0x18
#define IRP_MJ_QUERY_QUOTA                  0x19
#define IRP_MJ_SET_QUOTA                    0x1a
#define IRP_MJ_PNP                          0x1b
#define IRP_MJ_MAXIMUM_FUNCTION             0x1b

//
//  IRP minor codes
//

#define IRP_MN_QUERY_DIRECTORY              0x01
#define IRP_MN_NOTIFY_CHANGE_DIRECTORY      0x02
#define IRP_MN_USER_FS_REQUEST              0x00
#define IRP_MN_MOUNT_VOLUME                 0x01
#define IRP_MN_VERIFY_VOLUME                0x02
#define IRP_MN_LOAD_FILE_SYSTEM             0x03
#define IRP_MN_TRACK_LINK                   0x04
#define IRP_MN_LOCK                         0x01
#define IRP_MN_UNLOCK_SINGLE                0x02
#define IRP_MN_UNLOCK_ALL                   0x03
#define IRP_MN_UNLOCK_ALL_BY_KEY            0x04
#define IRP_MN_NORMAL                       0x00
#define IRP_MN_DPC                          0x01
#define IRP_MN_MDL                          0x02
#define IRP_MN_COMPLETE                     0x04
#define IRP_MN_COMPRESSED                   0x08
#define IRP_MN_MDL_DPC                      (IRP_MN_MDL | IRP_MN_DPC)
#define IRP_MN_COMPLETE_MDL                 (IRP_MN_COMPLETE | IRP_MN_MDL)
#define IRP_MN_COMPLETE_MDL_DPC             (IRP_MN_COMPLETE_MDL | IRP_MN_DPC)
#define IRP_MN_SCSI_CLASS                   0x01
#define IRP_MN_START_DEVICE                 0x00
#define IRP_MN_QUERY_REMOVE_DEVICE          0x01
#define IRP_MN_REMOVE_DEVICE                0x02
#define IRP_MN_CANCEL_REMOVE_DEVICE         0x03
#define IRP_MN_STOP_DEVICE                  0x04
#define IRP_MN_QUERY_STOP_DEVICE            0x05
#define IRP_MN_CANCEL_STOP_DEVICE           0x06
#define IRP_MN_QUERY_DEVICE_RELATIONS       0x07
#define IRP_MN_QUERY_INTERFACE              0x08
#define IRP_MN_QUERY_CAPABILITIES           0x09
#define IRP_MN_QUERY_RESOURCES              0x0A
#define IRP_MN_QUERY_RESOURCE_REQUIREMENTS  0x0B
#define IRP_MN_QUERY_DEVICE_TEXT            0x0C
#define IRP_MN_FILTER_RESOURCE_REQUIREMENTS 0x0D
#define IRP_MN_READ_CONFIG                  0x0F
#define IRP_MN_WRITE_CONFIG                 0x10
#define IRP_MN_EJECT                        0x11
#define IRP_MN_SET_LOCK                     0x12
#define IRP_MN_QUERY_ID                     0x13
#define IRP_MN_QUERY_PNP_DEVICE_STATE       0x14
#define IRP_MN_QUERY_BUS_INFORMATION        0x15
#define IRP_MN_DEVICE_USAGE_NOTIFICATION    0x16
#define IRP_MN_SURPRISE_REMOVAL             0x17
#define IRP_MN_QUERY_LEGACY_BUS_INFORMATION 0x18
#define IRP_MN_WAIT_WAKE                    0x00
#define IRP_MN_POWER_SEQUENCE               0x01
#define IRP_MN_SET_POWER                    0x02
#define IRP_MN_QUERY_POWER                  0x03
#define IRP_MN_QUERY_ALL_DATA               0x00
#define IRP_MN_QUERY_SINGLE_INSTANCE        0x01
#define IRP_MN_CHANGE_SINGLE_INSTANCE       0x02
#define IRP_MN_CHANGE_SINGLE_ITEM           0x03
#define IRP_MN_ENABLE_EVENTS                0x04
#define IRP_MN_DISABLE_EVENTS               0x05
#define IRP_MN_ENABLE_COLLECTION            0x06
#define IRP_MN_DISABLE_COLLECTION           0x07
#define IRP_MN_REGINFO                      0x08
#define IRP_MN_EXECUTE_METHOD               0x09

//
//  IRP Flags
//

#define IRP_NOCACHE                     0x00000001
#define IRP_PAGING_IO                   0x00000002
#define IRP_SYNCHRONOUS_API             0x00000004
#define IRP_SYNCHRONOUS_PAGING_IO       0x00000040

#endif //__MSPYLOG_H__

/* Client side structure declaration for client/server communication - Starts */

#ifndef __CLIENT_COMMUNICATOR_H__
#define __CLIENT_COMMUNICATOR_H__

#pragma pack(1)

typedef struct _CHANGE_NOTIFICATION_MESSAGE {

    //
    //  Required structure header.
    //

    FILTER_MESSAGE_HEADER MessageHeader;

    //
    //  Private scanner-specific fields begin here.
    //

    CHANGE_NOTIFICATION Notification;

    //
    //  Overlapped structure: this is not really part of the message
    //  However we embed it instead of using a separately allocated overlap structure
    //

    OVERLAPPED Ovlp;
    
} CHANGE_NOTIFICATION_MESSAGE, *PCHANGE_NOTIFICATION_MESSAGE;

typedef struct _CHANGE_NOTIFICATION_REPLY_MESSAGE {

    //
    //  Required structure header.
    //

    FILTER_REPLY_HEADER ReplyHeader;

    //
    //  Private scanner-specific fields begin here.
    //

    CHANGE_NOTIFICATION_REPLY Reply;

} CHANGE_NOTIFICATION_REPLY_MESSAGE, *PCHANGE_NOTIFICATION_REPLY_MESSAGE;

#endif //  __CLIENT_COMMUNICATOR_H_

/* Client side structure declaration for client/server communication - Ends */


