/*++

Module Name:

FsMonitorClient.c

Abstract:

This file contains the implementation for the main function of the
user application piece of MiniSpy.  This function is responsible for
controlling the command mode available to the user to control the
kernel mode driver.

Environment:

User mode

--*/

#include <DriverSpecs.h>
__user_code

#include <stdlib.h>
#include <stdio.h>
#include <wchar.h>
#include <windows.h>
#include <assert.h>
#include "FSMonitorClient.h"
#include <strsafe.h>


#define SUCCESS              	0
#define USAGE_ERROR          	1
#define FILTER_NAME         	L"RMPHVMonitor"

VOID
	DisplayError (
	__in DWORD Code
	)

	/*++

	Routine Description:

	This routine will display an error message based off of the Win32 error
	code that is passed in. This allows the user to see an understandable
	error message instead of just the code.

	Arguments:

	Code - The error code to be translated.

	Return Value:

	None.

	--*/

{
	__nullterminated WCHAR buffer[MAX_PATH] = { 0 }; 
	DWORD count;
	HMODULE module = NULL;
	HRESULT status;

	count = FormatMessage (FORMAT_MESSAGE_FROM_SYSTEM,
		NULL,
		Code,
		0,
		buffer,
		sizeof(buffer) / sizeof(WCHAR),
		NULL);


	if (count == 0) {

		count = GetSystemDirectory( buffer,
			sizeof(buffer) / sizeof( WCHAR ) );

		if (count==0 || count > sizeof(buffer) / sizeof( WCHAR )) {

			//
			//  In practice we expect buffer to be large enough to hold the 
			//  system directory path. 
			//

			printf("    Could not translate error: %d\n", Code);
			return;
		}


		status = StringCchCat( buffer,
			sizeof(buffer) / sizeof( WCHAR ),
			L"\\fltlib.dll" );

		if (status != S_OK) {

			printf("    Could not translate error: %d\n", Code);
			return;
		}

		module = LoadLibraryExW( buffer, NULL, LOAD_LIBRARY_AS_DATAFILE );

		//
		//  Translate the Win32 error code into a useful message.
		//

		count = FormatMessage (FORMAT_MESSAGE_FROM_HMODULE,
			module,
			Code,
			0,
			buffer,
			sizeof(buffer) / sizeof(WCHAR),
			NULL);

		if (module != NULL) {

			FreeLibrary( module );
		}

		//
		//  If we still couldn't resolve the message, generate a string
		//

		if (count == 0) {

			printf("    Could not translate error: %d\n", Code);
			return;
		}
	}

	//
	//  Display the translated error.
	//

	printf("    %ws\n", buffer);
}

//
//  Main uses a loop which has an assignment in the while 
//  conditional statement. Suppress the compiler's warning.
//

int _cdecl startClient(
	__in PGET_EVENT_LISTENER getEventListener)
	/*++

	Routine Description:

	Main routine for minispy

	Arguments:

	getEventListener - function pointer of callback method to notify change to C#

	Return Value:

	--*/
{
	HANDLE port = INVALID_HANDLE_VALUE, completion = NULL;
	HRESULT hResult = S_OK, hr;
	DWORD result;
	ULONG threadId;
	//HANDLE thread = NULL;
	CHAR inputChar;
	DWORD threadCount = DEFAULT_THREAD_COUNT;

	unsigned int i = 0;

	//
	//  Initialize handle in case of error
	//
	evtReceiverContext.IsInitialized = FALSE;
	evtReceiverContext.Port = port;
	evtReceiverContext.Completion = completion;
	evtReceiverContext.CleaningUp = FALSE;
	evtReceiverContext.GetEventListener = getEventListener;
	//
	//  Open the port that is used to talk to
	//  MiniSpy.
	//

	printf("Connecting to filter's port...\n");

	hResult = FilterConnectCommunicationPort(FSM_PORT_NAME,
		0,
		NULL,
		0,
		NULL,
		&port);

	if (IS_ERROR(hResult)) {

		printf("Could not connect to filter: 0x%08x\n", hResult);
		DisplayError(hResult);
		goto Main_Exit;
	}

	//---------------------------------------------------------------------------------------
	//
	//  Create a completion port to associate with this handle.
	//

	completion = CreateIoCompletionPort(port,
		NULL,
		0,
		threadCount);

	if (completion == NULL) {

		printf("ERROR: Creating completion port: %d\n", GetLastError());
		CloseHandle(port);
		goto Main_Exit;
	}

	printf("Scanner: Port = 0x%p Completion = 0x%p\n", port, completion);

	evtReceiverContext.Port = port;
	evtReceiverContext.Completion = completion;

	for (i = 0; i < DEFAULT_THREAD_COUNT; i++)
	{
		ClientThreadContext[i].ThreadID = i;
		printf("---------> Before\n");
		ClientThreadContext[i].SendEvent = getEventListener(i);
		printf("---------> After\n");
		// Close Handle When exiting
		threads[i] = CreateThread(NULL,
			0,
			(LPTHREAD_START_ROUTINE)RetrieveEventFromKerneMode,
			&ClientThreadContext[i],
			0,
			&threadId);
		if (threads[i] == NULL) {

			//
			//  Couldn't create thread.
			//

			hr = GetLastError();
			printf("ERROR: Couldn't create thread: %d\n", hr);
			goto Main_Exit;
		}

		printf("\nThread Id [%d]: %p", i, threads[i]);

	}

	fflush(stdout);
	evtReceiverContext.IsInitialized = TRUE;
	printf("Cleaning Threads..Waiting for Threads to Close\n");
	WaitForMultipleObjectsEx(DEFAULT_THREAD_COUNT, threads, TRUE, INFINITE, FALSE);
	printf("Wait Complete\n");

Main_Exit:

	for (i = 0; i < DEFAULT_THREAD_COUNT; i++)
	{
		if (threads[i]) {
			CloseHandle(threads[i]);
		}
	}
	if (evtReceiverContext.IsInitialized == FALSE)
	{
		printf("Closing Handles\n");

		if (INVALID_HANDLE_VALUE != evtReceiverContext.Port) {
			CloseHandle(evtReceiverContext.Port);
		}

		if (evtReceiverContext.Completion) {
			CloseHandle(evtReceiverContext.Completion); // Check for Failure case
		}
	}
	printf("ShutDown Complete\n");

	return 0;
}


ULONG
	IsAttachedToVolume(
	__in LPCWSTR VolumeName
	)
	/*++

	Routine Description:

	Determine if our filter is attached to this volume

	Arguments:

	VolumeName - The volume we are checking

	Return Value:

	TRUE - we are attached
	FALSE - we are not attached (or we couldn't tell)

	--*/
{
	PWCHAR filtername;
	CHAR buffer[1024];
	PINSTANCE_FULL_INFORMATION data = (PINSTANCE_FULL_INFORMATION)buffer;
	HANDLE volumeIterator = INVALID_HANDLE_VALUE;
	ULONG bytesReturned;
	ULONG instanceCount = 0;
	HRESULT hResult;

	//
	//  Enumerate all instances on this volume
	//

	hResult = FilterVolumeInstanceFindFirst( VolumeName,
		InstanceFullInformation,
		data,
		sizeof(buffer)-sizeof(WCHAR),
		&bytesReturned,
		&volumeIterator );

	if (IS_ERROR( hResult )) {

		return instanceCount;
	}

	do {

		assert((data->FilterNameBufferOffset+data->FilterNameLength) <= (sizeof(buffer)-sizeof(WCHAR)));
		__analysis_assume((data->FilterNameBufferOffset+data->FilterNameLength) <= (sizeof(buffer)-sizeof(WCHAR)));

		//
		//  Get the name.  Note that we are NULL terminating the buffer
		//  in place.  We can do this because we don't care about the other
		//  information and we have guaranteed that there is room for a NULL
		//  at the end of the buffer.
		//


		filtername = (PWCHAR) Add2Ptr(data,data->FilterNameBufferOffset);
		filtername[data->FilterNameLength/sizeof( WCHAR )] = L'\0';

		//
		//  Bump the instance count when we find a match
		//

		if (_wcsicmp(filtername,FILTER_NAME) == 0) {

			instanceCount++;
		}

	} while (SUCCEEDED( FilterVolumeInstanceFindNext( volumeIterator,
		InstanceFullInformation,
		data,
		sizeof(buffer)-sizeof(WCHAR),
		&bytesReturned ) ));

	//
	//  Close the handle
	//

	FilterVolumeInstanceFindClose( volumeIterator );
	return instanceCount;
}


void _cdecl	ListDevices(VOID)
/*++

Routine Description:

Display the volumes we are attached to

Arguments:

Return Value:

--*/
{
	UCHAR buffer[1024];
	PFILTER_VOLUME_BASIC_INFORMATION volumeBuffer = (PFILTER_VOLUME_BASIC_INFORMATION)buffer;
	HANDLE volumeIterator = INVALID_HANDLE_VALUE;
	ULONG volumeBytesReturned;
	HRESULT hResult = S_OK;
	__nullterminated WCHAR driveLetter[15] = { 0 };
	ULONG instanceCount;

	try {

		//
		//  Find out size of buffer needed
		//

		hResult = FilterVolumeFindFirst(FilterVolumeBasicInformation,
			volumeBuffer,
			sizeof(buffer)-sizeof(WCHAR),   //save space to null terminate name
			&volumeBytesReturned,
			&volumeIterator);

		if (IS_ERROR(hResult)) {

			return;
		}

		assert(INVALID_HANDLE_VALUE != volumeIterator);

		//
		//  Output the header
		//

		printf("\n"
			"Dos Name        Volume Name                            Status \n"
			"--------------  ------------------------------------  --------\n");

		//
		//  Loop through all of the filters, displaying instance information
		//

		do {

			assert((FIELD_OFFSET(FILTER_VOLUME_BASIC_INFORMATION, FilterVolumeName) + volumeBuffer->FilterVolumeNameLength) <= (sizeof(buffer)-sizeof(WCHAR)));
			__analysis_assume((FIELD_OFFSET(FILTER_VOLUME_BASIC_INFORMATION, FilterVolumeName) + volumeBuffer->FilterVolumeNameLength) <= (sizeof(buffer)-sizeof(WCHAR)));

			volumeBuffer->FilterVolumeName[volumeBuffer->FilterVolumeNameLength / sizeof(WCHAR)] = UNICODE_NULL;

			instanceCount = IsAttachedToVolume(volumeBuffer->FilterVolumeName);

			printf("%-14ws  %-36ws  %s",
				(SUCCEEDED(FilterGetDosName(
				volumeBuffer->FilterVolumeName,
				driveLetter,
				sizeof(driveLetter) / sizeof(WCHAR))) ? driveLetter : L""),
				volumeBuffer->FilterVolumeName,
				(instanceCount > 0) ? "Attached" : "");

			if (instanceCount > 1) {

				printf(" (%d)\n", instanceCount);

			}
			else {

				printf("\n");
			}

		} while (SUCCEEDED(hResult = FilterVolumeFindNext(volumeIterator,
			FilterVolumeBasicInformation,
			volumeBuffer,
			sizeof(buffer)-sizeof(WCHAR),    //save space to null terminate name
			&volumeBytesReturned)));

		if (HRESULT_FROM_WIN32(ERROR_NO_MORE_ITEMS) == hResult) {

			hResult = S_OK;
		}

	}
	finally {

		if (INVALID_HANDLE_VALUE != volumeIterator) {

			FilterVolumeFindClose(volumeIterator);
		}

		if (IS_ERROR(hResult)) {

			if (HRESULT_FROM_WIN32(ERROR_NO_MORE_ITEMS) == hResult) {

				printf("No volumes found.\n");

			}
			else {

				printf("Volume listing failed with error: 0x%08x\n",
					hResult);
			}
		}
	}
}

/*
*
* Event Receiver Client Thread
*
*/
DWORD
	RetrieveEventFromKerneMode(
	__in LPVOID ThreadContext
	)
	/*++

	Routine Description

	This is a worker thread that


	Arguments

	Context  - This thread context has a pointer to the port handle we use to send/receive messages,
	and a completion port handle that was already associated with the comm. port by the caller

	Return Value

	HRESULT indicating the status of thread exit.

	--*/
{
	PEVENT_THREAD_CONTEXT Context = (PEVENT_THREAD_CONTEXT) ThreadContext;
	PCHANGE_NOTIFICATION notification;
	CHANGE_NOTIFICATION_REPLY_MESSAGE replyMessage;
	PCHANGE_NOTIFICATION_MESSAGE message, msg;
	LPOVERLAPPED pOvlp;
	BOOL result;
	DWORD outSize;
	HRESULT hr;
	ULONG_PTR key;
	BOOL res;
	int ret;
	__int64 time;
	WCHAR buffer[1024];
	PWCHAR jsonString=NULL,tempBuffer=NULL;
	DWORD processID;

	processID = GetCurrentProcessId();
	printf( "\n-->Entering Thread");
#pragma warning(push)
#pragma warning(disable:4127) // conditional expression is constant

	while (TRUE) {

#pragma warning(pop)


		message = NULL;
		if (evtReceiverContext.CleaningUp) {

			break;
		}
		msg = (PCHANGE_NOTIFICATION_MESSAGE ) malloc( sizeof( CHANGE_NOTIFICATION_MESSAGE ) );

		if (msg == NULL) {

			hr = ERROR_NOT_ENOUGH_MEMORY;
			break;
		}

		memset( &msg->Ovlp, 0, sizeof( OVERLAPPED ) );

		//
		//  Request messages from the filter driver.
		//

		hr = FilterGetMessage( evtReceiverContext.Port,
			&msg->MessageHeader,
			sizeof(CHANGE_NOTIFICATION_MESSAGE),
			//                                   FIELD_OFFSET( CHANGE_NOTIFICATION_MESSAGE, Ovlp ),
			&msg->Ovlp );
		//printf( "\n-->( 1 ) Client FilterGetMessage");
		if (hr != HRESULT_FROM_WIN32( ERROR_IO_PENDING )) {
			printf( "\n-->Break 1");
			free( msg );
			break;
		}

		//
		//  Poll for messages from the filter component to scan.
		//

		result = GetQueuedCompletionStatus( evtReceiverContext.Completion, &outSize, &key, &pOvlp, INFINITE );

		//
		//  Obtain the message: note that the message we sent down via FltGetMessage() may NOT be
		//  the one dequeued off the completion queue: this is solely because there are multiple
		//  threads per single port handle. Any of the FilterGetMessage() issued messages can be
		//  completed in random order - and we will just dequeue a random one.		

		if (!result) {

			//
			//  An error occured.
			//
			printf( "\n-->Break 2 [%d][%d][%d][%d]",outSize, sizeof(CHANGE_NOTIFICATION_MESSAGE),sizeof(CHANGE_NOTIFICATION),sizeof(OVERLAPPED));
			hr = HRESULT_FROM_WIN32( GetLastError() );
			break;
		}

		message = CONTAINING_RECORD( pOvlp, CHANGE_NOTIFICATION_MESSAGE, Ovlp );
		notification = &message->Notification;

		//printf( "\n-->Collecting Events->1");


		// Used to skip events triggered by FapAgent.exe
		if(processID != (DWORD) notification->ProcessId) 
		{
			printf("\nData received -> %ws,%lu,%lu,%ld,%lld", notification->OldFileName, notification->hvWriteLength, notification->hvByteOffsetLowPart, notification->hvByteOffsetHighPart, notification->hvByteOffsetQuadPart);
			jsonString = getJSONString(notification);
			if(jsonString !=NULL)
			{
				//printf( "\nMessage [%d] , [%d]>>%ws", Context->ThreadID, wcslen(data), data);
				Context->SendEvent((LPWSTR)jsonString);
				free(jsonString);
			} 
			else
			{
				printf( "\njsonString = NULL");
			}
		}
		/*replyMessage.ReplyHeader.Status = 0;
		replyMessage.ReplyHeader.MessageId = message->MessageHeader.MessageId;
		//
		//  Need to invert the boolean -- result is true if found
		//  foul language, in which case SafeToOpen should be set to false.
		//

		replyMessage.Reply.SafeToOpen = TRUE;

		hr = FilterReplyMessage( evtReceiverContext.Port,
			(PFILTER_REPLY_HEADER) &replyMessage,
			sizeof( replyMessage ) );

		if (SUCCEEDED( hr ) || hr == ERROR_FLT_NO_WAITER_FOR_REPLY) {

			//printf( "Replying message [%d], SafeToOpen: %d\n", GetCurrentThreadId(), replyMessage.Reply.SafeToOpen );
		} else {

			printf( "Scanner: Error replying message. Error = 0x%p\n", hr );
			break;
		}*/
		if(message!=NULL)
		{
			free(message);
			message = NULL;
		}
	}

	if (!SUCCEEDED( hr )) {

		if (hr == HRESULT_FROM_WIN32( ERROR_INVALID_HANDLE )) {

			//
			//  Scanner port disconncted.
			//

			printf( "Scanner: Port is disconnected, probably due to scanner filter unloading.\n" );

		} else {

			printf( "Scanner: Unknown error occurred. Error = 0x%X\n", hr );
		}
	}
	if(message!=NULL)
	{
		free(message);
		message = NULL;
	}
	printf( "Thread Exit\n" );
	return hr;
}

int ulongToJSONFormat(
	__inout LPWSTR buffer,
	__in int bufferSize,
	__in LPWSTR key,
	__in ULONG value)
{
	int result = 0; 
	result = _snwprintf_s(buffer,bufferSize,bufferSize,L"\'%ws\':\'%ul\'",key,value);
	//printf("\n->%S", buffer );
	return result;
}

HRESULT _cdecl attachVolume(
	__in LPWSTR volumeName, 
	__in PSET_DOS_DEVICE_PATH setDosDevicePath)
{
	HRESULT hResult;
	WCHAR instanceName[INSTANCE_NAME_MAX_CHARS + 1];

	// Validate FilterAttach parameters before method invocation 
	hResult = FilterAttach( FILTER_NAME,
		(PWSTR)volumeName,
		NULL, // instance name
		sizeof(instanceName ),
		instanceName );
	if (SUCCEEDED( hResult )) {
		printf( "\n---> Attaching to Instance name: %S, Volume:%S\n", instanceName, volumeName );
		//ListDevices(setDosDevicePath, volumeName);
		ListDevices();

	} else {

		printf( "\n---> Could not attach to device: 0x%08x\n", hResult );
		DisplayError( hResult );
	}
	return hResult;
}

HRESULT _cdecl detachVolume(
	__in LPWSTR volumeName)
{
	HRESULT hResult;
	WCHAR instanceName[INSTANCE_NAME_MAX_CHARS + 1];

	hResult = FilterDetach( FILTER_NAME,
		(PWSTR)volumeName,
		NULL);

	if (SUCCEEDED( hResult )) {

		printf( "\n---> Detaching from Volume:%S\n", volumeName );

	} else {

		printf( "\n---> Could not detach from device: 0x%08x\n", hResult );
		DisplayError( hResult );
	}
	return hResult;
}

PWCHAR toString(const wchar_t* message, ...) //For LPWSTR prints use this log
{
	va_list args;
	int len,res;
	wchar_t * buffer=NULL;
	va_start(args, message);
	len = _vscwprintf(message, args) + 1;
	buffer = (wchar_t*)malloc(len * sizeof(wchar_t));
	if (buffer != NULL)
	{
		SecureZeroMemory((PVOID)buffer,len * sizeof(wchar_t));
		res=vswprintf_s(buffer, len, message, args);
		/*if (res)//Write exact error hanlding for this
		{
			//printf("\nReturn Value = %d", res);
		} else 
		{
			printf("\nError in toString(), vswprintf_s");
		}	*/

			if(!res)
			{
				printf("\nError in toString(), vswprintf_s");
			}
	} else
	{
		printf("\nMemory Allocation Failed...\n");
	}
	return buffer;
}

VOID _cdecl shutdownClientThreads(VOID)
{
	evtReceiverContext.CleaningUp = TRUE;
	printf("ShutDown Invoked\n");
	
	if (INVALID_HANDLE_VALUE != evtReceiverContext.Port) {
		CloseHandle( evtReceiverContext.Port);
	}

	if (evtReceiverContext.Completion) {
		CloseHandle( evtReceiverContext.Completion ); // Check for Failure case
	}

}

PWCHAR getJSONString(
	__in PCHANGE_NOTIFICATION notification)
{
	PWCHAR jsonString = NULL, tempBuffer = NULL;
	WCHAR tokSource[TOKEN_SOURCE_LENGTH+1];

	jsonString = toString(L"\"%ws\":%lu", L"ProcessID", (ULONG)notification->ProcessId);//1st Entry json string
	tempBuffer = jsonString;
	if(jsonString==NULL) return jsonString;

	jsonString = toString(L"%ws,\"%ws\":%lu", jsonString, L"ThreadID", (ULONG)notification->ThreadId);
	if(tempBuffer) free(tempBuffer); 
	if(jsonString==NULL) return jsonString;
	tempBuffer = jsonString;

	jsonString = toString(L"%ws,\"%ws\":\"%ws\"", jsonString, L"OldFileName", notification->OldFileName);
	if (tempBuffer) free(tempBuffer);
	if (jsonString == NULL) return jsonString;
	tempBuffer = jsonString;

	jsonString = toString(L"%ws,\"%ws\":%lu", jsonString, L"hvWriteLength", (ULONG)notification->hvWriteLength);
	if (tempBuffer) free(tempBuffer);
	if (jsonString == NULL) return jsonString;
	tempBuffer = jsonString;

	jsonString = toString(L"%ws,\"%ws\":%lu", jsonString, L"hvByteOffsetLowPart", (ULONG)notification->hvByteOffsetLowPart);
	if (tempBuffer) free(tempBuffer);
	if (jsonString == NULL) return jsonString;
	tempBuffer = jsonString;

	jsonString = toString(L"%ws,\"%ws\":%ld", jsonString, L"hvByteOffsetHighPart", (LONG)notification->hvByteOffsetHighPart);
	if (tempBuffer) free(tempBuffer);
	if (jsonString == NULL) return jsonString;
	tempBuffer = jsonString;

	jsonString = toString(L"%ws,\"%ws\":%I64d", jsonString, L"hvByteOffsetQuadPart", (LONGLONG)notification->hvByteOffsetQuadPart);
	if (tempBuffer) free(tempBuffer);
	if (jsonString == NULL) return jsonString;
	tempBuffer = jsonString;

	jsonString = toString(L"{%ws}", jsonString);//final brace for json string
	if(tempBuffer) free(tempBuffer); 

	//printf("\n--->>%ws",jsonString);
	return jsonString;
}
