/*++

Module Name:

    FSMonitorKern.h

Abstract:
    Header file which contains the structures, type definitions,
    constants, global variables and function prototypes that are
    only visible within the kernel.

Environment:

    Kernel mode

--*/

#ifndef __MSPYKERN_H__
#define __MSPYKERN_H__

#include <fltKernel.h>
#include <suppress.h>
#include "FSMonitor.h"

#pragma prefast(disable:__WARNING_ENCODE_MEMBER_FUNCTION_POINTER, "Not valid for kernel mode drivers")

//
//  Memory allocation tag
//

#define FSM_INSTANCE_CONTEXT_POOL_TAG    	'nIsF'
#define FSM_STREAMHANDLE_CONTEXT_POOL_TAG  	'xSsF'
#define FSM_STREAM_CONTEXT_POOL_TAG      	'cSsF'
#define FSM_PREOP_DATA_POOL_TAG       		'dPsF'
#define FSM_VOLUME_PROP_POOL_TAG       		'pVsF'
#define FSM_USER_SID_POOL_TAG       		'sUsF'
#define FSM_TOKEN_SOURCE_POOL_TAG      		'sTsF'
#define FSM_PROCESS_NAME_POOL_TAG      		'nPsF'

//
//  Vista define for including transaction support
//

#define OS_VERSION_GREATER_THAN_VISTA    (NTDDI_VERSION >= NTDDI_VISTA)
#define OS_VERSION_GREATER_THAN_W2K  (OSVER(NTDDI_VERSION) > NTDDI_WIN2K)

#define DF_VOLUME_GUID_NAME_SIZE        48

#define DF_CONTEXT_POOL_TYPE            NonPagedPool

#define FlagOnAll( F, T )                                                    \
    (FlagOn( F, T ) == T)

#define SetBitOnFlag( Var, Flag ) 		Var = ( Var | Flag)
#define ResetBitOnFlag( Var, Flag ) 		Var = ( Var & (~Flag))


//---------------------------------------------------------------------------//
//  ReFS Compatibility Helpers                                               //
//---------------------------------------------------------------------------//

//
//  This helps us deal with ReFS 128-bit file IDs and NTFS 64-bit file IDs.
//

typedef union _FSM_FILE_REFERENCE {

    struct {
        ULONGLONG   Value;          //  The 64-bit file ID lives here.
        ULONGLONG   UpperZeroes;    //  In a 64-bit file ID this will be 0.
    } FileId64;

    UCHAR           FileId128[16];  //  The 128-bit file ID lives here.
    
} FSM_FILE_REFERENCE, *PFSM_FILE_REFERENCE;

//---------------------------------------------------------------------------//
//  Types                                                                    //
//---------------------------------------------------------------------------//

//
//  This is the instance context for this minifilter, it stores the volume's
//  GUID name.
//

typedef struct _FSM_INSTANCE_CONTEXT {

    //
    //  Volume GUID name.
    //

    UNICODE_STRING VolumeGuidName;

} FSM_INSTANCE_CONTEXT, *PFSM_INSTANCE_CONTEXT;


//
//  This is the stream context for this minifilter, attached whenever a stream
//  becomes a candidate for deletion.
//

typedef struct _FSM_STREAMHANDLE_CONTEXT {

    //
    //  FLT_FILE_NAME_INFORMATION structure with the names for this stream
    //  and file. This is only used for printing out the opened name when
    //  notifying deletes. This will be the result of an opened query name
    //  done at the last pre-cleanup on the file/stream.
    //
    //  Therefore, there is no requirement of maintaining the file name
    //  information (for the purposes we use it) in sync with the FltMgr name
    //  cache or the file system. This makes it okay to store it in the stream
    //  context.
    //

    PFLT_FILE_NAME_INFORMATION  NameInfo;

    //
    //  File ID, obtained from querying the file system for FileInternalInformation.
    //  If the File ID is 128 bits (as in ReFS) we get it via FileIdInformation.
    //

    FSM_FILE_REFERENCE           FileId;

    //
    //  Number of SetDisp operations in flight.
    //

    volatile LONG               NumOps;

    //
    //  IsNotified == 1 means a file/stream deletion was already notified.
    //

    volatile LONG               IsNotified;

    //
    //  EventNotificationFlag - Action specific bits are set to 1 for each type action in this stream.
    //

    volatile LONG               EventNotificationFlag;

    //
    //  Whether or not we've already queried the file ID.
    //

    BOOLEAN                     FileIdSet;

    //
    //  Delete Disposition for this stream.
    //

    BOOLEAN                     SetDisp;

    //
    //  Delete-on-Close state for this stream.
    //

    BOOLEAN                     DeleteOnClose;

    //
    //  UserSID retrieved in post IRP_MJ_CREATE.
    //

    WCHAR 			UserSID[MAXX_PATH];

    //
    //  Accesses are stored in this flag
    //

    CHANGE_NOTIFICATION		Notification;
	    
} FSM_STREAMHANDLE_CONTEXT, *PFSM_STREAMHANDLE_CONTEXT;


//---------------------------------------------------------------------------//
//      Global variables						     //
//---------------------------------------------------------------------------//

typedef struct _FSMONITOR_DATA {

    //
    //  The object that identifies this driver.
    //

    PDRIVER_OBJECT DriverObject;

    //
    //  The filter that results from a call to
    //  FltRegisterFilter.
    //

    PFLT_FILTER Filter;

    //
    //  Server port: user mode connects to this port
    //

    PFLT_PORT ServerPort;

    //
    //  Client connection port: only one connection is allowed at a time.,
    //

    PFLT_PORT ClientPort;

    //
    //  Global debug flags
    //

    ULONG DebugFlags;

} FSMONITOR_DATA, *PFSMONITOR_DATA;

//
//  Fsmonitor's global variables
//

extern FSMONITOR_DATA FsmData;

//
//  DebugFlag values
//

#define SPY_DEBUG_PARSE_NAMES   0x00000001

//---------------------------------------------------------------------------//
//  Registration structure						     //
//---------------------------------------------------------------------------//

extern const FLT_REGISTRATION FilterRegistration;

//---------------------------------------------------------------------------//
//  Function prototypes							     //
//---------------------------------------------------------------------------//

NTSTATUS
FsmFilterUnload (
    __in FLT_FILTER_UNLOAD_FLAGS Flags
    );

NTSTATUS
FsmQueryTeardown (
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __in FLT_INSTANCE_QUERY_TEARDOWN_FLAGS Flags
    );


//---------------------------------------------------------------------------//
//  InstanceSetupCallback to handle volume attach for USB drivers.	     //
//---------------------------------------------------------------------------//

NTSTATUS VolumeInstanceSetupCallback(
  __in  PCFLT_RELATED_OBJECTS FltObjects,
  __in  FLT_INSTANCE_SETUP_FLAGS Flags,
  __in  DEVICE_TYPE VolumeDeviceType,
  __in  FLT_FILESYSTEM_TYPE VolumeFilesystemType
);


//---------------------------------------------------------------------------//
//  Logging routines							     //
//---------------------------------------------------------------------------//

VOID
InitEventNotification (
    __in PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __inout PCHANGE_NOTIFICATION notification
    );

VOID

SetPostOperationData (
    __in PFLT_CALLBACK_DATA Data,
    __inout PCHANGE_NOTIFICATION notification
    );

VOID
SendPostOperationData (
    __in PFLT_CALLBACK_DATA Data,
    __inout PCHANGE_NOTIFICATION notification
    );

VOID
SetFileName(
    __in PUNICODE_STRING fileName,
    __inout PCHANGE_NOTIFICATION notification
    );

VOID
SetUserSID(
    __inout PCHANGE_NOTIFICATION notification,
	__in HANDLE token
    );

VOID
SetTokenSource(
    __inout PCHANGE_NOTIFICATION notification,
	__in HANDLE token
    );

VOID	
SetUserSIDFromSubjectSecurityContext(
    __in PFLT_CALLBACK_DATA Data,
    __inout PCHANGE_NOTIFICATION notification
    );

BOOLEAN
CopyUnicodeStringToWCHAR(
    __in PUNICODE_STRING source,
    __out WCHAR *destination,
    __in long maxSize 
    );

NTSTATUS 
GetProcessImageName(
    __inout PUNICODE_STRING ProcessImageName);

typedef NTSTATUS (*QUERY_INFO_PROCESS) (
    __in HANDLE ProcessHandle,
    __in PROCESSINFOCLASS ProcessInformationClass,
    __out_bcount(ProcessInformationLength) PVOID ProcessInformation,
    __in ULONG ProcessInformationLength,
    __out_opt PULONG ReturnLength
    );

QUERY_INFO_PROCESS ZwQueryInformationProcess;

NTSTATUS
	GetUserTokenHandle(
	__inout HANDLE *token
	);

//---------------------------------------------------------------------------//
//  Context Cleanup Callbacks                                                //
//---------------------------------------------------------------------------//

VOID 
FsmInstanceContextCleanupCallback (
    __in PFSM_INSTANCE_CONTEXT InstanceContext,
    __in FLT_CONTEXT_TYPE ContextType
    );

VOID
FsmStreamHandleContextCleanupCallback (
    __in PFSM_STREAMHANDLE_CONTEXT StreamHandleContext,
    __in FLT_CONTEXT_TYPE ContextType
    );

//---------------------------------------------------------------------------//
//  MiniFilter Operation Callback Routines                                   //
//---------------------------------------------------------------------------//

FLT_PREOP_CALLBACK_STATUS
FsmPreOperationCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __deref_out_opt PVOID *CompletionContext
    );

FLT_POSTOP_CALLBACK_STATUS
FsmPostOperationCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __in PVOID CompletionContext,
    __in FLT_POST_OPERATION_FLAGS Flags
    );

/*FLT_PREOP_CALLBACK_STATUS
FsmPreCreateCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __out  PCHANGE_NOTIFICATION notification
    );

FLT_POSTOP_CALLBACK_STATUS
FsmPostCreateCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __in  PCHANGE_NOTIFICATION notification,    
    __in FLT_POST_OPERATION_FLAGS Flags
    );

FLT_PREOP_CALLBACK_STATUS
FsmPreSetInfoCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __out  PCHANGE_NOTIFICATION notification
    );

FLT_POSTOP_CALLBACK_STATUS
FsmPostSetInfoCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __in PCHANGE_NOTIFICATION notification,
    __in FLT_POST_OPERATION_FLAGS Flags
    );

FLT_PREOP_CALLBACK_STATUS
FsmPreReadCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __out  PCHANGE_NOTIFICATION notification
    );

FLT_POSTOP_CALLBACK_STATUS
FsmPostReadCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __in PCHANGE_NOTIFICATION notification,
    __in FLT_POST_OPERATION_FLAGS Flags
    );*/

FLT_PREOP_CALLBACK_STATUS
FsmPreWriteCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __out  PCHANGE_NOTIFICATION notification
    );

/*FLT_POSTOP_CALLBACK_STATUS
FsmPostWriteCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __in PCHANGE_NOTIFICATION notification,
    __in FLT_POST_OPERATION_FLAGS Flags
    );

FLT_PREOP_CALLBACK_STATUS
FsmPreSetSecurityCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __out  PCHANGE_NOTIFICATION notification
    );

FLT_POSTOP_CALLBACK_STATUS
FsmPostSetSecurityCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __in PCHANGE_NOTIFICATION notification,
    __in FLT_POST_OPERATION_FLAGS Flags
    );

FLT_PREOP_CALLBACK_STATUS
FsmPreCleanupCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __out  PCHANGE_NOTIFICATION notification
    );

FLT_POSTOP_CALLBACK_STATUS
FsmPostCleanupCallback (
    __inout PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __in PCHANGE_NOTIFICATION notification,
    __in FLT_POST_OPERATION_FLAGS Flags
    );*/

//---------------------------------------------------------------------------//
//  Context manipulation functions                                           //
//---------------------------------------------------------------------------//

NTSTATUS
FsmAllocateContext (
    __in FLT_CONTEXT_TYPE ContextType,
    __out PFLT_CONTEXT *Context
    );

NTSTATUS
FsmGetOrSetContext (
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __in_opt PVOID Target,//_When_(ContextType==FLT_INSTANCE_CONTEXT, _In_opt_) _When_(ContextType!=FLT_INSTANCE_CONTEXT, _In_)
    __out PFLT_CONTEXT *Context,
    __in FLT_CONTEXT_TYPE ContextType
    );

NTSTATUS
FsmGetContext (
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __in_opt PVOID Target,// _When_(ContextType==FLT_INSTANCE_CONTEXT, _In_opt_) _When_(ContextType!=FLT_INSTANCE_CONTEXT, _In_)
    __in FLT_CONTEXT_TYPE ContextType,
    __out PFLT_CONTEXT *Context
    );

NTSTATUS
FsmSetContext (
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __in_opt PVOID Target,//_When_(ContextType==FLT_INSTANCE_CONTEXT, _In_opt_) _When_(ContextType!=FLT_INSTANCE_CONTEXT, _In_)
    __in FLT_CONTEXT_TYPE ContextType,
    __in PFLT_CONTEXT NewContext,
    __out_opt PFLT_CONTEXT *OldContext
    );

//---------------------------------------------------------------------------//
//  			Miscellaneous Functions		                     //
//---------------------------------------------------------------------------//

VOID
FsmSetFileNameFromPreOpData (
    __in PFLT_CALLBACK_DATA Data,
    __in PCFLT_RELATED_OBJECTS FltObjects,
    __inout PCHANGE_NOTIFICATION notification
    );

BOOLEAN
FsmCopyWideString (
    __inout WCHAR *Dest,
    __in WCHAR *Source,
    __in long MaxLength
    );

NTSTATUS
DfGetFileNameInformation (
    __in  PFLT_CALLBACK_DATA Data,
    __inout PFSM_STREAMHANDLE_CONTEXT StreamHandleContext
    );

void
FsmSetAdditionInfoFromContext (
    __inout PCHANGE_NOTIFICATION currentIrpNotificationInfo,
    __in PCHANGE_NOTIFICATION InfoFromContext
    );

#endif  //__MSPYKERN_H__


