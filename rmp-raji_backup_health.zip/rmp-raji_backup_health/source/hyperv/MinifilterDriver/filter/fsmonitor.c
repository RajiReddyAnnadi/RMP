/*++

Module Name:

FsMonitor.c

Abstract:

This is the main module for the FsMonitor mini-filter.

Environment:

Kernel mode

--*/

#include "FSMonitorKern.h"
#include <stdio.h>


//
//  Global variables
//


FSMONITOR_DATA FsmData;

//---------------------------------------------------------------------------
//  Function prototypes
//---------------------------------------------------------------------------
DRIVER_INITIALIZE DriverEntry;

NTSTATUS
DriverEntry(
__in PDRIVER_OBJECT DriverObject,
__in PUNICODE_STRING RegistryPath
);

NTSTATUS
FsmMessage(
__in PVOID ConnectionCookie,
__in_bcount_opt(InputBufferSize) PVOID InputBuffer,
__in ULONG InputBufferSize,
__out_bcount_part_opt(OutputBufferSize, *ReturnOutputBufferLength) PVOID OutputBuffer,
__in ULONG OutputBufferSize,
__out PULONG ReturnOutputBufferLength
);

NTSTATUS
FsmConnect(
__in PFLT_PORT ClientPort,
__in PVOID ServerPortCookie,
__in_bcount(SizeOfContext) PVOID ConnectionContext,
__in ULONG SizeOfContext,
__deref_out_opt PVOID *ConnectionCookie
);

VOID
FsmDisconnect(
__in_opt PVOID ConnectionCookie
);

//---------------------------------------------------------------------------//
//  Assign text sections for each routine.				     //
//---------------------------------------------------------------------------//

#ifdef ALLOC_PRAGMA
#pragma alloc_text(INIT, DriverEntry)
#pragma alloc_text(PAGE, FsmFilterUnload)
#pragma alloc_text(PAGE, FsmQueryTeardown)
#pragma alloc_text(PAGE, FsmConnect)
#pragma alloc_text(PAGE, FsmDisconnect)
#pragma alloc_text(PAGE, FsmMessage)
#endif

//---------------------------------------------------------------------------//
//                      ROUTINES					     //
//---------------------------------------------------------------------------//

NTSTATUS
DriverEntry(
__in PDRIVER_OBJECT DriverObject,
__in PUNICODE_STRING RegistryPath
)
/*++

Routine Description:

This routine is called when a driver first loads.  Its purpose is to
initialize global state and then register with FltMgr to start filtering.

Arguments:

DriverObject - Pointer to driver object created by the system to
represent this driver.
RegistryPath - Unicode string identifying where the parameters for this
driver are located in the registry.

Return Value:

Status of the operation.

--*/
{
	PSECURITY_DESCRIPTOR sd;
	OBJECT_ATTRIBUTES oa;
	UNICODE_STRING uniString;
	NTSTATUS status = STATUS_SUCCESS;

	try {

		//
		// Initialize global data structures.
		//

		FsmData.DriverObject = DriverObject;

		//
		//  Now that our global configuration is complete, register with FltMgr.
		//

		status = FltRegisterFilter(DriverObject,
			&FilterRegistration,
			&FsmData.Filter);

		if (!NT_SUCCESS(status)) {

			return status;
		}


		status = FltBuildDefaultSecurityDescriptor(&sd,
			FLT_PORT_ALL_ACCESS);

		if (!NT_SUCCESS(status)) {
			return status;
		}

		RtlInitUnicodeString(&uniString, FSM_PORT_NAME);

		InitializeObjectAttributes(&oa,
			&uniString,
			OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE,
			NULL,
			sd);

		status = FltCreateCommunicationPort(FsmData.Filter,
			&FsmData.ServerPort,
			&oa,
			NULL,
			(PFLT_CONNECT_NOTIFY)FsmConnect,
			(PFLT_DISCONNECT_NOTIFY)FsmDisconnect,
			(PFLT_MESSAGE_NOTIFY)FsmMessage,
			1);

		FltFreeSecurityDescriptor(sd);

		if (!NT_SUCCESS(status)) {
			return status;
		}

		//
		//  We are now ready to start filtering
		//

		status = FltStartFiltering(FsmData.Filter);

	}
	finally {

		if (!NT_SUCCESS(status)) {

			if (NULL != FsmData.ServerPort) {
				FltCloseCommunicationPort(FsmData.ServerPort);
			}

			if (NULL != FsmData.Filter) {
				FltUnregisterFilter(FsmData.Filter);
			}
		}
	}

	return status;
}

NTSTATUS
FsmConnect(
__in PFLT_PORT ClientPort,
__in PVOID ServerPortCookie,
__in_bcount(SizeOfContext) PVOID ConnectionContext,
__in ULONG SizeOfContext,
__deref_out_opt PVOID *ConnectionCookie
)
/*++

Routine Description

This is called when user-mode connects to the server
port - to establish a connection

Arguments

ClientPort - This is the pointer to the client port that
will be used to send messages from the filter.
ServerPortCookie - unused
ConnectionContext - unused
SizeofContext   - unused
ConnectionCookie - unused

Return Value

STATUS_SUCCESS - to accept the connection
--*/
{

	PAGED_CODE();

	UNREFERENCED_PARAMETER(ServerPortCookie);
	UNREFERENCED_PARAMETER(ConnectionContext);
	UNREFERENCED_PARAMETER(SizeOfContext);
	UNREFERENCED_PARAMETER(ConnectionCookie);

	ASSERT(FsmData.ClientPort == NULL);
	FsmData.ClientPort = ClientPort;
	return STATUS_SUCCESS;
}


VOID
FsmDisconnect(
__in_opt PVOID ConnectionCookie
)
/*++

Routine Description

This is called when the connection is torn-down. We use it to close our handle to the connection

Arguments

ConnectionCookie - unused

Return value

None
--*/
{

	PAGED_CODE();

	UNREFERENCED_PARAMETER(ConnectionCookie);

	//
	//  Close our handle
	//

	FltCloseClientPort(FsmData.Filter, &FsmData.ClientPort);
}

NTSTATUS
FsmFilterUnload(
__in FLT_FILTER_UNLOAD_FLAGS Flags
)
/*++

Routine Description:

This is called when a request has been made to unload the filter.  Unload
requests from the Operation System (ex: "sc stop minispy" can not be
failed.  Other unload requests may be failed.

You can disallow OS unload request by setting the
FLTREGFL_DO_NOT_SUPPORT_SERVICE_STOP flag in the FLT_REGISTARTION
structure.

Arguments:

Flags - Flags pertinent to this operation

Return Value:

Always success

--*/
{
	UNREFERENCED_PARAMETER(Flags);

	PAGED_CODE();

	//
	//  Close the server port. This will stop new connections.
	//

	FltCloseCommunicationPort(FsmData.ServerPort);
	FltUnregisterFilter(FsmData.Filter);

	return STATUS_SUCCESS;
}


NTSTATUS
FsmQueryTeardown(
__in PCFLT_RELATED_OBJECTS FltObjects,
__in FLT_INSTANCE_QUERY_TEARDOWN_FLAGS Flags
)
/*++

Routine Description:

This allows our filter to be manually detached from a volume.

Arguments:

FltObjects - Contains pointer to relevant objects for this operation.
Note that the FileObject field will always be NULL.

Flags - Flags pertinent to this operation

Return Value:

--*/
{
	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(Flags);
	PAGED_CODE();
	return STATUS_SUCCESS;
}


NTSTATUS
FsmMessage(
__in PVOID ConnectionCookie,
__in_bcount_opt(InputBufferSize) PVOID InputBuffer,
__in ULONG InputBufferSize,
__out_bcount_part_opt(OutputBufferSize, *ReturnOutputBufferLength) PVOID OutputBuffer,
__in ULONG OutputBufferSize,
__out PULONG ReturnOutputBufferLength
)
/*++

Routine Description:

This is called whenever a user mode application wishes to communicate
with this minifilter.

Arguments:

ConnectionCookie - unused

OperationCode - An identifier describing what type of message this
is.  These codes are defined by the MiniFilter.
InputBuffer - A buffer containing input data, can be NULL if there
is no input data.
InputBufferSize - The size in bytes of the InputBuffer.
OutputBuffer - A buffer provided by the application that originated
the communication in which to store data to be returned to this
application.
OutputBufferSize - The size in bytes of the OutputBuffer.
ReturnOutputBufferSize - The size in bytes of meaningful data
returned in the OutputBuffer.

Return Value:

Returns the status of processing the message.

--*/
{
	MINISPY_COMMAND command;
	NTSTATUS status = STATUS_SUCCESS;

	PAGED_CODE();

	UNREFERENCED_PARAMETER(ConnectionCookie);

	//
	//                      **** PLEASE READ ****
	//
	//  The INPUT and OUTPUT buffers are raw user mode addresses.  The filter
	//  manager has already done a ProbedForRead (on InputBuffer) and
	//  ProbedForWrite (on OutputBuffer) which guarentees they are valid
	//  addresses based on the access (user mode vs. kernel mode).  The
	//  minifilter does not need to do their own probe.
	//
	//  The filter manager is NOT doing any alignment checking on the pointers.
	//  The minifilter must do this themselves if they care (see below).
	//
	//  The minifilter MUST continue to use a try/except around any access to
	//  these buffers.
	//

	if ((InputBuffer != NULL) &&
		(InputBufferSize >= (FIELD_OFFSET(COMMAND_MESSAGE, Command) +
		sizeof(MINISPY_COMMAND)))) {

		try  {

			//
			//  Probe and capture input message: the message is raw user mode
			//  buffer, so need to protect with exception handler
			//

			command = ((PCOMMAND_MESSAGE)InputBuffer)->Command;

		} except(EXCEPTION_EXECUTE_HANDLER) {

			return GetExceptionCode();
		}

		switch (command) {

		case GetMiniSpyLog:

			//
			//  Return as many log records as can fit into the OutputBuffer
			//

			if ((OutputBuffer == NULL) || (OutputBufferSize == 0)) {

				status = STATUS_INVALID_PARAMETER;
				break;
			}

			//
			//  We want to validate that the given buffer is POINTER
			//  aligned.  But if this is a 64bit system and we want to
			//  support 32bit applications we need to be careful with how
			//  we do the check.  Note that the way SpyGetLog is written
			//  it actually does not care about alignment but we are
			//  demonstrating how to do this type of check.
			//

#if defined(_WIN64)
			if (IoIs32bitProcess(NULL)) {

				//
				//  Validate alignment for the 32bit process on a 64bit
				//  system
				//

				if (!IS_ALIGNED(OutputBuffer, sizeof(ULONG))) {

					status = STATUS_DATATYPE_MISALIGNMENT;
					break;
				}

			}
			else {
#endif

				if (!IS_ALIGNED(OutputBuffer, sizeof(PVOID))) {

					status = STATUS_DATATYPE_MISALIGNMENT;
					break;
				}

#if defined(_WIN64)
			}
#endif
			//
			//  Get the log record.
			//
			/* Commented by meeeee
			status = SpyGetLog( OutputBuffer,
			OutputBufferSize,
			ReturnOutputBufferLength );*/
			break;


		case GetMiniSpyVersion:

			//
			//  Return version of the MiniSpy filter driver.  Verify
			//  we have a valid user buffer including valid
			//  alignment
			//

			if ((OutputBufferSize < sizeof(MINISPYVER)) ||
				(OutputBuffer == NULL)) {

				status = STATUS_INVALID_PARAMETER;
				break;
			}

			//
			//  Validate Buffer alignment.  If a minifilter cares about
			//  the alignment value of the buffer pointer they must do
			//  this check themselves.  Note that a try/except will not
			//  capture alignment faults.
			//

			if (!IS_ALIGNED(OutputBuffer, sizeof(ULONG))) {

				status = STATUS_DATATYPE_MISALIGNMENT;
				break;
			}

			//
			//  Protect access to raw user-mode output buffer with an
			//  exception handler
			//

			try {

				((PMINISPYVER)OutputBuffer)->Major = MINISPY_MAJ_VERSION;
				((PMINISPYVER)OutputBuffer)->Minor = MINISPY_MIN_VERSION;

			} except(EXCEPTION_EXECUTE_HANDLER) {

				return GetExceptionCode();
			}

			*ReturnOutputBufferLength = sizeof(MINISPYVER);
			status = STATUS_SUCCESS;
			break;

		default:
			status = STATUS_INVALID_PARAMETER;
			break;
		}

	}
	else {

		status = STATUS_INVALID_PARAMETER;
	}

	return status;
}


//---------------------------------------------------------------------------//
//              Operation filtering routines				     //
//---------------------------------------------------------------------------//


FLT_PREOP_CALLBACK_STATUS
FsmPreOperationCallback(
__inout PFLT_CALLBACK_DATA Data,
__in PCFLT_RELATED_OBJECTS FltObjects,
__deref_out_opt PVOID *CompletionContext
)
/*++

Routine Description:

This routine receives ALL pre-operation callbacks for this filter.  It then
tries to log information about the given operation.  If we are able
to log information then we will call our post-operation callback  routine.

NOTE:  This routine must be NON-PAGED because it can be called on the
paging path.

Arguments:

Data - Contains information about the given operation.

FltObjects - Contains pointers to the various objects that are pertinent
to this operation.

CompletionContext - This receives the address of our log buffer for this
operation.  Our completion routine then receives this buffer address.

Return Value:

Identifies how processing should continue for this operation

--*/
{
	FLT_PREOP_CALLBACK_STATUS returnStatus = FLT_PREOP_SUCCESS_NO_CALLBACK; //assume we are NOT going to call our completion routine
	NTSTATUS status;
	PCHANGE_NOTIFICATION notification = NULL;

	*CompletionContext = NULL;

	// Allocate Memory for Event Notification Message
	notification = (PCHANGE_NOTIFICATION)ExAllocatePoolWithTag(NonPagedPool, sizeof(CHANGE_NOTIFICATION), FSM_PREOP_DATA_POOL_TAG);

	if (notification == NULL)
	{
		DbgPrint("\n!!! Notification Memory allocated failed fsmonitor");
		return FLT_PREOP_SUCCESS_NO_CALLBACK; // Do not call Post callback
	}

	InitEventNotification(Data, FltObjects, notification);
	FsmSetFileNameFromPreOpData(Data, FltObjects, notification);

	switch (Data->Iopb->MajorFunction)

	{
	/*case IRP_MJ_CREATE:
		returnStatus = FsmPreCreateCallback(Data, notification);
		break;

	case IRP_MJ_READ:
		returnStatus = FsmPreReadCallback(Data, FltObjects, notification);
		break;*/

	case IRP_MJ_WRITE:
		returnStatus = FsmPreWriteCallback(Data, FltObjects, notification);
		break;

	/*case IRP_MJ_SET_INFORMATION:
		returnStatus = FsmPreSetInfoCallback(Data, FltObjects, notification);
		break;

	case IRP_MJ_SET_SECURITY:
		returnStatus = FsmPreSetSecurityCallback(Data, FltObjects, notification);
		break;

	case IRP_MJ_CLEANUP:
		returnStatus = FsmPreCleanupCallback(Data, notification);
		break;*/
	}

	if (returnStatus == FLT_PREOP_SUCCESS_NO_CALLBACK)
	{
		if (notification != NULL)
		{
			ExFreePoolWithTag(notification, FSM_PREOP_DATA_POOL_TAG);
		}
	}
	else
	{
		*CompletionContext = notification;
	}
	//    DbgPrint("Pre END -> PID = [%d] IRQL = [%d], ThreadID = [%d]",PsGetCurrentProcessId(), KeGetCurrentIrql(), PsGetCurrentThreadId());
	return returnStatus;
}




















FLT_POSTOP_CALLBACK_STATUS
SafePostCallback(
__inout PFLT_CALLBACK_DATA Data,
__in PCFLT_RELATED_OBJECTS FltObjects,
__in PVOID CompletionContext,
__in FLT_POST_OPERATION_FLAGS Flags
)
{
	PCHANGE_NOTIFICATION notification = NULL;
	notification = (PCHANGE_NOTIFICATION)CompletionContext;

	notification->hvWriteLength = Data->Iopb->Parameters.Write.Length;
	notification->hvByteOffsetHighPart = Data->Iopb->Parameters.Write.ByteOffset.HighPart;
	notification->hvByteOffsetLowPart = Data->Iopb->Parameters.Write.ByteOffset.LowPart;
	notification->hvByteOffsetQuadPart = Data->Iopb->Parameters.Write.ByteOffset.QuadPart;
	
	SendPostOperationData(Data, notification);
	DbgPrint("\nIN safepostcallback...-> %d ", KeGetCurrentIrql());

	if (notification != NULL)
	{
		if (notification->Context != NULL)
		{
			FltReleaseContext(notification->Context);
		}
		ExFreePoolWithTag(notification, FSM_PREOP_DATA_POOL_TAG);
	}

	return  FLT_POSTOP_FINISHED_PROCESSING;
}





























FLT_POSTOP_CALLBACK_STATUS
FsmPostOperationCallback(
__inout PFLT_CALLBACK_DATA Data,
__in PCFLT_RELATED_OBJECTS FltObjects,
__in PVOID CompletionContext,
__in FLT_POST_OPERATION_FLAGS Flags
)
/*++

Routine Description:

This routine receives ALL post-operation callbacks.  This will take
the log record passed in the context parameter and update it with
the completion information.  It will then insert it on a list to be
sent to the usermode component.

NOTE:  This routine must be NON-PAGED because it can be called at DPC level

Arguments:

Data - Contains information about the given operation.

FltObjects - Contains pointers to the various objects that are pertinent
to this operation.

CompletionContext - Pointer to the RECORD_LIST structure in which we
store the information we are logging.  This was passed from the
pre-operation callback

Flags - Contains information as to why this routine was called.

Return Value:

Identifies how processing should continue for this operation

--*/
{
	
	PCHANGE_NOTIFICATION notification = NULL;
	PFLT_TAG_DATA_BUFFER tagData;
	PFLT_FILE_NAME_INFORMATION nameInfo = NULL;
	PUNICODE_STRING nameToUse;
	NTSTATUS status;
	FILE_STANDARD_INFORMATION fileInfo;
	FLT_POSTOP_CALLBACK_STATUS RetPostOperationStatus = FLT_POSTOP_FINISHED_PROCESSING;

	UNREFERENCED_PARAMETER(FltObjects);

	notification = (PCHANGE_NOTIFICATION)CompletionContext;

	//
	//  If our instance is in the process of being torn down don't bother to
	//  log this record, free it now.
	//

	if (FlagOn(Flags, FLTFL_POST_OPERATION_DRAINING))
	{
		//DbgPrint("FLTFL_POST_OPERATION_DRAINING [%d] [%d]", PsGetCurrentProcessId(), PsGetCurrentThreadId());
		goto PostOperationCallbackExit;
	}

	if (STATUS_REPARSE == Data->IoStatus.Status)
	{
		//DbgPrint("STATUS_REPARSE [%ws] ", notification->OldFileName);
		goto PostOperationCallbackExit;
	}

	//if (NT_SUCCESS( Data->IoStatus.Status ) && (STATUS_REPARSE != Data->IoStatus.Status)) { This condition has to be checked for inclusion; source delete.c
	if (KeGetCurrentIrql() <= DISPATCH_LEVEL)
	{
		if (Data->Iopb->MajorFunction == IRP_MJ_WRITE)
		{
			if (wcsstr(notification->OldFileName, L".vhd") != NULL || wcsstr(notification->OldFileName, L".avhd"))
			{
				BOOLEAN bRet;
				try
				{
					if (FlagOn(Flags, FLTFL_POST_OPERATION_DRAINING))
					{
						DbgPrint("Draining bit set.");
						goto PostOperationCallbackExit;
					}

					bRet = FLT_IS_IRP_OPERATION(Data);
					if (FALSE == bRet)
					{
						DbgPrint("NOT IRP based...");
						goto PostOperationCallbackExit;
					}

					if (FlagOn(Data->Iopb->IrpFlags, IRP_PAGING_IO))
					{
						DbgPrint("Paging IO...");
						goto PostOperationCallbackExit;
					}

					bRet = FltDoCompletionProcessingWhenSafe(
						Data,
						FltObjects,
						notification,
						Flags,
						SafePostCallback,
						&RetPostOperationStatus
						);
					if (FALSE == bRet && FLT_POSTOP_FINISHED_PROCESSING == RetPostOperationStatus)
					{
						DbgPrint("FltDoCompletionProcessingWhenSafe failed.");
						goto PostOperationCallbackExit;
					}

					return RetPostOperationStatus;
				}
				except(EXCEPTION_EXECUTE_HANDLER)
				{
					DbgPrint("\n!!! Exception in MyFilterDelayedPostOpCB ");
				}

				//notification->Context = NULL;
			}					
		}

	}

	// Free all resource before returning

PostOperationCallbackExit:

	if (notification != NULL)
	{
		if (notification->Context != NULL)
		{
			FltReleaseContext(notification->Context);
		}
		ExFreePoolWithTag(notification, FSM_PREOP_DATA_POOL_TAG);
	}
	return RetPostOperationStatus;


}

//-----------------------------------------------------------------------------------------------------------//

