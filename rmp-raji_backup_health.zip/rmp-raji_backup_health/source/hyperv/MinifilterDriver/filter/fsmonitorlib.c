/*++

Module Name:

FsMonitorLib.c

Abstract:
This contains library support routines for FsMonitor

Environment:

Kernel mode

--*/

#include "FSMonitorKern.h"
#include <stdio.h>

#ifdef ALLOC_PRAGMA

#pragma alloc_text(PAGE, FsmStreamHandleContextCleanupCallback)
#pragma alloc_text(PAGE, FsmInstanceContextCleanupCallback)

#pragma alloc_text(PAGE, FsmAllocateContext)
#pragma alloc_text(PAGE, FsmGetOrSetContext)
#pragma alloc_text(PAGE, FsmGetContext)
#pragma alloc_text(PAGE, FsmSetContext)
#pragma alloc_text(PAGE, DfGetFileNameInformation)

/*#pragma alloc_text(PAGE, FsmPreCreateCallback)
#pragma alloc_text(PAGE, FsmPostCreateCallback)
#pragma alloc_text(PAGE, FsmPreSetInfoCallback)
#pragma alloc_text(PAGE, FsmPostSetInfoCallback)
#pragma alloc_text(PAGE, FsmPreReadCallback)
#pragma alloc_text(PAGE, FsmPostReadCallback)*/
#pragma alloc_text(PAGE, FsmPreWriteCallback)
/*#pragma alloc_text(PAGE, FsmPostWriteCallback)
#pragma alloc_text(PAGE, FsmPreSetSecurityCallback)
#pragma alloc_text(PAGE, FsmPostSetSecurityCallback)
#pragma alloc_text(PAGE, FsmPreCleanupCallback)
#pragma alloc_text(PAGE, FsmPostCleanupCallback)*/

#pragma alloc_text(PAGE, InitEventNotification)
#pragma alloc_text(PAGE, SetPostOperationData)
#pragma alloc_text(PAGE, SendPostOperationData)
#pragma alloc_text(PAGE, SetFileName)
#pragma alloc_text(PAGE, SetUserSID)
#pragma alloc_text(PAGE, SetTokenSource)
#pragma alloc_text(PAGE, SetUserSIDFromSubjectSecurityContext)
#pragma alloc_text(PAGE, CopyUnicodeStringToWCHAR)
#pragma alloc_text(PAGE, GetUserTokenHandle)
#pragma alloc_text(PAGE, GetProcessImageName)
#pragma alloc_text(PAGE, FsmSetFileNameFromPreOpData)
#pragma alloc_text(PAGE, FsmCopyWideString)
#pragma alloc_text(PAGE, FsmSetAdditionInfoFromContext)

#endif

//---------------------------------------------------------------------------//
//  			VolumeInstanceSetupCallback.			     //
//---------------------------------------------------------------------------//


/*
*	Instance Callback
*	-----------------
*
InstanceSetupCallback to handle volume attach for USB drivers.

FltObjects [in]
Pointer to an FLT_RELATED_OBJECTS structure that contains opaque pointers for the objects related to the current operation.

Flags [in]
Bitmask of flags that indicate why the instance is being attached. One or more of the following:
Flag	->	Meaning
FLTFL_INSTANCE_SETUP_AUTOMATIC_ATTACHMENT -> The instance is being attached automatically. Either the minifilter driver was just loaded and is being attached to all existing volumes, or it is being attached to a newly mounted volume.
FLTFL_INSTANCE_SETUP_MANUAL_ATTACHMENT -> The instance is being attached manually because a user-mode application has called FilterAttach or FilterAttachAtAltitude or because a kernel-mode component has called FltAttachVolume or FltAttachVolumeAtAltitude.
FLTFL_INSTANCE_SETUP_NEWLY_MOUNTED_VOLUME -> The instance is being attached automatically to a newly mounted volume.
FLTFL_INSTANCE_SETUP_DETACHED_VOLUME -> The instance is being attached to a detached volume. It is possible, on some filesystems (such as FAT and CDFS), to reattach a volume after it has detached. A volume is detached if it has no associated storage stack. A volume in this state is usually a dismounted volume that still has open files.
typedef ULONG FLT_INSTANCE_SETUP_FLAGS;

//
//  If set, this is an automatic instance attachment notification.  These
//  occur when the filter is first loaded for all existing volumes, and
//  when a new volume is mounted.
//

#define FLTFL_INSTANCE_SETUP_AUTOMATIC_ATTACHMENT   0x00000001

//
//  If set, this is a manual instance attachment request via FilterAttach
//  (user mode) or FltAttachVolume.
//

#define FLTFL_INSTANCE_SETUP_MANUAL_ATTACHMENT      0x00000002

//
//  If set, this is an automatic instance notification for a volume that
//  has just been mounted in the system.
//

#define FLTFL_INSTANCE_SETUP_NEWLY_MOUNTED_VOLUME   0x00000004

#if FLT_MGR_LONGHORN
//
//  If set, this volume is not currently attached to a storage stack.
//  This usually means the volume is dismounted but it does not always
//  mean that.  There are scnearios with certain file systems (fat & cdfs
//  being some) where a volume can become reattached after it has detached.
//  This flag is only set in Longhorn or later.
//

#define FLTFL_INSTANCE_SETUP_DETACHED_VOLUME        0x00000008

#endif // FLT_MGR_LONGHORN

VolumeDeviceType [in]
Device type of the file system volume. Must be one of the following:
FILE_DEVICE_CD_ROM_FILE_SYSTEM
FILE_DEVICE_DISK_FILE_SYSTEM
FILE_DEVICE_NETWORK_FILE_SYSTEM

#define FILE_DEVICE_CD_ROM_FILE_SYSTEM  0x00000003
#define FILE_DEVICE_DISK_FILE_SYSTEM    0x00000008
#define FILE_DEVICE_NETWORK_FILE_SYSTEM 0x00000014

VolumeFilesystemType [in]
File system type of the volume. The possible values are listed in FLT_FILESYSTEM_TYPE.
*/

NTSTATUS VolumeInstanceSetupCallback(
	__in  PCFLT_RELATED_OBJECTS FltObjects,
	__in  FLT_INSTANCE_SETUP_FLAGS Flags,
	__in  DEVICE_TYPE VolumeDeviceType,
	__in  FLT_FILESYSTEM_TYPE VolumeFilesystemType
	)
{
	NTSTATUS returnStatus = STATUS_FLT_DO_NOT_ATTACH;
	NTSTATUS volumePropStatus;
	PFLT_VOLUME_PROPERTIES VolumeProperties = NULL;
	ULONG LengthReturned = 0;
	ULONG bufferSize;
	NTSTATUS status = STATUS_SUCCESS;
	unsigned int i = 0;
	BOOLEAN isWritable = FALSE;

	DbgPrint("\nInside VolumeInstanceSetupCallback()");
	volumePropStatus = FltGetVolumeProperties(FltObjects->Volume, VolumeProperties, 0, &LengthReturned);

	VolumeProperties = (PFLT_VOLUME_PROPERTIES)ExAllocatePoolWithTag(NonPagedPool, LengthReturned, FSM_VOLUME_PROP_POOL_TAG);
	if (VolumeProperties == NULL)
	{
		DbgPrint("\nMemory Allocation Failed for VolumeProperties");
		return returnStatus;
	}
	bufferSize = LengthReturned;
	//Get VolumeProperties 
	volumePropStatus = FltGetVolumeProperties(FltObjects->Volume, VolumeProperties, bufferSize, &LengthReturned);
	if (volumePropStatus != STATUS_SUCCESS)
	{
		DbgPrint("\nFltGetVolumeProperties Failed");
	}
	//	DbgPrint( "\n--->RealDeviceName = ");	
	DbgPrint("\nFlags = 0x%X,", Flags);
	DbgPrint("\tDeviceObjectFlags = 0x%X", VolumeProperties->DeviceObjectFlags);
	DbgPrint("\nDeviceType = 0x%X,", VolumeProperties->DeviceType);
	DbgPrint("\tDeviceCharacteristics = 0x%X", VolumeProperties->DeviceCharacteristics);// Identify Removable storage From this flag...
	DbgPrint("\nRealDeviceName = %wZ", &VolumeProperties->RealDeviceName);

	// Newly mounted volumes are attached automatically.
	status = FltIsVolumeWritable(FltObjects->Volume, &isWritable);
	if (!NT_SUCCESS(status))
	{
		isWritable = FALSE;
	}
	if ((Flags & FLTFL_INSTANCE_SETUP_MANUAL_ATTACHMENT) == FLTFL_INSTANCE_SETUP_MANUAL_ATTACHMENT)
		// || ((Flags & FLTFL_INSTANCE_SETUP_NEWLY_MOUNTED_VOLUME) == FLTFL_INSTANCE_SETUP_NEWLY_MOUNTED_VOLUME && isWritable))
		returnStatus = STATUS_SUCCESS;

	if (VolumeProperties != NULL) ExFreePoolWithTag((PVOID)VolumeProperties, FSM_VOLUME_PROP_POOL_TAG);
	return returnStatus;
}

//---------------------------------------------------------------------------------------------//

VOID
FsmInstanceContextCleanupCallback(
__in PFSM_INSTANCE_CONTEXT InstanceContext,
__in FLT_CONTEXT_TYPE ContextType
)
/*++

Routine Description:

This routine cleans up an instance context, which consists on freeing
pool used by the volume GUID name string.

Arguments:

InstanceContext - Pointer to FSM_INSTANCE_CONTEXT to be cleaned up.

ContextType - Type of InstanceContext. Must be FLT_INSTANCE_CONTEXT.

--*/
{
	UNREFERENCED_PARAMETER(ContextType);

	PAGED_CODE();

	ASSERT(ContextType == FLT_INSTANCE_CONTEXT);

	//DfFreeUnicodeString( &InstanceContext->VolumeGuidName );
}

//---------------------------------------------------------------------------------------------//

VOID
FsmStreamHandleContextCleanupCallback(
__in PFSM_STREAMHANDLE_CONTEXT StreamContext,
__in FLT_CONTEXT_TYPE ContextType
)
/*++

Routine Description:

This routine cleans up a stream context. The only cleanup necessary is
releasing the FLT_FILE_NAME_INFORMATION object of the NameInfo field.

Arguments:

StreamContext - Pointer to FSM_STREAMHANDLE_CONTEXT to be cleaned up.

ContextType   - Type of StreamContext. Must be FLT_STREAM_CONTEXT.

--*/
{
	UNREFERENCED_PARAMETER(ContextType);

	PAGED_CODE();

	ASSERT(ContextType == FLT_STREAM_CONTEXT || ContextType == FLT_STREAMHANDLE_CONTEXT);

	//
	//  Release NameInfo if present.
	//

	if (StreamContext->NameInfo != NULL) {
		/*if(ContextType == FLT_STREAM_CONTEXT)
		{
		DbgPrint("\n->StreamContext - > CleanupCallback for [%wZ]", &StreamContext->NameInfo->Name);
		} else
		{
		DbgPrint("\nStreamHandleContext - > CleanupCallback for [%wZ]", &StreamContext->NameInfo->Name);
		}*/
		FltReleaseFileNameInformation(StreamContext->NameInfo);
		StreamContext->NameInfo = NULL;
	}
}



//---------------------------------------------------------------------------------------------//

FLT_PREOP_CALLBACK_STATUS
FsmPreWriteCallback(
__inout PFLT_CALLBACK_DATA Data,
__in PCFLT_RELATED_OBJECTS FltObjects,
__out  PCHANGE_NOTIFICATION notification
)
/*++

Routine Description:

This routine is the pre-operation completion routine for
IRP_MJ_SET_SECURITY in this miniFilter.


Arguments:

Data - Pointer to the filter callbackData that is passed to us.

FltObjects - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance, its associated volume and
file object.

CompletionContext - The context for the completion routine for this
operation.

Return Value:

FLT_PREOP_SYNCHRONIZE -

FLT_PREOP_SUCCESS_NO_CALLBACK -

--*/
{
	NTSTATUS status;
	PFSM_STREAMHANDLE_CONTEXT streamContext = NULL;
	BOOLEAN race;

	UNREFERENCED_PARAMETER(FltObjects);

	PAGED_CODE();

	status = FsmGetOrSetContext(FltObjects,
		Data->Iopb->TargetFileObject,
		&streamContext,
		FLT_STREAMHANDLE_CONTEXT);

	if (!NT_SUCCESS(status)) {
		return FLT_PREOP_SUCCESS_NO_CALLBACK;
	}

	notification->Context = (PVOID)streamContext;

	return FLT_PREOP_SUCCESS_WITH_CALLBACK;
}

//////////////////////////////////////////////////////////////////////////////
//  Context manipulation functions starts here				    //
//////////////////////////////////////////////////////////////////////////////


//---------------------------------------------------------------------------------------------//

NTSTATUS
FsmAllocateContext(
__in FLT_CONTEXT_TYPE ContextType,
__out PFLT_CONTEXT *Context
)
/*++

Routine Description:

This routine allocates and initializes a context of given type.

Arguments:

ContextType   - Type of context to be allocated/initialized.

Context       - Pointer to a context pointer.

Return Value:

Returns a status forwarded from FltAllocateContext.

--*/
{
	NTSTATUS status;
	//PDF_TRANSACTION_CONTEXT transactionContext;

	PAGED_CODE();

	switch (ContextType) {

	case FLT_STREAMHANDLE_CONTEXT:

		status = FltAllocateContext(FsmData.Filter,
			FLT_STREAMHANDLE_CONTEXT,
			sizeof(FSM_STREAMHANDLE_CONTEXT),
			DF_CONTEXT_POOL_TYPE,
			Context);

		if (NT_SUCCESS(status)) {
			RtlZeroMemory(*Context, sizeof(FSM_STREAMHANDLE_CONTEXT));
		}

		return status;

	case FLT_STREAM_CONTEXT:

		status = FltAllocateContext(FsmData.Filter,
			FLT_STREAM_CONTEXT,
			sizeof(FSM_STREAMHANDLE_CONTEXT),
			DF_CONTEXT_POOL_TYPE,
			Context);

		if (NT_SUCCESS(status)) {
			RtlZeroMemory(*Context, sizeof(FSM_STREAMHANDLE_CONTEXT));
		}

		return status;
		/*
		case FLT_TRANSACTION_CONTEXT:

		status = FltAllocateContext( FsmData.Filter,
		FLT_TRANSACTION_CONTEXT,
		sizeof(DF_TRANSACTION_CONTEXT),
		DF_CONTEXT_POOL_TYPE,
		Context );

		if (NT_SUCCESS( status )) {
		RtlZeroMemory( *Context, sizeof(DF_TRANSACTION_CONTEXT) );

		transactionContext = *Context;

		InitializeListHead( &transactionContext->DeleteNotifyList );

		transactionContext->Resource = ExAllocatePoolWithTag( NonPagedPool,
		sizeof(ERESOURCE),
		DF_ERESOURCE_POOL_TAG );
		//DbgPrint("--> FsmAllocateContextv for FLT_TRANSACTION_CONTEXT!\n" );
		if (NULL == transactionContext->Resource) {
		FltReleaseContext( transactionContext );
		return STATUS_INSUFFICIENT_RESOURCES;
		}
		ExInitializeResourceLite( transactionContext->Resource );
		}

		return status;
		*/
	case FLT_INSTANCE_CONTEXT:

		status = FltAllocateContext(FsmData.Filter,
			FLT_INSTANCE_CONTEXT,
			sizeof(FSM_INSTANCE_CONTEXT),
			DF_CONTEXT_POOL_TYPE,
			Context);

		if (NT_SUCCESS(status)) {
			RtlZeroMemory(*Context, sizeof(FSM_INSTANCE_CONTEXT));
		}

		return status;

	default:

		return STATUS_INVALID_PARAMETER;
	}
}

//---------------------------------------------------------------------------------------------//

NTSTATUS
FsmGetOrSetContext(
__in PCFLT_RELATED_OBJECTS FltObjects,
__in_opt PVOID Target,//_When_(ContextType==FLT_INSTANCE_CONTEXT, _In_opt_) _When_(ContextType!=FLT_INSTANCE_CONTEXT, _In_)
__out PFLT_CONTEXT *Context,
__in FLT_CONTEXT_TYPE ContextType
)
/*++

Routine Description:

This routine obtains a context of type ContextType that is attached to
Target.

If a context is already attached to Target, it will be returned in
*Context. If a context is already attached, but *Context points to
another context, *Context will be released.

If no context is attached, and *Context points to a previously allocated
context, *Context will be attached to the Target.

Finally, if no previously allocated context is passed to this routine
(*Context is a NULL pointer), a new Context is created and then attached
to Target.

In case of race conditions (or the presence of a previously allocated
context at *Context), the existing attached context is returned via
*Context.

In case of a transaction context, this function will also enlist in the
transaction.

Arguments:

FltObjects    - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance and its associated volume.

Target        - Pointer to the target to which we want to attach the
context. It will actually be either a FILE_OBJECT or
a KTRANSACTION.  It is NULL for an Instance context.

Context       - Pointer to a pointer to a context. Used both for
returning an allocated/attached context or for receiving
a context to attach to the Target.

ContextType   - Type of context to get/allocate/attach. Also used to
disambiguate the target/context type as this minifilter
only has one type of context per target.

Return Value:

Returns a status forwarded from Flt(((Get|Set)Xxx)|Allocate)Context or
FltEnlistInTransaction.

--*/
{
	NTSTATUS status;
	PFLT_CONTEXT newContext;
	PFLT_CONTEXT oldContext;

	PAGED_CODE();

	ASSERT(NULL != Context);

	newContext = *Context;

	//
	//  Is there already a context attached to the target?
	//

	status = FsmGetContext(FltObjects,
		Target,
		ContextType,
		&oldContext);

	if (STATUS_NOT_FOUND == status) {

		//
		//  There is no attached context. This means we have to either attach the
		//  one provided by the caller or allocate a new one and attach it.
		//

		if (NULL == newContext) {

			//
			//  No provided context. Allocate one.
			//

			status = FsmAllocateContext(ContextType, &newContext);

			if (!NT_SUCCESS(status)) {

				//
				//  We failed to allocate.
				//

				return status;
			}
		}

	}
	else if (!NT_SUCCESS(status)) {

		//
		//  We failed trying to get a context from the target.
		//

		// Possible Leak
		if (NULL != newContext) {
			DbgPrint("\n\n Critical!!! \n\n");
			FltReleaseContext(newContext);
		}

		return status;

	}
	else {

		//
		//  There is already a context attached to the target, so return
		//  that context.
		//
		//  If a context was provided by the caller, release it if it's not
		//  the one attached to the target.
		//  

		//
		//  The caller is not allowed to set the same context on the target
		//  twice.
		//
		ASSERT(newContext != oldContext);

		if (NULL != newContext) {

			FltReleaseContext(newContext);
		}

		*Context = oldContext;
		return status;
	}

	//
	//  At this point we should have a context to set on the target (newContext).
	//

	status = FsmSetContext(FltObjects,
		Target,
		ContextType,
		newContext,
		&oldContext);

	if (!NT_SUCCESS(status)) {

		//
		//  FltSetStreamContext failed so we must release the new context.
		//

		FltReleaseContext(newContext);

		if (STATUS_FLT_CONTEXT_ALREADY_DEFINED == status) {

			//
			//  We're racing with some other call which managed to set the
			//  context before us. We will return that context instead, which
			//  will be in oldContext.
			//

			*Context = oldContext;
			return STATUS_SUCCESS;

		}
		else {

			//
			//  Failed to set the context. Return NULL.
			//

			*Context = NULL;
			return status;
		}
	}

	//
	//  If this is setting a transaction context, we want to enlist in the
	//  transaction as well.
	//

	/*#if OS_VERSION_GREATER_THAN_VISTA

	if (FLT_TRANSACTION_CONTEXT == ContextType) {

	status = FltEnlistInTransaction( FltObjects->Instance,
	(PKTRANSACTION)Target,
	newContext,
	DF_NOTIFICATION_MASK );

	}

	#endif    */
	//
	//  Setting the context was successful so just return newContext.
	//

	*Context = newContext;
	return status;
}

//---------------------------------------------------------------------------------------------//

NTSTATUS
FsmGetContext(
__in PCFLT_RELATED_OBJECTS FltObjects,
__in_opt PVOID Target,// _When_(ContextType==FLT_INSTANCE_CONTEXT, _In_opt_) _When_(ContextType!=FLT_INSTANCE_CONTEXT, _In_)
__in FLT_CONTEXT_TYPE ContextType,
__out PFLT_CONTEXT *Context
)
/*++

Routine Description:

This routine gets the given context from the target.

Arguments:

FltObjects    - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance and its associated volume.

Target        - Pointer to the target from which we want to obtain the
context. It will actually be either a FILE_OBJECT or
a KTRANSACTION. For instance contexts, it's ignored, as
the target is the FLT_INSTANCE itself, obtained from
Data->Iopb->TargetInstance.

ContextType   - Type of context to get. Also used to disambiguate
the target/context type as this minifilter
only has one type of context per target.

Context       - Pointer returning a pointer to the attached context.

Return Value:

Returns a status forwarded from FltSetXxxContext.

--*/
{
	PAGED_CODE();

	switch (ContextType) {

	case FLT_STREAMHANDLE_CONTEXT:

		return FltGetStreamHandleContext(FltObjects->Instance,
			(PFILE_OBJECT)Target,
			Context);

	case FLT_STREAM_CONTEXT:

		return FltGetStreamContext(FltObjects->Instance,
			(PFILE_OBJECT)Target,
			Context);
		/*#if OS_VERSION_GREATER_THAN_VISTA

		case FLT_TRANSACTION_CONTEXT:

		return FltGetTransactionContext( FltObjects->Instance,
		(PKTRANSACTION)Target,
		Context );

		#endif	    */
	case FLT_INSTANCE_CONTEXT:

		return FltGetInstanceContext(FltObjects->Instance,
			Context);

	default:

		return STATUS_INVALID_PARAMETER;
	}
}


//---------------------------------------------------------------------------------------------//

NTSTATUS
FsmSetContext(
__in PCFLT_RELATED_OBJECTS FltObjects,
__in_opt PVOID Target,//_When_(ContextType==FLT_INSTANCE_CONTEXT, _In_opt_) _When_(ContextType!=FLT_INSTANCE_CONTEXT, _In_)
__in FLT_CONTEXT_TYPE ContextType,
__in PFLT_CONTEXT NewContext,
__out_opt PFLT_CONTEXT *OldContext
)
/*++

Routine Description:

This routine sets the given context to the target.

Arguments:

FltObjects    - Pointer to the FLT_RELATED_OBJECTS data structure containing
opaque handles to this filter, instance and its associated volume.

Target        - Pointer to the target to which we want to attach the
context. It will actually be either a FILE_OBJECT or
a KTRANSACTION. For instance contexts, it's ignored, as
the target is the FLT_INSTANCE itself, obtained from
Data->Iopb->TargetInstance.

ContextType   - Type of context to get/allocate/attach. Also used to
disambiguate the target/context type as this minifilter
only has one type of context per target.

NewContext    - Pointer to the context the caller wants to attach.

OldContext    - Returns the context already attached to the target, if
that is the case.

Return Value:

Returns a status forwarded from FltSetXxxContext.

--*/
{
	PAGED_CODE();

	switch (ContextType) {

	case FLT_STREAMHANDLE_CONTEXT:

		return FltSetStreamHandleContext(FltObjects->Instance,
			(PFILE_OBJECT)Target,
			FLT_SET_CONTEXT_KEEP_IF_EXISTS,
			NewContext,
			OldContext);

	case FLT_STREAM_CONTEXT:

		return FltSetStreamContext(FltObjects->Instance,
			(PFILE_OBJECT)Target,
			FLT_SET_CONTEXT_KEEP_IF_EXISTS,
			NewContext,
			OldContext);

		/*#if OS_VERSION_GREATER_THAN_VISTA

		case FLT_TRANSACTION_CONTEXT:

		return FltSetTransactionContext( FltObjects->Instance,
		(PKTRANSACTION)Target,
		FLT_SET_CONTEXT_KEEP_IF_EXISTS,
		NewContext,
		OldContext );
		#endif*/

	case FLT_INSTANCE_CONTEXT:

		return FltSetInstanceContext(FltObjects->Instance,
			FLT_SET_CONTEXT_KEEP_IF_EXISTS,
			NewContext,
			OldContext);

	default:

		ASSERT(!"Unexpected context type!\n");

		return STATUS_INVALID_PARAMETER;
	}
}


//---------------------------------------------------------------------------------------------//

//////////////////////////////////////////////////////////////////////////////
//  			Miscellaneous Functions		                    //
//////////////////////////////////////////////////////////////////////////////

//---------------------------------------------------------------------------------------------//

VOID
FsmSetFileNameFromPreOpData(
__in PFLT_CALLBACK_DATA Data,
__in PCFLT_RELATED_OBJECTS FltObjects,
__inout PCHANGE_NOTIFICATION notification
)
/*--

Routine Description:

This helper tries to find file name from PreOpData and sets file name in notification

Arguments:

Data - Contains information about the given operation.

notification - Structure used to send infomation to post operation.

--*/
{
	PFLT_FILE_NAME_INFORMATION nameInfo = NULL;
	UNICODE_STRING defaultName;
	PUNICODE_STRING nameToUse;
	NTSTATUS status;

#if OS_VERSION_GREATER_THAN_W2K
	WCHAR name[MAXX_PATH];
#endif
	PAGED_CODE();


	ResetBitOnFlag(notification->FsmFlags, FSM_FILENAME_AVAILABLE);
	//
	//  We got a log record, if there is a file object, get its name.
	//
	//  NOTE: By default, we use the query method
	//  FLT_FILE_NAME_QUERY_ALWAYS_ALLOW_CACHE_LOOKUP
	//  because FsMonitor would like to get the name as much as possible, but
	//  can cope if we can't retrieve a name.  For a debugging type filter,
	//  like Minispy, this is reasonable, but for most production filters
	//  who need names reliably, they should query the name at times when it
	//  is known to be safe and use the query method
	//  FLT_FILE_NAME_QUERY_DEFAULT.
	//

	if (FltObjects->FileObject != NULL) {

		status = FltGetFileNameInformation(Data,
			FLT_FILE_NAME_NORMALIZED |
			FLT_FILE_NAME_QUERY_DEFAULT,
			&nameInfo);

	}
	else {

		//
		//  Can't get a name when there's no file object
		//
		status = STATUS_UNSUCCESSFUL;
	}

	//
	//  Use the name if we got it else use a default name
	//

	if (NT_SUCCESS(status)) {

		nameToUse = &nameInfo->Name;
		SetBitOnFlag(notification->FsmFlags, FSM_FILENAME_AVAILABLE);
		//
		//  Parse the name if requested
		//

		if (FlagOn(FsmData.DebugFlags, SPY_DEBUG_PARSE_NAMES)) {

#ifdef DBG
			ASSERT(NT_SUCCESS(FltParseFileNameInformation(nameInfo)));
#else
			FltParseFileNameInformation(nameInfo);
#endif
		}

	}
	else {


#if OS_VERSION_GREATER_THAN_W2K
		NTSTATUS lstatus;
		PFLT_FILE_NAME_INFORMATION lnameInfo;

		//
		//  If we couldn't get the "normalized" name try and get the
		//  "opened" name
		//
		//DbgPrint( "1) Name Unsuccess-> 0x%X", status);
		if (FltObjects->FileObject != NULL) {

			//
			//  Get the opened name
			//

			lstatus = FltGetFileNameInformation(Data,
				FLT_FILE_NAME_OPENED |
				FLT_FILE_NAME_QUERY_DEFAULT,
				&lnameInfo);


			if (NT_SUCCESS(lstatus)) {

#pragma prefast(suppress:__WARNING_BANNED_API_USAGE, "reviewed and safe usage")
				(VOID)_snwprintf(name,
					sizeof(name) / sizeof(WCHAR),
					L"<%08x> %wZ",
					status,
					&lnameInfo->Name);

				SetBitOnFlag(notification->FsmFlags, FSM_FILENAME_AVAILABLE);
				FltReleaseFileNameInformation(lnameInfo);

			}
			else {

				//
				//  If that failed report both NORMALIZED status and
				//  OPENED status
				//

#pragma prefast(suppress:__WARNING_BANNED_API_USAGE, "reviewed and safe usage")
				(VOID)_snwprintf(name,
					sizeof(name) / sizeof(WCHAR),
					L"<NO NAME: NormalizeStatus=%08x OpenedStatus=%08x>",
					status,
					lstatus);
			}

		}
		else {

#pragma prefast(suppress:__WARNING_BANNED_API_USAGE, "reviewed and safe usage")
			(VOID)_snwprintf(name,
				sizeof(name) / sizeof(WCHAR),
				L"<NO NAME>");

		}

		//
		//  Name was initialized by _snwprintf() so it may not be null terminated
		//  if the buffer is insufficient. We will ignore this error and truncate
		//  the file name. 
		//

		name[(sizeof(name) / sizeof(WCHAR)) - 1] = L'\0';

		RtlInitUnicodeString(&defaultName, name);
		nameToUse = &defaultName;
#else
		//
		//  We were unable to get the String safe routine to work on W2K
		//  Do it the old safe way
		//

		RtlInitUnicodeString(&defaultName, L"<NO NAME>");
		nameToUse = &defaultName;
#endif 
	}

	SetFileName(nameToUse, notification);

	//  Release the name information structure (if defined)

	if (NULL != nameInfo) {
		FltReleaseFileNameInformation(nameInfo);
	}
}

BOOLEAN
FsmCopyWideString(
__inout WCHAR *Destination,
__in WCHAR *Source,
__in long MaxLength
)
{
	//	UNICODE_STRING SourceUnicodeVersion;
	BOOLEAN retValue = FALSE;
	long len = (MaxLength - 1) * sizeof(WCHAR);

	PAGED_CODE();
	Destination[0] = UNICODE_NULL;

	if (Source != NULL)
	{
		//		DbgPrint("\nSource - > [%ws]", Source);
		//		RtlInitUnicodeString( &SourceUnicodeVersion, Source );
		try
		{
			//			if(SourceUnicodeVersion.Length < len) len = SourceUnicodeVersion.Length;
			RtlCopyBytes(Destination, Source, len);
			Destination[len / sizeof(WCHAR)] = UNICODE_NULL;
			retValue = TRUE;
		} except(EXCEPTION_EXECUTE_HANDLER) {
			DbgPrint("!!! Exception in CopyUnicodeStringToWCHAR() -> %d", GetExceptionCode());
			Destination[0] = UNICODE_NULL;
		}
		//		DbgPrint("\nDestination - > [%ws]", Destination);
	}

	return retValue;
}

//---------------------------------------------------------------------------------------------//

NTSTATUS
DfGetFileNameInformation(
__in  PFLT_CALLBACK_DATA Data,
__inout PFSM_STREAMHANDLE_CONTEXT StreamContext
)
/*++

Routine Description:

This routine gets and parses the file name information, obtains the File
ID and saves them in the stream context.

Arguments:

Data  - Pointer to FLT_CALLBACK_DATA.

StreamContext - Pointer to stream context that will receive the file
information.

Return Value:

Returns statuses forwarded from Flt(Get|Parse)FileNameInformation or
FltQueryInformationFile.

--*/
{
	NTSTATUS status;
	PFLT_FILE_NAME_INFORMATION oldNameInfo;
	PFLT_FILE_NAME_INFORMATION newNameInfo;

	PAGED_CODE();

	//
	//  FltGetFileNameInformation - this is enough for a file name.
	//

	status = FltGetFileNameInformation(Data,
		(FLT_FILE_NAME_OPENED |
		FLT_FILE_NAME_QUERY_DEFAULT),
		&newNameInfo);

	if (!NT_SUCCESS(status)) {
		return status;
	}

	//
	//  FltParseFileNameInformation - this fills in the other gaps, like the
	//  stream name, if present.
	//

	status = FltParseFileNameInformation(newNameInfo);

	if (!NT_SUCCESS(status)) {
		return status;
	}

	//
	//  Now that we have a good NameInfo, set it in the context, replacing
	//  the previous one.
	//

	oldNameInfo = InterlockedExchangePointer(&StreamContext->NameInfo,
		newNameInfo);

	if (NULL != oldNameInfo) {

		FltReleaseFileNameInformation(oldNameInfo);
	}

	return status;
}

//---------------------------------------------------------------------------------------------//

VOID
InitEventNotification(
__in PFLT_CALLBACK_DATA Data,
__in PCFLT_RELATED_OBJECTS FltObjects,
__inout PCHANGE_NOTIFICATION notification
)
{

	PAGED_CODE();

	notification->FsmFlags = 0;
	notification->AccessType = 0;
	notification->AccessMask = 0;
	notification->FileAttributes = 0;
	notification->Context = NULL;

	notification->UserSID[0] = UNICODE_NULL;
	notification->TokenSource[0] = UNICODE_NULL;
	notification->ImageFileName[0] = UNICODE_NULL;
	notification->NewFileName[0] = UNICODE_NULL;

	notification->CallbackMajorId = Data->Iopb->MajorFunction;
	notification->CallbackMinorId = Data->Iopb->MinorFunction;
	notification->IrpFlags = Data->Iopb->IrpFlags;
	notification->Flags = Data->Flags;

	notification->ProcessId = (FILE_ID)PsGetCurrentProcessId();
	notification->ThreadId = (FILE_ID)PsGetCurrentThreadId();

	notification->CreationTime.QuadPart = 0;
	notification->LastAccessTime.QuadPart = 0;
	notification->LastWriteTime.QuadPart = 0;

	KeQuerySystemTime(&notification->OriginatingTime);
}

VOID SetPostOperationData(
	__in PFLT_CALLBACK_DATA Data,
	__inout PCHANGE_NOTIFICATION notification
	)
{
	WCHAR buffer[MAXX_PATH];
	HANDLE token;
	NTSTATUS status = STATUS_SUCCESS;
	UNICODE_STRING imageFileName;

	PAGED_CODE();

	RtlInitEmptyUnicodeString(&imageFileName, buffer, MAXX_PATH);
	notification->Status = Data->IoStatus.Status;
	notification->Information = Data->IoStatus.Information;

	status = GetUserTokenHandle(&token);
	if (status == STATUS_SUCCESS)
	{
		SetUserSID(notification, token);
		SetTokenSource(notification, token);
		ZwClose(token);
	}

	status = GetProcessImageName(&imageFileName);
	if (status == STATUS_SUCCESS)
	{
		CopyUnicodeStringToWCHAR(&imageFileName, notification->ImageFileName, MAXX_PATH);//Check return value for failure and add debug prints.
	}
	//DbgPrint("\n>> [%d][%d] --> [Irp:0x%x] - [%08lx:0x%p] [AM:0x%x] [R:%i D:%i] [0x%x] [IRP-Flag:0x%x] [%d] [%ws]", PsGetCurrentProcessId(), PsGetCurrentThreadId(), notification->CallbackMajorId, notification->Status, (PVOID)notification->Information, notification->AccessMask, notification->IsRename ,notification->IsDelete, notification->Flags, notification->IrpFlags, notification->IsFileNameAvailable, notification->OldFileName);
	KeQuerySystemTime(&notification->CompletionTime);
}


VOID SendPostOperationData(
	__in PFLT_CALLBACK_DATA Data,
	__inout PCHANGE_NOTIFICATION notification
	)
	/*++

	Routine Description:

	This is called from the post-operation callback routine to copy the
	necessary information into the log record.

	NOTE:  This code must be NON-PAGED because it can be called on the
	paging path or at DPC level.

	Arguments:

	Data - The Data structure that contains the information we want to record.

	RecordList - Where we want to save the data

	Return Value:

	None.

	--*/
{

	ULONG replyLength;
	NTSTATUS status = STATUS_SUCCESS;
	BOOLEAN safe = TRUE;
	FILE_ID PID, TID;
	LARGE_INTEGER timeout = { 0 };

	PAGED_CODE();

	try
	{
		//DbgPrint( "[%d] Send Message [%d]",PsGetCurrentProcessId(), KeGetCurrentIrql());
		if (notification == NULL)
		{
			DbgPrint("\n!!! Notification Memory allocated failed");
		}
		else
		{
			//
			//  Send message to user mode to indicate it should scan the buffer.
			//  We don't have to synchronize between the send and close of the handle
			//  as FltSendMessage takes care of that.
			//
			timeout.QuadPart = -((LONGLONG)10) * (LONGLONG)1000 * (LONGLONG)1000; // 1s

			replyLength = sizeof(CHANGE_NOTIFICATION_REPLY);

			status = FltSendMessage(FsmData.Filter,
				&FsmData.ClientPort,
				notification,
				sizeof(CHANGE_NOTIFICATION),
				NULL,
				&replyLength,
				//	NULL);
				&timeout);

			if (STATUS_SUCCESS == status) {
				//DbgPrint( "[%d] Success [%d]",PsGetCurrentProcessId(), KeGetCurrentIrql());
			}
			else {

				//
				//  Couldn't send message. This sample will let the i/o through.
				//

				DbgPrint("\n!!! scanner.sys --- couldn't send message to user-mode to scan file, status 0x%X", status);
			}
		}

	} except(EXCEPTION_EXECUTE_HANDLER) {
		DbgPrint("\n!!! Exception in RtlCopyBytes while copying NewFileName");
	}

}

VOID
SetFileName(
__in PUNICODE_STRING fileName,
__inout PCHANGE_NOTIFICATION notification
)
{

	int len = (MAXX_PATH - 1) * sizeof(WCHAR);

	PAGED_CODE();

	notification->OldFileName[0] = UNICODE_NULL;

	try {
		if (fileName != NULL)
		{
			if (fileName->Length < len) len = fileName->Length;
			RtlCopyBytes(notification->OldFileName, fileName->Buffer, len);
			notification->OldFileName[len / sizeof(WCHAR)] = UNICODE_NULL;
		}
	} except(EXCEPTION_EXECUTE_HANDLER) {
		//
		//  Error accessing buffer. Complete i/o with failure
		//
		notification->OldFileName[0] = UNICODE_NULL;
		DbgPrint("\n!!! Exception in RtlCopyMemory");
	}
}

BOOLEAN
CopyUnicodeStringToWCHAR(
__in PUNICODE_STRING source,
__out WCHAR *destination,
__in long maxSize
)
{
	BOOLEAN retValue = TRUE;
	long len = (maxSize - 1) * sizeof(WCHAR);

	PAGED_CODE();

	destination[0] = UNICODE_NULL;
	try {
		if (source != NULL)
		{
			if (source->Length < len) len = source->Length;
			RtlCopyBytes(destination, source->Buffer, len);
			destination[len / sizeof(WCHAR)] = UNICODE_NULL;
		}
	} except(EXCEPTION_EXECUTE_HANDLER) {
		//
		//  Error accessing buffer. Complete i/o with failure
		//
		DbgPrint("\n!!! Exception in CopyUnicodeStringToWCHAR() -> %d", GetExceptionCode());
		destination[0] = UNICODE_NULL;
		retValue = FALSE;
	}
	return retValue;
}

NTSTATUS
GetUserTokenHandle(
__inout HANDLE *token
)
{
	//HANDLE processHandle, threadHandle;
	NTSTATUS status = STATUS_SUCCESS;

	PAGED_CODE();

	//threadHandle = NtCurrentThread();
	status = ZwOpenThreadTokenEx(NtCurrentThread(), GENERIC_READ, TRUE, OBJ_KERNEL_HANDLE, token);
	//NtClose(threadHandle);

	if (status != STATUS_SUCCESS)
	{
		//processHandle = NtCurrentProcess();
		status = ZwOpenProcessTokenEx(NtCurrentProcess(), GENERIC_READ, OBJ_KERNEL_HANDLE, token);
		//NtClose(processHandle);

		if (status != STATUS_SUCCESS)
		{
			DbgPrint("\nError in ZwOpenProcessTokenEx -> [0x%x] -> IRQL[%d]", status, KeGetCurrentIrql());
		}
	}
	return status;
}

VOID
SetUserSID(
__inout PCHANGE_NOTIFICATION notification,
__in HANDLE token
)
{
	ULONG len;
	PTOKEN_USER ppUser = NULL;
	UNICODE_STRING userSID;
	NTSTATUS status;

	PAGED_CODE();

	notification->UserSID[0] = UNICODE_NULL;
	if (notification->UserSID[0] != UNICODE_NULL)
	{
		return;
	}
	//Get TokenUser from this token handle
	status = ZwQueryInformationToken(token, TokenUser, NULL, 0, &len); //to get required length

	if (status == STATUS_BUFFER_TOO_SMALL && len>0)
	{
		ppUser = (PTOKEN_USER)ExAllocatePoolWithTag(NonPagedPool, len, FSM_USER_SID_POOL_TAG);
		if (ppUser == NULL) //tagged memory allocation
		{
			DbgPrint("\nMemory allocation failed for UserSID -> IRQL[%d]", KeGetCurrentIrql());
		}
		else
		{
			status = ZwQueryInformationToken(token, TokenUser, (PVOID)ppUser, len, &len);
			if (status == STATUS_SUCCESS)
			{
				try {
					status = RtlConvertSidToUnicodeString(&userSID, ppUser->User.Sid, TRUE);
					if (status == STATUS_SUCCESS)
					{
						//Access Violation Error will happen if userSID.MaximumLength is Gerater than MAXX_PATH
						RtlCopyBytes(notification->UserSID, userSID.Buffer, userSID.MaximumLength);
						notification->UserSID[userSID.MaximumLength / sizeof(WCHAR)] = UNICODE_NULL;
						RtlFreeUnicodeString(&userSID);
					}
					else
					{
						DbgPrint("\nError in RtlConvertSidToUnicodeString - UserSID -> [0x%x] -> IRQL[%d]", status, KeGetCurrentIrql());
					}
				} except(EXCEPTION_EXECUTE_HANDLER) {
					DbgPrint("\n!!! Exception in RtlCopyMemory - UserSID -> IRQL[%d]", KeGetCurrentIrql());
					notification->UserSID[0] = UNICODE_NULL;
				}
			}
			else
			{
				DbgPrint("\n2) Error while retrieving TokenUser -UserSID -> [0x%x] -> IRQL[%d]", status, KeGetCurrentIrql());
			}
		}
	}
	else
	{
		DbgPrint("\n1) Error while retrieving TokenUser - UserSID -> [0x%x] -> IRQL[%d] -> len[%d]", status, KeGetCurrentIrql(), len);
	}
	if (ppUser != NULL) {
		ExFreePoolWithTag((PVOID)ppUser, FSM_USER_SID_POOL_TAG);
	}
}

VOID	SetUserSIDFromSubjectSecurityContext(
	__in PFLT_CALLBACK_DATA Data,
	__inout PCHANGE_NOTIFICATION notification
	)
{
	PTOKEN_USER ppUser = NULL;
	UNICODE_STRING userSID;
	NTSTATUS status;
	PACCESS_TOKEN pToken = NULL;

	PAGED_CODE();

	pToken = SeQuerySubjectContextToken(&(Data->Iopb->Parameters.Create.SecurityContext->AccessState->SubjectSecurityContext));

	status = SeQueryInformationToken(pToken, TokenUser, &ppUser);
	if (status == STATUS_SUCCESS)
	{
		try
		{
			status = RtlConvertSidToUnicodeString(&userSID, ppUser->User.Sid, TRUE);
			if (status == STATUS_SUCCESS)
			{
				//Access Violation Error will happen if userSID.MaximumLength is Gerater than MAXX_PATH
				RtlCopyBytes(notification->UserSID, userSID.Buffer, userSID.MaximumLength);
				notification->UserSID[userSID.MaximumLength / sizeof(WCHAR)] = UNICODE_NULL;
				RtlFreeUnicodeString(&userSID);
				//DbgPrint("\n->SetUserSIDFromSubjectSecurityContext [%ws]", notification->UserSID);

			}
			else
			{
				notification->UserSID[0] = UNICODE_NULL;
				DbgPrint("\nError in RtlConvertSidToUnicodeString - UserSID -> [0x%x] -> IRQL[%d]", status, KeGetCurrentIrql());
			}
		} except(EXCEPTION_EXECUTE_HANDLER)
		{
			DbgPrint("\n!!! Exception in RtlCopyMemory - UserSID -> IRQL[%d]", KeGetCurrentIrql());
			notification->UserSID[0] = UNICODE_NULL;
		}
		ExFreePool((PVOID)ppUser);
	}
	else
	{
		DbgPrint("\n--> SeQueryInformationToken Failed");

	}
}
VOID
SetTokenSource(
__inout PCHANGE_NOTIFICATION notification,
__in HANDLE token
)
{
	ULONG len = 0;
	PTOKEN_SOURCE ppUser = NULL;
	UNICODE_STRING userSID;
	NTSTATUS status;

	PAGED_CODE();

	notification->TokenSource[0] = UNICODE_NULL;

	//Get TokenSource from this token handle
	status = ZwQueryInformationToken(token, TokenSource, NULL, 0, &len); //to get required length

	if (status == STATUS_BUFFER_TOO_SMALL && len>0)
	{
		ppUser = (PTOKEN_SOURCE)ExAllocatePoolWithTag(NonPagedPool, len, FSM_TOKEN_SOURCE_POOL_TAG);
		if (ppUser == NULL) //tagged memory allocation
		{
			DbgPrint("\nMemory allocation failed in TokenSource... IRQL[%d]", KeGetCurrentIrql());
		}
		else
		{
			status = ZwQueryInformationToken(token, TokenSource, (PVOID)ppUser, len, &len);
			if (status == STATUS_SUCCESS)
			{
				try {
					RtlCopyBytes(notification->TokenSource, ppUser->SourceName, TOKEN_SOURCE_LENGTH);
					notification->TokenSource[TOKEN_SOURCE_LENGTH] = UNICODE_NULL;
				} except(EXCEPTION_EXECUTE_HANDLER) {
					DbgPrint("\n!!! Exception in RtlCopyMemory - TokenSource -> IRQL[%d]", KeGetCurrentIrql());
					notification->TokenSource[0] = UNICODE_NULL;
				}
			}
			else
			{
				DbgPrint("\n2) Error while retrieving TokenSource -> [0x%x] -> IRQL[%d] ", status, KeGetCurrentIrql());
			}
		}
	}
	else
	{
		DbgPrint("\n1) Error while retrieving TokenSource -> [0x%x] -> IRQL[%d] -> len[%d]", status, KeGetCurrentIrql(), len);
	}

	if (ppUser != NULL) {
		ExFreePoolWithTag((PVOID)ppUser, FSM_TOKEN_SOURCE_POOL_TAG);
	}

}

NTSTATUS
GetProcessImageName(
__inout PUNICODE_STRING ProcessImageName
)
{
	NTSTATUS status;
	ULONG returnedLength;
	ULONG bufferLength;
	PVOID buffer;
	PUNICODE_STRING imageName;

	PAGED_CODE(); // this eliminates the possibility of the IDLE Thread/Process
	//PAGED_CODE_LOCKED();

	if (NULL == ZwQueryInformationProcess) {

		UNICODE_STRING routineName;

		RtlInitUnicodeString(&routineName, L"ZwQueryInformationProcess");

		ZwQueryInformationProcess =
			(QUERY_INFO_PROCESS)MmGetSystemRoutineAddress(&routineName);

		if (NULL == ZwQueryInformationProcess) {
			DbgPrint("\nCannot resolve ZwQueryInformationProcess");
			return STATUS_FWP_NULL_POINTER;
		}
	}
	//
	// Step one - get the size we need
	//
	status = ZwQueryInformationProcess(NtCurrentProcess(),
		ProcessImageFileName,
		NULL, // buffer
		0, // buffer size
		&returnedLength);

	if (STATUS_INFO_LENGTH_MISMATCH != status) {

		return status;

	}

	//
	// Is the passed-in buffer going to be big enough for us?  
	// This function returns a single contguous buffer model...
	//
	bufferLength = returnedLength - sizeof(UNICODE_STRING);

	if (ProcessImageName->MaximumLength < bufferLength) {

		ProcessImageName->Length = (USHORT)bufferLength;

		DbgPrint("\nSTATUS_BUFFER_OVERFLOW in GetProcessImageName");

		return STATUS_BUFFER_OVERFLOW;

	}

	//
	// If we get here, the buffer IS going to be big enough for us, so 
	// let's allocate some storage.
	//
	buffer = ExAllocatePoolWithTag(NonPagedPool, returnedLength, FSM_PROCESS_NAME_POOL_TAG);

	if (NULL == buffer) {
		DbgPrint("\nMemory Allocation Failed for buffer in GetProcessImageName");
		return STATUS_INSUFFICIENT_RESOURCES;

	}

	//
	// Now lets go get the data
	//
	status = ZwQueryInformationProcess(NtCurrentProcess(),
		ProcessImageFileName,
		buffer,
		returnedLength,
		&returnedLength);

	if (NT_SUCCESS(status)) {
		//
		// Ah, we got what we needed
		//
		imageName = (PUNICODE_STRING)buffer;

		RtlCopyUnicodeString(ProcessImageName, imageName);

	}

	//
	// free our buffer
	//

	ExFreePoolWithTag((PVOID)buffer, FSM_PROCESS_NAME_POOL_TAG);

	//
	// And tell the caller what happened.
	//    
	return status;
}

//---------------------------------------------------------------------------------------------//


void
FsmSetAdditionInfoFromContext(
__inout PCHANGE_NOTIFICATION currentIrpNotificationInfo,
__in PCHANGE_NOTIFICATION InfoFromContext
)
{
	PAGED_CODE();
	try
	{
		currentIrpNotificationInfo->CreationTime = InfoFromContext->CreationTime;
		currentIrpNotificationInfo->LastAccessTime = InfoFromContext->LastAccessTime;
		currentIrpNotificationInfo->LastWriteTime = InfoFromContext->LastWriteTime;
		currentIrpNotificationInfo->FileAttributes = InfoFromContext->FileAttributes;
		FsmCopyWideString(currentIrpNotificationInfo->UserSID, InfoFromContext->UserSID, MAXX_PATH);
	} except(EXCEPTION_EXECUTE_HANDLER) {
		DbgPrint("!!! Exception in FsmSetAdditionInfoFromContext() -> ox%x", GetExceptionCode());
	}
}


//---------------------------------------------------------------------------------------------//

