/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.ads.startup.actions;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.tanukisoftware.wrapper.WrapperManager;

import com.manageengine.ads.fw.roboupdate.process.RoboUpdateConstants;
import com.manageengine.ads.fw.roboupdate.process.RoboUpdateInfoParser;
import com.manageengine.ads.startup.process.InvokeClass;


/**
 *
 * @author aswathy-1909
 */
public class RoboUpdateManager implements InvokeClass{

	public static String homeDir = "";

	public static String userHome = System.getProperty("user.dir");

	public static List<String> classpathList = null;

	public void executeProgram(Properties addionalParams, String[] args)
	{
		String message = "";  // No I18N
		String ppmLib = "ppmLib"; // No I18N
		try
		{
			int lastIndex = userHome.lastIndexOf("\\");
			homeDir = userHome.substring(0,lastIndex);

			String classPath = null;
			String roboupdate = System.getProperty("roboupdate");
			String dbHome = new File(System.getProperty("user.dir"),System.getProperty("db.home")).getCanonicalPath();
			classpathList = new RoboUpdateInfoParser(System.getProperty("roboupdate.conf")).getClasspathForProcess("Roboupdater"); // No I18N
			
			if(roboupdate != null && roboupdate.equalsIgnoreCase("true"))
			{
				classPath = constructClassPath(classpathList,homeDir,ppmLib);
				replaceWrapper(homeDir);
			}
			else
			{
				classPath = constructClassPath(classpathList,homeDir,null);
				roboupdate = "false"; // No I18N
				deletePPMLib(homeDir,ppmLib);
			}
			checkPersistenceConfiguration(homeDir);
			String command = "\"" + homeDir + "\\jre\\bin\\java.exe\"  -Dserver.home=\"" + homeDir + "\" -Ddb.home=\"" + dbHome + "\" -Droboupdate=" + roboupdate + " -DppmLib=" + ppmLib + " -Dconf.dir=\"" + homeDir + "\\conf\" -Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager -Djava.util.logging.config.file=\"" + homeDir + "/conf/logging.properties\"  -Dlog.dir=\"" + homeDir + "\\ppmLog\" -cp " + "\"" + classPath + "\"" + " com.manageengine.ads.fw.roboupdate.RoboUpdater"; // NO I18N
			message = process(command);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		if((message.equalsIgnoreCase("error")) || (message.equalsIgnoreCase(RoboUpdateConstants.MESSAGE_RESTORE_FAILED)))
		{
			
			WrapperManager.stop(1);
		}
		else if(message.equalsIgnoreCase(RoboUpdateConstants.MESSAGE_RESTART_SERVER))
		{
			
			WrapperManager.restart();
		}
		else if(message.equalsIgnoreCase(RoboUpdateConstants.MESSAGE_RESTART_FOR_UPDATE))
		{
			try
			{
				if(updateWrapper(homeDir,ppmLib))
				{
					backupConfiguration(homeDir);
					checkUpdateManager(homeDir + File.separator + "lib"); // No I18N
					copyFilesToPPMLib(classpathList,homeDir,ppmLib);
					WrapperManager.restart();
				}
			}
			catch (Exception e)
			{
				replaceWrapper(homeDir);
				WrapperManager.restart();
				e.printStackTrace();
			}
			
		}

	}

	public static String process(String command)
	{
		String message = "";
		try
		{

			Process process1 = Runtime.getRuntime().exec(command);
			ProcessStreamReader inputReader = new ProcessStreamReader(process1.getInputStream(),System.out);
			ProcessStreamReader outputReader = new ProcessStreamReader(process1.getErrorStream(),System.err);

			inputReader.start();
			outputReader.start();
			process1.waitFor();
			inputReader.join();
			outputReader.join();
			message = inputReader.getExitMessage();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return message;
	}

	private static void replaceWrapper(String homeDir)
	{
		try
		{
			File previousWrapper = new File(homeDir,"/conf/wrapper_old.conf");
			if(previousWrapper.exists())
			{
				FileUtils.copyFile(previousWrapper,new File(homeDir,"/conf/wrapper.conf"));
				//previousWrapper.delete();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public static boolean updateWrapper(String homeDir, String ppmLib) throws Exception
	{
		String wrapperLocation = homeDir + "/conf/wrapper.conf";  // No I18N
		int classpathIndex = 1, additionalPathIndex = 1, libraryPathIndex = 1;
		File oldWrapper =new File(homeDir + "/conf/wrapper_old.conf");
		FileUtils.copyFile(new File(wrapperLocation),oldWrapper);
		if(oldWrapper.exists())
		{
		List<String> wrapperData = FileUtils.readLines(new File(wrapperLocation),null);
		String binLocation = homeDir + File.separator + "bin"; // No I18N
		String newLibLocation = homeDir + File.separator + ppmLib;
		for (int i = 0; i < wrapperData.size(); i++)
		{
			String line = wrapperData.get(i);
			if(line.startsWith("#"))
			{
				continue;
			}
			else if(line.contains("wrapper.java.classpath") || line.contains("wrapper.java.library.path"))
			{
				String data[] = line.split("=");

				if(data.length > 1)
				{
					File file = new File(binLocation,data[1]);
					if(file.exists())
					{
						if(!file.isDirectory())
						{
							FileUtils.copyFile(file,new File(newLibLocation,file.getName()));
							if(data[0].contains("wrapper.java.classpath"))
							{
								line = "wrapper.java.classpath." + classpathIndex +"=" + ".." + File.separator + ppmLib + File.separator + file.getName(); // No I18N
								classpathIndex++;
							}
							else
							{
								line = "wrapper.java.library.path." + libraryPathIndex +"=" + ".." + File.separator + ppmLib + File.separator + file.getName(); // No I18N
								libraryPathIndex++;
							}
							wrapperData.set(i,line);
						}
						else if(!file.getName().equals("lib"))
						{
							FileUtils.copyDirectory(file,new File(newLibLocation,file.getName()));
							if(data[0].contains("wrapper.java.classpath"))
							{
								line = "wrapper.java.classpath." + classpathIndex +"=" + ".." + File.separator + ppmLib + File.separator + file.getName(); // No I18N
								classpathIndex++;
							}
							else
							{
								line = "wrapper.java.library.path." + libraryPathIndex +"=" + ".." + File.separator + ppmLib + File.separator + file.getName(); // No I18N
								libraryPathIndex++;
							}
							wrapperData.set(i,line);
						}
						else
						{
							wrapperData.set(i,null);
						}
					}
				}
			}
			else if(line.contains("wrapper.java.additional"))
			{
				additionalPathIndex++;
			}
		}
		wrapperData.add("wrapper.java.additional."+additionalPathIndex+"=-Droboupdate=TRUE"); // No I18N
		
		//Added  To reset failed Invocation count because of multiple startups 
		wrapperData.add("wrapper.successful_invocation_time=60"); // No I18N
		
		FileUtils.writeLines(new File(wrapperLocation),null,wrapperData);
		}
		else
		{
			return false;
		}
		return true;
	}

	private static void copyFilesToPPMLib(List<String> filestoCopy, String homeDir, String ppmLibName)
	{
		try
		{
			for (String fileName : filestoCopy)
			{
				File file = new File(homeDir,fileName);
				if(file.exists() && !file.isDirectory())
				{
					FileUtils.copyFile(file,new File(homeDir + File.separator + ppmLibName,file.getName()));
				}
				else if(file.exists())
				{
					FileUtils.copyDirectory(file,new File(homeDir + File.separator + ppmLibName,fileName));
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	private static String constructClassPath(List<String> referencedFiles, String homeDir, String ppmLib)
	{
		StringBuilder result = new StringBuilder();
		for (String file : referencedFiles)
		{
			result.append(homeDir);
			if(ppmLib != null)
			{
				String[] fileName = file.split("\\\\");
				result.append(File.separator + ppmLib + File.separator + fileName[fileName.length - 1]);
			}
			else
			{
				result.append(file);
			}
			result.append(";");
		}
		return result.toString();
	}

	private static void checkUpdateManager(String libDirectory)
	{
		try
		{
			String updateManagerNewFileName = "AdventNetUpdateManagerInstaller.jar_new";  // No I18N
			String updateManagerExistingFileName = "AdventNetUpdateManagerInstaller.jar"; // No I18N
			File file = new File(libDirectory,updateManagerNewFileName);
			if(file.exists())
			{
				FileUtils.copyFile(file,new File(libDirectory,updateManagerExistingFileName));
				file.delete();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private static void checkPersistenceConfiguration(String homeDir)
	{
		try
		{
			File databaseParamsNewFile=new File(homeDir+File.separator+"conf","database_params.conf_new");
			File persistenceConfigNewFile=new File(homeDir+File.separator+"conf","Persistence/persistence-configurations.xml_new");

			if(databaseParamsNewFile.exists())
			{
				FileUtils.copyFile(databaseParamsNewFile,new File(homeDir+File.separator+"conf","database_params.conf"));
				databaseParamsNewFile.delete();
			}
			if(persistenceConfigNewFile.exists())
			{
				FileUtils.copyFile(persistenceConfigNewFile,new File(homeDir+File.separator+"conf","Persistence/persistence-configurations.xml"));
				persistenceConfigNewFile.delete();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	private static void deletePPMLib(String homeDir, String ppmLibName)
	{
		try
		{
			File file = new File(homeDir,ppmLibName);
			if(file.exists())
			{
				FileUtils.deleteDirectory(new File(homeDir,ppmLibName));
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

	}
	
	private static void backupConfiguration(String homeDir)
	{
		try
		{
			FileUtils.copyFile(new File(homeDir+File.separator+"conf","database_params.conf"),new File(homeDir+File.separator+"conf","database_params.conf_old"));
			FileUtils.copyFile(new File(homeDir+File.separator+"conf","/Persistence/persistence-configurations.xml"),new File(homeDir+File.separator+"conf","/Persistence/persistence-configurations.xml_old"));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}    
}
