package com.manageengine.rmp.bmr;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.DateUtil;
import com.manageengine.rmp.bmr.configure.BMRDatabase;
import com.manageengine.rmp.bmr.schedule.BMRScheduler;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.licensing.Environment;
import com.manageengine.rmp.licensing.LicenseType;
import com.manageengine.rmp.licensing.LicenseUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import com.manageengine.rmp.virtual.NativeException;
import com.manageengine.rmp.virtual.VMNativeHandler;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Iterator;

//ignoreI18n_start
public class BMRLicenseHandler {
    public static void applyLicense(ArrayList newServers, boolean isRemoveBackups) throws Exception {
        LogWriter.bmr.info("API called: BMRLicenseHandler.applyLicense(" + newServers + ", " + isRemoveBackups + ")");
        try {
            int subscribedCount = LicenseUtil.licenseSubscriptionCount(Environment.windows_server);
            if(newServers.size() > subscribedCount && subscribedCount != -1) {
                throw new Exception("New Servers count greater than subscribed servers count");
            }
            ArrayList oldLicensedServers = getLicensedServersFromDB();
            DataObject dobject = CommonUtil.getPersistence().get(TableName.BMR_DOMAIN_CONTROLLERS, (Criteria) null);
            Iterator itr = newServers.iterator();
            while (itr.hasNext()) {
                Long serverId = (Long) itr.next();
                oldLicensedServers.remove(serverId);
                Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), serverId, QueryConstants.EQUAL);
                Row row = dobject.getRow(TableName.BMR_DOMAIN_CONTROLLERS, criteria);
                row.set("IS_LICENSED", LicenseType.Licensed.ordinal());
                dobject.updateRow(row);
            }
            if (oldLicensedServers.size() > 0 && isRemoveBackups) {
                removeBackups(oldLicensedServers);
            }
            CommonUtil.getPersistence().update(dobject);

            disableBackupSchedule(oldLicensedServers);

            UpdateQuery updateQuery = new UpdateQueryImpl(TableName.BMR_DOMAIN_CONTROLLERS);
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), newServers.toArray(), QueryConstants.NOT_IN);
            criteria = criteria.and(new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "OBJECT_TYPE"), "SERVER", QueryConstants.EQUAL, false));
            updateQuery.setCriteria(criteria);
            updateQuery.setUpdateColumn("BACKUP_FILTER_TIME", DateUtil.getTimestampFromDate(Calendar.getInstance().getTime()));
            CommonUtil.getPersistence().update(updateQuery);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Apply License failed!");
        }
    }

    private static void removeBackups(ArrayList serverIds) {
        LogWriter.bmr.info("API called: BMRLicenseHandler.removeBackups(" + serverIds + ")");
        try {
            DataObject bmrTotalBackupDetailsObject = CommonUtil.getPersistence().get(TableName.BMR_TOTAL_BACKUP_DETAILS, (Criteria) null);
            DataObject repoDobj = CommonUtil.getPersistence().get(TableName.RMP_STORAGE_REPOSITORY, (Criteria) null);
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), serverIds.toArray(), QueryConstants.IN);
            ArrayList<Long> delRows = new ArrayList();
            ArrayList<String> domainsList = new ArrayList<>();
            DataObject bmrIndividualBackupDetailsObject = CommonUtil.getPersistence().get(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, criteria);
            if(!bmrIndividualBackupDetailsObject.isEmpty()) {
                Iterator rows = bmrIndividualBackupDetailsObject.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                while (rows.hasNext()) {
                    Row bmrIndividualBackupDetailsRow = (Row) rows.next();
                    long serverId = (long) bmrIndividualBackupDetailsRow.get("DC_ID");
                    long repositoryId = (long) bmrIndividualBackupDetailsRow.get("REPOSITORY_ID");
                    String folder = (String) bmrIndividualBackupDetailsRow.get("BACKUP_FOLDER");
                    String backupFolder = BMRDatabase.getNameFromId(serverId) + "\\" + folder;
                    double backupSize = (double) bmrIndividualBackupDetailsRow.get("SIZE");
                    String backupType = (String) bmrIndividualBackupDetailsRow.get("BACKUP_TYPE");

                    String domainName = BMRDatabase.getDomainNamefromDcId(serverId);
                    domainsList.add(domainName);

                    String status = (String) bmrIndividualBackupDetailsRow.get("STATUS");

                    try {
                        if(folder.isEmpty() || deleteLocation(repositoryId, backupFolder, repoDobj) || status.startsWith("Failed")) {
                            if(backupSize > 0) {
                                Criteria criteria1 = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "DC_ID"), serverId, QueryConstants.EQUAL);
                                Row bmrTotalBackupDetailsRow = bmrTotalBackupDetailsObject.getRow(TableName.BMR_TOTAL_BACKUP_DETAILS, criteria1);
                                int fullBackupCount = (int)bmrTotalBackupDetailsRow.get("FB_COUNT");
                                int incrementalBackupCount = (int)bmrTotalBackupDetailsRow.get("IB_COUNT");
                                if(backupType.equalsIgnoreCase("FB")) {
                                    fullBackupCount -= 1;
                                }
                                else if(backupType.equalsIgnoreCase("IB")) {
                                    incrementalBackupCount -= 1;
                                }
                                bmrTotalBackupDetailsRow.set("SIZE", (double)bmrTotalBackupDetailsRow.get("SIZE") - backupSize);
                                bmrTotalBackupDetailsRow.set("FB_COUNT", fullBackupCount);
                                bmrTotalBackupDetailsRow.set("IB_COUNT", incrementalBackupCount);
                                bmrTotalBackupDetailsObject.updateRow(bmrTotalBackupDetailsRow);
                            }
                            delRows.add((Long) bmrIndividualBackupDetailsRow.get("OPERATION_ID"));
                        }
                    } catch (Exception e) {
                        LogWriter.bmr.severe("BMRLicenseHandler.removeBackups(): Unable to delete folder(" + backupFolder + ") in its location");
                        e.printStackTrace();
                    }
                }
                if(delRows.size() > 0) {
                    Criteria criteria1 = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), delRows.toArray(), QueryConstants.IN);
                    CommonUtil.getPersistence().delete(criteria1);
                }
                CommonUtil.getPersistence().update(bmrTotalBackupDetailsObject);
                for(int i = 0; i < domainsList.size(); i++) {
                    if(BMRDatabase.noBackupsAvailable(domainsList.get(i))) {
                        Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_DETAILS, "DOMAIN_NAME"), domainsList.get(i), QueryConstants.EQUAL);
                        UpdateQuery upquery = new UpdateQueryImpl(TableName.BMR_DOMAIN_DETAILS);
                        upquery.setUpdateColumn("IS_BACKUP_DONE", false);
                        upquery.setCriteria(domainCriteria);
                        CommonUtil.getPersistence().update(upquery);
                        LogWriter.bmr.info("IS_BACKUP_DONE set to false for domain " + domainsList.get(i));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static boolean deleteLocation(Long repoId, String backupFolder, DataObject repoDobj) {
        LogWriter.bmr.info("API called: BMRLicenseHandler.deleteLocation()");
        try {
            Criteria crt = new Criteria(Column.getColumn(TableName.RMP_STORAGE_REPOSITORY, "REPOSITORY_ID"), repoId, QueryConstants.EQUAL);
            Row row = repoDobj.getRow(TableName.RMP_STORAGE_REPOSITORY, crt);
            if (row != null) {
                Hashtable repoDetails = new Hashtable();
                repoDetails.put("REPOSITORY_PATH", row.get("REPOSITORY_PATH"));
                repoDetails.put("USERNAME", row.get("REPOSITORY_USERNAME"));
                repoDetails.put("PASSWORD", row.get("REPOSITORY_PASSWORD"));
                boolean isLocal = (boolean) row.get("IS_LOCAL");
                NativeException nativeException = new NativeException();
                if (isLocal || VMNativeHandler.validateConnectRepository(repoDetails, "connect", nativeException)) {
                    if (nativeException.isExceptionOccured()) {
                        LogWriter.bmr.severe(nativeException.toString());
                        throw new Exception("A native error has been detected");
                    }
                    String backupDirectory = repoDetails.get("REPOSITORY_PATH") + "\\" + backupFolder;
                    File file = new File(backupDirectory);
                    if (file.exists()) {
                        FileUtils.deleteDirectory(file);
                        if (!isLocal) {
                            NativeException nativeException1 = new NativeException();
                            VMNativeHandler.validateConnectRepository(repoDetails, "disconnect", nativeException1);
                            if (nativeException1.isExceptionOccured()) {
                                LogWriter.bmr.severe(nativeException1.toString());
                                throw new Exception("A native error has been detected");
                            }
                        }
                        return true;
                    }
                }
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private static ArrayList getLicensedServersFromDB() {
        // the method also updates IS_LICENSED column to unlicensed
        LogWriter.bmr.info("API called: BMRLicenseHandler.getLicensedServersFromDB()");
        ArrayList retVal = new ArrayList();
        try {
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "IS_LICENSED"), LicenseType.Licensed.ordinal(), QueryConstants.EQUAL);
            DataObject dobject = CommonUtil.getPersistence().get(TableName.BMR_DOMAIN_CONTROLLERS, criteria);
            Iterator itr = dobject.getRows(TableName.BMR_DOMAIN_CONTROLLERS);
            while (itr.hasNext()) {
                Row row = (Row) itr.next();
                retVal.add(row.get("DC_ID"));
                row.set("IS_LICENSED", LicenseType.Unlicensed.ordinal());// No I18N
                dobject.updateRow(row);
            }
            CommonUtil.getPersistence().update(dobject);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return retVal;
    }

    public static void updateIsWindowsServerConfigured() {
        LogWriter.bmr.info("API called: " + "BMRLicenseHandler.updateIsWindowsServerConfigured()");
        try {
            UpdateQuery updateQuery = new UpdateQueryImpl(TableName.RMP_SYSTEM_PARAMS);
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_WINDOWSSERVER_CONFIGURED", QueryConstants.EQUAL);
            updateQuery.setCriteria(criteria);
            updateQuery.setUpdateColumn("PARAM_VALUE", "true");
            CommonUtil.getPersistence().update(updateQuery);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void disableBackupSchedule(ArrayList<Long> serverIds) {
        try {
            for(int i = 0; i < serverIds.size(); i++) {
                long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(BMRDatabase.getDomainNamefromDcId(serverIds.get(i))).getProperty("DOMAIN_ID"));
                SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
                query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
                Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), serverIds.get(i), QueryConstants.EQUAL);
                query.setCriteria(dcCriteria.and(domainCriteria));
                DataObject dobj = CommonUtil.getPersistence().get(query);
                if(!dobj.isEmpty()) {
                    Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);

                    long fbScheduleId = (long) row.get("FB_SCHEDULE_ID");
                    long ibScheduleId = (long) row.get("IB_SCHEDULE_ID");

                    if (fbScheduleId != 0) {
                        BMRScheduler.disableSchedule(fbScheduleId);
                    }

                    if (ibScheduleId != 0) {
                        BMRScheduler.disableSchedule(ibScheduleId);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
//ignoreI18n_end
