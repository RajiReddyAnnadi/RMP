/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.bmr.configure;

import com.adventnet.customview.CustomViewManager;
import com.adventnet.customview.CustomViewRequest;
import com.adventnet.customview.ViewData;
import com.adventnet.ds.query.*;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.model.table.CVTableModel;
import com.adventnet.persistence.*;
import com.adventnet.taskengine.util.PersistenceUtil;
import com.adventnet.taskengine.util.ScheduleUtil;
import com.manageengine.ads.fw.agent.installation.WindowsHandler;
import com.manageengine.ads.fw.domain.ADSDomainHandler;
import com.manageengine.ads.fw.ldap.ad.ADSADException;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.DateUtil;
import com.manageengine.rmp.admin.MailInfoBMR;
import com.manageengine.rmp.admin.NotificationAPI;
import com.manageengine.rmp.admin.constants.NotificationType;
import com.manageengine.rmp.bmr.BMRThreadManager;
import com.manageengine.rmp.bmr.agent.InstallAgent;
import com.manageengine.rmp.bmr.schedule.BMRScheduler;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.RMPCommonUtil;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dashboard.GetDomainDetails;
import com.manageengine.rmp.jni.BMRIso;
import com.manageengine.rmp.jni.RMPMountManager;
import com.manageengine.rmp.jni.RMPNativeManager;
import com.manageengine.rmp.licensing.Environment;
import com.manageengine.rmp.licensing.LicenseType;
import com.manageengine.rmp.licensing.LicenseUtil;
import com.manageengine.rmp.licensing.ProductSubscriptionInfo;
import com.manageengine.rmp.scheduler.ScheduleManager;
import com.manageengine.rmp.settings.AddDomainServ;
import com.manageengine.rmp.util.GeneralUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import com.manageengine.rmp.util.winutil.WindowsUtil;
import com.manageengine.rmp.virtual.repository.VMRepositoryServer;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.InetAddress;
import java.net.URLDecoder;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 * @author Chella-3221
 */
public class BMRDatabase {

    public static void backupCode(String dcName, long backupId, long domainId, String type, String code, Long fullBuId, int isEncrypted, String secretKey) {
        FileInputStream fis = null;
        BufferedReader inp = null;
        try {
            Properties details = null;
            String backupFolder = "", status = "Started", folder = "";
            long operationId;
            String domainName = (String) RMPDomainHandler.getDomainDetailsById(domainId).getProperty("DOMAIN_NAME");
            operationId = BMRDatabase.getLatestBackupId(backupId);
            Properties prop = RMPDomainHandler.getDomainDetailsByName(domainName);
            String authenticationRequired = prop.getProperty("IS_AUTHENTICATION_REQUIRED");
            int availableLicenseCount = LicenseUtil.licenseSubscriptionCount(Environment.windows_server);
            int appliedLicenseCount = LicenseUtil.getLicenseAppliedCount(Environment.windows_server);
            if (LicenseUtil.getDaysToExpire() <= 0) {
                BMRDatabase.updateBackupStatus(backupId, "Failed (License has expired)"); //No I18N
            }  else if (getLicenseType(backupId) == LicenseType.Unlicensed && !(availableLicenseCount==-1 || (availableLicenseCount>0 && availableLicenseCount>appliedLicenseCount))) {
                BMRDatabase.updateBackupStatus(backupId, "Failed (" + dcName + " is not Licensed)");  //No I18N
            } else if (authenticationRequired != null && authenticationRequired.equalsIgnoreCase("false")) { //No I18N
                BMRDatabase.updateBackupStatus(backupId, "Failed (Access Denied)"); //No I18N
            }  else {
                if (getLicenseType(backupId) == LicenseType.Unlicensed) {
                    BMRDatabase.applyLicense(backupId);
                }
                String domainFlatName = (String) prop.getProperty("USER_DOMAIN_NAME");
                String domainUser = (String) prop.getProperty("USER_NAME");
                String domainPwd = (String) prop.getProperty("PASSWORD");
                String finalUserName = domainFlatName + "\\" + domainUser + "###" + domainPwd;//No I18N
                Long totalTime = 0L;
                float finalSize = 0f;
                boolean isDeleted = BMRDatabase.isDCDeleted(backupId);
                if (!isDeleted) {
                    BMRDatabase.updateDCAgent(dcName, backupId, domainId);
                    String isAgentInstalled = BMRDatabase.getAgentInstallationStatus(backupId, domainId);
                    JSONObject repoStatus = isRepoEnabled(backupId);
                    boolean isRepoEnabled = (boolean) repoStatus.get("isEnabled");
                    boolean isRepoDeleted = (boolean) repoStatus.get("isDeleted");
                    if (isRepoDeleted) {
                        LogWriter.bmr.info("Repository deleted");//NO I18N
                        BMRDatabase.updateBackupStatus(backupId, "Failed (Repository deleted)"); //No I18N
                    } else if (!isRepoEnabled) {
                        LogWriter.bmr.info("Repository disabled");//NO I18N
                        BMRDatabase.updateBackupStatus(backupId, "Failed (Repository disabled)"); //No I18N
                    } else if (isAgentInstalled.equalsIgnoreCase("Backup configured")) {
                        JSONArray allPartitions = new JSONArray();
                        details = BMRDatabase.getLocationDetail(backupId);
                        String loc = details.get("Location").toString();
                        String name = details.get("User").toString();
                        String pwd = details.get("Password").toString();
                        Properties props = RMPNativeManager.checkCredentials(loc, name, pwd, "connect"); //No I18N
                        if (props.get("Success") != null) {
                            Date now = new Date();
                            SimpleDateFormat dateFormat = new SimpleDateFormat("MM.dd.yyyy 'at' HH.mm"); //No I18N
                            folder = dateFormat.format(now);
                            BMRDatabase.updateBackupLocation(backupId, folder);
                            String time = loc + "\\" + dcName + "\\" + folder;  //NO I18N
                            LogWriter.bmr.info("Backup location: " + time);//NO I18N
                            File dir = new File(time);
                            dir.mkdirs();
                            backupFolder = time;
                            status = BMRDatabase.triggerBackupAndUpdateStatus(finalUserName, dcName, domainFlatName, domainUser, domainPwd, backupFolder, name, pwd, code, "", isEncrypted, secretKey);
                            Properties disconnectProps = RMPNativeManager.checkCredentials(loc, name, pwd, "disconnect"); //No I18N
                        } else {
                            LogWriter.bmr.info("In backupCode....RMPNativeManager.checkCredentials failed "+props.toString());//No I18N
                            if(props.get("Invalid_Password")!=null || props.get("Logon_Failure") != null){
                                status = "Failed (Access denied to the repository)";//No I18N
                            } else {
                                status = "Failed (Location inaccessible)"; //No I18N
                            }
                        }
                        if (status.equals("Started")) {
                            Properties props1 = RMPNativeManager.checkCredentials(loc, name, pwd, "connect"); //No I18N
                            //if (props1.get("Success") != null) {
                            try {
                                File fin = new File(backupFolder + "\\BackupDetails.txt");
                                fis = new FileInputStream(fin);
                                inp = new BufferedReader(new InputStreamReader(fis));
                                Properties buDetails = BMRDatabase.readFromBMRBackupDetailsFile(type, backupFolder, inp);
                                status = (String) buDetails.getProperty("status");
                                finalSize = Float.parseFloat((String) buDetails.getProperty("finalSize"));
                                totalTime = Long.valueOf(buDetails.getProperty("totalTime"));
                                allPartitions = new JSONArray((String) buDetails.getProperty("allPartitions"));

                                if (type.equals("IB")) {
                                    int partitionCnt = allPartitions.length();
                                    int prevPartitionCnt = BMRDatabase.getPrevPartitionCnt(backupId);
                                    if (partitionCnt != prevPartitionCnt) {
                                        status = "Failed (Partition count is different)";//No I18N
                                        LogWriter.bmr.info("Backup failed (Partition count is different)");//NO I18N
                                    }
                                }

                                Properties disconnectProps1 = RMPNativeManager.checkCredentials(loc, name, pwd, "disconnect"); //No I18N
                            } catch (Exception e) {
                                LogWriter.bmr.info("In Backupcode catch");//NO I18N
                                e.printStackTrace();
                                status = "Failed (Location inaccessible)"; //No I18N
                            }
                        }
                        BMRDatabase.updateIndividualBackupDetails(operationId, finalSize, allPartitions, folder, status, totalTime);
                        if (type.equals("IB")) {
                            BMRDatabase.storeIncrementalBackupDetails(fullBuId, operationId);
                        }
                        if (finalSize > 0f) {
                            BMRDatabase.updateTotalBackupDetails(domainName, domainId, backupId, finalSize, type);
                            if (type.equals("FB") && status.equals("Completed")) {
                                if (!BMRDatabase.deleteExcessBackups(backupId, domainName)) {
                                    LogWriter.bmr.info("Retention failed to delete old backups");//NO I18N
                                }
                            }
                        }
                    } else {
                        LogWriter.bmr.info("Agent installation has failed");//NO I18N
                        BMRDatabase.updateBackupStatus(backupId, "Failed (Retry Agent installation)"); //No I18N
                    }
                } else {
                    LogWriter.bmr.info("DC has been deleted");//NO I18N
                    BMRDatabase.updateBackupStatus(backupId, "Failed (Server has been deleted)"); //No I18N
                }
            }
            JSONObject mailData = MailInfoBMR.setBMRBackupMailInfo(operationId);
            NotificationAPI.notifyBMR(NotificationType.BMRBackup, mailData);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
                if (inp != null) {
                    inp.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public synchronized static void runBMRNewDcSchedule(List domainList) {
        try {
            for (int i = 0; i < domainList.size(); i++) {
                String domain = (String) domainList.get(i);
                Properties prop = RMPDomainHandler.getDomainDetailsByName(domain);
                long domainId = Long.valueOf(prop.getProperty("DOMAIN_ID"));
                String user = null, password = null, dcName = null, userDomain = null;
                String authenticationRequired = prop.getProperty("IS_AUTHENTICATION_REQUIRED");
                if (authenticationRequired != null && authenticationRequired.equalsIgnoreCase("true")) {
                    user = (String) prop.getProperty("USER_NAME");
                    password = (String) prop.getProperty("PASSWORD");
                    userDomain = (String) prop.getProperty("USER_DOMAIN_NAME");
                    ArrayList dcList = (ArrayList) prop.get("DOMAIN_CONTROLLER_LIST");
                    dcName = (String) dcList.get(0);
                }
                ArrayList allDCList = BMRDatabase.getAllMachinesFiltered(domain, userDomain, user, password, dcName);
                JSONArray dcsList = BMRDatabase.getBMRDcs(domain, "DC",false); // NO I18N
                JSONArray serversList = BMRDatabase.getBMRDcs(domain, "SERVER",false); // NO I18N
                for (int j = 0; j < dcsList.length(); j++) {
                    JSONObject jObj = dcsList.getJSONObject(j);
                    serversList.put(jObj);
                }
                if (allDCList.size() > 0) {
                    for (int j = 0; j < allDCList.size(); j++) {
                        Properties dcProps = (Properties) allDCList.get(j);
                        String newDc = dcProps.getProperty("cn");
                        String dnsName = dcProps.getProperty("dNSHostName");
                        String guid = dcProps.getProperty("objectGUID");
                        String machineType = dcProps.getProperty("machineType");
                        Criteria dcCriteria;
                        Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                        Criteria testCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "GUID"), null, QueryConstants.EQUAL);

                        boolean testResult = RMPCommonUtil.isTableEmpty(TableName.BMR_DOMAIN_CONTROLLERS, domainCriteria.and(testCriteria), new String[]{"DC_ID"});//No I18N
                        if (!testResult) {
                            dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_NAME"), newDc, QueryConstants.EQUAL);
                        } else {
                            dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "GUID"), guid, QueryConstants.EQUAL);
                        }
                        boolean dcResult = RMPCommonUtil.isTableEmpty(TableName.BMR_DOMAIN_CONTROLLERS, domainCriteria.and(dcCriteria), new String[]{"DC_ID"});//No I18N

                        LicenseType licenseType = LicenseType.Unlicensed;
                        if (machineType.equalsIgnoreCase("DC")) {
                            if (LicenseUtil.hasComponent(LicenseUtil.ADOBJECTS_COMPONENT) && ProductSubscriptionInfo.subscribedObjectCt != 0) {
                                licenseType = LicenseType.NotRequired;
                            }
                        }

                        if (dcResult) {
                            LogWriter.general.info("New DC discovered by daily scheduler" + newDc);//No I18N
                            DataObject obj = CommonUtil.getPersistence().constructDataObject();
                            Row row = new Row(TableName.BMR_DOMAIN_CONTROLLERS);
                            DataAccess.generateValues(row);
                            row.set("DOMAIN_ID", domainId);  //No I18N
                            row.set("DC_NAME", newDc);//No I18N
                            row.set("DC_DNS_NAME", dnsName);//No I18N
                            row.set("GUID", guid);//No I18N
                            row.set("OBJECT_TYPE", machineType);//No I18N
                            row.set("IS_DELETED", false);//No I18N
                            row.set("IS_LICENSED", licenseType.ordinal());//No I18N
                            obj.addRow(row);
                            CommonUtil.getPersistence().add(obj);
                            long dcId = (long) row.get("DC_ID");
                            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                            boolean scheduleResult = RMPCommonUtil.isTableEmpty(TableName.BMR_BACKUP_SCHEDULE, criteria, new String[]{"DC_ID"});//No I18N
                            if (!scheduleResult) {
                                BMRDatabase.setSchedule(domainId, dcId);
                            }
                        } else {
                            if(testResult) {
                                UpdateQuery query = new UpdateQueryImpl(TableName.BMR_DOMAIN_CONTROLLERS);
                                query.setUpdateColumn("IS_DELETED", false); //No I18N
                                query.setUpdateColumn("DC_NAME", newDc); //No I18N
                                query.setUpdateColumn("DC_DNS_NAME", dnsName); //No I18N
                                query.setUpdateColumn("OBJECT_TYPE", machineType); //No I18N
                                query.setUpdateColumn("IS_LICENSED", licenseType.ordinal()); //No I18N
                                Criteria updateDomainCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                                Criteria updateDcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "GUID"), guid, QueryConstants.EQUAL);
                                query.setCriteria(updateDomainCriteria.and(updateDcCriteria));
                                CommonUtil.getPersistence().update(query);
                                LogWriter.general.info("dc updated in daily scheduler:" + newDc);//No I18N
                            } else {
                                LogWriter.general.info("no dc discovered in daily scheduler");//No I18N
                            }
                        }
                    }
                    ArrayList<String> dcGuids = new ArrayList<>();
                    for (int j = 0; j < allDCList.size(); j++) {
                        Properties props = (Properties) allDCList.get(j);
                        if(props.getProperty("objectGUID")!=null) {
                            dcGuids.add(props.getProperty("objectGUID"));
                        }
                    }
                    for (int j = 0; j < serversList.length(); j++) {
                        JSONObject serverObject = serversList.getJSONObject(j);
                        String isDeletedDC = serverObject.get("dcName").toString().toLowerCase();
                        if(serverObject.get("dcGuid") != null) {
                            String deletedDcGuid = serverObject.get("dcGuid").toString();
                            if (!dcGuids.contains(deletedDcGuid)) {
                                UpdateQuery query = new UpdateQueryImpl(TableName.BMR_DOMAIN_CONTROLLERS);
                                query.setUpdateColumn("IS_DELETED", true); //No I18N
                                Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                                Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "GUID"), deletedDcGuid, QueryConstants.EQUAL);
                                query.setCriteria(domainCriteria.and(dcCriteria));
                                CommonUtil.getPersistence().update(query);
                                LogWriter.general.info("Deleted flag set for DC:" + isDeletedDC);//No I18N
                            } else {
                                UpdateQuery query = new UpdateQueryImpl(TableName.BMR_DOMAIN_CONTROLLERS);
                                query.setUpdateColumn("IS_DELETED", false); //No I18N
                                Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                                Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "GUID"), deletedDcGuid, QueryConstants.EQUAL);
                                query.setCriteria(domainCriteria.and(dcCriteria));
                                CommonUtil.getPersistence().update(query);
                                LogWriter.general.info("Deleted flag removed for DC:" + isDeletedDC);//No I18N
                            }
                        }
                    }
                } else {
                    LogWriter.general.info("allDCList is empty hence skipping DB changes for " + domain);//No I18N
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void applyLicense(long dcId) {
        try {
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcId, QueryConstants.EQUAL);
            UpdateQuery query = new UpdateQueryImpl(TableName.BMR_DOMAIN_CONTROLLERS);
            query.setUpdateColumn("IS_LICENSED", LicenseType.Licensed.ordinal()); //No I18N
            query.setCriteria(criteria);
            CommonUtil.getPersistence().update(query);
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    public static int getPrevPartitionCnt(long backupId) {
        int partitionCnt = 0;
        String status = "Completed";//NO I18N
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), backupId, QueryConstants.EQUAL);
            Criteria statusCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "STATUS"), status, QueryConstants.EQUAL);
            Criteria modeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "BACKUP_MODE"), "BMR", QueryConstants.EQUAL);
            Criteria typeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "BACKUP_TYPE"), "FB", QueryConstants.EQUAL);
            query.setCriteria(statusCriteria.and(dcCriteria.and(modeCriteria.and(typeCriteria))));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", false));//NO I18N

            DataObject dobj = CommonUtil.getPersistence().get(query);

            if (!dobj.isEmpty()) {
                Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                JSONArray partitionsInfo = new JSONArray(row.get("PARTITIONS_INFO").toString());
                for (int i = 0; i < partitionsInfo.length(); i++) {
                    JSONObject info = partitionsInfo.getJSONObject(i);
                    String partitionName = (String) info.get("name");
                    if (!partitionName.startsWith("Partition")) {
                        partitionCnt++;
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return partitionCnt;
    }

    public static Properties readFromBMRBackupDetailsFile(String type, String backupFolder, BufferedReader inp) {
        Properties details = new Properties();
        try {
            DecimalFormat formatter = new DecimalFormat("00");
            String info = null, status;
            Long totalTime = 0L;
            float finalSize = 0f, dcSize = 0f;
            int temp = 0, partitionsCnt = 0, totalPartitions = 0;
            JSONArray allPartitions = new JSONArray();
            info = inp.readLine();
            int diskCnt = Integer.parseInt(info);
            for (int loop = 0; loop < diskCnt; loop++) {
                JSONArray partitions = new JSONArray();
                temp = 0;
                partitionsCnt = 0;
                if (type.equals("FB")) {
                    while (!(info = inp.readLine()).equals("Partitions:")) {
                        LogWriter.bmr.info("Backup data1: " + info);//NO I18N
                        JSONObject partition = new JSONObject();
                        partition.put("name", info);
                        if (loop == 0 && partitionsCnt == 0) {
                            partition.put("diskCnt", diskCnt);
                        }

                        partitions.put(partition);
                        partitionsCnt++;
                    }
                    while (!(info = inp.readLine()).equals("Status:")) {
                        LogWriter.bmr.info("Backup data1 usn: " + info);//NO I18N
                        JSONObject partition = partitions.getJSONObject(temp);
                        partition.put("usn", info);
                        temp++;
                    }
                } else {
                    while (!(info = inp.readLine()).equals("Status:")) {
                        LogWriter.bmr.info("Backup data1: " + info);//NO I18N
                        JSONObject partition = new JSONObject();
                        partition.put("name", info);

                        if (loop == 0 && partitionsCnt == 0) {
                            partition.put("diskCnt", diskCnt);
                        }

                        partitions.put(partition);

                        partitionsCnt++;
                    }
                }

                int diskStatus = Integer.parseInt(inp.readLine());
                if (type.equals("FB")) {
                    for (int cnt = 0; cnt < partitionsCnt; cnt++) {
                        JSONObject partition = partitions.getJSONObject(cnt);
                        Long partitionFullSize = 0L;
                        if (diskStatus == 1) {
                            info = "DiskFailed"; //No I18N
                        } else {
                            partitionFullSize = Long.parseLong(inp.readLine()) + 3584L; //Add 3584 to make it mountable by vdk
                            info = inp.readLine();
                        }
                        LogWriter.bmr.info("Backup data2: " + info);//NO I18N
                        partition.put("fullSize", partitionFullSize);
                        partition.put("status", info);
                    }
                } else {
                    for (int cnt = 0; cnt < partitionsCnt; cnt++) {
                        JSONObject partition = partitions.getJSONObject(cnt);
                        if (diskStatus == 1) {
                            info = "DiskFailed"; //No I18N
                        } else {
                            info = inp.readLine();
                        }
                        LogWriter.bmr.info("Backup data2: " + info);//NO I18N
                        partition.put("status", info);
                    }
                }
                if (diskStatus == 0) {
                    info = inp.readLine();
                }
                for (int cnt = 0; cnt < partitionsCnt; cnt++) {
                    JSONObject partition = partitions.getJSONObject(cnt);
                    String statusVal = partition.get("status").toString();
                    if ((statusVal.equals("Inaccessible")) || (statusVal.equals("DiskFailed"))) {
                        partition.put("timeUnit", "secs");
                        partition.put("timeSec", "0");
                    } else {
                        info = inp.readLine();
                        LogWriter.bmr.info("Backup data3: " + info);//NO I18N
                        Long time = Long.parseLong(info);
                        if (time >= 60) {
                            Long timeMin = time / 60;
                            if (timeMin >= 60) {
                                Long timeHr = timeMin / 60;
                                timeMin = timeMin % 60;
                                partition.put("timeUnit", "hrs");
                                partition.put("timeHr", formatter.format(timeHr));
                                partition.put("timeMin", formatter.format(timeMin));
                            } else {
                                partition.put("timeUnit", "mins");
                                partition.put("timeHr", "00");
                                partition.put("timeMin", formatter.format(timeMin));
                            }
                        } else {
                            partition.put("timeUnit", "secs");
                            partition.put("timeSec", formatter.format(time));
                        }
                        totalTime += time;
                    }
                }
                totalPartitions += partitionsCnt;
                for (int j = 0; j < partitions.length(); j++) {
                    allPartitions.put(partitions.getJSONObject(j));
                }
            }

            info = inp.readLine();

            HashMap<String, String> filesMap = new HashMap<String, String>();
            if (type.equals("FB")) {
                String[] extension = new String[]{"img"};//NO I18N
                File file = new File(backupFolder);
                List<File> names = (List<File>) FileUtils.listFiles(file, extension, true);
                for (int loop = 0; loop < names.size(); loop++) {
                    String partitionName = names.get(loop).getName();
                    String partitionAbsName = names.get(loop).getAbsolutePath();
                    String partitionNameWithoutExtn = FilenameUtils.removeExtension(partitionName);
                    filesMap.put(partitionNameWithoutExtn, partitionAbsName);
                }
                if (names.isEmpty()) {
                    for (int cnt = 0; cnt < totalPartitions; cnt++) {
                        JSONObject partition = allPartitions.getJSONObject(cnt);
                        partition.put("size", 0f);
                        partition.put("sizeUnit", "MB");
                    }
                } else {
                    for (int cnt = 0; cnt < totalPartitions; cnt++) {
                        JSONObject partition = allPartitions.getJSONObject(cnt);
                        String statusVal = partition.get("status").toString();
                        if ((statusVal.equals("Inaccessible")) || (statusVal.equals("DiskFailed"))) {
                            partition.put("size", 0f);
                            partition.put("sizeUnit", "MB");
                        } else {
                            String name = partition.get("name").toString();
                            String fileName = "";
                            if (name.startsWith("Partition")) {
                                fileName = filesMap.get(name);
                            } else if (name.contains(":")) {
                                name = "Partition" + name.substring(0, 1);//No I18N
                                fileName = filesMap.get(name);
                            }
                            File test = new File(fileName);
                            float size = (float) test.length();
                            if (size < 1024) {
                                partition.put("size", Float.valueOf(String.format("%.1f", size).replace(",", ".")));
                                partition.put("sizeUnit", "Bytes");
                            } else {
                                float sizeKB = (float) size / (1024);
                                if (sizeKB < 1024) {
                                    partition.put("size", Float.valueOf(String.format("%.1f", sizeKB).replace(",", ".")));
                                    partition.put("sizeUnit", "KB");
                                } else {
                                    float sizeMB = (float) size / (1024 * 1024);
                                    if (sizeMB >= 1024) {
                                        float sizeGB = (float) sizeMB / 1024;
                                        partition.put("size", Float.valueOf(String.format("%.1f", sizeGB).replace(",", ".")));
                                        partition.put("sizeUnit", "GB");
                                    } else {
                                        partition.put("size", Float.valueOf(String.format("%.1f", sizeMB).replace(",", ".")));
                                        partition.put("sizeUnit", "MB");
                                    }
                                }
                            }
                            dcSize += (size);
                        }
                    }
                    finalSize = (float) dcSize;
                }
            } else {
                File file = new File(backupFolder);
                String[] names = file.list();
                for (String hdName : names) {
                    File hdFile = new File(backupFolder + "\\" + hdName);
                    if (hdFile.isDirectory()) {
                        String[] pNames = hdFile.list();
                        if (pNames.length > 0) {
                            for (String folderName : pNames) {
                                filesMap.put(folderName, (backupFolder + "\\" + hdName + "\\" + folderName));
                            }
                        }
                    }
                }

                for (int cnt = 0; cnt < totalPartitions; cnt++) {
                    JSONObject partition = allPartitions.getJSONObject(cnt);
                    String statusVal = partition.get("status").toString();
                    if ((statusVal.equals("Inaccessible")) || (statusVal.equals("DiskFailed"))) {
                        partition.put("size", 0f);
                        partition.put("sizeUnit", "MB");
                    } else {
                        String name = partition.get("name").toString();
                        String fileName = "";
                        if (name.startsWith("Partition")) {
                            fileName = filesMap.get(name);
                        } else if (name.contains(":")) {
                            name = "Partition" + name.substring(0, 1);//No I18N
                            fileName = filesMap.get(name);
                        }
                        float size = (float) FileUtils.sizeOfDirectory(new File(fileName));
                        if (size < 1024) {
                            partition.put("size", Float.valueOf(String.format("%.1f", size).replace(",", ".")));
                            partition.put("sizeUnit", "Bytes");
                        } else {
                            float sizeKB = (float) size / (1024);
                            if (sizeKB < 1024) {
                                partition.put("size", Float.valueOf(String.format("%.1f", sizeKB).replace(",", ".")));
                                partition.put("sizeUnit", "KB");
                            } else {
                                float sizeMB = (float) size / (1024 * 1024);
                                if (sizeMB >= 1024) {
                                    float sizeGB = (float) sizeMB / 1024;
                                    partition.put("size", Float.valueOf(String.format("%.1f", sizeGB).replace(",", ".")));
                                    partition.put("sizeUnit", "GB");
                                } else {
                                    partition.put("size", Float.valueOf(String.format("%.1f", sizeMB).replace(",", ".")));
                                    partition.put("sizeUnit", "MB");
                                }
                            }
                        }
                        dcSize += (size);
                    }
                }
                finalSize = (float) dcSize;
            }

            status = "Completed"; //No I18N
            for (int cnt = 0; cnt < totalPartitions; cnt++) {
                JSONObject partition = allPartitions.getJSONObject(cnt);
                String statusVal = partition.get("status").toString();
                if ((statusVal.equals("Inaccessible")) || (statusVal.equals("Failed")) || (statusVal.equals("DiskFailed"))) {
                    status = "Failed"; //No I18N
                    break;
                }
            }
            details.put("status", status);
            details.put("finalSize", Float.toString(finalSize));
            details.put("totalTime", totalTime.toString());
            details.put("allPartitions", allPartitions.toString());
            inp.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    public static String triggerBackupAndUpdateStatus(String finalUserName, String dcName, String domainName, String domainUser, String domainPwd, String backupFolder, String name, String pwd, String code, String filesList, int isEncrypted, String secretKey) {
        String status = "Started";//NO I18N
        Properties rpcResult = RMPNativeManager.triggerBackup("\\\\" + dcName, domainName, domainUser, domainPwd, backupFolder, name, pwd, code, filesList, isEncrypted, secretKey);

        if (rpcResult.get("CantAccess") != null) {
            int rpcRetVal = (int) rpcResult.get("CantAccess");
            LogWriter.bmr.severe("RPC call (triggerBackup) failed with error: " + rpcRetVal);//NO I18N
            if (rpcRetVal == 5) {
                status = "Failed (Access Denied)";//NO I18N
            } else {
                LogWriter.bmr.info("Agent not running. Executing RestartService.bat to attempt restart");//NO I18N
                int res = WindowsHandler.executeCommand(dcName, finalUserName, "*", "C:\\Program Files\\ManageEngine\\RMP\\RestartService.bat", true);//No I18N

                if (res == 16) {
                    rpcResult = RMPNativeManager.triggerBackup("\\\\" + dcName, domainName, domainUser, domainPwd, backupFolder, name, pwd, code, filesList, isEncrypted, secretKey);
                } else {
                    LogWriter.bmr.severe("Calling RestartService.bat: Remcom failed with error code: " + res);//NO I18N
                }

                if (rpcResult.get("CantAccess") != null) {
                    int rpcVal = (int) rpcResult.get("CantAccess");
                    LogWriter.bmr.severe("RPC call (triggerBackup) failed with error: " + rpcVal);//NO I18N
                    if (rpcVal == 5) {
                        status = "Failed (Access Denied)";//NO I18N
                    } else {
                        status = "Failed (Could not contact Agent)";//NO I18N
                    }
                }
            }
        }

        if (status.equals("Started")) {
            if (rpcResult.get("ReturnVal") != null) {
                int rpcVal = (int) rpcResult.get("ReturnVal");
                LogWriter.bmr.info("RPC call (triggerBackup) returned :" + rpcVal);//NO I18N
                if (rpcVal == 123) {
                    status = "Failed (Partition count is different)";//NO I18N
                } else if (rpcVal == 345) {
                    status = "Failed (Perform a full backup)";//NO I18N
                } else if (rpcVal == 456) {
                    status = "Failed (Volume(s) not found)";//NO I18N
                } else if (rpcVal == 53) {
                    status = "Failed (Location inaccessible from Server)";//NO I18N
                } else if (rpcVal == 112) {
                    status = "Failed (Insufficient space in storage)";//NO I18N
                } else if (rpcVal == 3) {
                    status = "Failed (Error in tracking changes)";//NO I18N
                } else if (rpcVal == 1326 || rpcVal == 86) {
                    status = "Failed (Access denied to the repository)";//NO I18N
                } else if (rpcVal != 0) {
                    status = "Failed";//NO I18N
                }
            }
        }

        return status;
    }

    public static void storeLocationDetails(JSONObject obj) {
        try {
            String location = URLDecoder.decode(GeneralUtil.replaceChar(obj, "loc"), "utf-8");//No I18N
            String userName = URLDecoder.decode(GeneralUtil.replaceChar(obj, "user"), "utf-8");//No I18N
            String password = URLDecoder.decode(GeneralUtil.replaceChar(obj, "pwd"), "utf-8");//No I18N

            DataObject dataobj = CommonUtil.getPersistence().constructDataObject();
            Row storagerow = new Row(TableName.BMR_BACKUP_STORAGE);
            storagerow.set("LOCATION", location);// No I18N
            storagerow.set("USER_NAME", userName);// No I18N
            storagerow.set("PASSWORD", password);// No I18N
            dataobj.addRow(storagerow);
            CommonUtil.getPersistence().add(dataobj);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static JSONObject getAllBmrRestoreDetails(int rangeStart, int limit, Criteria crit) {
        JSONObject restoreDetail = new JSONObject();
        JSONArray restoreList = new JSONArray();
        try {
            SimpleDateFormat timestampFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");// No I18N
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy_HH.mm.ss"); //No I18N
            SelectQueryImpl sqi = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS));
            sqi.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "DC_ID"));
            sqi.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "START_TIME"));
            sqi.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "TIME_TAKEN"));
            sqi.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "STATUS"));
            sqi.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "OPERATION_ID"));
            sqi.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "FILES_TO_RESTORE"));
            sqi.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "RESTORE_TYPE"));
            sqi.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "BACKUP_TIME"));
            sqi.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "BACKUP_POINT"));
            SortColumn sortcol = new SortColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "START_TIME", "START_TIME"), false);// No I18N
            sqi.addSortColumn(sortcol);
            sqi.setRange(new Range(rangeStart, limit));
            CustomViewRequest cvRequest = new CustomViewRequest(sqi);
            CustomViewManager cvManager = (CustomViewManager) BeanUtil.lookup("TableViewManager");// No I18N
            ViewData viewData = cvManager.getData(cvRequest);
            CVTableModel model = (CVTableModel) viewData.getModel();
            SimpleDateFormat timeformat = new SimpleDateFormat("MMM-dd-yyyy HH:mm:ss");// No I18N
            int rowcount = model.getRowCount();
            for (int len = 0; len < rowcount; len++) {
                JSONObject restoreDetails = new JSONObject();
                Long dcId = (Long) model.getValueAt(len, 0);
                restoreDetails.put("dcId", dcId);
                restoreDetails.put("MACHINE_NAME", getNameFromId(dcId));
                restoreDetails.put("MACHINE_TYPE", getObjectTypeFromId(dcId));
                String domainName = BMRDatabase.getDomainNamefromDcId(dcId);
                restoreDetails.put("DOMAIN", domainName);
                String time = timestampFormat.format((Timestamp) model.getValueAt(len, 1));
                String timeFolder = dateFormat.format((Timestamp) model.getValueAt(len, 1));
                String backupTime = timestampFormat.format((Timestamp) model.getValueAt(len, 7));
                restoreDetails.put("START_TIME", time);
                restoreDetails.put("FOLDER_TIME", timeFolder);
                restoreDetails.put("TIME_TAKEN", model.getValueAt(len, 2));
                restoreDetails.put("RESTORE_STATUS", model.getValueAt(len, 3).toString());
                restoreDetails.put("RESTORE_ID", model.getValueAt(len, 4));
                restoreDetails.put("RESTORE_TYPE", model.getValueAt(len, 6));
                restoreDetails.put("BACKUP_TIME", backupTime);
                restoreDetails.put("FILE_STATUS", model.getValueAt(len, 5).toString());
                restoreDetails.put("BACKUP_OPID", model.getValueAt(len, 8));
                restoreList.put(restoreDetails);
            }
            restoreDetail.put("isSuccess", true);
            restoreDetail.put("restoreList", restoreList);
            restoreDetail.put("restoreCount", model.getTotalRecordsCount());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return restoreDetail;
    }

    public static JSONArray getAllBmrRestoredFilesStatus(long restoreId) {
        try {
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "OPERATION_ID"), restoreId, QueryConstants.EQUAL);
            DataObject dataObject = CommonUtil.getPersistence().get(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, criteria);
            if (!dataObject.isEmpty()) {
                Row row = dataObject.getFirstRow(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS);
                JSONArray fileStatus = new JSONArray((String) row.get("FILES_TO_RESTORE"));
                return fileStatus;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static JSONObject bmrDeleteBackupRepository(Long repositoryId) {
        JSONObject status = new JSONObject();

        try {
            boolean isLocal = false;
            UpdateQuery query = new UpdateQueryImpl(TableName.RMP_STORAGE_REPOSITORY);
            Criteria idCriteria = new Criteria(Column.getColumn(TableName.RMP_STORAGE_REPOSITORY, "REPOSITORY_ID"), repositoryId, QueryConstants.EQUAL);
            query.setCriteria(idCriteria);
            query.setUpdateColumn("IS_DELETED", true);//No I18N
            query.setUpdateColumn("REPOSITORY_STATUS", "Deleted");//No I18N
            if (!isLocal) {
                query.setUpdateColumn("AGENT_PUSHED", "false;-");//No I18N
            }
            CommonUtil.getPersistence().update(query);
            status.put("isSuccess", true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    public static JSONObject validatePath(String path, String guestUserName, String guestPassword, boolean isLocal) {
        JSONObject ret = new JSONObject();
        String retVal = "";
        try {
            if (isLocal) {
                File file = new File(path);
                if (file.exists()) {
                    if (file.isFile()) {
                        retVal = "The path entered is of a file";//No I18N
                    } else if (file.isDirectory()) {
                        Date tempDate = new Date();
                        Long currentmillis = tempDate.getTime();
                        File testFile = new File(path + "\\TestFile" + currentmillis + ".txt");
                        try {
                            if (!testFile.exists()) {
                                if (testFile.createNewFile() && testFile.delete()) {
                                    LogWriter.bmr.info("User has both modify and write access to the folder.");// No I18N
                                } else {
                                    throw new Exception();
                                }
                            } else if (testFile.delete()) {
                                if (testFile.createNewFile() && testFile.delete()) {
                                    LogWriter.bmr.info("User has both modify and write access to the folder.");// No I18N
                                } else {
                                    throw new Exception();
                                }
                            } else {
                                throw new Exception();
                            }
                            retVal = "Success";//No I18N
                        } catch (Exception e) {
                            LogWriter.bmr.severe("Error : The user doesn't have write or modify access on the specified folder");// No I18N
                            retVal = "The user doesn't have write or modify access on the specified folder.";// No I18N
                            //return status;
                        }
                    }
                } else if (file.mkdirs()) {
                    Date tempDate = new Date();
                    Long currentmillis = tempDate.getTime();
                    File testFile = new File(path + "\\TestFile" + currentmillis + ".txt");
                    try {
                        if (!testFile.exists()) {
                            if (testFile.createNewFile() && testFile.delete()) {
                                LogWriter.bmr.info("User has both modify and write access to the folder.");// No I18N
                            } else {
                                throw new Exception();
                            }
                        } else if (testFile.delete()) {
                            if (testFile.createNewFile() && testFile.delete()) {
                                LogWriter.bmr.info("User has both modify and write access to the folder.");// No I18N
                            } else {
                                throw new Exception();
                            }
                        } else {
                            throw new Exception();
                        }
                        retVal = "Success";//No I18N
                    } catch (Exception e) {
                        LogWriter.bmr.severe("Error : The user doesn't have write or modify access on the specified folder");// No I18N
                        retVal = "The user doesn't have write or modify access on the specified folder.";// No I18N
                    }
                } else {
                    retVal = "Enter a valid path";// No I18N
                }
            } else {
                String errorMessage = "";
                JSONObject connectStatus = VMRepositoryServer.validateBackupRepository(path, guestUserName, guestPassword, false);
                if (connectStatus.get("retVal").toString().equalsIgnoreCase("Success")) {
                    retVal = "Success";//No I18N
                } else {
                    errorMessage = connectStatus.getString("retVal");
                    retVal = errorMessage;
                }
            }
            ret.put("retVal", retVal);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    public static String getDomainNamefromDcId(long dcId) {
        String domain = null;
        try {

            Criteria idCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcId, QueryConstants.EQUAL);
            DataObject dataObject = CommonUtil.getPersistence().get(TableName.BMR_DOMAIN_CONTROLLERS, idCriteria);
            if (!dataObject.isEmpty()) {
                Iterator iterator = dataObject.getRows(TableName.BMR_DOMAIN_CONTROLLERS);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    Long domainId = (Long) row.get("DOMAIN_ID");
                    Properties domainDetails = RMPDomainHandler.getDomainDetailsById(domainId);
                    domain = (String) domainDetails.get("DOMAIN_NAME");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return domain;
    }

    public static int getPrevBackupDiskCnt(long backupId) {
        int diskCnt = -1;
        String status = "Completed";//NO I18N
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), backupId, QueryConstants.EQUAL);
            Criteria statusCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "STATUS"), status, QueryConstants.EQUAL);
            query.setCriteria(statusCriteria.and(dcCriteria));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", false));//NO I18N

            DataObject dobj = CommonUtil.getPersistence().get(query);

            if (!dobj.isEmpty()) {
                Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                JSONArray partitionsInfo = new JSONArray(row.get("PARTITIONS_INFO").toString());
                JSONObject jsObject = (JSONObject) partitionsInfo.get(0);
                if (jsObject.has("diskCnt")) {
                    diskCnt = Integer.parseInt(jsObject.get("diskCnt").toString());
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return diskCnt;
    }

    public static synchronized void addDCDetailstoBMR(Properties prop, Long domainId) {
        try {
            boolean dcResult = false;
            DataObject obj = CommonUtil.getPersistence().constructDataObject();
            String user = null, password = null, dcName = null, userDomain = null;
            String domain = (String) prop.getProperty("DOMAIN_NAME");
            String authenticationRequired = prop.getProperty("IS_AUTHENTICATION_REQUIRED");
            if (authenticationRequired != null && authenticationRequired.equalsIgnoreCase("true")) {
                userDomain = (String) prop.getProperty("USER_DOMAIN_NAME");
                user = (String) prop.getProperty("USER_NAME");
                password = (String) prop.getProperty("PASSWORD");
                ArrayList dcList = (ArrayList) prop.get("DOMAIN_CONTROLLER_LIST");
                dcName = (String) dcList.get(0);
            }
            ArrayList allDCList = RMPNativeManager.getAllDCs(domain, userDomain, user, password, dcName);

            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            for (int i = 0; i < allDCList.size(); i++) {
                Properties dcProps = (Properties) allDCList.get(i);
                String newDc = dcProps.getProperty("NETBIOS_NAME").toLowerCase();
                String dnsName = dcProps.getProperty("DNSHOST_NAME").toLowerCase();
                String guid = dcProps.getProperty("GUID");

                Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "GUID"), guid, QueryConstants.EQUAL);
                dcResult = RMPCommonUtil.isTableEmpty(TableName.BMR_DOMAIN_CONTROLLERS, domainCriteria.and(dcCriteria), new String[]{"DC_ID"});//No I18N

                LicenseType licenseType = LicenseType.Unlicensed;
                if (LicenseUtil.hasComponent(LicenseUtil.ADOBJECTS_COMPONENT) && ProductSubscriptionInfo.subscribedObjectCt != 0) {
                    licenseType = LicenseType.NotRequired;
                }

                if (dcResult) {
                    Row row = new Row(TableName.BMR_DOMAIN_CONTROLLERS);
                    row.set("DOMAIN_ID", domainId);  //No I18N
                    row.set("DC_NAME", newDc);//No I18N
                    row.set("DC_DNS_NAME", dnsName);//No I18N
                    row.set("GUID", guid);//No I18N
                    row.set("IS_DELETED", false);//No I18N
                    row.set("OBJECT_TYPE", "DC");//No I18N
                    row.set("IS_LICENSED", licenseType.ordinal());//No I18N
                    obj.addRow(row);
                }
            }

            ArrayList allServerList = BMRDatabase.getAllMachinesFiltered(domain, userDomain, user, password, dcName);

            for (int i = 0; i < allServerList.size(); i++) {
                Properties serverProps = (Properties) allServerList.get(i);
                String serverGuid = serverProps.getProperty("objectGUID");
                Criteria serverCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "GUID"), serverGuid, QueryConstants.EQUAL);
                dcResult = RMPCommonUtil.isTableEmpty(TableName.BMR_DOMAIN_CONTROLLERS, domainCriteria.and(serverCriteria), new String[]{"DC_ID"});//No I18N
                if (dcResult && serverProps.getProperty("machineType").equalsIgnoreCase("SERVER")) {
                    LicenseType licenseType = LicenseType.Unlicensed;
                    Row row = new Row(TableName.BMR_DOMAIN_CONTROLLERS);
                    row.set("DOMAIN_ID", domainId);  //No I18N
                    row.set("DC_NAME", serverProps.getProperty("cn"));//No I18N
                    row.set("DC_DNS_NAME", serverProps.getProperty("dNSHostName"));//No I18N
                    row.set("GUID", serverProps.getProperty("objectGUID"));//No I18N
                    row.set("IS_DELETED", false);//No I18N
                    row.set("OBJECT_TYPE", "SERVER");//No I18N
                    row.set("IS_LICENSED", licenseType.ordinal());//No I18N
                    obj.addRow(row);
                }
            }

            if (!obj.isEmpty()) {
                CommonUtil.getPersistence().add(obj);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ArrayList getAllMachinesFiltered(String domain, String userDomain, String user, String password, String dcName) {
        ArrayList retArr = new ArrayList();

        try {
            ArrayList allDCList = RMPNativeManager.getAllDCs(domain, userDomain, user, password, dcName);

            for (int i = 0; i < allDCList.size(); i++) {
                Properties retProps = new Properties();
                Properties dcProps = (Properties) allDCList.get(i);
                String newDc = dcProps.getProperty("NETBIOS_NAME").toLowerCase();
                String dnsName = dcProps.getProperty("DNSHOST_NAME").toLowerCase();
                String guid = dcProps.getProperty("GUID");
                retProps.put("cn", newDc);
                retProps.put("dNSHostName", dnsName);
                retProps.put("objectGUID", guid);
                retProps.put("machineType", "DC");
                retArr.add(retProps);
            }
            String networkUserName = userDomain + "\\" + user;
            ArrayList allServerList = RMPNativeManager.getAllServers(domain, networkUserName, password, dcName);

            for (int i = 0; i < allServerList.size(); i++) {
                try {
                    Properties serverProps = (Properties) allServerList.get(i);
                    Properties retProps = new Properties();
                    String newServerCn = serverProps.getProperty("cn").toLowerCase();
                    String operatingSystemVersion = "-";
                    String mainVersion = "-";

                    if (serverProps.containsKey("operatingSystemVersion")) {
                        operatingSystemVersion = serverProps.getProperty("operatingSystemVersion");
                        mainVersion = (operatingSystemVersion.contains("(")) ? operatingSystemVersion.substring(0, operatingSystemVersion.indexOf("(") - 1) : operatingSystemVersion;
                    }

                    if (!mainVersion.equalsIgnoreCase("-")) {
                        if (Float.parseFloat(mainVersion) >= 6.0) {
                            String serverDnsName = "-";
                            if (serverProps.containsKey("dNSHostName")) {
                                serverDnsName = serverProps.getProperty("dNSHostName").toLowerCase();
                            }

                            String serverGuid = serverProps.getProperty("objectGUID");
                            retProps.put("cn", newServerCn);
                            retProps.put("dNSHostName", serverDnsName);
                            retProps.put("objectGUID", serverGuid);
                            retProps.put("machineType", "SERVER");
                            retArr.add(retProps);
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return retArr;
    }

    public static void updateDCTable(Properties prop, Long domainId) {
        try {
            String user = null, password = null, dcName = null, userDomain = null;
            String domain = (String) prop.getProperty("DOMAIN_NAME");
            String authenticationRequired = prop.getProperty("IS_AUTHENTICATION_REQUIRED");
            if (authenticationRequired != null && authenticationRequired.equalsIgnoreCase("true")) {
                user = (String) prop.getProperty("USER_NAME");
                userDomain = (String) prop.getProperty("USER_DOMAIN_NAME");
                password = (String) prop.getProperty("PASSWORD");
                ArrayList dcList = (ArrayList) prop.get("DOMAIN_CONTROLLER_LIST");
                dcName = (String) dcList.get(0);
            }
            ArrayList allDCList = RMPNativeManager.getAllDCs(domain, userDomain, user, password, dcName);
            for (int i = 0; i < allDCList.size(); i++) {
                Properties dcProps = (Properties) allDCList.get(i);
                String newDc = dcProps.getProperty("NETBIOS_NAME").toLowerCase();
                String dnsName = dcProps.getProperty("DNSHOST_NAME").toLowerCase();
                String guid = dcProps.getProperty("GUID");
                Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_NAME"), newDc, QueryConstants.EQUAL);
                UpdateQuery query = new UpdateQueryImpl(TableName.BMR_DOMAIN_CONTROLLERS);
                query.setUpdateColumn("DC_DNS_NAME", dnsName); //No I18N
                query.setUpdateColumn("GUID", guid); //No I18N
                query.setCriteria(domainCriteria.and(dcCriteria));
                CommonUtil.getPersistence().update(query);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateServersForExistingDomains() {
        ArrayList<Properties> domainDetails = RMPDomainHandler.getRMPDomainDetails();

        try {

            for (Properties prop : domainDetails) {
                long domainId = Long.parseLong(prop.getProperty("DOMAIN_ID"));
                DataObject obj = CommonUtil.getPersistence().constructDataObject();
                String user = null, password = null, dcName = null, userDomain = null;
                String domain = (String) prop.getProperty("DOMAIN_NAME");
                String authenticationRequired = prop.getProperty("IS_AUTHENTICATION_REQUIRED");

                if (authenticationRequired != null && authenticationRequired.equalsIgnoreCase("true")) {
                    user = (String) prop.getProperty("USER_NAME");
                    userDomain = (String) prop.getProperty("USER_DOMAIN_NAME");
                    password = (String) prop.getProperty("PASSWORD");
                    ArrayList dcList = (ArrayList) prop.get("DOMAIN_CONTROLLER_LIST");
                    dcName = (String) dcList.get(0);
                }

                ArrayList allServerList = BMRDatabase.getAllMachinesFiltered(domain,userDomain, user, password, dcName);
                ArrayList<Long> dcIDs = new ArrayList<Long>();

                LicenseType licenseType = LicenseType.Unlicensed;

                for (int i = 0; i < allServerList.size(); i++) {
                    Properties serverProps = (Properties) allServerList.get(i);

                    if (serverProps.getProperty("machineType").equalsIgnoreCase("SERVER")) {
                        Row row = new Row(TableName.BMR_DOMAIN_CONTROLLERS);
                        DataAccess.generateValues(row);
                        row.set("DOMAIN_ID", domainId);  //No I18N
                        row.set("DC_NAME", serverProps.getProperty("cn"));//No I18N
                        row.set("DC_DNS_NAME", serverProps.getProperty("dNSHostName"));//No I18N
                        row.set("GUID", serverProps.getProperty("objectGUID"));//No I18N
                        row.set("IS_DELETED", false);//No I18N
                        row.set("OBJECT_TYPE", "SERVER");//No I18N
                        row.set("IS_LICENSED", licenseType.ordinal());//No I18N
                        obj.addRow(row);
                        dcIDs.add((long) row.get("DC_ID"));
                    }
                }

                if (!obj.isEmpty()) {
                    CommonUtil.getPersistence().add(obj);
                }

                Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                boolean scheduleResult = RMPCommonUtil.isTableEmpty(TableName.BMR_BACKUP_SCHEDULE, criteria, new String[]{"DC_ID"});//No I18N

                if (!scheduleResult) {
                    for (int i = 0; i < dcIDs.size(); i++) {
                        BMRDatabase.setSchedule(domainId, dcIDs.get(i));
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void updateRepositoryID() {
        try {
            Properties prevLocDetails = BMRDatabase.getLocationDetails();
            String location = prevLocDetails.getProperty("Location");

            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.RMP_STORAGE_REPOSITORY));
            query.addSelectColumn(Column.getColumn(TableName.RMP_STORAGE_REPOSITORY, "*"));
            Criteria locCriteria = new Criteria(Column.getColumn(TableName.RMP_STORAGE_REPOSITORY, "REPOSITORY_PATH"), location, QueryConstants.EQUAL);
            query.setCriteria(locCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);

            if (!dobj.isEmpty()) {
                Row row = dobj.getFirstRow(TableName.RMP_STORAGE_REPOSITORY);
                long repoId = (long) row.get("REPOSITORY_ID");

                Criteria backupCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "STATUS"), "Backup not configured", QueryConstants.NOT_EQUAL);
                Criteria nullCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "REPOSITORY_ID"), null, QueryConstants.EQUAL);
                UpdateQuery updateQuery = new UpdateQueryImpl(TableName.BMR_BACKUP_SCHEDULE);
                updateQuery.setCriteria(backupCriteria.and(nullCriteria));
                updateQuery.setUpdateColumn("REPOSITORY_ID", repoId); //No I18N
                CommonUtil.getPersistence().update(updateQuery);

                Criteria nullIdCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "REPOSITORY_ID"), null, QueryConstants.EQUAL);
                Criteria idCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "REPOSITORY_ID"), 0L, QueryConstants.EQUAL);
                UpdateQuery updateQry = new UpdateQueryImpl(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                updateQuery.setCriteria(nullIdCriteria.or(idCriteria));
                updateQry.setUpdateColumn("REPOSITORY_ID", repoId); //No I18N
                CommonUtil.getPersistence().update(updateQry);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static JSONArray getStoredFiles(Criteria criteria, String ipAddr) {
        JSONArray dataArray = new JSONArray();
        JSONArray returnArr = new JSONArray();

        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            query.setCriteria(criteria);

            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);

                if (row.get("FILES_TO_BACKUP") != null && (((String) row.get("FILES_TO_BACKUP")).length() != 0)) {
                    dataArray = new JSONArray((String) row.get("FILES_TO_BACKUP"));
                }
            }

            for (int i = 0; i < dataArray.length(); i++) {
                JSONObject jsObject = (JSONObject) dataArray.get(i);
                String depth = (jsObject.get("depth")).toString();
                String folderId = (jsObject.get("folderId")).toString();
                String folderName = (String) (jsObject.get("folderName"));
                String folderPath = (String) (jsObject.get("folderPath"));
                String folderUncPath = (String) (jsObject.get("folderUncPath"));
                String folderDir = (jsObject.get("folderDir")).toString();

                folderPath = "smb://" + ipAddr + "/" + folderPath;//No I18N
                folderUncPath = "\\\\" + ipAddr + folderUncPath;//No I18N

                JSONObject fileObtained = new JSONObject();
                fileObtained.put("depth", depth);
                fileObtained.put("folderId", folderId);
                fileObtained.put("folderName", folderName);
                fileObtained.put("folderPath", folderPath);
                fileObtained.put("folderUncPath", folderUncPath);
                fileObtained.put("folderDir", folderDir);

                returnArr.put(fileObtained);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return returnArr;
    }

    public static boolean storeSelectedFiles(JSONObject inputJSONObject) {
        boolean isSuccess = false;

        try {
            // JSONArray inputArray = (JSONArray) inputJSONObject.getJSONArray("arr");// No I18N
            String filesStr = URLDecoder.decode(GeneralUtil.replaceChar(inputJSONObject, "arr"), "UTF-8");// No I18N
            JSONArray inputArray = new JSONArray(filesStr); // (JSONArray) inputJSONObject.get("filesToRestore");

            for (int i = 0; i < inputArray.length(); i++) {
                JSONObject deviceObject = (JSONObject) inputArray.get(i);
                String dcName = (deviceObject.get("device")).toString();
                long dcId = Long.parseLong(deviceObject.get("dcId").toString());
                JSONArray folderArray = (JSONArray) deviceObject.getJSONArray("folders");// No I18N
                JSONArray newFolderArray = removeDeviceName(folderArray);
                Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
                UpdateQuery upquery = new UpdateQueryImpl(TableName.BMR_BACKUP_SCHEDULE);
                upquery.setUpdateColumn("FILES_TO_BACKUP", newFolderArray.toString()); //No I18N
                upquery.setCriteria(criteria);
                CommonUtil.getPersistence().update(upquery);
            }

            isSuccess = true;
        } catch (Exception ex) {
            ex.printStackTrace();
            isSuccess = false;
        }

        return isSuccess;
    }

    public static JSONArray removeDeviceName(JSONArray folderArray) {
        String str = folderArray.toString();
        JSONArray arr = new JSONArray();
        try {
            if (folderArray.length() > 0) {
                String folderPath = (((JSONObject) folderArray.get(0)).get("folderUncPath")).toString();
                String smbFolderPath = (((JSONObject) folderArray.get(0)).get("folderPath")).toString();
                String ipAddr = folderPath.substring(0, folderPath.indexOf("\\", 2)) + "\\\\";
                String smbIp = smbFolderPath.substring(0, smbFolderPath.indexOf("/", 6) + 1);
                String returnArr = str.replaceAll(java.util.regex.Pattern.quote(ipAddr), "");
                returnArr = returnArr.replaceAll(java.util.regex.Pattern.quote(smbIp), "");
                arr = new JSONArray(returnArr);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return arr;
    }

    public static void storeConfiguredDomainDetails(String domainName) {
        try {
            DataObject obj = CommonUtil.getPersistence().constructDataObject();
            Row storagerow = new Row(TableName.BMR_DOMAIN_DETAILS);
            storagerow.set("DOMAIN_NAME", domainName);// No I18N
            storagerow.set("IS_BACKUP_DONE", false);// No I18N
            obj.addRow(storagerow);
            CommonUtil.getPersistence().add(obj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void storeTotalBackupDetails(JSONObject inputJSONObject) {
        try {
            JSONArray dcArray = (JSONArray) inputJSONObject.getJSONArray("dc");// No I18N
            String domainName = (String) inputJSONObject.get("domain");
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domainName).getProperty("DOMAIN_ID"));
            DataObject obj = CommonUtil.getPersistence().constructDataObject();
            for (int i = 0; i < dcArray.length(); i++) {
                JSONObject jsObject = (JSONObject) dcArray.get(i);
                String dcName = (String) (jsObject.get("dcName"));
                long backupId = Long.parseLong(jsObject.get("dcId").toString());
                Row storagerow = new Row(TableName.BMR_TOTAL_BACKUP_DETAILS);
                storagerow.set("DOMAIN_ID", domainId);// No I18N
                storagerow.set("DC_ID", backupId);// No I18N
                storagerow.set("FB_COUNT", 0);// No I18N
                storagerow.set("IB_COUNT", 0);// No I18N
                storagerow.set("SIZE", 0f);// No I18N
                obj.addRow(storagerow);
            }
            CommonUtil.getPersistence().add(obj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void createSchedule(JSONObject inputJSONObject, Criteria criteria) {
        try {
            String fbMask = (String) inputJSONObject.get("fbMask");// No I18N
            String fbDate = (String) inputJSONObject.get("fbDate");// No I18N
            String ibMask = (String) inputJSONObject.get("ibMask");// No I18N
            String ibDate = (String) inputJSONObject.get("ibDate");// No I18N
            String fbFreq = (String) inputJSONObject.get("fbFreq");
            String fbHr = (String) inputJSONObject.get("fbHr");// No I18N
            String fbMin = (String) inputJSONObject.get("fbMin");// No I18N
            String ibFreq = (String) inputJSONObject.get("ibFreq");
            String ibHr = (String) inputJSONObject.get("ibHr");// No I18N
            String ibMin = (String) inputJSONObject.get("ibMin");// No I18N
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            query.setCriteria(criteria);
            DataObject dobjFB = CommonUtil.getPersistence().get(query);
            Iterator iteratorFB = dobjFB.getRows(TableName.BMR_BACKUP_SCHEDULE);
            while (iteratorFB.hasNext()) {
                Row row = (Row) iteratorFB.next();
                long dcId = (long) row.get("DC_ID");
                String backupType = (String) row.get("BACKUP_TYPE");
                String backupFreq = null;
                if (fbFreq.equals("Monthly")) {
                    backupFreq = "0";
                } else if (fbFreq.equals("Daily")) {
                    backupFreq = "1";
                } else if (fbFreq.equals("Weekly")) {
                    backupFreq = "2";
                }
                String scheduleBackupType = "FB";// No I18N

                if (!backupType.equals("BMR")) {
                    scheduleBackupType = "flrFB";// No I18N
                }
                BMRScheduler bmrScheduler = new BMRScheduler(dcId, backupFreq, fbHr, fbMin, fbMask, fbDate, scheduleBackupType);
                bmrScheduler.updateSchedule();
            }

            boolean isIbRequired = Boolean.parseBoolean((String) inputJSONObject.get("isIbRequired"));

            if (isIbRequired) {
                DataObject dobjIB = CommonUtil.getPersistence().get(query);
                Iterator iteratorIB = dobjIB.getRows(TableName.BMR_BACKUP_SCHEDULE);
                while (iteratorIB.hasNext()) {
                    Row row = (Row) iteratorIB.next();
                    long dcId = (long) row.get("DC_ID");
                    String backupType = (String) row.get("BACKUP_TYPE");
                    String backupFreq = null;
                    if (ibFreq.equals("Monthly")) {
                        backupFreq = "0";
                    } else if (ibFreq.equals("Daily")) {
                        backupFreq = "1";
                    } else if (ibFreq.equals("Weekly")) {
                        backupFreq = "2";
                    }
                    String scheduleBackupType = "IB";// No I18N
                    if (!backupType.equals("BMR")) {
                        scheduleBackupType = "flrIB";// No I18N
                    }
                    BMRScheduler bmrScheduler = new BMRScheduler(dcId, backupFreq, ibHr, ibMin, ibMask, ibDate, scheduleBackupType);
                    bmrScheduler.updateSchedule();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void storeSchedule(JSONObject inputJSONObject) {
        try {
            JSONArray dcArray = (JSONArray) inputJSONObject.getJSONArray("dc");// No I18N
            String domainName = (String) inputJSONObject.get("domain");
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domainName).getProperty("DOMAIN_ID"));
            String status = (String) inputJSONObject.get("status");// No I18N
            String retention = (String) inputJSONObject.get("retention");// No I18N
            int repoId = Integer.parseInt((inputJSONObject.get("repositoryId").toString()));
            boolean isIbRequired = Boolean.parseBoolean((String) inputJSONObject.get("isIbRequired"));
            boolean isEncrypted = Boolean.parseBoolean((String) inputJSONObject.get("isEncrypted"));
            String encryptionPwd = "";
            if (isEncrypted) {
                encryptionPwd = URLDecoder.decode(inputJSONObject.get("secretKey").toString(), "UTF-8");// No I18N
            }
            DataObject dataobj = CommonUtil.getPersistence().constructDataObject();
            for (int i = 0; i < dcArray.length(); i++) {
                JSONObject jsObject = (JSONObject) dcArray.get(i);
                String dcName = (String) (jsObject.get("dcName"));
                long backupId = Long.parseLong(jsObject.get("dcId").toString());
                String backupType = (String) (jsObject.get("backupType"));
                Row storagerow = new Row(TableName.BMR_BACKUP_SCHEDULE);
                storagerow.set("DC_ID", backupId);// No I18N
                storagerow.set("DOMAIN_ID", domainId);// No I18N
                storagerow.set("FB_SCHEDULE_ID", 0L);// No I18N
                storagerow.set("IB_SCHEDULE_ID", 0L);// No I18N
                storagerow.set("RETENTION", retention);// No I18N
                storagerow.set("STATUS", status);// No I18N
                storagerow.set("ERROR_MSG", "");// No I18N
                storagerow.set("REPOSITORY_ID", repoId);// No I18N
                storagerow.set("IB_REQUIRED", isIbRequired);// No I18N
                storagerow.set("BACKUP_TYPE", backupType);// No I18N
                storagerow.set("IS_ENCRYPTED", isEncrypted);// No I18N
                storagerow.set("SECRETKEY", encryptionPwd);// No I18N
                dataobj.addRow(storagerow);
            }
            CommonUtil.getPersistence().add(dataobj);
            if (!(status.equals("Backup not configured"))) {
                storeConfiguredDomainDetails(domainName);
                storeTotalBackupDetails(inputJSONObject);
                Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);

                createSchedule(inputJSONObject, criteria);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setSchedule(long domainId, long backupId) {
        try {
            DataObject dataobj = CommonUtil.getPersistence().constructDataObject();
            Row storagerow = new Row(TableName.BMR_BACKUP_SCHEDULE);
            storagerow.set("DC_ID", backupId);// No I18N
            storagerow.set("DOMAIN_ID", domainId);// No I18N
            storagerow.set("FB_SCHEDULE_ID", 0L);// No I18N
            storagerow.set("IB_SCHEDULE_ID", 0L);// No I18N
            storagerow.set("RETENTION", "-");// No I18N
            storagerow.set("STATUS", "Backup not configured");// No I18N
            storagerow.set("ERROR_MSG", "");// No I18N
            storagerow.set("REPOSITORY_ID", -1);// No I18N
            storagerow.set("IB_REQUIRED", true);// No I18N
            storagerow.set("BACKUP_TYPE", "-");// No I18N
            dataobj.addRow(storagerow);
            CommonUtil.getPersistence().add(dataobj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static long getRepositoryIdFromDcId(long dcId) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
            return (long) row.get("REPOSITORY_ID");
        } catch (Exception e) {
            e.printStackTrace();
            return 0L;
        }
    }

    public static long storeIndividualBackupDetails(long backupId, String type, String status, String initiator, boolean isEncrypted, String encryptionPwd) {
        try {
            long repositoryId = getRepositoryIdFromDcId(backupId);
            String backupMode = getBackupTypeFromId(backupId);
            Date date = Calendar.getInstance().getTime();
            Timestamp startTime = DateUtil.getTimestampFromDate(date);
            DataObject dataobj = CommonUtil.getPersistence().constructDataObject();
            Row row = new Row(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
            DataAccess.generateValues(row);
            row.set("DC_ID", backupId);// No I18N
            row.set("REPOSITORY_ID", repositoryId);// No I18N
            row.set("BACKUP_TYPE", type);// No I18N
            row.set("START_TIME", startTime);// No I18N
            row.set("TIME_TAKEN", 0L);// No I18N
            row.set("INITIATOR", initiator);// No I18N
            row.set("SIZE", 0f);// No I18N
            row.set("PARTITIONS_INFO", "");// No I18N
            row.set("BACKUP_FOLDER", "-");// No I18N
            row.set("STATUS", status);// No I18N
            row.set("BACKUP_MODE", backupMode);// No I18N
            row.set("IS_MOUNTED", "-");// No I18N
            row.set("IS_ENCRYPTED", isEncrypted);// No I18N
            row.set("SECRETKEY", encryptionPwd);// No I18N
            dataobj.addRow(row);
            CommonUtil.getPersistence().add(dataobj);
            return (long) row.get("OPERATION_ID");
        } catch (Exception e) {
            e.printStackTrace();
            return 0L;
        }
    }

    public static void storeIncrementalBackupDetails(long fbId, long ibId) {
        try {
            DataObject dataobj = CommonUtil.getPersistence().constructDataObject();
            Row row = new Row(TableName.BMR_INCREMENTAL_BACKUP_DETAILS);
            row.set("FB_ID", fbId);// No I18N
            row.set("IB_ID", ibId);// No I18N
            dataobj.addRow(row);
            CommonUtil.getPersistence().add(dataobj);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isBMRConfigured(String domain) {
        boolean isBMRConfigured;
        Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_DETAILS, "DOMAIN_NAME"), domain, QueryConstants.EQUAL);
        isBMRConfigured = RMPCommonUtil.isTableEmpty(TableName.BMR_DOMAIN_DETAILS, criteria, new String[]{"UNIQUE_ID"});//No I18N
        return isBMRConfigured;
    }

    public static boolean isBMRBackupDone(String domain) {
        boolean isBMRBackupDone;
        Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_DETAILS, "DOMAIN_NAME"), domain, QueryConstants.EQUAL);
        Criteria buCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_DETAILS, "IS_BACKUP_DONE"), true, QueryConstants.EQUAL);
        isBMRBackupDone = RMPCommonUtil.isTableEmpty(TableName.BMR_DOMAIN_DETAILS, criteria.and(buCriteria), new String[]{"UNIQUE_ID"});//No I18N
        return isBMRBackupDone;
    }

    public static boolean isDCDeleted(long dcId) {
        boolean isDCDeleted = false;
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_DOMAIN_CONTROLLERS);
            isDCDeleted = (boolean) row.get("IS_DELETED");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isDCDeleted;
    }

    public static Properties currentEncryptionDetails(long dcId) {
        try {
            Properties encryptionDetails = new Properties();
            String secretKey = "";
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
            boolean isEncrypted = (boolean) row.get("IS_ENCRYPTED");
            if (isEncrypted) {
                secretKey = (String) row.get("SECRETKEY");
            }
            encryptionDetails.put("IS_ENCRYPTED", String.valueOf(isEncrypted));
            encryptionDetails.put("SECRETKEY", secretKey);
            return encryptionDetails;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Properties prevEncryptionDetails(long dcId) {
        try {
            Properties encryptionDetails = new Properties();
            String secretKey = "";
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", false));//NO I18N
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Row row = (Row) dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                boolean isEncrypted = (boolean) row.get("IS_ENCRYPTED");
                if (isEncrypted) {
                    secretKey = (String) row.get("SECRETKEY");
                }
                encryptionDetails.put("IS_ENCRYPTED", String.valueOf(isEncrypted));
                encryptionDetails.put("SECRETKEY", secretKey);
            }
            return encryptionDetails;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Properties getEncryptionDetails(long opId) {
        try {
            Properties encryptionDetails = new Properties();
            String secretKey = "";
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Row row = (Row) dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                boolean isEncrypted = (boolean) row.get("IS_ENCRYPTED");
                if (isEncrypted) {
                    secretKey = (String) row.get("SECRETKEY");
                }
                encryptionDetails.put("IS_ENCRYPTED", String.valueOf(isEncrypted));
                encryptionDetails.put("SECRETKEY", secretKey);
            }
            return encryptionDetails;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static JSONObject isRepoEnabled(long dcId) {
        boolean isEnabled = false;
        boolean isDeleted = true;
        JSONObject ret = new JSONObject();
        try {
            ret.put("isEnabled", isEnabled);
            ret.put("isDeleted", isDeleted);
            long repoId = getRepositoryIdFromDcId(dcId);
            Criteria idCriteria = new Criteria(Column.getColumn(TableName.RMP_STORAGE_REPOSITORY, "REPOSITORY_ID"), repoId, QueryConstants.EQUAL);
            DataObject dataObj = CommonUtil.getPersistence().get(TableName.RMP_STORAGE_REPOSITORY, idCriteria);
            if (!dataObj.isEmpty()) {
                Row row = (Row) dataObj.getFirstRow(TableName.RMP_STORAGE_REPOSITORY);
                isEnabled = (boolean) row.get("IS_ENABLED");
                isDeleted = (boolean) row.get("IS_DELETED");
            }
            ret.put("isEnabled", isEnabled);
            ret.put("isDeleted", isDeleted);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    public static JSONObject isRestoreRepoEnabled(Long opId) {
        boolean isEnabled = false;
        boolean isDeleted = true;
        JSONObject ret = new JSONObject();
        try {
            Long repoId = -1L;
            Criteria idCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            DataObject dataObj = CommonUtil.getPersistence().get(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, idCriteria);
            if (!dataObj.isEmpty()) {
                Row row = (Row) dataObj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                repoId = (Long) row.get("REPOSITORY_ID");
            }
            if (repoId != -1) {
                Criteria storageIdCriteria = new Criteria(Column.getColumn(TableName.RMP_STORAGE_REPOSITORY, "REPOSITORY_ID"), repoId, QueryConstants.EQUAL);
                DataObject storageDataObj = CommonUtil.getPersistence().get(TableName.RMP_STORAGE_REPOSITORY, storageIdCriteria);
                if (!storageDataObj.isEmpty()) {
                    Row storageRow = (Row) storageDataObj.getFirstRow(TableName.RMP_STORAGE_REPOSITORY);
                    isEnabled = (boolean) storageRow.get("IS_ENABLED");
                    isDeleted = (boolean) storageRow.get("IS_DELETED");
                }
            }
            ret.put("isEnabled", isEnabled);
            ret.put("isDeleted", isDeleted);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    public static synchronized JSONObject isCompleted(String dcName, long backupId, String type, String initiator, boolean isEncrypted, String encryptionPwd, String module) {
        JSONObject retObj = new JSONObject();
        String isBackupCompleted = "";
        String isRestoreCompleted = "";
        String restoreType = "";
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), backupId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", false));//NO I18N
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Row domain = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                isBackupCompleted = domain.get("STATUS").toString();
                JSONObject restoreResult = BMRDatabase.isRestoreCompleted(backupId);
                restoreType = (String) restoreResult.get("restoreType");
                if (restoreType.equals("VLR")) {
                    isRestoreCompleted = (String) restoreResult.get("result");
                }
                if ((module.equals("backup")) && (!(isBackupCompleted.equals("Started") || isBackupCompleted.equals("In Progress (But failed to delete old backups)") || isBackupCompleted.equals("Application Interrupted") || isBackupCompleted.equals("In Progress") || isRestoreCompleted.equals("Application Interrupted") || isRestoreCompleted.equals("Started") || isRestoreCompleted.equals("In Progress")))) {
                    storeIndividualBackupDetails(backupId, type, "Started", initiator, isEncrypted, encryptionPwd);//NO I18N
                }
            } else {
                if (module.equals("backup")) {
                    storeIndividualBackupDetails(backupId, type, "Started", initiator, isEncrypted, encryptionPwd);//NO I18N
                }
            }
            retObj.put("result", isBackupCompleted);
            retObj.put("restoreResult", isRestoreCompleted);
            retObj.put("restoreType", restoreType);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return retObj;
    }

    public static JSONObject isRestoreCompleted(long backupId) {
        JSONObject result = new JSONObject();
        String isCompleted = "";
        String restoreType = "";
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "DC_ID"), backupId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "*"));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "START_TIME", false));//NO I18N
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Row domain = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS);
                isCompleted = domain.get("STATUS").toString();
                restoreType = domain.get("RESTORE_TYPE").toString();
            }
            result.put("result", isCompleted);
            result.put("restoreType", restoreType);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


    public static void updateBackupStatus(long backupId, String status) {
        try {
            long opId = getLatestBackupId(backupId);
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            UpdateQuery query = new UpdateQueryImpl(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
            query.setUpdateColumn("STATUS", status); //No I18N
            query.setCriteria(criteria);
            CommonUtil.getPersistence().update(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateBackupLocation(long backupId, String location) {
        try {
            long opId = getLatestBackupId(backupId);
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            UpdateQuery query = new UpdateQueryImpl(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
            query.setUpdateColumn("BACKUP_FOLDER", location); //No I18N
            query.setCriteria(criteria);
            CommonUtil.getPersistence().update(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateLocationDetails(JSONObject obj) {
        try {
            String location = URLDecoder.decode(GeneralUtil.replaceChar(obj, "loc"), "utf-8");//No I18N
            String userName = URLDecoder.decode(GeneralUtil.replaceChar(obj, "user"), "utf-8");//No I18N
            String password = URLDecoder.decode(GeneralUtil.replaceChar(obj, "pwd"), "utf-8");//No I18N
            UpdateQuery query = new UpdateQueryImpl(TableName.BMR_BACKUP_STORAGE);
            query.setUpdateColumn("LOCATION", location); //No I18N
            query.setUpdateColumn("USER_NAME", userName); //No I18N
            query.setUpdateColumn("PASSWORD", password); //No I18N
            CommonUtil.getPersistence().update(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean pauseOrResumeSchedule(JSONObject obj) {
        try {
            String dcName = (String) obj.get("dc");
            boolean value = (boolean) obj.getBoolean("value");//No I18N
            long dcId = Long.parseLong(obj.get("dcId").toString());
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
            long fbScheduleId = (long) row.get("FB_SCHEDULE_ID");
            long ibScheduleId = (long) row.get("IB_SCHEDULE_ID");
            if (value) {
                BMRScheduler.disableSchedule(fbScheduleId);
                BMRScheduler.disableSchedule(ibScheduleId);
            } else {
                if (getLicenseType(dcId) == LicenseType.Unlicensed) {
                    return false;
                }
                BMRScheduler.enableSchedule(fbScheduleId);
                BMRScheduler.enableSchedule(ibScheduleId);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static JSONObject updateRepositoryUsedSpace(Long repositoryId) {
        JSONObject status = new JSONObject();
        try {
            JSONObject repoDetails = VMRepositoryServer.getBackupRepository(repositoryId).getJSONObject("selectedValue");
            Boolean isLocal = !(repoDetails.get("REPOSITORY_PATH").toString().startsWith("\\"));
            JSONObject isSuccess = VMRepositoryServer.validateBackupRepository(repoDetails.get("REPOSITORY_PATH").toString(), repoDetails.get("REPOSITORY_USERNAME").toString(), repoDetails.get("REPOSITORY_PASSWORD").toString(), isLocal);
            UpdateQuery query = new UpdateQueryImpl(TableName.RMP_STORAGE_REPOSITORY);
            Criteria idCriteria = new Criteria(Column.getColumn(TableName.RMP_STORAGE_REPOSITORY, "REPOSITORY_ID"), repositoryId, QueryConstants.EQUAL);
            query.setCriteria(idCriteria);
            if (isSuccess.get("retVal").toString().equals("Success")) {
                String freeSpace = Integer.parseInt(isSuccess.get("freespace").toString()) + " GB";//No I18N
                String capacity = Integer.parseInt(isSuccess.get("capacity").toString()) + " GB";//No I18N
                Long backupSize = Long.parseLong(isSuccess.get("backupSize").toString());

                //bug fix for negative repository size pick up whichever is less
                Long backupSizeDb = getBackupSizeOfRepository(repositoryId);
                backupSize = backupSize < backupSizeDb ? backupSize : backupSizeDb;

                query.setUpdateColumn("REPOSITORY_CAPACITY", capacity);//No I18N
                query.setUpdateColumn("REPOSITORY_FREE_SPACE", freeSpace);//No I18N
                query.setUpdateColumn("BACKUP_SIZE", backupSize);//No I18N

                status.put("isSuccess", true);
                VMRepositoryServer.updateStatus(repositoryId, "Connected");//No I18N
            } else {
                status.put("isSuccess", false);
                VMRepositoryServer.updateStatus(repositoryId, isSuccess.get("retVal").toString());
            }
            CommonUtil.getPersistence().update(query);
        } catch (Exception e) {
            LogWriter.virtual.severe("Exception Stack Trace : " + LogWriter.getStackTrace(e));// No I18N
        }
        return status;
    }

    public static JSONObject getActiveBMRBackupCount(String domain) {
        try {
            JSONObject returnObject = new JSONObject();
            Set<Long> dcSet = new HashSet<>();
            Properties details = RMPDomainHandler.getDomainDetailsByName(domain);
            long domainId = Long.valueOf(details.getProperty("DOMAIN_ID"));
            Criteria domIdCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            DataObject dataObj = CommonUtil.getPersistence().get(TableName.BMR_BACKUP_SCHEDULE, (domIdCriteria));
            Iterator iter = dataObj.getRows(TableName.BMR_BACKUP_SCHEDULE);
            while (iter.hasNext()) {
                Row rows = (Row) iter.next();
                Long dcId = (Long) rows.get("DC_ID");
                dcSet.add(dcId);
            }
            Criteria dcIdCrit = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), dcSet.toArray(), QueryConstants.IN);

            DataObject dataObject = CommonUtil.getPersistence().get(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, dcIdCrit);
            Iterator rowCounter = dataObject.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);

            long activeBackupCount = 0L;
            long inactiveBackupCount = 0L;

            while (rowCounter.hasNext()) {
                Row row = (Row) rowCounter.next();
                String status = row.get("STATUS").toString();
                if (status.equals("Started")) {
                    activeBackupCount++;
                } else {
                    inactiveBackupCount++;
                }
            }
            returnObject.put("active", activeBackupCount);
            returnObject.put("inactive", inactiveBackupCount);
            return returnObject;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Long getBackupSizeOfRepository(Long repositoryId) {
        Long totalSize = 0L;
        try {
            Criteria idCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "REPOSITORY_ID"), repositoryId, QueryConstants.EQUAL);
            DataObject dataObject = CommonUtil.getPersistence().get(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, idCriteria);
            if (!dataObject.isEmpty()) {
                Iterator iter = dataObject.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                while (iter.hasNext()) {
                    Row row = (Row) iter.next();
                    Double size = (Double) row.get("SIZE");
                    Long sizeLong = (new Double(size)).longValue();
                    totalSize += sizeLong;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return totalSize;
    }

    public static void enableOrDisableAllDCs(long domainId, boolean status) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            query.setCriteria(domainCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Iterator iterator = dobj.getRows(TableName.BMR_BACKUP_SCHEDULE);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    long fbScheduleId = (long) row.get("FB_SCHEDULE_ID");
                    long ibScheduleId = (long) row.get("IB_SCHEDULE_ID");
                    if (status) {
                        BMRScheduler.disableSchedule(fbScheduleId);
                        BMRScheduler.disableSchedule(ibScheduleId);
                    } else {
                        BMRScheduler.enableSchedule(fbScheduleId);
                        BMRScheduler.enableSchedule(ibScheduleId);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void disableSchedulesInFreeEdition(JSONObject obj) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Iterator iterator = dobj.getRows(TableName.BMR_BACKUP_SCHEDULE);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    long fbScheduleId = (long) row.get("FB_SCHEDULE_ID");
                    long ibScheduleId = (long) row.get("IB_SCHEDULE_ID");
                    BMRScheduler.disableSchedule(fbScheduleId);
                    BMRScheduler.disableSchedule(ibScheduleId);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String updateCredentials(JSONObject obj) {
        Properties prop = AddDomainServ.getDomainDetailsInfo(obj);
        List dcList = ADSDomainHandler.getDomainConfigurationList((String) prop.get("DOMAIN_NAME")); // No I18N
        String errormsg = AddDomainServ.editDomain(prop, dcList);
        Properties domainDetails = RMPDomainHandler.getDomainDetailsByName(prop.getProperty("DOMAIN_NAME"));
        String domainId = domainDetails.get("DOMAIN_ID").toString();
        Properties details = GetDomainDetails.getConfiguredValues(domainId);
        if (!details.get("STATUS_MESSAGE").toString().contains("success")) {
            errormsg = details.get("STATUS_MESSAGE").toString();
        }
        return errormsg;
    }

    public static void updateCalendarTable(long scheduleId, String frequency, String hour, String min, String unit, String mask, String date) {
        try {
            Long scheduleTime = 0L;
            UpdateQuery query = new UpdateQueryImpl("Calendar"); //No I18N
            query.setUpdateColumn("REPEAT_FREQUENCY", frequency); //No I18N
            query.setUpdateColumn("UNIT_OF_TIME", unit); //No I18N
            if (unit.equals("Hours")) {
                scheduleTime = Long.parseLong(hour);
            } else if (unit.equals("Minutes")) {
                scheduleTime = (Long.parseLong(hour) * 60) + Long.parseLong(min);
            }
            query.setUpdateColumn("TIME_OF_DAY", scheduleTime); //No I18N
            if (frequency.equalsIgnoreCase("weekly")) {
                query.setUpdateColumn("DAY_OF_WEEK", Integer.parseInt(mask)); //No I18N
            } else {
                query.setUpdateColumn("DAY_OF_WEEK", -1); //No I18N
            }
            if (frequency.equalsIgnoreCase("monthly")) {
                query.setUpdateColumn("DATE_OF_MONTH", Integer.parseInt(date)); //No I18N
            } else {
                query.setUpdateColumn("DATE_OF_MONTH", -1); //No I18N
            }
            Criteria idCriteria = new Criteria(Column.getColumn("Calendar", "SCHEDULE_ID"), scheduleId, QueryConstants.EQUAL);
            query.setCriteria(idCriteria);
            CommonUtil.getPersistence().update(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateTaskInputTable(long scheduleId) {
        try {
            DataObject scheduleDO = PersistenceUtil.getSchedule(scheduleId, true);
            UpdateQuery upquery = new UpdateQueryImpl("Task_Input"); //No I18N
            upquery.setUpdateColumn("SCHEDULE_TIME", new Timestamp(ScheduleUtil.calculateNextScheduleTime(scheduleDO, new Long(-1), true))); //No I18N
            Criteria idCriteria = new Criteria(Column.getColumn("Task_Input", "SCHEDULE_ID"), scheduleId, QueryConstants.EQUAL);
            upquery.setCriteria(idCriteria);
            CommonUtil.getPersistence().update(upquery);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateScheduleStatus(String backupType, JSONObject obj, Criteria criteria) {
        try {

            String retention = (String) obj.get("retention");
            String status = (String) obj.get("status");
            int repoId = Integer.parseInt((obj.get("repositoryId").toString()));
            boolean isIbRequired = Boolean.parseBoolean((String) obj.get("isIbRequired"));
            boolean isEncrypted = Boolean.parseBoolean((String) obj.get("isEncrypted"));
            String encryptionPwd = "";
            if (isEncrypted) {
                encryptionPwd = URLDecoder.decode(obj.get("secretKey").toString(), "UTF-8");// No I18N
            }

            UpdateQuery query = new UpdateQueryImpl(TableName.BMR_BACKUP_SCHEDULE);
            query.setUpdateColumn("REPOSITORY_ID", repoId); //No I18N
            query.setUpdateColumn("IB_REQUIRED", isIbRequired); //No I18N
            query.setUpdateColumn("RETENTION", retention); //No I18N
            query.setUpdateColumn("STATUS", status); //No I18N
            query.setUpdateColumn("BACKUP_TYPE", backupType); //No I18N
            query.setUpdateColumn("IS_ENCRYPTED", isEncrypted); //No I18N
            query.setUpdateColumn("SECRETKEY", encryptionPwd);//No I18N
            query.setCriteria(criteria);
            CommonUtil.getPersistence().update(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateSchedule(JSONObject obj) {
        try {
            JSONArray dcArray = (JSONArray) obj.getJSONArray("dc");//No I18N
            JSONObject jsObject = (JSONObject) dcArray.get(0);
            String domain = (String) obj.get("domain");
            int repoId = Integer.parseInt((obj.get("repositoryId").toString()));
            boolean isIbRequired = Boolean.parseBoolean((String) obj.get("isIbRequired"));
            String backupType = (String) obj.get("backupType");
            boolean isEncrypted = Boolean.parseBoolean((String) obj.get("isEncrypted"));
            boolean useOldPassword = obj.getBoolean("useOldPassword");// No I18N
            String encryptionPwd = "";
            if (!useOldPassword && isEncrypted) {
                encryptionPwd = URLDecoder.decode(obj.get("secretKey").toString(), "UTF-8");// No I18N
            }
            String dcName = (String) (jsObject.get("dcName"));
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
            long backupId = Long.parseLong(jsObject.get("dcId").toString());
            String fullFreq = (String) obj.get("fbFreq");
            String incrFreq = (String) obj.get("ibFreq");
            String fullHour = (String) obj.get("fbHr");
            String incrHour = (String) obj.get("ibHr");
            String fullMin = (String) obj.get("fbMin");
            String incrMin = (String) obj.get("ibMin");
            String fbMask = (String) obj.get("fbMask");
            String fbDate = (String) obj.get("fbDate");
            String ibMask = (String) obj.get("ibMask");
            String ibDate = (String) obj.get("ibDate");
            String unit;
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), backupId, QueryConstants.EQUAL);
            String retention = (String) obj.get("retention");

            SelectQueryImpl selquery = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            selquery.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            selquery.setCriteria(domainCriteria.and(dcCriteria));
            DataObject dobj = CommonUtil.getPersistence().get(selquery);
            Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
            long fbScheduleId = (long) row.get("FB_SCHEDULE_ID");
            long ibScheduleId = (long) row.get("IB_SCHEDULE_ID");
            String prevBackupType = (String) row.get("BACKUP_TYPE");

            UpdateQuery query = new UpdateQueryImpl(TableName.BMR_BACKUP_SCHEDULE);
            query.setUpdateColumn("RETENTION", retention); //No I18N
            query.setUpdateColumn("REPOSITORY_ID", repoId); //No I18N
            query.setUpdateColumn("IB_REQUIRED", isIbRequired); //No I18N
            query.setUpdateColumn("BACKUP_TYPE", backupType); //No I18N
            query.setUpdateColumn("IS_ENCRYPTED", isEncrypted); //No I18N
            if (!useOldPassword && isEncrypted) {
                query.setUpdateColumn("SECRETKEY", encryptionPwd); //No I18N
            } else if (!isEncrypted) {
                query.setUpdateColumn("SECRETKEY", ""); //No I18N
            }
            query.setCriteria(domainCriteria.and(dcCriteria));
            CommonUtil.getPersistence().update(query);

            if (prevBackupType.equals(backupType)) {
                if (fullMin.equals("00")) {
                    unit = "Hours"; //No I18N
                } else {
                    unit = "Minutes"; //No I18N
                }
                updateCalendarTable(fbScheduleId, fullFreq, fullHour, fullMin, unit, fbMask, fbDate);
                updateTaskInputTable(fbScheduleId);

                if (isIbRequired && ibScheduleId != 0) {
                    if (incrMin.equals("00")) {
                        unit = "Hours"; //No I18N
                    } else {
                        unit = "Minutes"; //No I18N
                    }
                    updateCalendarTable(ibScheduleId, incrFreq, incrHour, incrMin, unit, ibMask, ibDate);
                    updateTaskInputTable(ibScheduleId);
                } else if (isIbRequired && ibScheduleId == 0) {
                    String backupFreq = null;

                    if (incrFreq.equals("Monthly")) {
                        backupFreq = "0";
                    } else if (incrFreq.equals("Daily")) {
                        backupFreq = "1";
                    } else if (incrFreq.equals("Weekly")) {
                        backupFreq = "2";
                    }

                    String scheduleBackupType = "IB";// No I18N

                    if (!backupType.equals("BMR")) {
                        scheduleBackupType = "flrIB";// No I18N
                    }
                    BMRScheduler bmrScheduler = new BMRScheduler(backupId, backupFreq, incrHour, incrMin, ibMask, ibDate, scheduleBackupType);
                    bmrScheduler.updateSchedule();
                } else if (!isIbRequired && ibScheduleId != 0) {
                    // BMRScheduler.disableSchedule(ibScheduleId);
                    ScheduleManager.deleteSchedule(ibScheduleId);

                    UpdateQuery upquery = new UpdateQueryImpl(TableName.BMR_BACKUP_SCHEDULE);
                    upquery.setUpdateColumn("IB_SCHEDULE_ID", 0); //No I18N
                    upquery.setCriteria(domainCriteria.and(dcCriteria));
                    CommonUtil.getPersistence().update(upquery);
                }
            } else {
                ScheduleManager.deleteSchedule(fbScheduleId);
                if (ibScheduleId != 0) {
                    ScheduleManager.deleteSchedule(ibScheduleId);
                    UpdateQuery upquery = new UpdateQueryImpl(TableName.BMR_BACKUP_SCHEDULE);
                    upquery.setUpdateColumn("IB_SCHEDULE_ID", 0); //No I18N
                    upquery.setCriteria(domainCriteria.and(dcCriteria));
                    CommonUtil.getPersistence().update(upquery);
                }
                createSchedule(obj, domainCriteria.and(dcCriteria));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateStatus(String domain, String dcName, long backupId, String status, String errorMsg) {
        try {
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
            UpdateQuery query = new UpdateQueryImpl(TableName.BMR_BACKUP_SCHEDULE);
            query.setUpdateColumn("STATUS", status); //No I18N

            if (status.equalsIgnoreCase("Backup not configured")) {
                query.setUpdateColumn("FILES_TO_BACKUP", ""); //No I18N
            }

            query.setUpdateColumn("ERROR_MSG", errorMsg); //No I18N
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), backupId, QueryConstants.EQUAL);
            query.setCriteria(domainCriteria.and(dcCriteria));
            CommonUtil.getPersistence().update(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateTotalBackupDetails(String domain, Long domainId, Long dcId, float dcSize, String type) {
        try {
            updateConfiguredDomainDetails(domain);
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_TOTAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "*"));
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(domainCriteria.and(dcCriteria));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_TOTAL_BACKUP_DETAILS);
            Integer fbCount = (Integer) row.get("FB_COUNT");
            Integer ibCount = (Integer) row.get("IB_COUNT");
            double size = (double) row.get("SIZE");
            UpdateQuery upquery = new UpdateQueryImpl(TableName.BMR_TOTAL_BACKUP_DETAILS);
            if (type.equals("FB")) {
                upquery.setUpdateColumn("FB_COUNT", ++fbCount); //No I18N
            } else {
                upquery.setUpdateColumn("IB_COUNT", ++ibCount); //No I18N
            }
            upquery.setUpdateColumn("SIZE", size + dcSize); //No I18N

            upquery.setCriteria(domainCriteria.and(dcCriteria));
            CommonUtil.getPersistence().update(upquery);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateIndividualBackupDetails(Long operationId, float dcSize, JSONArray partitions, String backupFolder, String status, Long totalTime) {
        try {
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), operationId, QueryConstants.EQUAL);
            UpdateQuery upquery = new UpdateQueryImpl(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
            upquery.setUpdateColumn("PARTITIONS_INFO", partitions.toString()); //No I18N
            upquery.setUpdateColumn("SIZE", dcSize); //No I18N
            upquery.setUpdateColumn("BACKUP_FOLDER", backupFolder); //No I18N
            upquery.setUpdateColumn("STATUS", status); //No I18N
            upquery.setUpdateColumn("TIME_TAKEN", totalTime); //No I18N
            upquery.setCriteria(criteria);
            CommonUtil.getPersistence().update(upquery);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateConfiguredDomainDetails(String domain) {
        try {
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_DETAILS, "DOMAIN_NAME"), domain, QueryConstants.EQUAL);
            UpdateQuery upquery = new UpdateQueryImpl(TableName.BMR_DOMAIN_DETAILS);
            upquery.setUpdateColumn("IS_BACKUP_DONE", true); //No I18N
            upquery.setCriteria(domainCriteria);
            CommonUtil.getPersistence().update(upquery);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Properties getLocationDetail(long dcId) {
        Properties details = new Properties();
        try {
            long repoId = getRepositoryIdFromDcId(dcId);
            JSONObject repositoryObj = VMRepositoryServer.getBackupRepository(repoId).getJSONObject("selectedValue");
            details.put("Location", repositoryObj.get("REPOSITORY_PATH").toString());
            details.put("User", repositoryObj.get("REPOSITORY_USERNAME").toString());
            details.put("Password", repositoryObj.get("REPOSITORY_PASSWORD").toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    public static Properties getLocationDetails() {
        Properties details = new Properties();
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_STORAGE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_STORAGE, "*"));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Row domain = dobj.getFirstRow(TableName.BMR_BACKUP_STORAGE);
                details.put("Location", domain.get("LOCATION").toString());
                details.put("User", domain.get("USER_NAME").toString());
                details.put("Password", domain.get("PASSWORD").toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    public static JSONArray getBMRDcs(String domain, String machineType, boolean isFromGetDC) {
        JSONArray jArray = new JSONArray();
        try {
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria objectTypeCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "OBJECT_TYPE"), machineType, QueryConstants.EQUAL);
            Criteria delCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "IS_DELETED"), false, QueryConstants.EQUAL);
            if(isFromGetDC) {
                query.setCriteria(dcCriteria.and(objectTypeCriteria.and(delCriteria)));
            } else {
                query.setCriteria(dcCriteria.and(objectTypeCriteria));
            }
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Iterator iterator = dobj.getRows(TableName.BMR_DOMAIN_CONTROLLERS);
            while (iterator.hasNext()) {
                Row row = (Row) iterator.next();
                JSONObject dcObj = new JSONObject();
                dcObj.put("dcName", row.get("DC_NAME"));
                dcObj.put("dcGuid", row.get("GUID"));
                dcObj.put("dcId", row.get("DC_ID"));
                jArray.put(dcObj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jArray;
    }

    public static JSONArray getBMRMachineDetails(Criteria otherCriteria) {
        JSONArray returnValue = new JSONArray();
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "IS_LICENSED"));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_NAME")); // NO I18N
            query.addSortColumn(new SortColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_NAME"), true)); // NO I18N
            if (otherCriteria != null) {
                query.setCriteria(otherCriteria);
            }
            DataObject dataObject = CommonUtil.getPersistence().get(query);
            if (!dataObject.isEmpty()) {
                Iterator rows = dataObject.getRows(TableName.BMR_DOMAIN_CONTROLLERS);
                while (rows.hasNext()) {
                    Row row = (Row) rows.next();
                    JSONObject machineDetails = new JSONObject();
                    machineDetails.put("serverID", (Long) row.get("DC_ID"));//NO I18N
                    machineDetails.put("isLicensed", (int) row.get("IS_LICENSED"));//NO I18N
                    machineDetails.put("name", (String) row.get("DC_NAME"));//NO I18N
                    returnValue.put(machineDetails);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnValue;
    }

    public static JSONArray getUnconfiguredDcs(String domain, String machineType) {
        JSONArray jArray = new JSONArray();
        try {
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));// No I18N
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "OBJECT_TYPE"));// No I18N
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "IS_DELETED"));// No I18N

            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), QueryConstants.EQUAL);
            Join join = new Join(TableName.BMR_BACKUP_SCHEDULE, TableName.BMR_DOMAIN_CONTROLLERS, criteria, Join.INNER_JOIN);
            selectQuery.addJoin(join);

            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria statusCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "STATUS"), "Backup not configured", QueryConstants.EQUAL);
            Criteria objectTypeCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "OBJECT_TYPE"), machineType, QueryConstants.EQUAL);
            Criteria delCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "IS_DELETED"), false, QueryConstants.EQUAL);

            selectQuery.setCriteria(domainCriteria.and(statusCriteria.and(objectTypeCriteria.and(delCriteria))));

            DataObject dobj = CommonUtil.getPersistence().get(selectQuery);
            Iterator iterator = dobj.getRows(TableName.BMR_BACKUP_SCHEDULE);
            while (iterator.hasNext()) {
                Row row = (Row) iterator.next();
                long dcId = (long) row.get("DC_ID");
                String dcName = getNameFromId(dcId);
                JSONObject dcObj = new JSONObject();
                dcObj.put("dcName", dcName);
                dcObj.put("dcId", dcId);
                jArray.put(dcObj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jArray;
    }

    public static String getFQDNFromFlatName(long dcId) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_DOMAIN_CONTROLLERS);
            return row.get("DC_DNS_NAME").toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getOSArchitecture(long dcId) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_DOMAIN_CONTROLLERS);
            return (String) row.get("OS_ARCHITECTURE");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void updateOSArchitecture(long dcId, String osArchitecture) {
        try {
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcId, QueryConstants.EQUAL);
            UpdateQuery query = new UpdateQueryImpl(TableName.BMR_DOMAIN_CONTROLLERS);
            query.setUpdateColumn("OS_ARCHITECTURE", osArchitecture); //No I18N
            query.setCriteria(criteria);
            CommonUtil.getPersistence().update(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getNameFromId(Long dcId) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_DOMAIN_CONTROLLERS);
            return (String) row.get("DC_NAME");

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getBackupTypeFromId(Long dcId) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
            return (String) row.get("BACKUP_TYPE");

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static JSONArray getFailedBackupDetailsFromId(Long dcId, int days) {
        JSONArray dataArray = new JSONArray();
        try {
            SimpleDateFormat timestampFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm"); //No I18N
            String isLike = "Failed";  //No I18N
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -days);
            Date endDate = cal.getTime();
            Timestamp startTime = DateUtil.getTimestampFromDate(endDate);
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            Criteria statCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "STATUS"), isLike, QueryConstants.CONTAINS, false);
            Criteria timeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME"), startTime, QueryConstants.GREATER_THAN);
            Criteria criteria = dcCriteria.and(statCriteria);
            query.setCriteria(criteria.and(timeCriteria));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Iterator iterator = dobj.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
            while (iterator.hasNext()) {
                Row row = (Row) iterator.next();
                JSONObject data = new JSONObject();
                String time = timestampFormat.format((Timestamp) row.get("START_TIME"));
                data.put("startTime", time);
                data.put("status", row.get("STATUS"));
                data.put("repoId", row.get("REPOSITORY_ID"));
                data.put("backupType", row.get("BACKUP_MODE"));
                dataArray.put(data);
            }
            return dataArray;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getObjectTypeFromId(Long dcId) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_DOMAIN_CONTROLLERS);
            return (String) row.get("OBJECT_TYPE");

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Row getScheduleDetails(long scheduleId) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable("Calendar"));
            query.addSelectColumn(Column.getColumn("Calendar", "*"));
            Criteria idCriteria = new Criteria(Column.getColumn("Calendar", "SCHEDULE_ID"), scheduleId, QueryConstants.EQUAL);
            query.setCriteria(idCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (dobj.isEmpty()) {
                return null;
            }
            Row row = dobj.getFirstRow("Calendar");//No I18N
            return row;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static JSONObject getSchedule(Criteria criteria, int rangeStart, int limit) {
        JSONObject returnObject = new JSONObject();
        JSONArray dataArray = new JSONArray();
        try {
            DecimalFormat formatter = new DecimalFormat("00");
            String time;
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(new Column(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"));
            query.addSelectColumn(new Column(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"));
            query.addSelectColumn(new Column(TableName.BMR_BACKUP_SCHEDULE, "FB_SCHEDULE_ID"));
            query.addSelectColumn(new Column(TableName.BMR_BACKUP_SCHEDULE, "IB_SCHEDULE_ID"));
            query.addSelectColumn(new Column(TableName.BMR_BACKUP_SCHEDULE, "IB_REQUIRED"));
            query.addSelectColumn(new Column(TableName.BMR_BACKUP_SCHEDULE, "RETENTION"));
            query.addSelectColumn(new Column(TableName.BMR_BACKUP_SCHEDULE, "STATUS"));
            query.addSelectColumn(new Column(TableName.BMR_BACKUP_SCHEDULE, "ERROR_MSG"));
            query.addSelectColumn(new Column(TableName.BMR_BACKUP_SCHEDULE, "REPOSITORY_ID"));
            query.addSelectColumn(new Column(TableName.BMR_BACKUP_SCHEDULE, "BACKUP_TYPE"));
            query.addSelectColumn(new Column(TableName.BMR_BACKUP_SCHEDULE, "IS_ENCRYPTED"));

            // query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            query.setCriteria(criteria);
            SortColumn scol = new SortColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), false); // NO I18N
            query.addSortColumn(scol);
            query.setRange(new Range(rangeStart, limit));

            CustomViewRequest cvRequest = new CustomViewRequest(query);
            CustomViewManager cvManager = (CustomViewManager) BeanUtil.lookup("TableViewManager");// No I18N
            ViewData viewData = cvManager.getData(cvRequest);
            CVTableModel model = (CVTableModel) viewData.getModel();
            long totalcount = model.getTotalRecordsCount();
            int rowcount = model.getRowCount();

            returnObject.put("total", totalcount);

            for (int i = 0; i < rowcount; i++) {

                JSONObject data = new JSONObject();
                long dcId = Long.parseLong(model.getValueAt(i, 0).toString());
                String dcName = getNameFromId(dcId);
                // String dcName = getNameFromId((long) row.get("DC_ID"));
                String objectType = getObjectTypeFromId(dcId);
                boolean isIbRequired = Boolean.parseBoolean(model.getValueAt(i, 4).toString());
                boolean isEncrypted = Boolean.parseBoolean(model.getValueAt(i, 10).toString());
                // boolean isIbRequired = ((boolean) row.get("IB_REQUIRED"));
                data.put("dc", dcName);
                data.put("dcId", dcId);
                data.put("objectType", objectType);
                long fbId = Long.parseLong(model.getValueAt(i, 2).toString());
                // long fbId = (long) row.get("FB_SCHEDULE_ID");
                Row fbCalendarRow = getScheduleDetails(fbId);
                if (fbCalendarRow != null) {
                    data.put("fb_freq", fbCalendarRow.get("REPEAT_FREQUENCY").toString().toLowerCase());
                    data.put("fb_day", (Integer) fbCalendarRow.get("DAY_OF_WEEK"));
                    data.put("fb_date", formatter.format((Integer) fbCalendarRow.get("DATE_OF_MONTH")));
                    if (((String) fbCalendarRow.get("UNIT_OF_TIME")).equalsIgnoreCase("Hours")) {
                        data.put("fb_hr", formatter.format((long) fbCalendarRow.get("TIME_OF_DAY")));
                        data.put("fb_min", "00");
                    } else if (((String) fbCalendarRow.get("UNIT_OF_TIME")).equalsIgnoreCase("Minutes")) {
                        data.put("fb_hr", formatter.format(((long) (fbCalendarRow.get("TIME_OF_DAY")) / 60)));
                        data.put("fb_min", formatter.format(((long) (fbCalendarRow.get("TIME_OF_DAY")) % 60)));
                    }
                } else {
                    data.put("fb_freq", "-");
                }

                long ibId = Long.parseLong(model.getValueAt(i, 3).toString());
                // long ibId = (long) row.get("IB_SCHEDULE_ID");
                Row ibCalendarRow = getScheduleDetails(ibId);
                if (ibCalendarRow != null) {
                    data.put("ib_freq", ibCalendarRow.get("REPEAT_FREQUENCY").toString().toLowerCase());
                    data.put("ib_day", (Integer) ibCalendarRow.get("DAY_OF_WEEK"));
                    data.put("ib_date", formatter.format((Integer) ibCalendarRow.get("DATE_OF_MONTH")));
                    if (((String) ibCalendarRow.get("UNIT_OF_TIME")).equalsIgnoreCase("Hours")) {
                        data.put("ib_hr", formatter.format((long) ibCalendarRow.get("TIME_OF_DAY")));
                        data.put("ib_min", "00");
                    } else if (((String) ibCalendarRow.get("UNIT_OF_TIME")).equalsIgnoreCase("Minutes")) {
                        data.put("ib_hr", formatter.format((long) (ibCalendarRow.get("TIME_OF_DAY")) / 60));
                        data.put("ib_min", formatter.format((long) (ibCalendarRow.get("TIME_OF_DAY")) % 60));
                    }
                } else {
                    data.put("ib_freq", "-");
                }

                SimpleDateFormat timestampFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");// No I18N
                Timestamp nextFullBackup = new Timestamp(ScheduleManager.getActualScheduleTime(fbId));
                Timestamp nextIncrBackup = null;

                if (isIbRequired) {
                    nextIncrBackup = new Timestamp(ScheduleManager.getActualScheduleTime(ibId));

                    if (nextFullBackup.before(nextIncrBackup)) {
                        time = timestampFormat.format(nextFullBackup);
                    } else {
                        time = timestampFormat.format(nextIncrBackup);
                    }
                } else {
                    time = timestampFormat.format(nextFullBackup);
                }

                int pauseStatus = BMRScheduler.getEnableDisableScheduleStatus(fbId);
                JSONObject prevBackup = getPreviousBackupDetails(Long.parseLong(model.getValueAt(i, 0).toString()));
                data.put("pauseStatus", pauseStatus);
                data.put("retention", model.getValueAt(i, 5).toString());
                data.put("status", model.getValueAt(i, 6).toString());
                data.put("errorMsg", model.getValueAt(i, 7).toString());
                data.put("nextBackup", time);
                data.put("prevBackup", (String) prevBackup.get("date"));
                data.put("prevStatus", (String) prevBackup.get("status"));
                data.put("backupType", model.getValueAt(i, 9).toString());
                data.put("repositoryType", model.getValueAt(i, 8).toString());
                data.put("isIbRequired", isIbRequired);
                data.put("licenseType", getLicenseType(dcId).ordinal());
                data.put("isEncrypted", isEncrypted);
                dataArray.put(data);
            }

            returnObject.put("schedule", dataArray);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return returnObject;
    }

    public static JSONObject getPreviousBackupDetails(long dcId) {
        JSONObject data = new JSONObject();
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", false));//NO I18N
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                SimpleDateFormat timestampFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");// No I18N
                String time = timestampFormat.format((Timestamp) row.get("START_TIME"));
                data.put("date", time);
                data.put("status", (String) row.get("STATUS"));
            } else {
                data.put("date", "-");
                data.put("status", "-");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    public static int getBackupCount(long dcId) {
        int count = 0;
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            Criteria idCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            Criteria statusCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "STATUS"), "Completed", QueryConstants.EQUAL);
            Criteria typeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "BACKUP_TYPE"), "FB", QueryConstants.EQUAL);
            query.setCriteria(idCriteria.and(statusCriteria.and(typeCriteria)));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if(!dobj.isEmpty()) {
                Iterator iterator = dobj.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    count++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public static int getRetentionCount(long dcId) {
        int retentionCnt = 0;
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
            String retention = (String) row.get("RETENTION");
            retentionCnt = Integer.parseInt(retention);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return retentionCnt;
    }

    public static void updateAgentDetails() {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.ADS_AGENT_CONFIGURATION));
            query.addSelectColumn(Column.getColumn(TableName.ADS_AGENT_CONFIGURATION, "*"));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Criteria criteria = new Criteria(Column.getColumn(TableName.ADS_AGENT_CONFIGURATION, "AGENT_NAME"), "BMR64", QueryConstants.EQUAL);
                UpdateQuery upquery = new UpdateQueryImpl(TableName.ADS_AGENT_CONFIGURATION);
                upquery.setUpdateColumn("AGENT_GUID", "{CFDE979F-E065-4B88-A77B-C24627FE09D2}"); //No I18N
                upquery.setCriteria(criteria);
                CommonUtil.getPersistence().update(upquery);
                Criteria criteria1 = new Criteria(Column.getColumn(TableName.ADS_AGENT_CONFIGURATION, "AGENT_NAME"), "BMR32", QueryConstants.EQUAL);
                UpdateQuery upquery1 = new UpdateQueryImpl(TableName.ADS_AGENT_CONFIGURATION);
                upquery1.setUpdateColumn("AGENT_GUID", "{262D8F15-C2E3-4B7E-AA5E-F17FF549CAF9}"); //No I18N
                upquery1.setCriteria(criteria1);
                CommonUtil.getPersistence().update(upquery1);
            } else {
                WindowsUtil.agentDetails();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateDCStatus() {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "STATUS"), "Backup configured", QueryConstants.EQUAL);
                UpdateQuery upquery = new UpdateQueryImpl(TableName.BMR_BACKUP_SCHEDULE);
                upquery.setUpdateColumn("STATUS", "Upgrade Agent"); //No I18N
                upquery.setCriteria(criteria);
                CommonUtil.getPersistence().update(upquery);
            } else {
                LogWriter.bmr.info("No rows found in BMR_BACKUP_SCHEDULE");//No I18N
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateInstalledGUID(long dcId, long domainId, String guid) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "*"));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcId, QueryConstants.EQUAL);
                Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                UpdateQuery upquery = new UpdateQueryImpl(TableName.BMR_DOMAIN_CONTROLLERS);
                upquery.setUpdateColumn("AGENT_GUID", guid); //No I18N
                upquery.setCriteria(dcCriteria.and(domainCriteria));
                CommonUtil.getPersistence().update(upquery);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean agentInstallCall(String dcName, long dcId, String finalName, String domain, String agentName, Properties details) {
        try {
            String status = InstallAgent.agentInstall(details, finalName, agentName, true);
            if (status != null) {
                if (!InstallAgent.getAgentStatus(details, finalName, agentName)) {
                    BMRDatabase.updateStatus(domain, dcName, dcId, "Installation failed", status);//No I18N
                    return false;
                } else {
                    BMRDatabase.updateStatus(domain, dcName, dcId, "Backup configured", "");//No I18N
                    return true;
                }
            } else {
                BMRDatabase.updateStatus(domain, dcName, dcId, "Backup configured", "");//No I18N
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean agentUninstallCall(String dcName, long dcId, String finalName, String domain, String agentName, Properties details, boolean isAccessible) {
        try {
            LogWriter.bmr.info("In Agentuninstall method");//No I18N
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria.and(domainCriteria));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
            String configStatus = (String) row.get("STATUS");
            boolean retStatus = isAccessible && configStatus.equals("Backup configured");
            if (retStatus) {
                String status = InstallAgent.agentInstall(details, finalName, agentName, false);
                if (status != null) {
                    LogWriter.bmr.info("Agent uninstall failed");//No I18N
                    retStatus = false;
                }
            }
            long fbScheduleId = (long) row.get("FB_SCHEDULE_ID");
            long ibScheduleId = (long) row.get("IB_SCHEDULE_ID");

            if (fbScheduleId != 0) {
                ScheduleManager.deleteSchedule(fbScheduleId);
            }

            if (ibScheduleId != 0) {
                ScheduleManager.deleteSchedule(ibScheduleId);
            }

            BMRScheduler.updateBackupScheduleTable(dcId, 0L, "FB");//No I18N
            BMRScheduler.updateBackupScheduleTable(dcId, 0L, "IB");//No I18N
            BMRDatabase.updateStatus(domain, dcName, dcId, "Backup not configured", "");//No I18N
            BMRDatabase.deleteBackupEntries(dcId);
            return retStatus;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean isPingable(String dcName) {
        try {
            /*
             Socket soc = new Socket();
             InetAddress inet = InetAddress.getByName(dcName);
             soc.connect(new InetSocketAddress(inet, 389), 5000);//Connecting to LDAP port
             LogWriter.bmr.info("Status : " + dcName + "  is reachable");//No I18N
             return true;*/
            InetAddress inet = InetAddress.getByName(dcName);
            inet.isReachable(1000);
            return true;
        } catch (IOException e) {
            LogWriter.bmr.info("IOException thrown when accessing host...");//No I18N
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            LogWriter.bmr.info("Exception in reaching host...");//No I18N
            e.printStackTrace();
            return false;
        }
    }

    public static void updateDCAgent(String dcName, long dcId, long domainId) {
        try {
            //updateAgentDetails();
            String domain = (String) RMPDomainHandler.getDomainDetailsById(domainId).getProperty("DOMAIN_NAME");
            boolean osArchitectureKnown = false;
            String installedAgentGUID = getInstalledAgentGUID(dcId, domainId);
            String latestAgent64 = getLatestAgentGUID("BMR64");//No I18N
            String latestAgent32 = getLatestAgentGUID("BMR32");//No I18N
            if (installedAgentGUID == null || (!(installedAgentGUID.equals(latestAgent64)) && !(installedAgentGUID.equals(latestAgent32)))) {
                LogWriter.bmr.info("Trying to install agent...");//NO I18N
                String dnsName = BMRDatabase.getFQDNFromFlatName(dcId);
                if (dnsName == null || dnsName.isEmpty()) {
                    dnsName = dcName;
                }
                String finalName = "";
                //String domain = (String) RMPDomainHandler.getDomainDetailsById(domainId).getProperty("DOMAIN_NAME");
                Properties details = RMPDomainHandler.getDomainDetailsByName(domain);
                String domainName = (String) details.getProperty("USER_DOMAIN_NAME");
                String pwd = (String) details.getProperty("PASSWORD");
                String name = domainName + "\\" + (String) details.getProperty("USER_NAME") + "###" + pwd;//No I18N
                String[] param = {"OSArchitecture"};// No I18N
                String result, agentName = "BMR64", latestGUID = latestAgent64;//No I18N

                boolean isPingable = isPingable(dcName);
                if (isPingable) {
                    finalName = dcName;
                } else {
                    isPingable = isPingable(dnsName);
                    if (isPingable) {
                        finalName = dnsName;
                    } else {
                        LogWriter.bmr.info("Ping failed.DC is inaccessible");//NO I18N
                        BMRDatabase.updateStatus(domain, dcName, dcId, "Installation failed", "Server inaccessible");//No I18N
                    }
                }

                if (!finalName.isEmpty()) {
                    try {

                        result = BMRDatabase.getOSArchitecture(dcId);

                        if (result == "" || result == null) {
                            osArchitectureKnown = false;
                            Properties resprop = WindowsUtil.getOSArchitecture(details, finalName, param, "Select * from Win32_OperatingSystem");// No I18N

                            if (resprop != null) {
                                result = resprop.get("OSArchitecture").toString();
                                osArchitectureKnown = true;
                                BMRDatabase.updateOSArchitecture(dcId, result);
                            } else {
                                osArchitectureKnown = false;
                            }
                        } else {
                            osArchitectureKnown = true;
                        }

                        if (osArchitectureKnown) {
                            if (result.contains("64")) {
                                agentName = "BMR64";// No I18N
                                latestGUID = latestAgent64;
                            } else if (result.contains("32")) {
                                agentName = "BMR32";// No I18N
                                latestGUID = latestAgent32;
                            }
                            if (!InstallAgent.getAgentStatus(details, finalName, agentName)) {
                                int res = WindowsHandler.executeCommand(finalName, name, "*", "C:\\Program Files\\ManageEngine\\RMP\\DeleteService.bat", true);//No I18N
                                LogWriter.bmr.info("DeleteService failed :" + res);//NO I18N
                                if (BMRDatabase.agentInstallCall(dcName, dcId, finalName, domain, agentName, details)) {
                                    updateInstalledGUID(dcId, domainId, latestGUID);
                                }
                            } else {
                                LogWriter.bmr.info("Agent already installed");//NO I18N
                                BMRDatabase.updateStatus(domain, dcName, dcId, "Backup configured", "");//No I18N
                                updateInstalledGUID(dcId, domainId, latestGUID);
                            }
                        } else {
                            LogWriter.bmr.info("Error : OS Architecture unknown");//NO I18N
                            if (!InstallAgent.getAgentStatus(details, finalName, "BMR64")) {
                                int res = WindowsHandler.executeCommand(finalName, name, "*", "C:\\Program Files\\ManageEngine\\RMP\\DeleteService.bat", true);//No I18N
                                LogWriter.bmr.info("DeleteService failed :" + res);//NO I18N
                                if (BMRDatabase.agentInstallCall(dcName, dcId, finalName, domain, "BMR64", details)) {
                                    updateInstalledGUID(dcId, domainId, latestAgent64);
                                }
                            } else {
                                LogWriter.bmr.info("Agent already installed");//NO I18N
                                BMRDatabase.updateStatus(domain, dcName, dcId, "Backup configured", "");//No I18N
                                updateInstalledGUID(dcId, domainId, latestGUID);
                            }
                        }
                    } catch (ADSADException ex) {
                        LogWriter.bmr.info("ADSADException: " + ex.getExceptionMsg());//NO I18N
                        if (!InstallAgent.getAgentStatus(details, finalName, "BMR64")) {
                            int res = WindowsHandler.executeCommand(finalName, name, "*", "C:\\Program Files\\ManageEngine\\RMP\\DeleteService.bat", true);//No I18N
                            LogWriter.bmr.info("DeleteService failed :" + res);//NO I18N
                            if (BMRDatabase.agentInstallCall(dcName, dcId, finalName, domain, "BMR64", details)) {
                                updateInstalledGUID(dcId, domainId, latestAgent64);
                            }
                        } else {
                            LogWriter.bmr.info("Agent already installed");//NO I18N
                            BMRDatabase.updateStatus(domain, dcName, dcId, "Backup configured", "");//No I18N
                            updateInstalledGUID(dcId, domainId, latestGUID);
                        }
                    } catch (Exception e) {
                        LogWriter.bmr.info("Error : Installation failed");//NO I18N
                        if (!InstallAgent.getAgentStatus(details, finalName, "BMR64")) {
                            int res = WindowsHandler.executeCommand(finalName, name, "*", "C:\\Program Files\\ManageEngine\\RMP\\DeleteService.bat", true);//No I18N
                            LogWriter.bmr.info("DeleteService failed :" + res);//NO I18N
                            if (BMRDatabase.agentInstallCall(dcName, dcId, finalName, domain, "BMR64", details)) {
                                updateInstalledGUID(dcId, domainId, latestAgent64);
                            }
                        } else {
                            LogWriter.bmr.info("Agent already installed");//NO I18N
                            BMRDatabase.updateStatus(domain, dcName, dcId, "Backup configured", "");//No I18N
                            updateInstalledGUID(dcId, domainId, latestGUID);
                        }
                    }
                }
            } else {
                LogWriter.bmr.info("Latest Agent already installed");//NO I18N
                BMRDatabase.updateStatus(domain, dcName, dcId, "Backup configured", "");//No I18N
                updateInstalledGUID(dcId, domainId, installedAgentGUID);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static JSONArray getDCChartDetails(JSONObject obj) {
        JSONArray dataArray = new JSONArray();
        try {
            String domain = (String) obj.get("domain");
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_TOTAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria sizeCriteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "SIZE"), 0f, QueryConstants.GREATER_THAN);
            query.setCriteria(criteria.and(sizeCriteria));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Iterator iterator = dobj.getRows(TableName.BMR_TOTAL_BACKUP_DETAILS);
            while (iterator.hasNext()) {
                Row row = (Row) iterator.next();
                JSONObject data = new JSONObject();
                long dcId = (long) row.get("DC_ID");
                String dcName = getNameFromId(dcId);
                String backupType = getBackupTypeFromId((long) row.get("DC_ID"));
                String machineType = BMRDatabase.getObjectTypeFromId((long) row.get("DC_ID"));  //NO I18N
                data.put("dc", dcName);
                data.put("dcId", dcId);
                data.put("fb_count", (Integer) row.get("FB_COUNT"));
                data.put("ib_count", (Integer) row.get("IB_COUNT"));
                data.put("size", (double) row.get("SIZE"));
                data.put("machineType", machineType);
                data.put("backupType", backupType);
                dataArray.put(data);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataArray;
    }

    public static JSONArray getFailedBackupChartDetails(JSONObject obj) {
        JSONArray dataArray = new JSONArray();
        try {
            List<String> domainList = RMPDomainHandler.getDomainNames();
            int len = 0;
            int selected = Integer.parseInt(obj.get("selected").toString());
            for (len = 0; len < domainList.size(); ++len) {
                String domain = domainList.get(len).toString();
                long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
                SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
                query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
                Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                query.setCriteria(criteria);
                DataObject dobj = CommonUtil.getPersistence().get(query);
                Iterator iterator = dobj.getRows(TableName.BMR_BACKUP_SCHEDULE);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    String dcName = getNameFromId((long) row.get("DC_ID"));
                    JSONArray returnedArray = BMRDatabase.getFailedBackupDetailsFromId((long) row.get("DC_ID"), selected); //NO I18N
                    if (returnedArray.length() != 0) {
                        int retLen = 0;
                        for (retLen = 0; retLen < returnedArray.length(); ++retLen) {
                            JSONObject data = new JSONObject();
                            JSONObject jObj = returnedArray.getJSONObject(retLen);
                            data.put("dc", dcName);
                            long repId = (long) jObj.get("repoId");
                            JSONObject repositoryDetails = VMRepositoryServer.getBackupRepository(repId);
                            JSONObject repoDetails = repositoryDetails.getJSONObject("selectedValue");
                            data.put("repoName", repoDetails.get("REPOSITORY_NAME"));
                            data.put("backupType", jObj.get("backupType"));
                            String status = (String) jObj.get("status");
                            String reason = " ";
                            if (status.contains("(")) {
                                reason = status.substring((status.indexOf('(') + 1), (status.length() - 1));
                            } else {
                                reason = "Unexpected error";    //NO I18N
                            }
                            data.put("reason", reason);
                            data.put("scheduledRuntime", jObj.get("startTime").toString());
                            dataArray.put(data);

                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataArray;
    }

    public static JSONArray getDomainChartDetails(JSONObject obj) {
        JSONArray dataArray = new JSONArray();
        try {
            Set<Long> dcSet = new HashSet<>();
            Criteria sizCriteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "SIZE"), 0.0, QueryConstants.LESS_EQUAL);
            DataObject dataObject = CommonUtil.getPersistence().get(TableName.BMR_TOTAL_BACKUP_DETAILS, sizCriteria);
            if (!dataObject.isEmpty()) {
                Iterator iter = dataObject.getRows(TableName.BMR_TOTAL_BACKUP_DETAILS);
                while (iter.hasNext()) {
                    Row bmrSchedRow = (Row) iter.next();
                    Long dcId = (Long) bmrSchedRow.get("DC_ID");
                    dcSet.add(dcId);
                }
            }
            Criteria statusCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "STATUS"), "Backup not configured", QueryConstants.EQUAL);
            DataObject dataObj = CommonUtil.getPersistence().get(TableName.BMR_BACKUP_SCHEDULE, statusCriteria);
            if (!dataObj.isEmpty()) {
                Iterator bmrIter = dataObj.getRows(TableName.BMR_BACKUP_SCHEDULE);
                while (bmrIter.hasNext()) {
                    Row bmrBackupScheduleRow = (Row) bmrIter.next();
                    Long dcId = (Long) bmrBackupScheduleRow.get("DC_ID");
                    dcSet.add(dcId);
                }
            }
            Criteria dcIdCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcSet.toArray(), QueryConstants.IN);
            DataObject dObject = CommonUtil.getPersistence().get(TableName.BMR_DOMAIN_CONTROLLERS, dcIdCriteria);
            JSONArray bmrBackArray = new JSONArray();
            if (!dObject.isEmpty()) {
                Iterator schedIter = dObject.getRows(TableName.BMR_DOMAIN_CONTROLLERS);
                while (schedIter.hasNext()) {
                    Row bmrRow = (Row) schedIter.next();
                    JSONObject bmrFailedBackupObj = new JSONObject();
                    bmrFailedBackupObj.put("machineId", bmrRow.get("DC_ID"));
                    bmrFailedBackupObj.put("machineName", bmrRow.get("DC_NAME"));
                    bmrFailedBackupObj.put("machineType", bmrRow.get("OBJECT_TYPE"));
                    bmrBackArray.put(bmrFailedBackupObj);
                }
            }
            dataArray.put(bmrBackArray);

            Set<Long> domainSet = new HashSet<>();
            DataObject schedObj = CommonUtil.getPersistence().get(TableName.BMR_BACKUP_SCHEDULE, (Criteria) null);
            if (!schedObj.isEmpty()) {
                Iterator schedIter = schedObj.getRows(TableName.BMR_BACKUP_SCHEDULE);
                while (schedIter.hasNext()) {
                    Row bmrBackupSchedRow = (Row) schedIter.next();
                    Long schedDomainId = (Long) bmrBackupSchedRow.get("DOMAIN_ID");
                    domainSet.add(schedDomainId);
                }
            }

            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_TOTAL_BACKUP_DETAILS));
            Join dcJoin = new Join(TableName.BMR_TOTAL_BACKUP_DETAILS, TableName.BMR_DOMAIN_CONTROLLERS, new String[]{"DC_ID"}, new String[]{"DC_ID"}, Join.INNER_JOIN);
            Join dcJoin2 = new Join(TableName.BMR_TOTAL_BACKUP_DETAILS, TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, new String[]{"DC_ID"}, new String[]{"DC_ID"}, Join.INNER_JOIN);
            query.addSelectColumn(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "*"));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_NAME"));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "OBJECT_TYPE"));
            query.addJoin(dcJoin);
            query.addJoin(dcJoin2);

            List domainList = RMPDomainHandler.getDomainNames();
            for (int i = 0; i < domainList.size(); i++) {
                String domain = domainList.get(i).toString();
                long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
                Integer fbCount = 0, ibCount = 0, dcCount = 0, domainCnt = 0, bmrCount = 0, flbCount = 0, vlbCount = 0, objDCCount = 0, serverCount = 0;
                float size = 0f;
                if (domainSet.contains(domainId)) {
                    domainCnt++;
                }
                JSONArray dcList = new JSONArray();
                JSONArray serversList = new JSONArray();
                Set<Long> bmrDcIdSet = new HashSet<>();
                Set<Long> flrDcIdSet = new HashSet<>();
                Set<Long> vlrDcIdSet = new HashSet<>();
                JSONArray bmrArray = new JSONArray();
                JSONArray flbArray = new JSONArray();
                JSONArray vlbArray = new JSONArray();
                Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                Criteria sizeCriteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "SIZE"), 0f, QueryConstants.GREATER_THAN);
                query.setCriteria(criteria.and(sizeCriteria));
                DataObject dobj = CommonUtil.getPersistence().get(query);
                if (!dobj.isEmpty()) {
                    Iterator iterator = dobj.getRows(TableName.BMR_TOTAL_BACKUP_DETAILS);
                    Iterator dcIterator = dobj.getRows(TableName.BMR_DOMAIN_CONTROLLERS);
                    Iterator backIterator = dobj.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                    while (iterator.hasNext()) {
                        Row row = (Row) iterator.next();
                        size += (double) row.get("SIZE");
                        long dcId = (long) row.get("DC_ID");
                        fbCount += (Integer) row.get("FB_COUNT");
                        ibCount += (Integer) row.get("IB_COUNT");
                        ++dcCount;
                        String object = BMRDatabase.getObjectTypeFromId(dcId);
                        if (object.compareToIgnoreCase("DC") == 0) {
                            objDCCount++;
                        } else {
                            serverCount++;
                        }
                    }
                    while (dcIterator.hasNext()) {
                        Row dcRow = (Row) dcIterator.next();
                        String machineType = (String) dcRow.get("OBJECT_TYPE");

                        if (machineType.equalsIgnoreCase("DC")) {
                            JSONObject dcObj = new JSONObject();
                            dcObj.put("dcName", dcRow.get("DC_NAME"));
                            dcObj.put("dcId", dcRow.get("DC_ID"));
                            dcList.put(dcObj);
                        } else {
                            JSONObject serverObj = new JSONObject();
                            serverObj.put("dcName", dcRow.get("DC_NAME"));
                            serverObj.put("dcId", dcRow.get("DC_ID"));
                            serversList.put(serverObj);
                        }
                    }
                    while (backIterator.hasNext()) {
                        JSONObject object = new JSONObject();
                        Row row = (Row) backIterator.next();
                        String backupType = (String) row.get("BACKUP_MODE");
                        String status = (String) row.get("STATUS");
                        if (status.compareToIgnoreCase("Completed") == 0) {
                            if ((backupType.compareToIgnoreCase("BMR") == 0) || (backupType.compareToIgnoreCase("OLD BMR") == 0)) {
                                long dcId = (long) row.get("DC_ID");
                                bmrDcIdSet.add(dcId);
                            } else if (backupType.compareToIgnoreCase("FLR") == 0) {
                                long dcId = (long) row.get("DC_ID");
                                flrDcIdSet.add(dcId);
                            } else if (backupType.compareToIgnoreCase("VLR") == 0) {
                                long dcId = (long) row.get("DC_ID");
                                vlrDcIdSet.add(dcId);
                            }
                        }
                    }

                    Criteria bmrDcIdCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), bmrDcIdSet.toArray(), QueryConstants.IN);
                    DataObject dObj = CommonUtil.getPersistence().get(TableName.BMR_DOMAIN_CONTROLLERS, bmrDcIdCriteria);
                    if (!dObj.isEmpty()) {
                        Iterator schedIter = dObj.getRows(TableName.BMR_DOMAIN_CONTROLLERS);
                        while (schedIter.hasNext()) {
                            Row bmrRow = (Row) schedIter.next();
                            JSONObject bmrBackupObj = new JSONObject();
                            bmrBackupObj.put("machineId", bmrRow.get("DC_ID"));
                            bmrBackupObj.put("machineName", bmrRow.get("DC_NAME"));
                            bmrBackupObj.put("machineType", bmrRow.get("OBJECT_TYPE"));
                            bmrArray.put(bmrBackupObj);
                        }
                    }
                    Criteria flrDcIdCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), flrDcIdSet.toArray(), QueryConstants.IN);
                    DataObject datObj = CommonUtil.getPersistence().get(TableName.BMR_DOMAIN_CONTROLLERS, flrDcIdCriteria);
                    if (!datObj.isEmpty()) {
                        Iterator schedIter = datObj.getRows(TableName.BMR_DOMAIN_CONTROLLERS);
                        while (schedIter.hasNext()) {
                            Row bmrRow = (Row) schedIter.next();
                            JSONObject flbBackupObj = new JSONObject();
                            flbBackupObj.put("machineId", bmrRow.get("DC_ID"));
                            flbBackupObj.put("machineName", bmrRow.get("DC_NAME"));
                            flbBackupObj.put("machineType", bmrRow.get("OBJECT_TYPE"));
                            flbArray.put(flbBackupObj);
                        }
                    }
                    Criteria vlrDcIdCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), vlrDcIdSet.toArray(), QueryConstants.IN);
                    DataObject daObj = CommonUtil.getPersistence().get(TableName.BMR_DOMAIN_CONTROLLERS, vlrDcIdCriteria);
                    if (!daObj.isEmpty()) {
                        Iterator schedIter = daObj.getRows(TableName.BMR_DOMAIN_CONTROLLERS);
                        while (schedIter.hasNext()) {
                            Row bmrRow = (Row) schedIter.next();
                            JSONObject vlbBackupObj = new JSONObject();
                            vlbBackupObj.put("machineId", bmrRow.get("DC_ID"));
                            vlbBackupObj.put("machineName", bmrRow.get("DC_NAME"));
                            vlbBackupObj.put("machineType", bmrRow.get("OBJECT_TYPE"));
                            vlbArray.put(vlbBackupObj);
                        }
                    }
                    bmrCount = bmrArray.length();
                    flbCount = flbArray.length();
                    vlbCount = vlbArray.length();
                }
                JSONObject data = new JSONObject();
                data.put("domain", domain);
                data.put("domainCnt", domainCnt);
                data.put("fb_count", fbCount);
                data.put("ib_count", ibCount);
                data.put("dc_count", dcCount);
                data.put("objDCCount", objDCCount);
                data.put("serverCount", serverCount);
                data.put("dc_list", dcList);
                data.put("server_list", serversList);
                data.put("size", size);
                data.put("bmrCount", bmrCount);
                data.put("flbCount", flbCount);
                data.put("vlbCount", vlbCount);
                data.put("bmrArray", bmrArray);
                data.put("flbArray", flbArray);
                data.put("vlbArray", vlbArray);
                dataArray.put(data);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataArray;
    }

    public static void loadDefaultRepository() {
        try {
            DataObject dobj = CommonUtil.getPersistence().get(TableName.BMR_BACKUP_STORAGE, (Criteria) null);
            Iterator iter = dobj.getRows(TableName.BMR_BACKUP_STORAGE, (Criteria) null);

            if (!dobj.isEmpty()) {
                while (iter.hasNext()) {
                    String repoName, repoPath, repoUser, repoPass;
                    Long repositoryId = null;
                    boolean isLocal = false;
                    Row row = (Row) iter.next();
                    repoUser = (String) row.get("USER_NAME");
                    repoPath = (String) row.get("LOCATION");
                    repoPass = (String) row.get("PASSWORD");
                    repoName = "Backup Storage"; //No I18N
                    String repo = repoName;
                    int rand = 0;
                    while (true) {
                        rand++;
                        Persistence per = CommonUtil.getPersistence();
                        Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_STORAGE_REPOSITORY, "REPOSITORY_NAME"), repoName, QueryConstants.EQUAL, false);
                        criteria = criteria.and(new Criteria(Column.getColumn(TableName.RMP_STORAGE_REPOSITORY, "IS_DELETED"), false, QueryConstants.EQUAL));
                        DataObject dObject = per.get(TableName.RMP_STORAGE_REPOSITORY, criteria);
                        if (!dObject.isEmpty()) {
                            repoName = repo + '_' + rand;
                        } else {
                            break;
                        }
                    }

                    JSONObject isSuccess = VMRepositoryServer.validateBackupRepository(repoPath, repoUser, repoPass, isLocal);

                    if (isSuccess.get("retVal").toString().equals("Success")) {
                        //JSONObject status = new JSONObject();
                        String freeSpace = Integer.parseInt(isSuccess.get("freespace").toString()) + " GB";//No I18N
                        String capacity = Integer.parseInt(isSuccess.get("capacity").toString()) + " GB";//No I18N
                        Long backupSize = Long.parseLong(isSuccess.get("backupSize").toString());
                        JSONObject status = VMRepositoryServer.createBackupRepository(repoName, repoPath, repoUser, repoPass, freeSpace, capacity, backupSize, isLocal);
                        if (status.has("repositoryid")) {
                            LogWriter.bmr.info("BMR default Repository added successfully");//No I18N
                        } else {
                            LogWriter.bmr.info("BMR default Repository addition failed");//No I18N
                        }
                    } else {
                        //JSONObject status = new JSONObject();
                        String freeSpace = "0 GB";//No I18N
                        String capacity = "0 GB";//No I18N
                        Long backupSize = 0L;
                        JSONObject status = VMRepositoryServer.createBackupRepository(repoName, repoPath, repoUser, repoPass, freeSpace, capacity, backupSize, isLocal);
                        if (status.has("repositoryid")) {
                            LogWriter.bmr.info("BMR default Repository added successfully");//No I18N
                        } else {
                            LogWriter.bmr.info("BMR default Repository addition failed");//No I18N
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateOldBackupSize() {
        try {
            DataObject dObject = CommonUtil.getPersistence().get(TableName.BMR_TOTAL_BACKUP_DETAILS, (Criteria) null);
            if (!dObject.isEmpty()) {
                Iterator iterator = dObject.getRows(TableName.BMR_TOTAL_BACKUP_DETAILS);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    double size = (double) row.get("SIZE");
                    long dcId = (long) row.get("DC_ID");
                    size = size * 1024 * 1024 * 1024;
                    Criteria idCriteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
                    UpdateQuery query = new UpdateQueryImpl(TableName.BMR_TOTAL_BACKUP_DETAILS);
                    query.setUpdateColumn("SIZE", size); //No I18N
                    query.setCriteria(idCriteria);
                    CommonUtil.getPersistence().update(query);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static boolean compareFilesConfiguredAndPrevBackupFiles(Long dcId) {
        boolean ret = false;
        Set<String> configuredFileSet = new HashSet<>();
        Set<String> prevBackupFileSet = new HashSet<>();
        try {
            Criteria scheduleCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            DataObject dObject = CommonUtil.getPersistence().get(TableName.BMR_BACKUP_SCHEDULE, scheduleCriteria);
            if (!dObject.isEmpty()) {
                Row row = (Row) dObject.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
                JSONArray filesToBackup = new JSONArray((String) row.get("FILES_TO_BACKUP"));
                for (int i = 0; i < filesToBackup.length(); i++) {
                    JSONObject object = (JSONObject) filesToBackup.get(i);
                    String fileName = (String) object.get("folderUncPath");
                    String temp = "";
                    if (fileName.endsWith("\\")) {
                        temp = fileName.substring(1, (fileName.length() - 1));
                    } else {
                        temp = fileName.substring(1);
                    }
                    String path = temp.replaceFirst("\\$", ":");
                    configuredFileSet.add(path);
                }
            }
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            Criteria dcIdCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            Criteria backupTypeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "BACKUP_TYPE"), "FB", QueryConstants.EQUAL);
            Criteria statCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "STATUS"), "Completed", QueryConstants.EQUAL, false);
            Criteria criteria = dcIdCriteria.and(backupTypeCriteria.and(statCriteria));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", false)); //NO I18N
            query.setCriteria(criteria);
            DataObject dataObject = CommonUtil.getPersistence().get(query);
            if (!dataObject.isEmpty()) {
                Row row1 = (Row) dataObject.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                JSONArray partitionInfo = new JSONArray((String) row1.get("PARTITIONS_INFO"));
                for (int i = 0; i < partitionInfo.length(); i++) {
                    JSONObject jObject = (JSONObject) partitionInfo.get(i);
                    String fileName = (String) jObject.get("name");
                    prevBackupFileSet.add(fileName);
                }
            }
            int sLength = configuredFileSet.size();
            int bLength = prevBackupFileSet.size();
            if (sLength != bLength) {
                ret = true;
            } else if (configuredFileSet.containsAll(prevBackupFileSet)) {
                ret = false;
            } else {
                ret = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    public static JSONArray compareFilesConfiguredAndBackedUp(JSONArray allPartitions, Set configuredFileSet) {
        Set<String> fileAllPartitionSet = new HashSet<>();
        try {
            for (int j = 0; j < allPartitions.length(); j++) {
                JSONObject obj = (JSONObject) allPartitions.get(j);
                String fileName = (String) obj.get("name");
                fileAllPartitionSet.add(fileName);
            }
            int configuredFileSetLength = configuredFileSet.size();
            int fileAllPartitionSetLength = fileAllPartitionSet.size();
            if (configuredFileSetLength != fileAllPartitionSetLength) {
                Iterator<String> itr = configuredFileSet.iterator();
                while (itr.hasNext()) {
                    String file = itr.next();
                    if (!fileAllPartitionSet.contains(file)) {
                        JSONObject obj = new JSONObject();
                        obj.put("name", file);
                        obj.put("type", "File");
                        obj.put("status", "Not modified");
                        allPartitions.put(obj);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return allPartitions;
    }

    public static JSONArray compareDrivesAndFiles(JSONArray allPartitions, List driveList, Set configuredFileSet) {
        try {
            int driveListLength = driveList.size();
            Iterator<String> itr = configuredFileSet.iterator();
            while (itr.hasNext()) {
                String file = itr.next();
                for (int j = 0; j < driveListLength; j++) {
                    String drive = driveList.get(j).toString();
                    if (file.startsWith(drive)) {
                        JSONObject obj = new JSONObject();
                        obj.put("name", file);
                        obj.put("type", "File");
                        obj.put("status", "Failed");
                        allPartitions.put(obj);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return allPartitions;
    }

    public static String getAgentInstallationStatus(long dcId, long domainId) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria.and(domainCriteria));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
            return (String) row.get("STATUS");
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getInstalledAgentGUID(long dcId, long domainId) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "*"));
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria.and(domainCriteria));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_DOMAIN_CONTROLLERS);
            return (String) row.get("AGENT_GUID");
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getLatestAgentGUID(String name) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.ADS_AGENT_CONFIGURATION));
            query.addSelectColumn(Column.getColumn(TableName.ADS_AGENT_CONFIGURATION, "*"));
            Criteria nameCriteria = new Criteria(Column.getColumn(TableName.ADS_AGENT_CONFIGURATION, "AGENT_NAME"), name, QueryConstants.EQUAL);
            query.setCriteria(nameCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.ADS_AGENT_CONFIGURATION);
            return (String) row.get("AGENT_GUID");
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static long getLatestBackupId(long dcId) {
        try {
            long opId = 0L;
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", false));//NO I18N
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
            opId = (long) row.get("OPERATION_ID");
            return opId;
        } catch (Exception e) {
            e.printStackTrace();
            return 0L;
        }
    }

    public static long getLatestRestoreId(long dcId) {
        try {
            long opId = 0L;
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "*"));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "START_TIME", false));//NO I18N
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS);
            opId = (long) row.get("OPERATION_ID");
            return opId;
        } catch (Exception e) {
            e.printStackTrace();
            return 0L;
        }
    }

    public static long getFullBackupId(long dcId, boolean value) {
        try {
            long opId = 0L;
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", value));//NO I18N
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Iterator iterator = dobj.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    String type = (String) row.get("BACKUP_TYPE");
                    if (type.equals("FB")) {
                        opId = (long) row.get("OPERATION_ID");
                        break;
                    }
                }
            }
            return opId;
        } catch (Exception e) {
            e.printStackTrace();
            return 0L;
        }
    }

    public static Criteria getBackupFilterCriteria(Long dcId) {
        Criteria backupFilterCriteria = null;

        try {
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "*"));
            selectQuery.setCriteria(new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcId, QueryConstants.EQUAL));
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if (!dataObject.isEmpty()) {
                Row row = dataObject.getFirstRow(TableName.BMR_DOMAIN_CONTROLLERS);
                Timestamp backupFilterTime = (Timestamp) row.get("BACKUP_FILTER_TIME");
                int licenseType = (int) row.get("IS_LICENSED");
                if (licenseType == LicenseType.Unlicensed.ordinal()) {
                    return backupFilterCriteria;
                }
                if (licenseType == LicenseType.Licensed.ordinal() && backupFilterTime != null) {
                    backupFilterCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME"), backupFilterTime, QueryConstants.GREATER_THAN);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return backupFilterCriteria;
    }

    public static Properties getFullBackupDetails(long dcId, boolean value) {
        Properties details = new Properties();
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", value));//NO I18N
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            Criteria backupFilterCriteria = getBackupFilterCriteria(dcId);
            if (backupFilterCriteria != null) {
                query.setCriteria(criteria.and(backupFilterCriteria));
            } else {
                query.setCriteria(criteria);
            }
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Iterator iterator = dobj.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    String type = (String) row.get("BACKUP_TYPE");
                    if (type.equals("FB")) {
                        details.put("OpId", row.get("OPERATION_ID").toString());
                        details.put("Mode", (String) row.get("BACKUP_MODE"));
                        details.put("Status", (String) row.get("STATUS"));
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    public static String getPrevBackupStatus(long dcId) {
        String status = "";
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", false));//NO I18N
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            Criteria modeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "BACKUP_MODE"), "BMR", QueryConstants.EQUAL);
            query.setCriteria(criteria.and(modeCriteria));
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Row row = (Row) dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                status = (String) row.get("STATUS");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    public static Properties getBackupFolder(long opId) {
        Properties details = new Properties();
        String fullBackupFolder = null;
        long repositoryId = -1;
        String repositoryPath = null;
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                repositoryId = (long) row.get("REPOSITORY_ID");
                long dcId = (long) row.get("DC_ID");
                String dcName = getNameFromId(dcId);
                JSONObject repositoryObj = VMRepositoryServer.getBackupRepository(repositoryId).getJSONObject("selectedValue");
                repositoryPath = repositoryObj.get("REPOSITORY_PATH").toString();
                String backupFolder = (String) row.get("BACKUP_FOLDER");
                String backupMode = (String) row.get("BACKUP_MODE");
                if (backupMode.equalsIgnoreCase("OLD BMR")) {
                    fullBackupFolder = repositoryPath + "\\" + backupFolder;//NO I18N
                } else {
                    fullBackupFolder = repositoryPath + "\\" + dcName + "\\" + backupFolder;//NO I18N
                }
                details.put("Location", repositoryPath);
                details.put("folder", backupFolder);
                details.put("backupFolder", fullBackupFolder);
                details.put("User", repositoryObj.get("REPOSITORY_USERNAME").toString());
                details.put("Password", repositoryObj.get("REPOSITORY_PASSWORD").toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    public static double getBackupSize(long opId) {
        try {
            double size = 0f;

            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
            size = (double) row.get("SIZE");
            return size;
        } catch (Exception e) {
            e.printStackTrace();
            return 0f;

        }
    }

    public static long getIBParentId(long ibId) {
        try {
            long fbId = 0L;
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INCREMENTAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INCREMENTAL_BACKUP_DETAILS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INCREMENTAL_BACKUP_DETAILS, "IB_ID"), ibId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Row row = dobj.getFirstRow(TableName.BMR_INCREMENTAL_BACKUP_DETAILS);
                fbId = (long) row.get("FB_ID");
            }
            return fbId;
        } catch (Exception e) {
            e.printStackTrace();
            return 0L;
        }
    }

    public static boolean isFullBackup(long opId) {
        boolean result = false;
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
            String type = (String) row.get("BACKUP_TYPE");
            if (type.equals("FB")) {
                result = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static String getBackupMode(long opId) {
        String mode = "";
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                mode = (String) row.get("BACKUP_MODE");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mode;
    }

    public static JSONObject getNextScheduleRuntime(long dcId) {
        JSONObject list = new JSONObject();
        String time = "";
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
            long fbScheduleId = (long) row.get("FB_SCHEDULE_ID");
            long ibScheduleId = (long) row.get("IB_SCHEDULE_ID");
            boolean isIbRequired = (ibScheduleId == 0) ? false : true;
            SimpleDateFormat timestampFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");// No I18N
            Timestamp nextFullBackup = new Timestamp(ScheduleManager.getActualScheduleTime(fbScheduleId));
            Timestamp nextIncrBackup = null;

            if (isIbRequired) {
                nextIncrBackup = new Timestamp(ScheduleManager.getActualScheduleTime(ibScheduleId));

                if (nextFullBackup.before(nextIncrBackup)) {
                    time = timestampFormat.format(nextFullBackup);
                    list.put("type", "Full");
                } else {
                    time = timestampFormat.format(nextIncrBackup);
                    list.put("type", "Incremental");
                }
            } else {
                time = timestampFormat.format(nextFullBackup);
                list.put("type", "Full");
            }
            list.put("time", time);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return list;
    }

    public static JSONArray getIndividualBackupDetailsFromTO(JSONObject obj, Criteria criteria) {
        JSONArray dataArray = new JSONArray();
        try {
            SimpleDateFormat timestampFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");// No I18N
            String fromDateString = obj.get("f").toString();
            String toDateString = obj.get("t").toString();
            boolean value = (boolean) obj.get("value");
            Integer offset = obj.getInt("offset") * 60000; // No I18N
            int count = (int) obj.get("count");
            DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy"); // No I18N
            Date fromDate = dateFormat.parse(fromDateString);
            Date toDate = dateFormat.parse(toDateString);
            fromDate = new Date(fromDate.getTime() /*+ offset*/);
            toDate = new Date(toDate.getTime() /*+ offset*/);
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            if (value) {
                query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", false));//NO I18N
            } else {
                query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", true));//NO I18N
            }
            Criteria fromDateCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME"), fromDate, QueryConstants.GREATER_EQUAL);
            Criteria toDateCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME"), toDate, QueryConstants.LESS_EQUAL);
            if (count != 0) {
                query.setCriteria(criteria.and(fromDateCriteria).and(toDateCriteria));
            } else {
                query.setCriteria(criteria);
            }
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Iterator iterator = dobj.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    JSONObject data = new JSONObject();
                    String time = timestampFormat.format((Timestamp) row.get("START_TIME"));
                    data.put("date", time);
                    long dcId = (long) row.get("DC_ID");
                    long repoId = (long) row.get("REPOSITORY_ID");
                    JSONObject repoObject = VMRepositoryServer.getBackupRepository(repoId).getJSONObject("selectedValue");
                    String repoName = repoObject.get("REPOSITORY_NAME").toString();
                    data.put("dcId", (long) row.get("DC_ID"));
                    data.put("repoName", repoName);
                    data.put("time", (Long) row.get("TIME_TAKEN"));
                    data.put("size", (double) row.get("SIZE"));
                    data.put("mode", (String) row.get("BACKUP_MODE"));
                    data.put("type", (String) row.get("BACKUP_TYPE"));
                    data.put("opId", (long) row.get("OPERATION_ID"));
                    data.put("status", (String) row.get("STATUS"));
                    data.put("initiator", (String) row.get("INITIATOR"));
                    dataArray.put(data);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataArray;
    }

    public static JSONArray getIndividualBackupDetails(JSONObject obj, Criteria criteria) {
        JSONArray dataArray = new JSONArray();
        try {
            SimpleDateFormat timestampFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");// No I18N
            boolean value = (boolean) obj.get("value");
            int count = (int) obj.get("count");
            Calendar cal = Calendar.getInstance();
            Date startDate = cal.getTime();
            Timestamp endTime = DateUtil.getTimestampFromDate(startDate);
            cal.add(Calendar.DATE, -count);
            Date endDate = cal.getTime();
            Timestamp startTime = DateUtil.getTimestampFromDate(endDate);
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            if (value) {
                query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", false));//NO I18N
            } else {
                query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", true));//NO I18N
            }
            Criteria startCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME"), startTime, QueryConstants.GREATER_EQUAL);
            Criteria endCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME"), endTime, QueryConstants.LESS_EQUAL);
            if (count != 0) {
                query.setCriteria(criteria.and(startCriteria).and(endCriteria));
            } else {
                query.setCriteria(criteria);
            }
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Iterator iterator = dobj.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    JSONObject data = new JSONObject();
                    String time = timestampFormat.format((Timestamp) row.get("START_TIME"));
                    data.put("date", time);
                    data.put("time", (Long) row.get("TIME_TAKEN"));
                    long dcId = (long) row.get("DC_ID");
                    long repoId = (long) row.get("REPOSITORY_ID");
                    JSONObject repoObject = VMRepositoryServer.getBackupRepository(repoId).getJSONObject("selectedValue");
                    String repoName = repoObject.get("REPOSITORY_NAME").toString();
                    data.put("dcId", (long) row.get("DC_ID"));
                    data.put("repoName", repoName);
                    data.put("size", (double) row.get("SIZE"));
                    data.put("mode", (String) row.get("BACKUP_MODE"));
                    data.put("type", (String) row.get("BACKUP_TYPE"));
                    data.put("opId", (long) row.get("OPERATION_ID"));
                    data.put("status", (String) row.get("STATUS"));
                    data.put("initiator", (String) row.get("INITIATOR"));
                    dataArray.put(data);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataArray;
    }

    public static JSONArray getIndividualBackupDetailsByCount(JSONObject obj, Criteria criteria) {
        JSONArray dataArray = new JSONArray();
        try {
            SimpleDateFormat timestampFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");// No I18N
            boolean value = (boolean) obj.get("value");
            int count = (int) obj.get("count");
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            if (value) {
                query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", false));//NO I18N
            } else {
                query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", true));//NO I18N
            }
            query.setCriteria(criteria);

            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Iterator iterator = dobj.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                for (int i = 0; i < count; i++) {
                    if (iterator.hasNext()) {
                        Row row = (Row) iterator.next();
                        JSONObject data = new JSONObject();
                        String time = timestampFormat.format((Timestamp) row.get("START_TIME"));
                        data.put("date", time);
                        long dcId = (long) row.get("DC_ID");
                        long repoId = (long) row.get("REPOSITORY_ID");
                        JSONObject repoObject = VMRepositoryServer.getBackupRepository(repoId).getJSONObject("selectedValue");
                        String repoName = repoObject.get("REPOSITORY_NAME").toString();
                        data.put("dcId", (long) row.get("DC_ID"));
                        data.put("repoName", repoName);
                        data.put("time", (Long) row.get("TIME_TAKEN"));
                        data.put("size", (double) row.get("SIZE"));
                        data.put("type", (String) row.get("BACKUP_TYPE"));
                        data.put("mode", (String) row.get("BACKUP_MODE"));
                        data.put("opId", (long) row.get("OPERATION_ID"));
                        data.put("status", (String) row.get("STATUS"));
                        data.put("initiator", (String) row.get("INITIATOR"));
                        dataArray.put(data);
                    } else {
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataArray;
    }

    public static JSONArray getRestorePoints(Criteria criteria) {
        JSONArray dataArray = new JSONArray();
        try {
            SimpleDateFormat timestampFormat = new SimpleDateFormat("dd MMM yyyy, HH:mm");// No I18N
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", true));//NO I18N
            query.setCriteria(criteria);

            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Iterator iterator = dobj.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    JSONObject data = new JSONObject();
                    String time = timestampFormat.format((Timestamp) row.get("START_TIME"));
                    String type = (String) row.get("BACKUP_TYPE");
                    String mode = (String) row.get("BACKUP_MODE");
                    long opId = (long) row.get("OPERATION_ID");
                    String backup = null;
                    if (mode.equals("BMR")) {
                        backup = " (Bare metal)";//No I18N
                    } else if (mode.equals("VLR")) {
                        backup = " (Volume Level)";//No I18N
                    } else {
                        backup = " (File Level)";//No I18N
                    }
                    data.put("date", time + backup);
                    data.put("id", opId);
                    data.put("type", type);
                    dataArray.put(data);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataArray;
    }

    public static JSONArray getPartitionDetails(JSONObject obj, Criteria criteria) {

        try {
            boolean value = (boolean) obj.get("value");
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            if (value) {
                query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", false));//NO I18N
            } else {
                query.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", true));//NO I18N
            }
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                JSONArray dataArray = new JSONArray((String) row.get("PARTITIONS_INFO"));
                return dataArray;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }

    public static List<String> getConfiguredDomains(Criteria criteria) {
        List<String> domainList = new ArrayList<String>();
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_DETAILS, "*"));
            if (criteria != null) {
                query.setCriteria(criteria);
            }
            DataObject obj = CommonUtil.getPersistence().get(query);
            Iterator iterator = obj.getRows(TableName.BMR_DOMAIN_DETAILS);
            while (iterator.hasNext()) {
                Row domain = (Row) iterator.next();
                domainList.add((String) domain.get("DOMAIN_NAME"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return domainList;
    }

    public static void checkStatusAtStart() {
        try {
            ArrayList<Long> operationIDsRestore = updateOperationStatus(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS);
            ArrayList<Long> operationIDsBackup = updateOperationStatus(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
            for (Long operationID : operationIDsBackup) {
                JSONObject mailData = MailInfoBMR.setBMRBackupMailInfo(operationID);
                LogWriter.general.info("Mail: Calling NotificationAPI.notifyBMR() from BMRDatabase.checkStatusAtStart()"); // No I18N
                NotificationAPI.notifyBMR(NotificationType.BMRBackup, mailData);
            }
            for (Long operationID : operationIDsRestore) {
                JSONObject mailData = MailInfoBMR.setBMRRestoreMailInfo(operationID);
                LogWriter.general.info("Mail: Calling NotificationAPI.notifyBMR() from BMRDatabase.checkStatusAtStart()"); // No I18N
                NotificationAPI.notifyBMR(NotificationType.BMRRestore, mailData);
            }
            setDLLDetails(false);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Long> updateOperationStatus(String tableName) {
        ArrayList<Long> operationIDs = new ArrayList<Long>();

        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(tableName));
            query.addSelectColumn(Column.getColumn(tableName, "*"));
            Criteria criteria = new Criteria(Column.getColumn(tableName, "STATUS"), "Started", QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Iterator iterator = dobj.getRows(tableName);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    row.set("STATUS", "Application Interrupted");// No I18N
                    dobj.updateRow(row);
                    operationIDs.add((Long) row.get("OPERATION_ID"));  // No I18N
                }
                CommonUtil.getPersistence().update(dobj);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return operationIDs;
    }

    public static void updateInterruptedBackupStatus(String dcName, long backupId, String domain) {
        try {
            long operationId = BMRDatabase.getLatestBackupId(backupId);
            Properties details = BMRDatabase.getBackupFolder(operationId);
            String loc = details.get("Location").toString();
            String name = details.get("User").toString();
            String pwd = details.get("Password").toString();
            String folder = details.get("folder").toString();
            String buFolder = details.get("backupFolder").toString();
            String buFile = buFolder + "\\BackupDetails.txt";//NO I18N
            JSONArray partitions = new JSONArray();
            Properties props = RMPNativeManager.checkCredentials(loc, name, pwd, "connect");//NO I18N
            LogWriter.bmr.info("checkCredentials in updateInterruptedBackupStatus: " + props);//NO I18N
            if (props.get("Success") != null) {
                File checkFile = new File(buFile);
                if (checkFile.exists()) {
                    File newFile = new File(buFolder + "\\BackupDetails1.txt");
                    boolean success = checkFile.renameTo(newFile);
                    if (success) {
                        newFile.renameTo(checkFile);
                        readBackupDetails(dcName, backupId, domain);
                    } else {
                        updateBackupStatus(backupId, "In Progress");//NO I18N
                    }
                } else {
                    LogWriter.bmr.severe("BackupDetails file does not exist in the specified location");//NO I18N
                    updateIndividualBackupDetails(operationId, 0f, partitions, folder, "Failed", 0L);//NO I18N
                    JSONObject mailData = MailInfoBMR.setBMRBackupMailInfo(operationId);
                    NotificationAPI.notifyBMR(NotificationType.BMRBackup, mailData);
                }
                Properties disconnectProps1 = RMPNativeManager.checkCredentials(loc, name, pwd, "disconnect");//NO I18N
            } else {
                if(props.get("Invalid_Password")!=null || props.get("Logon_Failure") != null){
                    LogWriter.bmr.info("In updateInterruptedBackupStatus checkCredentials failed...Invalid password");//NO I18N
                    updateIndividualBackupDetails(operationId, 0f, partitions, folder, "Failed (Access denied to the repository)", 0L);//NO I18N
                } else {
                    LogWriter.bmr.info("In updateInterruptedBackupStatus checkCredentials failed");//NO I18N
                    updateIndividualBackupDetails(operationId, 0f, partitions, folder, "Failed (Location inaccessible)", 0L);//NO I18N
                }
                JSONObject mailData = MailInfoBMR.setBMRBackupMailInfo(operationId);
                NotificationAPI.notifyBMR(NotificationType.BMRBackup, mailData);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateInterruptedRestoreStatus(final String dcName, long backupId, String domain, final long backupOpId, long operationId, String folderTime) {
        try {
            String downloadPath = "";
            String initiator = "";
            long restoreOptionTemp = 0L;
            int restoreOption = 0;
            String filesToRestore = "";
            final String type;
            Set<String> configuredFileSet = new HashSet<>();
            Criteria idCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "OPERATION_ID"), operationId, QueryConstants.EQUAL);
            DataObject dataObject = CommonUtil.getPersistence().get(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, idCriteria);
            Row row = (Row) dataObject.getFirstRow(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS);
            type = (String) row.get("RESTORE_TYPE");
            filesToRestore = (String) row.get("FILES_TO_RESTORE");
            if (type.equals("FLR")) {
                downloadPath = (String) row.get("DOWNLOAD_PATH");
                restoreOptionTemp = (long) row.get("RESTORE_OPTION");
                restoreOption = (int) restoreOptionTemp;
                initiator = (String) row.get("INITIATOR");
                if (restoreOption == 2) {
                    if (downloadPath.startsWith("\\\\")) {
                        JSONObject ret = validatePath(downloadPath, "-", "-", false);
                        String retVal = (String) ret.get("retVal");
                        LogWriter.bmr.info("validatePath returns: " + retVal);//NO I18N
                        if (!retVal.equals("Success")) {
                            String errMsg = "";
                            if (retVal.indexOf(":") != -1) {
                                errMsg = "Could not connect to \"Copy to\" path";//NO I18N
                            } else {
                                errMsg = "Write/modify access denied";//NO I18N
                            }
                            FLRDatabase.updateRestStatus(operationId, "Failed (" + errMsg + ")");//NO I18N
                            return;
                        }
                    }
                }
            }
            if (type.equals("VLR")) {
                JSONArray filesToRestoreArray = new JSONArray(filesToRestore);
                for (int len = 0; len < filesToRestoreArray.length(); len++) {
                    JSONObject pathObj = (JSONObject) filesToRestoreArray.get(len);
                    String folderPath = (String) pathObj.get("folderPath");
                    String displayPath = (String) pathObj.get("folderUncPath");
                    if (displayPath.endsWith("\\")) {
                        displayPath = displayPath.substring(0, (displayPath.length() - 1));
                    }
                    configuredFileSet.add(displayPath);
                }
                Properties restoreLocDetails = null;
                JSONArray partitions = new JSONArray();
                if (BMRDatabase.isFullBackup(backupOpId)) {
                    restoreLocDetails = BMRDatabase.getBackupFolder(backupOpId);
                } else {
                    long opId = getIBParentId(backupOpId);
                    restoreLocDetails = BMRDatabase.getBackupFolder(getIBParentId(backupOpId));
                }
                String loc = restoreLocDetails.get("Location").toString();
                String restoreLoc = restoreLocDetails.get("backupFolder").toString();
                String restoreUname = restoreLocDetails.get("User").toString();
                String restorePwd = restoreLocDetails.get("Password").toString();
                String restoreFilePath;
                String restoreFolder = "restoreDetails_" + folderTime + ".txt"; //No I18N
                restoreFilePath = restoreLoc + "\\" + restoreFolder;
                Properties props = RMPNativeManager.checkCredentials(loc, restoreUname, restorePwd, "connect");//NO I18N
                LogWriter.bmr.info("checkCredentials in updateInterruptedRestoreStatus: " + props);//NO I18N
                if (props.get("Success") != null) {
                    File checkFile = new File(restoreFilePath);
                    if (checkFile.exists()) {
                        File newFile = new File(restoreLoc + "\\BackupDetails1.txt");
                        boolean success = checkFile.renameTo(newFile);
                        if (success) {
                            newFile.renameTo(checkFile);
                            JSONObject retObj = FLRDatabase.readRestoreDetails(dcName, domain, restoreFilePath, operationId, type, configuredFileSet, null);
                            String status = (String) retObj.get("status");
                            Long totalTime = (Long) retObj.get("totalTime");
                            JSONArray allPartitions = (JSONArray) retObj.get("allPartitions");
                            FLRDatabase.updateRestoreStatus(operationId, status, totalTime, allPartitions);
                            JSONObject mailData = MailInfoBMR.setBMRRestoreMailInfo(operationId);
                            NotificationAPI.notifyBMR(NotificationType.BMRRestore, mailData);
                        } else {
                            FLRDatabase.updateRestStatus(operationId, "In Progress");//NO I18N
                        }
                    } else {
                        LogWriter.bmr.severe("restoreDetails file does not exist in the specified location");//NO I18N
                        FLRDatabase.updateRestStatus(operationId, "Failed");//NO I18N
                        JSONObject mailData = MailInfoBMR.setBMRRestoreMailInfo(operationId);
                        NotificationAPI.notifyBMR(NotificationType.BMRRestore, mailData);
                    }
                } else {
                    if(props.get("Invalid_Password")!=null || props.get("Logon_Failure") != null){
                        LogWriter.bmr.info("In updateInterruptedRestoreStatus checkCredentials failed...Invalid password");//NO I18N
                        FLRDatabase.updateRestStatus(operationId, "Failed (Access denied to the repository)");//NO I18N
                    } else {
                        LogWriter.bmr.info("In updateInterruptedRestoreStatus checkCredentials failed..");//NO I18N
                        FLRDatabase.updateRestStatus(operationId, "Failed (Location inaccessible)");//NO I18N
                    }
                    JSONObject mailData = MailInfoBMR.setBMRRestoreMailInfo(operationId);
                    NotificationAPI.notifyBMR(NotificationType.BMRRestore, mailData);
                }
            } else {

                //final BMRThreadManager manager = BMRThreadManager.getBMRThreadManager();
                //manager.clearData();
                JSONObject retObj = preMergeAndMount(dcName, backupId, type, backupOpId);
                JSONObject mountRetObj = retObj.getJSONObject("mountRetVal");
                String mergeRetVal = (String) retObj.get("mergeRetVal");
                JSONArray drivesList;
                /*if(mergeRetVal.isEmpty() || mountRetVal.isEmpty()) {
                 manager.clearData();
                 }*/
                JSONObject jObj = new JSONObject();
                jObj.put("filesToRestore", filesToRestore);
                jObj.put("mergeFolder", mergeRetVal);
                jObj.put("drivesList", mountRetObj.getBoolean("isSuccessful") ? mountRetObj.getJSONArray("successfulDriveLetters") : new JSONArray());
                jObj.put("domain", domain);
                jObj.put("dc", dcName);
                jObj.put("dcId", backupId);
                jObj.put("type", type);
                jObj.put("restorePtId", (int) backupOpId);
                jObj.put("downloadPath", downloadPath);
                jObj.put("restoreOption", restoreOption);
                jObj.put("operationId", (int) operationId);
                jObj.put("initiator", initiator);
                JSONObject retRestoreNow = FLRDatabase.restoreNow(jObj);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean getInterruptedVLRdetails(String dcName, long dcId, String domainName) {
        boolean success = false;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy_HH.mm.ss"); //No I18N
            long backupOpId, restoreOpId;
            String folderTime;
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            Criteria typeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "RESTORE_TYPE"), "VLR", QueryConstants.EQUAL);
            Criteria statusCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "STATUS"), "Application Interrupted", QueryConstants.EQUAL);
            Criteria statusCriteria2 = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "STATUS"), "In Progress", QueryConstants.EQUAL);
            Criteria criteria = dcCriteria.and(typeCriteria.and(statusCriteria.or(statusCriteria2)));
            DataObject dObject = CommonUtil.getPersistence().get(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, criteria);
            if (!dObject.isEmpty()) {
                Row row = (Row) dObject.getFirstRow(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS);
                backupOpId = (long) row.get("BACKUP_POINT");
                String timeFolder = dateFormat.format((Timestamp) row.get("START_TIME"));
                restoreOpId = (long) row.get("OPERATION_ID");
                updateInterruptedRestoreStatus(dcName,dcId,domainName,backupOpId,restoreOpId,timeFolder);
                success = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }

    public static JSONObject preMergeAndMount(final String dcName, final long dcId, final String type, final long backupOpId) {
        JSONObject retObj = new JSONObject();
        final BMRThreadManager manager = BMRThreadManager.getBMRThreadManager(); //mod
        try {
            boolean isFB = BMRDatabase.isFullBackup(backupOpId);
            final String origBackupType = BMRDatabase.getBackupTypeFromOpId(backupOpId);

            int mountVal = type.equalsIgnoreCase("FLR") ? 2 : 1;
            manager.clearData();

            Thread mergeThread = null;
            Thread mountThread = null;

            if (origBackupType.equalsIgnoreCase("FLR")) {
                BMRDatabase.mergeBackupsThreaded(backupOpId, dcName, dcId);
            } else if (!isFB) {
                mergeThread = new Thread() {
                    @Override
                    public void run() {
                        BMRDatabase.mergeBackupsThreaded(backupOpId, dcName, dcId);
                    }
                };
            }

            mountThread = new Thread() {
                @Override
                public void run() {
                    try {
                        manager.setStatus("mount_" + backupOpId, BMRThreadManager.STARTED); //No I18N
                        JSONObject mountRetObj = new JSONObject();
                        String mountRetStr = "";
                        String errorMsg = "";
                        JSONArray successfulDriveLetters = new JSONArray();
                        JSONArray failedDriveLetters = new JSONArray();

                        if (origBackupType.equalsIgnoreCase("VLR") || origBackupType.equalsIgnoreCase("BMR")) {
                            Long fbId = 0L;
                            if (!BMRDatabase.isFullBackup(backupOpId)) {
                                fbId = BMRDatabase.getIBParentId(backupOpId);
                            } else {
                                fbId = backupOpId;
                            }

                            if (type.equalsIgnoreCase("VLR")) {
                                JSONArray mountDrives = new JSONArray();
                                JSONObject obj = FLRDatabase.listAllImgFiles(fbId);
                                if(!obj.has("errorMsg")) {
                                    List<File> names = (List) obj.get("names");
                                    for (int loop = 0; loop < names.size(); loop++) {
                                        String partitionName = names.get(loop).getName();
                                        String partitionNameWithoutExtn = FilenameUtils.removeExtension(partitionName);
                                        String driveLetter = Character.toString(partitionNameWithoutExtn.charAt((partitionNameWithoutExtn.length() - 1)));
                                        if (Character.isLetter(partitionNameWithoutExtn.charAt((partitionNameWithoutExtn.length() - 1)))) {
                                            JSONObject mountObj = new JSONObject();
                                            mountObj.put("value", driveLetter + ":");
                                            mountObj.put("displayName", driveLetter + ":");
                                            mountDrives.put(mountObj);
                                        }
                                    }
                                    successfulDriveLetters = mountDrives;
                                } else {
                                    errorMsg = obj.get("errorMsg").toString();
                                }
                            } else {
                                int driverStatus = RMPMountManager.checkDriverStatus();
                                if (driverStatus == 0) {
                                    mountRetStr = FLRDatabase.mountToDrive(backupOpId);
                                } else {
                                    FLRDatabase.copyFilesToInstallationFolder();
                                    driverStatus = RMPMountManager.checkDriverStatus();
                                    if (driverStatus == 0) {
                                        mountRetStr = FLRDatabase.mountToDrive(backupOpId);
                                    } else {
                                        errorMsg = "Driver not installed"; //No I18N
                                        LogWriter.bmr.severe("checkDriverStatus returned " + driverStatus);//No I18N
                                    }
                                }
                            }
                        } else if (origBackupType.equalsIgnoreCase("FLR")) {

                            if (manager.getStatus("merge") == BMRThreadManager.SUCCESS) {
                                Map<String, String> retMap = (Map) manager.getRetVal("merge"); //No I18N
                                String mergeFolder = retMap.get("mergeFolder");
                                String username = retMap.get("REPOSITORY_USERNAME");
                                String password = retMap.get("REPOSITORY_PASSWORD");

                                Properties conProps = RMPNativeManager.checkCredentials(mergeFolder, username, password, "connect");//No I18N

                                if (conProps.get("Success") != null) {
                                    JSONArray successfulArr = new JSONArray();
                                    JSONArray failedArr = new JSONArray();
                                    File partitions = new File(mergeFolder);
                                    boolean toContinue = true;

                                    File partitionFiles[] = partitions.listFiles(new FilenameFilter() {
                                        @Override
                                        public boolean accept(File current, String name) {
                                            return new File(current, name).isDirectory();
                                        }
                                    });

                                    for (File partition : partitionFiles) {
                                        boolean isMountSuccessful = false;
                                        String partitionDrive = partition.getName();
                                        String driveLetter = "";

                                        if(toContinue) {
                                            int driveLetterNo = RMPMountManager.chooseDriveLetter();
                                            if (driveLetterNo > 0 && driveLetterNo < 27) {
                                                driveLetter = String.valueOf((char) (driveLetterNo + 64));
                                                int result = RMPMountManager.mountFileLevelBackup(driveLetter + ":", partition.getAbsolutePath());
                                                if (result == 0) {
                                                    isMountSuccessful = true;
                                                }
                                            } else {
                                                toContinue = false;
                                            }
                                        }

                                        if(isMountSuccessful) {
                                            JSONObject obj = new JSONObject();
                                            obj.put("value", driveLetter + ":");
                                            obj.put("displayName", partitionDrive.charAt(partitionDrive.length() - 1) + ":");
                                            successfulArr.put(obj);
                                        } else {
                                            JSONObject obj = new JSONObject();
                                            obj.put("value", partitionDrive.charAt(partitionDrive.length() - 1) + ":");
                                            failedArr.put(obj);
                                        }
                                    }

                                    successfulDriveLetters = successfulArr;
                                    failedDriveLetters = failedArr;
                                } else {
                                    LogWriter.bmr.severe("mergeAndMountBackups: Connect to merge folder failed.");//No I18N
                                    errorMsg = "Repository password has been changed"; //No I18N
                                }

                                RMPNativeManager.checkCredentials(mergeFolder, username, password, "disconnect");//No I18N
                            } else {
                                LogWriter.bmr.severe("mergeAndMountBackups: Merge process failed. Mount process skipped.");//No I18N
                            }
                        }

                        if(!mountRetStr.isEmpty()) {
                            mountRetObj = new JSONObject(mountRetStr);
                        } else {
                            mountRetObj.put("isSuccessful", successfulDriveLetters.length()>0 ? true : false);
                            mountRetObj.put("errorMsg", errorMsg);
                            mountRetObj.put("successfulDriveLetters", successfulDriveLetters);
                            mountRetObj.put("failedDriveLetters", failedDriveLetters);
                        }

                        manager.setStatus("mount_" + backupOpId, mountRetObj.getBoolean("isSuccessful") ? BMRThreadManager.SUCCESS : BMRThreadManager.FAILED);//No I18N
                        manager.setRetVal("mount_" + backupOpId, mountRetObj.toString());//No I18N

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            };
            if (mergeThread != null) {
                mergeThread.start();
            }
            mountThread.start();
            mountThread.join();
            if (mergeThread != null) {
                mergeThread.join();
            }

            boolean isMountSuccessful = manager.getStatus("mount_"+backupOpId)==BMRThreadManager.SUCCESS; //No I18N
            JSONObject mountRetObj = new JSONObject(manager.getRetVal("mount_" + backupOpId).toString());//No I18N
            String mergeRetVal;

            if (manager.hasProcess("merge")) {
                Map retMap = (Map) manager.getRetVal("merge");//No I18N
                mergeRetVal = (String) retMap.get("mergeFolder");
            } else {
                manager.setStatus("merge", BMRThreadManager.FAILED);//No I18N
                mergeRetVal = "-";
                manager.setRetVal("merge", "-");//No I18N
            }

            if (mergeRetVal.isEmpty() || !isMountSuccessful) {
                manager.clearData();
            } else {
                FLRDatabase.markMountDismount(backupOpId, mountVal, mountRetObj.getJSONArray("successfulDriveLetters")); //No I18N
            }

            retObj.put("mergeRetVal", mergeRetVal);
            retObj.put("mountRetVal", mountRetObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return retObj;
    }

    public static void readBackupDetails(String dcName, long backupId, String domainName) {
        try {
            Properties buDetails = new Properties();
            Properties prop = RMPDomainHandler.getDomainDetailsByName(domainName);
            long domainId = Long.valueOf(prop.getProperty("DOMAIN_ID"));
            long fullBuId = 0;
            long operationId = BMRDatabase.getLatestBackupId(backupId);
            String type = "IB";//NO I18N
            String backupMode = BMRDatabase.getBackupMode(operationId);
            Set<String> configuredFileSet = new HashSet<>();
            String folderUncPath;
            if (isFullBackup(operationId)) {
                type = "FB";//NO I18N
            }
            if (type.equals("IB")) {
                Properties prevBackupDetails = BMRDatabase.getFullBackupDetails(backupId, false);
                if (!prevBackupDetails.isEmpty()) {
                    fullBuId = Long.valueOf(prevBackupDetails.getProperty("OpId"));
                }
            }
            Properties details = BMRDatabase.getBackupFolder(operationId);
            String folder = details.getProperty("folder").toString();
            String backupFolder = details.getProperty("backupFolder").toString();
            String buFile = backupFolder + "\\BackupDetails.txt";//NO I18N
            JSONArray allPartitions = new JSONArray();
            Long totalTime = 0L;
            float finalSize = 0f;
            String status = "Failed";//NO I18N
            File fin = new File(buFile);
            FileInputStream fis = new FileInputStream(fin);
            BufferedReader in = new BufferedReader(new InputStreamReader(fis));
            try {
                if (backupMode.equals("BMR")) {
                    buDetails = BMRDatabase.readFromBMRBackupDetailsFile(type, backupFolder, in);
                } else {
                    Criteria scheduleCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), backupId, QueryConstants.EQUAL);
                    DataObject dObject = CommonUtil.getPersistence().get(TableName.BMR_BACKUP_SCHEDULE, scheduleCriteria);
                    if (!dObject.isEmpty()) {
                        Row row = (Row) dObject.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
                        JSONArray selectedPaths = new JSONArray((String) row.get("FILES_TO_BACKUP"));
                        for (int len = 0; len < selectedPaths.length(); len++) {
                            JSONObject pathObj = (JSONObject) selectedPaths.get(len);
                            folderUncPath = (String) pathObj.get("folderUncPath");
                            LogWriter.bmr.info("Volume found " + folderUncPath);//NO I18N
                            String temp = "";
                            if (folderUncPath.endsWith("\\")) {
                                temp = folderUncPath.substring(1, (folderUncPath.length() - 1));
                            } else {
                                temp = folderUncPath.substring(1);
                            }
                            String path = temp.replaceFirst("\\$", ":");
                            LogWriter.bmr.info("Volume truncated " + path);//NO I18N
                            if (backupMode.equals("FLR")) {
                                configuredFileSet.add(path);
                            }
                        }
                    }
                    buDetails = FLRDatabase.readFromFLRBackupDetailsFile(type, backupFolder, in, backupMode, configuredFileSet);

                }
                status = (String) buDetails.getProperty("status");
                finalSize = Float.parseFloat((String) buDetails.getProperty("finalSize"));
                totalTime = Long.valueOf(buDetails.getProperty("totalTime"));
                allPartitions = new JSONArray((String) buDetails.getProperty("allPartitions"));
                BMRDatabase.updateIndividualBackupDetails(operationId, finalSize, allPartitions, folder, status, totalTime);
                if (type.equals("IB")) {
                    BMRDatabase.storeIncrementalBackupDetails(fullBuId, operationId);
                }
                if (finalSize > 0f) {
                    BMRDatabase.updateTotalBackupDetails(domainName, domainId, backupId, finalSize, type);
                    if (type.equals("FB") && status.equals("Completed")) {
                        if (!BMRDatabase.deleteExcessBackups(backupId, domainName)) {
                            LogWriter.bmr.info("Retention failed to delete old backups");//NO I18N
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                in.close();
                BMRDatabase.updateIndividualBackupDetails(operationId, 0f, new JSONArray(), folder, "Failed", 0L);//NO I18N
            }
            JSONObject mailData = MailInfoBMR.setBMRBackupMailInfo(operationId);
            NotificationAPI.notifyBMR(NotificationType.BMRBackup, mailData);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String checkCredentials(JSONObject obj) {
        String retVal = "";
        try {
            String user = null, pwd = null;
            user = URLDecoder.decode(GeneralUtil.replaceChar(obj, "user"), "utf-8");//No I18N
            pwd = URLDecoder.decode(GeneralUtil.replaceChar(obj, "pwd"), "utf-8");//No I18N
            String location = URLDecoder.decode(GeneralUtil.replaceChar(obj, "location"), "utf-8");//No I18N
            if (user.equals("-") || pwd.equals("-")) {
                user = null;
                pwd = null;
            }
            Properties props = RMPNativeManager.checkCredentials(location, user, pwd, "connect");// No I18N
            LogWriter.bmr.info("checkCredentials(): " + props);//NO I18N
            if (props.get("Success") != null) {
                File folder = new File(location);
                if (folder.exists()) {
                    //To avoid handling the same file, while multiple backups are scheduled at same time with same repository
                    Date tempDate = new Date();
                    Long currentmillis = tempDate.getTime();
                    File testFile = new File(location + "\\TestFile" + currentmillis + ".txt");
                    try {
                        if (!testFile.exists()) {
                            if (testFile.createNewFile() && testFile.delete()) {
                                LogWriter.bmr.info("User has both modify and write access to the folder.");//No I18N
                            } else {
                                throw new Exception();
                            }
                        } else if (testFile.delete()) {
                            if (testFile.createNewFile() && testFile.delete()) {
                                LogWriter.bmr.info("User has both modify and write access to the folder.");//No I18N
                            } else {
                                throw new Exception();
                            }
                        } else {
                            throw new Exception();
                        }
                        retVal = "Success";//No I18N
                    } catch (Exception e) {
                        Properties disconnectProps = RMPNativeManager.checkCredentials(location, user, pwd, "disconnect");// No I18N
                        LogWriter.bmr.severe("Error : The user doesn't have write or modify access on the specified folder");//No I18N
                        retVal = "Error : The user doesn't have write or modify access on the specified folder";//No I18N
                    }
                } else {
                    retVal = "Error : The specified folder is not present!";//No I18N
                }
            } else if (props.get("Access_Denied") != null) {
                retVal = "Error : Access Denied";//No I18N
            } else if (props.get("Bad_Net_Path") != null) {
                retVal = "Error : Network path was not found";//No I18N
            } else if (props.get("Bad_Net_Name") != null) {
                retVal = "Error : Network name cannot be found";//No I18N
            } else if (props.get("Invalid_Password") != null) {
                retVal = "Error : Specified network password is not correct";//No I18N
            } else if (props.get("NoNet_BadPath") != null) {
                retVal = "Error : Network path was either typed incorrectly or does not exist.Please try again.";//No I18N
            } else if (props.get("Logon_Failure") != null) {
                retVal = "Error : The user name or password is incorrect.";//No I18N
            } else if (props.get("Bad_UserName") != null) {
                retVal = "Error : Specified username is invalid.";//No I18N
            } else if (props.get("Other") != null) {
                retVal = "Error : Could not access the location due to some error.Please try again.";//No I18N
            }
            Properties disconnectProps = RMPNativeManager.checkCredentials(location, user, pwd, "disconnect");// No I18N
        } catch (Exception e) {
            e.printStackTrace();
        }
        return retVal;
    }

    public static void setDLLDetails(boolean value) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.RMP_SYSTEM_PARAMS));
            query.addSelectColumn(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "*"));
            Criteria crit = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_BMRDLL_AVAILABLE", QueryConstants.EQUAL);
            query.setCriteria(crit);
            DataObject dataobj = CommonUtil.getPersistence().get(query);
            if (dataobj.isEmpty()) {
                DataObject dobj = new WritableDataObject();
                Row row = new Row("SystemParams"); // No I18N
                row.set("PARAM_NAME", "IS_BMRDLL_AVAILABLE"); // No I18N
                row.set("PARAM_VALUE", Boolean.toString(value)); // No I18N
                dobj.addRow(row);
                Persistence per = (Persistence) BeanUtil.lookup("Persistence");
                per.add(dobj);
            } else {
                Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_BMRDLL_AVAILABLE", QueryConstants.EQUAL);
                UpdateQuery upquery = new UpdateQueryImpl(TableName.RMP_SYSTEM_PARAMS);
                upquery.setUpdateColumn("PARAM_VALUE", Boolean.toString(value)); //No I18N
                upquery.setCriteria(criteria);
                CommonUtil.getPersistence().update(upquery);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean getDLLDetails() {
        try {
            boolean value = false;
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.RMP_SYSTEM_PARAMS));
            query.addSelectColumn(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_BMRDLL_AVAILABLE", QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.RMP_SYSTEM_PARAMS);
            String paramValue = String.valueOf(row.get("PARAM_VALUE"));
            value = Boolean.parseBoolean(paramValue);
            return value;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void setNewIsoStatus(boolean value) {
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.RMP_SYSTEM_PARAMS));
            query.addSelectColumn(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "*"));
            Criteria crit = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_NEWISO_CREATED", QueryConstants.EQUAL);
            query.setCriteria(crit);
            DataObject dataobj = CommonUtil.getPersistence().get(query);
            if (dataobj.isEmpty()) {
                DataObject dobj = new WritableDataObject();
                Row row = new Row("SystemParams"); // No I18N
                row.set("PARAM_NAME", "IS_NEWISO_CREATED"); // No I18N
                row.set("PARAM_VALUE", Boolean.toString(value)); // No I18N
                dobj.addRow(row);
                Persistence per = (Persistence) BeanUtil.lookup("Persistence");
                per.add(dobj);
            } else {
                Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_NEWISO_CREATED", QueryConstants.EQUAL);
                UpdateQuery upquery = new UpdateQueryImpl(TableName.RMP_SYSTEM_PARAMS);
                upquery.setUpdateColumn("PARAM_VALUE", Boolean.toString(value)); //No I18N
                upquery.setCriteria(criteria);
                CommonUtil.getPersistence().update(upquery);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String isNewIsoStatus() {
        String value = "empty";//NO I18N
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.RMP_SYSTEM_PARAMS));
            query.addSelectColumn(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_NEWISO_CREATED", QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);

            if (dobj.isEmpty()) {
                value = "empty";//NO I18N
            } else {
                Row row = dobj.getFirstRow(TableName.RMP_SYSTEM_PARAMS);
                String paramValue = String.valueOf(row.get("PARAM_VALUE"));
                value = paramValue;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return value;
    }

    public static void deleteRow(long opId) {
        try {
            LogWriter.bmr.info("In deleteRow");//NO I18N
            Persistence per = CommonUtil.getPersistence();
            DataObject delrow = per.get(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, (Criteria) null);
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            delrow.deleteRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, criteria);
            per.update(delrow);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deleteRestoreDetailsRow(long opId) {
        try {
            LogWriter.bmr.info("In restore deleteRow");//NO I18N
            Persistence per = CommonUtil.getPersistence();
            DataObject delrow = per.get(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, (Criteria) null);
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            delrow.deleteRows(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, criteria);
            per.update(delrow);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deleteBackupEntries(long dcId) {
        try {
            DataObject dobj = CommonUtil.getPersistence().get(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, (Criteria) null);
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            dobj.deleteRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, criteria);
            CommonUtil.getPersistence().update(dobj);

            DataObject delTotalrow = CommonUtil.getPersistence().get(TableName.BMR_TOTAL_BACKUP_DETAILS, (Criteria) null);
            Criteria totalCriteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            delTotalrow.deleteRows(TableName.BMR_TOTAL_BACKUP_DETAILS, totalCriteria);
            CommonUtil.getPersistence().update(delTotalrow);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deleteUnconfiguredDCRows(String domain, long domainId) {
        try {
            LogWriter.bmr.info("In deleteUnconfiguredDCRows");//NO I18N
            Persistence per = CommonUtil.getPersistence();
            DataObject delrow = per.get(TableName.BMR_BACKUP_SCHEDULE, (Criteria) null);
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            delrow.deleteRows(TableName.BMR_BACKUP_SCHEDULE, criteria);
            per.update(delrow);
            DataObject delDomainDetailsrow = per.get(TableName.BMR_DOMAIN_DETAILS, (Criteria) null);
            Criteria domainDetailsCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_DETAILS, "DOMAIN_NAME"), domain, QueryConstants.EQUAL);
            delDomainDetailsrow.deleteRows(TableName.BMR_DOMAIN_DETAILS, domainDetailsCriteria);
            per.update(delDomainDetailsrow);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean performRetention(long oldestFullBuId, long dcId) {
        try {
            LogWriter.bmr.info("In performRetention");//NO I18N
            int newIBCnt = 0;
            float newSize = 0f;
            boolean fbResult = true, ibResult = true;
            Properties details = BMRDatabase.getBackupFolder(oldestFullBuId);
            String loc = details.get("Location").toString();
            String name = details.get("User").toString();
            String pwd = details.get("Password").toString();
            Properties props = RMPNativeManager.checkCredentials(loc, name, pwd, "connect");//No I18N
            LogWriter.bmr.info("checkCredentials Start 1 in performRetention: " + props);//NO I18N

            if (props.get("Success") != null) {
                String folder = details.getProperty("folder").toString();
                String fbFolder = details.getProperty("backupFolder").toString();
                LogWriter.bmr.info("Folder:" + folder + " ...");//NO I18N

                if (!(folder.isEmpty())) {
                    LogWriter.bmr.info("Full path to Delete:" + fbFolder + " ...");//NO I18N
                    try {
                        File fbDelete = new File(fbFolder);
                        if (fbDelete.exists()) {
                            FileUtils.deleteDirectory(fbDelete);
                            LogWriter.bmr.info("Deleted " + fbFolder);//NO I18N
                        }
                    } catch (Exception e) {
                        LogWriter.bmr.info("Failed deleting " + fbFolder);//NO I18N
                        e.printStackTrace();
                        fbResult = false;
                    }
                } else {
                    LogWriter.bmr.info("dbPath is empty...So skipping deletion...");//NO I18N
                }

                RMPNativeManager.checkCredentials(loc, name, pwd, "disconnect");//No I18N
            }

            newSize += getBackupSize(oldestFullBuId);
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INCREMENTAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_INCREMENTAL_BACKUP_DETAILS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INCREMENTAL_BACKUP_DETAILS, "FB_ID"), oldestFullBuId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if (!dobj.isEmpty()) {
                Iterator iterator = dobj.getRows(TableName.BMR_INCREMENTAL_BACKUP_DETAILS);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    long ibId = (long) row.get("IB_ID");
                    details = BMRDatabase.getBackupFolder(ibId);
                    String repoLoc = details.get("Location").toString();
                    String repoUsername = details.get("User").toString();
                    String repoPwd = details.get("Password").toString();
                    Properties prop = RMPNativeManager.checkCredentials(repoLoc, repoUsername, repoPwd, "connect");//No I18N
                    LogWriter.bmr.info("checkCredentials Start 2 in performRetention: " + prop);//NO I18N
                    if (prop.get("Success") != null) {
                        String folder = details.getProperty("folder").toString();
                        String ibFolder = details.getProperty("backupFolder").toString();
                        LogWriter.bmr.info("Folder:" + folder + " ...");//NO I18N
                        if (!(folder.isEmpty())) {
                            LogWriter.bmr.info("Full path to Delete:" + ibFolder + " ...");//NO I18N
                            try {
                                File ibDelete = new File(ibFolder);
                                if (ibDelete.exists()) {
                                    FileUtils.deleteDirectory(ibDelete);
                                    LogWriter.bmr.info("Deleted " + ibFolder);//NO I18N
                                }
                            } catch (Exception e) {
                                LogWriter.bmr.info("Failed deleting " + ibFolder);//NO I18N
                                e.printStackTrace();
                                ibResult = false;
                            }
                        } else {
                            LogWriter.bmr.info("ibPath is empty...So skipping deletion...");//NO I18N
                        }

                        RMPNativeManager.checkCredentials(repoLoc, repoUsername, repoPwd, "disconnect");//No I18N
                    }

                    double ibSize = getBackupSize(ibId);
                    if (ibSize > 0) {
                        newIBCnt++;
                        newSize += ibSize;
                    }
                    deleteRow(ibId);
                }
            }
            deleteRow(oldestFullBuId);
            SelectQueryImpl selquery = new SelectQueryImpl(Table.getTable(TableName.BMR_TOTAL_BACKUP_DETAILS));
            selquery.addSelectColumn(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
            selquery.setCriteria(dcCriteria);
            DataObject obj = CommonUtil.getPersistence().get(selquery);
            Row row = obj.getFirstRow(TableName.BMR_TOTAL_BACKUP_DETAILS);
            Integer fbCount = (Integer) row.get("FB_COUNT");
            Integer ibCount = (Integer) row.get("IB_COUNT");
            double size = (double) row.get("SIZE");
            UpdateQuery upquery = new UpdateQueryImpl(TableName.BMR_TOTAL_BACKUP_DETAILS);
            upquery.setUpdateColumn("FB_COUNT", fbCount - 1); //No I18N
            upquery.setUpdateColumn("IB_COUNT", ibCount - newIBCnt); //No I18N
            upquery.setUpdateColumn("SIZE", size - newSize); //No I18N
            upquery.setCriteria(dcCriteria);
            CommonUtil.getPersistence().update(upquery);
            if (fbResult && ibResult) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean deleteExcessBackups(long dcId, String domain) {
        try {
            LogWriter.bmr.info("In deleteExcessBackups()");//NO I18N
            boolean check = false, retVal = true;
            int retentionCnt = getRetentionCount(dcId);
            int actualCnt = getBackupCount(dcId);
            while (actualCnt > retentionCnt) {
                long oldestFullBuId = getFullBackupId(dcId, true);
                if (getBackupSize(oldestFullBuId) > 0) {
                    retVal = performRetention(oldestFullBuId, dcId);
                } else {
                    Properties details = BMRDatabase.getBackupFolder(oldestFullBuId);
                    String loc = details.get("Location").toString();
                    String name = details.get("User").toString();
                    String pwd = details.get("Password").toString();
                    Properties props = RMPNativeManager.checkCredentials(loc, name, pwd, "connect");//No I18N
                    LogWriter.bmr.info("checkCredentials in deleteExcessBackups: " + props);//NO I18N
                    if (props.get("Success") != null) {
                        String folder = details.getProperty("folder").toString();
                        String fbFolder = details.getProperty("backupFolder").toString();
                        if (!(folder.isEmpty())) {
                            LogWriter.bmr.info("Deleting " + fbFolder + " ...");//NO I18N
                            try {
                                File toDel = new File(fbFolder);
                                if (toDel.exists()) {
                                    FileUtils.deleteDirectory(new File(fbFolder));
                                    LogWriter.bmr.info("Deleted " + fbFolder);//NO I18N
                                }
                            } catch (Exception e) {
                                LogWriter.bmr.info("Failed deleting " + fbFolder);//NO I18N
                                e.printStackTrace();
                            }
                        } else {
                            LogWriter.bmr.info("deleteExcessBackups dbPath is empty...So skipping deletion...");//NO I18N
                        }

                        RMPNativeManager.checkCredentials(loc, name, pwd, "disconnect");//No I18N
                    }
                    deleteRow(oldestFullBuId);
                }
                actualCnt = getBackupCount(dcId);
            }
            if (noBackupsAvailable(domain)) {
                Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_DETAILS, "DOMAIN_NAME"), domain, QueryConstants.EQUAL);
                UpdateQuery upquery = new UpdateQueryImpl(TableName.BMR_DOMAIN_DETAILS);
                upquery.setUpdateColumn("IS_BACKUP_DONE", false); //No I18N
                upquery.setCriteria(domainCriteria);
                CommonUtil.getPersistence().update(upquery);
                LogWriter.bmr.info("IS_BACKUP_DONE set to false");//NO I18N
            }
            return retVal;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean noBackupsAvailable(String domain) {
        try {
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_TOTAL_BACKUP_DETAILS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria cntCriteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "FB_COUNT"), 0, QueryConstants.GREATER_THAN);
            boolean result = RMPCommonUtil.isTableEmpty(TableName.BMR_TOTAL_BACKUP_DETAILS, criteria.and(cntCriteria), new String[]{"DC_ID"});//No I18N
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return true;
        }
    }

    public static int createIso(final String path) {
        try {

            String startPath = System.getProperty("server.dir") + File.separator + "bin" + File.separator;// No I18N
            String wimPath = path;
            Properties result = null;
            int retVal = 1;

            if (path.equals("")) {
                result = BMRIso.updateIso(startPath);
            } else {
                result = BMRIso.createIso(startPath, wimPath);
            }
            if (result != null) {
                retVal = (int) result.get("retVal");
            }

            String mountFolder = startPath + "mount";// No I18N
            String isoFolder = startPath + "iso";    // No I18N

            FileUtils.deleteDirectory(new File(mountFolder));

            if (retVal != 0) {
                FileUtils.deleteDirectory(new File(isoFolder));
            }

            return retVal;
        } catch (Exception e) {
            e.printStackTrace();
            return 1;
        }
    }

    public static String getBackupTypeFromOpId(long opId) {
        String backupType = null;

        try {
            SelectQueryImpl selquery = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            selquery.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            Criteria opCrit = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            selquery.setCriteria(opCrit);
            DataObject obj = CommonUtil.getPersistence().get(selquery);
            if (!obj.isEmpty()) {
                Row row = obj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                backupType = (String) row.get("BACKUP_MODE");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return backupType;
    }

    public static void mergeBackupsThreaded(long opId, String dcName, long dcId) {
        try {
            BMRThreadManager manager = BMRThreadManager.getBMRThreadManager();

            manager.setStatus("merge", BMRThreadManager.STARTED); // No I18N
            Map repoMap = new HashMap();

            String folder = BMRDatabase.mergeBackups(opId, dcName, dcId);
            if (!folder.isEmpty() && !folder.equals("Repository password has been changed")) {
                String repoPath = folder.substring(0, folder.lastIndexOf("\\", folder.lastIndexOf("\\") - 1)); // No I18N
                repoMap = FLRDatabase.getRepoDetailsFromPath(repoPath);
                manager.setStatus("merge", BMRThreadManager.SUCCESS); // No I18N
            } else {
                manager.setStatus("merge", BMRThreadManager.FAILED); // No I18N
            }
            repoMap.put("mergeFolder", folder);
            String origBackupType = BMRDatabase.getBackupTypeFromOpId(opId);
            repoMap.put("origBackupType", origBackupType);
            manager.setRetVal("merge", repoMap); // No I18N
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static String mergeBackups(long ibId, String dcName, long dcId) {
        try {
            boolean isBMR;
            String backupType = getBackupTypeFromOpId(ibId);
            int queryConst = QueryConstants.GREATER_THAN;

            if (backupType.equals("BMR")) {
                isBMR = true;
            } else {
                isBMR = false;
                if (backupType.equals("FLR")) {
                    queryConst = QueryConstants.GREATER_EQUAL;
                }
            }

            String mergeFolder = "";
            long fbId = 0L;
            Properties details = BMRDatabase.getBackupFolder(ibId);
            String loc = details.get("Location").toString();
            String name = details.get("User").toString();
            String pwd = details.get("Password").toString();
            mergeFolder = loc + "\\" + dcName + "\\" + "merge";//NO I18N
            String[] exclude = new String[]{"rename_file.txt", "delete_file.txt"};//No I18N
            ArrayList<String> backups = new ArrayList<String>();
            ArrayList<String> users = new ArrayList<String>();
            ArrayList<String> pwds = new ArrayList<String>();
            if (BMRDatabase.isFullBackup(ibId)) {
                fbId = ibId;
            } else {
                fbId = getIBParentId(ibId);
            }
            Properties props = RMPNativeManager.checkCredentials(loc, name, pwd, "connect");//No I18N
            LogWriter.bmr.info("checkCredentials in mergeBackups: " + props);//NO I18N
            if (props.get("Success") != null) {
                File file = new File(mergeFolder);
                if (file.exists()) {
                    FileUtils.deleteDirectory(file);
                }
                SelectQueryImpl selquery = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
                selquery.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
                Criteria crit = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), dcId, QueryConstants.EQUAL);
                Criteria crit1 = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), fbId, queryConst);
                Criteria crit2 = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), ibId, QueryConstants.LESS_EQUAL);
                Criteria statusCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "STATUS"), "Completed", QueryConstants.EQUAL);
                selquery.setCriteria(crit.and(crit1).and(crit2).and(statusCriteria));
                selquery.addSortColumn(new SortColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME", true));//NO I18N
                DataObject obj = CommonUtil.getPersistence().get(selquery);
                if (!obj.isEmpty()) {
                    Iterator iterator = obj.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                    while (iterator.hasNext()) {
                        Row row = (Row) iterator.next();
                        long repoId = (long) row.get("REPOSITORY_ID");
                        String folder = (String) row.get("BACKUP_FOLDER");
                        JSONObject repositoryObj = VMRepositoryServer.getBackupRepository(repoId).getJSONObject("selectedValue");
                        String backupLoc = repositoryObj.get("REPOSITORY_PATH").toString();
                        String userName = repositoryObj.get("REPOSITORY_USERNAME").toString();
                        String password = repositoryObj.get("REPOSITORY_PASSWORD").toString();
                        String oldFolder = backupLoc + "\\" + dcName + "\\" + folder;//NO I18N
                        backups.add(oldFolder);
                        users.add(userName);
                        pwds.add(password);
                    }
                }
                String firstBackup = backups.get(0);
                String userName = users.get(0);
                String password = pwds.get(0);
                Properties propsFirst = RMPNativeManager.checkCredentials(firstBackup, userName, password, "connect");//No I18N
                if (propsFirst.get("Success") != null) {
                    FileUtils.copyDirectory(new File(firstBackup), new File(mergeFolder));

                    if (backups.size() > 1) {
                        for (int i = 1; i < backups.size(); i++) {
                            String nextBackup = backups.get(i);
                            userName = users.get(i);
                            password = pwds.get(i);
                            Properties propsNext = RMPNativeManager.checkCredentials(nextBackup, userName, password, "connect");//No I18N
                            if (propsNext.get("Success") != null) {
                                renameFiles(mergeFolder, nextBackup, isBMR);
                                deleteFiles(mergeFolder, nextBackup, isBMR);
                                copyBackups(nextBackup, mergeFolder);
                            } else {
                                if (propsNext.get("Invalid_Password") != null || propsNext.get("Logon_Failure") != null) {
                                    LogWriter.bmr.severe("Cannot access folder: " + nextBackup + " (Repository password has been changed)");//NO I18N
                                    return "Repository password has been changed";//No I18N
                                } else {
                                    LogWriter.bmr.severe("Cannot access folder: " + nextBackup);//NO I18N
                                    return "";
                                }
                            }
                        }
                        initialDelete(mergeFolder);
                        for (int i = 0; i < backups.size(); i++) {
                            String nextBackup = backups.get(i);
                            userName = users.get(i);
                            password = pwds.get(i);
                            Properties propsNext2 = RMPNativeManager.checkCredentials(nextBackup, userName, password, "connect");//No I18N
                            if (propsNext2.get("Success") != null) {
                                mergeFiles(nextBackup, mergeFolder, isBMR);
                            } else {
                                if (propsNext2.get("Invalid_Password") != null || propsNext2.get("Logon_Failure") != null) {
                                    LogWriter.bmr.severe("Cannot access folder: " + nextBackup + " (Repository password has been changed)");//NO I18N
                                    return "Repository password has been changed";//NO I18N
                                } else {
                                    LogWriter.bmr.severe("Cannot access folder: " + nextBackup);//NO I18N
                                    return "";
                                }
                            }
                        }
                    }
                } else {
                    if (propsFirst.get("Invalid_Password") != null || propsFirst.get("Logon_Failure") != null) {
                        LogWriter.bmr.severe("Cannot access folder: " + firstBackup + " (Repository password has been changed)");//NO I18N
                        return "Repository password has been changed";//NO I18N
                    } else {
                        LogWriter.bmr.severe("Cannot access folder: " + firstBackup);//NO I18N
                        return "";
                    }
                }
                RMPNativeManager.checkCredentials(firstBackup, userName, password, "disconnect");//No I18N
                RMPNativeManager.checkCredentials(mergeFolder, name, pwd, "disconnect");//No I18N

                return mergeFolder;
            } else {
                if (props.get("Invalid_Password") != null || props.get("Logon_Failure") != null) {
                    LogWriter.bmr.severe("Cannot access storage during merge(Repository password has been changed)");//NO I18N
                    return "Repository password has been changed";//NO I18N
                } else {
                    LogWriter.bmr.severe("Cannot access storage during merge");//NO I18N
                    return "";
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static void copyBackups(String nextBackup, String mergeFolder) {
        try {
            FileUtils.copyDirectory(new File(nextBackup), new File(mergeFolder));
        } catch (IOException e) {
            LogWriter.bmr.severe("Merge IOException: " + e.getMessage());//NO I18N
            String str = e.getMessage();
            if (str.contains("exists but is not a directory")) {
                String tempStr = str.substring(str.indexOf('\'') + 1);
                String filePath = tempStr.substring(0, tempStr.indexOf('\''));
                LogWriter.bmr.severe("File to be deleted in merge:" + filePath);//NO I18N
                File delFile = new File(filePath);
                delFile.delete();
                copyBackups(nextBackup, mergeFolder);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void initialDelete(String src) {
        boolean isBMR = false;
        try {
            File merge = new File(src);
            String[] diskNames = merge.list();
            String[] partitionNames = null;

            if (!isBMR) {
                partitionNames = diskNames;
                diskNames = new String[]{"dummyDisk"};// No I18N
            }

            for (String disk : diskNames) {
                String diskFullPath = src + "\\" + disk;
                if (!isBMR) {
                    diskFullPath = src;
                }
                File diskFile = new File(diskFullPath);
                if (diskFile.isDirectory()) {
                    if (partitionNames == null) {
                        partitionNames = diskFile.list();
                    }
                    for (String partition : partitionNames) {
                        String partitionFullPath = diskFullPath + "\\" + partition;
                        File partitionFile = new File(partitionFullPath);

                        if (partitionFile.isDirectory()) {
                            String[] fileNames = partitionFile.list();
                            for (String file : fileNames) {
                                if (file.equals("rename_file.txt") || file.equals("delete_file.txt")) {
                                    File destFile = new File(partitionFullPath + "\\" + file);
                                    if (destFile.exists()) {
                                        destFile.delete();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void mergeFiles(String src, String dest, boolean isBMR) {
        try {
            File merge = new File(src);
            String[] diskNames = merge.list();
            String[] partitionNames = null;

            if (!isBMR) {
                partitionNames = diskNames;
                diskNames = new String[]{"dummyDisk"};// No I18N
            }

            for (String disk : diskNames) {
                String diskFullPath = src + "\\" + disk;
                if (!isBMR) {
                    diskFullPath = src;
                }
                File diskFile = new File(diskFullPath);
                if (diskFile.isDirectory()) {
                    if (partitionNames == null) {
                        partitionNames = diskFile.list();
                    }
                    for (String partition : partitionNames) {
                        String partitionFullPath = diskFullPath + "\\" + partition;
                        File partitionFile = new File(partitionFullPath);

                        if (partitionFile.isDirectory()) {
                            String[] fileNames = partitionFile.list();
                            for (String file : fileNames) {
                                if (file.equals("rename_file.txt") || file.equals("delete_file.txt")) {
                                    String tempPath = dest + "\\" + disk + "\\" + partition;// No I18N
                                    if (!isBMR) {
                                        tempPath = dest + "\\" + partition;
                                    }
                                    File srcFile = new File(partitionFullPath + "\\" + file);
                                    File destFile = new File(tempPath + "\\" + file);

                                    FileInputStream inStream = new FileInputStream(srcFile);
                                    FileOutputStream outStream = new FileOutputStream(destFile, true);

                                    byte[] buffer = new byte[1024];

                                    int length;
                                    while ((length = inStream.read(buffer)) > 0) {
                                        outStream.write(buffer, 0, length);
                                    }
                                    inStream.close();
                                    outStream.close();
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void renameFiles(String src, String dest, boolean isBMR) {
        FileInputStream inStream = null;
        BufferedReader bufread = null;
        try {
            File merge = new File(src);
            String[] diskNames = merge.list();
            String[] partitionNames = null;

            if (!isBMR) {
                partitionNames = diskNames;
                diskNames = new String[]{"dummyDisk"};// No I18N
            }

            for (String disk : diskNames) {
                String diskFullPath = src + "\\" + disk;

                if (!isBMR) {
                    diskFullPath = src;
                }

                File diskFile = new File(diskFullPath);

                if (diskFile.isDirectory()) {

                    if (partitionNames == null) {
                        partitionNames = diskFile.list();
                    }

                    for (String partition : partitionNames) {
                        String partitionFullPath = diskFullPath + "\\" + partition;
                        if (new File(partitionFullPath).isDirectory()) {
                            String tempPath = dest + "\\" + disk + "\\" + partition;// No I18N

                            if (!isBMR) {
                                tempPath = dest + "\\" + partition;
                            }

                            File nxtBkpFile = new File(tempPath);
                            if (nxtBkpFile.exists()) {
                                File srcFile = new File(tempPath + "\\rename_file.txt");
                                if (srcFile.exists()) {
                                    inStream = new FileInputStream(srcFile);
                                    bufread = new BufferedReader(new InputStreamReader(inStream));
                                    String line = null;
                                    while ((line = bufread.readLine()) != null) {
                                        String[] names = line.split("--");
                                        File toRename = new File(partitionFullPath + "\\" + names[0]);
                                        File newName = new File(partitionFullPath + "\\" + names[1]);
                                        toRename.renameTo(newName);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bufread != null) {
                    bufread.close();
                }
                if (inStream != null) {
                    inStream.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void deleteFiles(String src, String dest, boolean isBMR) {
        FileInputStream inStream = null;
        BufferedReader bread = null;
        try {
            File merge = new File(src);
            String[] diskNames = merge.list();
            String[] partitionNames = null;

            if (!isBMR) {
                partitionNames = diskNames;
                diskNames = new String[]{"dummyDisk"};// No I18N
            }

            for (String disk : diskNames) {
                String diskFullPath = src + "\\" + disk;
                if (!isBMR) {
                    diskFullPath = src;
                }
                File diskFile = new File(diskFullPath);
                if (diskFile.isDirectory()) {
                    if (partitionNames == null) {
                        partitionNames = diskFile.list();
                    }
                    for (String partition : partitionNames) {
                        String partitionFullPath = diskFullPath + "\\" + partition;
                        if (new File(partitionFullPath).isDirectory()) {
                            String tempPath = dest + "\\" + disk + "\\" + partition;// No I18N
                            if (!isBMR) {
                                tempPath = dest + "\\" + partition;
                            }
                            File nxtBkpFile = new File(tempPath);
                            if (nxtBkpFile.exists()) {
                                File srcFile = new File(tempPath + "\\delete_file.txt");
                                if (srcFile.exists()) {
                                    inStream = new FileInputStream(srcFile);
                                    bread = new BufferedReader(new InputStreamReader(inStream));
                                    String line = null;
                                    while ((line = bread.readLine()) != null) {
                                        File toDelete = new File(partitionFullPath + "\\" + line);
                                        if (toDelete.isDirectory()) {
                                            FileUtils.deleteDirectory(toDelete);
                                        } else {
                                            toDelete.delete();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (inStream != null) {
                    inStream.close();
                }
                if (bread != null) {
                    bread.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public static boolean checkFullRestore(String dcName, long opId) {
        try {
            boolean check = true;
            int i = 0;
            JSONArray partitionsArray = null;
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_NAME"), dcName, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_DOMAIN_CONTROLLERS);
            long domainId = (long) row.get("DOMAIN_ID");
            Properties details = RMPDomainHandler.getDomainDetailsById(domainId);
            String domainName = (String) details.getProperty("USER_DOMAIN_NAME");
            String name = domainName + "\\" + (String) details.getProperty("USER_NAME");//No I18N
            String pwd = (String) details.getProperty("PASSWORD");

            String path = "\\\\" + dcName + "\\C$\\Program Files\\ManageEngine\\RMP\\usnvalues.txt";// No I18N

            SelectQueryImpl selquery = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            selquery.setCriteria(criteria);
            selquery.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            DataObject obj = CommonUtil.getPersistence().get(selquery);
            if (!obj.isEmpty()) {
                Row partitionRow = obj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                partitionsArray = new JSONArray((String) partitionRow.get("PARTITIONS_INFO"));
                Properties props = RMPNativeManager.checkCredentials("\\\\" + dcName + "\\c$", name, pwd, "connect");//No I18N
                if (props.get("Success") != null) {
                    File fin = new File(path);
                    FileInputStream fis = new FileInputStream(fin);
                    BufferedReader in = new BufferedReader(new InputStreamReader(fis));
                    String info = null;
                    while ((info = in.readLine()) != null) {
                        JSONObject partition = (JSONObject) partitionsArray.get(i);
                        String usnValue = (String) partition.get("usn");
                        if (!info.equals(usnValue)) {
                            check = false;
                            break;
                        }
                        i++;
                    }
                    RMPNativeManager.checkCredentials("\\\\" + dcName + "\\c$", name, pwd, "disconnect");//No I18N
                    return check;
                } else {
                    LogWriter.bmr.severe("Could not access usn file: " + props);//NO I18N
                    return false;
                }
            } else {
                LogWriter.bmr.severe("Could not get Partition information");//NO I18N
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static LicenseType getLicenseType(Long dcId) {
        try {
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"));//No I18N
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "IS_LICENSED"));//No I18N
            selectQuery.setCriteria(new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), dcId, QueryConstants.EQUAL));//No I18N
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if (!dataObject.isEmpty()) {
                Row row = dataObject.getFirstRow(TableName.BMR_DOMAIN_CONTROLLERS);
                return LicenseType.values()[(int) row.get("IS_LICENSED")];//No I18N
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.bmr.severe("BMRDatabase.getLicenseType(): " + e);//No I18N
        }
        return null;
    }
}
