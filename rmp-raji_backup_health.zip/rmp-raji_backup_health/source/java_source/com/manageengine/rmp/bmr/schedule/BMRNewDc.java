/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.bmr.schedule;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.taskengine.Task;
import com.adventnet.taskengine.TaskContext;
import com.adventnet.taskengine.TaskExecutionException;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.bmr.configure.BMRDatabase;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.RMPCommonUtil;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.licensing.Environment;
import com.manageengine.rmp.licensing.LicenseType;
import com.manageengine.rmp.licensing.LicenseUtil;
import com.manageengine.rmp.licensing.ProductSubscriptionInfo;
import com.manageengine.rmp.util.RMPDomainHandler;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 *
 * @author chella-3221
 */
public class BMRNewDc implements Task {

    @Override
    public void executeTask(TaskContext taskContext) throws TaskExecutionException {
        // Test
        try {
            List domainList = RMPDomainHandler.getDomainNames();
            BMRDatabase.runBMRNewDcSchedule(domainList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void stopTask() throws TaskExecutionException {
    }
}
