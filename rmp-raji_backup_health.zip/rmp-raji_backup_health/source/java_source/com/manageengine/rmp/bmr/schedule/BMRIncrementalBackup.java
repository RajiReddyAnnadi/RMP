/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.bmr.schedule;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.taskengine.DEFAULT_TASK_INPUT;
import com.adventnet.taskengine.Task;
import com.adventnet.taskengine.TaskContext;
import com.adventnet.taskengine.TaskExecutionException;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.bmr.configure.BMRDatabase;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.jni.RMPNativeManager;
import com.manageengine.rmp.util.RMPDomainHandler;
import org.json.JSONObject;

import java.io.File;
import java.util.Iterator;
import java.util.Properties;

/**
 *
 * @author chella-3221
 */
//ignoreI18n_start
public class BMRIncrementalBackup implements Task {

    @Override
    public void executeTask(TaskContext taskContext) throws TaskExecutionException {

        try {
            Iterator<Row> iter = taskContext.getDefaultTaskInputs();
            long dcId = -1L;
            while (iter.hasNext()) {
                Row row = iter.next();
                String varName = (String) row.get(DEFAULT_TASK_INPUT.VARIABLE_NAME);
                switch (varName) {
                    case "dcIdIB":
                        dcId = Long.valueOf((String) row.get(DEFAULT_TASK_INPUT.VARIABLE_VALUE));
                        break;
                }
            }
            LogWriter.bmr.info("BMR Incremental backup scheduler triggered");
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
            final long domainId = (long) row.get("DOMAIN_ID");
            final String domainName = (String) RMPDomainHandler.getDomainDetailsById(domainId).getProperty("DOMAIN_NAME");
            final String dcName = BMRDatabase.getNameFromId(dcId);
            // String type = "IB";
            final long finalDcId = dcId;
            Thread thread = new Thread() {
                @Override
                public void run() {
                    try {
                        String type = "IB";
                        int prevBackupDiskCnt = -1;
                        int currentDiskCnt = -1;
                        String code = "Ibackup", backupMode = "", fbStatus = "";
                        long fullBuId = 0;
                        Properties prop = RMPDomainHandler.getDomainDetailsByName(domainName);
                        String domainFlatName = (String) prop.getProperty("USER_DOMAIN_NAME");
                        String domainUser = (String) prop.getProperty("USER_NAME");
                        String domainUname = domainFlatName + "\\" + domainUser;//No I18N
                        String domainPwd = (String) prop.getProperty("PASSWORD");
                        String finalUserName = domainUname + "###" + domainPwd;//No I18N

                        Properties usnprops = RMPNativeManager.checkCredentials("\\\\" + dcName + "\\c$", domainUname, domainPwd, "connect");//No I18N
                        if (usnprops.get("Success") != null) {
                            String path = "\\\\" + dcName + "\\C$\\Program Files\\ManageEngine\\RMP\\usnvalues_0.txt";// No I18N
                            File usnFile = new File(path);
                            if (!usnFile.exists()) {
                                type = "FB";
                                code = "Backup";
                            }
                            RMPNativeManager.checkCredentials("\\\\" + dcName + "\\c$", domainUname, domainPwd, "disconnect");//No I18N
                        } else {
                            LogWriter.bmr.severe("Could not access usn file: " + usnprops);//NO I18N
                        }

                        if (type.equals("IB")) {
                            prevBackupDiskCnt = BMRDatabase.getPrevBackupDiskCnt(finalDcId);
                            currentDiskCnt = RMPNativeManager.getCurrentDiskCnt("\\\\" + dcName, domainFlatName, domainUser, domainPwd);

                            if (currentDiskCnt == -1) {
                                LogWriter.bmr.severe("Error retrieving the disk count");//NO I18N
                            } else if (currentDiskCnt > prevBackupDiskCnt) {
                                type = "FB";
                                code = "Backup";
                            }
                        }
                        if (type.equals("IB")) {
                            Properties prevBackupDetails = BMRDatabase.getFullBackupDetails(finalDcId, false);
                            if (!prevBackupDetails.isEmpty()) {
                                fullBuId = Long.valueOf(prevBackupDetails.getProperty("OpId"));
                                backupMode = (String) prevBackupDetails.getProperty("Mode");
                                fbStatus = (String) prevBackupDetails.getProperty("Status");
                            }
                            if ((!backupMode.equals("BMR")) || (!fbStatus.equals("Completed"))) {
                                LogWriter.bmr.severe("Previous full backup failed...So triggering FB instead of IB.");//NO I18N
                                type = "FB";
                                code = "Backup";
                            }
                        }
                        if (type.equals("IB")) {
                            String prevStatus = BMRDatabase.getPrevBackupStatus(finalDcId);
                            if (!prevStatus.isEmpty()) {
                                if (prevStatus.equals("Failed (Partition count is different)")) {
                                    LogWriter.bmr.severe("Partition count changed...So triggering FB instead of IB.");//NO I18N
                                    type = "FB";
                                    code = "Backup";
                                }
                            }
                        }
                        Properties prevEncryptionDetails = BMRDatabase.prevEncryptionDetails(finalDcId);
                        boolean prevEncryptionStatus = Boolean.parseBoolean((String) prevEncryptionDetails.getProperty("IS_ENCRYPTED"));
                        String prevEncryptionPwd = (String) prevEncryptionDetails.getProperty("SECRETKEY");
                        Properties currentEncryptionDetails = BMRDatabase.currentEncryptionDetails(finalDcId);
                        boolean currentEncryptionStatus = Boolean.parseBoolean((String) currentEncryptionDetails.getProperty("IS_ENCRYPTED"));
                        String currentEncryptionPwd = (String) currentEncryptionDetails.getProperty("SECRETKEY");
                        int isEncrypted = (currentEncryptionStatus) ? 1 : 0;
                        if (type.equals("IB")) {
                            if ((prevEncryptionStatus != currentEncryptionStatus) || (!(prevEncryptionPwd.equals(currentEncryptionPwd)))) {
                                LogWriter.bmr.severe("Encrytion state or password mismatch...So triggering FB instead of IB.");//NO I18N
                                type = "FB";
                                code = "Backup";
                            }
                        }
                        JSONObject prevBackupStatus = BMRDatabase.isCompleted(dcName, finalDcId, type, "Scheduler", currentEncryptionStatus, currentEncryptionPwd,"backup");
                        String backupResult = (String) prevBackupStatus.get("result");
                        String restoreResult = (String) prevBackupStatus.get("restoreResult");
                        if (backupResult.equals("Application Interrupted") || backupResult.equals("In Progress")) {
                            BMRDatabase.updateInterruptedBackupStatus(dcName, finalDcId, domainName);
                            prevBackupStatus = BMRDatabase.isCompleted(dcName,finalDcId,  type, "Scheduler", currentEncryptionStatus, currentEncryptionPwd, "backup");
                            backupResult = (String) prevBackupStatus.get("result");
                        }
                        if(restoreResult.equals("Application Interrupted") || restoreResult.equals("In Progress")) {
                            boolean ret = BMRDatabase.getInterruptedVLRdetails(dcName,finalDcId,domainName);
                            prevBackupStatus = BMRDatabase.isCompleted(dcName, finalDcId, type, "Scheduler", currentEncryptionStatus, currentEncryptionPwd, "backup");
                            backupResult = (String) prevBackupStatus.get("result");
                            restoreResult = (String) prevBackupStatus.get("restoreResult");
                        }
                        if (!((backupResult.equals("Started")) || (backupResult.equals("In Progress (But failed to delete old backups)")) || (backupResult.equals("In Progress")) || (restoreResult.equals("In Progress")) || (restoreResult.equals("Started")))) {
                            BMRDatabase.backupCode(dcName, finalDcId, domainId, type, code, fullBuId, isEncrypted, currentEncryptionPwd);
                        } else {
                            LogWriter.bmr.severe("Agent busy due to another backup or restore in progress...So skipping the schedule.");//NO I18N
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            };
            thread.start();

        } catch (Exception e) {

        }
    }

    @Override
    public void stopTask() throws TaskExecutionException {
    }
}
