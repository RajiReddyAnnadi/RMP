/*
 * To change this license header, choose License Headers inReader Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template inReader the editor.
 */
package com.manageengine.rmp.bmr.configure;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.agent.installation.WindowsHandler;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.DateUtil;
import com.manageengine.rmp.admin.MailInfoBMR;
import com.manageengine.rmp.admin.NotificationAPI;
import com.manageengine.rmp.admin.constants.NotificationType;
import com.manageengine.rmp.bmr.BMRThreadManager;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.driver.RMPDriverManager;
import com.manageengine.rmp.jni.RMPMountManager;
import com.manageengine.rmp.jni.RMPNativeManager;
import com.manageengine.rmp.licensing.Environment;
import com.manageengine.rmp.licensing.LicenseType;
import com.manageengine.rmp.licensing.LicenseUtil;
import com.manageengine.rmp.util.GeneralUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.manageengine.rmp.bmr.configure.BMRDatabase.getIBParentId;

/**
 *
 * @author chella-3221
 */
public class FLRDatabase {

    public static String mountToDrive(long opId) {
        JSONObject retObj = new JSONObject();
        String errorMsg = "";
        JSONArray successfulDriveLetters = new JSONArray();
        JSONArray failedDriveLetters = new JSONArray();

        try {
            Long offset = 0L;
            int retry;
            if (!BMRDatabase.isFullBackup(opId)) {
                opId = BMRDatabase.getIBParentId(opId);
            }
            Properties encryptionDetails = BMRDatabase.getEncryptionDetails(opId);
            String encryptionStatus = (String) encryptionDetails.getProperty("IS_ENCRYPTED");
            String encryptionPwd = (String) encryptionDetails.getProperty("SECRETKEY");
            String serverHome = System.getProperty("server.dir");
            String productBin = serverHome + File.separator + "bin" + File.separator + "driversInstalled" + File.separator;//No I18N
            String userModePath = serverHome + File.separator + "bin" + File.separator + "driver" + File.separator;//No I18N
            String sparseFolder = serverHome + File.separator + "temp_BMR" + File.separator;//No I18N
            LogWriter.bmr.info("productBin: " + productBin);//NO I18N
            LogWriter.bmr.info("sparseFolder: " + sparseFolder);//NO I18N
            File dir = new File(sparseFolder);

            if (!dir.exists()) {
                boolean created = dir.mkdir();
                LogWriter.bmr.info("created: " + created);//NO I18N
            }

            boolean startStatus = RMPDriverManager.getDriverManager().startAttachDriver("BMR", serverHome.substring(0, 3));//No I18N
            LogWriter.bmr.info("RMPDriver startStatus: " + startStatus);//NO I18N

            if (startStatus) {
                int vdkInstall = RMPMountManager.startVdk(productBin + "vdk.exe");//No I18N
                LogWriter.bmr.info("vdkInstall: " + vdkInstall);//NO I18N
                if (vdkInstall != 0) {
                    LogWriter.bmr.info("vdkInstall failed");//NO I18N
                } else {
                    Map<String, Long> sizeMap = new HashMap<>();
                    SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
                    Criteria idCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
                    query.setCriteria(idCriteria);
                    query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));

                    DataObject dobj = CommonUtil.getPersistence().get(query);

                    if (!dobj.isEmpty()) {
                        Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                        JSONArray partitionsInfo = new JSONArray(row.get("PARTITIONS_INFO").toString());
                        for (int pObj = 0; pObj < partitionsInfo.length(); pObj++) {
                            JSONObject partition = (JSONObject) partitionsInfo.get(pObj);
                            sizeMap.put((String) partition.get("name"), Long.parseLong(partition.get("fullSize").toString()));
                        }
                    }

                    JSONObject obj = FLRDatabase.listAllImgFiles(opId);
                    if(!obj.has("errorMsg")) {
                        List<File> names = (List) obj.get("names");
                        if (names.size() > 0) {
                            if (!names.isEmpty()) {
                                boolean toContinue = true;
                                for (int loop = 0; loop < names.size(); loop++) {
                                    String partitionName = names.get(loop).getName();
                                    String partitionAbsName = names.get(loop).getAbsolutePath();
                                    String partitionNameWithoutExtn = FilenameUtils.removeExtension(partitionName);
                                    String partitionAbsNameWithoutExtn = FilenameUtils.removeExtension(partitionAbsName);
                                    if (Character.isLetter(partitionNameWithoutExtn.charAt((partitionNameWithoutExtn.length() - 1)))) {
                                        boolean isMountSuccessful = false;
                                        if(toContinue) {
                                            String sparseFile = sparseFolder + partitionNameWithoutExtn + ".rmp_BMR";//No I18N
                                            String indexFile = partitionAbsNameWithoutExtn + ".idx";//No I18N
                                            offset = sizeMap.get((partitionNameWithoutExtn.substring((partitionNameWithoutExtn.length() - 1))) + ":");
                                            int sparse = RMPMountManager.createSparseFile(sparseFile, offset);

                                            if (sparse != 0) {
                                                LogWriter.bmr.info("createSparseFile status: " + sparse);//NO I18N
                                            } else {
                                                String tempName = sparseFolder + partitionNameWithoutExtn + ".tmp";//No I18N
                                                File tempFile = new File(tempName);
                                                LogWriter.bmr.info("partitionAbsoluteName:" + partitionAbsName + " " + encryptionStatus.toString());//NO I18N
                                                LogWriter.bmr.info("indexFile:" + indexFile);//NO I18N
                                                String params = encryptionStatus + "<??>" + encryptionPwd + "<??>" + partitionAbsName + "<??>";
                                                //Replacing " with "" to avoid issues when secretKey has " in it
                                                int userModeStatus = RMPMountManager.startUserMode(userModePath + "RMPFileMounterClient.exe", params.replace("\"", "\"\""), indexFile, tempName);//No I18N
                                                LogWriter.bmr.info("userModeStatus: " + userModeStatus);//NO I18N
                                                if (userModeStatus == -1) {
                                                    LogWriter.bmr.info("Failed to start UserMode process");//NO I18N
                                                } else {
                                                    //Need to wait till usermode loads the index to memory.So dummy loop given temporarily.Need to change...
                                                    while (!tempFile.exists()) {
                                                        try {
                                                            Thread.sleep(1000);
                                                        } catch (InterruptedException e) {
                                                            LogWriter.bmr.info("In thread sleep catch");//NO I18N
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                    LogWriter.bmr.info("After index load...");//NO I18N
                                                    int mountStatus = -1;
                                                    for (retry = 0; retry < 10; retry++) {
                                                        mountStatus = RMPMountManager.mountBackupImage(productBin + "vdk.exe", sparseFile, retry);//No I18N
                                                        LogWriter.bmr.info("mountStatus: " + mountStatus);//NO I18N
                                                        if (mountStatus == 0) {
                                                            LogWriter.bmr.info("mountStatus success");//NO I18N
                                                            break;
                                                        }
                                                    }
                                                    if (mountStatus != 0) {
                                                        LogWriter.bmr.info("mountBackupImage failed");//NO I18N
                                                    } else {
                                                        int driveLetterNo = RMPMountManager.chooseDriveLetter();
                                                        LogWriter.bmr.info("driveLetterNo: " + driveLetterNo);//NO I18N
                                                        String driveLetter = "";
                                                        if (driveLetterNo > 0 && driveLetterNo < 27) {
                                                            driveLetter = String.valueOf((char) (driveLetterNo + 64));
                                                            LogWriter.bmr.info("driveLetter: " + driveLetter);//NO I18N

                                                            int linkStatus = RMPMountManager.linkDriveLetter(productBin + "vdk.exe", driveLetter + ":", retry);//No I18N
                                                            LogWriter.bmr.info("linkStatus: " + linkStatus);//NO I18N
                                                            if (linkStatus != 0) {
                                                                LogWriter.bmr.info("linkDriveLetter failed");//NO I18N
                                                            } else {
                                                                JSONObject mountObj = new JSONObject();
                                                                mountObj.put("value", driveLetter + ":");
                                                                mountObj.put("displayName", (partitionNameWithoutExtn.substring((partitionNameWithoutExtn.length() - 1))) + ":");
                                                                successfulDriveLetters.put(mountObj);
                                                                isMountSuccessful = true;
                                                                LogWriter.bmr.info("mountedBackups" + successfulDriveLetters.toString());//NO I18N
                                                            }
                                                        } else {
                                                            LogWriter.bmr.info("Failed to get driveLetter");//NO I18N
                                                            toContinue = false;
                                                        }
                                                    }
                                                }
                                            }

                                            if(!isMountSuccessful) {
                                                JSONObject failedObj = new JSONObject();
                                                failedObj.put("value", (partitionNameWithoutExtn.substring((partitionNameWithoutExtn.length() - 1))));
                                                failedDriveLetters.put(failedObj);
                                            }
                                        }
                                    } else {
                                        LogWriter.bmr.info("Skipping partitition with no drive letter:" + partitionNameWithoutExtn);//NO I18N
                                    }
                                }
                            } else {
                                LogWriter.bmr.info("No img files found");//NO I18N
                            }
                        } else {
                            LogWriter.bmr.info("Failed could not access location");//NO I18N
                        }
                    } else {
                        errorMsg = obj.get("errorMsg").toString();
                        LogWriter.bmr.info("Failed could not access location (Repository password has been changed)");//NO I18N
                    }

                    if(!(successfulDriveLetters.length()>0)) {
                        unmountDrives();
                    }
                }
            }
        } catch (Exception e) {
            LogWriter.bmr.info("In mountToDrive catch");//NO I18N
            e.printStackTrace();
        } finally {
            try {
                retObj.put("errorMsg", errorMsg);
                retObj.put("successfulDriveLetters", successfulDriveLetters);
                retObj.put("failedDriveLetters", failedDriveLetters);
                retObj.put("isSuccessful", successfulDriveLetters.length()>0 ? true : false);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return  retObj.toString();
    }

    public static void copyFilesToInstallationFolder() {
        try {
            Properties prop = RMPMountManager.getOsVersion();
            if (prop.containsKey("majorVersion")) {
                String osVersion = null;
                int majorVersion = (int) prop.get("majorVersion");
                int minorVersion = (int) prop.get("minorVersion");
                if (majorVersion == 6 && minorVersion == 1) {
                    osVersion = "Win7";//No I18N
                } else if (majorVersion == 6 && minorVersion == 2) {
                    osVersion = "Win8";//No I18N
                } else if (majorVersion == 6 && minorVersion == 3) {
                    osVersion = "Win8.1";//No I18N
                } else if (majorVersion == 10 && minorVersion == 0) {
                    osVersion = "Win10";//No I18N
                }

                String serverHome = System.getProperty("server.dir");
                String productBin = serverHome + File.separator + "bin" + File.separator + "driversInstalled";//No I18N
                String driverPath = serverHome + File.separator + "bin" + File.separator + "driver" + File.separator;//No I18N
                String vdkPath = serverHome + File.separator + "bin" + File.separator + "driver" + File.separator + "BMR" + File.separator;//No I18N

                File dir = new File(productBin);
                if (!dir.exists()) {
                    boolean created = dir.mkdir();
                    LogWriter.bmr.info("driversInstalled creation status: " + created);//NO I18N
                }
                FileUtils.copyFile(new File(driverPath + osVersion + "\\RMPfileMounter.sys"), new File(productBin + "\\RMPFileMounter.sys"));
                FileUtils.copyFile(new File(driverPath + osVersion + "\\RMPfileMounter.inf"), new File(productBin + "\\RMPFileMounter.inf"));
                FileUtils.copyFile(new File(vdkPath + osVersion + "\\vdk.sys"), new File(productBin + "\\vdk.sys"));
                FileUtils.copyFile(new File(vdkPath + "\\vdk.exe"), new File(productBin + "\\vdk.exe"));

                //Call RMPfileMounter and vdk install commands
                RMPMountManager.installRMPDriver(productBin + "\\RMPFileMounter.inf");//No I18N
                int vdkInstall = RMPMountManager.installVdk(productBin + "\\vdk.exe");//No I18N
                LogWriter.bmr.info("vdkInstall: " + vdkInstall);//NO I18N
                LogWriter.virtual.info("VDDK mount installer starts");//No I18N
                //String vcRuntimePath = serverHome + File.separator + "bin" + File.separator + "vcredist_x64.exe";//No I18N
                //int vcRuntime2013Status = RMPMountManager.installVcRuntime2013(vcRuntimePath);
                //LogWriter.virtual.info("vcRuntime2013Status : " + vcRuntime2013Status);//No I18N
                int vddkDriverStatus = RMPMountManager.checkVDDKDriverStatus();
                if (vddkDriverStatus != 0) {
                    LogWriter.virtual.info("VDDK mount driver not installed status : " + vddkDriverStatus);//No I18N
                    String vddkMountPath = driverPath + File.separator + "VMWARE" + File.separator + "vstor2install.bat";//No I18N
                    int vddkInstall = RMPMountManager.installVddkDriver(vddkMountPath);
                    LogWriter.virtual.info("VDDKInstall : " + vddkInstall);//No I18N
                } else {
                    LogWriter.virtual.info("VDDK mount driver already installed status : " + vddkDriverStatus);//No I18N
                }
                LogWriter.virtual.info("VDDK mount installer ends");//No I18N
            } else {
                LogWriter.bmr.info("In copyFilesToInstallationFolder, RMPMountManager.getOsVersion() returns null");//NO I18N
            }
        } catch (Exception e) {
            LogWriter.bmr.info("In copyFilesToInstallationFolder catch");//NO I18N
            e.printStackTrace();
        }
    }

    public static JSONObject listAllImgFiles(long opId) {
        JSONObject retObject = new JSONObject();
        List<File> names = new ArrayList<>();

        try {
            Properties backupDetails = BMRDatabase.getBackupFolder(opId);
            String loc = backupDetails.get("Location").toString();
            String name = backupDetails.get("User").toString();
            String pwd = backupDetails.get("Password").toString();
            String buFolder = backupDetails.get("backupFolder").toString();

            Properties props = RMPNativeManager.checkCredentials(loc, name, pwd, "connect");//NO I18N
            LogWriter.bmr.info("checkCredentials in mountBackup: " + props);//NO I18N
            if (props.get("Success") != null) {
                String[] extension = new String[]{"img"};//NO I18N
                File file = new File(buFolder);
                if (file.exists()) {
                    names = (List<File>) FileUtils.listFiles(file, extension, true);
                } else {
                    LogWriter.bmr.info("listAllImgFiles : Could not find the backup folder");//NO I18N
                }
            } else {
                if(props.get("Invalid_Password")!=null || props.get("Logon_Failure") != null){
                    LogWriter.bmr.severe("Failed could not access location (Repository password has been changed)");//NO I18N
                    retObject.put("errorMsg", "Repository password has been changed");
                } else {
                    retObject.put("errorMsg", "Could not connect to repository");
                    LogWriter.bmr.severe("Failed could not access location");//NO I18N
                }
            }
            retObject.put("names", names);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return retObject;
    }

    public static JSONObject validateSelectedVolumes(JSONArray filesToRestore, String domain, String dcName) {
        JSONObject obj = new JSONObject();

        try {
            Properties prop = RMPDomainHandler.getDomainDetailsByName(domain);
            String domainFlatName = (String) prop.getProperty("USER_DOMAIN_NAME");
            String domainUser = (String) prop.getProperty("USER_NAME");
            String domainPwd = (String) prop.getProperty("PASSWORD");
            String finalUserName = domainFlatName + "\\" + domainUser;//No I18N
            String missingDrives = "";
            obj.put("result", true);
            obj.put("missingDrives", missingDrives);
            String dcPathToCheck = "\\\\" + dcName+"\\admin$"; // NO I18N
            String dcInput = dcPathToCheck + "";
            Properties props1 = RMPNativeManager.checkCredentials(dcInput, finalUserName, domainPwd, "connect");// No I18N
            LogWriter.bmr.info("checkCredentials in validateSelectedVolumes: " + props1);//NO I18N
            if (props1.get("Success") != null) {

                for (int len = 0; len < filesToRestore.length(); len++) {
                    JSONObject pathObj = (JSONObject) filesToRestore.get(len);
                    String displayPath = (String) pathObj.get("folderUncPath");
                    String driveLetter = Character.toString(displayPath.charAt(0));
                    String pathToCheck = "\\\\" + dcName + "\\" + driveLetter + "$"; // NO I18N
                    String input = pathToCheck + "";
                    Properties props = RMPNativeManager.checkCredentials(input, finalUserName, domainPwd, "connect");// No I18N
                    LogWriter.bmr.info("checkCredentials in validateSelectedVolumes: " + props);//NO I18N

                    if (props.get("Success") != null) {
                        if (new File(input + "\\Windows\\System32\\drivers\\etc\\hosts").exists()) {
                            obj.put("result", false);
                            obj.put("drive", driveLetter);
                            obj.put("operatingSystem", true);
                            break;
                        } else if (new File(input + "\\Boot").exists() && new File(input + "\\bootmgr").exists()) {
                            obj.put("result", false);
                            obj.put("drive", driveLetter);
                            obj.put("systemReserved", true);
                            break;
                        } else if (new File(input + "\\pagefile.sys").exists()) {
                            obj.put("result", false);
                            obj.put("drive", driveLetter);
                            obj.put("pageFile", true);
                            break;
                        }
                    } else if (props.get("Invalid_Password") != null) {
                        obj.put("errorMsg", "Domain credential has been changed");
                        obj.put("result", false);
                    } else {
                        missingDrives += driveLetter + ", ";
                        obj.put("result", false);
                    }
                }

                if (missingDrives.length() != 0) {
                    obj.put("missingDrives", missingDrives.substring(0, missingDrives.length() - 2));
                }
            } else {
                obj.put("checkCred", "false");
                obj.put("result", false);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return obj;
    }

    public static void unmountDrives() {
        try {
            String serverHome = System.getProperty("server.dir");
            String productBin = serverHome + File.separator + "bin" + File.separator + "driversInstalled" + File.separator;//No I18N
            String sparseFolder = serverHome + File.separator + "temp_BMR" + File.separator;//No I18N
            boolean stopStatus = RMPDriverManager.getDriverManager().stopDriver("BMR");//No I18N
            LogWriter.bmr.info("RMPDriver stopStatus: " + stopStatus);//NO I18N
            int vdkClose = RMPMountManager.unmountBackupImage(productBin + "vdk.exe");//No I18N
            LogWriter.bmr.info("vdkClose: " + vdkClose);//NO I18N
            if (vdkClose == 0) {
                LogWriter.bmr.info("unmountBackupImage success");//NO I18N
            }
            int stopVdk = RMPMountManager.stopVdk(productBin + "vdk.exe");//No I18N
            LogWriter.bmr.info("stopVdk: " + stopVdk);//NO I18N
            if (stopVdk == 0) {
                LogWriter.bmr.info("stopVdk success");//NO I18N
            }
            File file = new File(sparseFolder);
            if (file.exists()) {
                FileUtils.deleteDirectory(file);
            }
        } catch (Exception e) {
            LogWriter.bmr.info("In unmountDrives catch");//NO I18N
            e.printStackTrace();
        }
    }

    public static JSONArray compareConfiguredAndBackedupVolumes(JSONArray allPartitions, Set configuredFileSet, String type) {
        Set<String> allPartitionSet = new HashSet<>();
        try {
            for (int j = 0; j < allPartitions.length(); j++) {
                JSONObject obj = (JSONObject) allPartitions.get(j);
                String volName = (String) obj.get("name");
                allPartitionSet.add(volName);
            }
            int configuredFileSetLength = configuredFileSet.size();
            int allPartitionSetLength = allPartitionSet.size();
            if (configuredFileSetLength != allPartitionSetLength) {
                Iterator<String> itr = configuredFileSet.iterator();
                while (itr.hasNext()) {
                    String volume = itr.next();
                    if (!allPartitionSet.contains(volume)) {
                        JSONObject obj = new JSONObject();
                        obj.put("name", volume);
                        obj.put("type", "Volume");
                        obj.put("status", "Not found");
                        if (type.equals("FB")) {
                            obj.put("fullSize", 0L);
                        }
                        obj.put("timeUnit", "secs");
                        obj.put("timeSec", "0");
                        obj.put("size", 0f);
                        obj.put("sizeUnit", "MB");
                        allPartitions.put(obj);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return allPartitions;
    }

    public static JSONArray compareConfiguredAndRestoredVolumes(JSONArray allPartitions, Set configuredFileSet) {
        Set<String> allPartitionSet = new HashSet<>();
        try {
            for (int j = 0; j < allPartitions.length(); j++) {
                JSONObject obj = (JSONObject) allPartitions.get(j);
                String volName = (String) obj.get("name");
                allPartitionSet.add(volName);
            }
            int configuredFileSetLength = configuredFileSet.size();
            int allPartitionSetLength = allPartitionSet.size();
            if (configuredFileSetLength != allPartitionSetLength) {
                Iterator<String> itr = configuredFileSet.iterator();
                while (itr.hasNext()) {
                    String volume = itr.next();
                    if (!allPartitionSet.contains(volume)) {
                        JSONObject obj = new JSONObject();
                        obj.put("name", volume);
                        obj.put("status", "Not found");
                        obj.put("TimeTaken", "0");
                        allPartitions.put(obj);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return allPartitions;
    }

    public static Properties readFromFLRBackupDetailsFile(String type, String backupFolder, BufferedReader inReader, String backupMode, Set configuredFileSet) {
        Properties details = new Properties();
        try {
            DecimalFormat formatter = new DecimalFormat("00");
            String info = null, status;
            Long totalTime = 0L;
            float finalSize = 0f;
            int partitionsCnt = 0, totalPartitions = 0, foundFilesCnt = 0;
            JSONArray allPartitions = new JSONArray();
            if (backupMode.equals("VLR")) {
                while (true) {
                    JSONArray partitions = new JSONArray();
                    partitionsCnt = 0;
                    info = inReader.readLine();
                    if (info == null) {
                        break;
                    } else {
                        while (!(info.equals("Status:"))) {
                            LogWriter.bmr.info("Backup data1: " + info);//NO I18N
                            JSONObject partition = new JSONObject();
                            partition.put("name", info);
                            partition.put("type", "Volume");
                            partitions.put(partition);
                            partitionsCnt++;
                            info = inReader.readLine();
                        }
                    }
                    int diskStatus = Integer.parseInt(inReader.readLine());
                    if (type.equals("FB")) {
                        for (int cnt = 0; cnt < partitionsCnt; cnt++) {
                            JSONObject partition = partitions.getJSONObject(cnt);
                            Long partitionFullSize = 0L;
                            if (diskStatus == 1) {
                                info = "DiskFailed"; //No I18N
                            } else {
                                partitionFullSize = Long.parseLong(inReader.readLine()) + 3584L; //Add 3584 to make it mountable by vdk
                                info = inReader.readLine();
                            }
                            LogWriter.bmr.info("Backup data2: " + info);//NO I18N
                            partition.put("fullSize", partitionFullSize);
                            partition.put("status", info);
                        }
                    } else {
                        for (int cnt = 0; cnt < partitionsCnt; cnt++) {
                            JSONObject partition = partitions.getJSONObject(cnt);
                            if (diskStatus == 1) {
                                info = "DiskFailed"; //No I18N
                            } else {
                                info = inReader.readLine();
                            }
                            LogWriter.bmr.info("Backup data2: " + info);//NO I18N
                            partition.put("status", info);
                        }
                    }
                    if (diskStatus == 0) {
                        info = inReader.readLine();
                    }
                    for (int cnt = 0; cnt < partitionsCnt; cnt++) {
                        JSONObject partition = partitions.getJSONObject(cnt);
                        String statusVal = partition.get("status").toString();
                        if ((statusVal.equals("Inaccessible")) || (statusVal.equals("DiskFailed"))) {
                            partition.put("timeUnit", "secs");
                            partition.put("timeSec", "0");
                        } else {
                            info = inReader.readLine();
                            LogWriter.bmr.info("Backup data4: " + info);//NO I18N
                            Long time = Long.parseLong(info);
                            if (time >= 60) {
                                Long timeMin = time / 60;
                                if (timeMin >= 60) {
                                    Long timeHr = timeMin / 60;
                                    timeMin = timeMin % 60;
                                    partition.put("timeUnit", "hrs");
                                    partition.put("timeHr", formatter.format(timeHr));
                                    partition.put("timeMin", formatter.format(timeMin));
                                } else {
                                    partition.put("timeUnit", "mins");
                                    partition.put("timeHr", "00");
                                    partition.put("timeMin", formatter.format(timeMin));
                                }
                            } else {
                                partition.put("timeUnit", "secs");
                                partition.put("timeSec", formatter.format(time));
                            }
                            totalTime += time;
                        }
                    }
                    totalPartitions += partitionsCnt;
                    for (int j = 0; j < partitions.length(); j++) {
                        allPartitions.put(partitions.getJSONObject(j));
                    }

                    info = inReader.readLine();
                    if (info.equals("VolumeLevelEnd")) {
                        break;
                    }
                }
                allPartitions = FLRDatabase.compareConfiguredAndBackedupVolumes(allPartitions, configuredFileSet, type);
            }
            if (backupMode.equals("FLR")) {
                info = inReader.readLine();
                while (true) {
                    List<String> driveList = new ArrayList<String>();
                    while (true) {
                        LogWriter.bmr.info("Drives: " + info);//NO I18N
                        driveList.add(info);
                        info = inReader.readLine();
                        if (info.equals("Status:")) {
                            break;
                        }
                    }
                    int diskStatus = Integer.parseInt(inReader.readLine());
                    if (diskStatus == 1) {
                        allPartitions = BMRDatabase.compareDrivesAndFiles(allPartitions, driveList, configuredFileSet);
                    } else {
                        while (!(info = inReader.readLine()).equals("DiskEnd")) {
                            JSONObject partition = new JSONObject();
                            partition.put("name", info);
                            partition.put("type", "File");
                            partition.put("status", inReader.readLine());
                            allPartitions.put(partition);
                        }
                    }
                    info = inReader.readLine();
                    if (info.equals("FileLevelEnd")) {
                        break;
                    }
                }
                info = inReader.readLine();
                Long filesTime = Long.parseLong(info);
                totalTime += filesTime;
                allPartitions = BMRDatabase.compareFilesConfiguredAndBackedUp(allPartitions, configuredFileSet);
            }
            File file = new File(backupFolder);
            if (backupMode.equals("VLR")) {
                HashMap<String, String> filesMap = new HashMap<String, String>();
                if (type.equals("FB")) {
                    String[] extension = new String[]{"img"};//No I18N
                    List<File> names = (List<File>) FileUtils.listFiles(file, extension, true);
                    for (int loop = 0; loop < names.size(); loop++) {
                        String partitionName = names.get(loop).getName();
                        String partitionAbsName = names.get(loop).getAbsolutePath();
                        String partitionNameWithoutExtn = FilenameUtils.removeExtension(partitionName);
                        filesMap.put(partitionNameWithoutExtn, partitionAbsName);
                    }
                    if (names.isEmpty()) {
                        for (int cnt = 0; cnt < totalPartitions; cnt++) {
                            JSONObject partition = allPartitions.getJSONObject(cnt);
                            partition.put("size", 0f);
                            partition.put("sizeUnit", "MB");
                        }
                    } else {
                        for (int cnt = 0; cnt < totalPartitions; cnt++) {
                            JSONObject partition = allPartitions.getJSONObject(cnt);
                            String statusVal = partition.get("status").toString();
                            if ((statusVal.equals("Inaccessible")) || (statusVal.equals("DiskFailed"))) {
                                partition.put("size", 0f);
                                partition.put("sizeUnit", "MB");
                            } else {
                                String name = partition.get("name").toString();
                                String fileName = "";
                                if (name.startsWith("Partition")) {
                                    fileName = filesMap.get(name);
                                } else if (name.contains(":")) {
                                    name = "Partition" + name.substring(0, 1);//No I18N
                                    fileName = filesMap.get(name);
                                }
                                File test = new File(fileName);
                                float size = (float) test.length();
                                if (size < 1024) {
                                    partition.put("size", Float.valueOf(String.format("%.1f", size).replace(",", ".")));
                                    partition.put("sizeUnit", "Bytes");
                                } else {
                                    float sizeKB = (float) size / (1024);
                                    if (sizeKB < 1024) {
                                        partition.put("size", Float.valueOf(String.format("%.1f", sizeKB).replace(",", ".")));
                                        partition.put("sizeUnit", "KB");
                                    } else {
                                        float sizeMB = (float) size / (1024 * 1024);
                                        if (sizeMB >= 1024) {
                                            float sizeGB = (float) sizeMB / 1024;
                                            partition.put("size", Float.valueOf(String.format("%.1f", sizeGB).replace(",", ".")));
                                            partition.put("sizeUnit", "GB");
                                        } else {
                                            partition.put("size", Float.valueOf(String.format("%.1f", sizeMB).replace(",", ".")));
                                            partition.put("sizeUnit", "MB");
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    String[] names = file.list();
                    for (String pName : names) {
                        File pFile = new File(backupFolder + "\\" + pName);
                        if (pFile.isDirectory()) {
                            filesMap.put(pName, (backupFolder + "\\" + pName));
                        }
                    }

                    for (int cnt = 0; cnt < totalPartitions; cnt++) {
                        JSONObject partition = allPartitions.getJSONObject(cnt);
                        String statusVal = partition.get("status").toString();
                        if ((statusVal.equals("Inaccessible")) || (statusVal.equals("DiskFailed"))) {
                            partition.put("size", 0f);
                            partition.put("sizeUnit", "MB");
                        } else {
                            String name = partition.get("name").toString();
                            String fileName = "";
                            if (name.startsWith("Partition")) {
                                fileName = filesMap.get(name);
                            } else if (name.contains(":")) {
                                name = "Partition" + name.substring(0, 1);//No I18N
                                fileName = filesMap.get(name);
                            }
                            float size = (float) FileUtils.sizeOfDirectory(new File(fileName));
                            if (size < 1024) {
                                partition.put("size", Float.valueOf(String.format("%.1f", size).replace(",", ".")));
                                partition.put("sizeUnit", "Bytes");
                            } else {
                                float sizeKB = (float) size / (1024);
                                if (sizeKB < 1024) {
                                    partition.put("size", Float.valueOf(String.format("%.1f", sizeKB).replace(",", ".")));
                                    partition.put("sizeUnit", "KB");
                                } else {
                                    float sizeMB = (float) size / (1024 * 1024);
                                    if (sizeMB >= 1024) {
                                        float sizeGB = (float) sizeMB / 1024;
                                        partition.put("size", Float.valueOf(String.format("%.1f", sizeGB).replace(",", ".")));
                                        partition.put("sizeUnit", "GB");
                                    } else {
                                        partition.put("size", Float.valueOf(String.format("%.1f", sizeMB).replace(",", ".")));
                                        partition.put("sizeUnit", "MB");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            finalSize = (float) FileUtils.sizeOfDirectory(file);
            status = "Completed";//No I18N
            if (backupMode.equals("VLR")) {
                for (int cnt = 0; cnt < allPartitions.length(); cnt++) {
                    JSONObject partition = allPartitions.getJSONObject(cnt);
                    String statusVal = partition.get("status").toString();
                    if ((statusVal.equals("Inaccessible")) || (statusVal.equals("Failed")) || (statusVal.equals("DiskFailed"))) {
                        status = "Failed";//No I18N
                        break;
                    }
                }
            } else if (backupMode.equals("FLR")) {
                for (int cnt = 0; cnt < allPartitions.length(); cnt++) {
                    JSONObject partition = allPartitions.getJSONObject(cnt);
                    String statusVal = partition.get("status").toString();
                    if ((!(statusVal.equalsIgnoreCase("Not found"))) && (!(statusVal.startsWith("Failed")))) {
                        foundFilesCnt++;
                    }
                }
                if (foundFilesCnt == 0) { //All selected files not found in the Server;Hence setting status to Failed;If only few files not found,Status not changed to Failed
                    status = "Failed";//No I18N
                }
            }
            details.put("status", status);
            details.put("finalSize", Float.toString(finalSize));
            details.put("totalTime", totalTime.toString());
            details.put("allPartitions", allPartitions.toString());
            inReader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return details;
    }

    public static void backupCode(String dcName, long backupId, long domainId, String type, String volumeCode, String fileCode, long fullBuId, int isEncrypted, String secretKey) {
        FileInputStream fis = null;
        BufferedReader inReader = null;
        try {
            Properties details = null;
            String backupFolder = "", status = "Started", folder = "", code = "";
            String files = "", folderUncPath;
            String backupMode = BMRDatabase.getBackupTypeFromId(backupId);
            if (backupMode.equals("VLR")) {
                code = volumeCode;
            } else if (backupMode.equals("FLR")) {
                code = fileCode;
            }
            long operationId;
            String domainName = (String) RMPDomainHandler.getDomainDetailsById(domainId).getProperty("DOMAIN_NAME");
            operationId = BMRDatabase.getLatestBackupId(backupId);
            int availableLicenseCount = LicenseUtil.licenseSubscriptionCount(Environment.windows_server);
            int appliedLicenseCount = LicenseUtil.getLicenseAppliedCount(Environment.windows_server);
            Properties prop = RMPDomainHandler.getDomainDetailsByName(domainName);

            String authenticationRequired = prop.getProperty("IS_AUTHENTICATION_REQUIRED");
            if (LicenseUtil.getDaysToExpire() <= 0) {
                BMRDatabase.updateBackupStatus(backupId, "Failed (License has expired)"); //No I18N
            } else if (BMRDatabase.getLicenseType(backupId) == LicenseType.Unlicensed && !(availableLicenseCount==-1 || (availableLicenseCount>0 && availableLicenseCount>appliedLicenseCount))) {
                BMRDatabase.updateBackupStatus(backupId, "Failed (" + dcName + " is not Licensed)");  //No I18N
            } else if (authenticationRequired != null && authenticationRequired.equalsIgnoreCase("false")) {  //No I18N
                BMRDatabase.updateBackupStatus(backupId, "Failed (Access Denied)");//No I18N
            } else {
                if (BMRDatabase.getLicenseType(backupId) == LicenseType.Unlicensed) {
                    BMRDatabase.applyLicense(backupId);
                }
                String domainFlatName = (String) prop.getProperty("USER_DOMAIN_NAME");
                String domainUser = (String) prop.getProperty("USER_NAME");
                String domainPwd = (String) prop.getProperty("PASSWORD");
                String finalUserName = domainFlatName + "\\" + domainUser + "###" + domainPwd;//No I18N
                Long totalTime = 0L;
                float finalSize = 0f;
                boolean isDeleted = BMRDatabase.isDCDeleted(backupId);
                if (!isDeleted) {
                    BMRDatabase.updateDCAgent(dcName, backupId, domainId);
                    String isAgentInstalled = BMRDatabase.getAgentInstallationStatus(backupId, domainId);
                    JSONObject repoStatus = BMRDatabase.isRepoEnabled(backupId);
                    boolean isRepoEnabled = (boolean) repoStatus.get("isEnabled");
                    boolean isRepoDeleted = (boolean) repoStatus.get("isDeleted");
                    if (isRepoDeleted) {
                        LogWriter.bmr.info("Repository deleted");//NO I18N
                        BMRDatabase.updateBackupStatus(backupId, "Failed (Repository deleted)"); //No I18N
                    } else if (!isRepoEnabled) {
                        LogWriter.bmr.info("Repository disabled");//NO I18N
                        BMRDatabase.updateBackupStatus(backupId, "Failed (Repository disabled)"); //No I18N
                    } else if (isAgentInstalled.equalsIgnoreCase("Backup configured")) {
                        JSONArray allPartitions = new JSONArray();
                        details = BMRDatabase.getLocationDetail(backupId);
                        String loc = details.get("Location").toString();
                        String name = details.get("User").toString();
                        String pwd = details.get("Password").toString();
                        Set<String> configuredFileSet = new HashSet<>();
                        Properties props = RMPNativeManager.checkCredentials(loc, name, pwd, "connect");//No I18N
                        if (props.get("Success") != null) {
                            Date now = new Date();
                            SimpleDateFormat dateFormat = new SimpleDateFormat("MM.dd.yyyy 'at' HH.mm");//No I18N
                            folder = dateFormat.format(now);
                            BMRDatabase.updateBackupLocation(backupId, folder);
                            String time = loc + "\\" + dcName + "\\" + folder; //No I18N
                            LogWriter.bmr.info("Backup location: " + time);//NO I18N
                            File dir = new File(time);
                            dir.mkdirs();
                            backupFolder = time;
                            Criteria scheduleCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), backupId, QueryConstants.EQUAL);
                            DataObject dObject = CommonUtil.getPersistence().get(TableName.BMR_BACKUP_SCHEDULE, scheduleCriteria);
                            if (!dObject.isEmpty()) {
                                Row row = (Row) dObject.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
                                JSONArray selectedPaths = new JSONArray((String) row.get("FILES_TO_BACKUP"));
                                for (int len = 0; len < selectedPaths.length(); len++) {
                                    JSONObject pathObj = (JSONObject) selectedPaths.get(len);
                                    folderUncPath = (String) pathObj.get("folderUncPath");
                                    LogWriter.bmr.info("Volume found " + folderUncPath);//NO I18N
                                    //String temp = folderUncPath.substring(1, (folderUncPath.length() - 1));
                                    String temp = "";
                                    if (folderUncPath.endsWith("\\")) {
                                        temp = folderUncPath.substring(1, (folderUncPath.length() - 1));
                                    } else {
                                        temp = folderUncPath.substring(1);
                                    }
                                    String path = temp.replaceFirst("\\$", ":");
                                    LogWriter.bmr.info("Volume truncated " + path);//NO I18N
                                    files += path + "<?>";
                                    LogWriter.bmr.info("Files " + files);//NO I18N
                                    configuredFileSet.add(path);
                                }
                            }

                            Properties disconnectProps = RMPNativeManager.checkCredentials(loc, name, pwd, "disconnect");//No I18N

                            if (!files.isEmpty()) {
                                status = BMRDatabase.triggerBackupAndUpdateStatus(finalUserName, dcName, domainFlatName, domainUser, domainPwd, backupFolder, name, pwd, code, files, isEncrypted, secretKey);
                            }

                        } else {
                            LogWriter.bmr.info("In backupCode....RMPNativeManager.checkCredentials failed "+props.toString());//No I18N
                            if(props.get("Invalid_Password")!=null || props.get("Logon_Failure") != null){
                                status = "Failed (Access denied to the repository)";//No I18N
                            } else {
                                status = "Failed (Location inaccessible)";//No I18N
                            }
                        }

                        if (status.equals("Started")) {
                            Properties props1 = RMPNativeManager.checkCredentials(loc, name, pwd, "connect");//No I18N
                            if (props1.get("Success") != null) {
                                try {
                                    File fin = new File(backupFolder + "\\BackupDetails.txt");
                                    fis = new FileInputStream(fin);
                                    inReader = new BufferedReader(new InputStreamReader(fis));
                                    Properties buDetails = FLRDatabase.readFromFLRBackupDetailsFile(type, backupFolder, inReader, backupMode, configuredFileSet);
                                    status = (String) buDetails.getProperty("status");
                                    finalSize = Float.parseFloat((String) buDetails.getProperty("finalSize"));
                                    totalTime = Long.valueOf(buDetails.getProperty("totalTime"));
                                    allPartitions = new JSONArray((String) buDetails.getProperty("allPartitions"));
                                    Properties disconnectProps1 = RMPNativeManager.checkCredentials(loc, name, pwd, "disconnect");//No I18N
                                } catch (Exception e) {
                                    LogWriter.bmr.info("In Backupcode catch");//NO I18N
                                    e.printStackTrace();
                                    status = "Failed (Location inaccessible)";//No I18N
                                }
                            } else {
                                LogWriter.bmr.info("In backupCode....RMPNativeManager.checkCredentials failed " + props1.toString());//No I18N
                                if (props1.get("Invalid_Password") != null || props1.get("Logon_Failure") != null) {
                                    status = "Failed (Access denied to the repository)";//No I18N
                                } else {
                                    status = "Failed (Location inaccessible)";//No I18N
                                }
                            }
                        }
                        BMRDatabase.updateIndividualBackupDetails(operationId, finalSize, allPartitions, folder, status, totalTime);
                        if (type.equals("IB")) {
                            BMRDatabase.storeIncrementalBackupDetails(fullBuId, operationId);
                        }
                        if (finalSize > 0f) {
                            BMRDatabase.updateTotalBackupDetails(domainName, domainId, backupId, finalSize, type);
                            if (type.equals("FB") && status.equals("Completed")) {
                                if (!BMRDatabase.deleteExcessBackups(backupId, domainName)) {
                                    LogWriter.bmr.info("Retention failed to delete old backups");//NO I18N
                                }
                            }
                        }
                    } else {
                        LogWriter.bmr.info("Agent installation has failed");//NO I18N
                        BMRDatabase.updateBackupStatus(backupId, "Failed (Retry Agent installation)");//No I18N
                    }
                } else {
                    LogWriter.bmr.info("DC has been deleted");//NO I18N
                    BMRDatabase.updateBackupStatus(backupId, "Failed (Server has been deleted)");//No I18N
                }
            }
            JSONObject mailData = MailInfoBMR.setBMRBackupMailInfo(operationId);

            LogWriter.general.info("Mail: Calling NotificationAPI.notifyBMR() from FLRDatabase.backupCode()");//No I18N
            NotificationAPI.notifyBMR(NotificationType.BMRBackup, mailData);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (inReader != null) {
                    inReader.close();
                }
                if (fis != null) {
                    fis.close();
                }
            } catch (Exception e) {
                LogWriter.bmr.info("In finally's catch");//NO I18N
                e.printStackTrace();
            }
        }
    }

    public static JSONObject restoreNow(JSONObject inputJSONObject) {
        JSONObject retVal = new JSONObject();
        FileInputStream fis = null;
        BufferedReader inReader = null;
        JSONArray drivesList = null;
        String origBackupType = "", restoreType = "";
        long restorePoint = -1;
        try {
            Set<String> configuredFileSet = new HashSet<>();
            String domain = (String) inputJSONObject.get("domain");
            String dcName = (String) inputJSONObject.get("dc");
            long dcId = Long.parseLong(inputJSONObject.get("dcId").toString());
            restoreType = (String) inputJSONObject.get("type");
            int restorePointTemp = Integer.parseInt(inputJSONObject.get("restorePtId").toString());
            restorePoint = (long) restorePointTemp;
            origBackupType = BMRDatabase.getBackupTypeFromOpId(restorePoint);
            drivesList = (JSONArray) inputJSONObject.get("drivesList");
            boolean isRestorePointFullBackup = false;
            String filesStr = URLDecoder.decode(GeneralUtil.replaceChar(inputJSONObject, "filesToRestore"), "UTF-8");// No I18N
            JSONArray filesToRestore = new JSONArray(filesStr);
            int restoreOption = (Integer) inputJSONObject.get("restoreOption");
            String initiator = URLDecoder.decode(GeneralUtil.replaceChar(inputJSONObject, "initiator"), "UTF-8");// No I18N
            String downloadPath = URLDecoder.decode(GeneralUtil.replaceChar(inputJSONObject, "downloadPath"), "UTF-8");// No I18N
            String mergeFolder = URLDecoder.decode(GeneralUtil.replaceChar(inputJSONObject, "mergeFolder"), "UTF-8");// No I18N
            int operIdTemp = (Integer) inputJSONObject.get("operationId");
            long operId = (long) operIdTemp;
            Properties prop = RMPDomainHandler.getDomainDetailsByName(domain);
            String domainFlatName = (String) prop.getProperty("USER_DOMAIN_NAME");
            String domainUser = (String) prop.getProperty("USER_NAME");
            String domainPwd = (String) prop.getProperty("PASSWORD");
            String finalUserName = domainFlatName + "\\" + domainUser;//No I18N

            Properties locDetails = BMRDatabase.getBackupFolder(restorePoint);
            String mergeUser = locDetails.getProperty("User");
            String mergePwd = locDetails.getProperty("Password");
            int type, result = 0, mode;
            boolean isEncrypted = false;
            String secretKey = "";
            Date date = Calendar.getInstance().getTime();
            Timestamp backupTime = DateUtil.getTimestampFromDate(date);
            Map<String, Map> renameManagerMap = null;

            Criteria idCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), restorePoint, QueryConstants.EQUAL);
            DataObject dataObject = CommonUtil.getPersistence().get(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, idCriteria);
            if (!dataObject.isEmpty()) {
                Row row = (Row) dataObject.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                backupTime = (Timestamp) row.get("START_TIME");
                isEncrypted = (boolean) row.get("IS_ENCRYPTED");
                if (isEncrypted) {
                    secretKey = (String) row.get("SECRETKEY");
                }
            }
            int currentEncryptionStatus = (isEncrypted) ? 1 : 0;
            if (origBackupType.equalsIgnoreCase("BMR")) {
                type = 0;
            } else {
                type = 1;
            }

            if (origBackupType.equalsIgnoreCase("FLR")) {
                mode = 0;
            } else if (origBackupType.equalsIgnoreCase("BMR")) {
                mode = 1;
            } else {
                mode = 2;
            }

            Properties restoreLocDetails = null;

            if (BMRDatabase.isFullBackup(restorePoint)) {
                isRestorePointFullBackup = true;
            } else {
                isRestorePointFullBackup = false;
            }

            if (isRestorePointFullBackup) {
                restoreLocDetails = locDetails;
            } else {
                restoreLocDetails = BMRDatabase.getBackupFolder(getIBParentId(restorePoint));
            }

            String restoreLoc = restoreLocDetails.get("backupFolder").toString();
            String restoreUname = restoreLocDetails.get("User").toString();
            String restorePwd = restoreLocDetails.get("Password").toString();
            String restoreFilePath;

            Date now = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy_HH.mm.ss"); //No I18N
            String restoreFolder = "restoreDetails_" + dateFormat.format(now) + ".txt"; //No I18N
            restoreFilePath = restoreLoc + "\\" + restoreFolder;
            String status = "Started";//NO I18N
            String files = "";
            String incrFiles = "";
            String volLevelFiles = "";
            String drives = "";

            long operationId = FLRDatabase.storeIndividualRestoreDetails(dcId, restorePoint, now, filesToRestore, restoreType, restoreOption, downloadPath, backupTime, initiator);
            if (operId != -1) {
                BMRDatabase.deleteRestoreDetailsRow(operId);
            }

            if (LicenseUtil.getDaysToExpire() <= 0) {
                status = "License has expired. Please upgrade your license."; //No I18N
                retVal.put("result", status); //No I18N
                retVal.put("stopSpinner", true); //No I18N
                FLRDatabase.updateRestoreStatus(operationId, status, 0L, new JSONArray());
                throw new Exception(status);
            }
            if (BMRDatabase.getLicenseType(dcId) == LicenseType.Unlicensed) {
                status = "Failed (" + dcName + " is not Licensed)"; //No I18N
                retVal.put("result", status); //No I18N
                retVal.put("stopSpinner", true); //No I18N
                FLRDatabase.updateRestoreStatus(operationId, status, 0L, new JSONArray());
                throw new Exception(status);
            }
            BMRThreadManager manager = BMRThreadManager.getBMRThreadManager();

            if (operId != -1) {
                if (!isRestorePointFullBackup) {
                    boolean isBMRBackup;
                    File mergeFile = new File(mergeFolder);
                    if (mergeFile.list()[0].startsWith("Harddisk")) {
                        isBMRBackup = true;
                    } else {
                        isBMRBackup = false;
                    }
                    String mountRetVal = (String) manager.getRetVal("mount_" + restorePoint);//No I18N
                    for (int i = 0; i < drivesList.length(); i++) {
                        JSONObject drivObj = drivesList.getJSONObject(i);
                        String rDriveLetter = (String) drivObj.get("displayName");
                        rDriveLetter = rDriveLetter.substring(0, rDriveLetter.indexOf(":"));
                        String rDrivePath = "";
                        if (isBMRBackup) {
                            for (File file : mergeFile.listFiles()) {
                                String eachPath = file.getAbsolutePath();
                                String partitionPath = eachPath + "\\" + "Partition" + rDriveLetter;
                                if (new File(partitionPath).exists()) {
                                    rDrivePath = partitionPath;
                                    break;
                                }
                            }
                        } else {
                            rDrivePath = mergeFolder + File.separator + "Partition" + rDriveLetter;//No I18N
                        }
                        File partitionFile = new File(rDrivePath);

                        if (partitionFile.exists()) {
                            Map<String, String> renameEntriesSorted = null;
                            Map<String, String> deleteEntries;
                            Map<String, Map> renameMap = manager.renameEntries;
                            if (renameMap == null) {
                                String partitionFullPath = partitionFile.getAbsolutePath();
                                String renameFilePath = partitionFullPath + File.separator + "rename_file.txt";//No I18N
                                Map<String, String> renameEntries = BMRConfiguration.getChangedEntries(renameFilePath, false);
                                renameMap = new LinkedHashMap<>();
                                renameMap.put(rDriveLetter + ":", renameEntries);
                                manager.renameEntries = renameMap;
                            } else {
                                String partitionFullPath = partitionFile.getAbsolutePath();
                                String renameFilePath = partitionFullPath + File.separator + "rename_file.txt";//No I18N
                                Map<String, String> renameEntries = BMRConfiguration.getChangedEntries(renameFilePath, false);
                                renameMap.put(rDriveLetter + ":", renameEntries);
                            }
                        }
                    }
                }
                for (int len = 0; len < filesToRestore.length(); len++) {
                    String folderPathTemp = "";
                    JSONObject pathObj = (JSONObject) filesToRestore.get(len);
                    String folderPath = (String) pathObj.get("folderPath");
                    String displayPath = (String) pathObj.get("folderUncPath");
                    if (displayPath.endsWith("\\")) {
                        displayPath = displayPath.substring(0, (displayPath.length() - 1));
                    }
                    for (int i = 0; i < drivesList.length(); i++) {
                        JSONObject obj = (JSONObject) drivesList.get(i);
                        String drive = obj.getString("value");
                        String displayName = obj.getString("displayName");
                        folderPathTemp = folderPath;
                        if (displayPath.startsWith(displayName)) {
                            folderPathTemp = drive + folderPath.substring(folderPath.indexOf(":") + 1, folderPath.length());
                            break;
                        }
                    }
                    files += folderPathTemp + "<?>";
                    volLevelFiles += displayPath + "<?>";
                    configuredFileSet.add(displayPath);

                    if (pathObj.has("mergePath")) {
                        incrFiles += (String) pathObj.get("mergePath") + "<?>";
                    }
                }
            } else {
                for (int len = 0; len < filesToRestore.length(); len++) {
                    JSONObject pathObj = (JSONObject) filesToRestore.get(len);
                    String folderPath = (String) pathObj.get("folderPath");
                    String displayPath = (String) pathObj.get("folderUncPath");
                    if (displayPath.endsWith("\\")) {
                        displayPath = displayPath.substring(0, (displayPath.length() - 1));
                    }
                    files += folderPath + "<?>";
                    volLevelFiles += displayPath + "<?>";
                    configuredFileSet.add(displayPath);

                    if (pathObj.has("mergePath")) {
                        incrFiles += (String) pathObj.get("mergePath") + "<?>";
                    }
                }
            }
            if (incrFiles.isEmpty()) {
                incrFiles = "-";
            }
            for (int i = 0; i < drivesList.length(); i++) {
                JSONObject obj = (JSONObject) drivesList.get(i);
                String drive = obj.getString("value");
                String displayName = obj.getString("displayName");
                drives += Character.toString(drive.charAt(0)) + "--" + Character.toString(displayName.charAt(0)) + "<?>";
            }
            manager.setStatus("restore_" + restorePoint, BMRThreadManager.STARTED); // No I18N

            if (restoreType.equals("FLR")) {
                String renamedFiles = "";

                if (!isRestorePointFullBackup && !origBackupType.equalsIgnoreCase("FLR")) {
                    renameManagerMap = manager.renameEntries;

                    if (renameManagerMap != null) {
                        for (Map.Entry<String, Map> entry : renameManagerMap.entrySet()) {
                            String driveLetter = entry.getKey();
                            Map<String, String> renameMap = entry.getValue();
                            for (Map.Entry<String, String> cEntry : renameMap.entrySet()) {
                                String oldName = driveLetter + File.separator + cEntry.getKey();
                                String newName = driveLetter + File.separator + cEntry.getValue();
                                renamedFiles += oldName + "--" + newName + "<?>";
                            }
                        }
                    }
                }

                if (renamedFiles.isEmpty()) {
                    renamedFiles = "-";
                }
                result = RMPNativeManager.performFLR(restoreOption, mode, "\\\\" + dcName, finalUserName, domainPwd, mergeFolder, mergeUser, mergePwd, files, incrFiles, drives, downloadPath, restoreFilePath, restoreUname, restorePwd, renamedFiles, isEncrypted, secretKey);//No I18N
                LogWriter.bmr.info("performFLR result: " + result); // No I18N
                if (result == 0) {
                    status = "Started"; // No I18N
                } else if (result == 112 || result == 28) {
                    status = "Failed (Insufficient space in the destination)";//NO I18N
                } else if (result == 1326) {
                    status = "Failed (Access Denied)";//NO I18N
                } else if (result == -1) {
                    status = "Failed (Server inaccessible)";//NO I18N
                } else if (result == -2) {
                    status = "Failed (Repository inaccessible)";//NO I18N
                } else {
                    status = "Failed"; // No I18N
                }
            } else {
                Properties rpcResult = RMPNativeManager.performVLR("\\\\" + dcName, domainFlatName, domainUser, domainPwd, restoreLoc, restoreUname, restorePwd, volLevelFiles, type, mergeFolder, mergeUser, mergePwd, restoreFilePath, currentEncryptionStatus, secretKey);
                LogWriter.bmr.info("performVLR returned:" + rpcResult);//NO I18N

                if (rpcResult.get("CantAccess") != null) {
                    if ((Integer) rpcResult.get("CantAccess") == 5) {
                        int rpcVal = (int) rpcResult.get("CantAccess");
                        LogWriter.bmr.severe("RPC call (performVLR) failed with error: " + rpcVal);//NO I18N
                        status = "Failed (Access Denied)";//NO I18N
                    } else {
                        LogWriter.bmr.info("Restore: Agent not running. Executing RestartService.bat to attempt restart");//NO I18N
                        int res = WindowsHandler.executeCommand(dcName, finalUserName, "*", "C:\\Program Files\\ManageEngine\\RMP\\RestartService.bat", true);//No I18N

                        if (res == 16) {
                            rpcResult = RMPNativeManager.performVLR("\\\\" + dcName, domainFlatName, domainUser, domainPwd, restoreLoc, restoreUname, restorePwd, volLevelFiles, type, mergeFolder, mergeUser, mergePwd, restoreFilePath, currentEncryptionStatus, secretKey);
                        } else {
                            LogWriter.bmr.severe("Calling RestartService.bat: Remcom failed with error code: " + res);//NO I18N
                        }

                        if (rpcResult.get("CantAccess") != null) {
                            int rpcVal = (int) rpcResult.get("CantAccess");
                            if (rpcVal == 5) {
                                LogWriter.bmr.severe("RPC call (performVLR) failed with error: " + rpcVal);//NO I18N
                                status = "Failed (Access Denied)";//NO I18N
                            } else {
                                LogWriter.bmr.severe("RPC call (performVLR) failed with error: " + rpcVal);//NO I18N
                                status = "Failed (Could not contact Agent)";//NO I18N
                            }
                        }
                    }
                }
                if (status.equals("Started")) {
                    if (rpcResult.get("ReturnVal") != null) {
                        int rpcVal = (int) rpcResult.get("ReturnVal");

                        if (rpcVal == 53) {
                            status = "Failed (Location inaccessible from Server)";//NO I18N
                        } else if (rpcVal == 456) {
                            status = "Failed (Volume(s) not found)";//NO I18N
                        } else if (rpcVal == 3) {
                            status = "Failed (Insufficient space in the destination)";//NO I18N
                        } else if (rpcVal == 1326 || rpcVal == 86) {
                            status = "Failed (Access denied to the repository)";//NO I18N
                        } else if (rpcVal != 0) {
                            status = "Failed";//NO I18N
                        }
                    }
                }
            }

            DecimalFormat formatter = new DecimalFormat("00");
            JSONArray allPartitions = new JSONArray();
            String info = null;
            int partitionsCnt = 0, totalPartitions = 0;
            Long totalTime = 0L;

            if (status.equals("Started")) {
                Properties props1 = RMPNativeManager.checkCredentials(restoreLoc, restoreUname, restorePwd, "connect");//No I18N
                JSONObject retObj = readRestoreDetails(dcName, domain, restoreFilePath, operationId, restoreType, configuredFileSet, renameManagerMap);
                status = (String) retObj.get("status");
                totalTime = (Long) retObj.get("totalTime");
                allPartitions = (JSONArray) retObj.get("allPartitions");
                Properties disconnectProps = RMPNativeManager.checkCredentials(restoreLoc, restoreUname, restorePwd, "disconnect");//No I18N
            }

            if (status.contains("Failed")) {
                manager.setStatus("restore_" + restorePoint, BMRThreadManager.FAILED); // No I18N
            } else {
                manager.setStatus("restore_" + restorePoint, BMRThreadManager.SUCCESS); // No I18N
            }

            FLRDatabase.updateRestoreStatus(operationId, status, totalTime, allPartitions);

            JSONObject mailData = MailInfoBMR.setBMRRestoreMailInfo(operationId);

            LogWriter.general.info("Mail: Calling NotificationAPI.notifyBMR() from FLRDatabase.restoreNow()");//No I18N
            NotificationAPI.notifyBMR(NotificationType.BMRRestore, mailData);

            manager.clearData();
            retVal.put("result", status);
            retVal.put("stopSpinner", true);

            return retVal;

        } catch (Exception ex) {
            BMRThreadManager.getBMRThreadManager().clearData();
            ex.printStackTrace();
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
                if (inReader != null) {
                    inReader.close();
                }
                if (!origBackupType.equalsIgnoreCase("FLR")) {
                    if (!restoreType.equals("VLR")) {
                        FLRDatabase.unmountDrives();
                    }
                } else {
                    for (int i = 0; i < drivesList.length(); i++) {
                        JSONObject obj = (JSONObject) drivesList.get(i);
                        String drive = obj.getString("value");
                        RMPMountManager.unmountFileLevelBackup(drive);
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                BMRThreadManager.getBMRThreadManager().clearData();
                FLRDatabase.markMountDismount(restorePoint, 0, new JSONArray());
            }
        }

        return retVal;
    }

    public static long storeIndividualRestoreDetails(long dcId, long backupPt, Date date, JSONArray fileToRestore, String restoreType, int restoreOption, String downloadPath, Timestamp time, String initiator) {
        try {
            //Date date = Calendar.getInstance().getTime();
            Timestamp startTime = DateUtil.getTimestampFromDate(date);
            String status = "Started";// No I18N
            DataObject dataobj = CommonUtil.getPersistence().constructDataObject();
            Row row = new Row(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS);
            DataAccess.generateValues(row);
            row.set("DC_ID", dcId);// No I18N
            row.set("START_TIME", startTime);// No I18N
            row.set("BACKUP_POINT", backupPt);// No I18N
            row.set("TIME_TAKEN", 0L);// No I18N
            row.set("STATUS", status);// No I18N
            row.set("FILES_TO_RESTORE", fileToRestore.toString());// No I18N
            row.set("RESTORE_TYPE", restoreType);// No I18N
            row.set("RESTORE_OPTION", restoreOption);// No I18N
            row.set("DOWNLOAD_PATH", downloadPath);// No I18N
            row.set("RESTORE_TYPE", restoreType);// No I18N
            row.set("BACKUP_TIME", time);// No I18N
            row.set("INITIATOR", initiator);// No I18N
            dataobj.addRow(row);
            CommonUtil.getPersistence().add(dataobj);
            return (long) row.get("OPERATION_ID");
        } catch (Exception e) {
            e.printStackTrace();
            return 0L;
        }
    }

    public static void updateRestoreStatus(long operationId, String status, Long totalTime, JSONArray allPartitions) {
        try {
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "OPERATION_ID"), operationId, QueryConstants.EQUAL);
            UpdateQuery query = new UpdateQueryImpl(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS);
            query.setUpdateColumn("STATUS", status); //No I18N
            query.setUpdateColumn("TIME_TAKEN", totalTime); //No I18N
            query.setUpdateColumn("FILES_TO_RESTORE", allPartitions.toString()); //No I18N
            query.setCriteria(criteria);
            CommonUtil.getPersistence().update(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateRestStatus(long opId, String status) {
        try {
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            UpdateQuery query = new UpdateQueryImpl(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS);
            query.setUpdateColumn("STATUS", status); //No I18N
            query.setCriteria(criteria);
            CommonUtil.getPersistence().update(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static JSONObject readRestoreDetails(String dcName, String domainName, String restoreFilePath, long operationId, String restoreType, Set configuredFileSet, Map<String, Map> renameManagerMap) {
        JSONObject retObj = new JSONObject();
        FileInputStream fis = null;
        BufferedReader inReader = null;
        String status = "";
        Long totalTime = 0L;
        JSONArray allPartitions = new JSONArray();
        try {
            status = "Failed";//No I18N
            retObj.put("status", status);
            retObj.put("totalTime", totalTime);
            retObj.put("allPartitions", allPartitions);
            DecimalFormat formatter = new DecimalFormat("00");
            String info = null;
            int partitionsCnt = 0, totalPartitions = 0;
            File fin;
            fin = new File(restoreFilePath);
            fis = new FileInputStream(fin);
            inReader = new BufferedReader(new InputStreamReader(fis));

            if (restoreType.equals("VLR")) {
                while ((info = inReader.readLine()) != null) {
                    JSONArray partitions = new JSONArray();
                    partitionsCnt = 0;

                    do {
                        JSONObject partition = new JSONObject();
                        partition.put("name", info);
                        partitions.put(partition);
                        partitionsCnt++;
                    } while (!(info = inReader.readLine()).equals("Status:"));

                    int diskStatus = Integer.parseInt(inReader.readLine());

                    for (int cnt = 0; cnt < partitionsCnt; cnt++) {
                        if (diskStatus == 1) {
                            info = "DiskFailed";//NO I18N
                        } else {
                            info = inReader.readLine();
                        }
                        JSONObject partition = partitions.getJSONObject(cnt);
                        partition.put("status", info);
                    }
                    if (diskStatus == 0) {
                        info = inReader.readLine();
                    }
                    for (int cnt = 0; cnt < partitionsCnt; cnt++) {
                        JSONObject partition = partitions.getJSONObject(cnt);
                        String statusVal = partition.get("status").toString();
                        if ((statusVal.equals("Inaccessible")) || (statusVal.equals("DiskFailed"))) {
                            partition.put("TimeTaken", "0");
                        } else {
                            info = inReader.readLine();
                            Long time = Long.parseLong(info);
                            partition.put("TimeTaken", formatter.format(time));
                            totalTime += time;
                        }
                    }
                    totalPartitions += partitionsCnt;
                    for (int j = 0; j < partitions.length(); j++) {
                        allPartitions.put(partitions.getJSONObject(j));
                    }
                }
                allPartitions = FLRDatabase.compareConfiguredAndRestoredVolumes(allPartitions, configuredFileSet);
            } else if (restoreType.equals("FLR")) {
                Map<String, Integer> filesList = new HashMap<>();
                while ((info = inReader.readLine()) != null) {
                    JSONObject partition = new JSONObject();
                    partition.put("name", info);
                    String stat = inReader.readLine();
                    partition.put("status", stat);
                    Long filesTime = Long.parseLong(inReader.readLine());
                    if (filesTime == 0L && stat.equals("Success")) {
                        filesTime = 1L;
                    }
                    partition.put("TimeTaken", formatter.format(filesTime));

                    if (renameManagerMap != null) {
                        String tempName = info.substring(3);
                        String origDrive = info.substring(0, 2);
                        boolean check = false;
                        Map<String, String> renameMap = renameManagerMap.get(origDrive);
                        if (renameMap != null) {
                            while (renameMap.containsKey(tempName)) {
                                tempName = renameMap.get(tempName);
                                check = true;
                            }
                            if (check) {
                                info = origDrive + File.separator + tempName;
                            }
                        }
                    }

                    if (!filesList.containsKey(info)) {
                        filesList.put(info, partitionsCnt++);
                        partition.put("name", info);
                        allPartitions.put(partition);
                    } else {
                        int index = filesList.get(info);
                        JSONObject obj = allPartitions.getJSONObject(index);
                        String name = obj.get("name").toString();
                        Long time = obj.getLong("TimeTaken") + filesTime;//No I18N
                        if (name.equalsIgnoreCase(info)) {
                            obj.put("status", partition.get("status").toString());
                            obj.put("TimeTaken", formatter.format(time));
                        }
                    }
                    totalTime += filesTime;
                }
                totalPartitions += partitionsCnt;
            }
            status = "Completed";//NO I18N
            if (restoreType.equals("VLR")) {
                for (int cnt = 0; cnt < totalPartitions; cnt++) {
                    JSONObject partition = allPartitions.getJSONObject(cnt);
                    String statusVal = partition.get("status").toString();
                    if ((statusVal.equals("Inaccessible")) || (statusVal.startsWith("Failed")) || (statusVal.equals("DiskFailed"))) {
                        if (totalPartitions == 1) {
                            status = statusVal;
                        } else {
                            status = "Failed (Few volumes failed)";//NO I18N
                        }
                        break;
                    }
                }
            } else if (restoreType.equals("FLR")) {
                int restoreFailedStatus = 0, restoreAccesDenied = 0, restoreSuccessStatus = 0, restoreFileInUse = 0;
                for (int cnt = 0; cnt < totalPartitions; cnt++) {
                    JSONObject partition = allPartitions.getJSONObject(cnt);
                    String statusVal = partition.get("status").toString();
                    if (statusVal.startsWith("Failed")) {
                        restoreFailedStatus++;
                        if (statusVal.equals("Failed (Restricted Access)")) {
                            restoreAccesDenied++;
                        } else if (statusVal.equals("Failed (File in use by another process)")) {
                            restoreFileInUse++;
                        }
                    } else {
                        restoreSuccessStatus++;
                    }
                }
                if (restoreFailedStatus == 0) {
                    status = "Completed";//NO I18N
                } else if (restoreSuccessStatus > 0 && restoreFailedStatus > 0) {
                    status = "Failed (Few files failed)";//NO I18N
                } else if (restoreSuccessStatus == 0) {
                    if (restoreAccesDenied == restoreFailedStatus) {
                        status = "Failed (Restricted Access)";//NO I18N
                    } else if (restoreFileInUse == restoreFailedStatus) {
                        status = "Failed (File in use by another process)";//NO I18N
                    } else {
                        status = "Failed";//NO I18N
                    }
                }
            }
            retObj.put("status", status);
            retObj.put("totalTime", totalTime);
            retObj.put("allPartitions", allPartitions);

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
                if (inReader != null) {
                    inReader.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return retObj;
    }

    public static Map getRepoDetailsFromPath(String repositoryPath) {
        Map<String, String> map = new HashMap();
        try {
            DataObject dObj = CommonUtil.getPersistence().get(TableName.RMP_STORAGE_REPOSITORY, (Criteria) null);
            Criteria crit = new Criteria(Column.getColumn(TableName.RMP_STORAGE_REPOSITORY, "REPOSITORY_PATH"), repositoryPath, QueryConstants.EQUAL);
            Criteria localCrit = new Criteria(Column.getColumn(TableName.RMP_STORAGE_REPOSITORY, "IS_LOCAL"), false, QueryConstants.EQUAL);
            Iterator iterator = dObj.getRows(TableName.RMP_STORAGE_REPOSITORY, crit.and(localCrit));
            while (iterator.hasNext()) {
                Row row = (Row) iterator.next();
                map.put("REPOSITORY_USERNAME", (String) row.get("REPOSITORY_USERNAME"));
                map.put("REPOSITORY_PATH", (String) row.get("REPOSITORY_PATH"));
                map.put("REPOSITORY_PASSWORD", (String) row.get("REPOSITORY_PASSWORD"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }

    public static void markMountDismount(long opId, int mountVal, JSONArray drivesList) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("mountVal", mountVal);
            obj.put("drivesList", drivesList);
            String objStr = "";
            if (drivesList.length() == 0) {
                BMRThreadManager.getBMRThreadManager().stopTimer();
                objStr = "-";
            } else {
                BMRThreadManager.getBMRThreadManager().startTimer();
                objStr = obj.toString();
            }
            Criteria opCrit = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            UpdateQuery updateQuery = new UpdateQueryImpl(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
            updateQuery.setCriteria(opCrit);
            updateQuery.setUpdateColumn("IS_MOUNTED", objStr); //No I18N
            CommonUtil.getPersistence().update(updateQuery);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static boolean checkMountStatus(long opId) {
        boolean isMounted = false;

        try {
            int mountVal;
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            DataObject dobj = CommonUtil.getPersistence().get(query);

            if (!dobj.isEmpty()) {
                Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                if (row.get("IS_MOUNTED") != null) {
                    String isMountedVal = row.get("IS_MOUNTED").toString();
                    if (!isMountedVal.equals("-")) {
                        JSONObject sObj = new JSONObject(isMountedVal);
                        mountVal = sObj.getInt("mountVal"); // No I18N
                        if (mountVal != 0) {
                            isMounted = true;
                        }
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return isMounted;
    }

    public static JSONObject getMountedPointDetails() {
        JSONObject retObj = new JSONObject();

        try {
            retObj.put("noRows", true);
            SimpleDateFormat timestampFormat = new SimpleDateFormat("dd MMM yyyy, HH:mm");// No I18N
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "IS_MOUNTED"), "-", QueryConstants.NOT_LIKE);
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            DataObject dobj = CommonUtil.getPersistence().get(query);

            if (!dobj.isEmpty()) {
                Row row = dobj.getFirstRow(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                JSONObject data = new JSONObject();

                String time = timestampFormat.format((Timestamp) row.get("START_TIME"));
                String type = (String) row.get("BACKUP_TYPE");
                String backup = "";

                if (type.equals("FB")) {
                    backup = " (Full Backup)";//No I18N
                } else if (type.equals("IB")) {
                    backup = " (Incremental Backup)";//No I18N
                }

                String rPoint = time + backup;
                long dcId = (long) row.get("DC_ID");
                String domainName = BMRDatabase.getDomainNamefromDcId(dcId);
                String dcName = BMRDatabase.getNameFromId(dcId);
                String backupType = (String) row.get("BACKUP_TYPE");
                JSONObject mountObj = new JSONObject(row.get("IS_MOUNTED").toString());
                int isMounted = mountObj.getInt("mountVal"); // No I18N
                JSONArray drivesList = mountObj.getJSONArray("drivesList"); // No I18N
                long opId = (long) row.get("OPERATION_ID");
                String rType = "";

                if (isMounted == 1) {
                    rType = "VLR"; // No I18N
                } else if (isMounted == 2) {
                    rType = "FLR"; // No I18N
                }

                retObj.put("noRows", false);
                retObj.put("opId", opId);
                retObj.put("domain", domainName);
                retObj.put("dc", dcName);
                retObj.put("dcId", dcId);
                retObj.put("rType", rType);
                retObj.put("rPoint", rPoint);
                retObj.put("drivesList", drivesList);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return retObj;
    }

    public static void unmountDrives(long opId) {
        try {
            BMRThreadManager manager = BMRThreadManager.getBMRThreadManager();
            JSONObject retObj = getMountedPointDetails();
            JSONArray drivesList = !retObj.getBoolean("noRows") ? retObj.getJSONArray("drivesList") : new JSONArray(); // No I18N

            if (opId == -1) {
                if (!retObj.getBoolean("noRows")) {
                    opId = retObj.getLong("opId"); // No I18N
                    if (retObj.getString("rType").equalsIgnoreCase("VLR")) {
                        manager.clearData();
                        FLRDatabase.markMountDismount(opId, 0, new JSONArray());
                        return;
                    }
                } else {
                    return;
                }
            }

            String origBackupType = BMRDatabase.getBackupTypeFromOpId(opId);
            if (origBackupType.equalsIgnoreCase("BMR") || origBackupType.equalsIgnoreCase("VLR")) {
                FLRDatabase.unmountDrives();
            } else {
                for (int i = 0; i < drivesList.length(); i++) {
                    JSONObject obj = (JSONObject) drivesList.get(i);
                    String drive = obj.getString("value");
                    RMPMountManager.unmountFileLevelBackup(drive);
                }
            }
            manager.clearData();
            FLRDatabase.markMountDismount(opId, 0, new JSONArray());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
