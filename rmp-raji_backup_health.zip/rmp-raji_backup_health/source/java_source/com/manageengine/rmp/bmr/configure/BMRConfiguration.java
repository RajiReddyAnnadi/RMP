/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.bmr.configure;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.agent.installation.WindowsHandler;
import com.manageengine.ads.fw.filebrowser.FileBrowserHandler;
import com.manageengine.ads.fw.ldap.ad.ADSADException;
import com.manageengine.ads.fw.license.LicenseManager;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.bmr.BMRLicenseHandler;
import com.manageengine.rmp.bmr.BMRThreadManager;
import com.manageengine.rmp.bmr.agent.InstallAgent;
import com.manageengine.rmp.bmr.schedule.BMRNewDc;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.RMPCommonUtil;
import com.manageengine.rmp.constants.RmpConstants;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.jni.BMRIso;
import com.manageengine.rmp.jni.RMPNativeManager;
import com.manageengine.rmp.licensing.*;
import com.manageengine.rmp.settings.DomainSettingsAction;
import com.manageengine.rmp.technician.RMPTechnicianHandler;
import com.manageengine.rmp.util.GeneralUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import com.manageengine.rmp.util.winutil.WindowsUtil;
import org.apache.commons.io.FileUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.InetAddress;
import java.net.URLDecoder;
import java.sql.Timestamp;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.manageengine.rmp.bmr.configure.BMRDatabase.updateInstalledGUID;
import static com.manageengine.rmp.settings.DomainSettings.getDomainDetailsFromProperties;

/**
 *
 * @author Chella-3221
 */
//ignoreI18n_start
public class BMRConfiguration extends DispatchAction {

    public ActionForward getDC(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            String domainName = (String) inputJSONObject.get("domain");
            String machineType = (String) inputJSONObject.get("machineType");
            JSONArray retArray = BMRDatabase.getBMRDcs(domainName, machineType,true);

            // if free license got applied, need to reframe license
            if (machineType.equalsIgnoreCase("SERVER") && retArray.length() > 0) {
                LicenseUtil.checkAndUpdateLicense(Environment.windows_server);
            }

            out.println(retArray.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward getUnconfiguredDC(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            String domainName = (String) inputJSONObject.get("domain");
            String machineType = (String) inputJSONObject.get("machineType");
            //JSONArray dcsList = ADDiscoveryHandler.getDCNames(domainName);
            // List dcsList = RMPDomainHandler.getDCList(domainName);
            JSONArray retArray = BMRDatabase.getUnconfiguredDcs(domainName, machineType);

            out.println(retArray.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkDomain(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            String domainName = (String) inputJSONObject.get("domain");
            boolean result = false;
            if (RMPDomainHandler.getDomainDetailsByName(domainName).getProperty("IS_AUTHENTICATION_REQUIRED").equals("false")) {
                result = true;
            }
            JSONObject status = new JSONObject();
            status.put("result", result);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward firstInstall(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            response.setContentType(RmpConstants.CONTENT_TYPE);
            String domain = (String) inputJSONObject.get("domain");
            String configType = (String) inputJSONObject.get("configType");
            JSONArray dcArray = (JSONArray) inputJSONObject.getJSONArray("dc");// No I18N

            Properties details = RMPDomainHandler.getDomainDetailsByName(domain);
            long domainId = Long.valueOf(details.getProperty("DOMAIN_ID"));
            String domainName = (String) details.getProperty("USER_DOMAIN_NAME");
            String pwd = (String) details.getProperty("PASSWORD");
            String name = domainName + "\\" + (String) details.getProperty("USER_NAME") + "###" + pwd;//No I18N
            String[] param = {"OSArchitecture"};// No I18N
            String latestAgent64 = BMRDatabase.getLatestAgentGUID("BMR64");
            String latestAgent32 = BMRDatabase.getLatestAgentGUID("BMR32");
            String result, agentName = "BMR64", latestGUID = latestAgent64;
            for (int i = 0; i < dcArray.length(); i++) {
                JSONObject jsObject = (JSONObject) dcArray.get(i);
                String dcName = (String) (jsObject.get("dcName"));
                long dcId = Long.parseLong(jsObject.get("dcId").toString());
                String finalName = "";
                boolean osArchitectureKnown = false;
                String dnsName = BMRDatabase.getFQDNFromFlatName(dcId);
                if (dnsName == null || dnsName.isEmpty()) {
                    dnsName = dcName;
                }

                boolean isPingable = BMRDatabase.isPingable(dcName);
                if (isPingable) {
                    finalName = dcName;
                } else {
                    isPingable = BMRDatabase.isPingable(dnsName);
                    if (isPingable) {
                        finalName = dnsName;
                    } else {
                        LogWriter.bmr.info("Ping failed.DC is inaccessible");//NO I18N
                        BMRDatabase.updateStatus(domain, dcName, dcId, "Installation failed", "Server inaccessible");
                    }
                }

                if (!finalName.isEmpty()) {
                    try {
                        result = BMRDatabase.getOSArchitecture(dcId);

                        if (result == "" || result == null) {
                            osArchitectureKnown = false;
                            Properties resprop = WindowsUtil.getOSArchitecture(details, finalName, param, "Select * from Win32_OperatingSystem");// No I18N

                            if (resprop != null) {
                                result = resprop.get("OSArchitecture").toString();
                                osArchitectureKnown = true;
                                BMRDatabase.updateOSArchitecture(dcId, result);
                            } else {
                                osArchitectureKnown = false;
                            }
                        } else {
                            osArchitectureKnown = true;
                        }

                        if (osArchitectureKnown) {
                            if (result.contains("64")) {
                                agentName = "BMR64";// No I18N
                                latestGUID = latestAgent64;
                            } else if (result.contains("32")) {
                                agentName = "BMR32";// No I18N
                                latestGUID = latestAgent32;
                            }
                            if (!InstallAgent.getAgentStatus(details, finalName, agentName)) {
                                int res = WindowsHandler.executeCommand(finalName, name, "*", "C:\\Program Files\\ManageEngine\\RMP\\DeleteService.bat", true);//No I18N
                                LogWriter.bmr.info("DeleteService failed :" + res);//NO I18N
                                if (BMRDatabase.agentInstallCall(dcName, dcId, finalName, domain, agentName, details)) {
                                    updateInstalledGUID(dcId, domainId, latestGUID);
                                }
                            } else {
                                LogWriter.bmr.info("Agent already installed");//NO I18N
                                BMRDatabase.updateStatus(domain, dcName, dcId, "Backup configured", "");
                                updateInstalledGUID(dcId, domainId, latestGUID);
                            }
                        } else {
                            LogWriter.bmr.info("Error : OS Architecture unknown");//NO I18N
                            if (!InstallAgent.getAgentStatus(details, finalName, "BMR64")) {
                                int res = WindowsHandler.executeCommand(finalName, name, "*", "C:\\Program Files\\ManageEngine\\RMP\\DeleteService.bat", true);//No I18N
                                LogWriter.bmr.info("DeleteService failed :" + res);//NO I18N
                                if (BMRDatabase.agentInstallCall(dcName, dcId, finalName, domain, "BMR64", details)) {
                                    updateInstalledGUID(dcId, domainId, latestAgent64);
                                }
                            } else {
                                LogWriter.bmr.info("Agent already installed");//NO I18N
                                BMRDatabase.updateStatus(domain, dcName, dcId, "Backup configured", "");
                                updateInstalledGUID(dcId, domainId, latestGUID);
                            }
                        }
                    } catch (ADSADException ex) {
                        LogWriter.bmr.info("ADSADException: " + ex.getExceptionMsg());//NO I18N
                        if (ex.getExceptionMsg().contains("Access is denied.")) {
                            LogWriter.bmr.info("Server credentials has been changed");//NO I18N
                            BMRDatabase.updateStatus(domain, dcName, dcId, "Access denied", "");
                        } else {
                            if (!InstallAgent.getAgentStatus(details, finalName, "BMR64")) {
                                int res = WindowsHandler.executeCommand(finalName, name, "*", "C:\\Program Files\\ManageEngine\\RMP\\DeleteService.bat", true);//No I18N
                                LogWriter.bmr.info("DeleteService failed :" + res);//NO I18N
                                if (BMRDatabase.agentInstallCall(dcName, dcId, finalName, domain, "BMR64", details)) {
                                    updateInstalledGUID(dcId, domainId, latestAgent64);
                                }
                            } else {
                                LogWriter.bmr.info("Agent already installed");//NO I18N
                                BMRDatabase.updateStatus(domain, dcName, dcId, "Backup configured", "");
                                updateInstalledGUID(dcId, domainId, latestGUID);
                            }
                        }
                    } catch (Exception e) {
                        LogWriter.bmr.info("Error : Installation failed");//NO I18N
                        if (!InstallAgent.getAgentStatus(details, finalName, "BMR64")) {
                            int res = WindowsHandler.executeCommand(finalName, name, "*", "C:\\Program Files\\ManageEngine\\RMP\\DeleteService.bat", true);//No I18N
                            LogWriter.bmr.info("DeleteService failed :" + res);//NO I18N
                            if (BMRDatabase.agentInstallCall(dcName, dcId, finalName, domain, "BMR64", details)) {
                                updateInstalledGUID(dcId, domainId, latestAgent64);
                            }
                        } else {
                            LogWriter.bmr.info("Agent already installed");//NO I18N
                            BMRDatabase.updateStatus(domain, dcName, dcId, "Backup configured", "");
                            updateInstalledGUID(dcId, domainId, latestGUID);
                        }
                    }
                }
            }
            JSONObject status = new JSONObject();
            status.put("stopSpinner", true);
            status.put(configType, true);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public ActionForward updateAgent(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject status = new JSONObject();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            response.setContentType(RmpConstants.CONTENT_TYPE);
            String domain = (String) inputJSONObject.get("domain");
            String dcName = (String) inputJSONObject.get("dc");
            long dcId = Long.parseLong(inputJSONObject.get("dcId").toString());
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
            JSONObject prevstatus = BMRDatabase.isCompleted(dcName,dcId,"","",false,"","update");
            String backupResult = prevstatus.get("result").toString();
            String restoreResult = prevstatus.get("restoreResult").toString();
            if(backupResult.equalsIgnoreCase("Application Interrupted") || backupResult.equalsIgnoreCase("In Progress")) {
                BMRDatabase.updateInterruptedBackupStatus(dcName,dcId,domain);
                prevstatus = BMRDatabase.isCompleted(dcName,dcId,"","",false,"","update");
                backupResult = prevstatus.get("result").toString();
            }
            if(restoreResult.equals("Application Interrupted") || restoreResult.equals("In Progress")) {
                boolean ret = BMRDatabase.getInterruptedVLRdetails(dcName,dcId,domain);
                prevstatus = BMRDatabase.isCompleted(dcName,dcId,"","",false,"","update");
                backupResult = (String) prevstatus.get("result");
                restoreResult = (String) prevstatus.get("restoreResult");
            }
            if (!((backupResult.equals("Started")) || (backupResult.equals("In Progress (But failed to delete old backups)")) || (backupResult.equals("In Progress")) || (restoreResult.equals("In Progress")) || (restoreResult.equals("Started")))) {
                BMRDatabase.updateDCAgent(dcName, dcId, domainId);
                status.put("success", true);
            } else {
                status.put("success", false);
                LogWriter.bmr.severe("Agent busy due to another backup or restore in progress...try updating after it's completion.");//NO I18N
            }
            status.put("stopSpinner", true);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public ActionForward uninstallAgent(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            response.setContentType(RmpConstants.CONTENT_TYPE);
            String domain = (String) inputJSONObject.get("domain");
            String configType = (String) inputJSONObject.get("configType");
            String dcName = (String) inputJSONObject.get("dc");
            long dcId = Long.parseLong(inputJSONObject.get("dcId").toString());
            boolean uninstallResult = false, agentResult = true;
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
            String agentStatus = BMRDatabase.getAgentInstallationStatus(dcId, domainId);

            if (!agentStatus.equalsIgnoreCase("Upgrade Agent")) {
                Properties details = RMPDomainHandler.getDomainDetailsByName(domain);
                String[] param = {"OSArchitecture"};// No I18N
                String result, agentName = "BMR64";
                String finalName = "";
                boolean osArchitectureKnown = false;

                String dnsName = BMRDatabase.getFQDNFromFlatName(dcId);
                if (dnsName == null || dnsName.isEmpty()) {
                    dnsName = dcName;
                }

                boolean isPingable = BMRDatabase.isPingable(dcName);
                if (isPingable) {
                    finalName = dcName;
                } else {
                    isPingable = BMRDatabase.isPingable(dnsName);
                    if (isPingable) {
                        finalName = dnsName;
                    } else {
                        LogWriter.bmr.info("Ping failed.DC is inaccessible");//NO I18N
                    }
                }

                if (!finalName.isEmpty()) {
                    try {

                        result = BMRDatabase.getOSArchitecture(dcId);

                        if (result == "" || result == null) {
                            osArchitectureKnown = false;
                            Properties resprop = WindowsUtil.getOSArchitecture(details, finalName, param, "Select * from Win32_OperatingSystem");// No I18N

                            if (resprop != null) {
                                result = resprop.get("OSArchitecture").toString();
                                osArchitectureKnown = true;
                                BMRDatabase.updateOSArchitecture(dcId, result);
                            } else {
                                osArchitectureKnown = false;
                            }
                        } else {
                            osArchitectureKnown = true;
                        }

                        if (osArchitectureKnown) {
                            if (result.contains("64")) {
                                agentName = "BMR64";// No I18N
                            } else if (result.contains("32")) {
                                agentName = "BMR32";// No I18N
                            }
                            uninstallResult = BMRDatabase.agentUninstallCall(dcName, dcId, finalName, domain, agentName, details, true);

                        } else {
                            LogWriter.bmr.info("Error : OS Architecture unknown");//NO I18N
                            uninstallResult = BMRDatabase.agentUninstallCall(dcName, dcId, finalName, domain, "BMR64", details, true);
                        }
                    } catch (ADSADException ex) {
                        LogWriter.bmr.info("ADSADException: " + ex.getExceptionMsg());//NO I18N
                        uninstallResult = BMRDatabase.agentUninstallCall(dcName, dcId, finalName, domain, "BMR64", details, true);
                    } catch (Exception e) {
                        LogWriter.bmr.info("Error : Installation failed");//NO I18N
                        uninstallResult = BMRDatabase.agentUninstallCall(dcName, dcId, finalName, domain, "BMR64", details, true);
                    }
                } else {
                    LogWriter.bmr.info("Unable to access the DC.So deleting the schedules alone...");//NO I18N
                    uninstallResult = BMRDatabase.agentUninstallCall(dcName, dcId, finalName, domain, "BMR64", details, false);
                }
            } else {
                LogWriter.bmr.info("Upgrade agent and try unconfiguring the server");//NO I18N
                agentResult = false;
            }
            JSONObject status = new JSONObject();
            status.put("stopSpinner", true);
            status.put("uninstallResult", uninstallResult);
            status.put("agentResult", agentResult);
            status.put(configType, true);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public ActionForward getDomains(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            List domainList = RMPDomainHandler.getDomainNames();
            JSONArray list = new JSONArray();
            for (int i = 0; i < domainList.size(); i++) {
                list.put(domainList.get(i));
            }
            out.println(list.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward getConfiguredDomains(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            boolean value = (boolean) inputJSONObject.get("value");
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            List domainList;
            if (value) {
                domainList = BMRDatabase.getConfiguredDomains(null);
            } else {
                Criteria buCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_DETAILS, "IS_BACKUP_DONE"), true, QueryConstants.EQUAL);
                domainList = BMRDatabase.getConfiguredDomains(buCriteria);
            }
            JSONArray list = new JSONArray();
            for (int i = 0; i < domainList.size(); i++) {
                list.put(domainList.get(i));
            }
            out.println(list.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkRestoreStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            List domainList;
            boolean result = false;
            Criteria buCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_DETAILS, "IS_BACKUP_DONE"), true, QueryConstants.EQUAL);
            domainList = BMRDatabase.getConfiguredDomains(buCriteria);
            if (domainList.size() > 0) {
                result = true;
            }
            JSONObject status = new JSONObject();
            status.put("result", result);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward deleteUnconfiguredDCRows(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            String domain = (String) inputJSONObject.get("domain");
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
            BMRDatabase.deleteUnconfiguredDCRows(domain, domainId);
            out.println(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward runBMRNewDcSchedule(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            String domain = inputJSONObject.get("domain").toString();
            List domainList = new ArrayList<String>();
            domainList.add(domain);
            BMRDatabase.runBMRNewDcSchedule(domainList);
            out.println(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward configureDC(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            BMRDatabase.storeTotalBackupDetails(inputJSONObject);
            JSONArray dcArray = (JSONArray) inputJSONObject.getJSONArray("dc");//No I18N
            //JSONObject jsObject = (JSONObject) dcArray.get(0);
            for (int i = 0; i < dcArray.length(); i++) {
                JSONObject jsObject = (JSONObject) dcArray.get(i);
                String domain = (String) inputJSONObject.get("domain");
                String dcName = (String) (jsObject.get("dcName"));
                String backupType = (String) (jsObject.get("backupType"));
                long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
                long backupId = Long.parseLong(jsObject.get("dcId").toString());
                Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), backupId, QueryConstants.EQUAL);
                BMRDatabase.updateScheduleStatus(backupType, inputJSONObject, domainCriteria.and(dcCriteria));
                BMRDatabase.createSchedule(inputJSONObject, domainCriteria.and(dcCriteria));
            }
            out.println(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward storeDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            BMRDatabase.storeLocationDetails(inputJSONObject);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward updateDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            BMRDatabase.updateLocationDetails(inputJSONObject);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward updateCredentials(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            String domain = (String) inputJSONObject.get("domain");
            PrintWriter out = response.getWriter();
            JSONObject status = new JSONObject();
            String errormsg = BMRDatabase.updateCredentials(inputJSONObject);
            if (errormsg.equals("success")) {
                long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
                UpdateQuery query = new UpdateQueryImpl(TableName.BMR_BACKUP_SCHEDULE);
                query.setUpdateColumn("STATUS", "Installation failed"); //No I18N
                query.setUpdateColumn("ERROR_MSG", ""); //No I18N
                Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                Criteria statusCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "STATUS"), "Backup not configured", QueryConstants.NOT_EQUAL);
                query.setCriteria(domainCriteria.and(statusCriteria));
                CommonUtil.getPersistence().update(query);
                status.put("status", true);
            } else {
                status.put("status", false);
                int errorCode = DomainSettingsAction.getErrorCode(errormsg, "credentialUpdate");   //No I18N
                status.put("errorcode", errorCode);
            }
            status.put("stopSpinner", true);
            status.put("credentialsUpdated", true);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward bmrDomainUpdateCredentials(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            String domain = (String) inputJSONObject.get("domain");
            PrintWriter out = response.getWriter();
            JSONObject status = new JSONObject();
            String errormsg = BMRDatabase.updateCredentials(inputJSONObject);
            if (errormsg.equals("success")) {
                LogWriter.bmr.info("Credentials updated successfully for domain: " + domain);
                status.put("status", true);
            } else {
                status.put("status", false);
                int errorCode = DomainSettingsAction.getErrorCode(errormsg, "credentialUpdate");   //No I18N
                LogWriter.bmr.info("Credentials updation failed for domain: " + domain + " -->" + errormsg);
                status.put("errorcode", errorCode);
            }
            status.put("stopSpinner", true);
            status.put("credentialsUpdated", true);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            String domainName = (String) inputJSONObject.get("domain");
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domainName).getProperty("DOMAIN_ID"));
            boolean locationResult = RMPCommonUtil.isTableEmpty(TableName.BMR_BACKUP_STORAGE, null, new String[]{"UNIQUE_ID"});
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria statusCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "STATUS"), "Backup not configured", QueryConstants.NOT_EQUAL);

            boolean scheduleResult = RMPCommonUtil.isTableEmpty(TableName.BMR_BACKUP_SCHEDULE, criteria.and(statusCriteria), new String[]{"DC_ID"});
            JSONObject status = new JSONObject();
            status.put("locationResult", locationResult);
            status.put("scheduleResult", scheduleResult);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkConfigurationStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            boolean result = RMPCommonUtil.isTableEmpty(TableName.BMR_TOTAL_BACKUP_DETAILS, null, new String[]{"DC_ID"});
            JSONObject status = new JSONObject();
            status.put("result", result);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward getDLLDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            boolean result = BMRDatabase.getDLLDetails();
            JSONObject status = new JSONObject();
            status.put("result", result);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkRepositoryStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            String dcName = (String) inputJSONObject.get("dc");
            long dcId = Long.parseLong(inputJSONObject.get("dcId").toString());
            PrintWriter out = response.getWriter();
            JSONObject status = BMRDatabase.isRepoEnabled(dcId);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkRestoreRepositoryStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            Integer value = (Integer) inputJSONObject.get("id");
            Long opId = value.longValue();
            LogWriter.bmr.info("checkRepositoryStatus opId: " + opId);
            PrintWriter out = response.getWriter();
            JSONObject status = BMRDatabase.isRestoreRepoEnabled(opId);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkCompletionStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            String dcName = (String) inputJSONObject.get("dc");
            String module = (String) inputJSONObject.get("module");
            String type = "";
            String initiator = "";
            String currentEncryptionPwd = "";
            boolean currentEncryptionStatus = false;
            long backupId = Long.parseLong(inputJSONObject.get("dcId").toString());
            if (module.equals("backup")) {
                type = (String) inputJSONObject.get("type");
                initiator = (String) inputJSONObject.get("initiator");
                Properties currentEncryptionDetails = BMRDatabase.currentEncryptionDetails(backupId);
                currentEncryptionStatus = Boolean.parseBoolean((String) currentEncryptionDetails.getProperty("IS_ENCRYPTED"));
                currentEncryptionPwd = (String) currentEncryptionDetails.getProperty("SECRETKEY");
            }
            PrintWriter out = response.getWriter();
            JSONObject result = BMRDatabase.isCompleted(dcName, backupId, type, initiator, currentEncryptionStatus, currentEncryptionPwd, module);
            out.println(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkForCredentials(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {

        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            String domainName = (String) inputJSONObject.get("domainName");
            JSONObject status = new JSONObject();

            PrintWriter out = response.getWriter();
            Properties prop = RMPDomainHandler.getDomainDetailsByName(domainName);
            long domainId = Long.valueOf(prop.getProperty("DOMAIN_ID"));
            String authenticationRequired = prop.getProperty("IS_AUTHENTICATION_REQUIRED");

            if (authenticationRequired != null && authenticationRequired.equalsIgnoreCase("false")) {
                status.put("result", "notAuthenticated");
            } else {
                status.put("result", "authenticated");
            }

            out.println(status);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward
            getIPAddressFromDeviceName(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        JSONObject result = new JSONObject();
        PrintWriter out = null;

        String deviceName = null;

        try {

            out = response.getWriter();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            deviceName = (String) inputJSONObject.get("deviceName");
            response.setContentType(RmpConstants.CONTENT_TYPE);
            InetAddress address1;
            String ipAddress = null;

            address1 = InetAddress.getByName(deviceName);

            ipAddress = address1.getHostAddress();

            if (ipAddress != null) {
                result.put("ip", ipAddress);
            } else {
                result.put("ip", deviceName);
            }

            out.println(result);
        } catch (Exception ex) {
            ex.printStackTrace();
            try {
                result.put("ip", deviceName);
                out.println(result);
            } catch (Exception ex1) {
                ex.printStackTrace();
            }
        }

        return null;
    }

    public ActionForward getStoredFiles(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            JSONArray returnArr = new JSONArray();
            String ip = (String) inputJSONObject.get("ipAddress");
            String machineName = (String) inputJSONObject.get("machineName");
            String backupType = (String) inputJSONObject.get("type");
            PrintWriter out = response.getWriter();
            response.setContentType(RmpConstants.CONTENT_TYPE);
            long dcId = Long.parseLong(inputJSONObject.get("machineId").toString());
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            Criteria backupTypeCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "BACKUP_TYPE"), backupType, QueryConstants.EQUAL);
            returnArr = BMRDatabase.getStoredFiles(criteria.and(backupTypeCriteria), ip);
            out.println(returnArr.toString());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public ActionForward storeSelectedFiles(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            response.setContentType(RmpConstants.CONTENT_TYPE);
            boolean isSuccess = BMRDatabase.storeSelectedFiles(inputJSONObject);
            JSONObject status = new JSONObject();
            status.put("result", isSuccess);
            out.println(status);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public ActionForward getLocalVolumes(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse resp) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            resp.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = resp.getWriter();
            JSONArray list = (JSONArray) inputJSONObject.get("drivesList");
            JSONObject status = new JSONObject();
            JSONArray filesObtainedList = new JSONArray();

            for (int loop = 0; loop < list.length(); loop++) {
                String eachDrive = ((JSONObject) list.get(loop)).get("value").toString();
                JSONObject fileObtained = new JSONObject();
                fileObtained.put("folderId", loop + 1);
                fileObtained.put("folderPath", eachDrive + "\\");
                fileObtained.put("folderName", eachDrive);
                fileObtained.put("folderUncPath", eachDrive + "\\");
                fileObtained.put("folderDir", true);
                filesObtainedList.put(fileObtained);
            }

            status.put("filesInFolder", filesObtainedList);
            status.put("accessDenied", false);
            status.put("isSuccess", true);
            out.println(status.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public ActionForward getMountedPointDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, final HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            JSONObject retObj = FLRDatabase.getMountedPointDetails();
            out.println(retObj);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public ActionForward getDomainOfMountedPoint(ActionMapping mapping, ActionForm form, HttpServletRequest request, final HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            JSONObject retObj = FLRDatabase.getMountedPointDetails();
            out.println(retObj);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public ActionForward getLocalDirectoryFolders(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse resp) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            resp.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = resp.getWriter();
            String urlToSearch = URLDecoder.decode(inputJSONObject.get("urlToSearch").toString(), "UTF-8");
            Boolean needFile = (Boolean) inputJSONObject.get("needFile");
            String displayURL = URLDecoder.decode(inputJSONObject.get("displayURL").toString(), "UTF-8");
            JSONObject argsList = new JSONObject(URLDecoder.decode(inputJSONObject.get("argsList").toString(), "UTF-8"));
            JSONArray list = (JSONArray) inputJSONObject.get("drivesList");
            BMRThreadManager manager = BMRThreadManager.getBMRThreadManager();
            Integer opId = argsList.getInt("restoreOpId");
            JSONObject status = new JSONObject();

            if (!FLRDatabase.checkMountStatus(opId)) {
                status.put("closeBrowser", true);
                out.println(status.toString());
                return null;
            }

            for (int retry = 0; retry < 3; retry++) {
                status = FileBrowserHandler.getLocalFolders(urlToSearch, needFile, list);
                if (!status.getBoolean("accessDenied")) {
                    break;
                } else {
                    LogWriter.bmr.severe("FileBrowserHandler : getLocalFolders failed with at retry : " + retry);
                }
            }

            boolean accessDenied, isSuccess, isBMRBackup;
            accessDenied = status.getBoolean("accessDenied");
            isSuccess = status.getBoolean("isSuccess");

            boolean toCompare = false;

            /*
             * 1. If it has process merge, either (merge (for an IB) would have happened) or (selected restore point is FB and merge is not done).
             * 2. If it the second case, we would have set its status to BMRThreadManager.FAILED.
             * */
            Map<String, String> retMap = null;
            JSONArray filesArr = new JSONArray();

            if (manager.hasProcess("merge")) {
                if (manager.getStatus("merge") == BMRThreadManager.SUCCESS) {
                    retMap = (Map) manager.getRetVal("merge");
                    String origBackupType = retMap.get("origBackupType");
                    if (!origBackupType.equalsIgnoreCase("FLR")) {
                        toCompare = true;
                    }
                }
            }

            if (!accessDenied && isSuccess) {
                filesArr = status.getJSONArray("filesInFolder");
            }

            if (!accessDenied && !urlToSearch.isEmpty() && manager.hasProcess("merge") & toCompare) {
                String mergeFolder = retMap.get("mergeFolder");
                String username = retMap.get("REPOSITORY_USERNAME");
                String password = retMap.get("REPOSITORY_PASSWORD");

                Properties conProps = RMPNativeManager.checkCredentials(mergeFolder, username, password, "connect");//No I18N

                if (conProps.get("Success") != null) {
                    File mergeFile = new File(mergeFolder);

                    File[] subFolders = mergeFile.listFiles(new FileFilter() {
                        @Override
                        public boolean accept(File file) {
                            return file.isDirectory();
                        }
                    });

                    if (subFolders[0].getName().startsWith("Harddisk")) {
                        isBMRBackup = true;
                    } else {
                        isBMRBackup = false;
                    }

                    // Renaming & Deleting Logic
                    for (int i = 0; i < filesArr.length(); i++) {
                        JSONObject obj = (JSONObject) filesArr.get(i);
                        String fName = obj.getString("folderName");
                        if (displayURL.endsWith(File.separator)) {
                            obj.put("folderUncPath", displayURL + fName);
                        } else {
                            obj.put("folderUncPath", displayURL + File.separator + fName);
                        }
                    }

                    if (!urlToSearch.startsWith(mergeFolder) && filesArr.length() > 0) {
                        JSONObject sampleObj = (JSONObject) filesArr.get(0);
                        String tempUncPath = sampleObj.getString("folderUncPath");
                        String rDriveLetter = Character.toString(tempUncPath.charAt(tempUncPath.indexOf(":") - 1));
                        String rDrivePath = "";

                        if (isBMRBackup) {
                            for (File file : mergeFile.listFiles()) {
                                String eachPath = file.getAbsolutePath();
                                String partitionPath = eachPath + "\\" + "Partition" + rDriveLetter;

                                if (new File(partitionPath).exists()) {
                                    rDrivePath = partitionPath;
                                    break;
                                }
                            }
                        } else {
                            rDrivePath = mergeFolder + File.separator + "Partition" + rDriveLetter;
                        }

                        File partitionFile = new File(rDrivePath);

                        if (partitionFile.exists()) {
                            Map<String, String> renameEntriesSorted = null;
                            Map<String, String> deleteEntries;
                            Map<String, Map> renameMap = manager.renameEntries;
                            Map<String, Map> renameManagerMap = manager.renameEntriesSorted;
                            Map<String, Map> delManagerMap = manager.deleteEntries;

                            if (delManagerMap == null || renameManagerMap == null || renameMap == null) {
                                String partitionFullPath = partitionFile.getAbsolutePath();
                                String delFilePath = partitionFullPath + File.separator + "delete_file.txt";
                                String renameFilePath = partitionFullPath + File.separator + "rename_file.txt";
                                deleteEntries = getChangedEntries(delFilePath, true);
                                Map<String, String> renameEntries = getChangedEntries(renameFilePath, false);
                                renameEntriesSorted = getSortedEntries(renameEntries);
                                renameMap = new LinkedHashMap<>();
                                renameManagerMap = new LinkedHashMap<>();
                                delManagerMap = new LinkedHashMap<>();
                                renameMap.put(rDriveLetter + ":", renameEntries);
                                renameManagerMap.put(rDriveLetter + ":", renameEntriesSorted);
                                delManagerMap.put(rDriveLetter + ":", deleteEntries);
                                manager.renameEntries = renameMap;
                                manager.renameEntriesSorted = renameManagerMap;
                                manager.deleteEntries = delManagerMap;
                            } else {
                                if (delManagerMap.containsKey(rDriveLetter + ":") && renameManagerMap.containsKey(rDriveLetter + ":")) {
                                    renameEntriesSorted = renameManagerMap.get(rDriveLetter + ":");
                                    deleteEntries = delManagerMap.get(rDriveLetter + ":");
                                } else {
                                    String partitionFullPath = partitionFile.getAbsolutePath();
                                    String delFilePath = partitionFullPath + File.separator + "delete_file.txt";
                                    String renameFilePath = partitionFullPath + File.separator + "rename_file.txt";
                                    deleteEntries = getChangedEntries(delFilePath, true);
                                    Map<String, String> renameEntries = getChangedEntries(renameFilePath, false);
                                    renameEntriesSorted = getSortedEntries(renameEntries);
                                    renameMap.put(rDriveLetter + ":", renameEntries);
                                    renameManagerMap.put(rDriveLetter + ":", renameEntriesSorted);
                                    delManagerMap.put(rDriveLetter + ":", deleteEntries);
                                }
                            }

                            for (int i = 0; i < filesArr.length(); i++) {
                                JSONObject obj = (JSONObject) filesArr.get(i);
                                String fUncPath = obj.getString("folderUncPath");
                                String uncPathToSearch = fUncPath.substring(3);
                                String newFUncPath = "";
                                while (renameEntriesSorted.containsKey(uncPathToSearch)) {
                                    newFUncPath = fUncPath.substring(0, 2) + "\\" + renameEntriesSorted.get(uncPathToSearch);
                                    String newFName = newFUncPath.substring(newFUncPath.lastIndexOf("\\") + 1);
                                    obj.put("folderName", newFName);
                                    obj.put("folderUncPath", newFUncPath);
                                    obj.put("renamed", true);
                                    uncPathToSearch = newFUncPath.substring(3);
                                }
                            }

                            JSONArray newFilesArr = new JSONArray(filesArr.toString());
                            filesArr = new JSONArray();
                            int folderId = 0;

                            for (int i = 0; i < newFilesArr.length(); i++) {
                                JSONObject obj = (JSONObject) newFilesArr.get(i);
                                String fUncPath = obj.getString("folderUncPath");
                                String pathToSearch = fUncPath.substring(3);
                                if (!deleteEntries.containsKey(pathToSearch)) {
                                    obj.put("folderId", ++folderId);
                                    filesArr.put(obj);
                                }
                            }
                        }
                    }

                    if (!urlToSearch.startsWith(mergeFolder)) {
                        // JSONObject firstObj = (JSONObject) filesArr.get(0);
                        // String tempPath = firstObj.getString("folderUncPath");
                        String driveLetter = Character.toString(displayURL.charAt(displayURL.indexOf(":") - 1));
                        String urlDrive = Character.toString(urlToSearch.charAt(urlToSearch.indexOf(":") - 1));
                        String folderPath = urlToSearch.replaceFirst(urlDrive + ":", "Partition" + driveLetter);

                        String drivePath = mergeFolder + "\\" + folderPath;
                        String pathToReplace = mergeFolder + "\\";

                        if (isBMRBackup) {
                            for (File file : mergeFile.listFiles()) {
                                String eachPath = file.getAbsolutePath();
                                String partitionPath = eachPath + "\\" + folderPath;

                                if (new File(partitionPath).exists()) {
                                    pathToReplace = eachPath + "\\";
                                    drivePath = partitionPath;
                                    break;
                                }
                            }
                        }

                        File driveFile = new File(drivePath);

                        if (driveFile.exists() && driveFile.isDirectory()) {
                            int newFolderId = filesArr.length();
                            for (File file : driveFile.listFiles()) {
                                String retFilePath = file.getAbsolutePath();
                                String filePath = file.getAbsolutePath();
                                filePath = filePath.replaceAll(Pattern.quote(pathToReplace), "");
                                String drive = Character.toString(filePath.charAt(9));
                                filePath = filePath.replaceFirst("Partition" + drive, drive + ":");
                                boolean isFound = false;

                                for (int i = 0; i < filesArr.length(); i++) {
                                    JSONObject obj = (JSONObject) filesArr.get(i);
                                    String folderUncPath = obj.getString("folderUncPath");
                                    if (filePath.equalsIgnoreCase(folderUncPath)) {
                                        // Insert "merge" key
                                        obj.put("mergePath", retFilePath);
                                        obj.put("merge", true);
                                        isFound = true;
                                        break;
                                    }
                                }
                                if (!isFound) {
                                    // Insert JSON object
                                    JSONObject fileObtained = new JSONObject();
                                    fileObtained.put("folderId", ++newFolderId);
                                    fileObtained.put("folderPath", retFilePath);
                                    fileObtained.put("folderName", file.getName());
                                    retFilePath = retFilePath.replaceFirst(Pattern.quote(pathToReplace), "");
                                    String retDrive = Character.toString(retFilePath.charAt(9));
                                    retFilePath = retFilePath.replaceFirst("Partition" + retDrive, retDrive + ":");
                                    fileObtained.put("folderUncPath", retFilePath);
                                    fileObtained.put("folderDir", file.isDirectory());
                                    filesArr.put(fileObtained);
                                }
                            }
                        }
                    }
                }

                RMPNativeManager.checkCredentials(mergeFolder, username, password, "disconnect");//No I18N
            }

            if (!accessDenied && !urlToSearch.isEmpty() && manager.hasProcess("merge") && urlToSearch.endsWith(File.separator)) {
                JSONArray newFilesArr = new JSONArray(filesArr.toString());
                filesArr = new JSONArray();
                int newFId = 0;
                for (int i = 0; i < newFilesArr.length(); i++) {
                    JSONObject obj = (JSONObject) newFilesArr.get(i);
                    String folderName = obj.getString("folderName");
                    boolean isDirectory = obj.getBoolean("folderDir");
                    if (urlToSearch.endsWith(File.separator)) {
                        if (!((folderName.equalsIgnoreCase("rename_file.txt") || folderName.equalsIgnoreCase("delete_file.txt")) && !isDirectory)) {
                            obj.put("folderId", ++newFId);
                            filesArr.put(obj);
                        }
                    }
                }
            }

            if (filesArr.length() > 0) {
                status.put("isSuccess", true);
            } else {
                status.put("isSuccess", false);
            }

            status.put("filesInFolder", filesArr);

            out.println(status.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static Map<String, String> getSortedEntries(Map<String, String> entryMap) {
        Map<String, String> retMap = new LinkedHashMap<>();
        Map<String, String> tempMap = new LinkedHashMap<>(); // assigned with retMap.

        try {
            for (Map.Entry<String, String> pEntry : entryMap.entrySet()) {
                for (Map.Entry<String, String> cEntry : retMap.entrySet()) {
                    String retPath = cEntry.getKey();
                    String oldPath = pEntry.getKey();
                    if (retPath.startsWith(oldPath + File.separator)) {
                        String valueForKey = cEntry.getValue();
                        tempMap.remove(retPath);
                        Pattern pattern = Pattern.compile(Pattern.quote(oldPath));
                        Matcher matcher = pattern.matcher(valueForKey);
                        valueForKey = matcher.replaceFirst(matcher.quoteReplacement(pEntry.getValue()));
                        matcher = pattern.matcher(retPath);
                        retPath = matcher.replaceFirst(matcher.quoteReplacement(pEntry.getValue()));
                        tempMap.put(retPath, valueForKey);
                    }
                }
                tempMap.put(pEntry.getKey(), pEntry.getValue());
                retMap.putAll(tempMap);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return retMap;
    }

    public static Map<String, String> getChangedEntries(String fullPath, boolean isDelFile) {
        Map<String, String> retMap = new LinkedHashMap<>();
        BufferedReader bufRead = null;

        try {
            File srcFile = new File(fullPath);
            if (srcFile.exists()) {
                bufRead = new BufferedReader(new InputStreamReader(new FileInputStream(srcFile)));
                String line = null;
                while ((line = bufRead.readLine()) != null) {
                    if (isDelFile) {
                        retMap.put(line, "");
                    } else {
                        String[] names = line.split("--");
                        if (names.length >= 2) {
                            retMap.put(names[0], names[1]);
                        }
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (bufRead != null) {
                    bufRead.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        return retMap;
    }

    public static JSONArray removeJsonObjectByIndex(int pos, JSONArray inputArr) {
        JSONArray list = new JSONArray();
        try {
            int len = inputArr.length();
            for (int i = 0; i < len; i++) {
                if (i != pos) {
                    list.put(inputArr.get(i));
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }

    public static JSONArray addJSONObjectByIndex(int pos, JSONObject jsonObj, JSONArray jsonArr) {
        try {
            for (int i = jsonArr.length(); i > pos; i--) {
                jsonArr.put(i, jsonArr.get(i - 1));
            }
            jsonArr.put(pos, jsonObj);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return jsonArr;
    }

    public ActionForward getDirectoryFolders(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse resp) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            resp.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = resp.getWriter();

            String domainName = URLDecoder.decode(inputJSONObject.get("adminUserName").toString(), "UTF-8");
            Properties prop = RMPDomainHandler.getDomainDetailsByName(domainName);

            String domainFlatName = (String) prop.getProperty("USER_DOMAIN_NAME");
            String adminUserName = (String) prop.getProperty("USER_NAME");
            String username = domainFlatName + "\\" + adminUserName;//No I18N
            String adminPassword = (String) prop.getProperty("PASSWORD");

            String deviceName = URLDecoder.decode(inputJSONObject.get("deviceName").toString(), "UTF-8");
            String urlToSearch = URLDecoder.decode(inputJSONObject.get("urlToSearch").toString(), "UTF-8");

            Boolean needFile = (Boolean) inputJSONObject.get("needFile");
            JSONObject status = FileBrowserHandler.getFolders(deviceName, urlToSearch, needFile, username, adminPassword);

            if (!status.getBoolean("accessDenied")) {
                if (status.getBoolean("isSuccess")) {
                    boolean isRootLevel = urlToSearch.isEmpty();
                    JSONArray filesArr = (JSONArray) status.get("filesInFolder");
                    JSONArray newJson = new JSONArray();

                    if (isRootLevel) {
                        for (int i = 0; i < filesArr.length(); i++) {
                            JSONObject eachObj = filesArr.getJSONObject(i);
                            String folderName = eachObj.getString("folderName");
                            if (folderName.length() == 3 && folderName.endsWith("$/")) {
                                newJson.put(eachObj);
                            }
                        }
                        status.put("filesInFolder", newJson);
                    }
                }
            }

            out.println(status.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public ActionForward checkDomainStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            boolean isSuccessful = false;
            String domain = (String) inputJSONObject.get("domain");
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
            PrintWriter out = response.getWriter();
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_DETAILS, "DOMAIN_NAME"), domain, QueryConstants.EQUAL);
            Criteria buCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_DETAILS, "IS_BACKUP_DONE"), true, QueryConstants.EQUAL);
            boolean result = RMPCommonUtil.isTableEmpty(TableName.BMR_DOMAIN_DETAILS, domainCriteria.and(buCriteria), new String[]{"UNIQUE_ID"});
            if (!result) {
                Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                Criteria sizeCriteria = new Criteria(Column.getColumn(TableName.BMR_TOTAL_BACKUP_DETAILS, "SIZE"), 0f, QueryConstants.GREATER_THAN);
                isSuccessful = RMPCommonUtil.isTableEmpty(TableName.BMR_TOTAL_BACKUP_DETAILS, criteria.and(sizeCriteria), new String[]{"DC_ID"});
            }
            JSONObject status = new JSONObject();
            status.put("result", result);
            status.put("successResult", isSuccessful);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkCredentials(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            String retVal = (String) inputJSONObject.get("retVal");
            PrintWriter out = response.getWriter();
            String result = BMRDatabase.checkCredentials(inputJSONObject);
            JSONObject status = new JSONObject();
            status.put("result", result);
            status.put("stopSpinner", true);
            status.put(retVal, true);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward saveSchedule(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            BMRDatabase.storeSchedule(inputJSONObject);
            out.println(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward pauseOrResumeSchedule(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        JSONObject returnValue = new JSONObject();
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            response.setContentType(RmpConstants.CONTENT_TYPE);
            returnValue.put("success", BMRDatabase.pauseOrResumeSchedule(inputJSONObject));
            response.getWriter().print(returnValue.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward updateRepositoryUsedSpace(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(URLDecoder.decode(request.getParameter("req"), "UTF-8"));
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            Long repoId = Long.parseLong(inputJSONObject.get("repId").toString());//No I18N
            JSONObject retValue = BMRDatabase.updateRepositoryUsedSpace(repoId);
            out.println(retValue.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward getActiveBMRBackupCount(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse resp) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            String domain = (String) inputJSONObject.get("domain");
            resp.setContentType(RmpConstants.CONTENT_TYPE);
            JSONObject backupCount = BMRDatabase.getActiveBMRBackupCount(domain);
            resp.getWriter().print(backupCount.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward disableSchedulesInFreeEdition(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            BMRDatabase.disableSchedulesInFreeEdition(inputJSONObject);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward updateSchedule(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            BMRDatabase.updateSchedule(inputJSONObject);
            out.println(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward getSchedule(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            Criteria criteria;
            int rangeStart = Integer.parseInt(inputJSONObject.get("rangeStart").toString());
            int limit = Integer.parseInt((String) inputJSONObject.get("limit").toString());
            String domain = (String) inputJSONObject.get("domain");
            long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domain).getProperty("DOMAIN_ID"));
            boolean value = (boolean) inputJSONObject.get("value");
            if (value) {
                Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                Criteria statusCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "STATUS"), "Backup not configured", QueryConstants.NOT_EQUAL);
                criteria = domainCriteria.and(statusCriteria);
            } else {
                String dcName = (String) inputJSONObject.get("dc");
                long dcId = Long.parseLong(inputJSONObject.get("dcId").toString());
                Criteria domainCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
                criteria = domainCriteria.and(dcCriteria);
            }

            JSONObject retVal = BMRDatabase.getSchedule(criteria, rangeStart, limit);
            out.println(retVal.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward getLocationDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            Properties details = BMRDatabase.getLocationDetail(48);
            JSONObject result = new JSONObject();
            result.put("location", details.get("Location").toString());
            result.put("user", details.get("User").toString());
            result.put("pwd", details.get("Password").toString());
            out.println(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward getRestorePoints(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            Criteria criteria;
            Criteria restoreTypeCriteria = null;
            Criteria restTypeCriteria = null;
            String dcName = (String) inputJSONObject.get("dc");
            String restoreType = (String) inputJSONObject.get("restoreType");
            long backupId = Long.parseLong(inputJSONObject.get("dcId").toString());

            Criteria backupFilterCriteria = null;
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "BACKUP_FILTER_TIME"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "IS_LICENSED"));
            selectQuery.setCriteria(new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"), backupId, QueryConstants.EQUAL));
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if (!dataObject.isEmpty()) {
                Row row = dataObject.getFirstRow(TableName.BMR_DOMAIN_CONTROLLERS);
                Timestamp backupFilterTime = (Timestamp) row.get("BACKUP_FILTER_TIME");
                int licenseType = (int) row.get("IS_LICENSED");
                if (licenseType == LicenseType.Unlicensed.ordinal()) {
                    out.println(new JSONArray());
                    return null;
                }
                if (licenseType == LicenseType.Licensed.ordinal() && backupFilterTime != null) {
                    backupFilterCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME"), backupFilterTime, QueryConstants.GREATER_THAN);
                }
            }

            Criteria statusCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "STATUS"), "Completed", QueryConstants.EQUAL);
            Criteria idCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), backupId, QueryConstants.EQUAL);

            if (restoreType.contains("Bare Metal")) {
                restoreTypeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "BACKUP_MODE"), "BMR", QueryConstants.EQUAL);
                restTypeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "BACKUP_MODE"), "OLD BMR", QueryConstants.EQUAL);
                criteria = statusCriteria.and(idCriteria.and(restoreTypeCriteria.or(restTypeCriteria)));
            } else if (restoreType.contains("Volume Level")) {
                restoreTypeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "BACKUP_MODE"), "FLR", QueryConstants.NOT_EQUAL);
                restTypeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "BACKUP_MODE"), "OLD BMR", QueryConstants.NOT_EQUAL);
                criteria = statusCriteria.and(idCriteria.and(restoreTypeCriteria.and(restTypeCriteria)));
            } else {
                restoreTypeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "BACKUP_MODE"), "OLD BMR", QueryConstants.NOT_EQUAL);
                criteria = statusCriteria.and(idCriteria.and(restoreTypeCriteria));
            }

            JSONArray array = BMRDatabase.getRestorePoints((backupFilterCriteria == null) ? criteria : criteria.and(backupFilterCriteria));
            out.println(array.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward plotDCsChart(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            JSONArray array = BMRDatabase.getDCChartDetails(inputJSONObject);
            out.println(array.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward plotFailedBackupChart(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            JSONArray array = BMRDatabase.getFailedBackupChartDetails(inputJSONObject);
            out.println(array.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward plotDomainsChart(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            JSONArray array = BMRDatabase.getDomainChartDetails(inputJSONObject);
            out.println(array.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward createIso(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            int value = 1;
            String path = (String) inputJSONObject.get("path");
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.RMP_SYSTEM_PARAMS));
            query.addSelectColumn(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "*"));
            Criteria crit = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_BMRDLL_AVAILABLE", QueryConstants.EQUAL);
            query.setCriteria(crit);
            DataObject dataobj = CommonUtil.getPersistence().get(query);
            SelectQueryImpl query1 = new SelectQueryImpl(Table.getTable(TableName.RMP_SYSTEM_PARAMS));
            query1.addSelectColumn(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "*"));
            Criteria crit1 = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_BMRDLL_AVAILABLE", QueryConstants.EQUAL);
            Criteria crit2 = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_VALUE"), false, QueryConstants.EQUAL);
            query1.setCriteria(crit1.and(crit2));
            DataObject dataobj1 = CommonUtil.getPersistence().get(query1);
            if (dataobj.isEmpty() || (!dataobj1.isEmpty())) {
                BMRIso.loadIsoLibrary();
            }
            boolean dllValue = BMRDatabase.getDLLDetails();

            if (dllValue) {
                value = BMRDatabase.createIso(path);
            }

            if (value == 0) {
                BMRDatabase.setNewIsoStatus(true);
            }

            JSONObject status = new JSONObject();
            status.put("dllValue", dllValue);
            status.put("result", value);
            status.put("stopSpinner", true);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward getNewIsoStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            String isNewIsoCreated = BMRDatabase.isNewIsoStatus();

            JSONObject status = new JSONObject();
            status.put("result", isNewIsoCreated);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkForFolders(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();

            String startPath = System.getProperty("server.dir") + File.separator + "bin" + File.separator;// No I18N

            String isoFolder = startPath + "iso";    // No I18N
            String efiFolder = isoFolder + File.separator + "EFI";    // No I18N
            String bcdPath = isoFolder + File.separator + "BOOT" + File.separator + "BCD";    // No I18N
            String bootSdiPath = isoFolder + File.separator + "BOOT" + File.separator + "BOOT.SDI";    // No I18N
            String bootFixPath = isoFolder + File.separator + "BOOT" + File.separator + "BOOTFIX.BIN";    // No I18N
            String etfsBootPath = isoFolder + File.separator + "BOOT" + File.separator + "etfsboot.com";    // No I18N
            String sourcesFolder = isoFolder + File.separator + "sources";    // No I18N
            String bootWimPath = sourcesFolder + File.separator + "boot.wim";    // No I18N
            String bootMgrPath = isoFolder + File.separator + "BOOTMGR";    // No I18N
            String bootMgrEfiPath = isoFolder + File.separator + "BOOTMGR.EFI";    // No I18N
            String bootX64EfiPath = efiFolder + File.separator + "BOOT" + File.separator + "BOOTX64.EFI";
            String mBcdPath = efiFolder + File.separator + "Microsoft" + File.separator + "Boot" + File.separator + "BCD";
            String efiSysPath = efiFolder + File.separator + "Microsoft" + File.separator + "Boot" + File.separator + "efisys.bin";

            File bcdFile = new File(bcdPath);
            File bootSdiFile = new File(bootSdiPath);
            File bootFixFile = new File(bootFixPath);
            File etfsBootFile = new File(etfsBootPath);
            File bootWimFile = new File(bootWimPath);
            File bootMgrFile = new File(bootMgrPath);
            File bootMgrEfiFile = new File(bootMgrEfiPath);
            File bootX64EfiFile = new File(bootX64EfiPath);
            File mBcdFile = new File(mBcdPath);
            File efiSysFile = new File(efiSysPath);

            boolean isExists = false;

            if (bcdFile.exists() && bootSdiFile.exists() && bootFixFile.exists()
                    && etfsBootFile.exists() && bootWimFile.exists() && bootMgrFile.exists()
                    && bootMgrEfiFile.exists() && bootX64EfiFile.exists() && mBcdFile.exists()
                    && efiSysFile.exists()) {
                isExists = true;
            } else {
                isExists = false;
                FileUtils.deleteDirectory(new File(isoFolder));
            }

            JSONObject status = new JSONObject();
            status.put("isExists", isExists);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward plotBackupsChart(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            Criteria sizeCriteria = null, idCriteria = null;
            boolean getByName = (boolean) inputJSONObject.get("getByName");
            if (getByName) {
                long backupId = Long.parseLong(inputJSONObject.get("dcId").toString());
                sizeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "SIZE"), 0f, QueryConstants.GREATER_THAN);
                idCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), backupId, QueryConstants.EQUAL);
            } else {
                Integer value = (Integer) inputJSONObject.get("opId");
                long opId = value.longValue();
                sizeCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "SIZE"), 0f, QueryConstants.GREATER_THAN);
                idCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            }
            boolean getByCount = (boolean) inputJSONObject.get("getByCount");
            if (getByCount) {
                JSONArray array = BMRDatabase.getIndividualBackupDetailsByCount(inputJSONObject, sizeCriteria.and(idCriteria));
                out.println(array.toString());
            } else {
                int count = (int) inputJSONObject.get("count");
                if (count == -1) {
                    JSONArray array = BMRDatabase.getIndividualBackupDetailsFromTO(inputJSONObject, sizeCriteria.and(idCriteria));
                    out.println(array.toString());
                } else {
                    JSONArray array = BMRDatabase.getIndividualBackupDetails(inputJSONObject, sizeCriteria.and(idCriteria));
                    out.println(array.toString());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward getHistory(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            JSONObject retVal = new JSONObject();
            PrintWriter out = response.getWriter();
            String dcName = (String) inputJSONObject.get("dc");
            long backupId = Long.parseLong(inputJSONObject.get("dcId").toString());
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), backupId, QueryConstants.EQUAL);

            JSONArray array = BMRDatabase.getIndividualBackupDetails(inputJSONObject, criteria);
            JSONObject jsonObj = BMRDatabase.getNextScheduleRuntime(backupId);
            String nextScheduleRuntime = jsonObj.getString("time");
            String type = jsonObj.getString("type");
            retVal.put("history", array);
            retVal.put("nextRuntime", nextScheduleRuntime);
            retVal.put("nextRunType", type);

            out.println(retVal.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward updateInterruptedBackupStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            String dcName = (String) inputJSONObject.get("dc");
            long backupId = Long.parseLong(inputJSONObject.get("dcId").toString());
            String domain = (String) inputJSONObject.get("domain");
            BMRDatabase.updateInterruptedBackupStatus(dcName, backupId, domain);
            out.println(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward updateInterruptedRestoreStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            String dcName = (String) inputJSONObject.get("dc");
            long dcId = Long.parseLong(inputJSONObject.get("dcId").toString());
            String domain = (String) inputJSONObject.get("domain");
            Integer value = (Integer) inputJSONObject.get("backupOpId");
            Long backupOpId = value.longValue();
            Integer valueId = (Integer) inputJSONObject.get("restoreId");
            Long restoreOpId = valueId.longValue();
            String folderTime = (String) inputJSONObject.get("folderTime");
            BMRDatabase.updateInterruptedRestoreStatus(dcName, dcId, domain, backupOpId, restoreOpId, folderTime);
            out.println(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward updateInterruptedVLRStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            String dcName = (String) inputJSONObject.get("dc");
            long backupId = Long.parseLong(inputJSONObject.get("dcId").toString());
            String domainName = (String) inputJSONObject.get("domain");
            boolean ret = BMRDatabase.getInterruptedVLRdetails(dcName, backupId, domainName);
            PrintWriter out = response.getWriter();
            out.println(ret);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward partitionDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            Criteria criteria;
            boolean getByName = (boolean) inputJSONObject.get("getByName");
            boolean getByCount = (boolean) inputJSONObject.get("getByCount");
            if (getByName) {
                long backupId = Long.parseLong(inputJSONObject.get("dcId").toString());
                criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), backupId, QueryConstants.EQUAL);
            } else {
                Integer value = (Integer) inputJSONObject.get("opId");
                long opId = value.longValue();
                criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), opId, QueryConstants.EQUAL);
            }
            /*if (!getByCount) {
             int count = (int) inputJSONObject.get("count");
             Calendar cal = Calendar.getInstance();
             Date startDate = cal.getTime();
             Timestamp endTime = DateUtil.getTimestampFromDate(startDate);
             cal.add(Calendar.DATE, -count);
             Date endDate = cal.getTime();
             Timestamp startTime = DateUtil.getTimestampFromDate(endDate);
             Criteria startCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME"), startTime, QueryConstants.GREATER_EQUAL);
             Criteria endCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME"), endTime, QueryConstants.LESS_EQUAL);
             criteria = criteria.and(startCriteria).and(endCriteria);
             }*/
            JSONArray array = BMRDatabase.getPartitionDetails(inputJSONObject, criteria);
            out.println(array.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward backupNow(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            
            final JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
             Thread thread = new Thread() {
             @Override
             public void run() {
             try {
             long fullBuId = 0;
             String dcName = (String) inputJSONObject.get("dc");
             String type = (String) inputJSONObject.get("type");
             String code = (String) inputJSONObject.get("code");
             String domainName = (String) inputJSONObject.get("domain");
             Properties prop = RMPDomainHandler.getDomainDetailsByName(domainName);
             long domainId = Long.valueOf(prop.getProperty("DOMAIN_ID"));
             long backupId = Long.parseLong(inputJSONObject.get("dcId").toString());
             String backupType = BMRDatabase.getBackupTypeFromId(backupId);
             Properties currentEncryptionDetails = BMRDatabase.currentEncryptionDetails(backupId);
             boolean currentEncryptionStatus = Boolean.parseBoolean((String) currentEncryptionDetails.getProperty("IS_ENCRYPTED"));
             String currentEncryptionPwd = (String) currentEncryptionDetails.getProperty("SECRETKEY");
             int isEncrypted = (currentEncryptionStatus) ? 1 : 0;
             if (backupType.equals("BMR")) {
             LogWriter.bmr.info("In backupNow, Mode: BMR ");//NO I18N
             BMRDatabase.backupCode(dcName, backupId, domainId, type, code, fullBuId, isEncrypted, currentEncryptionPwd);
             } else {
             LogWriter.bmr.info("In backupNow, Mode: FLR ");//NO I18N
             FLRDatabase.backupCode(dcName, backupId, domainId, type, "Volume", "File", fullBuId, isEncrypted, currentEncryptionPwd);
             }
             } catch (Exception e) {
             e.printStackTrace();
             }
             }
             };
            thread.start();
        } catch (Exception e) {
            e.printStackTrace();
            }
        return null;
    }

    public ActionForward getRunningProcesses(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        JSONObject retVal = new JSONObject();

        try {
            PrintWriter out = response.getWriter();
            BMRThreadManager manager = BMRThreadManager.getBMRThreadManager();
            ArrayList<String> list = manager.getAllRunningProcesses();
            JSONObject obj = new JSONObject();
            HashMap<String, Integer> map = manager.getAllStatus();
            for (Map.Entry<String, Integer> entry : map.entrySet()) {
                obj.put(entry.getKey(), entry.getValue());
            }
            for (String str : list) {
                if (str.contains("mount")) {
                    retVal.put("mount", str);
                } else if (str.contains("merge")) {
                    retVal.put("merge", str);
                } else if (str.contains("restore")) {
                    retVal.put("restore", str);
                }
            }
            retVal.put("proArr", obj);
            out.println(retVal);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward mergeAndMountBackups(ActionMapping mapping, ActionForm form, HttpServletRequest request, final HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            final String dcName = (String) inputJSONObject.get("dc");
            long dcId = Long.parseLong(inputJSONObject.get("dcId").toString());
            final Integer value = (Integer) inputJSONObject.get("id");
            final Long opId = value.longValue();
            final String restoreType = (String) inputJSONObject.get("restoreType");
            boolean isBMR = restoreType.equals("Bare Metal Restore");
            String errorMsg = "";

            final BMRThreadManager manager = BMRThreadManager.getBMRThreadManager();
            JSONObject obj = FLRDatabase.getMountedPointDetails();

            if (!obj.getBoolean("noRows")) {

                long prevOpId = obj.getLong("opId");

                if (obj.getString("rType").equalsIgnoreCase("VLR")) {
                    FLRDatabase.markMountDismount(prevOpId, 0, new JSONArray());
                } else {
                    FLRDatabase.unmountDrives(prevOpId);
                }
            }

            if (isBMR) {
                String folder = BMRDatabase.mergeBackups(opId, dcName, dcId);
                JSONObject status = new JSONObject();
                status.put("stopSpinner", true);
                status.put("folder", folder);
                status.put("merge", true);
                out.println(status);
            } else {
                String type = restoreType.equalsIgnoreCase("Volume Level Restore") ? "VLR" : "FLR";

                JSONObject retObj = BMRDatabase.preMergeAndMount(dcName, dcId, type, opId);
                JSONObject mountRetObj = retObj.getJSONObject("mountRetVal");
                String mergeRetVal = (String) retObj.get("mergeRetVal");
                JSONArray drivesList;
                JSONObject status = new JSONObject();
                boolean isMountSuccessful = mountRetObj.getBoolean("isSuccessful");

                errorMsg = mountRetObj.getString("errorMsg");

                if (isMountSuccessful) {
                    drivesList = mountRetObj.getJSONArray("successfulDriveLetters");
                } else {
                    drivesList = new JSONArray();
                }

                if (mergeRetVal.isEmpty() || !isMountSuccessful) {
                    manager.clearData();
                }
                if (mergeRetVal.equalsIgnoreCase("Repository password has been changed")) {
                    errorMsg = "Repository password has been changed";
                    mergeRetVal = "--"; //check this
                    FLRDatabase.markMountDismount(opId, 0, new JSONArray());
                }

                status.put("stopSpinner", true);
                status.put("mergeRetVal", mergeRetVal);
                status.put("mountRetVal", drivesList);
                status.put("failedDriveLetters", mountRetObj.getJSONArray("failedDriveLetters"));
                status.put("errorMsg", errorMsg);

                out.println(status);
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static ActionForward restoreNow(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            JSONObject retVal = FLRDatabase.restoreNow(inputJSONObject);
            out.print(retVal);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public ActionForward getBackupFolder(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            long opId = Long.parseLong(inputJSONObject.get("id").toString());
            long finalOpId = -1;
            boolean isFB = BMRDatabase.isFullBackup(opId);
            if (isFB) {
                finalOpId = opId;
            } else {
                long fbId = BMRDatabase.getIBParentId(opId);
                finalOpId = fbId;
            }
            Properties storage = BMRDatabase.getBackupFolder(finalOpId);
            JSONObject status = new JSONObject();
            status.put("folder", storage.getProperty("backupFolder").toString());
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward getAllBmrRestoreDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(URLDecoder.decode(request.getParameter("req"), "UTF-8"));
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            int rangeStart = Integer.parseInt(inputJSONObject.get("rangestart").toString());// No I18N
            int limit = Integer.parseInt(inputJSONObject.get("limit").toString());// No I18N
            JSONObject restoreDetail = BMRDatabase.getAllBmrRestoreDetails(rangeStart, limit, null);
            out.println(restoreDetail.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward validatePath(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));// No I18N
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            Boolean isLocal = (Boolean) inputJSONObject.get("isLocal");
            String guestUserName = null, guestPassword = null, copyToPath = null;
            if (isLocal) {
                copyToPath = URLDecoder.decode(GeneralUtil.replaceChar(inputJSONObject, "path"), "UTF-8");// No I18N
            } else {
                guestUserName = URLDecoder.decode(inputJSONObject.getJSONObject("guestCredentials").get("username").toString(), "UTF-8");
                guestPassword = URLDecoder.decode(inputJSONObject.getJSONObject("guestCredentials").get("password").toString(), "UTF-8");
                copyToPath = URLDecoder.decode(inputJSONObject.getJSONObject("guestCredentials").get("path").toString(), "UTF-8");
            }
            JSONObject ret = BMRDatabase.validatePath(copyToPath, guestUserName, guestPassword, isLocal);
            out.println(ret.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward validateSelectedVolumes(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            String filesStr = URLDecoder.decode(GeneralUtil.replaceChar(inputJSONObject, "arr"), "UTF-8");// No I18N
            JSONArray filesToRestore = new JSONArray(filesStr);
            String domain = (String) inputJSONObject.get("domain");
            String dcName = (String) inputJSONObject.get("dc");
            JSONObject obj = FLRDatabase.validateSelectedVolumes(filesToRestore, domain, dcName);
            out.println(obj.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward getAllBmrRestoredFilesStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(URLDecoder.decode(request.getParameter("req"), "UTF-8"));
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            Long restoreId = Long.parseLong(inputJSONObject.get("restoreId").toString());// No I18N
            JSONArray array = BMRDatabase.getAllBmrRestoredFilesStatus(restoreId);
            out.println(array.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward bmrDeleteRepository(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(URLDecoder.decode(request.getParameter("req"), "UTF-8"));
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            Long repoId = Long.parseLong(inputJSONObject.get("repId").toString());//No I18N
            JSONObject status = BMRDatabase.bmrDeleteBackupRepository(repoId);
            out.println(status.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkIso(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            boolean result;
            String isoPath = System.getProperty("server.dir") + File.separator + "bin" + File.separator + "RMP.iso";// No I18N
            String path = null;
            File file = new File(isoPath);

            if (file.exists()) {
                result = true;
                path = isoPath;
            } else {
                result = false;
                path = "Not yet created";
            }

            JSONObject status = new JSONObject();
            status.put("result", result);
            status.put("path", path);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkWimFile(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            String retVal = "Success";
            boolean adkResult = false, check = true;
            boolean value = (boolean) inputJSONObject.get("value");
            String input = URLDecoder.decode(GeneralUtil.replaceChar(inputJSONObject, "path"), "utf-8");//No I18N
            if (value) {
                String user = URLDecoder.decode(GeneralUtil.replaceChar(inputJSONObject, "user"), "utf-8");//No I18N
                String pwd = URLDecoder.decode(GeneralUtil.replaceChar(inputJSONObject, "pwd"), "utf-8");//No I18N
                Properties props = RMPNativeManager.checkCredentials(input, user, pwd, "connect");// No I18N
                LogWriter.bmr.info("checkCredentials in checkWimFile: " + props);//NO I18N
                if (props.get("Success") != null) {
                    retVal = "Success";//No I18N
                } else {
                    check = false;
                    if (props.get("Access_Denied") != null) {
                        retVal = "Error : Access Denied";//No I18N
                    } else if (props.get("Bad_Net_Path") != null) {
                        retVal = "Error : Network path was not found";//No I18N
                    } else if (props.get("Bad_Net_Name") != null) {
                        retVal = "Error : Network name cannot be found";//No I18N
                    } else if (props.get("Invalid_Password") != null) {
                        retVal = "Error : Specified network password is not correct";//No I18N
                    } else if (props.get("NoNet_BadPath") != null) {
                        retVal = "Error : Network path was either typed incorrectly or does not exist.Please try again.";//No I18N
                    } else if (props.get("Logon_Failure") != null) {
                        retVal = "Error : The user name or password is incorrect.";//No I18N
                    } else if (props.get("Bad_UserName") != null) {
                        retVal = "Error : Specified username is invalid.";//No I18N
                    } else if (props.get("Other") != null) {
                        retVal = "Error : Could not access the location due to some error.Please try again.";//No I18N
                    }
                }
            }
            if (check) {
                String wimPath = input + "\\Windows Preinstallation Environment\\amd64\\en-us\\winpe.wim";// No I18N
                File file = new File(wimPath);
                if (file.exists()) {
                    adkResult = true;
                }
            }
            JSONObject status = new JSONObject();
            status.put("result", retVal);
            status.put("adkResult", adkResult);
            status.put("stopSpinner", true);
            status.put("wimCheck", true);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkType(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            Integer value = Integer.parseInt(inputJSONObject.get("id").toString());
            long opId = value.longValue();
            boolean isFB = BMRDatabase.isFullBackup(opId);
            JSONObject status = new JSONObject();
            status.put("result", isFB);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkFullRestore(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            PrintWriter out = response.getWriter();
            String dcName = (String) inputJSONObject.get("dc");
            Integer value = (Integer) inputJSONObject.get("id");
            long opId = value.longValue();
            long fbId = BMRDatabase.getIBParentId(opId);
            boolean check = BMRDatabase.checkFullRestore(dcName, fbId);
            JSONObject status = new JSONObject();
            status.put("result", check);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward unmountDrives(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            PrintWriter out = response.getWriter();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            Integer opId = (Integer) inputJSONObject.get("opId");
            String restoreType = inputJSONObject.getString("restoreType");
            BMRThreadManager manager = BMRThreadManager.getBMRThreadManager();
            if (restoreType.equalsIgnoreCase("VLR")) {
                manager.clearData();
                FLRDatabase.markMountDismount(opId, 0, new JSONArray());
            } else {
                FLRDatabase.unmountDrives(opId);
            }
            JSONObject status = new JSONObject();
            status.put("result", true);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkLicense(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            boolean isFreeVersion = false;
            PrintWriter out = response.getWriter();
            if (SubscriptionModel.checkSubscription(FunctionalityModel.isFreeEdition)) {
                isFreeVersion = true;
            }
            JSONObject status = new JSONObject();
            status.put("result", isFreeVersion);
            out.println(status);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward bmrDomainsShow(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        JSONArray jsonObj = new JSONArray();
        try {
            PrintWriter out = response.getWriter();
            ArrayList<Properties> domainDetails = RMPDomainHandler.getRMPDomainDetails();
            JSONArray jsonDomainList = new JSONArray();
            for (Properties prop : domainDetails) {
                boolean displayDomain = false, isBMRBackupConfigured = false, isBMRBackupDone = false;
                String domainName = prop.get("DOMAIN_NAME").toString();
                Long roleId = RMPTechnicianHandler.getRoleIdByDomainName(domainName, request);
                if (roleId.compareTo(0L) != 0) {
                    if (RMPTechnicianHandler.isDisplayDomain(roleId, request.getRequestURI())) {
                        displayDomain = true;
                    }
                    if (!BMRDatabase.isBMRConfigured(domainName)) {
                        isBMRBackupConfigured = true;
                    }
                    if (!BMRDatabase.isBMRBackupDone(domainName)) {
                        isBMRBackupDone = true;
                    }
                    JSONArray jsondomain = getDomainDetailsFromProperties(prop);
                    jsondomain.put(7, displayDomain);
                    jsondomain.put(8, isBMRBackupConfigured);
                    jsondomain.put(9, isBMRBackupDone);
                    jsonDomainList.put(jsondomain);
                }
            }
            jsonObj.put(0, jsonDomainList);
            out.println(jsonObj.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // for licensing - start
    public ActionForward applyLicense(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse resp) throws JSONException, IOException {
        JSONObject retval = new JSONObject();
        resp.setContentType(RmpConstants.CONTENT_TYPE);
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));//NO I18N
            Boolean isSave = (Boolean) inputJSONObject.get("isSave");//NO I18N
            if (isSave) {
                ArrayList<Long> newServersList = new ArrayList<Long>();
                JSONArray jArray = (JSONArray) inputJSONObject.get("licensedList");//NO I18N
                if (jArray != null) {
                    for (int i = 0; i < jArray.length(); i++) {
                        newServersList.add(Long.parseLong(jArray.get(i).toString()));
                    }
                }
                boolean isRemoveBackups = Boolean.parseBoolean(inputJSONObject.get("isRemoveBackups").toString());// No I18N
                BMRLicenseHandler.applyLicense(newServersList, isRemoveBackups);
            }
            BMRLicenseHandler.updateIsWindowsServerConfigured();
            retval.put("isSuccess", true);//NO I18N
            resp.getWriter().print(retval.toString());
        } catch (Exception e) {
            e.printStackTrace();
            retval.put("isSuccess", false);//NO I18N
            resp.getWriter().print(retval.toString());
        }
        return null;
    }

    public ActionForward getBMRLicenseDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));//NO I18N
            response.setContentType(RmpConstants.CONTENT_TYPE);
            PrintWriter out = response.getWriter();
            JSONObject returnValue = new JSONObject();
            JSONArray machineDetatils = new JSONArray();
            List domainList = RMPDomainHandler.getDomainNames();
            for (int i = 0; i < domainList.size(); i++) {
                JSONObject domainData = new JSONObject();
                String domainName = (String) domainList.get(i);
                long domainId = Long.valueOf(RMPDomainHandler.getDomainDetailsByName(domainName).getProperty("DOMAIN_ID"));//NO I18N
                Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);//NO I18N
                JSONArray machineList = BMRDatabase.getBMRMachineDetails(criteria);
                domainData.put("domainName", domainName);//NO I18N
                domainData.put("machines", machineList);//NO I18N
                machineDetatils.put(domainData);
            }
            returnValue.put("machineDetails", machineDetatils);//NO I18N
            returnValue.put("availableCount", LicenseUtil.licenseSubscriptionCount(Environment.windows_server));//NO I18N

            JSONObject componentDetails = LicenseManager.getComponentDetails();
            boolean showInfo = false;
            JSONArray infoKey = new JSONArray();
            if (componentDetails.has(LicenseUtil.ADOBJECTS_COMPONENT) && ProductSubscriptionInfo.subscribedObjectCt != 0) {
                showInfo = true;
                infoKey.put("rmp.licensing.free_dcs_info");
            }
            if (!componentDetails.has(LicenseUtil.WINDOWSSERVERS_COMPONENT) && !(LicenseUtil.getSubscriptionType() == EditionType.Free.ordinal())) {
                showInfo = true;
                infoKey.put("rmp.licensing.free_servers_info");
            }
            returnValue.put("showInfo", showInfo);// NO I18N
            returnValue.put("infoKey", infoKey);
            out.println(returnValue.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public ActionForward checkIsLicensed(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse resp) {
        LogWriter.bmr.info("API called: " + "BMRConfiguration.checkIsLicensed()");
        try {
            JSONObject retval = new JSONObject();
            Integer licenseSubscription = LicenseUtil.licenseSubscriptionCount(Environment.windows_server);
            if (licenseSubscription == -1) {//Unlimited License
                licenseSubscription = Integer.MAX_VALUE;
            }
            boolean needLicensePopup = (licenseSubscription - LicenseUtil.getWindowsServersUsage(false)) > 0; // User has more subscription available
            needLicensePopup = (needLicensePopup & (LicenseUtil.getWindowsServersUsage(true) > LicenseUtil.getWindowsServersUsage(false)));//User has unlicensed Hosts

            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_WINDOWSSERVER_CONFIGURED", QueryConstants.EQUAL);
            DataObject obj = CommonUtil.getPersistence().get(TableName.RMP_SYSTEM_PARAMS, criteria);
            Iterator iter = obj.getRows("SystemParams");
            if (iter.hasNext()) {
                Row row = (Row) iter.next();
                if (row.get("PARAM_VALUE").toString().equalsIgnoreCase("false")) {
                    needLicensePopup = true;
                }
            }
            retval.put("status", needLicensePopup);
            resp.getWriter().print(retval.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // for licensing - end
}
// ignoreI18n_end
