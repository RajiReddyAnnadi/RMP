/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.bmr.agent;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.ds.query.SortColumn;
import com.manageengine.ads.fw.agent.installation.AgentExecutionHandler;
import com.manageengine.ads.fw.agent.installation.InstallationUtil;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.util.GeneralUtil;
import java.util.ArrayList;
import java.util.Properties;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Chella-3221
 */
public class InstallAgent {

    public static String agentInstall(Properties agentDetails, String domainController, String name,boolean isInstall) {
        String error = null, errorMsg = null;
        JSONObject errorObject = new JSONObject();
        try {
            ArrayList<Properties> workstation = new ArrayList<Properties>();
            Properties wrkstn = new Properties();
            String domainname = agentDetails.getProperty("DOMAIN_NAME"); //No I18N
            String flatname = agentDetails.getProperty("USER_DOMAIN_NAME");
            String pwd = agentDetails.getProperty("PASSWORD");  //No I18N
            String uname = agentDetails.getProperty("USER_NAME"); //No I18N
            String dcName = domainController;
//            if (pwd.contains("\"")) {
//                pwd = pwd.replaceAll("\"", "\\\\" + "\"");
//            }
            wrkstn.setProperty("WORKSTATION_NAME", dcName);
            wrkstn.setProperty("OBJECT_GUID", dcName);
            wrkstn.setProperty("DOMAIN_NAME", domainname);
            wrkstn.setProperty("USERNAME", "\""+flatname + "\\" + uname +"\""+ "###" +pwd);
            wrkstn.setProperty("PASSWORD", "*");
            wrkstn.setProperty("OS", "windows");
            workstation.add(wrkstn);
            int retVal = -1;
            if(isInstall){
                LogWriter.bmr.info("Installing agent..");//NO I18N
                retVal = AgentExecutionHandler.installAgent(workstation, name, true, null, null, null, false);
            }
            else{
                LogWriter.bmr.info("Uninstalling agent..");//NO I18N
                retVal = AgentExecutionHandler.uninstallAgent(workstation, name, true, null, null, null, false);
            }
            boolean check = false;
            while (!check) {
                JSONObject resultObj = AgentExecutionHandler.getStatus(retVal).getJSONObject(0);
                JSONArray statusArray = resultObj.getJSONArray("status");//No I18N
                JSONObject statusObj = statusArray.getJSONObject(0);
                String status = statusObj.get("status").toString();
                if ((status.equals("ads.agent.install_failed")) || (status.equals("ads.agent.install_success"))||(status.equals("ads.agent.uninstall_failed")) || (status.equals("ads.agent.uninstall_success"))) {
                    check = true;
                }
            }
            errorObject = GeneralUtil.getAgentErrorMessage(domainController);
            if(!errorObject.get("error").toString().equalsIgnoreCase("No Error"))
            {
                error = errorObject.get("error").toString();
                errorMsg = errorObject.get("errorMsg").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        LogWriter.bmr.info("InstallAgent error -> " + error);//no i18n
	LogWriter.bmr.info("InstallAgent errorMsg -> " + errorMsg);//no i18n
        return errorMsg;
    }

    public static boolean getAgentStatus(Properties agentDetails, String dcName, String name) {
        try {
            Properties wrkstn = new Properties();
            String domainname = agentDetails.getProperty("DOMAIN_NAME"); //No I18N
            String flatname = agentDetails.getProperty("USER_DOMAIN_NAME"); //No I18N
            String pwd = agentDetails.getProperty("PASSWORD");  //No I18N
            String uname = agentDetails.getProperty("USER_NAME"); //No I18N
            if (pwd.contains("\"")) {
                pwd = pwd.replaceAll("\"", "\\\\" + "\"");
            }
            wrkstn.setProperty("WORKSTATION_NAME", dcName);
            wrkstn.setProperty("OBJECT_GUID", dcName);
            wrkstn.setProperty("DOMAIN_NAME", domainname);
            wrkstn.setProperty("USERNAME", flatname + "\\" + uname);
            wrkstn.setProperty("PASSWORD", pwd);
            wrkstn.setProperty("OS", "windows");
            Properties agentProperties = InstallationUtil.getAgentDetails(name);
            CheckAgentStatus obj = new CheckAgentStatus(wrkstn, agentProperties);
            boolean status = obj.isStatusInstalled();
            LogWriter.bmr.info("AgentStatus: " + status);//NO I18N
            return status;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
