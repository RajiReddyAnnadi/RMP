/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.bmr.agent;

import com.manageengine.ads.fw.agent.installation.InstallationTask;
import java.util.Properties;

/**
 *
 * @author chella-3221
 */
public class CheckAgentStatus extends InstallationTask {

    public CheckAgentStatus(Properties workstationProp, Properties agentProperties) {
        super(workstationProp, agentProperties);
    }

    public boolean isStatusInstalled() {
        return isAgentInstalled();
    }
}
