/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.bmr.schedule;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.Row;
import com.adventnet.taskengine.Scheduler;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.scheduler.ScheduleManager;
import com.manageengine.rmp.util.DataTypeUtil;
import java.util.ArrayList;
import java.util.HashMap;
import javax.transaction.SystemException;
import javax.transaction.TransactionManager;

/**
 *
 * @author chella-3221
 */
public class BMRScheduler {

    public long dcId;
    public int backupFrequency;
    public String hour;
    public String min;
    public int weekMask;
    public int dateMask;
    public String backupType;

    public BMRScheduler(long dcId, String backupFrequency, String hour, String min, String weekMask, String dateMask, String backupType) {
        try {
            this.dcId = dcId;
            if (weekMask != null) {
                this.weekMask = Integer.parseInt(weekMask);
            }
            if (dateMask != null) {
                this.dateMask = Integer.parseInt(dateMask);
            }
            this.backupFrequency = Integer.parseInt(backupFrequency);
            this.hour = hour;
            this.min = min;
            this.backupType = backupType;
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.severe("BMRBackupScheduler Construct : " + e);//No I18N
        }
    }

    public void updateSchedule() throws IllegalStateException, SecurityException, SystemException {
        TransactionManager txn = DataAccess.getTransactionManager();
        try {
            txn.begin();
            //deleteSchedules(backupType);
            HashMap<String, String> dataInputTask = new HashMap<String, String>();
            if (backupType.equals("FB")) {
                dataInputTask.put("dcIdFB", String.valueOf(dcId));
            } else if (backupType.equals("flrFB")) {
                dataInputTask.put("dcIdFlrFB", String.valueOf(dcId));
            } else if (backupType.equals("flrIB")) {
                dataInputTask.put("dcIdFlrIB", String.valueOf(dcId));
            } else {
                dataInputTask.put("dcIdIB", String.valueOf(dcId));
            }

            int HH = Integer.parseInt(hour);
            int MM = Integer.parseInt(min);
            LogWriter.general.info("Setting BMR Schedule @ " + HH + ":" + MM);//No I18N
            String scheduleAppend = "_" + dcId + "_" + 0;
            ScheduleManager scheduleManager;
            if (backupType.equals("FB")) {
                scheduleManager = new ScheduleManager("bmrFB" + scheduleAppend, "com.manageengine.rmp.bmr.schedule.BMRFullBackup", "bmrFBSchedule" + scheduleAppend);//No I18N
            } else if (backupType.equals("flrFB")) {
                scheduleManager = new ScheduleManager("flrFB" + scheduleAppend, "com.manageengine.rmp.bmr.schedule.FLRFullBackup", "flrFBSchedule" + scheduleAppend);//No I18N
            } else if (backupType.equals("flrIB")) {
                scheduleManager = new ScheduleManager("flrIB" + scheduleAppend, "com.manageengine.rmp.bmr.schedule.FLRIncrementalBackup", "flrIBSchedule" + scheduleAppend);//No I18N
            } else {
                scheduleManager = new ScheduleManager("bmrIB" + scheduleAppend, "com.manageengine.rmp.bmr.schedule.BMRIncrementalBackup", "bmrIBSchedule" + scheduleAppend);//No I18N
            }
            long scheduleId = 0L;
            if (backupFrequency == 0) {
                int[] selectedDates = getSelectedWeeks(dateMask);
                scheduleId = scheduleManager.setInfiniteMonthlySchedule(HH, MM, selectedDates);
            } else if (backupFrequency == 1) {
                scheduleId = scheduleManager.setInfiniteDailySchedule(HH, MM);
            } else if (backupFrequency == 2) {
                int[] selectedWeeks = getSelectedWeeks(weekMask);
                scheduleId = scheduleManager.setInfiniteWeeklySchedule(HH, MM, selectedWeeks);
            }
            scheduleManager.scheduleTask(dataInputTask);
            updateBackupScheduleTable(dcId, scheduleId, backupType);

            txn.commit();
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.severe("BMRBackupScheduler : " + e);//No I18N
            txn.rollback();
        }
    }

    //********************************
    // Backup Scheduler Utilities
    //********************************
    private int[] getSelectedWeeks(int weekMask) {
        ArrayList<Integer> selectedWeeks = new ArrayList<Integer>();

        selectedWeeks.add(weekMask);

        return DataTypeUtil.getArrayListAsIntArray(selectedWeeks);
    }

    public static void disableSchedule(Long scheduleID) {
        try {
            setStatus(scheduleID, 4);
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.severe("BMRBackupScheduler : " + e);//No I18N
        }
    }

    private static void setStatus(Long scheduleID, Integer status) {
        try {
            Persistence persistence = (Persistence) BeanUtil.lookup("Persistence");
            Scheduler scheduler = (Scheduler) BeanUtil.lookup("Scheduler");

            DataObject scheduledTaskDataObject = persistence.get("Scheduled_Task", new Criteria(Column.getColumn("Scheduled_Task", "SCHEDULE_ID"), scheduleID, QueryConstants.EQUAL));
            if (scheduledTaskDataObject.size("Scheduled_Task") > 0) {
                Row row = scheduledTaskDataObject.getFirstRow("Scheduled_Task");

                scheduler.setScheduledTaskAdminStatus(scheduleID, ((Long) row.get("TASK_ID")).longValue(), status);
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.severe("BMRBackupScheduler : " + e);//No I18N
        }
    }

    public static void enableSchedule(Long scheduleID) {
        try {
            setStatus(scheduleID, 3);
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.severe("BMRBackupScheduler : " + e);//No I18N
        }
    }

    public static int getEnableDisableScheduleStatus(Long scheduleID) throws Exception {
        Persistence persistence = (Persistence) BeanUtil.lookup("Persistence");
        int enableDisableValue = 3;
        DataObject scheduledTaskDataObject = persistence.get("Scheduled_Task", new Criteria(Column.getColumn("Scheduled_Task", "SCHEDULE_ID"), scheduleID, QueryConstants.EQUAL));
        if (scheduledTaskDataObject.size("Scheduled_Task") > 0) {
            Row row = scheduledTaskDataObject.getFirstRow("Scheduled_Task");
            enableDisableValue = ((Integer) row.get("ADMIN_STATUS")).intValue();
        }

        return enableDisableValue;
    }

    public static void updateBackupScheduleTable(long dcId, long scheduleId, String type) {
        try {
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            UpdateQuery upquery = new UpdateQueryImpl(TableName.BMR_BACKUP_SCHEDULE);
            if ((type.equals("FB")) || (type.equals("flrFB"))) {
                upquery.setUpdateColumn("FB_SCHEDULE_ID", scheduleId); //No I18N 
            } else {
                upquery.setUpdateColumn("IB_SCHEDULE_ID", scheduleId); //No I18N 
            }

            upquery.setCriteria(criteria);
            CommonUtil.getPersistence().update(upquery);
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.severe("BMRBackupScheduler : " + e);
        }
    }
}
