package com.manageengine.rmp.bmr;

import com.manageengine.rmp.bmr.configure.FLRDatabase;
import com.manageengine.rmp.common.LogWriter;

import java.util.*;

public class BMRThreadManager {

    private static BMRThreadManager instance = null;
    private static HashMap<String, Integer> statusMap = null;
    private static HashMap<String, Object > retValMap = null;
    public Map<String, Map> renameEntriesSorted;
    public Map<String, Map> renameEntries;
    public Map<String, Map> deleteEntries;
    Timer timer;

    public final static int STARTED = 0;
    public final static int SUCCESS = 1;
    public final static int FAILED = 2;

    public static BMRThreadManager getBMRThreadManager() {

        synchronized (BMRThreadManager.class) {
            if (instance == null) {
                instance = new BMRThreadManager();
            }
        }
        return instance;
    }

    private BMRThreadManager() {
        statusMap = new HashMap<>();
        retValMap = new HashMap<>();
    }

    public synchronized void setStatus(String process, int status) {
        statusMap.put(process, status);
    }

    public synchronized void setRetVal(String process, Object retVal) {
        Integer status = statusMap.get(process);

        if(status!=null) {
            if(status != BMRThreadManager.STARTED) {
                retValMap.put(process, retVal);
            } else {
                LogWriter.bmr.info("Process running. Cannot set the value.");//NO I18N
            }
        } else {
            LogWriter.bmr.info("No process found with specified name");//NO I18N
        }
    }

    public synchronized Object getRetVal(String process) {
        Integer status = statusMap.get(process);

        if(status!=null) {
            if(status != BMRThreadManager.STARTED) {
                return retValMap.get(process);
            } else {
                LogWriter.bmr.info("Process running. Cannot get the value.");//NO I18N
            }
        } else {
            LogWriter.bmr.info("No process found with specified name");//NO I18N
        }

        return "";
    }

    public synchronized int getStatus(String process) {
        Integer status = statusMap.get(process);

        if(status!=null) {
            return status;
        } else {
            return  -1; // No process found with specified name
        }
    }

    public synchronized boolean hasProcess (String process) {
        return statusMap.containsKey(process);
    }

    public synchronized boolean proceedCheck() {
        int numberOfProcesses = statusMap.size();
        for (Map.Entry<String,Integer> entry : statusMap.entrySet()) {
            if(entry.getValue()==BMRThreadManager.STARTED) {
                return false;
            }
        }
        return true;
    }

    public synchronized void clearData() {
        this.deleteEntries = null;
        this.renameEntriesSorted = null;
        statusMap.clear();
        retValMap.clear();
    }

    public ArrayList<String> getAllRunningProcesses() {
        ArrayList<String> list = new ArrayList();

        for (Map.Entry<String, Integer> entry : statusMap.entrySet())
        {
            if(entry.getValue()==BMRThreadManager.STARTED) {
                list.add(entry.getKey());
            }
        }

        return list;
    }

    public boolean isProcessRunning() {
        if(statusMap.containsValue(BMRThreadManager.STARTED)) {
            return true;
        } else {
            return false;
        }
    }

    public HashMap<String,Integer> getAllStatus() {
        return statusMap;
    }

    public void startTimer() {
        if(timer!=null) {
            timer.cancel();
        }
        timer = new Timer("unmountOnTimeout");
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if(proceedCheck()) {
                    LogWriter.bmr.info("Timer Called unmountDrives.."); // No I18N
                    FLRDatabase.unmountDrives(-1);
                }
            }
        }, new Date(new Date().getTime() + 900 * 1000), 900 * 1000);

        LogWriter.bmr.info("Timer started successfully..."); // No I18N
    }

    public void stopTimer() {
        if(timer!=null) {
            LogWriter.bmr.info("Timer Stopped"); // No I18N
            timer.cancel();
        }
        timer = null;
    }

}