/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.bmr.schedule;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.taskengine.DEFAULT_TASK_INPUT;
import com.adventnet.taskengine.Task;
import com.adventnet.taskengine.TaskContext;
import com.adventnet.taskengine.TaskExecutionException;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.bmr.configure.BMRDatabase;
import com.manageengine.rmp.bmr.configure.FLRDatabase;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.util.RMPDomainHandler;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.Properties;

/**
 *
 * @author chella-3221
 */
//ignoreI18n_start
public class FLRFullBackup implements Task {

    @Override
    public void executeTask(TaskContext taskContext) throws TaskExecutionException {

        try {
            Iterator<Row> iter = taskContext.getDefaultTaskInputs();
            long dcId = -1L;
            while (iter.hasNext()) {
                Row row = iter.next();
                String varName = (String) row.get(DEFAULT_TASK_INPUT.VARIABLE_NAME);
                switch (varName) {
                    case "dcIdFlrFB":
                        dcId = Long.valueOf((String) row.get(DEFAULT_TASK_INPUT.VARIABLE_VALUE));
                        break;
                }
            }
            LogWriter.bmr.info("FLR Full backup scheduler triggered");
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_BACKUP_SCHEDULE));
            query.addSelectColumn(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "*"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_BACKUP_SCHEDULE, "DC_ID"), dcId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Row row = dobj.getFirstRow(TableName.BMR_BACKUP_SCHEDULE);
            final long domainId = (long) row.get("DOMAIN_ID");
            final String domainName = (String) RMPDomainHandler.getDomainDetailsById(domainId).getProperty("DOMAIN_NAME");
            final String dcName = BMRDatabase.getNameFromId(dcId);
            final String type = "FB";
            final long finalDcId = dcId;
            Thread thread = new Thread() {
                @Override
                public void run() {
                    try {
                        Properties currentEncryptionDetails = BMRDatabase.currentEncryptionDetails(finalDcId);
                        boolean currentEncryptionStatus = Boolean.parseBoolean((String) currentEncryptionDetails.getProperty("IS_ENCRYPTED"));
                        String currentEncryptionPwd = (String) currentEncryptionDetails.getProperty("SECRETKEY");
                        int isEncrypted = (currentEncryptionStatus) ? 1 : 0;
                        JSONObject prevBackupStatus = BMRDatabase.isCompleted(dcName, finalDcId, type, "Scheduler", currentEncryptionStatus, currentEncryptionPwd,"backup");
                        String backupResult = (String) prevBackupStatus.get("result");
                        String restoreResult = (String) prevBackupStatus.get("restoreResult");
                        if (backupResult.equals("Application Interrupted") || backupResult.equals("In Progress")) {
                            BMRDatabase.updateInterruptedBackupStatus(dcName, finalDcId, domainName);
                            prevBackupStatus = BMRDatabase.isCompleted(dcName, finalDcId, type, "Scheduler", currentEncryptionStatus, currentEncryptionPwd, "backup");
                            backupResult = (String) prevBackupStatus.get("result");
                        }
                        if(restoreResult.equals("Application Interrupted") || restoreResult.equals("In Progress")) {
                            boolean ret = BMRDatabase.getInterruptedVLRdetails(dcName,finalDcId,domainName);
                            prevBackupStatus = BMRDatabase.isCompleted(dcName, finalDcId, type, "Scheduler", currentEncryptionStatus, currentEncryptionPwd, "backup");
                            backupResult = (String) prevBackupStatus.get("result");
                            restoreResult = (String) prevBackupStatus.get("restoreResult");
                        }
                        if (!((backupResult.equals("Started")) || (backupResult.equals("In Progress (But failed to delete old backups)")) || (backupResult.equals("In Progress")) || (restoreResult.equals("In Progress")) || (restoreResult.equals("Started")))) {
                            FLRDatabase.backupCode(dcName, finalDcId, domainId, type, "Volume", "File", 0L, isEncrypted, currentEncryptionPwd);
                        } else {
                            LogWriter.bmr.severe("Agent busy due to another backup or restore in progress...So skipping the schedule.");//NO I18N
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            };
            thread.start();

            //}
        } catch (Exception e) {

        }
    }

    @Override
    public void stopTask() throws TaskExecutionException {
    }
}
