/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.backupexplorer;

import com.manageengine.rmp.admin.authentication.RMPAuthConstants;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.OperationType;
import com.manageengine.rmp.constants.StatusId;
import com.manageengine.rmp.dataobjects.OperationInfo;
import com.manageengine.rmp.recovery.RecoveryInitiator;
import com.manageengine.rmp.settings.DomainSettings;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *$Id$ 
 * @author vijay-2377
 */
public class RevertAllObjects extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
       try {
            JSONObject reqParams = new JSONObject(req.getParameter("req"));//NO I18N
            Long domainId = reqParams.getLong("d");//NO I18N
            if (DomainSettings.getDomainStatus(domainId) == 0) {
                JSONObject responseData = new JSONObject();
                responseData.put("status", 0);
                resp.getWriter().println(responseData);
                return;
            }
            String comment = reqParams.get("comment").toString();//NO I18N
            JSONArray deselectedObjects  = reqParams.getJSONArray("deselectedObjects");//NO I18N
            JSONObject partiallySelectedObjects=reqParams.getJSONObject("partiallyselectedObjects");//NO I18N
            JSONObject filter=reqParams.getJSONObject("filter");//NO I18N
            HttpSession session = req.getSession();
            String loginName = (String)session.getAttribute(RMPAuthConstants.LOGIN_NAME);
            OperationInfo recoveryOperationInfo = new OperationInfo(domainId, (reqParams.getInt("operationType")== OperationType.Revert.ordinal() ? OperationType.Revert : OperationType.Restore), loginName,StatusId.InitiatingRestore.value,-1);//NO I18N
            RecoveryInitiator initiator = new RecoveryInitiator(domainId, comment, recoveryOperationInfo,deselectedObjects,partiallySelectedObjects,filter);
            initiator.StartRecovery();
            resp.getWriter().println(recoveryOperationInfo.operationId);
        } 
       catch(Exception e){
             LogWriter.recovery.severe("Restore.revert "+e);//NO I18N
       }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";//NO I18N
    }// </editor-fold>

}
