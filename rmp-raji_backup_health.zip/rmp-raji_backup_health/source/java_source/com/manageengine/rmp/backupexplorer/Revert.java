/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.backupexplorer;

import com.manageengine.rmp.admin.authentication.RMPAuthConstants;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.OperationType;
import com.manageengine.rmp.constants.RmpConstants;
import com.manageengine.rmp.constants.StatusId;
import com.manageengine.rmp.dataobjects.OperationInfo;
import com.manageengine.rmp.recovery.RecoveryInitiator;
import com.manageengine.rmp.settings.DomainSettings;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * $Id$
 *
 * @author vijay-2377
 */
public class Revert extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            JSONObject reqParams = new JSONObject(req.getParameter("req"));
            long domainId = reqParams.getLong("d");//NO I18N
            if (DomainSettings.getDomainStatus(domainId) == 0) {
                JSONObject responseData = new JSONObject();
                responseData.put("status", 0);
                resp.getWriter().println(responseData);
                return;
            }
            if (reqParams.has("revertAllObjects")) {
                RequestDispatcher dispatcher = req.getRequestDispatcher(reqParams.get("revertAllObjects").toString());//No I18N   
                dispatcher.forward(req, resp);
                return;
            }
            

            String comment = reqParams.get("comment").toString();//NO I18N
            JSONArray restoreData = reqParams.getJSONArray("selectedObjList");//NO I18N
            HttpSession session = req.getSession();
            String loginName = (String) session.getAttribute(RMPAuthConstants.LOGIN_NAME);
            OperationInfo recoveryOperationInfo = new OperationInfo(domainId, OperationType.Revert, loginName, StatusId.InitiatingRestore.value, -1);
            RecoveryInitiator initiator = new RecoveryInitiator(domainId, comment, restoreData, recoveryOperationInfo);
            initiator.StartRecovery();
            resp.setContentType(RmpConstants.CONTENT_TYPE);
            resp.getWriter().println(recoveryOperationInfo.operationId);
        } catch (Exception e) {
            LogWriter.recovery.severe("Restore.revert " + e);//NO I18N
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";//NO I18N
    }// </editor-fold>

}
