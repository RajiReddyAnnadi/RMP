/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.backupexplorer;

import com.adventnet.ds.query.SelectQuery;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.DateUtil;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dashboard.DashboardUtil;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * $Id$ :
 * 
 * @author vijay-2377
 */
public class GetBackupListByCount extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          try{
                    
                    JSONObject reqParams = new JSONObject(request.getParameter("req"));//NO I18N
                    String domainId=reqParams.get("d").toString();
                    Integer startingRowNumber=reqParams.getInt("startingRowNumber");//NO I18N
                    boolean order=reqParams.getBoolean("order");//NO I18N
                    Integer endingRowNumber=reqParams.getInt("endingRowNumber");//NO I18N
                    boolean isBackupInfo = true;
                    if(reqParams.has("isBackupInfo")){
                        isBackupInfo = reqParams.getBoolean("isBackupInfo");//No I18N
                    }
                    JSONArray result=prepareBackupList(domainId,startingRowNumber,endingRowNumber,order,isBackupInfo);
                    response.getWriter().println(result.toString());                  
       }
       catch(Exception e){
             LogWriter.portal.severe(String.format("GetBackupListByCount.GetBackupListByCount requset:%s excep:%s", JSONObjectUtil.toJsonObject(request), e));//NO I18N
         }
    }
    public static JSONArray prepareBackupList(String domainId,Integer startingRowNumber,Integer endingRowNumber,boolean order,boolean isBackupInfo){
        JSONArray backupList = new JSONArray();
        try{
            SelectQuery query = DashboardUtil.formBackupInfoQuery(domainId, startingRowNumber, endingRowNumber, order, isBackupInfo, false);
            DataObject dataObject = CommonUtil.getPersistence().get(query);
            Iterator iterator = dataObject.getRows(TableName.RMP_OPERATION_INFO);

            while (iterator.hasNext()) {
                JSONArray backupInfo = new JSONArray();
                Row row = (Row) iterator.next();
                backupInfo.put(DateUtil.getUtcDate((Timestamp) row.get("START_TIME")));
                backupInfo.put(row.get("COUNTS"));
                backupInfo.put(row.get("OPERATION_ID"));
                backupInfo.put(row.get("DATA"));
                backupInfo.put(row.get("TIME_TAKEN"));
                backupInfo.put(row.get("STATUS"));
                backupInfo.put(row.get("INITIATOR"));
                backupList.put(backupInfo);
            }
            return backupList;
        }
        catch(Exception e){
            LogWriter.portal.severe(String.format("GetBackupList.getBackupList domainId:%s excep:%s", domainId, e)); //NO I18N
        }
        return backupList;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";//NO I18N
    }// </editor-fold>

}
