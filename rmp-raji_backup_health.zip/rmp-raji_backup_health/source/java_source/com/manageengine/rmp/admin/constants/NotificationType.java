/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.admin.constants;

/**
 *
 * @author aswathy-1909
 * $Id:$
 */
public enum NotificationType {
    ADBackup,
    ADRestore,
    ADRecycle,
    ADRollback,

    BMRBackup,
    BMRRestore,
    BMRNewISOCreation,

    HyperVBackup,
    HyperVRestore,

    VMWareBackup,
    VMWareRestore
}
