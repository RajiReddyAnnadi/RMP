package com.manageengine.rmp.admin.productnotifier;

import com.manageengine.ads.fw.notifications.NotificationConstants;
import com.manageengine.ads.fw.notifications.NotificationInterface;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GPOErrorNotifier implements NotificationInterface, NotificationConstants {

    private static final String GPO_BACKUP_ERROR = "0";//no i18n
    private static JSONObject notifications = new JSONObject();
    private static String notificationName = "GPO_ERROR_NOTIFIER";//no i18n

    private static Logger logger = Logger.getLogger("ADSLogger");//no i18n

    public GPOErrorNotifier() {
        try {
            notifications.put(GPO_BACKUP_ERROR, new JSONObject());
        } catch(Exception e) {
            logger.log(Level.INFO, "Exception in instantiating class: GPOErrorNotifier "+e.getMessage());//no i18n
        }
    }

    @Override
    public Boolean isNotificationAvailable(Long userId) throws Exception {
        Boolean isNotificationAvailable = false;
        JSONObject obj = new JSONObject();
        try {
            if(ProductNotifierUtil.isGPOFailedObjectsAvailable()) {
                obj.put(NOTIFICATION_ICON, Icon.WARNING);
                obj.put(NOTIFICATION_MESSAGE, "ads.notification_center.gpo_error_message");//no i18n
                obj.put(NOTIFICATION_ACTION_TEXT, "ads.notification_center.gpo_error_action");//no i18n
                obj.put(NOTIFICATION_ACTION, "showGPOErrorDetails");//no i18n
                obj.put(NOTIFICATION_NAME, notificationName);
                obj.put(NOTIFICATION_ID, GPO_BACKUP_ERROR);
                obj.put(ENABLE_STATUS, true);
                obj.put(NOTIFICATION_IS_DISMISSABLE, false);

                notifications.put(GPO_BACKUP_ERROR,obj);

                isNotificationAvailable = true;
            }
            else {
                notifications.getJSONObject(GPO_BACKUP_ERROR).put(ENABLE_STATUS, false);
            }
        } catch (Exception e) {
            logger.log(Level.INFO,"Exception in GPOErrorNotifier.isNotificationAvailable(" + String.valueOf(userId) + ")", e); //no i18n
        }
        return isNotificationAvailable;
    }

    @Override
    public JSONArray getNotification(Long userId) throws Exception {
        JSONArray arr = new JSONArray();
        Iterator iterator = notifications.keys();
        while(iterator.hasNext()) {
            JSONObject obj = notifications.getJSONObject((String) iterator.next());
            if(obj.optBoolean(ENABLE_STATUS)) {
                arr.put(obj);
            }
        }
        return arr;
    }

    @Override
    public Boolean setNotification(JSONObject obj) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");//no I18n
    }

    @Override
    public JSONObject notificationAction(JSONObject params) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");//no I18n
    }
}
