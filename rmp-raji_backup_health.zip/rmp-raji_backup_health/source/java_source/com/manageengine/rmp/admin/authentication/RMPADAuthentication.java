/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.admin.authentication;

import com.adventnet.authentication.AAALOGIN;
import com.adventnet.authentication.PAMException;
import com.adventnet.authentication.lm.ADAuthenticator;
import com.adventnet.authentication.util.AuthUtil;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.delegation.TechnicianConstants;
import com.manageengine.ads.fw.delegation.TechnicianHandler;
import com.manageengine.ads.fw.domain.ADSDomainHandler;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.metracker.MeTrackerUtil;
import com.manageengine.rmp.util.GeneralUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import com.manageengine.rmp.util.SessionListener;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpSession;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author suganya-1815
 */
//ignoreI18n_start
public class RMPADAuthentication extends ADAuthenticator 
{
    public boolean authenticate() throws LoginException 
    {
        HttpSession session = this.request.getSession();
        String domainName = null;
        boolean result = false;
        String serverName = null;
        boolean isDefaultAdmin = false;
        try 
        {
            this.loginName = URLDecoder.decode(this.loginName, "utf-8");
            this.password = URLDecoder.decode(this.password, "utf-8");
            domainName = this.request.getParameter("domainName");
            if(domainName == null)
            {
                domainName = RMPAuthConstants.RMP_AUTHENTICATION;
            }
            int backSlashindex = this.loginName.lastIndexOf("\\");
            int atIndex = this.loginName.lastIndexOf("@");
            if (domainName.equals(RMPAuthConstants.RMP_AUTHENTICATION)&&backSlashindex==-1&&atIndex==-1) 
            {
                Row passwordRow = null,userStatusRow = null,accountStatusRow = null;
                try 
                {
                    this.accountDO = RMPAuthHandler.getAccountDO(this.loginName, this.serviceName, domainName);
                    RMPAuthHandler.isValidAccount(this.accountDO);
                    passwordRow = this.accountDO.getFirstRow(TableName.AAAPASSWORD);
                    userStatusRow = accountDO.getFirstRow(TableName.AAAUSERSTATUS);
                    accountStatusRow = accountDO.getFirstRow(TableName.AAAACCOUNTSTATUS);
                } 
                catch (DataAccessException dae) 
                {
                    throw new PAMException("rmp.login.common.error.dataaccess_exception", dae);
                }
                
                String userStatus = (String) userStatusRow.get("STATUS");
                if("DISABLED".equalsIgnoreCase(userStatus))
                {
                    throw new LoginException("rmp.login.common.error.user_disabled_in_rmp");
                }
                
                String accountStatus = (String) accountStatusRow.get("STATUS");
                if("DEACTIVATED".equals(accountStatus))
                {
                    throw new LoginException("rmp.login.common.error.user_accnt_disabled_in_rmp");
                }
                else if("LOCKED".equals(accountStatus))
                {
                    throw new LoginException("rmp.login.common.error.user_accnt_locked_in_rmp");
                }
                
                String passwordFromDb = (String) passwordRow.get("PASSWORD");
                String salt = (String) passwordRow.get("SALT");
                String algorithm = (String) passwordRow.get("ALGORITHM");
                if ((algorithm == null) || (!algorithm.equals("MD5"))) 
                {
                    throw new PAMException("rmp.login.common.error.unknown_algorithm");
                }
                String encPassword = AuthUtil.getEncryptedPassword(this.password, salt);
                result = passwordFromDb.equals(encPassword);
                if (!result) 
                {
                    throw new LoginException("rmp.login.common.error.invalid_login");
                }
                
                session.setAttribute(RMPAuthConstants.IS_DOMAIN_USER,false);
                if(this.loginName.equalsIgnoreCase("admin")) 
                {
                    isDefaultAdmin = true;
                }
            }
            else
            {
                if(backSlashindex != -1)
                {
                    domainName = this.loginName.substring(0,backSlashindex);
                    this.loginName = this.loginName.substring(backSlashindex + 1);
                    JSONObject domainDetails = ADSDomainHandler.getDomainDetails(domainName);
                    if(domainDetails.length()==0)
                    {
                        throw new LoginException("rmp.login.common.error.invalid_login");
                    }
                    List dcList = ADSDomainHandler.getDCList(domainName);
                    serverName = dcList.get(0).toString();
                    domainName = domainDetails.get("DOMAIN_NAME").toString(); 

                }
                else if(atIndex != -1)
                {
                    String upnDomain =  this.loginName.substring(atIndex+1);
                    Properties domainDetails = RMPDomainHandler.getDomainDetailsByName(upnDomain);
                    if(domainDetails==null)
                    {
                        domainDetails = RMPDomainHandler.getDomainDetailsByName(domainName);
                        if(domainDetails==null)
                        {
                            throw new LoginException("rmp.login.common.error.invalid_login");
                        }
                    }
                    else
                    {
                        domainName = upnDomain;
                    }
                    
                    ArrayList<Properties> loginUserProp = RMPAuthHandler.getLoginUserDetails(loginName,domainDetails);
                    if(!loginUserProp.isEmpty())
                    { 
                        this.loginName = GeneralUtil.getADProperty(loginUserProp.get(0), "sAMAccountName");
                    }
                    else
                    {
                        this.loginName = this.loginName.substring(0, atIndex);
                    }
                    List dcList = ADSDomainHandler.getDCList(domainName);
                    serverName = dcList.get(0).toString();
                    domainName = domainDetails.getProperty("DOMAIN_NAME");
                }
                else if(domainName != null && !domainName.equals(RMPAuthConstants.RMP_AUTHENTICATION))
                {
                    JSONObject domainDetails = ADSDomainHandler.getDomainDetails(domainName);
                    List dcList = ADSDomainHandler.getDCList(domainName);
                    serverName = dcList.get(0).toString();
                    domainName = domainDetails.get("DOMAIN_NAME").toString();
                }
                
                String status = RMPAuthHandler.authenticateUser(serverName,domainName,this.loginName,this.password,"false");
                if(!status.equalsIgnoreCase("success"))
                {
                    throw new LoginException(status);
                }
                
                try
                {
                    this.accountDO = RMPAuthHandler.getAccountDO(this.loginName, this.serviceName, domainName);
                    result = RMPAuthHandler.isValidAccount(this.accountDO);
                }
                catch (DataAccessException dae) 
                {
                    throw new PAMException("rmp.login.common.error.dataaccess_exception", dae);
                }
                session.setAttribute(RMPAuthConstants.IS_DOMAIN_USER,true);
            }
            
            Row loginRow = this.accountDO.getRow(TableName.AAALOGIN); // NO I18N
            String aaaLoginName = (String) loginRow.get(AAALOGIN.NAME);
            Long loginId = (Long) loginRow.get(TechnicianConstants.LOGIN_ID);
            if(TechnicianHandler.getDelegatedDomainRoles(loginId).length() == 0)
            {
                throw new LoginException("rmp.login.common.error.invalid_login");
            } 
            
            session.setAttribute(RMPAuthConstants.LOGIN_NAME, aaaLoginName);
            session.setAttribute("DOMAIN_NAME", domainName);
            session.setAttribute(TechnicianConstants.LOGIN_ID,loginId);
            setRoles(session,domainName,loginId);
            SessionListener.updateLoginIdMapping(loginId, session);
	    SessionListener.updateSessionMetadata(session.getId(), this.request, aaaLoginName);
	    
            Row accountRow = this.accountDO.getFirstRow(TableName.AAAACCOUNT);
            Long accountId = (Long) accountRow.get("ACCOUNT_ID");
            MeTrackerUtil.updateLoginTrackInfo(accountId, isDefaultAdmin);
        } 
        catch (LoginException loginException) 
        {
            session.setAttribute(RMPAuthConstants.LOGIN_NAME, this.loginName);
            session.setAttribute("DOMAIN_NAME", domainName);
            throw new LoginException(loginException.getMessage());
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        return result;
    }
    
    public void setRoles(HttpSession session,String domainName,Long loginId){
        try{
            JSONArray delegatedDomainRoles = TechnicianHandler.getDelegatedDomainRoles(loginId);
            List<Long> roleList = new ArrayList<Long>();
            Long loginDomainRole = new Long(0);
            if (delegatedDomainRoles.length() == 1 && delegatedDomainRoles.getJSONObject(0).get("DOMAIN_NAME").equals("ads.fw.delegation.all_domains")) {
                JSONObject allDomainsRole = new JSONObject();
                ArrayList<Properties> domains = RMPDomainHandler.getRMPDomainDetails();
                JSONObject domainRole = delegatedDomainRoles.getJSONObject(0);
                allDomainsRole.put(RMPAuthConstants.RMP_AUTHENTICATION, domainRole.getLong("ROLE_ID"));
                loginDomainRole = domainRole.getLong("ROLE_ID");
                for (int i = 0; i < domains.size(); i++) {
                    Properties domainDetails = domains.get(i);
                    allDomainsRole.put((String) domainDetails.get("DOMAIN_NAME"), domainRole.getLong("ROLE_ID"));
                    roleList.add(domainRole.getLong("ROLE_ID"));
                }
                session.setAttribute(RMPAuthConstants.IS_ALL_DOMAINS_DELEGATED, true);
                session.setAttribute(RMPAuthConstants.USER_ROLES, roleList);
                session.setAttribute(RMPAuthConstants.DOMAIN_VS_ROLES, allDomainsRole);
            } else {
                JSONObject domainVsRoles = new JSONObject();
                for (int i = 0; i < delegatedDomainRoles.length(); i++) {
                    JSONObject domainRole = delegatedDomainRoles.getJSONObject(i);
                    roleList.add((Long) domainRole.get("ROLE_ID"));
                    domainVsRoles.put(domainRole.get("DOMAIN_NAME").toString(), domainRole.getLong("ROLE_ID"));
                    if (domainName.equals(domainRole.get("DOMAIN_NAME").toString())) {
                        loginDomainRole = domainRole.getLong("ROLE_ID");
                    }
                }
                session.setAttribute(RMPAuthConstants.IS_ALL_DOMAINS_DELEGATED, false);
                session.setAttribute(RMPAuthConstants.USER_ROLES, roleList);
                session.setAttribute(RMPAuthConstants.DOMAIN_VS_ROLES, domainVsRoles);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
    }

}
//ignoreI18n_end
