/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.admin;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.admin.constants.OperationstatusMailnotification;
import com.manageengine.rmp.bmr.configure.BMRDatabase;
import com.manageengine.rmp.constants.NotificationSettingsType;
import com.manageengine.rmp.constants.OperationStatus;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.admin.constants.NotificationType;
import com.manageengine.rmp.common.LogWriter;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

import com.manageengine.rmp.dataobjects.OperationInfo;
import org.json.JSONArray;
import org.json.JSONObject;
import org.apache.commons.io.IOUtils;

import java.io.*;
/**
 *
 * @author aswathy-1909
 * $Id:$
 */
//ignoreI18n_start
public class NotificationAPI {
    public static void notifyAD(NotificationType notificationType,Object data)
    {
        LogWriter.general.info("API Called: NotificationAPI.notifyAD()");
        try {
            boolean hasEmptyMailID = false;
            OperationInfo operationInfo = (OperationInfo)data;
            boolean isSuccess;
            if(notificationType == NotificationType.ADBackup) {
                isSuccess = (operationInfo.status == OperationStatus.Completed) || (operationInfo.status == OperationStatus.Interrupted) || (operationInfo.status == OperationStatus.PartiallyCompleted);
            }
            else{
                isSuccess = operationInfo.status == OperationStatus.Completed;
            }
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_NOTIFICAITON_SETTINGS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_NOTIFICAITON_SETTINGS, "*"));
            Criteria criteria = getDefaultSelectCriteria(isSuccess);
            selectQuery.setCriteria(criteria);
            DataObject dataObj = CommonUtil.getPersistence().get(selectQuery);
            if(dataObj.isEmpty()){
                LogWriter.general.info(String.format("NotificationAPI.notifyAD : Notification not enabled for this operation: Notification Type-%d", notificationType.ordinal()));
                return;
            }
            if(!MailTemplate.isDomainEnabled(operationInfo.domainId)) {
                LogWriter.general.info(String.format("NotificationAPI.notifyBMR : Notification Type-%d Skipped for disabled domain", notificationType.ordinal()));
                return;
            }

            boolean isNotificationEnabled = false;
            String toMailIDs = "";
            Iterator rows = dataObj.getRows(TableName.RMP_NOTIFICAITON_SETTINGS);
            while(rows.hasNext()){
                boolean isDomainIDConfigured = false;
                Row row = (Row) rows.next();
                JSONObject jsonData = new JSONObject(String.valueOf(row.get("DATA")));
                JSONObject adData = jsonData.getJSONObject("AD");
                boolean isAllDomainsSelected = adData.has("isAllDomainsSelected") && adData.getBoolean("isAllDomainsSelected");
                if(isAllDomainsSelected) {
                    isDomainIDConfigured = true;
                }
                else {
                    JSONArray adDomains = adData.getJSONArray("domains");
                    for(int i = 0; i < adDomains.length(); i++){
                        if(adDomains.getLong(i) == operationInfo.domainId){
                            isDomainIDConfigured = true;
                            break;
                        }
                    }
                }
                if(!isDomainIDConfigured){
                    continue;
                }
                boolean isOperationConfigured = false;
                JSONArray operationsConfigured = adData.getJSONArray("OperationsToBeNotified");
                for(int i = 0; i < operationsConfigured.length(); i++){
                    if(operationsConfigured.getInt(i) == notificationType.ordinal()){
                        isOperationConfigured = true;
                        break;
                    }
                }
                if(!isOperationConfigured){
                    continue;
                }
                isNotificationEnabled = true;
                if(((String) row.get("MAIL_IDS")).equals("")) {
                    hasEmptyMailID = true;
                }
                else{
                    toMailIDs = toMailIDs + (String) row.get("MAIL_IDS") + ",";
                }
            }
            if(!toMailIDs.equals("")) {
                toMailIDs = toMailIDs.substring(0, toMailIDs.length() - 1);
            }

        	if(!isNotificationEnabled) {
        		LogWriter.general.info(String.format("NotificationAPI.notifyAD : Notification not enabled for this operation: Notification Type-%d", notificationType.ordinal()));
                return;
            }

            JSONObject notificationData = MailTemplate.getADMailerContent(notificationType, data, isSuccess);
            if(notificationData==null) {
                LogWriter.general.info("NotificationAPI.notify: Error getting mail template");
                return;
            }
            LogWriter.general.info(String.format("NotificationAPI.notifyAD : Notification Type: %d. Sending mail...", notificationType.ordinal()));
            String subject = String.valueOf(notificationData.get("SUBJECT"));
            String message = String.valueOf(notificationData.get("MESSAGE"));
            if(!toMailIDs.equals("")) {
                JSONObject resultObject = ServerSettings.sendBulkMail(subject, message, toMailIDs);
                if(resultObject.getBoolean("success")) {
                    LogWriter.general.info("NotificationAPI.notifyAD : Notification Type: Mail sent to " + toMailIDs);
                }
                else {
                    LogWriter.general.info("NotificationAPI.notifyAD: Sending mail failed");
                }
            }
            if(hasEmptyMailID) {
                JSONObject resultObject = ServerSettings.sendBulkMail(subject, message, null);
                if(resultObject.getBoolean("success")) {
                    LogWriter.general.info("NotificationAPI.notifyAD : Notification Type: Mail sent to admin");
                }
                else {
                    LogWriter.general.info("NotificationAPI.notifyAD: Sending mail failed");
                }
            }
        }
        catch (Exception e)
        {
            LogWriter.general.severe("NotificationAPI.notifyAD " + LogWriter.getStackTrace(e));
        }
    }

    public static void notifyVM(NotificationType notificationType, JSONObject data) {
        LogWriter.general.info("API Called: NotificationAPI.notifyVM()");
        try {
            boolean hasEmptyMailID = false;
            boolean isSuccess = data.getBoolean("status");
            long backupID = 0L;
            if(data.has("backupID")){
                backupID = data.getLong("backupID");
            }

            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_NOTIFICAITON_SETTINGS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_NOTIFICAITON_SETTINGS, "*"));
            Criteria criteria = getDefaultSelectCriteria(isSuccess);
            selectQuery.setCriteria(criteria);
            DataObject dataObj = CommonUtil.getPersistence().get(selectQuery);
            if(dataObj.isEmpty()){
                LogWriter.general.info(String.format("NotificationAPI.notifyVM : Notification not enabled for this operation: Notification Type-%d", notificationType.ordinal()));
                return;
            }

            boolean isNotificationEnabled = false;
            String toMailIDs = "";
            Iterator rows = dataObj.getRows(TableName.RMP_NOTIFICAITON_SETTINGS);
            while(rows.hasNext()){
                Row row = (Row) rows.next();
                JSONObject jsonData = new JSONObject(String.valueOf(row.get("DATA")));
                boolean isOperationConfigured = false;
                JSONObject vmData = null;
                switch (notificationType){
                    case VMWareBackup:
                    case VMWareRestore:
                        vmData = jsonData.getJSONObject("VMWare");
                        break;
                    case HyperVBackup:
                    case HyperVRestore:
                        vmData = jsonData.getJSONObject("HyperV");
                        break;
                }
                JSONArray operationsConfigured = vmData.getJSONArray("OperationsToBeNotified");
                for(int i = 0; i < operationsConfigured.length(); i++){
                    if(operationsConfigured.getInt(i) == notificationType.ordinal()){
                        isOperationConfigured = true;
                        break;
                    }
                }
                if(!isOperationConfigured){
                    continue;
                }
                switch (notificationType){
                    case VMWareRestore:
                    case HyperVRestore:
                        isNotificationEnabled = true;
                        break;
                    case VMWareBackup:
                    case HyperVBackup:
                        boolean isBackupConfigured = false;
                        boolean isAllBackupsSelected = vmData.has("isAllBackupsSelected") && vmData.getBoolean("isAllBackupsSelected");
                        if(isAllBackupsSelected) {
                            isBackupConfigured = true;
                        }
                        else {
                            JSONArray backups = vmData.getJSONArray("backups");
                            for(int i = 0; i < backups.length(); i++){
                                if(backups.getLong(i) == backupID){
                                    isBackupConfigured = true;
                                    break;
                                }
                            }
                        }
                        if(isBackupConfigured){
                            isNotificationEnabled = true;
                        }
                        break;
                }
                if(isNotificationEnabled){
                    if(((String) row.get("MAIL_IDS")).equals("")) {
                        hasEmptyMailID = true;
                    }
                    else{
                        toMailIDs = toMailIDs + (String) row.get("MAIL_IDS") + ",";
                    }
                }
            }
            if(!toMailIDs.equals("")) {
                toMailIDs = toMailIDs.substring(0, toMailIDs.length() - 1);
            }

            if(!isNotificationEnabled) {
                LogWriter.general.info(String.format("NotificationAPI.notifyVM : Notification not enabled for this operation: Notification Type-%d", notificationType.ordinal()));
                return;
            }

            JSONObject notificationData = MailTemplate.getVMMailerContent(notificationType, data, isSuccess);
            if(notificationData==null) {
                LogWriter.general.info("NotificationAPI.notify: Error getting mail template");
                return;
            }
            LogWriter.general.info(String.format("NotificationAPI.notifyVM : Notification Type: %d. Sending mail...", notificationType.ordinal()));
            String subject = String.valueOf(notificationData.get("SUBJECT"));
            String message = String.valueOf(notificationData.get("MESSAGE"));
            if(!toMailIDs.equals("")) {
                JSONObject resultObject = ServerSettings.sendBulkMail(subject, message, toMailIDs);
                if(resultObject.getBoolean("success")) {
                    LogWriter.general.info("NotificationAPI.notifyVM : Notification Type: Mail sent to " + toMailIDs);
                }
                else {
                    LogWriter.general.info("NotificationAPI.notifyVM: Sending mail failed");
                }
            }
            if(hasEmptyMailID) {
                JSONObject resultObject = ServerSettings.sendBulkMail(subject, message, null);
                if(resultObject.getBoolean("success")) {
                    LogWriter.general.info("NotificationAPI.notifyVM : Notification Type: Mail sent to admin");
                }
                else {
                    LogWriter.general.info("NotificationAPI.notifyVM: Sending mail failed");
                }
            }
        } catch (Exception e) {
            LogWriter.general.severe("NotificationAPI.notifyVM " + LogWriter.getStackTrace(e));
        }
    }

    public static void notifyBMR(NotificationType notificationType, JSONObject data) {
        LogWriter.general.info("API Called: NotificationAPI.notifyBMR()");
        try {
            boolean hasEmptyMailID = false;
            boolean isSuccess = data.getBoolean("status");
            long domainId = data.getLong("domainId");
            boolean isISOCreationConfigured = false;

            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_NOTIFICAITON_SETTINGS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_NOTIFICAITON_SETTINGS, "*"));
            Criteria criteria = getDefaultSelectCriteria(isSuccess);
            selectQuery.setCriteria(criteria);
            DataObject dataObj = CommonUtil.getPersistence().get(selectQuery);
            if(dataObj.isEmpty()){
                LogWriter.general.info(String.format("NotificationAPI.notifyBMR : Notification not enabled for this operation: Notification Type-%d", notificationType.ordinal()));
                return;
            }
            if(!MailTemplate.isDomainEnabled(domainId)) {
                LogWriter.general.info(String.format("NotificationAPI.notifyAD : Notification Type-%d Skipped for disabled domain", notificationType.ordinal()));
                return;
            }

            boolean isNotificationEnabled = false;
            String toMailIDs = "";
            Iterator rows = dataObj.getRows(TableName.RMP_NOTIFICAITON_SETTINGS);
            while(rows.hasNext()){
                boolean isDomainIDConfigured = false;
                Row row = (Row) rows.next();
                JSONObject jsonData = new JSONObject(String.valueOf(row.get("DATA")));
                JSONObject bmrData = jsonData.getJSONObject("BMR");
                boolean isAllDomainsSelected = bmrData.has("isAllDomainsSelected") && bmrData.getBoolean("isAllDomainsSelected");
                if(isAllDomainsSelected) {
                    isDomainIDConfigured = true;
                }
                else {
                    JSONArray bmrDomains = bmrData.getJSONArray("domains");
                    for(int i = 0; i < bmrDomains.length(); i++){
                        if(bmrDomains.getLong(i) == domainId){
                            isDomainIDConfigured = true;
                            break;
                        }
                    }
                }
                if(!isDomainIDConfigured){
                    continue;
                }
                boolean isOperationConfigured = false;
                JSONArray operationsConfigured = bmrData.getJSONArray("OperationsToBeNotified");
                for(int i = 0; i < operationsConfigured.length(); i++){
                    if(operationsConfigured.getInt(i) == NotificationType.BMRNewISOCreation.ordinal()) {
                        isISOCreationConfigured = true;
                    }
                    if(operationsConfigured.getInt(i) == notificationType.ordinal()){
                        isOperationConfigured = true;
                    }
                }
                if(!isOperationConfigured){
                    continue;
                }
                isNotificationEnabled = true;
                if(((String) row.get("MAIL_IDS")).equals("")) {
                    hasEmptyMailID = true;
                }
                else{
                    toMailIDs = toMailIDs + (String) row.get("MAIL_IDS") + ",";
                }
            }
            if(!toMailIDs.equals("")) {
                toMailIDs = toMailIDs.substring(0, toMailIDs.length() - 1);
            }

            if(!isNotificationEnabled) {
                LogWriter.general.info(String.format("NotificationAPI.notifyBMR : Notification not enabled for this operation: Notification Type-%d", notificationType.ordinal()));
                return;
            }

            JSONObject notificationData = MailTemplate.getBMRMailerContent(notificationType, isISOCreationConfigured, data);
            if(notificationData==null) {
                LogWriter.general.info("NotificationAPI.notify: Error getting mail template");
                return;
            }
            LogWriter.general.info(String.format("NotificationAPI.notify : Notification Type: %d. Sending mail...", notificationType.ordinal()));
            String subject = String.valueOf(notificationData.get("SUBJECT"));
            String message = String.valueOf(notificationData.get("MESSAGE"));
            if(!toMailIDs.equals("")) {
                JSONObject resultObject = ServerSettings.sendBulkMail(subject, message, toMailIDs);
                if(resultObject.getBoolean("success")) {
                    LogWriter.general.info("NotificationAPI.notifyBMR : Notification Type: Mail sent to " + toMailIDs);
                }
                else {
                    LogWriter.general.info("NotificationAPI.notifyBMR: Sending mail failed");
                }
            }
            if(hasEmptyMailID) {
                JSONObject resultObject = ServerSettings.sendBulkMail(subject, message, null);
                if(resultObject.getBoolean("success")) {
                    LogWriter.general.info("NotificationAPI.notifyBMR : Notification Type: Mail sent to admin");
                }
                else {
                    LogWriter.general.info("NotificationAPI.notifyBMR: Sending mail failed");
                }
            }
        } catch (Exception e) {
            LogWriter.general.severe("NotificationAPI.notifyBMR: " + LogWriter.getStackTrace(e));
        }
    }

    private static Criteria getDefaultSelectCriteria(boolean isSuccess) {
        LogWriter.general.info("API Called: NotificationAPI.getDefaultSelectCriteria()");
        try {
            // exclude scheduled notification rows
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_NOTIFICAITON_SETTINGS, "NOTIFICATION_TYPE"), NotificationSettingsType.Scheduled.ordinal(), QueryConstants.NOT_EQUAL);
            if(isSuccess){
                // exclude rows that is configured to notify only for failed operations
                criteria = criteria.and(new Criteria(Column.getColumn(TableName.RMP_NOTIFICAITON_SETTINGS, "NOTIFICATION_TYPE"), NotificationSettingsType.Failure.ordinal(), QueryConstants.NOT_EQUAL));
            }
            return criteria;
        } catch (Exception e) {
            LogWriter.general.severe("NotificationAPI.getDefaultSelectCriteria " + LogWriter.getStackTrace(e));
            return null;
        }
    }

    public static JSONObject getNotificationTemplate(int notifyType, OperationstatusMailnotification operationStatus) {
        LogWriter.general.info("API Called: NotificationAPI.getNotificationTemplate()");
        try {
            Criteria notificationDataType = new Criteria(Column.getColumn(TableName.RMP_NOTIFICATION_DATA, "NOTIFICATION_TYPE"), notifyType, QueryConstants.EQUAL);
            Criteria operationStatusCriteria = new Criteria(Column.getColumn(TableName.RMP_NOTIFICATION_DATA, "OPERATION_STATUS"), operationStatus.ordinal(), QueryConstants.EQUAL);
            DataObject obj = CommonUtil.getPersistence().get(TableName.RMP_NOTIFICATION_DATA,notificationDataType.and(operationStatusCriteria));
            Row row=obj.getFirstRow(TableName.RMP_NOTIFICATION_DATA);
            JSONObject notificationMessage = new JSONObject();

            ByteArrayInputStream tempByteInputStream;
            tempByteInputStream = (ByteArrayInputStream) row.get("MESSAGE");
            byte[] tempByte;
            tempByte = IOUtils.toByteArray(tempByteInputStream);
            String message = new String(tempByte, "UTF-8");
            notificationMessage.put("SUBJECT", String.valueOf(row.get("SUBJECT")));
            notificationMessage.put("MESSAGE",message);
            notificationMessage.put("NOTIFICATION_ID", (int)row.get("NOTIFICATION_ID"));
            return notificationMessage;
        } catch (Exception e) {
            LogWriter.general.severe("NotificationAPI.getNotificationTemplate " + LogWriter.getStackTrace(e));
            return null;
        }
    }

    public static void notifyScheduled(Long notificationID){
        LogWriter.general.info("API Called: NotificationAPI.notifyScheduled()");
        try{
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_NOTIFICAITON_SETTINGS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_NOTIFICAITON_SETTINGS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_NOTIFICAITON_SETTINGS, "UNIQUE_ID"), notificationID, QueryConstants.EQUAL);
            selectQuery.setCriteria(criteria);
            DataObject dataObj = CommonUtil.getPersistence().get(selectQuery);
            if(dataObj.isEmpty()) {
                LogWriter.general.info("NotificationAPI.notifyScheduled: Error getting schedule details");
                return;
            }
            Iterator rows = dataObj.getRows(TableName.RMP_NOTIFICAITON_SETTINGS);
            if(rows.hasNext()){
                Row row = (Row) rows.next();
                String toMailIDs = (String) row.get("MAIL_IDS");
                JSONObject jsonData = new JSONObject(String.valueOf(row.get("DATA")));

                Date toDate = Calendar.getInstance().getTime();
                Date fromDate = Calendar.getInstance().getTime();
                long scheduleID = (long) row.get("SCHEDULE_ID");
                Row scheuleInfoRow = BMRDatabase.getScheduleDetails(scheduleID);
                if (scheuleInfoRow != null) {
                    String repeatFrequency = (String) scheuleInfoRow.get("REPEAT_FREQUENCY");
                    if(repeatFrequency.equalsIgnoreCase("monthly")) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.add(Calendar.MONTH, -1);
                        fromDate = calendar.getTime();
                    }
                    else if(repeatFrequency.equalsIgnoreCase("weekly")) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.add(Calendar.WEEK_OF_MONTH, -1);
                        fromDate = calendar.getTime();
                    }
                    else if(repeatFrequency.equalsIgnoreCase("daily")) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.add(Calendar.DAY_OF_WEEK, -1);
                        fromDate = calendar.getTime();
                    }
                }
                else{
                    LogWriter.general.info("NotificationAPI.notifyScheduled: Error setting fromDate");
                    return;
                }

                JSONObject notificationData = MailTemplate.getScheduledMailerContent(jsonData, fromDate, toDate);
                if(notificationData==null) {
                    LogWriter.general.info("NotificationAPI.notify: Error getting mail template");
                    return;
                }
                LogWriter.general.info("NotificationAPI.notifyScheduled : Sending scheduled mail...");
                String subject = String.valueOf(notificationData.get("SUBJECT"));
                String message = String.valueOf(notificationData.get("MESSAGE"));
                JSONObject resultObject = ServerSettings.sendBulkMail(subject, message, (toMailIDs.equals(""))?null:toMailIDs);
                if(resultObject.getBoolean("success")) {
                    LogWriter.general.info("NotificationAPI.notifyScheduled: Scheduled mail sent to " + ((toMailIDs.equals(""))?"admin":toMailIDs));
                }
                else {
                    LogWriter.general.info("NotificationAPI.notifyScheduled: Sending mail failed");
                }
            }
        } catch (Exception e){
            LogWriter.general.severe("NotificationAPI.notifyScheduled " + LogWriter.getStackTrace(e));
        }
    }

}
//ignoreI18n_end
