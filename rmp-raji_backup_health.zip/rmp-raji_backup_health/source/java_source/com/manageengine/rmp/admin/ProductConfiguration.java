/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.admin;

import com.manageengine.rmp.util.RMPXMLHandler;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.metracker.MeTrackerUtil;
import com.manageengine.ads.fw.util.XMLHandler;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.ServerSocket;
import javax.servlet.http.HttpServlet;

/**
 * $Id$
 * @author aswathy-1909
 */
public class ProductConfiguration extends HttpServlet{
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try {
            if(request.getPathInfo().equals("/GET")) {
                getProductSettings(response);
            }
            else if(request.getPathInfo().equals("/SAVE")) {
                saveProductSettings(request, response);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            LogWriter.general.severe("ProductConfiguration.doGet " + e ); // No I18N
        }
    }
    
    private void getProductSettings(HttpServletResponse response)
    {
        try {
            Boolean isMeTrackerEnabled = MeTrackerUtil.getMeTrackerStatus();
            JSONObject productSettings = new JSONObject();
            if(isMeTrackerEnabled != null) { 
                productSettings.put("isMeTrackerEnabled",isMeTrackerEnabled); // No I18N
            }
            JSONObject productSettingsServerXml=new XMLHandler("server.xml").getConnectionSettings(); //No I18N
            productSettings.put("port", productSettingsServerXml.get("HTTP"));
            productSettings.put("httpsPort", productSettingsServerXml.get("HTTPS"));
            productSettings.put("SSL", productSettingsServerXml.get("SSL"));
            productSettings.put("sessionTimeout", getSessionTimeout());
            response.getWriter().print(productSettings.toString()); 
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.severe("ProductConfiguration.getProductSettings " + e.getStackTrace()); // No I18N
        }
    }
    
    public String getSessionTimeout() {
    	try {
            RMPXMLHandler xMLHandler = new RMPXMLHandler("..\\conf\\web.xml");  // No I18N
            return xMLHandler.getSessionTimeOut(); 
    	}
    	catch (Exception exp) {
            exp.printStackTrace();
            LogWriter.general.severe("Error in getSessionTimeout "+exp);
        }
    	return null;
    }
    
    public static void saveProductSettings(HttpServletRequest request, HttpServletResponse response) throws IOException, JSONException {
        JSONObject result = new JSONObject();   
        try {
            boolean isSuccess = true, portCheck = true;
            JSONObject obj = new JSONObject(request.getParameter("req"));
            if(obj.has("checkHttpPortNo")) 
            {
            	JSONObject productSettingsServerXml=new XMLHandler("server.xml").getConnectionSettings(); //No I18N
            	int httpCurrent = Integer.parseInt((String)productSettingsServerXml.get("HTTP"));
            	String httpsString = (String)productSettingsServerXml.get("HTTPS");
            	int httpsCurrent = httpsString.equals("NOT_SET") ? -1 : Integer.parseInt(httpsString);
            	if(obj.getBoolean("checkHttpPortNo")) 
                {
            		int httpNew = Integer.parseInt(request.getParameter("HTTP"));
                	if(!(httpNew==httpCurrent || httpNew==httpsCurrent)) 
                        {
                		if(!checkPortAvailability(httpNew)) {
                			portCheck = false;
                			result.put("portError", 2);
                		}
                	}
                }
                if(obj.getBoolean("checkHttpsPortNo"))
                {
                	int httpsNew = Integer.parseInt(request.getParameter("HTTPS"));
                	if(!(httpsNew == httpCurrent || httpsNew == httpsCurrent)) 
                        {
                		if(!checkPortAvailability(httpsNew)) {
                			portCheck = false;
                			result.put("portError", 3);
                		}
                	}
                }
            }
            
            if(portCheck) {
            	if(obj.has("isMeTrackerEnabled")) 
                {
                	Boolean enableMeTrackResult = MeTrackerUtil.enableMeTracker(obj.getBoolean("isMeTrackerEnabled")); // No I18N
                }
                if(obj.has("https")) 
                {
                	XMLHandler serverHandler = new XMLHandler("server.xml"); //NO I18N
                        serverHandler.updateConnectionSettings(request); 
                	new XMLHandler("..\\webapps\\admp_rmp\\WEB-INF\\web.xml").updateConfidential(request);  //NO I18N
                	if(obj.getBoolean("https"))
                        {
                		serverHandler.updateConnectionSettings("name", "SSL", "maxHttpHeaderSize", "65535"); // No I18N
                                serverHandler.writeToFile();
                	}
                }
                if(obj.has("sessionTimeout")) 
                {
                        String expiryTime = (String) request.getParameter("SESSION_EXPIRY_TIME");
                	new RMPXMLHandler("..\\conf\\web.xml").setSessionTimeOut(expiryTime); //No I18N
                	request.getSession().setMaxInactiveInterval(60*Integer.parseInt(expiryTime));
                }
            }
            result.put("success", isSuccess&&portCheck);
            response.getWriter().print(result.toString());  
        } catch (Exception e) {
            result.put("success",false);
            response.getWriter().print(result.toString());  
            e.printStackTrace();
            LogWriter.general.severe("ServerSettings.saveProductSettings " + e); // No I18N
        }
    }
    
    
     public static boolean checkPortAvailability(int portNum)
    {
        if (portNum < 0){
            return false;
        }
        try{
            ServerSocket sock = new ServerSocket(portNum);
            sock.close();
            return true;
	}catch(Exception ex){
            return false;
        }
    }      
}
