/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.admin.authentication;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.persistence.DataObject;
import com.manageengine.ads.fw.delegation.role.RoleConstants;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.common.LogWriter;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author poornima-3055
 */
public class ADSAuthHandler {
    
    public static DataObject getActionsDO(){
        try {
            SelectQuery selectQuery = getActionsSelectQuery();
            return CommonUtil.getCachedPersistence().get(selectQuery);
        } catch(Exception e) {
            LogWriter.general.info("Exception at ADSHandler.getActionsDO :" + e.getMessage());   // No I18N
        }
        return null;
    }
    
    
    
    public static DataObject getAuthorizedActionsDO(List<Long> rolesList){
        try {
            Long[] roles = new Long[rolesList.size()];
            rolesList.toArray(roles);
            SelectQuery selectQuery = getActionsSelectQuery();
            Join join = new Join(RoleConstants.ADS_ACTIONS, RoleConstants.ADS_ROLE_VS_ACTIONS, new String[]{"ACTION_ID"}, new String[]{"ACTION_ID"}, Join.LEFT_JOIN);
            selectQuery.addJoin(join);
            Criteria rolesCriteria = new Criteria(Column.getColumn(RoleConstants.ADS_ROLE_VS_ACTIONS, "ROLE_ID"), roles, QueryConstants.IN);
            selectQuery.setCriteria(rolesCriteria);
            return CommonUtil.getCachedPersistence().get(selectQuery);
        } catch(Exception e) {
            LogWriter.general.info("Exception at ADSHandler.getAuthorizedActionsDO :" + e.getMessage());   // No I18N
        }
        return null;
    }
    
    public static SelectQuery getActionsSelectQuery(){
        SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(RoleConstants.ADS_ACTIONS));
        selectQuery.addSelectColumn(Column.getColumn(RoleConstants.ADS_ACTIONS, "ACTION_ID"));
        selectQuery.addSelectColumn(Column.getColumn(RoleConstants.ADS_ACTIONS, "ACTION_URL"));
        selectQuery.addSelectColumn(Column.getColumn(RoleConstants.ADS_ACTIONS, "ACTION_TYPE_ID"));
        SortColumn parentIdSort = new SortColumn(Column.getColumn(RoleConstants.ADS_ACTIONS, "PARENT_ACTION_ID"), true); // No I18N
        List sortColumns = new ArrayList();
        sortColumns.add(parentIdSort);
        selectQuery.addSortColumns(sortColumns);
        return selectQuery;
    }
    
    public static DataObject getRoleVsActionsDO(){
        try {
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(RoleConstants.ADS_ROLE_VS_ACTIONS));
            selectQuery.addSelectColumn(Column.getColumn(RoleConstants.ADS_ROLE_VS_ACTIONS, "*"));
            return CommonUtil.getCachedPersistence().get(selectQuery);
        } catch(Exception e) {
            LogWriter.general.info("Exception at Authorization.getRoleVsActionsDO :" + e.getMessage()); // No I18N
        }
        return null;
    }
       
}
