package com.manageengine.rmp.admin;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.i18n.ADSResourceBundle;
import com.manageengine.ads.fw.i18n.I18NUtil;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.DateUtil;
import com.manageengine.me.util.JSONArrayUtil;
import com.manageengine.rmp.admin.constants.NotificationType;
import com.manageengine.rmp.admin.constants.OperationstatusMailnotification;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.i18n.Rmpi18n;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.virtual.VirtualConstants;
import com.manageengine.rmp.virtual.VirtualMachineUtil;
import com.manageengine.rmp.virtual.backup.VirtualBackupServerUtil;
import com.manageengine.rmp.virtual.repository.VMRepositoryServer;
import com.manageengine.rmp.virtual.restore.VirtualRestoreServerUtil;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

//ignoreI18n_start
public class MailInfoVM {
    public static JSONObject setVMBackupMailInfo(Long backupId, OperationstatusMailnotification successStatus, int virtualEnvironment) throws JSONException {
        LogWriter.general.info("API called: MailInfoVM.setVMBackupMailInfo()");
        try {
            boolean isSuccess = (successStatus == OperationstatusMailnotification.Success);
            boolean allVMsFailed = true;
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            JSONObject mailData = new JSONObject();
            mailData.put("status", isSuccess);
            mailData.put("backupID", backupId);
            Criteria cri = new Criteria(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_SCHEDULE, "BACKUP_ID"), backupId, QueryConstants.EQUAL);
            DataObject dataObject = CommonUtil.getPersistence().get(TableName.RMP_VIRTUAL_BACKUP_SCHEDULE, cri);
            Long repoId = null;
            Row backupScheduleRow = dataObject.getFirstRow(TableName.RMP_VIRTUAL_BACKUP_SCHEDULE);
            JSONObject generalInfo = new JSONObject();
            if (backupScheduleRow != null) {
                generalInfo.put("%SCHEDULE_NAME%", backupScheduleRow.get("BACKUP_SCHEDULE_NAME"));
                Object backupTime = backupScheduleRow.get("LAST_RUN_TIME");
                if (backupTime != null) {
                    backupTime = MailTemplate.getMailDateFormat().format(((Timestamp) backupTime).getTime());
                }
                generalInfo.put("%START_TIME%", backupTime);
                String message = "";
                String operation = resBundle.getString("rmp.notification.operations.Backup");
                if (isSuccess) {
                    generalInfo.put("%STATUS%", "Success");
                    message = operation + " " + resBundle.getString("rmp.mail.common.operation_completed");
                } else {
                    generalInfo.put("%STATUS%", "Failed");
                    message = operation + " " + resBundle.getString("rmp.mail.common.operation_failed");
                }
                message += " " + resBundle.getString("rmp.mail.common.please_find_info_below");
                generalInfo.put("%MESSAGE%", message);
                generalInfo.put("%OPERATION%", operation);
                repoId = (Long) backupScheduleRow.get("REPOSITORY_ID");
            }
            JSONObject repoDetails = VMRepositoryServer.getBackupRepository(repoId).getJSONObject("selectedValue");
            //for repository details of backup {repository_name,repository_path}
            JSONObject repoInfo = new JSONObject();
            String repoName = repoDetails.get("REPOSITORY_NAME").toString();
            String repoPath = repoDetails.get("REPOSITORY_PATH").toString();
            repoInfo.put("%REPOSITORY_NAME%", repoName);
            repoInfo.put("%REPOSITORY_PATH%", repoPath);
            mailData.put("repoInfo", repoInfo);
            //for vmdetails
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_OPERATION, "BACKUP_ID"), backupId, QueryConstants.EQUAL);
            DataObject dataObj = CommonUtil.getPersistence().get(TableName.RMP_VIRTUAL_BACKUP_OPERATION, criteria);

            dataObj.sortRows(TableName.RMP_VIRTUAL_BACKUP_OPERATION, new SortColumn(TableName.RMP_VIRTUAL_BACKUP_OPERATION, "BACKUP_IDENTIFIER", false));// No I18N
            Row backupRow = dataObj.getFirstRow(TableName.RMP_VIRTUAL_BACKUP_OPERATION);

            if (backupRow != null) {
                String initiator = (String) backupRow.get("INITIATOR");
                generalInfo.put("%INITIATED_BY%", initiator);
                long backupIdentifier = (long) backupRow.get("BACKUP_IDENTIFIER");// No I18N
                long backupDuration = (long) backupRow.get("BACKUP_DURATION");// No I18N
                if (successStatus == OperationstatusMailnotification.Interrupted) {
                    generalInfo.put("%TIME_TAKEN%", "-");
                }
                else {
                    generalInfo.put("%TIME_TAKEN%", DateUtil.millisecondsToTime(backupDuration * 1000));
                }
                mailData.put("generalInfo", generalInfo);
                //vm details
                JSONArray vmInfo = new JSONArray();
                JSONObject vmDetails = new JSONObject();
                Criteria cri1 = new Criteria(new Column(TableName.RMP_VM_BACKEDUP_DETAILS, "BACKUP_IDENTIFIER"), backupIdentifier, QueryConstants.EQUAL);
                DataObject dataObj1 = CommonUtil.getPersistence().get(TableName.RMP_VM_BACKEDUP_DETAILS, cri1);
                if(!dataObj1.isEmpty()) {
                    Iterator rowIterator = dataObj1.getRows(TableName.RMP_VM_BACKEDUP_DETAILS);
                    //for virtual machines details of backup [success - {VM_NAME,BACKUP_TYPE,BACKUP_SIZE}/failure - {VM_NAME,REASON}]
                    //for success
                    while (rowIterator.hasNext()) {
                        Row row = (Row) rowIterator.next();
                        vmDetails = new JSONObject();
                        vmDetails.put("%VM_NAME%", getVMName((Long) row.get("VM_ID"), (virtualEnvironment == VirtualConstants.HYPERV)?"Hyper-V":"VMware"));
                        vmDetails.put("%BACKUP_TYPE%", getBackupTypeString((String) row.get("BACKUP_TYPE")));
                        vmDetails.put("%BACKUP_SIZE%", getBackupSize((Long) row.get("BACKUP_SIZE")));
                        vmInfo.put(vmDetails);
                        allVMsFailed = false;
                    }
                }
                if(!isSuccess) {
                    //for failure
                    boolean isFailureMessageAvailable = false;
                    JSONArray backupSteps = VirtualBackupServerUtil.getBackupScheduleSteps(backupIdentifier);
                    ArrayList<Long> failedVMs = new ArrayList<Long>();
                    for (int i = 0; i < backupSteps.length(); i++) {
                        JSONObject backupstep = backupSteps.getJSONObject(i);
                        if (Integer.parseInt(backupstep.get("status").toString()) == 0) {
                            if (Long.parseLong(backupstep.get("vmId").toString()) == 0) { // failure before vm-specific step - could be failure on connect to repository or failure in host-specific step
                                vmDetails = new JSONObject();
                                vmDetails.put("Error", backupstep.get("message").toString());
                                vmDetails.put("%VM_NAME%", getVMName(null, (virtualEnvironment == VirtualConstants.HYPERV)?"Hyper-V":"VMware"));
                                vmDetails.put("%REASON%", backupstep.get("message").toString());
                                vmInfo.put(vmDetails);
                                isFailureMessageAvailable = true;
                            } else if(!failedVMs.contains(Long.parseLong(backupstep.get("vmId").toString()))){
                                vmDetails = new JSONObject();
                                vmDetails.put("%VM_NAME%", getVMName(Long.parseLong(backupstep.get("vmId").toString()), (virtualEnvironment == VirtualConstants.HYPERV)?"Hyper-V":"VMware"));
                                vmDetails.put("%REASON%", backupstep.get("message").toString());
                                vmInfo.put(vmDetails);
                                failedVMs.add(Long.parseLong(backupstep.get("vmId").toString()));
                                isFailureMessageAvailable = true;
                            }
                        }
                    }
                    if(!isFailureMessageAvailable) {
                        vmDetails = new JSONObject();
                        vmDetails.put("Error", "Backup failed due to an unexpected error.");
                        vmDetails.put("%VM_NAME%", getVMName(null, (virtualEnvironment == VirtualConstants.HYPERV)?"Hyper-V":"VMware"));
                        vmDetails.put("%REASON%", "Backup failed due to an unexpected error.");
                        vmInfo.put(vmDetails);
                    }
                }
                mailData.put("vmInfo", vmInfo);
            }
            if (!isSuccess) {
                //for trouble shooting tips
                JSONObject troubleShoot = new JSONObject();
                troubleShoot.put("%TIPS_TROUBLESHOOT%", resBundle.getString("rmp.mail.VM.troubleshoot.default"));
                mailData.put("troubleShoot", troubleShoot);
            }
            mailData.put("allVMsFailed", allVMsFailed);
            return mailData;
        } catch (Exception e) {
            LogWriter.general.severe("MailInfoVM.setVMBackupMailInfo " + LogWriter.getStackTrace(e)); // No I18N
            return null;
        }
    }

    public static JSONObject setVMRestoreMailInfo(Long restoreIdentifier, OperationstatusMailnotification successStatus, int virtualEnvironment){
        LogWriter.general.info("API called: MailInfoVM.setVMRestoreMailInfo()");
        JSONObject mailData = new JSONObject();
        try {
            boolean isSuccess = (successStatus == OperationstatusMailnotification.Success);
            boolean allVMsFailed = true;
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            mailData.put("status", isSuccess);
            mailData.put("virtualEnvironment", virtualEnvironment);
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_VM_RESTORE, "RESTORE_IDENTIFIER"), restoreIdentifier, QueryConstants.EQUAL);
            JSONArray restoreArray = VirtualRestoreServerUtil.getAllRestoreDetails(1, 0, criteria, null).getJSONArray("restoreList");
            JSONObject restoreJSON = restoreArray.getJSONObject(0);

            JSONObject generalInfo = new JSONObject();
            JSONObject restoreInfo = new JSONObject();
            generalInfo.put("%INITIATED_BY%", restoreJSON.getString("INITIATOR"));
            SimpleDateFormat oldFormat = new SimpleDateFormat("MMM-dd-yyyy HH:mm:ss");
            generalInfo.put("%START_TIME%", MailTemplate.getMailDateFormat().format(oldFormat.parse(restoreJSON.getString("RESTORE_DURATION"))));
            generalInfo.put("%STATUS%", restoreJSON.getString("RESTORE_STATUS"));
            generalInfo.put("%RESTORE_LABEL%", restoreJSON.getString("RESTORE_LABEL"));
            if (successStatus == OperationstatusMailnotification.Interrupted) {
                generalInfo.put("%TIME_TAKEN%", "-");
            }
            else {
                generalInfo.put("%TIME_TAKEN%", DateUtil.millisecondsToTime(getRestoreDuration(restoreIdentifier)));
            }
            int restoreType = restoreJSON.getInt("RESTORE_TYPE_INT");
            mailData.put("restoreType", restoreType);
            restoreInfo.put("%RESTORE_TYPE%", virtualEnvironment == VirtualConstants.VMWARE ?
                    getVmwareRestoreType(restoreType) : getHypervRestoreType(restoreType));
            restoreInfo.put("%DESTINATION_HOST%", restoreJSON.getString("DESTINATION"));
            restoreInfo.put("%COUNT%", restoreJSON.getInt("NO_OF_VMS"));
            String message = "";
            String operation = resBundle.getString("rmp.notification.operations.Restore");
            if (isSuccess) {
                generalInfo.put("%STATUS%", "Success");
                message = operation + " " + resBundle.getString("rmp.mail.common.operation_completed");
            } else {
                generalInfo.put("%STATUS%", "Failed");
                message = operation + " " + resBundle.getString("rmp.mail.common.operation_failed");
            }
            message += " " + resBundle.getString("rmp.mail.common.please_find_info_below");
            generalInfo.put("%MESSAGE%", message);
            generalInfo.put("%OPERATION%", operation);

            mailData.put("generalInfo", generalInfo);

            JSONArray vmInfo = new JSONArray();
            JSONArray fileInfo = new JSONArray();
            if(restoreType == VirtualConstants.FILE_LEVEL_RESTORE) {
                JSONObject flrRestoreDetails = VirtualRestoreServerUtil.getFLRDetails(restoreIdentifier);
                restoreInfo.put("%RESTORE_POINT_FLR%", MailTemplate.getMailDateFormat().format(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(flrRestoreDetails.getString("restorePoint"))));
                restoreInfo.put("%VM_NAME_FLR%", flrRestoreDetails.getString("vmName"));
                restoreInfo.put("%HOST_NAME_FLR%", flrRestoreDetails.isNull("HOST_NAME") ? "" : flrRestoreDetails.getString("HOST_NAME"));
                if(!isSuccess) {
                    // for common failure message
                    JSONObject vmDetails = new JSONObject();
                    String commonErrorMessage = VirtualRestoreServerUtil.getCommonRestoreFailureErrorMessage(restoreIdentifier);
                    vmDetails.put("Error", commonErrorMessage);
                    vmInfo.put(vmDetails);
                }
            }
            else {
                JSONArray vmArray = VirtualRestoreServerUtil.getRestoredVmList(restoreIdentifier).getJSONArray("vmDetails");
                JSONObject vmDetails;
                ArrayList<Long> failedVMs = new ArrayList<>();
                ArrayList<String> failedVMsReason = new ArrayList<>();
                if(!isSuccess) {
                    Hashtable<String, ArrayList> failedVMDetails = VirtualRestoreServerUtil.getFailedVMs(restoreIdentifier);
                    failedVMs = failedVMDetails.get("failedVMs");
                    failedVMsReason = failedVMDetails.get("failureReason");
                }
                for(int i = 0; i < vmArray.length(); i++) {
                    if(!failedVMs.contains(vmArray.getJSONObject(i).getLong("vmid"))) {
                        // for success
                        vmDetails = new JSONObject();
                        vmDetails.put("%VM_NAME%", vmArray.getJSONObject(i).getString("nameOfVm"));
                        String restorePoint;
                        try {
                            restorePoint = MailTemplate.getMailDateFormat().format(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(vmArray.getJSONObject(i).getString("resPointofVM")));
                        } catch (ParseException e) {
                            LogWriter.general.severe("MailInfoVM.setVMRestoreMailInfo : Unparseable restore Point - " + vmArray.getJSONObject(i).getString("resPointofVM"));
                            restorePoint = "-";
                        }
                        vmDetails.put("%RESTORE_POINT%", restorePoint);
                        vmDetails.put("%LOCATION%", vmArray.getJSONObject(i).getString("locationOfVM"));
                        vmInfo.put(vmDetails);
                        allVMsFailed = false;
                    }
                }
                // for failure
                for (int i = 0; i < failedVMs.size(); i++) {
                    vmDetails = new JSONObject();
                    vmDetails.put("%VM_NAME%", getVMName(failedVMs.get(i), (virtualEnvironment == VirtualConstants.HYPERV)?"Hyper-V":"VMware"));
                    vmDetails.put("%REASON%", failedVMsReason.get(i));
                    vmInfo.put(vmDetails);
                }
                // for common failure message
                if(!isSuccess && failedVMs.size() == 0) {
                    vmDetails = new JSONObject();
                    String commonErrorMessage = VirtualRestoreServerUtil.getCommonRestoreFailureErrorMessage(restoreIdentifier);
                    vmDetails.put("Error", commonErrorMessage);
                    vmDetails.put("%VM_NAME%", (virtualEnvironment == VirtualConstants.HYPERV)?"Hyper-V":"VMware");
                    vmDetails.put("%REASON%", commonErrorMessage);
                    vmInfo.put(vmDetails);
                }
            }
            if (!isSuccess) {
                //for trouble shooting tips
                JSONObject troubleShoot = new JSONObject();
                troubleShoot.put("%TIPS_TROUBLESHOOT%", resBundle.getString("rmp.mail.VM.troubleshoot.default"));
                mailData.put("troubleShoot", troubleShoot);
            }
            mailData.put("restoreInfo", restoreInfo);
            mailData.put("vmInfo", vmInfo);
            mailData.put("fileInfo", fileInfo);
            mailData.put("allVMsFailed", allVMsFailed);
            mailData.put("isLiveMigration", (virtualEnvironment == VirtualConstants.HYPERV && restoreType == VirtualConstants.HV_LIVE_MIGRATE) ||
                    (virtualEnvironment == VirtualConstants.VMWARE && restoreType == VirtualConstants.LIVE_MIGRATE));
        } catch (Exception e) {
            LogWriter.general.severe("MailInfoVM.setVMRestoreMailInfo : " + LogWriter.getStackTrace(e)); // No I18N
        }
        return mailData;
    }

    public static JSONArray setVMScheduledMailInfo(boolean isAllBackupsSelected, JSONArray backups, JSONArray vmOperationsConfigured, int virtualEnvironment, java.util.Date fromDate, java.util.Date toDate) {
        LogWriter.general.info("API called: MailInfoVM.setVMScheduledMailInfo()");
        JSONArray vmMailData = new JSONArray();
        try {
            ArrayList<Integer> operationsConfigured = JSONArrayUtil.toArrayList(vmOperationsConfigured);

            Hashtable<Long, String> hostName = new Hashtable<>();

            // backup
            Hashtable<Long, Integer> backupDetailsSuccess = new Hashtable<>();
            Hashtable<Long, Integer> backupDetailsFailure = new Hashtable<>();
            Hashtable<Long, Integer> backupDetailsTotal = new Hashtable<>();
            if(operationsConfigured.contains(NotificationType.HyperVBackup.ordinal()) || operationsConfigured.contains(NotificationType.VMWareBackup.ordinal())) {
                SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_VIRTUAL_BACKUP_OPERATION));
                selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_OPERATION, "BACKUP_IDENTIFIER"));
                selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_OPERATION, "BACKUP_STATUS"));
                selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_OPERATION, "BACKUP_ID"));
                Criteria fromDateCriteria = new Criteria(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_OPERATION, "BACKUP_TIME"), (new java.sql.Timestamp(fromDate.getTime())), QueryConstants.GREATER_THAN);
                Criteria toDateCriteria = new Criteria(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_OPERATION, "BACKUP_TIME"), (new java.sql.Timestamp(toDate.getTime())), QueryConstants.LESS_THAN);
                if (isAllBackupsSelected) {
                    selectQuery.setCriteria(fromDateCriteria.and(toDateCriteria));
                }
                else {
                    Criteria backupIDCriteria = new Criteria(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_OPERATION, "BACKUP_ID"), JSONArrayUtil.toLongArray(backups), QueryConstants.IN);
                    selectQuery.setCriteria(backupIDCriteria.and(fromDateCriteria).and(toDateCriteria));
                }
                DataObject dataObj = CommonUtil.getPersistence().get(selectQuery);
                Iterator rows = dataObj.getRows(TableName.RMP_VIRTUAL_BACKUP_OPERATION);
                while (rows.hasNext()) {
                    Row row = (Row) rows.next();
                    long backupIdentifier = (long) row.get("BACKUP_IDENTIFIER");
                    long backupId = (long) row.get("BACKUP_ID");
                    if(VirtualMachineUtil.getvirtualEnvironmentfrombackupId(backupId) != virtualEnvironment) {
                        continue;
                    }
                    String status = (String) row.get("BACKUP_STATUS");
                    if(!status.equalsIgnoreCase("completed") && !status.equalsIgnoreCase("failed") && !status.equalsIgnoreCase("Interrupted")) {
                        continue;
                    }
                    SelectQuery selectQuery1 = new SelectQueryImpl(Table.getTable(TableName.RMP_VIRTUAL_BACKUP_OPERATION));
                    Join join = new Join(TableName.RMP_VIRTUAL_BACKUP_OPERATION, TableName.RMP_VM_BACKEDUP_DETAILS, new String[] {"BACKUP_IDENTIFIER"}, new String[] {"BACKUP_IDENTIFIER"}, Join.LEFT_JOIN);
                    Join join1 = new Join(TableName.RMP_VM_BACKEDUP_DETAILS, TableName.RMP_VM_DETAILS, new String[] {"VM_ID"}, new String[] {"VM_ID"}, Join.LEFT_JOIN);
                    Join join2 = new Join(TableName.RMP_VM_DETAILS, TableName.RMP_VSPHERE_DETAILS, new String[] {"VSPHERE_HOST_ID"}, new String[] {"VSPHERE_HOST_ID"}, Join.LEFT_JOIN);
                    selectQuery1.addSelectColumn(Column.getColumn(TableName.RMP_VSPHERE_DETAILS, "VSPHERE_HOST_ID"));
                    selectQuery1.addSelectColumn(Column.getColumn(TableName.RMP_VSPHERE_DETAILS, "HOST_NAME"));
                    selectQuery1.addSelectColumn(Column.getColumn(TableName.RMP_VM_BACKEDUP_DETAILS, "BACKUP_VM_IDENTIFIER"));
                    selectQuery1.addSelectColumn(Column.getColumn(TableName.RMP_VM_DETAILS, "VM_ID"));
                    selectQuery1.addSelectColumn(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_OPERATION, "BACKUP_IDENTIFIER"));
                    selectQuery1.addJoin(join);
                    selectQuery1.addJoin(join1);
                    selectQuery1.addJoin(join2);
                    Criteria backupIdentifierCriteria = new Criteria(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_OPERATION, "BACKUP_IDENTIFIER"), backupIdentifier, QueryConstants.EQUAL);
                    Criteria virtualEnvironmentCriteria = new Criteria(Column.getColumn(TableName.RMP_VM_DETAILS, "VIRTUAL_ENVIRONMENT"), virtualEnvironment, QueryConstants.EQUAL);
                    selectQuery1.setCriteria(backupIdentifierCriteria.and(virtualEnvironmentCriteria));
                    DataObject dataObject = CommonUtil.getPersistence().get(selectQuery1);
                    Iterator iterator = dataObject.getRows(TableName.RMP_VSPHERE_DETAILS);
                    ArrayList<Long> successfulVMsHost = new ArrayList<Long>();
                    while(iterator.hasNext()) {
                        Row row1 = (Row)iterator.next();
                        long vsphereHostID = (long)row1.get("VSPHERE_HOST_ID");
                        String hostname = (String)row1.get("HOST_NAME");
                        successfulVMsHost.add(vsphereHostID);
                        if(!hostName.contains(vsphereHostID)) {
                            hostName.put(vsphereHostID, hostname);
                        }
                    }
                    ArrayList<Long> failedVMsHost = new ArrayList<Long>();
                    if (status.equalsIgnoreCase("failed") || status.equalsIgnoreCase("Interrupted")) {
                        Hashtable<String, ArrayList> failedVMDetails = VirtualBackupServerUtil.getFailedVMs(backupIdentifier);
                        ArrayList<Long> failedVMs = failedVMDetails.get("failedVMs");
                        for(int i = 0; i < failedVMs.size(); i++) {
                            long vmID = failedVMs.get(i);
                            SelectQuery selectQuery2 = new SelectQueryImpl(Table.getTable(TableName.RMP_VM_DETAILS));
                            selectQuery2.setCriteria(new Criteria(Column.getColumn(TableName.RMP_VM_DETAILS, "VM_ID"), vmID, QueryConstants.EQUAL));
                            Join join3 = new Join(TableName.RMP_VM_DETAILS, TableName.RMP_VSPHERE_DETAILS, new String[] {"VSPHERE_HOST_ID"}, new String[] {"VSPHERE_HOST_ID"}, Join.LEFT_JOIN);
                            selectQuery2.addSelectColumn(Column.getColumn(TableName.RMP_VSPHERE_DETAILS, "VSPHERE_HOST_ID"));
                            selectQuery2.addSelectColumn(Column.getColumn(TableName.RMP_VSPHERE_DETAILS, "HOST_NAME"));
                            selectQuery2.addSelectColumn(Column.getColumn(TableName.RMP_VM_DETAILS, "VM_ID"));
                            selectQuery2.addJoin(join3);
                            DataObject dataObject1 = CommonUtil.getPersistence().get(selectQuery2);
                            Iterator iterator1 = dataObject1.getRows(TableName.RMP_VSPHERE_DETAILS);
                            if(iterator1.hasNext()) {
                                Row row1 = (Row)iterator1.next();
                                long vsphereHostID = (long)row1.get("VSPHERE_HOST_ID");
                                String hostname = (String)row1.get("HOST_NAME");
                                if(!failedVMsHost.contains(vsphereHostID)) {
                                    failedVMsHost.add(vsphereHostID);
                                }
                                if(!hostName.contains(vsphereHostID)) {
                                    hostName.put(vsphereHostID, hostname);
                                }
                            }
                        }
                    }
                    for(int i = 0; i < successfulVMsHost.size(); i++) {
                        if(!failedVMsHost.contains(successfulVMsHost.get(i))) {
                            backupDetailsSuccess.put(successfulVMsHost.get(i), (backupDetailsSuccess.get(successfulVMsHost.get(i)) == null)?1:(backupDetailsSuccess.get(successfulVMsHost.get(i))+1));
                            backupDetailsTotal.put(successfulVMsHost.get(i), (backupDetailsTotal.get(successfulVMsHost.get(i)) == null)?1:(backupDetailsTotal.get(successfulVMsHost.get(i))+1));
                        }
                    }
                    for(int i = 0; i < failedVMsHost.size(); i++) {
                        backupDetailsFailure.put(failedVMsHost.get(i), (backupDetailsFailure.get(failedVMsHost.get(i)) == null)?1:(backupDetailsFailure.get(failedVMsHost.get(i))+1));
                        backupDetailsTotal.put(failedVMsHost.get(i), (backupDetailsTotal.get(failedVMsHost.get(i)) == null)?1:(backupDetailsTotal.get(failedVMsHost.get(i))+1));
                    }
                }
            }

            // restore
            Hashtable<Long, Integer> restoreDetailsSuccess = new Hashtable<>();
            Hashtable<Long, Integer> restoreDetailsFailure = new Hashtable<>();
            Hashtable<Long, Integer> restoreDetailsTotal = new Hashtable<>();

            if(operationsConfigured.contains(NotificationType.HyperVRestore.ordinal()) || operationsConfigured.contains(NotificationType.VMWareRestore.ordinal())) {
                SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_VM_RESTORE));
                selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_VM_RESTORE, "RESTORE_IDENTIFIER"));
                selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_VM_RESTORE, "RESTORE_STATUS"));
                Criteria virtualEnvironmentCriteria = new Criteria(Column.getColumn(TableName.RMP_VM_RESTORE, "VIRTUAL_ENVIRONMENT"), virtualEnvironment, QueryConstants.EQUAL);
                Criteria fromDateCriteria = new Criteria(Column.getColumn(TableName.RMP_VM_RESTORE, "RESTORE_TIME"), (new java.sql.Timestamp(fromDate.getTime())), QueryConstants.GREATER_THAN);
                Criteria toDateCriteria = new Criteria(Column.getColumn(TableName.RMP_VM_RESTORE, "RESTORE_TIME"), (new java.sql.Timestamp(toDate.getTime())), QueryConstants.LESS_THAN);
                selectQuery.setCriteria(virtualEnvironmentCriteria.and(fromDateCriteria).and(toDateCriteria));
                DataObject dataObj = CommonUtil.getPersistence().get(selectQuery);
                Iterator rows = dataObj.getRows(TableName.RMP_VM_RESTORE);
                while (rows.hasNext()) {
                    Row row = (Row) rows.next();
                    long restoreIdentifier = (long) row.get("RESTORE_IDENTIFIER");
                    String status = (String) row.get("RESTORE_STATUS");
                    if(!status.equalsIgnoreCase("Success") && !status.equalsIgnoreCase("Failed")) {
                        continue;
                    }
                    SelectQuery selectQuery1 = new SelectQueryImpl(Table.getTable(TableName.RMP_VM_RESTORE));
                    Join join = new Join(TableName.RMP_VM_RESTORE, TableName.RMP_VMS_RESTORED_LIST, new String[] {"RESTORE_IDENTIFIER"}, new String[] {"RESTORE_IDENTIFIER"}, Join.LEFT_JOIN);
                    Join join1 = new Join(TableName.RMP_VMS_RESTORED_LIST, TableName.RMP_VM_BACKEDUP_DETAILS, new String[] {"BACKUP_VM_IDENTIFIER"}, new String[] {"BACKUP_VM_IDENTIFIER"}, Join.LEFT_JOIN);
                    Join join2 = new Join(TableName.RMP_VM_BACKEDUP_DETAILS, TableName.RMP_VM_DETAILS, new String[] {"VM_ID"}, new String[] {"VM_ID"}, Join.LEFT_JOIN);
                    Join join3 = new Join(TableName.RMP_VM_DETAILS, TableName.RMP_VSPHERE_DETAILS, new String[] {"VSPHERE_HOST_ID"}, new String[] {"VSPHERE_HOST_ID"}, Join.LEFT_JOIN);
                    selectQuery1.addSelectColumn(Column.getColumn(TableName.RMP_VM_RESTORE, "RESTORE_IDENTIFIER"));
                    selectQuery1.addSelectColumn(Column.getColumn(TableName.RMP_VMS_RESTORED_LIST, "RESTORE_VM_IDENTIFIER"));
                    selectQuery1.addSelectColumn(Column.getColumn(TableName.RMP_VM_BACKEDUP_DETAILS, "BACKUP_VM_IDENTIFIER"));
                    selectQuery1.addSelectColumn(Column.getColumn(TableName.RMP_VM_DETAILS, "VM_ID"));
                    selectQuery1.addSelectColumn(Column.getColumn(TableName.RMP_VSPHERE_DETAILS, "VSPHERE_HOST_ID"));
                    selectQuery1.addSelectColumn(Column.getColumn(TableName.RMP_VSPHERE_DETAILS, "HOST_NAME"));
                    selectQuery1.addJoin(join);
                    selectQuery1.addJoin(join1);
                    selectQuery1.addJoin(join2);
                    selectQuery1.addJoin(join3);
                    Criteria restoreIdentifierCriteria = new Criteria(Column.getColumn(TableName.RMP_VM_RESTORE, "RESTORE_IDENTIFIER"), restoreIdentifier, QueryConstants.EQUAL);
                    selectQuery1.setCriteria(restoreIdentifierCriteria);
                    DataObject dataObject = CommonUtil.getPersistence().get(selectQuery1);
                    Iterator iterator1 = dataObject.getRows(TableName.RMP_VSPHERE_DETAILS);
                    Iterator iterator2 = dataObject.getRows(TableName.RMP_VM_DETAILS);
                    ArrayList<Long> successfulVMsHost = new ArrayList<Long>();
                    ArrayList<Long> failedVMsHost = new ArrayList<Long>();
                    ArrayList<Long> failedVms = status.equalsIgnoreCase("Success") ? new ArrayList<Long>() : VirtualRestoreServerUtil.getFailedVMs(restoreIdentifier).get("failedVMs");
                    while(iterator1.hasNext()) {
                        Row row1 = (Row)iterator1.next();
                        long vmId = (long)((Row)iterator2.next()).get("VM_ID");
                        long vsphereHostID = (long)row1.get("VSPHERE_HOST_ID");
                        String hostname = (String)row1.get("HOST_NAME");
                        if (failedVms.indexOf(vmId) == -1) {
                            successfulVMsHost.add(vsphereHostID);
                        } else {
                            failedVMsHost.add(vsphereHostID);
                        }
                        if(!hostName.contains(vsphereHostID)) {
                            hostName.put(vsphereHostID, hostname);
                        }
                    }
                    for(int i = 0; i < successfulVMsHost.size(); i++) {
                        if(!failedVMsHost.contains(successfulVMsHost.get(i))) {
                            restoreDetailsSuccess.put(successfulVMsHost.get(i), (restoreDetailsSuccess.get(successfulVMsHost.get(i)) == null)?1:(restoreDetailsSuccess.get(successfulVMsHost.get(i))+1));
                            restoreDetailsTotal.put(successfulVMsHost.get(i), (restoreDetailsTotal.get(successfulVMsHost.get(i)) == null)?1:(restoreDetailsTotal.get(successfulVMsHost.get(i))+1));
                        }
                    }
                    for(int i = 0; i < failedVMsHost.size(); i++) {
                        restoreDetailsFailure.put(failedVMsHost.get(i), (restoreDetailsFailure.get(failedVMsHost.get(i)) == null)?1:(restoreDetailsFailure.get(failedVMsHost.get(i))+1));
                        restoreDetailsTotal.put(failedVMsHost.get(i), (restoreDetailsTotal.get(failedVMsHost.get(i)) == null)?1:(restoreDetailsTotal.get(failedVMsHost.get(i))+1));
                    }
                }
            }

            // preparing mail data
            for (Enumeration e = hostName.keys(); e.hasMoreElements();) {
                long vsphereHostID = (long) e.nextElement();
                String hostname = hostName.get(vsphereHostID);
                JSONObject hostData = new JSONObject();
                hostData.put("hostName", hostname);
                JSONArray operationDetails = new JSONArray();
                for(int j = 0; j < vmOperationsConfigured.length(); j++) {
                    JSONObject operationData = new JSONObject();
                    int notificationType = vmOperationsConfigured.getInt(j);
                    String operationName = MailTemplate.getOperationNameFromNotificationType(NotificationType.values()[notificationType]);
                    operationData.put("operation", notificationType);
                    Integer totalCount = (operationName.equalsIgnoreCase("Backup"))?backupDetailsTotal.get(vsphereHostID):restoreDetailsTotal.get(vsphereHostID);
                    Integer successCount = (operationName.equalsIgnoreCase("Backup"))?backupDetailsSuccess.get(vsphereHostID):restoreDetailsSuccess.get(vsphereHostID);
                    Integer failureCount = (operationName.equalsIgnoreCase("Backup"))?backupDetailsFailure.get(vsphereHostID):restoreDetailsFailure.get(vsphereHostID);
                    operationData.put("totalCount", (totalCount != null)?totalCount:0);
                    operationData.put("successCount", (successCount != null)?successCount:0);
                    operationData.put("failureCount", (failureCount != null)?failureCount:0);
                    operationDetails.put(operationData);
                }
                hostData.put("operationDetails", operationDetails);
                vmMailData.put(hostData);
            }

        } catch (Exception e) {
            LogWriter.general.severe("MailInfoVM.setVMScheduledMailInfo: " + LogWriter.getStackTrace(e));
        }
        return vmMailData;
    }

    public static String getVMName(Long vmId, String alternateName) {
        try{
            if(vmId == null) {
                return alternateName;
            }
            String vmName = alternateName;
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_VM_DETAILS, "VM_ID"), vmId, QueryConstants.EQUAL);
            DataObject dataObj = CommonUtil.getPersistence().get(TableName.RMP_VM_DETAILS, criteria);
            Row row = dataObj.getFirstRow(TableName.RMP_VM_DETAILS);
            if (row != null) {
                vmName = (String) row.get("VM_NAME");
            }
            return vmName;
        } catch (DataAccessException e) {
            return alternateName;
        }
    }

    public static String getBackupSize(Long backupsize) {
        String backupSize = null;
        if (Math.round(backupsize / (1024.0 * 1024)) == 0) {
            backupSize = Math.round(backupsize / (1024.0)) + " KB";
        } else if (Math.round(backupsize / (1024.0 * 1024 * 1024)) == 0) {
            backupSize = Math.round(backupsize / (1024.0 * 1024)) + " MB";
        } else {
            backupSize = Math.round(backupsize / (1024.0 * 1024 * 1024)) + " GB";
        }
        return backupSize;
    }

    private static String getVmwareRestoreType(int restoreType) {
        try {
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            if(restoreType == VirtualConstants.DISK_RESTORE) {
                return resBundle.getString("rmp.mail.virtual.disk_restore");
            }
            else if(restoreType == VirtualConstants.FULL_RESTORE) {
                return resBundle.getString("rmp.mail.virtual.full_restore");
            }
            else if(restoreType == VirtualConstants.REVERT) {
                return resBundle.getString("rmp.mail.virtual.revert");
            }
            else if(restoreType == VirtualConstants.LIVE_MIGRATE) {
                return resBundle.getString("rmp.mail.virtual.live_migration");
            }
            else if(restoreType == VirtualConstants.FILE_LEVEL_RESTORE) {
                return resBundle.getString("rmp.mail.virtual.file_level_restore");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private static String getHypervRestoreType(int restoreType) {
        try {
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            if(restoreType == VirtualConstants.DISK_RESTORE) {
                return resBundle.getString("rmp.mail.virtual.disk_restore");
            }
            else if(restoreType == VirtualConstants.FULL_RESTORE) {
                return resBundle.getString("rmp.mail.virtual.full_restore");
            }
            else if(restoreType == VirtualConstants.HV_LIVE_MIGRATE) {
                return resBundle.getString("rmp.mail.virtual.live_migration");
            }
            else if(restoreType == VirtualConstants.FILE_LEVEL_RESTORE) {
                return resBundle.getString("rmp.mail.virtual.file_level_restore");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static Long getRestoreDuration(long restoreIdentifier) {
        Long duration = 0L;
        try{
            SelectQueryImpl selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_VM_RESTORE));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_VM_RESTORE, "RESTORE_IDENTIFIER"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_VM_RESTORE, "RESTORE_DURATION"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_VM_RESTORE, "RESTORE_IDENTIFIER"), restoreIdentifier, QueryConstants.EQUAL);
            selectQuery.setCriteria(criteria);
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if(!dataObject.isEmpty()){
                Row row = dataObject.getFirstRow(TableName.RMP_VM_RESTORE);
                duration = (Long)(row.get("RESTORE_DURATION"));
            }
        } catch (Exception e) {
            LogWriter.general.severe("MailInfoVM.getRestoreDuration " + LogWriter.getStackTrace(e));
        }
        return duration;
    }

    private static String getBackupTypeString(String backupType) {
        String returnValue = "";
        try {
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            if(backupType.equalsIgnoreCase(VirtualConstants.INCRBACKUP)) {
                returnValue = resBundle.getString("rmp.mail.incremental_backup");
            } else if (backupType.equalsIgnoreCase(VirtualConstants.FULLBACKUP)) {
                returnValue = resBundle.getString("rmp.mail.full_backup");
            } else if(backupType.equalsIgnoreCase(VirtualConstants.HEALTHCHECKFULLBACKUP) || backupType.equalsIgnoreCase(VirtualConstants.HEALTHCHECKINCRBACKUP)) {
                returnValue = resBundle.getString("rmp.mail.health_check_backup");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnValue;
    }
}
//ignoreI18n_end
