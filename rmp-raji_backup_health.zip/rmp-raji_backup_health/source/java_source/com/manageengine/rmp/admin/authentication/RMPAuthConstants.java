/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.admin.authentication;

/**
 *
 * @author suganya-1815
 */
public class RMPAuthConstants {
    public static final String RMP_AUTHENTICATION="RecoveryManager Plus Authentication"; //NO I18N
    public static final String IS_DOMAIN_USER ="isDomainUser";//NO I18N
    public static final String LOGIN_NAME ="LOGIN_NAME";//NO I18N
    public static final String DOMAIN_VS_ROLES ="domainVsRoles"; //NO I18N
    public static final String IS_ALL_DOMAINS_DELEGATED = "allDomainsDelegated"; //NO I18N
    public static final String USER_ROLES ="userRoles";//NO I18N
}