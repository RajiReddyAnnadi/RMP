/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.admin.authentication;

/**
 *
 * @author poornima-3055
 */
public class RMPAuthErrorCodes {
    
    public static final int NO_AUTHORIZATION = 401;
}
