package com.manageengine.rmp.admin.productnotifier;

import com.manageengine.ads.fw.notifications.NotificationConstants;
import com.manageengine.ads.fw.notifications.NotificationInterface;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RegistryUpdateNotifier implements NotificationInterface, NotificationConstants {
    private static final String REGISTRY_UPDATE_FAILURE = "0";//no i18n
    private static JSONObject notifications = new JSONObject();
    private static String notificationName = "REGISTRY_UPDATE_NOTIFIER";//no i18n

    private static Logger logger = Logger.getLogger("ADSLogger");//no i18n

    public RegistryUpdateNotifier() {
        try {
            notifications.put(REGISTRY_UPDATE_FAILURE, new JSONObject());
        } catch(Exception e) {
            logger.log(Level.INFO, "Exception in instantiating class: RegistryUpdateNotifier "+e.getMessage());//no i18n
        }
    }

    @Override
    public Boolean isNotificationAvailable(Long userId) throws Exception {
        Boolean isNotificationAvailable = false;
        JSONObject obj = new JSONObject();
        try {
            if(ProductNotifierUtil.isRegistryUpdateFailed()) {
                obj.put(NOTIFICATION_ICON, Icon.CRITICAL);
                obj.put(NOTIFICATION_MESSAGE, "ads.notification_center.registry_update_failed");//no i18n
                obj.put(NOTIFICATION_ACTION_TEXT, "ads.notification_center.troubleshoot");
                obj.put(NOTIFICATION_ACTION, "showUpdateRegistry");
                obj.put(NOTIFICATION_NAME, notificationName);
                obj.put(NOTIFICATION_ID, REGISTRY_UPDATE_FAILURE);
                obj.put(ENABLE_STATUS, true);
                obj.put(NOTIFICATION_IS_DISMISSABLE, true);

                notifications.put(REGISTRY_UPDATE_FAILURE,obj);

                isNotificationAvailable = true;
            }
            else {
                notifications.getJSONObject(REGISTRY_UPDATE_FAILURE).put(ENABLE_STATUS, false);
            }
        } catch (Exception e) {
            logger.log(Level.INFO,"Exception in GPOErrorNotifier.isNotificationAvailable(" + String.valueOf(userId) + ")", e); //no i18n
        }
        return isNotificationAvailable;
    }

    @Override
    public JSONArray getNotification(Long userId) throws Exception {
        JSONArray arr = new JSONArray();
        Iterator iterator = notifications.keys();
        while(iterator.hasNext()) {
            JSONObject obj = notifications.getJSONObject((String) iterator.next());
            if(obj.optBoolean(ENABLE_STATUS)) {
                arr.put(obj);
            }
        }
        return arr;
    }

    @Override
    public Boolean setNotification(JSONObject obj) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");//no I18n
    }

    @Override
    public JSONObject notificationAction(JSONObject params) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");//no I18n
    }
}
