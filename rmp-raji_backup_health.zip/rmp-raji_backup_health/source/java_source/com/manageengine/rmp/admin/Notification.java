package com.manageengine.rmp.admin;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataAccess;
import com.manageengine.rmp.bmr.configure.BMRDatabase;
import com.manageengine.rmp.constants.RmpConstants;
import com.manageengine.rmp.util.RMPDomainHandler;
import com.manageengine.rmp.virtual.VirtualConstants;
import com.manageengine.rmp.virtual.backup.VirtualBackupServerUtil;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.NotificationSettingsType;
import com.manageengine.rmp.constants.TableName;
import org.json.JSONArray;
//ignoreI18n_start
public class Notification extends HttpServlet{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		try {
			if(request.getPathInfo().equals("/get")) {
				JSONObject notificationData = new JSONObject();
				notificationData.put("notifications", getNotificationsData());
				response.getWriter().print(notificationData.toString());
			}
			else if(request.getPathInfo().equals("/save")) {
				saveNotificationSettings(request, response);
			}
			else if(request.getPathInfo().equals("/delete")) {
				deleteNotificationSettings(request, response);
			}
		}
		catch(Exception e)
		{
			LogWriter.general.severe("Error in Notification.doGet " + LogWriter.getStackTrace(e) ); // No I18N
		}
	}

	private JSONArray getNotificationsData(){
		LogWriter.general.info("API Called: Notification.getNotificationsData()");
		JSONArray notificationsList = new JSONArray();
		try{
			SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.RMP_NOTIFICAITON_SETTINGS));
			query.addSelectColumn(Column.getColumn(TableName.RMP_NOTIFICAITON_SETTINGS, "*"));
			query.addSortColumn(new SortColumn(new Column(TableName.RMP_NOTIFICAITON_SETTINGS, "NOTIFICATION_SETTINGS_NAME"), true));
			DataObject obj = CommonUtil.getPersistence().get(query);
			if(!obj.isEmpty()) {
				Iterator itr = obj.getRows(TableName.RMP_NOTIFICAITON_SETTINGS);
				while (itr.hasNext()) {
					JSONObject notificationInfo = new JSONObject();
					Row row = (Row) itr.next();
					notificationInfo.put("ID",(int) row.get("UNIQUE_ID"));
					notificationInfo.put("NAME",row.get("NOTIFICATION_SETTINGS_NAME").toString());
					int notificationType = (int) row.get("NOTIFICATION_TYPE");
					notificationInfo.put("TYPE",notificationType);
					notificationInfo.put("DATA",row.get("DATA").toString());
					notificationInfo.put("MAILIDS",row.get("MAIL_IDS").toString());

					if(notificationType == NotificationSettingsType.Scheduled.ordinal()) {
						DecimalFormat formatter = new DecimalFormat("00");
						Row scheduleDetails = BMRDatabase.getScheduleDetails((Long)row.get("SCHEDULE_ID"));
						JSONObject scheduleInfo = new JSONObject();
						if (scheduleDetails != null) {
							scheduleInfo.put("frequencyType", scheduleDetails.get("REPEAT_FREQUENCY").toString().toLowerCase());
							scheduleInfo.put("day", (Integer) scheduleDetails.get("DAY_OF_WEEK"));
							scheduleInfo.put("dom", formatter.format((Integer) scheduleDetails.get("DATE_OF_MONTH")));
							if (((String) scheduleDetails.get("UNIT_OF_TIME")).equalsIgnoreCase("Hours")) {
								scheduleInfo.put("hr", formatter.format((long) scheduleDetails.get("TIME_OF_DAY")));
								scheduleInfo.put("min", "00");
							} else if (((String) scheduleDetails.get("UNIT_OF_TIME")).equalsIgnoreCase("Minutes")) {
								scheduleInfo.put("hr", formatter.format(((long) (scheduleDetails.get("TIME_OF_DAY")) / 60)));
								scheduleInfo.put("min", formatter.format(((long) (scheduleDetails.get("TIME_OF_DAY")) % 60)));
							}
						}
						notificationInfo.put("SCHEDULE", scheduleInfo);
					}
					notificationsList.put(notificationInfo);
				}
			}
		}catch(Exception ex){
			LogWriter.general.severe("Error in Notification.getNotificationsData: " + LogWriter.getStackTrace(ex));
		}
		return notificationsList;
	}
	private void saveNotificationSettings(HttpServletRequest request, HttpServletResponse response) throws JSONException, IOException {
		LogWriter.general.info("API Called: Notification.saveNotificationSettings(request, response)");
		JSONObject result = new JSONObject();
		try {
			JSONObject req = new JSONObject(request.getParameter("req"));
			result.put("success", saveNotificationSettings(req.getJSONObject("notification")));
			response.getWriter().print(result);
		}
		catch (Exception e) {
			response.getWriter().print(e);
			LogWriter.general.severe("Error in saveNotificationSettings "+LogWriter.getStackTrace(e)); // No I18N
		}
	}
	private void deleteNotificationSettings(HttpServletRequest request, HttpServletResponse response) throws JSONException, IOException {
		LogWriter.general.info("API Called: Notification.deleteNotificationSettings(request, response)");
		JSONObject result = new JSONObject();
		try {
			JSONObject req = new JSONObject(request.getParameter("req"));
			result.put("success", deleteNotificationSettings(req.getJSONObject("notification")));
			response.getWriter().print(result);
		}
		catch (Exception e) {
			response.getWriter().print(e);
			LogWriter.general.severe("Error in Notification.deleteNotificationSettings "+LogWriter.getStackTrace(e)); // No I18N
		}
	}

	public static boolean deleteNotificationSettings(JSONObject jsonData) throws Exception {
		LogWriter.general.info("API Called: Notification.deleteNotificationSettings(JSONObject)");
		try{
			int uniqueID = jsonData.getInt("uniqueID");
			DataObject dataObject = CommonUtil.getPersistence().get(TableName.RMP_NOTIFICAITON_SETTINGS, new Criteria(Column.getColumn(TableName.RMP_NOTIFICAITON_SETTINGS, "UNIQUE_ID"), uniqueID, QueryConstants.EQUAL));
			Row existingRow = dataObject.getFirstRow(TableName.RMP_NOTIFICAITON_SETTINGS);
			int prevNotificationType = (int)existingRow.get("NOTIFICATION_TYPE");
			Long prevScheduleID = (Long) existingRow.get("SCHEDULE_ID");
			if(prevNotificationType == NotificationSettingsType.Scheduled.ordinal()) {
				NotificationScheduler.deleteSchedule(prevScheduleID);
			}
			dataObject.deleteRow(existingRow);
			CommonUtil.getPersistence().update(dataObject);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static boolean saveNotificationSettings(JSONObject jsonData) throws Exception {
		LogWriter.general.info("API Called: Notification.saveNotificationSettings(JSONObject)");
		try {
			String name = jsonData.getString("name");
			int notificationType = jsonData.getInt("notificationType");
			String data = jsonData.getJSONObject("modules").toString();
			String toMailIds = "";
			if(jsonData.has("mailIdsToBeNotified")) {
				toMailIds = jsonData.getString("mailIdsToBeNotified");
			}
			// edit existing notification
			if(jsonData.has("uniqueID")) {
				int uniqueID = jsonData.getInt("uniqueID");
				DataObject dataObject = CommonUtil.getPersistence().get(TableName.RMP_NOTIFICAITON_SETTINGS, new Criteria(Column.getColumn(TableName.RMP_NOTIFICAITON_SETTINGS, "UNIQUE_ID"), uniqueID, QueryConstants.EQUAL));
				Row existingRow = dataObject.getFirstRow(TableName.RMP_NOTIFICAITON_SETTINGS);
				if(dataObject.isEmpty()) {
					throw new Exception("Error finding existing notification");
				}
				int prevNotificationType = (int)existingRow.get("NOTIFICATION_TYPE");
				Long prevScheduleID = (Long) existingRow.get("SCHEDULE_ID");
				existingRow.set("NOTIFICATION_SETTINGS_NAME", name);
				existingRow.set("NOTIFICATION_TYPE", notificationType);
				existingRow.set("DATA", data);
				existingRow.set("MAIL_IDS", toMailIds);
				existingRow.set("SCHEDULE_ID", null);
				dataObject.updateRow(existingRow);
				CommonUtil.getPersistence().update(dataObject);

				if(prevNotificationType == NotificationSettingsType.Scheduled.ordinal()) {
					NotificationScheduler.deleteSchedule(prevScheduleID);
				}
				if(notificationType == NotificationSettingsType.Scheduled.ordinal()) {
					JSONObject scheduleData = jsonData.getJSONObject("schedule");
					String frequencyType = scheduleData.getString("frequencyType");
					String freq = null;
					String dom = null;
					String day = null;
					if (frequencyType.equals("Monthly")) {
						freq = "0";
						dom = scheduleData.getString("dom");
					} else if (frequencyType.equals("Daily")) {
						freq = "1";
					} else if (frequencyType.equals("Weekly")) {
						freq = "2";
						day = scheduleData.getString("day");
					}
					NotificationScheduler notificationScheduler = new NotificationScheduler(uniqueID, freq, scheduleData.getString("hr"), scheduleData.getString("min"), day, dom);
					notificationScheduler.createSchedule();
				}
			}
			// create new notification
			else {
				DataObject dataObject = CommonUtil.getPersistence().constructDataObject();
				Row insertrow = new Row(TableName.RMP_NOTIFICAITON_SETTINGS);
				DataAccess.generateValues(insertrow);
				insertrow.set("NOTIFICATION_SETTINGS_NAME", name);
				insertrow.set("NOTIFICATION_TYPE", notificationType);
				insertrow.set("DATA", data);
				insertrow.set("MAIL_IDS", toMailIds);
				insertrow.set("SCHEDULE_ID", null);
				dataObject.addRow(insertrow);
				CommonUtil.getPersistence().add(dataObject);

				if(notificationType == NotificationSettingsType.Scheduled.ordinal()) {
					int uniqueID = (int) insertrow.get("UNIQUE_ID");
					JSONObject scheduleData = jsonData.getJSONObject("schedule");
					String frequencyType = scheduleData.getString("frequencyType");
					String freq = null;
					String dom = null;
					String day = null;
					if (frequencyType.equals("Monthly")) {
						freq = "0";
						dom = scheduleData.getString("dom");
					} else if (frequencyType.equals("Daily")) {
						freq = "1";
					} else if (frequencyType.equals("Weekly")) {
						freq = "2";
						day = scheduleData.getString("day");
					}
					NotificationScheduler notificationScheduler = new NotificationScheduler(uniqueID, freq, scheduleData.getString("hr"), scheduleData.getString("min"), day, dom);
					notificationScheduler.createSchedule();
				}
			}
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static void setDefaultMailNotification() {
		LogWriter.general.info("API Called: Notification.setDefaultMailNotification()");
		try{
			JSONObject data = new JSONObject();

			ArrayList<Properties> domainDetails = RMPDomainHandler.getRMPDomainDetails();
			JSONObject adData = new JSONObject();
			adData.put("domains", new JSONArray());
			JSONObject bmrData = new JSONObject();
			bmrData.put("domains", new JSONArray());
			if(domainDetails.size() > 0) {
				JSONArray adOperations = new JSONArray();
				for(int i = 0; i < RmpConstants.AD_OPERATIONS.length; i++) {
					adOperations.put(RmpConstants.AD_OPERATIONS[i]);
				}
				JSONArray bmrOperations = new JSONArray();
				for(int i = 0; i < RmpConstants.BMR_OPERATIONS.length; i++) {
					bmrOperations.put(RmpConstants.BMR_OPERATIONS[i]);
				}
				adData.put("isAllDomainsSelected", true);
				adData.put("OperationsToBeNotified", adOperations);
				bmrData.put("isAllDomainsSelected", true);
				bmrData.put("OperationsToBeNotified", bmrOperations);
			}
			else {
				adData.put("isAllDomainsSelected", false);
				adData.put("OperationsToBeNotified", new JSONArray());
				bmrData.put("isAllDomainsSelected", false);
				bmrData.put("OperationsToBeNotified", new JSONArray());
			}
			data.put("AD", adData);
			data.put("BMR", bmrData);

			JSONObject vmwareData = new JSONObject();
			Criteria virtualCriteria = null;
			virtualCriteria = new Criteria(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_SCHEDULE, "VIRTUAL_ENVIRONMENT"), VirtualConstants.VMWARE, QueryConstants.EQUAL);
			JSONArray vmwareBackupDetails = VirtualBackupServerUtil.getBackupDetails(new JSONArray(), 0, 0, virtualCriteria).getJSONArray("schedules");
			vmwareData.put("backups", new JSONArray());
			if(vmwareBackupDetails.length() > 0) {
				JSONArray vmwareOperations = new JSONArray();
				for(int i = 0; i < RmpConstants.VMWARE_OPERATIONS.length; i++) {
					vmwareOperations.put(RmpConstants.VMWARE_OPERATIONS[i]);
				}
				vmwareData.put("isAllBackupsSelected", true);
				vmwareData.put("OperationsToBeNotified", vmwareOperations);
			}
			else {
				vmwareData.put("isAllBackupsSelected", false);
				vmwareData.put("OperationsToBeNotified", new JSONArray());
			}
			data.put("VMWare", vmwareData);

			JSONObject hyperVData = new JSONObject();
			virtualCriteria = new Criteria(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_SCHEDULE, "VIRTUAL_ENVIRONMENT"), VirtualConstants.HYPERV, QueryConstants.EQUAL);
			JSONArray hyperVBackupDetails = VirtualBackupServerUtil.getBackupDetails(new JSONArray(), 0, 0, virtualCriteria).getJSONArray("schedules");
			hyperVData.put("backups", new JSONArray());
			if(hyperVBackupDetails.length() > 0) {
				JSONArray hyperVOperations = new JSONArray();
				for(int i = 0; i < RmpConstants.HYPERV_OPERATIONS.length; i++) {
					hyperVOperations.put(RmpConstants.HYPERV_OPERATIONS[i]);
				}
				hyperVData.put("isAllBackupsSelected", true);
				hyperVData.put("OperationsToBeNotified", hyperVOperations);
			}
			else {
				hyperVData.put("isAllBackupsSelected", false);
				hyperVData.put("OperationsToBeNotified", new JSONArray());
			}
			data.put("HyperV", hyperVData);

			DataObject dataObject = CommonUtil.getPersistence().constructDataObject();
			Row insertrow = new Row(TableName.RMP_NOTIFICAITON_SETTINGS);
			DataAccess.generateValues(insertrow);
			insertrow.set("NOTIFICATION_SETTINGS_NAME", "Default");
			insertrow.set("NOTIFICATION_TYPE", NotificationSettingsType.All.ordinal());
			insertrow.set("DATA", data.toString());
			insertrow.set("MAIL_IDS", ServerSettings.getMailerSettings(null).getString("ADMIN_MAIL_ID"));
			insertrow.set("SCHEDULE_ID", null);
			dataObject.addRow(insertrow);
			CommonUtil.getPersistence().add(dataObject);
		}
		catch (Exception e) {
			LogWriter.general.severe("Error in Notification.setDefaultMailNotification()" + LogWriter.getStackTrace(e));
		}
	}

	public static void deleteVMBackupID(long backupID, int virtualEnvironment) {
		LogWriter.general.info("API Called: Notification.deleteVMBackupID()");
		try {
			SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_NOTIFICAITON_SETTINGS));
			selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_NOTIFICAITON_SETTINGS, "*"));
			DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
			Iterator rowIterator = dataObject.getRows(TableName.RMP_NOTIFICAITON_SETTINGS);
			while (rowIterator.hasNext()) {
				Row row = (Row) rowIterator.next();
				JSONObject data = new JSONObject((String)row.get("DATA"));
				if(virtualEnvironment == VirtualConstants.VMWARE) {
					boolean isAllBackupsSelected = data.getJSONObject("VMWare").has("isAllBackupsSelected") && data.getJSONObject("VMWare").getBoolean("isAllBackupsSelected");
					if (isAllBackupsSelected) {
						Criteria virtualCriteria = new Criteria(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_SCHEDULE, "VIRTUAL_ENVIRONMENT"), VirtualConstants.VMWARE, QueryConstants.EQUAL);
						if ((VirtualBackupServerUtil.getBackupDetails(new JSONArray(), 0, 0, virtualCriteria).getJSONArray("schedules")).length() == 0) {
							data.getJSONObject("VMWare").put("isAllBackupsSelected", false);
							data.getJSONObject("VMWare").put("OperationsToBeNotified", new JSONArray());
						}
					} else {
						JSONArray vmwareBackups = data.getJSONObject("VMWare").getJSONArray("backups");
						JSONArray vmwareBackupsNew = new JSONArray();
						for(int i = 0; i < vmwareBackups.length(); i++) {
							long value = vmwareBackups.getLong(i);
							if(value != backupID) {
								vmwareBackupsNew.put(value);
							}
						}
						data.getJSONObject("VMWare").put("backups", vmwareBackupsNew);
						if(vmwareBackupsNew.length() == 0) {
							data.getJSONObject("VMWare").put("OperationsToBeNotified", new JSONArray());
						}
					}
				}
				if(virtualEnvironment == VirtualConstants.HYPERV) {
					boolean isAllBackupsSelected = data.getJSONObject("HyperV").has("isAllBackupsSelected") && data.getJSONObject("HyperV").getBoolean("isAllBackupsSelected");
					if (isAllBackupsSelected) {
						Criteria virtualCriteria = new Criteria(Column.getColumn(TableName.RMP_VIRTUAL_BACKUP_SCHEDULE, "VIRTUAL_ENVIRONMENT"), VirtualConstants.HYPERV, QueryConstants.EQUAL);
						if ((VirtualBackupServerUtil.getBackupDetails(new JSONArray(), 0, 0, virtualCriteria).getJSONArray("schedules")).length() == 0) {
							data.getJSONObject("HyperV").put("isAllBackupsSelected", false);
							data.getJSONObject("HyperV").put("OperationsToBeNotified", new JSONArray());
						}
					} else {
						JSONArray hyperVBackups = data.getJSONObject("HyperV").getJSONArray("backups");
						JSONArray hyperVBackupsNew = new JSONArray();
						for(int i = 0; i < hyperVBackups.length(); i++) {
							long value = hyperVBackups.getLong(i);
							if(value != backupID) {
								hyperVBackupsNew.put(value);
							}
						}
						data.getJSONObject("HyperV").put("backups", hyperVBackupsNew);
						if(hyperVBackupsNew.length() == 0) {
							data.getJSONObject("HyperV").put("OperationsToBeNotified", new JSONArray());
						}
					}
				}
				row.set("DATA", data);
				dataObject.updateRow(row);
			}
			CommonUtil.getPersistence().update(dataObject);
		} catch (Exception e) {
			LogWriter.general.severe("Error in Notification.deleteVMBackupID()" + LogWriter.getStackTrace(e));
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
//ignoreI18n_end