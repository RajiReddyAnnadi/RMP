package com.manageengine.rmp.admin.productnotifier;

import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.RmpConstants;
import com.manageengine.rmp.util.GeneralUtil;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.json.JSONObject;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;

//ignoreI18n_start

public class ProductNotifierClient extends DispatchAction {
    // for GPO_ERROR_NOTIFIER start
    public ActionForward getGPOBackupErrorDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse resp) {
        try {
            JSONObject returnValue = new JSONObject();
            resp.setContentType(RmpConstants.CONTENT_TYPE);
            returnValue.put("domains", ProductNotifierUtil.getFailedDomains());
            resp.getWriter().print(returnValue.toString());
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.severe("ProductNotifierClient.getGPOBackupErrorDetails():" + e);
        }
        return null;
    }

    public ActionForward getGPOBackupErrorObjects(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse resp) {
        try {
            JSONObject returnValue = new JSONObject();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            long domainId = inputJSONObject.getLong("domainId");
            int startIndex = inputJSONObject.getInt("start");
            String searchString = URLDecoder.decode(GeneralUtil.replaceChar(inputJSONObject, "searchString"), "utf-8");
            String searchType = inputJSONObject.getString("searchType");
            returnValue.put("count", ProductNotifierUtil.getFailedObjectsCount(domainId, searchString, searchType));
            returnValue.put("objects", ProductNotifierUtil.getFailedObjects(domainId, startIndex, searchString, searchType));
            resp.setContentType(RmpConstants.CONTENT_TYPE);
            resp.getWriter().print(returnValue.toString());
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.severe("ProductNotifierClient.getGPOBackupErrorObjects():" + e);
        }
        return null;
    }

    public ActionForward getGPOBackupErrorObjectsNames(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse resp) {
        try {
            JSONObject returnValue = new JSONObject();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            long domainId = inputJSONObject.getLong("domainId");
            int range = inputJSONObject.getInt("range");
            String searchString = URLDecoder.decode(GeneralUtil.replaceChar(inputJSONObject, "searchString"), "utf-8");
            returnValue.put("objectsList", ProductNotifierUtil.getFailedObjectsNames(domainId, range, searchString));
            resp.setContentType(RmpConstants.CONTENT_TYPE);
            resp.getWriter().print(returnValue.toString());
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.severe("ProductNotifierClient.getGPOBackupErrorObjectsNames():" + e);
        }
        return null;
    }

        public ActionForward disableRetryBackup(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse resp) {
        try {
            JSONObject returnValue = new JSONObject();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            long domainId = inputJSONObject.getLong("domainId");
            String objectGuid = inputJSONObject.getString("objectGuid");
            returnValue.put("success", ProductNotifierUtil.disableRetryBackup(domainId, objectGuid));
            resp.setContentType(RmpConstants.CONTENT_TYPE);
            resp.getWriter().print(returnValue.toString());
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.severe("ProductNotifierClient.flipRetryBackup():" + e);
        }
        return null;
    }

    public ActionForward getBackupDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse resp) {
        try {
            JSONObject returnValue = new JSONObject();
            JSONObject inputJSONObject = new JSONObject(request.getParameter("req"));
            long domainId = inputJSONObject.getLong("domainId");
            returnValue.put("latestBackupTime", ProductNotifierUtil.getBackupDetails(domainId, false));
            returnValue.put("firstBackupTime", ProductNotifierUtil.getBackupDetails(domainId, true));
            resp.setContentType(RmpConstants.CONTENT_TYPE);
            resp.getWriter().print(returnValue.toString());
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.severe("ProductNotifierClient.getLastSuccessfulBackupIdentifier():" + e);
        }
        return null;
    }
    // for GPO_ERROR_NOTIFIER end
}

//ignoreI18n_end