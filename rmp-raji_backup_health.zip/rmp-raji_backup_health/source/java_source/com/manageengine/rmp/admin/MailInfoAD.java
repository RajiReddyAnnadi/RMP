package com.manageengine.rmp.admin;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.i18n.ADSResourceBundle;
import com.manageengine.ads.fw.i18n.I18NUtil;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.DateUtil;
import com.manageengine.me.util.JSONArrayUtil;
import com.manageengine.rmp.admin.constants.NotificationType;
import com.manageengine.rmp.admin.constants.OperationstatusMailnotification;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.i18n.Rmpi18n;
import com.manageengine.rmp.constants.*;
import com.manageengine.rmp.dataobjects.OperationInfo;
import com.manageengine.rmp.errors.RMPErrorId;
import com.manageengine.rmp.restore.GetResult;
import com.manageengine.rmp.rollback.RollbackUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
//ignoreI18n_start
public class MailInfoAD {
    public static JSONObject setADMailInfo(Object data, NotificationType notificationType) {
        LogWriter.general.info("MailInfoAD.setADMailInfo()");
        try {
            boolean isSuccess;
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            JSONObject notificationData = new JSONObject();
            JSONObject commonData = new JSONObject();
            OperationInfo operationInfo = (OperationInfo)data;
            notificationData.put("operation_status", operationInfo.status.ordinal());
            OperationStatus status = operationInfo.status;
            if(notificationType == NotificationType.ADBackup) {
                isSuccess = (status == OperationStatus.Completed || status == OperationStatus.PartiallyCompleted || status == OperationStatus.Interrupted);
            }
            else {
                isSuccess = (status == OperationStatus.Completed);
            }
            if(isSuccess) {
                commonData.put("%TOTAL_COUNT%",operationInfo.count);
            }
            else {
                JSONObject errorDetails = getErrorMessageFromStatusId(operationInfo.statusId);
                commonData.put("%REASON_FOR_FAILURE%", (errorDetails == null)?"-":errorDetails.get("errorMessage"));
                commonData.put("%TIPS_TROUBLESHOOT%",(errorDetails == null)?resBundle.getString("rmp.mail.troubleshoot.default"):errorDetails.get("troubleshootingTips"));
            }
            commonData.put("%START_TIME%",MailTemplate.getMailDateFormat().format(operationInfo.startTime));
            commonData.put("%STATUS%",operationInfo.status.toString());
            commonData.put("%INITIATED_BY%",operationInfo.initiator);
            Properties domainDetailsJson = RMPDomainHandler.getDomainDetailsById(operationInfo.domainId);
            commonData.put("%DOMAIN_NAME%",(String)domainDetailsJson.get("DOMAIN_NAME"));

            if (status == OperationStatus.Interrupted) {
                commonData.put("%TIME_TAKEN%", "-");
            }
            else {
                commonData.put("%TIME_TAKEN%", DateUtil.millisecondsToTime(operationInfo.timeTaken));
            }

            String message = "";
            String operation = MailTemplate.getOperationNameFromNotificationType(notificationType);

            if(isSuccess) {
                if (status == OperationStatus.Completed) {
                    message = operation + " " + resBundle.getString("rmp.mail.common.operation_completed");
                }
                else if (status == OperationStatus.PartiallyCompleted) { // only for backup
                    message = resBundle.getString("rmp.mail.common.backup_operation_completed_partially");
                } else {
                    message = operation + " " + resBundle.getString("rmp.mail.common.operation_interrupted");
                }
            }
            else {
                message = operation + " " + resBundle.getString("rmp.mail.common.operation_failed");
            }
            message += " " + resBundle.getString("rmp.mail.common.please_find_info_below");
            commonData.put("%MESSAGE%", message);
            commonData.put("%OPERATION%", operation);

            notificationData.put("commonData", commonData);
            return notificationData;
        }
        catch(Exception e) {
            LogWriter.general.severe("MailInfoAD.setADMailInfo : " + e);
            return null;
        }
    }

    public static JSONObject setADBackupMailInfo(Object data, JSONObject dataObject) {
        LogWriter.general.info("MailInfoAD.setADBackupMailInfo()");
        try{
            OperationInfo operationInfo = (OperationInfo)data;
            JSONArray jsonArrayData = new JSONArray(String.valueOf(operationInfo.data));
            JSONObject backupData = new JSONObject();
            int[] innerArray = JSONArrayUtil.toIntArray(new JSONArray(String.valueOf(jsonArrayData.get(0))));
            for (int j = 0, ct = 1; j < innerArray.length; j++)
            {
                backupData.put("%CHANGETYPEWISE_INFO_"+ct+"_1%" , String.valueOf(innerArray[j]));
                backupData.put("%CHANGETYPEWISE_INFO_"+ct+"_2%" , ChangeType.values()[j].toString());
                ct++;
            }
            dataObject.put("backupData", backupData);
            return dataObject;
        } catch(Exception e) {
            LogWriter.general.severe("MailTemplate.setADBackupMailInfo " + LogWriter.getStackTrace(e));
            return dataObject;
        }
    }

    public static JSONObject setADRestoreMailInfo(Object data, JSONObject dataObject) {
        LogWriter.general.info("MailInfoAD.setADRestoreMailInfo()");
        try{
            OperationInfo operationInfo = (OperationInfo)data;
            JSONArray restoreDataArray = GetResult.getRestoreResults(operationInfo.domainId, operationInfo.operationId);
            JSONObject restoreMailData = new JSONObject();
            int successCount = 0, failureCount = 0;
            for(int i = 0; i < restoreDataArray.length(); i++) {
                JSONObject restoreData = restoreDataArray.getJSONObject(i).getJSONObject("obj");
                if(restoreData.getBoolean("success")) {
                    successCount++;
                }
                else {
                    failureCount++;
                }
            }
            restoreMailData.put("%SUCCESS%", successCount);
            restoreMailData.put("%FAILURE%", failureCount);
            dataObject.put("restoreData", restoreMailData);
            return dataObject;
        } catch (Exception e) {
            LogWriter.general.severe("MailInfoAD.setADRestoreMailInfo " + LogWriter.getStackTrace(e));
            return dataObject;
        }
    }

    public static JSONObject setADRollBackMailInfo(Object data, JSONObject dataObject) {
        LogWriter.general.info("MailInfoAD.setADRollBackMailInfo()");
        try{
            OperationInfo operationInfo = (OperationInfo)data;
            JSONArray rollbackDataArray = RollbackUtil.getResultData(operationInfo.domainId, operationInfo.operationId, 0, 0);
            JSONObject rollBackMailData = new JSONObject();
            int successCount = 0, failureCount = 0;
            for(int i = 0; i < rollbackDataArray.length(); i++) {
                JSONObject rollBackData = rollbackDataArray.getJSONObject(i);
                if(rollBackData.getBoolean("success")) {
                    successCount++;
                }
                else {
                    failureCount++;
                }
            }
            rollBackMailData.put("%SUCCESS%", successCount);
            rollBackMailData.put("%FAILURE%", failureCount);
            rollBackMailData.put("%ROLLBACK_TO%", MailTemplate.getMailDateFormat().format(RollbackUtil.getRollBackToDate(operationInfo)));
            dataObject.put("rollbackData", rollBackMailData);
            return dataObject;
        } catch (Exception e) {
            LogWriter.general.severe("MailInfoAD.setADRollBackMailInfo " + LogWriter.getStackTrace(e));
            return dataObject;
        }
    }

    public static JSONArray setADScheduledMailInfo(boolean isAllDomainsSelected, JSONArray adDomains, JSONArray adOperationsConfigured, java.util.Date fromDate, java.util.Date toDate){
        LogWriter.general.info("API Called: MailInfoAD.setADScheduledMailData()");
        JSONArray adMailData = new JSONArray();
        try{
            if(isAllDomainsSelected) {
                adDomains = MailTemplate.getAllDomainIDs();
            }
            for(int i = 0; i < adDomains.length(); i++) {
                long domainID = adDomains.getLong(i);
                JSONObject domainData = new JSONObject();
                domainData.put("domainName", RMPDomainHandler.getDomainDetailsById(domainID).getProperty("DOMAIN_NAME"));
                JSONArray operationDetails = new JSONArray();
                for(int j = 0; j < adOperationsConfigured.length(); j++) {
                    JSONObject operationData = new JSONObject();
                    int notificationType = adOperationsConfigured.getInt(j);
                    int totalCount = 0, successCount = 0, failureCount = 0;
                    ArrayList<Integer> operations = getADOperationTypeFromNotificationType(NotificationType.values()[notificationType]);
                    SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OPERATION_INFO));
                    Criteria domainIDCriteria = new Criteria(Column.getColumn(TableName.RMP_OPERATION_INFO, "DOMAIN_ID"), domainID, QueryConstants.EQUAL);
                    Criteria operationTypeCriteria = new Criteria(Column.getColumn(TableName.RMP_OPERATION_INFO, "OPERATION_TYPE"), operations.toArray(), QueryConstants.IN);
                    Criteria fromDateCriteria = new Criteria(Column.getColumn(TableName.RMP_OPERATION_INFO, "START_TIME"), DateUtil.DateToTimestamp(fromDate), QueryConstants.GREATER_THAN);
                    Criteria toDateCriteria = new Criteria(Column.getColumn(TableName.RMP_OPERATION_INFO, "START_TIME"), DateUtil.DateToTimestamp(toDate), QueryConstants.LESS_THAN);
                    selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_OPERATION_INFO, "OPERATION_ID"));
                    selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_OPERATION_INFO, "STATUS"));
                    selectQuery.setCriteria(domainIDCriteria.and(operationTypeCriteria).and(fromDateCriteria).and(toDateCriteria));
                    DataObject dataObj = CommonUtil.getPersistence().get(selectQuery);
                    Iterator rows = dataObj.getRows(TableName.RMP_OPERATION_INFO);
                    while (rows.hasNext()) {
                        Row row = (Row) rows.next() ;
                        int status = (int) row.get("STATUS");

                        boolean successCondition, failureCondition;
                        if(notificationType == NotificationType.ADBackup.ordinal()) {
                            successCondition = (status == OperationStatus.Completed.ordinal() || status == OperationStatus.PartiallyCompleted.ordinal() || status == OperationStatus.Interrupted.ordinal());
                            failureCondition = (status == OperationStatus.Failed.ordinal());
                        } else {
                            successCondition = (status == OperationStatus.Completed.ordinal());
                            failureCondition = (status == OperationStatus.Failed.ordinal() || status == OperationStatus.Interrupted.ordinal());
                        }

                        if(successCondition) {
                            successCount++;
                            totalCount++;
                        }
                        else if(failureCondition) {
                            failureCount++;
                            totalCount++;
                        }
                    }
                    operationData.put("operation", notificationType);
                    operationData.put("totalCount", totalCount);
                    operationData.put("successCount", successCount);
                    operationData.put("failureCount", failureCount);
                    operationDetails.put(operationData);
                }
                domainData.put("operationDetails", operationDetails);
                adMailData.put(domainData);
            }
        } catch (Exception e){
            LogWriter.general.severe("MailInfoAD.setADScheduledMailData " + LogWriter.getStackTrace(e));
        }
        return adMailData;
    }

    public static ArrayList<Integer> getADOperationTypeFromNotificationType(NotificationType notificationType) {
        ArrayList<Integer> operationTypeArray = new ArrayList<>();
        try{
            switch (notificationType) {
                case ADRollback: {
                    operationTypeArray.add(OperationType.Rollback.ordinal());
                    break;
                }
                case ADRecycle: {
                    operationTypeArray.add(OperationType.Recycle.ordinal());
                    break;
                }
                case ADBackup: {
                    operationTypeArray.add(OperationType.Backup.ordinal());
                    operationTypeArray.add(OperationType.FullBackup.ordinal());
                    break;
                }
                case ADRestore: {
                    operationTypeArray.add(OperationType.Restore.ordinal());
                    operationTypeArray.add(OperationType.Revert.ordinal());
                    break;
                }
            }
        } catch(Exception e) {
            LogWriter.general.severe("NotificationAPI.getADOperationTypeFromNotificationType " + LogWriter.getStackTrace(e));
        }
        return operationTypeArray;
    }

    public static OperationstatusMailnotification getADOperationstatusMailnotification(int notificationType, OperationStatus operationStatus) {
        switch (operationStatus) {
            case Completed: {
                return OperationstatusMailnotification.Success;
            }
            case Failed: {
                return OperationstatusMailnotification.Failure;
            }
            case Interrupted: {
                if(notificationType == NotificationType.ADBackup.ordinal()) {
                    return OperationstatusMailnotification.Interrupted;
                } else {
                    return OperationstatusMailnotification.Failure;
                }
            }
            case PartiallyCompleted: {
                if(notificationType == NotificationType.ADBackup.ordinal()) {
                    return OperationstatusMailnotification.PartiallyCompleted;
                } else {
                    return OperationstatusMailnotification.Failure;
                }
            }
            default: {
                return null;
            }
        }
    }

    private static JSONObject getErrorMessageFromStatusId(long statusId) {
        try {
            LogWriter.general.info("API Called: MailInfoAD.getErrorMessageFromStatusId(" + String.valueOf(statusId) + ")");
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            JSONObject errorDetails = new JSONObject();
            String errorMessage = "rmp.mail.AD.failure_reason.unknown_error";
            String troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default");

            if(statusId == RMPErrorId.UNKNOWN_ERROR.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.unknown_error");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default");
            }
            else if (statusId == RMPErrorId.SETTING_ACCOUNT_PROPERTIES.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Account_Properties");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.SETTITNG_ATTRIBUTES.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Setting_Attributes");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.SETTING_PASSWORD.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Setting_Password");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.ADD_USER_TO_GROUP.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Add_User_To_Group");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.ACCESS_GROUP_NO_READ_PERMISSION.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.No_Read_Permission_To_Access_Group");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.ACCESS_GROUP.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Cannot_Access_Group");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.NO_VIEW_PERMISSION.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.No_View_Permission");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.NO_SUCH_USER_MATCHED.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.No_Such_User_Matched");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.ACCESS_CONTAINER.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Cannot_Access_Container");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.NO_SUCH_CONTACT_MATCHED.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.No_Such_Contact_Matched");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.NO_SUCH_GROUP_MATCHED.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.No_Such_Group_Matched");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.NO_SUCH_OU_MATCHED.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.No_Such_Ou_Matched");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.NO_SUCH_DNSNODE_MATCHED.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.No_Such_Dns_Node_Matched");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.NO_SUCH_DNSZONE_MATCHED.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.No_Such_Dns_Zone_Matched");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.NO_SUCH_OBJECT_EXIST.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.No_Such_Object_Exist");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.OBJECT_ALREADY_EXIST.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Object_Already_Exist");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.DELETED_OBJECT_CONTAINER__EMPTY.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Deleted_Object_Container_Access");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.INSUFFICIENT_ACCESS_RIGHTS.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Insufficient_Access_Rights");
                troubleshootingTips = resBundle.getString("rmp.mail.AD.troubleshoot.update_credentials");
            }
            else if (statusId == RMPErrorId.UNABLE_TO_MODIFY.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.unable_to_modify");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.UNABLE_TO_DELETE.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Unable_to_delete");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.NO_SUCH_LOCATION_EXIST.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.No_Such_Location_Exist");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.CANNOT_RECYCLE_SITE.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Recycling_site_object_is_not_allowed");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.CAN_MODIFY_ONLY_GPLINKS_FOR_SITE.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Only_gpo_links_can_be_modified_sites");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == RMPErrorId.CANNOT_MODIFY_DELETED_SITE.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Site_is_in_deleted_state");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default");
            }
            else if (statusId == RMPErrorId.UNABLE_TO_MOVE_TO_THAT_OU.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Unable_to_move_to_that_OU");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == StatusId.InitiatingBackup.value) {
                errorMessage = resBundle.getString("rmp.rollback.error_in_backup");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == StatusId.ConnectingDC.value) {
                errorMessage = resBundle.getString("rmp.rollback.failed_to_connect_dc");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default");
            }
            else if (statusId == StatusId.SearchingObjectChanges.value) {
                errorMessage = resBundle.getString("rmp.rollback.error_while_searching_changes");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == StatusId.PreparingData.value) {
                errorMessage = resBundle.getString("rmp.rollback.failed_to_prepare_rollback_data");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == StatusId.DomainStatus.value) {
                errorMessage = resBundle.getString("rmp.rollback.selected_domain_disabled_enable_domain_in_domain_settings");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == StatusId.BackedUpObjects.value) {
                errorMessage = resBundle.getString("rmp.rollback.error_while_taking_backup");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == StatusId.RecoveredObjects.value) {
                errorMessage = resBundle.getString("rmp.rollback.error_while_recovering_objects");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == StatusId.InitiatingRollback.value) {
                errorMessage = resBundle.getString("rmp.rollback.error_occured_while_initiating_operation");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == StatusId.InitiatingRestore.value) {
                errorMessage = resBundle.getString("rmp.rollback.error_occurred_while_initiating_rollback");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if (statusId == StatusId.AccessDeniedCredentials.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.AccessDeniedCredentials");
                troubleshootingTips = resBundle.getString("rmp.mail.AD.troubleshoot.update_credentials");
            }
            else if (statusId == StatusId.InvalidCredentials.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.InvalidCredentials");
                troubleshootingTips = resBundle.getString("rmp.mail.AD.troubleshoot.update_credentials");
            }
            else if (statusId == StatusId.AuthenticationProblem.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.AuthenticationProblem");
                troubleshootingTips = resBundle.getString("rmp.mail.AD.troubleshoot.update_credentials");
            }
            else if (statusId == StatusId.ServerNotOperational.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.ServerNotOperational");
                troubleshootingTips = resBundle.getString("rmp.mail.AD.troubleshoot.domain_controller_operational");
            }
            else if (statusId == StatusId.ApplicationRestared.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.Interrupted");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default");
            }
            else if (statusId == StatusId.AccessDenied.value) {
                errorMessage = resBundle.getString("rmp.mail.AD.failure_reason.AccessDenied");
                troubleshootingTips = resBundle.getString("rmp.mail.AD.troubleshoot.update_credentials");
            }
            else if(statusId == 0x0000272E) {
                errorMessage = resBundle.getString("rmp.errors.Sie_is_in_deleted_state");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if(statusId == 0x0000272D) {
                errorMessage = resBundle.getString("rmp.errors.Only_gpo_links_can_be_modified_sites");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if(statusId == 0x0000272C) {
                errorMessage = resBundle.getString("rmp.errors.Recycling_site_object_is_not_allowed");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            else if(statusId == 0x00000600) {
                errorMessage = resBundle.getString("rmp.rollback.failed_to_retrieve_changes");
                troubleshootingTips = resBundle.getString("rmp.mail.troubleshoot.default1");
            }
            errorDetails.put("errorMessage", errorMessage);
            errorDetails.put("troubleshootingTips", troubleshootingTips);
            return errorDetails;
        } catch (Exception e) {
            LogWriter.general.severe("Error in MailInfoAD.getErrorMessageFromStatusId(): " + LogWriter.getStackTrace(e));
            return null;
        }
    }
}
//ignoreI18n_end