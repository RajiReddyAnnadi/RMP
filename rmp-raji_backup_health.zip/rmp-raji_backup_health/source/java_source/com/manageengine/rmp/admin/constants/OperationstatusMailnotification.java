package com.manageengine.rmp.admin.constants;

public enum OperationstatusMailnotification {
    Failure,
    Success,
    PartiallyCompleted,
    Interrupted
}
