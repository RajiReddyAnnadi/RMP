package com.manageengine.rmp.admin;

import com.adventnet.persistence.Row;
import com.adventnet.taskengine.DEFAULT_TASK_INPUT;
import com.adventnet.taskengine.Task;
import com.adventnet.taskengine.TaskContext;
import com.adventnet.taskengine.TaskExecutionException;
import com.manageengine.rmp.common.LogWriter;

import java.util.Iterator;

//ignoreI18n_start
public class NotificationTask implements Task {

    @Override
    public void executeTask(TaskContext taskContext) throws TaskExecutionException {
        try{
            LogWriter.general.info("API called: NotificationTask.executeTask()");
            Iterator<Row> iter = taskContext.getDefaultTaskInputs();
            long notificationID = -1L;
            while (iter.hasNext()) {
                Row row = iter.next();
                String varName = (String) row.get(DEFAULT_TASK_INPUT.VARIABLE_NAME);
                switch (varName) {
                    case "NotificationID":
                        notificationID = Long.valueOf((String) row.get(DEFAULT_TASK_INPUT.VARIABLE_VALUE));
                        break;
                }
                NotificationAPI.notifyScheduled(notificationID);
            }

        } catch (Exception e){
            LogWriter.general.severe("NotificationTask.executeTask(): " + LogWriter.getStackTrace(e));
        }
    }

    @Override
    public void stopTask() throws TaskExecutionException {
    }
}
//ignoreI18n_end