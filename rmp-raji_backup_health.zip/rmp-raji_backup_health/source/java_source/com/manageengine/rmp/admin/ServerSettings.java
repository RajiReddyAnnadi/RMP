/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * $Id:$
 */
package com.manageengine.rmp.admin;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.manageengine.ads.fw.mail.MailAction;
import com.manageengine.ads.fw.mail.MailHandler;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.TableName;
import java.net.URLDecoder;
import javax.servlet.http.HttpServlet;

import com.manageengine.rmp.util.GeneralUtil;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author aswathy-1909
 */
//ignoreI18n_start
public class ServerSettings extends HttpServlet{

    private static final String IMAGES_DIRECTORY = System.getProperty("user.dir") + File.separator + ".." + File.separator + "webapps" + File.separator + "admp_rmp" + File.separator + "rmpEmberApp" + File.separator + "dist" + File.separator + "images" + File.separator;
	
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		try {
                    if(request.getPathInfo().equals("/GET")) {
                        getMailerSettings(response);
                    }
                    else if(request.getPathInfo().equals("/SAVE")) {
                        saveMailerSettings(request, response);
                    }
                    else {
                        getMailerSettings(response);
                    }
                }
		catch(Exception e)
		{
			e.printStackTrace();
			LogWriter.general.severe("ServerSettings.doGet " + e ); // No I18N
		}
    }
    
    public static JSONObject getMailerSettings(HttpServletResponse response)
    {
        LogWriter.general.info("API called: ServerSettings.getMailerSettings()");
    	JSONObject mailerSettings = new JSONObject();
		try {
			mailerSettings = MailHandler.getMailSettings();
			if(mailerSettings.has("PASSWORD")) { // No I18N
				mailerSettings.remove("PASSWORD"); // No I18N
			}
			if(response!=null) {
				response.getWriter().print(mailerSettings.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogWriter.general.severe("ServerSettings.getMailerSettings " + e); // No I18N
		}
		return mailerSettings;
    }
    
    public static void saveMailerSettings(HttpServletRequest request, HttpServletResponse response) throws IOException, JSONException{
        LogWriter.general.info("API called: ServerSettings.saveMailerSettings()");
        JSONObject result = new JSONObject();
        try {
            JSONObject obj = new JSONObject(request.getParameter("req"));
            JSONObject mailSettings = new JSONObject();
            JSONObject serverProps = new JSONObject();
            serverProps.put("SERVER_NAME", obj.get("SERVER_NAME").toString());
            serverProps.put("PORT", obj.get("PORT").toString());
            if(obj.has("USERNAME")  && obj.has("PASSWORD")) {
                obj.put("USERNAME",URLDecoder.decode(GeneralUtil.replaceChar(obj, "USERNAME"),"utf-8"));
                obj.put("PASSWORD",URLDecoder.decode(GeneralUtil.replaceChar(obj, "PASSWORD"),"utf-8"));
                serverProps.put("USER_NAME", obj.get("USERNAME").toString());
                serverProps.put("PASSWORD", obj.get("PASSWORD").toString());
            }
            serverProps.put("CONNECTION_SECURITY_ID", obj.get("CONNECTION_SECURITY_ID").toString());
            if(obj.get("CONNECTION_SECURITY")!=null)
            {
                serverProps.put("CONNECTION_SECURITY",obj.get("CONNECTION_SECURITY"));
            }
            mailSettings.put("FROM_MAIL_ID", obj.get("FROM_MAIL_ID").toString());
            mailSettings.put("ADMIN_MAIL_ID", obj.get("ADMIN_MAIL_ID").toString());
            mailSettings.put("TO_ADDRESSES", obj.get("ADMIN_MAIL_ID").toString());
            mailSettings.put("ENABLE_HTML_FORMAT",true);
            mailSettings.put("SUBJECT",URLDecoder.decode(GeneralUtil.replaceChar(obj, "SUBJECT"), "utf-8"));
            mailSettings.put("MESSAGE",URLDecoder.decode(GeneralUtil.replaceChar(obj, "MESSAGE"), "utf-8"));
            MailAction.sendMail(mailSettings, serverProps);
            MailHandler.setMailSettings(JSONObjectUtil.merge(mailSettings, serverProps));
            checkIfMailServerIsConfiguredForFirstTime(true);
            result.put("success",true );
        } catch (Exception e) {
            result.put("success",false);
            result.put("error", e.getMessage());
            e.printStackTrace();
            LogWriter.general.severe("ServerSettings.saveMailerSettings " + e); // No I18N
        }
        response.getWriter().print(result.toString());
    }
    
    public static JSONObject sendMail(String subject, String messge,String to_address) throws IOException,JSONException
    {
        LogWriter.general.info("API called: ServerSettings.sendMail()");
        JSONObject mailSettings = MailHandler.getMailSettings();
        JSONObject result = new JSONObject();
        try
        {
            mailSettings.put("ENABLE_HTML_FORMAT",true);
            if(to_address!=null){
                    mailSettings.put("TO_ADDRESSES",to_address);
            }
            mailSettings.put("SUBJECT",subject);
            mailSettings.put("MESSAGE",messge);
            ClassLoader originalClassLoader = Thread.currentThread().getContextClassLoader();
			try{
                MailAction.sendMail(mailSettings,MailHandler.getMailSettings());
                result.put("success", true);
            } catch (Exception e){
                LogWriter.general.severe("ServerSettings.sendMail " + e);// No I18N
                result.put("success",false);
                result.put("error", e.getMessage());
            }
            Thread.currentThread().setContextClassLoader(originalClassLoader);
		}
		catch(Exception e)
		{
            LogWriter.general.severe("ServerSettings.sendMail " + e);// No I18N
			e.printStackTrace();
		}
        return result;
    }

    public static JSONObject sendBulkMail(String subject, String message, String toAddress) throws IOException,JSONException {
        LogWriter.general.info("API called: ServerSettings.sendBulkMail()");
        JSONObject mailSettings = MailHandler.getMailSettings();
        JSONObject result = new JSONObject();
        try {
            mailSettings.put("ENABLE_HTML_FORMAT",true);
            if(toAddress!=null) {
                mailSettings.put("TO_ADDRESSES",toAddress);
            }
            mailSettings.put("SUBJECT",subject);
            mailSettings.put("MESSAGE",message);
            mailSettings.put("DIRECTORY_PATH", IMAGES_DIRECTORY);
            mailSettings.put("ATTACHMENT_TYPE", "IMAGE");
            mailSettings.put("IMG_CONTENT", "rmpMailImages");
            ClassLoader originalClassLoader = Thread.currentThread().getContextClassLoader();
            try {
                MailAction.sendBulkMailMsg(mailSettings,MailHandler.getMailSettings());
                result.put("success", true);
            } catch (Exception e) {
                LogWriter.general.severe("ServerSettings.sendMail " + e);
                result.put("success",false);
            }
            Thread.currentThread().setContextClassLoader(originalClassLoader);
        } catch(Exception e) {
            LogWriter.general.severe("ServerSettings.sendBulkMail " + e);
            e.printStackTrace();
        }
        return result;
    }

    public static void checkIfMailServerIsConfiguredForFirstTime(boolean isConfiguredInADSTable) {
        LogWriter.general.info("API called: ServerSettings.checkIfMailServerIsConfiguredForFirstTime()");
        try {
            // Check if mailSettings is configured in ADSMailSettings table
            if(isConfiguredInADSTable || ServerSettings.getMailerSettings(null).has("ADMIN_MAIL_ID")) {
                // Check if mailSettings is configured in system_params table.
                Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_MAILSERVER_CONFIGURED", QueryConstants.EQUAL, false);
                DataObject dataObj = CommonUtil.getPersistence().get(TableName.RMP_SYSTEM_PARAMS, criteria);
                Row sysParamRow = dataObj.getFirstRow(TableName.RMP_SYSTEM_PARAMS);
                if(!Boolean.parseBoolean(String.valueOf(sysParamRow.get("PARAM_VALUE")))) {
                    Criteria sysParamcriteria = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_MAILSERVER_CONFIGURED", QueryConstants.EQUAL, false);
                    UpdateQuery updateQuery = new UpdateQueryImpl(TableName.RMP_SYSTEM_PARAMS);
                    updateQuery.setCriteria(sysParamcriteria);
                    updateQuery.setUpdateColumn("PARAM_VALUE","true");
                    CommonUtil.getPersistence().update(updateQuery);
                    LogWriter.general.info("ServerSettings : Configuring mail settings for first time - Creating default mail notification template");
                    Notification.setDefaultMailNotification();
                }
            }
        } catch (Exception e) {
            LogWriter.general.severe("ServerSettings.checkIfMailServerIsConfiguredForFirstTime " + e);
            e.printStackTrace();
        }
    }
   
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
//ignoreI18n_end