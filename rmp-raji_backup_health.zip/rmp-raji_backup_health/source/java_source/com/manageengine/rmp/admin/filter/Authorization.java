/**
 * $Id:$
 */
package com.manageengine.rmp.admin.filter;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.delegation.role.RoleConstants;
import com.manageengine.rmp.admin.authentication.RMPAuthConstants;

import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.admin.authentication.RMPAuthErrorCodes;
import com.manageengine.rmp.admin.authentication.ADSAuthHandler;
import com.manageengine.rmp.util.RMPDomainHandler;
import com.manageengine.rmp.util.SessionListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.Filter;
import javax.servlet.FilterConfig;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.ServletException;

import org.json.JSONObject;

/**
 *
 * @author poornima-3055
 */
//ignoreI18n_start
public class Authorization implements Filter {
        
    public static final Long DOMAIN_ACTION = 3L;
    public static final Long COMMON_ACTION = 4L;
    public static final ArrayList<String> domainIdList = new ArrayList<String>(Arrays.asList("DOMAIN_ID", "d", "domainId")); //NO I18N

    private FilterConfig config = null; 
    
    public void init(FilterConfig filterConfig) {
        this.config = filterConfig;
    }

    public void destroy() {
    }

    public void doFilter(ServletRequest servletrequest, ServletResponse servletresponse, FilterChain filterchain) throws IOException, ServletException 
    {
        try {
            HttpServletRequest request = (HttpServletRequest) servletrequest;
            HttpServletResponse response = (HttpServletResponse) servletresponse;
            HttpSession session = (HttpSession) request.getSession();
            String domainName = "",urlPath = request.getRequestURI();
            
            String excludedURLs = this.config.getInitParameter("EXCLUDE_URL_PATTERN");
            if ((excludedURLs != null) && (Pattern.matches(excludedURLs, urlPath)))
            {
                filterchain.doFilter(servletrequest, servletresponse);
                return;
            }
            
            if(request.getParameterMap().containsKey("req")){
                JSONObject reqData = new JSONObject(request.getParameter("req"));
                if(reqData.has("domain")){
                    domainName = reqData.get("domain").toString();
                }else{
                    Long domainId = 0L;
                    for(int i = 0; i < domainIdList.size(); i++){
                        if(reqData.has(domainIdList.get(i))){
                            domainId = reqData.getLong(domainIdList.get(i));   
                            domainName = domainId != 0L ? RMPDomainHandler.getDomainDetailsById(domainId).getProperty("DOMAIN_NAME") : domainName;
                            break;
                        }
                    }
                }
               
                if(urlPath.lastIndexOf(".do")!=-1){
                  if(request.getParameterMap().containsKey("methodToCall")){
                      String method = request.getParameter("methodToCall");
                      urlPath=urlPath+"/"+method;
                  }  else{
                   urlPath=urlPath+"/"+reqData.get("operation").toString();
                  }
                }
            }

            if(checkForAccess(session, urlPath, domainName, response, request)){
                filterchain.doFilter(servletrequest, servletresponse);
            }else{
                JSONObject respData = new JSONObject();
                respData.put("errorCode", RMPAuthErrorCodes.NO_AUTHORIZATION);
                respData.put("errorMsg", "rmp.common.noAuthorization");
                response.getWriter().print(respData);
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.info("Authorization : "+((HttpServletRequest) servletrequest).getServletPath()+ e);// No I18N
        }

    }
    
    public static boolean checkForAccess(HttpSession session, String urlPath, String domainName, HttpServletResponse response, HttpServletRequest request){
        try {
            DataObject dobj = ADSAuthHandler.getActionsDO();
            Criteria criteria = new Criteria(Column.getColumn(RoleConstants.ADS_ACTIONS, "ACTION_URL"), urlPath, QueryConstants.EQUAL);
            Row action = dobj.getRow(RoleConstants.ADS_ACTIONS, criteria); 
           if(action == null){
               return true;
            } 
            Long actionType = (Long)action.get("ACTION_TYPE_ID");                
            boolean isDomainAction = actionType.compareTo(DOMAIN_ACTION) == 0 ? Boolean.TRUE : Boolean.FALSE;
            boolean isCommonAction = actionType.compareTo(COMMON_ACTION) == 0 ? Boolean.TRUE : Boolean.FALSE;
            if(isCommonAction && !domainName.isEmpty()){
                domainName="";
            }
            if(session==null||session.getAttribute(RMPAuthConstants.IS_ALL_DOMAINS_DELEGATED)==null){
     			session = SessionListener.getValidSession(request);	
     			if(session !=null&&session.getAttribute(RMPAuthConstants.IS_ALL_DOMAINS_DELEGATED)!=null){
     				Cookie myCookie = new Cookie("JSESSIONIDRMP", session.getId());
     				response.addCookie(myCookie);	
     				LogWriter.general.info("Changed the session id to valid one !!");
     			}
     			else{
     				LogWriter.general.info("Get session failed !!");
     				return false;
     			}
     	    }
            if(isDomainAction || !domainName.isEmpty()){
                Long roleId = new Long(0);
                if((Boolean)session.getAttribute(RMPAuthConstants.IS_ALL_DOMAINS_DELEGATED)){
                    roleId = ((JSONObject) session.getAttribute(RMPAuthConstants.DOMAIN_VS_ROLES)).getLong(RMPAuthConstants.RMP_AUTHENTICATION);
                }else{
                roleId = ((JSONObject) session.getAttribute(RMPAuthConstants.DOMAIN_VS_ROLES)).getLong(domainName);
                }
                Long actionId = (Long) action.get("ACTION_ID");
                DataObject roledobj = ADSAuthHandler.getRoleVsActionsDO();
                Criteria roleCriteria = new Criteria(Column.getColumn(RoleConstants.ADS_ROLE_VS_ACTIONS, "ROLE_ID"), roleId, QueryConstants.EQUAL);
                Criteria actionCriteria = new Criteria(Column.getColumn(RoleConstants.ADS_ROLE_VS_ACTIONS, "ACTION_ID"), actionId, QueryConstants.EQUAL);
                Row role = roledobj.getRow(RoleConstants.ADS_ROLE_VS_ACTIONS, roleCriteria.and(actionCriteria));   
                return role != null;
            }
            List<Long> userRoles = new ArrayList<Long>();
            if((Boolean)session.getAttribute(RMPAuthConstants.IS_ALL_DOMAINS_DELEGATED)){
                userRoles.add(((JSONObject) session.getAttribute(RMPAuthConstants.DOMAIN_VS_ROLES)).getLong(RMPAuthConstants.RMP_AUTHENTICATION));
            }else{
                userRoles = ((List) session.getAttribute(RMPAuthConstants.USER_ROLES));
            }
            DataObject roledobj = ADSAuthHandler.getAuthorizedActionsDO(userRoles);
            if(!roledobj.isEmpty() && roledobj.getRow(RoleConstants.ADS_ACTIONS, criteria) != null){
                return true;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            LogWriter.general.info("Exception at Authorization.checkForAccess :" + e.getMessage()); // No I18N
        }
        return false;
    }
    
}
//ignoreI18n_end
