package com.manageengine.rmp.admin;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataAccess;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.scheduler.ScheduleManager;
import com.manageengine.rmp.util.DataTypeUtil;

import javax.transaction.SystemException;
import javax.transaction.TransactionManager;
import java.util.ArrayList;
import java.util.HashMap;

//ignoreI18n_start
public class NotificationScheduler {
    public long notificationID;
    public int scheduleFrequency;
    public String hour;
    public String min;
    public int weekMask;
    public int dateMask;

    public NotificationScheduler(int notificationID, String scheduleFrequency, String hour, String min, String weekMask, String dateMask){
        try{
            this.notificationID = notificationID;
            if (weekMask != null) {
                this.weekMask = Integer.parseInt(weekMask);
            }
            if (dateMask != null) {
                this.dateMask = Integer.parseInt(dateMask);
            }
            this.scheduleFrequency = Integer.parseInt(scheduleFrequency);
            this.hour = hour;
            this.min = min;
        } catch (Exception e){
            LogWriter.general.severe("NotificationScheduler.NotificationScheduler(): " + LogWriter.getStackTrace(e));
        }
    }

    public void createSchedule() throws IllegalStateException, SecurityException, SystemException {
        TransactionManager txn = DataAccess.getTransactionManager();
        try{
            txn.begin();
            HashMap<String, String> dataInputTask = new HashMap<String, String>();
            dataInputTask.put("NotificationID", String.valueOf(notificationID));
            String scheduleAppend = "_" + notificationID + "_";
            ScheduleManager scheduleManager = new ScheduleManager("Notification" + scheduleAppend, "com.manageengine.rmp.admin.NotificationTask", "Notification" + scheduleAppend);
            int hours = Integer.parseInt(hour);
            int minutes = Integer.parseInt(min);
            long scheduleId = 0L;
            if (scheduleFrequency == 0) {
                int[] selectedDates = intToIntArray(dateMask);
                scheduleId = scheduleManager.setInfiniteMonthlySchedule(hours, minutes,selectedDates);
            }
            else if (scheduleFrequency == 1) {
                scheduleId = scheduleManager.setInfiniteDailySchedule(hours, minutes);
            }
            else if (scheduleFrequency == 2) {
                int[] selectedDays = intToIntArray(weekMask);
                scheduleId = scheduleManager.setInfiniteWeeklySchedule(hours, minutes, selectedDays);
            }
            scheduleManager.scheduleTask(dataInputTask);
            updateNotificationSettingsTable(this.notificationID, scheduleId);
            txn.commit();
        } catch (Exception e){
            LogWriter.general.severe("NotificationScheduler.createSchedule(): " + LogWriter.getStackTrace(e));
            txn.rollback();
        }
    }

    private static int[] intToIntArray(int param) {
        ArrayList<Integer> list = new ArrayList<Integer>();
        list.add(param);
        return DataTypeUtil.getArrayListAsIntArray(list);
    }

    private static void updateNotificationSettingsTable(long notificationID, long scheduleID){
        try{
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_NOTIFICAITON_SETTINGS, "UNIQUE_ID"), notificationID, QueryConstants.EQUAL);
            UpdateQuery upquery = new UpdateQueryImpl(TableName.RMP_NOTIFICAITON_SETTINGS);
            upquery.setUpdateColumn("SCHEDULE_ID", scheduleID);
            upquery.setCriteria(criteria);
            CommonUtil.getPersistence().update(upquery);
        } catch (Exception e){
            LogWriter.general.severe("NotificationScheduler.updateNotificationSettingsTable(): " + LogWriter.getStackTrace(e));
        }
    }

    public static boolean deleteSchedule(Long scheduleId) throws SystemException {
        TransactionManager txn = DataAccess.getTransactionManager();
        try {
            txn.begin();
            ScheduleManager.deleteSchedule(scheduleId);
            txn.commit();
            return true;
        } catch (Exception e) {
            txn.rollback();
            LogWriter.general.severe("NotificationScheduler.deleteSchedule(): " + LogWriter.getStackTrace(e));
            return false;
        }
    }
}
//ignoreI18n_end