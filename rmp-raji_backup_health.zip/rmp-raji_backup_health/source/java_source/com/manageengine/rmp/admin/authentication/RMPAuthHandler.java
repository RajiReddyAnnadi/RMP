/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.admin.authentication;


import com.adventnet.authentication.PAMException;

import com.adventnet.authentication.AAAACCADMINPROFILE;
import com.adventnet.authentication.AAAACCBADLOGINSTATUS;
import com.adventnet.authentication.AAAACCOUNT;
import com.adventnet.authentication.AAAACCOUNTSTATUS;
import com.adventnet.authentication.AAAACCPASSWORD;
import com.adventnet.authentication.AAAAUTHORIZEDROLE;
import com.adventnet.authentication.AAALOGIN;
import com.adventnet.authentication.AAAPASSWORD;
import com.adventnet.authentication.AAAPASSWORDPROFILE;
import com.adventnet.authentication.AAAPASSWORDSTATUS;
import com.adventnet.authentication.AAAROLE;
import com.adventnet.authentication.AAASERVICE;
import com.adventnet.authentication.AAAUSER;
import com.adventnet.authentication.AAAUSERPROFILE;
import com.adventnet.authentication.AAAUSERSTATUS;
import com.adventnet.ds.query.*;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.*;
import com.adventnet.persistence.DataObject;
import com.manageengine.ads.fw.jni.ADSNativeHandler;
import com.manageengine.ads.fw.ldap.ad.ADSADException;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.TableName;
import java.util.ArrayList;
import java.util.Properties;
import javax.security.auth.login.LoginException;

/**
 *
 * @author suganya-1815
 */
//ignoreI18n_start
public class RMPAuthHandler {
    public static DataObject getAccountDO(String loginName, String serviceName, String domainName) throws DataAccessException {
        LogWriter.general.info("fetching account dataobject for loginname : "+ loginName +"service : "+ serviceName);
        DataObject accountDobj = null;
        SelectQuery query = new SelectQueryImpl(new Table(AAALOGIN.TABLE));
        query.addSelectColumn(new Column(null, "*"));
        query.addJoin(new Join(AAALOGIN.TABLE, AAAUSER.TABLE, 
            new String [] {AAALOGIN.USER_ID}, new String [] {AAAUSER.USER_ID},
            Join.INNER_JOIN));
        query.addJoin(new Join(AAAUSER.TABLE, AAAUSERSTATUS.TABLE,
            new String [] {AAAUSER.USER_ID}, new String [] {AAAUSERSTATUS.USER_ID},
            Join.INNER_JOIN));
        query.addJoin(new Join(AAAUSER.TABLE, AAAUSERPROFILE.TABLE,
            new String [] {AAAUSER.USER_ID}, new String [] {AAAUSERPROFILE.USER_ID},
            Join.LEFT_JOIN));
        query.addJoin(new Join(AAALOGIN.TABLE, AAAACCOUNT.TABLE,
            new String [] {AAALOGIN.LOGIN_ID}, new String [] {AAAACCOUNT.LOGIN_ID},
            Join.INNER_JOIN));
        query.addJoin(new Join(AAAACCOUNT.TABLE, AAAACCOUNTSTATUS.TABLE,
            new String [] {AAAACCOUNT.ACCOUNT_ID}, new String [] {AAAACCOUNTSTATUS.ACCOUNT_ID},
            Join.LEFT_JOIN));
        query.addJoin(new Join(AAAACCOUNT.TABLE, AAAACCBADLOGINSTATUS.TABLE,
            new String [] {AAAACCOUNT.ACCOUNT_ID}, new String [] {AAAACCBADLOGINSTATUS.ACCOUNT_ID},
            Join.LEFT_JOIN));
        query.addJoin(new Join(AAAACCOUNT.TABLE, AAAACCADMINPROFILE.TABLE,
            new String [] {AAAACCOUNT.ACCOUNTPROFILE_ID}, new String [] {AAAACCADMINPROFILE.ACCOUNTPROFILE_ID},
            Join.LEFT_JOIN));
        query.addJoin(new Join(AAAACCOUNT.TABLE, AAASERVICE.TABLE,
            new String [] {AAAACCOUNT.SERVICE_ID}, new String [] {AAASERVICE.SERVICE_ID},
            Join.INNER_JOIN));
        query.addJoin(new Join(AAAACCOUNT.TABLE, AAAACCPASSWORD.TABLE, 
            new String [] {AAAACCOUNT.ACCOUNT_ID}, new String [] {AAAACCPASSWORD.ACCOUNT_ID},
            Join.LEFT_JOIN));
        query.addJoin(new Join(AAAACCPASSWORD.TABLE, AAAPASSWORD.TABLE,
            new String [] {AAAACCPASSWORD.PASSWORD_ID}, new String [] {AAAPASSWORD.PASSWORD_ID},
            Join.INNER_JOIN));
        query.addJoin( new Join (AAAPASSWORD.TABLE, AAAPASSWORDPROFILE.TABLE, 
            new String [] {AAAPASSWORD.PASSWDPROFILE_ID}, new String [] {AAAPASSWORDPROFILE.PASSWDPROFILE_ID},
            Join.LEFT_JOIN));
        query.addJoin( new Join (AAAPASSWORD.TABLE, AAAPASSWORDSTATUS.TABLE,
            new String [] {AAAPASSWORD.PASSWORD_ID}, new String [] {AAAPASSWORDSTATUS.PASSWORD_ID},
            Join.LEFT_JOIN));
        query.addJoin(new Join(AAAACCOUNT.TABLE, AAAAUTHORIZEDROLE.TABLE,
            new String [] {AAAACCOUNT.ACCOUNT_ID}, new String [] {AAAAUTHORIZEDROLE.ACCOUNT_ID},
            Join.LEFT_JOIN));
        query.addJoin(new Join(AAAAUTHORIZEDROLE.TABLE, AAAROLE.TABLE,
            new String [] {AAAAUTHORIZEDROLE.ROLE_ID}, new String [] {AAAROLE.ROLE_ID},
            Join.LEFT_JOIN));
        Criteria criteria = new Criteria( new Column(AAASERVICE.TABLE, AAASERVICE.NAME), serviceName, QueryConstants.EQUAL,false);
        criteria = criteria.and( new Criteria(new Column(AAALOGIN.TABLE, AAALOGIN.NAME), loginName, QueryConstants.EQUAL,false));
        criteria = criteria.and( new Criteria(new Column(AAALOGIN.TABLE, "DOMAINNAME"), domainName, QueryConstants.EQUAL,false));
        query.setCriteria(criteria);
        try {
            accountDobj = DataAccess.get(query);
            LogWriter.general.info("account data object fetched for login : "+ loginName +"and service : "+ serviceName +" is : "+ accountDobj);
            if(!accountDobj.containsTable(AAAACCOUNT.TABLE)) {
                Criteria criteriaForSys = new Criteria( new Column(AAASERVICE.TABLE, AAASERVICE.NAME), "System", QueryConstants.EQUAL);
                criteriaForSys = criteriaForSys.and( new Criteria(new Column(AAALOGIN.TABLE, AAALOGIN.NAME), loginName, QueryConstants.EQUAL));
                criteriaForSys = criteriaForSys.and( new Criteria(new Column(AAALOGIN.TABLE, "DOMAINNAME"), domainName, QueryConstants.EQUAL));
                SelectQuery clonedQuery = (SelectQuery) query.clone();
                clonedQuery.setCriteria(criteriaForSys);
                accountDobj = DataAccess.get(clonedQuery);
                LogWriter.general.info("account data object fetched for login : "+ loginName +" and service : System is : "+ accountDobj);
            }
        }
        catch(Exception e) {
            throw new DataAccessException("Exception occurred while fetching account dataobject", e);
        }
        return accountDobj;
    }   
    
    public static boolean isValidAccount(DataObject accountDO) throws LoginException {
        try {
            if (accountDO == null) {
                throw new PAMException("rmp.login.common.error.dataobject_null");
            }
            if (!accountDO.containsTable(TableName.AAAACCOUNT)) {
                throw new LoginException("rmp.login.common.error.no_such_account_for_choosen_domain");
            }
            if (!accountDO.containsTable(TableName.AAAPASSWORD)) {
                throw new LoginException("rmp.login.common.error.no_password_configured");
            }
            if(!accountDO.containsTable(TableName.AAAUSERSTATUS))
            {
                    throw new LoginException("rmp.login.common.error.no_such_user_configured");
            }
            if(!accountDO.containsTable(TableName.AAAACCOUNTSTATUS))
            {
                    throw new LoginException("rmp.login.common.error.no_such_accnt_configured");
            }
        } catch (Exception e) {
            throw new LoginException(e.getMessage());
        }
        return true;
    }

   public static ArrayList getLoginUserDetails(String upn,Properties domainDetails)throws Exception {
    ArrayList attributeList = new ArrayList();
    ArrayList list = new ArrayList();
    attributeList.add("sAMAccountName");attributeList.add("objectGUID");attributeList.add("userPrincipalName");
     attributeList.add("distinguishedName");attributeList.add("objectSid");	
    String searchString = "(&(objectClass=user)(objectCategory=person)(userPrincipalName=" + upn + "))";
    try{
   list = ADSNativeHandler.getObjectsWithOutListener(domainDetails, domainDetails.getProperty("DEFAULT_NAMING_CONTEXT"),attributeList, searchString);
    }catch(Exception e){
         throw new Exception(e.getMessage());
        }
    return list;
    }

    public static String authenticateUser(String serverName,String domainName, String loginName, String password, String isSSL)throws Exception {
       String result="";
       try{
           Properties retVal=ADSNativeHandler.DomainUserADAuth(serverName,domainName,loginName,password,isSSL);
            if(retVal.containsKey("Status")&&retVal.containsKey("IsAuthenticated")){
                if(((String)retVal.get("Status")).equals("SUCCESS")&&((String)retVal.get("IsAuthenticated")).equals("true")){       
                    result = "success";
                }else{
                   result = ADSNativeHandler.getLoginStatusMsg(retVal.getProperty("Status"));
                }
            }else{
             result = "ads.login.common.error.invalid_login";
            }
            
        }
       catch(ADSADException ex){
           LogWriter.general.info("RMPAuthHandler.authenticateUser: exception"+ex.getMessage());
           return getLoginErrorMessage(ex.getExceptionMsg());
       }
       catch(Exception e) {
            throw new Exception(e.getMessage());
        }
       return result;
    }
    
    public static String getLoginErrorMessage(String errorMsg){
       
        if (errorMsg.contains("servers_not_operational")) {
            errorMsg = "ads.login.common.error.server_not_operational";
        }
        else{
            errorMsg = "ads.login.common.error.invalid_login"; 
        }
        return errorMsg;
    }
    
    public static Long getUserId(String loginName, String domainName) throws DataAccessException
  {
    try
    {
      ReadOnlyPersistence rpers = (ReadOnlyPersistence)BeanUtil.lookup("PureCachedPersistence");
      Criteria crit = new Criteria(Column.getColumn("AaaLogin", "NAME"), loginName, QueryConstants.EQUAL, false);
      crit = crit.and(new Criteria(Column.getColumn("AaaLogin", "DOMAINNAME"), domainName, QueryConstants.EQUAL, false));
      DataObject aaaLoginDO = rpers.get("AaaLogin", crit);
      return (Long)aaaLoginDO.getRow("AaaLogin").get(2);
    }
    catch (Exception e) {
    }
    throw new DataAccessException("Exception occurred while fetching userID for loginName :: [" + loginName + "] and domainName :: [" + domainName + "]");
  }
}
//ignoreI18n_end
