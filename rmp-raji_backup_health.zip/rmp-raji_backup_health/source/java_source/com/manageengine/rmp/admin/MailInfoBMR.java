package com.manageengine.rmp.admin;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.i18n.ADSResourceBundle;
import com.manageengine.ads.fw.i18n.I18NUtil;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.DateUtil;
import com.manageengine.me.util.JSONArrayUtil;
import com.manageengine.rmp.admin.constants.NotificationType;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.i18n.Rmpi18n;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.util.RMPDomainHandler;
import com.manageengine.rmp.virtual.repository.VMRepositoryServer;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
//ignoreI18n_start
public class MailInfoBMR {

    public static JSONObject setBMRBackupMailInfo (long operationID) {
        LogWriter.general.info("API called: MailInfoBMR.setBMRBackupMailData()");
        JSONObject mailData = new JSONObject();
        try {
            JSONObject commonData = new JSONObject();
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "*"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_NAME"));
            Join join = new Join(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, TableName.BMR_DOMAIN_CONTROLLERS, new String[] {"DC_ID"}, new String[] {"DC_ID"}, Join.LEFT_JOIN);
            selectQuery.addJoin(join);
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"), operationID, QueryConstants.EQUAL);
            selectQuery.setCriteria(criteria);
            DataObject dataObj = CommonUtil.getPersistence().get(selectQuery);
            Iterator rows = dataObj.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
            Iterator rows1 = dataObj.getRows(TableName.BMR_DOMAIN_CONTROLLERS);
            if(rows.hasNext()) {
                Row row = (Row) rows.next() ;
                Row row1 = (Row)rows1.next();

                long domainId = (long)row1.get("DOMAIN_ID");
                String dcName = (String) row1.get("DC_NAME");
                String backupMode = (String) row.get("BACKUP_MODE");
                String status = (String) row.get("STATUS");
                String message = "", generalInfoStatus = "";
                boolean isSuccess = false;
                String successString = "";
                if(status.equalsIgnoreCase("Completed")) {
                    isSuccess = true;
                    successString = generalInfoStatus = "Success";
                    message = resBundle.getString("rmp.mail.backup_completed");
                }
                else if(status.contains("Failed")) {
                    successString = generalInfoStatus = "Failed";
                    message = resBundle.getString("rmp.mail.backup_failed");
                }
                else if(status.equalsIgnoreCase("Application Interrupted")) {
                    successString = generalInfoStatus = "Interrupted";
                    message = resBundle.getString("rmp.mail.backup_interrupted");
                }
                message += " " + resBundle.getString("rmp.mail.common.please_find_info_below");

                JSONObject generalInfo = new JSONObject();
                generalInfo.put("%STATUS%", generalInfoStatus);
                generalInfo.put("%DOMAIN_NAME%", RMPDomainHandler.getDomainDetailsById(domainId).getProperty("DOMAIN_NAME"));
                generalInfo.put("%INITIATED_BY%", (String)row.get("INITIATOR"));
                generalInfo.put("%DC_NAME%", dcName);
                if (status.equalsIgnoreCase("Application Interrupted") || (status.contains("Failed") && ((Long) row.get("TIME_TAKEN")).equals(0L))) {
                    generalInfo.put("%TIME_TAKEN%", "-");
                }
                else {
                    generalInfo.put("%TIME_TAKEN%", DateUtil.millisecondsToTime(((long) row.get("TIME_TAKEN")) * 1000));
                }
                generalInfo.put("%START_TIME%", MailTemplate.getMailDateFormat().format((Timestamp) row.get("START_TIME")));
                generalInfo.put("%BACKUP_TYPE%", getBackupTypeString((String) row.get("BACKUP_TYPE")));
                generalInfo.put("%BACKUP_MODE%", backupMode);
                generalInfo.put("%TOTAL_SIZE%", getBackupSize((double) row.get("SIZE")));
                generalInfo.put("%MESSAGE%", message);

                long repoId = (Long) row.get("REPOSITORY_ID");
                JSONObject repoDetails = VMRepositoryServer.getBackupRepository(repoId).getJSONObject("selectedValue");
                String repoName = repoDetails.get("REPOSITORY_NAME").toString();
                String repoPath = repoDetails.get("REPOSITORY_PATH").toString();
                generalInfo.put("%REPOSITORY_NAME%", repoName);
                generalInfo.put("%REPOSITORY_PATH%", repoPath);

                int successCount = 0, failureCount = 0;
                JSONArray partitionInfo = new JSONArray();
                JSONObject filesInfo = new JSONObject();
                JSONArray partitionInfoArray = new JSONArray();

                String partitioninfo = (String)row.get("PARTITIONS_INFO");
                if(!partitioninfo.equals("")) {
                    partitionInfoArray = new JSONArray(partitioninfo);
                }

                for(int i = 0; i < partitionInfoArray.length(); i++) {
                    JSONObject partition = partitionInfoArray.getJSONObject(i);
                    String name = partition.getString("name"), partitionStatus = partition.getString("status");
                    if(backupMode.equalsIgnoreCase("FLR")) {
                        if(StringUtils.containsIgnoreCase(partitionStatus, "Success") || StringUtils.containsIgnoreCase(partitionStatus, "Not modified")) {
                            successCount++;
                        } else  {
                            failureCount++;
                        }
                    }
                    else {
                        JSONObject partitionDetails = new JSONObject();
                        partitionDetails.put("%DRIVE_NAME%", name);
                        partitionDetails.put("%STATUS%", partitionStatus);
                        partitionDetails.put("%DRIVE_SIZE%", String.format("%.1f %s", partition.getDouble("size"), partition.getString("sizeUnit")));
                        String timeUnit = partition.getString("timeUnit");
                        String time = "";
                        if(timeUnit.equalsIgnoreCase("hrs") || timeUnit.equalsIgnoreCase("mins")){
                            time = partition.getString("timeHr") + " hr " + partition.getString("timeMin") + " min";
                        }
                        else if(timeUnit.equalsIgnoreCase("secs")) {
                            time = partition.getString("timeSec") + " sec";
                        }
                        partitionDetails.put("%TIME_TAKEN%", time);
                        partitionInfo.put(partitionDetails);
                    }
                }

                if(!isSuccess) {
                    commonData.put("%ERROR%", status);
                    commonData.put("%TIPS_TROUBLESHOOT%", getBackupTroubleShootingTipsFromStatus(status));
                }

                mailData.put("domainId", domainId);
                mailData.put("dcName", dcName);
                mailData.put("backupMode", getBackupModeString(backupMode));
                mailData.put("status", isSuccess);
                mailData.put("generalInfo", generalInfo);
                mailData.put("commonData", commonData);
                mailData.put("successString", successString);

                if(backupMode.equalsIgnoreCase("FLR")) {
                    filesInfo.put("%SUCCESS_COUNT%", successCount);
                    filesInfo.put("%FAILURE_COUNT%", failureCount);
                    filesInfo.put("%TOTAL_COUNT%", successCount + failureCount);
                    mailData.put("filesInfo", filesInfo);
                }
                else {
                    mailData.put("partitionInfo", partitionInfo);
                }
            }
        } catch (Exception e) {
            LogWriter.general.severe("MailInfoBMR.setBMRBackupMailData: " + LogWriter.getStackTrace(e));
        }
        return mailData;
    }

    public static JSONObject setBMRRestoreMailInfo (long operationID) {
        LogWriter.general.info("API called: MailInfoBMR.setBMRRestoreMailInfo()");
        JSONObject mailData = new JSONObject();
        try {
            JSONObject commonData = new JSONObject();
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "*"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_NAME"));
            Join join = new Join(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, TableName.BMR_DOMAIN_CONTROLLERS, new String[]{"DC_ID"}, new String[]{"DC_ID"}, Join.LEFT_JOIN);
            selectQuery.addJoin(join);
            Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "OPERATION_ID"), operationID, QueryConstants.EQUAL);
            selectQuery.setCriteria(criteria);
            DataObject dataObj = CommonUtil.getPersistence().get(selectQuery);
            Iterator rows = dataObj.getRows(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS);
            Iterator rows1 = dataObj.getRows(TableName.BMR_DOMAIN_CONTROLLERS);
            if (rows.hasNext()) {
                Row row = (Row) rows.next();
                Row row1 = (Row) rows1.next();

                long domainId = (long) row1.get("DOMAIN_ID");
                String dcName = (String) row1.get("DC_NAME");
                String status = (String) row.get("STATUS");
                String restoreType = (String) row.get("RESTORE_TYPE");
                String message = "", generalInfoStatus = "";
                boolean isSuccess = false;
                String successString = "";
                if (status.equalsIgnoreCase("Completed")) {
                    isSuccess = true;
                    successString = generalInfoStatus = "Success";
                    message = resBundle.getString("rmp.mail.restore_completed");
                } else if (status.contains("Failed")) {
                    successString = generalInfoStatus = "Failed";
                    message = resBundle.getString("rmp.mail.restore_failed");
                } else if (status.equalsIgnoreCase("Application Interrupted")) {
                    successString = generalInfoStatus = "Interrupted";
                    message = resBundle.getString("rmp.mail.restore_interrupted");
                }
                message += " " + resBundle.getString("rmp.mail.common.please_find_info_below");

                JSONObject generalInfo = new JSONObject();
                generalInfo.put("%STATUS%", generalInfoStatus);
                generalInfo.put("%DOMAIN_NAME%", RMPDomainHandler.getDomainDetailsById(domainId).getProperty("DOMAIN_NAME"));
                generalInfo.put("%INITIATED_BY%", (String)row.get("INITIATOR"));
                generalInfo.put("%DC_NAME%", dcName);
                if ((status.equalsIgnoreCase("Application Interrupted")) || (status.contains("Failed") && ((Long) row.get("TIME_TAKEN")).equals(0L))) {
                    generalInfo.put("%TIME_TAKEN%", "-");
                }
                else {
                    generalInfo.put("%TIME_TAKEN%", DateUtil.millisecondsToTime(((long) row.get("TIME_TAKEN")) * 1000));
                }
                generalInfo.put("%START_TIME%", MailTemplate.getMailDateFormat().format((Timestamp) row.get("START_TIME")));
                generalInfo.put("%RESTORE_POINT%", MailTemplate.getMailDateFormat().format((Timestamp)row.get("BACKUP_TIME")));
                generalInfo.put("%RESTORE_TYPE%", restoreType);
                generalInfo.put("%MESSAGE%", message);

                JSONObject restoreInfo = new JSONObject();
                JSONArray filesListMailData = new JSONArray();
                if (!successString.equalsIgnoreCase("Interrupted")) {
                    String filesInfoFromDB = (String) row.get("FILES_TO_RESTORE");
                    JSONArray filesListArray = new JSONArray();
                    int successCount = 0, failureCount = 0;
                    if(!filesInfoFromDB.equals("")) {
                        filesListArray = new JSONArray(filesInfoFromDB);
                    }
                    for(int i = 0; i < filesListArray.length(); i++) {
                        JSONObject fileInfo = filesListArray.getJSONObject(i);
                        String fileStatus = fileInfo.getString("status");
                        if(fileStatus.equalsIgnoreCase("success")) {
                            successCount++;
                        } else {
                            failureCount++;
                        }
                        if(restoreType.equalsIgnoreCase("VLR")) {
                            JSONObject fileInfoMailData = new JSONObject();
                            fileInfoMailData.put("%NAME%", fileInfo.getString("name"));
                            fileInfoMailData.put("%STATUS%", fileStatus);
                            fileInfoMailData.put("%TIME_TAKEN%", DateUtil.millisecondsToTime(Integer.parseInt(fileInfo.getString("TimeTaken")) * 1000));
                            filesListMailData.put(fileInfoMailData);
                        }
                    }
                    restoreInfo.put("%TOTAL_COUNT%", successCount + failureCount);
                    restoreInfo.put("%SUCCESS_COUNT%", successCount);
                    restoreInfo.put("%FAILURE_COUNT%", failureCount);
                }
                else {
                    restoreInfo.put("%TOTAL_COUNT%", "-");
                    restoreInfo.put("%SUCCESS_COUNT%", "-");
                    restoreInfo.put("%FAILURE_COUNT%", "-");
                }
                Long restoreOption = (Long) row.get("RESTORE_OPTION");
                String copyToPath = (String)row.get("DOWNLOAD_PATH");
                String restoreOptionString = getRestoreType(restoreOption.intValue()).replace("%COPY_TO_DESTINATION%", (copyToPath==null)?"":" " + copyToPath);
                restoreInfo.put("%RESTORE_OPTION%", restoreOptionString);

                if(!isSuccess) {
                    commonData.put("%ERROR%", status);
                    commonData.put("%TIPS_TROUBLESHOOT%", getRestoreTroubleShootingTipsFromStatus(status));
                }

                mailData.put("status", isSuccess);
                mailData.put("domainId", domainId);
                mailData.put("restoreType", getBackupModeString(restoreType));
                mailData.put("dcName", dcName);
                mailData.put("generalInfo", generalInfo);
                mailData.put("restoreInfo", restoreInfo);
                mailData.put("commonData", commonData);
                mailData.put("successString", successString);

                if(restoreType.equalsIgnoreCase("VLR")) {
                    mailData.put("filesInfo", filesListMailData);
                }
            }
        } catch (Exception e) {
            LogWriter.general.severe("MailInfoBMR.setBMRBackupMailData: " + LogWriter.getStackTrace(e));
        }
        return mailData;
    }

    public static JSONArray setBMRScheduledMailInfo(boolean isAllDomainsSelected, JSONArray bmrDomains, JSONArray bmrOperationsConfigured, java.util.Date fromDate, java.util.Date toDate) {
        LogWriter.general.info("API Called: MailInfoBMR.setBMRScheduledMailData()");
        JSONArray bmrMailData = new JSONArray();
        ArrayList<Integer> operationsConfigured = JSONArrayUtil.toArrayList(bmrOperationsConfigured);
        try{
            if(isAllDomainsSelected) {
                bmrDomains = MailTemplate.getAllDomainIDs();
            }
            for(int i = 0; i < bmrDomains.length(); i++) {
                int totalCount = 0, successCount = 0, failureCount = 0;
                long domainID = bmrDomains.getLong(i);
                JSONObject domainData = new JSONObject();
                domainData.put("domainName", RMPDomainHandler.getDomainDetailsById(domainID).getProperty("DOMAIN_NAME"));
                JSONArray operationDetails = new JSONArray();
                // Backup
                if(operationsConfigured.contains(NotificationType.BMRBackup.ordinal())) {
                    JSONObject operationData = new JSONObject();
                    SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS));
                    selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "OPERATION_ID"));
                    selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "STATUS"));
                    Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "DC_ID"), getBMRDcs(domainID).toArray(), QueryConstants.IN);
                    Criteria fromDateCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME"), DateUtil.getTimestampFromDate(fromDate), QueryConstants.GREATER_THAN);
                    Criteria toDateCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS, "START_TIME"), DateUtil.getTimestampFromDate(toDate), QueryConstants.LESS_THAN);
                    selectQuery.setCriteria(criteria.and(fromDateCriteria).and(toDateCriteria));
                    DataObject dataObj = CommonUtil.getPersistence().get(selectQuery);
                    Iterator rows = dataObj.getRows(TableName.BMR_INDIVIDUAL_BACKUP_DETAILS);
                    while (rows.hasNext()) {
                        Row row = (Row) rows.next() ;
                        String status = (String) row.get("STATUS");
                        if(status.equalsIgnoreCase("Completed")) {
                            successCount++;
                            totalCount++;
                        }
                        else if(status.contains("Failed") || status.equalsIgnoreCase("Application Interrupted")) {
                            failureCount++;
                            totalCount++;
                        }
                    }
                    operationData.put("operation", NotificationType.BMRBackup.ordinal());
                    operationData.put("totalCount", totalCount);
                    operationData.put("successCount", successCount);
                    operationData.put("failureCount", failureCount);
                    operationDetails.put(operationData);
                }
                totalCount = successCount = failureCount = 0;
                if(operationsConfigured.contains(NotificationType.BMRRestore.ordinal())) {
                    JSONObject operationData = new JSONObject();
                    SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS));
                    selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "OPERATION_ID"));
                    selectQuery.addSelectColumn(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "STATUS"));
                    Criteria criteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "DC_ID"), getBMRDcs(domainID).toArray(), QueryConstants.IN);
                    Criteria fromDateCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "START_TIME"), DateUtil.getTimestampFromDate(fromDate), QueryConstants.GREATER_THAN);
                    Criteria toDateCriteria = new Criteria(Column.getColumn(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS, "START_TIME"), DateUtil.getTimestampFromDate(toDate), QueryConstants.LESS_THAN);
                    selectQuery.setCriteria(criteria.and(fromDateCriteria).and(toDateCriteria));
                    DataObject dataObj = CommonUtil.getPersistence().get(selectQuery);
                    Iterator rows = dataObj.getRows(TableName.BMR_INDIVIDUAL_RESTORE_DETAILS);
                    while (rows.hasNext()) {
                        Row row = (Row) rows.next() ;
                        String status = (String) row.get("STATUS");
                        if(status.equalsIgnoreCase("Completed")) {
                            successCount++;
                            totalCount++;
                        }
                        else if(status.contains("Failed") || status.equalsIgnoreCase("Application Interrupted")) {
                            failureCount++;
                            totalCount++;
                        }
                    }
                    operationData.put("operation", NotificationType.BMRRestore.ordinal());
                    operationData.put("totalCount", totalCount);
                    operationData.put("successCount", successCount);
                    operationData.put("failureCount", failureCount);
                    operationDetails.put(operationData);
                }
                domainData.put("operationDetails", operationDetails);
                bmrMailData.put(domainData);
            }
        } catch (Exception e) {
            LogWriter.general.severe("MailInfoBMR.setBMRScheduledMailData: " + LogWriter.getStackTrace(e));
        }
        return bmrMailData;
    }

    public static ArrayList<Long> getBMRDcs(long domainId) {
        ArrayList<Long> dcs = new ArrayList<Long>();
        try {
            SelectQueryImpl query = new SelectQueryImpl(Table.getTable(TableName.BMR_DOMAIN_CONTROLLERS));
            query.addSelectColumn(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DC_ID"));
            Criteria dcCriteria = new Criteria(Column.getColumn(TableName.BMR_DOMAIN_CONTROLLERS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            query.setCriteria(dcCriteria);
            DataObject dobj = CommonUtil.getPersistence().get(query);
            Iterator iterator = dobj.getRows(TableName.BMR_DOMAIN_CONTROLLERS);
            while (iterator.hasNext()) {
                Row row = (Row) iterator.next();
                dcs.add((Long) row.get("DC_ID"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dcs;
    }

    public static String getISOCreationMessage() {
        try{
            String isoCreationMessage = "";
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_SYSTEM_PARAMS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_NEWISO_CREATED", QueryConstants.EQUAL);
            selectQuery.setCriteria(criteria);
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            Iterator rows = dataObject.getRows(TableName.RMP_SYSTEM_PARAMS);
            if(rows.hasNext()) {
                if(((String)((Row) rows.next()).get("PARAM_VALUE")).equalsIgnoreCase("false")) {
                    ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
                    isoCreationMessage = resBundle.getString("rmp.mail.BMR.create_new_iso");
                }
            }
            return isoCreationMessage;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private static String getBackupTroubleShootingTipsFromStatus(String status) {
        try{
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            String tipsTroubleshoot = resBundle.getString("rmp.mail.troubleshoot.default");
            if(status.equalsIgnoreCase("Failed (Could not contact Agent)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.cannot_contact_agent");
            }
            else if(status.equalsIgnoreCase("Failed (Location inaccessible from Server)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.backup_location_inaccessible");
            }
            else if(status.equalsIgnoreCase("Failed (Location inaccessible)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.backup_location_inaccessible_server");
            }
            else if(status.equalsIgnoreCase("Failed (Insufficient space in storage)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.space_insufficient");
            }
            else if(status.equalsIgnoreCase("Failed (Please try again)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.troubleshoot.default");
            }
            else if(status.equalsIgnoreCase("Failed (Retry Agent installation)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.retry_agent_installation");
            }
            else if(status.equalsIgnoreCase("Failed (Server has been deleted)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.server_accessible_over_network");
            }
            else if(status.equalsIgnoreCase("Failed (Access Denied)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.update_credentials");
            }
            else if(status.equalsIgnoreCase("Failed (Perform a successful full backup)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.perform_full_backup");
            }
            else if(status.equalsIgnoreCase("Failed")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.unknown_error");
            }
            else if(status.equalsIgnoreCase("Application Interrupted")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.troubleshoot.default");
            }
            else if(status.equalsIgnoreCase("Failed (Repository disabled)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.enable_repository");
            }
            else if(status.equalsIgnoreCase("Failed (Repository deleted)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.select_another_repository");
            }
            else if(status.equalsIgnoreCase("Failed (Volume(s) not found)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.update_volumes_selected");
            }
            else if(status.equalsIgnoreCase("Failed (Error in tracking changes)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.error_in_incremental_backup");
            }
            else if(status.equalsIgnoreCase("Failed (Partition count is different)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.partition_count_different");
            }
            else if(status.equalsIgnoreCase("Failed (License has expired)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.upgrade_license");
            }
            else if(status.equalsIgnoreCase("Failed (Access denied to the repository)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.update_repository_credentials");
            }
            return tipsTroubleshoot;
        } catch(Exception e){
            e.printStackTrace();
            return "";
        }
    }

    private static String getRestoreTroubleShootingTipsFromStatus(String status) {
        try {
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            String tipsTroubleshoot = resBundle.getString("rmp.mail.troubleshoot.default");
            if(status.equalsIgnoreCase("Failed (Could not contact Agent)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.cannot_contact_agent_restore");
            }
            else if(status.equalsIgnoreCase("Failed (Location inaccessible from Server)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.backup_location_inaccessible");
            }
            else if(status.equalsIgnoreCase("Failed (Location inaccessible)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.backup_location_inaccessible_server");
            }
            else if(status.equalsIgnoreCase("Failed (Insufficient space in the destination)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.insufficient_space");
            }
            else if(status.equalsIgnoreCase("Failed (Server has been deleted)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.server_accessible_over_network");
            }
            else if(status.equalsIgnoreCase("Failed (Retry Agent installation)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.retry_agent_installation");
            }
            else if(status.equalsIgnoreCase("Failed (Volume(s) not found)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.update_volumes_selected");
            }
            else if(status.equalsIgnoreCase("Failed (Few files failed)")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.few_files_failed");
            }
            else if(status.equalsIgnoreCase("Failed")) {
                tipsTroubleshoot = resBundle.getString("rmp.mail.BMR.troubleshoot.unknown_error_during_restore");
            }
            return tipsTroubleshoot;
        } catch(Exception e){
            e.printStackTrace();
            return "";
        }
    }

    public static String getBackupModeString(String backupMode) {
        String returnValue = "";
        try {
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            if(backupMode.equalsIgnoreCase("BMR") || backupMode.equalsIgnoreCase("OLD BMR")) {
                returnValue = resBundle.getString("rmp.bmr.backup_mode.bmr");
            } else if(backupMode.equalsIgnoreCase("FLR")) {
                returnValue = resBundle.getString("rmp.bmr.backup_mode.flr");
            } else if(backupMode.equalsIgnoreCase("VLR")) {
                returnValue = resBundle.getString("rmp.bmr.backup_mode.vlr");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnValue;
    }

    private static String getBackupTypeString(String backupType) {
        String returnValue = "";
        try {
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            if(backupType.equalsIgnoreCase("FB")) {
                returnValue = resBundle.getString("rmp.mail.full_backup");
            } else if(backupType.equalsIgnoreCase("IB")) {
                returnValue = resBundle.getString("rmp.mail.incremental_backup");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnValue;
    }

    private static String getRestoreType(int restoreOption) {
        try {
            String returnValue;
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            switch (restoreOption){
                case 1:
                    returnValue = resBundle.getString("rmp.bmr.restore_type.restore_keep");
                    break;
                case 0:
                    returnValue = resBundle.getString("rmp.bmr.restore_type.restore_overwrite");
                    break;
                case 2:
                    returnValue = resBundle.getString("rmp.bmr.restore_type.copy_to");
                    break;
                default:
                    returnValue = "";
            }
            return returnValue;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getBackupSize(double sizeInBytes) {
        String backupSize;
        if(Math.round(sizeInBytes / (1024)) == 0) {
            backupSize = String.format("%.2f Bytes", sizeInBytes);
        } else if (Math.round(sizeInBytes / (1024 * 1024)) == 0) {
            backupSize = String.format("%.2f KB", sizeInBytes / 1024);
        } else if (Math.round(sizeInBytes / (1024 * 1024 * 1024)) == 0) {
            backupSize = String.format("%.2f MB", sizeInBytes / (1024 * 1024));
        } else {
            backupSize = String.format("%.2f GB", sizeInBytes / (1024 * 1024 * 1024));
        }
        return backupSize;
    }
}
//ignoreI18n_end