/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * $Id:$
 */
package com.manageengine.rmp.admin;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.i18n.ADSResourceBundle;
import com.manageengine.ads.fw.i18n.I18NUtil;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.admin.constants.NotificationType;
import com.manageengine.rmp.admin.constants.OperationstatusMailnotification;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.i18n.Rmpi18n;
import com.manageengine.rmp.constants.OperationStatus;
import com.manageengine.rmp.constants.RmpConstants;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.virtual.VirtualConstants;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.regex.Matcher;
//ignoreI18n_start
/**
 *
 * @author aswathy-1909
 */
public class MailTemplate {
    public static JSONObject getADMailerContent (NotificationType notificationType, Object data, boolean isSuccess) {
        LogWriter.general.info("API called: MailTemplate.getADMailerContent()");
        JSONObject mailerContent;
        try {
            JSONObject dataObject = MailInfoAD.setADMailInfo(data, notificationType);
            switch(notificationType) {
                case ADBackup: {
                    dataObject = MailInfoAD.setADBackupMailInfo(data, dataObject);
                    break;
                }
                case ADRestore:
                case ADRecycle: {
                    dataObject = MailInfoAD.setADRestoreMailInfo(data, dataObject);
                    break;
                }
                case ADRollback: {
                    dataObject = MailInfoAD.setADRollBackMailInfo(data, dataObject);
                    break;
                }
            }
            if(isSuccess) {
                mailerContent = getADSuccessMailerContent(notificationType.ordinal(), dataObject);
            }
            else {
                mailerContent = getADFailureMailerContent(notificationType.ordinal(), dataObject);
            }
            
            return mailerContent;
        } catch (Exception e) {
            LogWriter.general.severe("MailTemplate.getADMailerContent " + LogWriter.getStackTrace(e));
            return null;
        }
    }

    private static JSONObject getADSuccessMailerContent(int notificationType,JSONObject data) {
        LogWriter.general.info("API called: MailTemplate.getADSuccessMailerContent()");
        try {
            JSONObject mailTemplate = NotificationAPI.getNotificationTemplate(notificationType, MailInfoAD.getADOperationstatusMailnotification(notificationType, OperationStatus.values()[data.getInt("operation_status")]));
            JSONObject messageTemplate = JSONObjectUtil.parse(String.valueOf(mailTemplate.get("MESSAGE")));

            JSONObject commonData = data.getJSONObject("commonData");

            String subject = String.valueOf(mailTemplate.get("SUBJECT"))
                    .replace("%DOMAIN_NAME%", commonData.get("%DOMAIN_NAME%").toString())
                    .replace("%TOTAL_COUNT%", commonData.get("%TOTAL_COUNT%").toString());

            String generalInfo = String.valueOf(messageTemplate.get("%GENERAL_INFO%"));

            // backup
            String objectwiseChangeInfo = "";
            if(data.has("backupData")) {
                objectwiseChangeInfo = keyReplacer(String.valueOf(messageTemplate.get("%OBJECTWISE_CHANGETYPEWISE%")), data.getJSONObject("backupData"));
            }

            // restore and recycle
            String restoreInfo = "";
            if(data.has("restoreData")) {
                restoreInfo = keyReplacer(String.valueOf(messageTemplate.get("%RESTORE_INFO%")), data.getJSONObject("restoreData"));
            }

            // rollback
            String rollbackInfo = "";
            if(data.has("rollbackData")) {
                rollbackInfo = keyReplacer(String.valueOf(messageTemplate.get("%ROLLBACK_INFO%")), data.getJSONObject("rollbackData"));
            }

            String message = String.valueOf(messageTemplate.get("message"))
                    .replace("%HEADER%",String.valueOf(messageTemplate.get("%HEADER%")))
                    .replace("%FOOTER_MESSAGE%",String.valueOf(messageTemplate.get("%FOOTER_MESSAGE%")))
                    .replace("%GENERAL_INFO%",generalInfo)
                    .replace("%OBJECTWISE_CHANGETYPEWISE%", objectwiseChangeInfo)
                    .replace("%RESTORE_INFO%", restoreInfo)
                    .replace("%ROLLBACK_INFO%", rollbackInfo)
                    .replace("%doublequote%", "\"");

            message = keyReplacer(message, commonData);

            mailTemplate.put("MESSAGE", message);
            mailTemplate.put("SUBJECT", subject);
            return mailTemplate;
        } catch (Exception e) {
            LogWriter.general.severe("MailTemplate.getADSuccessMailerContent " + LogWriter.getStackTrace(e));
            return null;
        }
    }

    private static JSONObject getADFailureMailerContent(int notificationType,JSONObject data) {
        LogWriter.general.info("API called: MailTemplate.getADFailureMailerContent()");
        try {
            JSONObject mailTemplate = NotificationAPI.getNotificationTemplate(notificationType, MailInfoAD.getADOperationstatusMailnotification(notificationType, OperationStatus.values()[data.getInt("operation_status")]));
            JSONObject messageTemplate = JSONObjectUtil.parse(String.valueOf(mailTemplate.get("MESSAGE")));

            JSONObject commonData = data.getJSONObject("commonData");

            String subject = String.valueOf(mailTemplate.get("SUBJECT"))
                    .replace("%DOMAIN_NAME%", commonData.get("%DOMAIN_NAME%").toString());

            String generalInfo = String.valueOf(messageTemplate.get("%GENERAL_INFO%"));

            String message = String.valueOf(messageTemplate.get("message"))
                    .replace("%HEADER%",String.valueOf(messageTemplate.get("%HEADER%")))
                    .replace("%FOOTER_MESSAGE%",String.valueOf(messageTemplate.get("%FOOTER_MESSAGE%")))
                    .replace("%GENERAL_INFO%",generalInfo)
                    .replace("%FAILURE_INFO%", messageTemplate.get("%FAILURE_INFO%").toString())
                    .replace("%doublequote%", "\"");

            message = keyReplacer(message, commonData);

            mailTemplate.put("MESSAGE", message);
            mailTemplate.put("SUBJECT", subject);
            return mailTemplate;

        } catch (Exception e) {
            LogWriter.general.severe("MailTemplate.getADFailureMailerContent " + LogWriter.getStackTrace(e));
            return null;
        }
    }

    public static JSONObject getVMMailerContent(NotificationType notificationType, JSONObject data, boolean isSuccess) {
        LogWriter.general.info("API called: MailTemplate.getVMMailerContent()");
        JSONObject mailerContent;
        try {
            switch (notificationType) {
                case HyperVBackup:
                case VMWareBackup:{
                    mailerContent = getVMBackupMailerContent(notificationType.ordinal(), data, isSuccess);
                    break;
                }

                case HyperVRestore:
                case VMWareRestore: {
                    mailerContent = getVMRestoreMailerContent(notificationType.ordinal(), data, isSuccess);
                    break;
                }
                default: {
                    mailerContent = null;
                    break;
                }
            }
            
            return mailerContent;
        } catch (Exception e) {
            LogWriter.general.severe("MailTemplate.getVMMailerContent " + LogWriter.getStackTrace(e));
            return null;
        }
    }

    public static JSONObject getVMBackupMailerContent(int notificationType, JSONObject data, boolean isSuccess) {
        LogWriter.general.info("API called: MailTemplate.getVMBackupMailerContent()");
        try {
            boolean allVMsFailed = data.getBoolean("allVMsFailed");
            JSONObject mailTemplate = (JSONObject) NotificationAPI.getNotificationTemplate(notificationType, isSuccess?OperationstatusMailnotification.Success:OperationstatusMailnotification.Failure);
            JSONObject messageTemplate = JSONObjectUtil.parse(String.valueOf(mailTemplate.get("MESSAGE")));

            String subject = String.valueOf(mailTemplate.get("SUBJECT"));

            String backupInfo = String.valueOf(messageTemplate.get("%BACKUP_INFO%"));

            String generalInfo = keyReplacer(String.valueOf(messageTemplate.get("%GENERAL_INFO%")), data.getJSONObject("generalInfo"));

            String repoInfo = keyReplacer(String.valueOf(messageTemplate.get("%REPOSITORY_INFO%")), data.getJSONObject("repoInfo"));

            String vmList = allVMsFailed ? String.valueOf(messageTemplate.get("%VM_LIST_2_F%")) : String.valueOf(messageTemplate.get("%VM_LIST%")), troubleShoot = "";
            JSONArray vmInfo = data.getJSONArray("vmInfo");
            //for Failure reason on Connect to Repository or Creating VM List
            if (vmInfo.length() == 1 && vmInfo.getJSONObject(0).has("Error")) {
                String error = vmInfo.getJSONObject(0).get("Error").toString();
                vmList = String.valueOf(messageTemplate.get("%GENERAL_ERROR_MESSAGE%")).replace("%ERROR%", error);
            } else {
                String vmDetails = "";

                String vmSuccess = String.valueOf(messageTemplate.get("%VM_SUCCESS%"));
                if (!isSuccess) {
                    String vmFailure = allVMsFailed ? String.valueOf(messageTemplate.get("%VM_FAILURE_2%")) : String.valueOf(messageTemplate.get("%VM_FAILURE%"));
                    for (int i = 0; i < vmInfo.length(); i++) {
                        JSONObject vmDetail = vmInfo.getJSONObject(i);
                        if (vmDetail.length() == 2 || vmDetail.has("Error")) {
                            vmDetails = vmDetails + keyReplacer(vmFailure, vmDetail);
                        } else {
                            vmDetails = vmDetails + keyReplacer(vmSuccess, vmDetail);
                        }
                    }
                } else {
                    for (int i = 0; i < vmInfo.length(); i++) {
                        JSONObject vmDetail = vmInfo.getJSONObject(i);
                        vmDetails = vmDetails + keyReplacer(vmSuccess, vmDetail);
                    }
                }
                vmList = vmList.replace("%VM_DETAILS%", vmDetails);
            }

            if (!isSuccess) {
                troubleShoot = keyReplacer(String.valueOf(messageTemplate.get("%TIPS_TROUBLESHOOT%")), data.getJSONObject("troubleShoot"));
            }

            String message = String.valueOf(messageTemplate.get("message")).
                    replace("%HEADER%", String.valueOf(messageTemplate.get("%HEADER%")))
                    .replace("%FOOTER_MESSAGE%", String.valueOf(messageTemplate.get("%FOOTER_MESSAGE%")))
                    .replace("%GENERAL_INFO%", generalInfo)
                    .replace("%BACKUP_INFO%", backupInfo)
                    .replace("%REPOSITORY_INFO%", repoInfo)
                    .replace("%VM_LIST%", vmList)
                    .replace("%TIPS_TROUBLESHOOT%", troubleShoot)
                    .replace("%doublequote%", "\"");

            mailTemplate.put("MESSAGE", message);
            mailTemplate.put("SUBJECT", subject);
            return mailTemplate;
        } catch (Exception e) {
            LogWriter.general.severe("MailTemplate.getVMBackupMailerContent " + LogWriter.getStackTrace(e));
            return null;
        }
    }

    public static JSONObject getVMRestoreMailerContent(int notificationType, JSONObject data, boolean isSuccess) {
        LogWriter.general.info("API called: MailTemplate.getVMRestoreMailerContent()");
        try{
            boolean allVMsFailed = data.getBoolean("allVMsFailed"), isLiveMigration = data.getBoolean("isLiveMigration");
            JSONObject mailTemplate = NotificationAPI.getNotificationTemplate(notificationType, isSuccess?OperationstatusMailnotification.Success:OperationstatusMailnotification.Failure);
            JSONObject messageTemplate = JSONObjectUtil.parse(String.valueOf(mailTemplate.get("MESSAGE")));

            String subject = String.valueOf(mailTemplate.get("SUBJECT"));

            String generalInfo = keyReplacer(String.valueOf(messageTemplate.get("%GENERAL_INFO%")), data.getJSONObject("generalInfo"));

            String vmList = "", troubleShoot = "", generalRestoreInfo;
            if(data.getInt("restoreType") == VirtualConstants.FILE_LEVEL_RESTORE) {
                generalRestoreInfo = String.valueOf(messageTemplate.get("%GENERAL_RESTORE_INFO_FLR%"));
                JSONArray vmInfo = data.getJSONArray("vmInfo");
                if(vmInfo.length() > 0) {
                    if (vmInfo.getJSONObject(0).has("Error")) {
                        String error = vmInfo.getJSONObject(0).get("Error").toString();
                        vmList = String.valueOf(messageTemplate.get("%GENERAL_ERROR_MESSAGE%")).replace("%ERROR%", error);
                    }
                }
            }
            else {
                generalRestoreInfo = String.valueOf(messageTemplate.get("%GENERAL_RESTORE_INFO%"));
                JSONArray vmInfo = data.getJSONArray("vmInfo");
                if(vmInfo.length() > 0) {
                    if (vmInfo.getJSONObject(0).has("Error")) {
                        String error = vmInfo.getJSONObject(0).get("Error").toString();
                        vmList = String.valueOf(messageTemplate.get("%GENERAL_ERROR_MESSAGE%")).replace("%ERROR%", error);
                    } else {
                        vmList = allVMsFailed ? String.valueOf(messageTemplate.get("%VM_LIST_2_F%")) : ((isLiveMigration) ? String.valueOf(messageTemplate.get("%VM_LIST_2%")): String.valueOf(messageTemplate.get("%VM_LIST%")));
                        String vmDetails = "";

                        String vmSuccess = isLiveMigration? String.valueOf(messageTemplate.get("%VM_SUCCESS_2%")) : String.valueOf(messageTemplate.get("%VM_SUCCESS%"));
                        if (!isSuccess) {
                            String vmFailure = (allVMsFailed || isLiveMigration) ? String.valueOf(messageTemplate.get("%VM_FAILURE_2%")) : String.valueOf(messageTemplate.get("%VM_FAILURE%"));
                            for (int i = 0; i < vmInfo.length(); i++) {
                                JSONObject vmDetail = vmInfo.getJSONObject(i);
                                if (vmDetail.length() == 2 || vmDetail.has("Error")) {
                                    vmDetails = vmDetails + keyReplacer(vmFailure, vmDetail);
                                } else {
                                    vmDetails = vmDetails + keyReplacer(vmSuccess, vmDetail);
                                }
                            }
                        } else {
                            for (int i = 0; i < vmInfo.length(); i++) {
                                JSONObject vmDetail = vmInfo.getJSONObject(i);
                                vmDetails = vmDetails + keyReplacer(vmSuccess, vmDetail);
                            }
                        }
                        vmList = vmList.replace("%VM_DETAILS%", vmDetails);
                    }
                }
            }
            generalRestoreInfo = keyReplacer(generalRestoreInfo, data.getJSONObject("restoreInfo"));

            if(!isSuccess) {
                troubleShoot = keyReplacer(String.valueOf(messageTemplate.get("%TIPS_TROUBLESHOOT%")), data.getJSONObject("troubleShoot"));
            }

            String message = String.valueOf(messageTemplate.get("message"))
                    .replace("%HEADER%", String.valueOf(messageTemplate.get("%HEADER%")))
                    .replace("%FOOTER_MESSAGE%", String.valueOf(messageTemplate.get("%FOOTER_MESSAGE%")))
                    .replace("%GENERAL_INFO%", generalInfo)
                    .replace("%RESTORE_INFO%", String.valueOf(messageTemplate.get("%RESTORE_INFO%")))
                    .replace("%GENERAL_RESTORE_INFO%", generalRestoreInfo)
                    .replace("%VM_LIST%", vmList)
                    .replace("%TIPS_TROUBLESHOOT%", troubleShoot)
                    .replace("%doublequote%", "\"");

            mailTemplate.put("MESSAGE", message);
            mailTemplate.put("SUBJECT", subject);
            return mailTemplate;
        } catch(Exception e) {
            LogWriter.general.severe("MailTemplate.getVMRestoreMailerContent " + LogWriter.getStackTrace(e));
            return null;
        }
    }

    public static JSONObject getBMRMailerContent(NotificationType notificationType, boolean isISOCreationConfigured, JSONObject data) {
        LogWriter.general.info("API called: MailTemplate.getBMRMailerContent()");
        try {
            JSONObject mailerContent;
            switch (notificationType) {
                case BMRBackup: {
                    mailerContent = getBMRBackupMailerContent(notificationType, isISOCreationConfigured, data);
                    break;
                }
                case BMRRestore: {
                    mailerContent = getBMRRestoreMailerContent(notificationType, isISOCreationConfigured, data);
                    break;
                }
                default: {
                    mailerContent = null;
                }
            }
            
            return mailerContent;
        } catch (Exception e) {
            LogWriter.general.severe("MailTemplate.getBMRMailerContent: " + LogWriter.getStackTrace(e));
            return null;
        }
    }

    public static JSONObject getBMRBackupMailerContent(NotificationType notificationType, boolean isISOCreationConfigured, JSONObject data) {
        LogWriter.general.info("API called: MailTemplate.getBMRBackupMailerContent()");
        try {
            boolean isSuccess = data.getBoolean("status");
            String successString = data.getString("successString");
            OperationstatusMailnotification operationStatus;
            if(successString.equalsIgnoreCase("Success")) {
                operationStatus = OperationstatusMailnotification.Success;
            } else if(successString.equalsIgnoreCase("Interrupted")) {
                operationStatus = OperationstatusMailnotification.Interrupted;
            } else {
                operationStatus = OperationstatusMailnotification.Failure;
            }

            JSONObject mailTemplate = NotificationAPI.getNotificationTemplate(notificationType.ordinal(), operationStatus);
            JSONObject messageTemplate = JSONObjectUtil.parse(String.valueOf(mailTemplate.get("MESSAGE")));

            String subject = String.valueOf(mailTemplate.get("SUBJECT"))
                    .replace("%DC_NAME%", data.getString("dcName"))
                    .replace("%BACKUP_MODE%", data.getString("backupMode"));

            String generalInfo = keyReplacer(String.valueOf(messageTemplate.get("%GENERAL_INFO%")), data.getJSONObject("generalInfo"));

            String driveInfo = "", driveDetails = "", troubleShoot = "", fileInfo = "";

            // for BMR, VLR
            if(data.has("partitionInfo")) {
                JSONArray partitionInfo = data.getJSONArray("partitionInfo");
                for(int i = 0; i < partitionInfo.length(); i++) {
                    JSONObject partitionData = partitionInfo.getJSONObject(i);
                    String partitionStatus = partitionData.getString("%STATUS%");
                    String driveTemplate = (StringUtils.containsIgnoreCase(partitionStatus, "Success") || StringUtils.containsIgnoreCase(partitionStatus, "Not modified"))?
                            messageTemplate.getString("%DRIVE_SUCCESS%") :
                            messageTemplate.getString("%DRIVE_FAILURE%"); // failed, deleted, not found
                    String partition = keyReplacer(driveTemplate, partitionData);
                    driveDetails = driveDetails + partition;
                }
                if(!driveDetails.equals("")){
                    driveInfo = messageTemplate.getString("%DRIVE_INFO%").replace("%DETAILS%", driveDetails);
                }
            }

            // for FLR
            if(data.has("filesInfo")) {
                fileInfo = keyReplacer(messageTemplate.getString("%FILE_INFO%"), data.getJSONObject("filesInfo"));
            }

            if(!isSuccess) {
                driveInfo += String.valueOf(messageTemplate.get("%GENERAL_ERROR_MESSAGE%"));
                troubleShoot = String.valueOf(messageTemplate.get("%TIPS_TROUBLESHOOT%"));
            }

            String iSOCreationMessage = "";
            if(isISOCreationConfigured && !MailInfoBMR.getISOCreationMessage().equals("")) {
                iSOCreationMessage = String.valueOf(messageTemplate.get("%ISO_CREATION_MESSAGE%"))
                        .replace("%MESSAGE%", MailInfoBMR.getISOCreationMessage());
            }

            String message = String.valueOf(messageTemplate.get("message"))
                    .replace("%HEADER%", String.valueOf(messageTemplate.get("%HEADER%")))
                    .replace("%FOOTER_MESSAGE%", String.valueOf(messageTemplate.get("%FOOTER_MESSAGE%")))
                    .replace("%GENERAL_INFO%", generalInfo)
                    .replace("%DRIVE_INFO%", driveInfo)
                    .replace("%FILE_INFO%", fileInfo)
                    .replace("%ISO_CREATION_MESSAGE%", iSOCreationMessage)
                    .replace("%TIPS_TROUBLESHOOT%", troubleShoot)
                    .replace("%doublequote%", "\"");

            message = keyReplacer(message, data.getJSONObject("commonData"));

            mailTemplate.put("MESSAGE", message);
            mailTemplate.put("SUBJECT", subject);
            return mailTemplate;
        } catch (Exception e) {
            LogWriter.general.severe("MailTemplate.getBMRBackupMailerContent: " + LogWriter.getStackTrace(e));
            return null;
        }
    }

    public static JSONObject getBMRRestoreMailerContent(NotificationType notificationType, boolean isISOCreationConfigured, JSONObject data) {
        LogWriter.general.info("API called: MailTemplate.getBMRRestoreMailerContent()");
        try {
            boolean isSuccess = data.getBoolean("status");
            String successString = data.getString("successString");
            OperationstatusMailnotification operationStatus;
            if(successString.equalsIgnoreCase("Success")) {
                operationStatus = OperationstatusMailnotification.Success;
            } else if(successString.equalsIgnoreCase("Interrupted")) {
                operationStatus = OperationstatusMailnotification.Interrupted;
            } else {
                operationStatus = OperationstatusMailnotification.Failure;
            }

            JSONObject mailTemplate = NotificationAPI.getNotificationTemplate(notificationType.ordinal(), operationStatus);
            JSONObject messageTemplate = JSONObjectUtil.parse(String.valueOf(mailTemplate.get("MESSAGE")));

            String subject = String.valueOf(mailTemplate.get("SUBJECT"))
                    .replace("%DC_NAME%", data.getString("dcName"))
                    .replace("%RESTORE_TYPE%", data.getString("restoreType"));

            String generalInfo = keyReplacer(String.valueOf(messageTemplate.get("%GENERAL_INFO%")), data.getJSONObject("generalInfo"));

            String driveInfo = "", driveDetails = "", troubleShoot = "";

            // for VLR
            if(data.has("filesInfo")) {
                JSONArray volumesInfo = data.getJSONArray("filesInfo");
                for(int i = 0; i < volumesInfo.length(); i++) {
                    JSONObject volumeData = volumesInfo.getJSONObject(i);
                    String driveTemplate = (volumeData.getString("%STATUS%").equalsIgnoreCase("Success"))?
                            messageTemplate.getString("%DRIVE_SUCCESS%") :
                            messageTemplate.getString("%DRIVE_FAILURE%");
                    String partition = keyReplacer(driveTemplate, volumeData);
                    driveDetails = driveDetails + partition;
                }
                if(!driveDetails.equals("")){
                    driveInfo = messageTemplate.getString("%DRIVE_INFO%").replace("%DETAILS%", driveDetails);
                }
            }

            String restoreInfo = keyReplacer(messageTemplate.getString("%RESTORE_INFO%"), data.getJSONObject("restoreInfo"))
                    .replace("%DRIVES_INFO%", driveInfo);

            if(!isSuccess) {
                restoreInfo += String.valueOf(messageTemplate.get("%GENERAL_ERROR_MESSAGE%"));
                troubleShoot = String.valueOf(messageTemplate.get("%TIPS_TROUBLESHOOT%"));
            }

            String iSOCreationMessage = "";
            if(isISOCreationConfigured && !MailInfoBMR.getISOCreationMessage().equals("")) {
                iSOCreationMessage = String.valueOf(messageTemplate.get("%ISO_CREATION_MESSAGE%"))
                        .replace("%MESSAGE%", MailInfoBMR.getISOCreationMessage());
            }

            String message = String.valueOf(messageTemplate.get("message"))
                    .replace("%HEADER%", String.valueOf(messageTemplate.get("%HEADER%")))
                    .replace("%FOOTER_MESSAGE%", String.valueOf(messageTemplate.get("%FOOTER_MESSAGE%")))
                    .replace("%GENERAL_INFO%", generalInfo)
                    .replace("%RESTORE_INFO%", restoreInfo)
                    .replace("%ISO_CREATION_MESSAGE%", iSOCreationMessage)
                    .replace("%TIPS_TROUBLESHOOT%", troubleShoot)
                    .replace("%doublequote%", "\"");

            message = keyReplacer(message, data.getJSONObject("commonData"));

            mailTemplate.put("MESSAGE", message);
            mailTemplate.put("SUBJECT", subject);
            return mailTemplate;
        } catch (Exception e) {
            LogWriter.general.severe("MailTemplate.getBMRBackupMailerContent: " + LogWriter.getStackTrace(e));
            return null;
        }
    }

    public static JSONObject getScheduledMailerContent(JSONObject data, Date fromDate, Date toDate) {
        JSONObject mailerContent = new JSONObject();
        LogWriter.general.info("API called: MailTemplate.getScheduledMailContent()");
        try {
            JSONObject mailTemplate = NotificationAPI.getNotificationTemplate(-1, OperationstatusMailnotification.Success);
            JSONObject messageTemplate = JSONObjectUtil.parse(String.valueOf(mailTemplate.get("MESSAGE")));

            String subject = String.valueOf(mailTemplate.get("SUBJECT"));
            String message = String.valueOf(messageTemplate.get("message"));
            String generalInfo = String.valueOf(messageTemplate.get("%GENERAL_INFO%"));

            String adInfo = "";
            JSONObject adData = data.getJSONObject("AD");
            boolean isAllDomainsSelectedAD = adData.getBoolean("isAllDomainsSelected");
            JSONArray adDomains = new JSONArray();
            if(!isAllDomainsSelectedAD) {
                adDomains = adData.getJSONArray("domains");
            }
            JSONArray adOperationsConfigured = adData.getJSONArray("OperationsToBeNotified");
            JSONArray adMailData = MailInfoAD.setADScheduledMailInfo(isAllDomainsSelectedAD, adDomains, adOperationsConfigured, fromDate, toDate);
            if(adMailData.length() > 0) {
                JSONObject adModuleInfo = new JSONObject();
                JSONObject adModuleGeneralInfo = new JSONObject();
                adModuleGeneralInfo.put("%MODULE_NAME%", "AD");
                for(int i = 0; i < RmpConstants.AD_OPERATIONS.length; i++) {
                    adModuleGeneralInfo.put("%OPERATION_" + RmpConstants.AD_OPERATIONS[i] + "_NAME%", getOperationNameFromNotificationType(NotificationType.values()[RmpConstants.AD_OPERATIONS[i]]));
                }
                adModuleInfo.put("generalInfo", adModuleGeneralInfo);
                JSONArray adRows = new JSONArray();
                for(int i = 0; i < adMailData.length(); i++) {
                    JSONObject adModuleRowInfo = new JSONObject();
                    adModuleRowInfo.put("%DOMAIN_NAME%", adMailData.getJSONObject(i).getString("domainName"));
                    JSONArray operations = adMailData.getJSONObject(i).getJSONArray("operationDetails");
                    for(int j = 0; j < operations.length(); j++) {
                        JSONObject operation = operations.getJSONObject(j);
                        adModuleRowInfo.put("%OPERATION_" + operation.getInt("operation") + "_TOTAL%", operation.getInt("totalCount"));
                        adModuleRowInfo.put("%OPERATION_" + operation.getInt("operation") + "_SUCCESS%", operation.getInt("successCount"));
                        adModuleRowInfo.put("%OPERATION_" + operation.getInt("operation") + "_FAILURE%", operation.getInt("failureCount"));
                    }
                    adRows.put(adModuleRowInfo);
                }
                adModuleInfo.put("rows", adRows);

                adInfo = String.valueOf(messageTemplate.get("%AD_INFO%"));
                String adRowsInfo = "";
                JSONArray adRowInfoArray = adModuleInfo.getJSONArray("rows");
                for(int i = 0; i < adRowInfoArray.length(); i++) {
                    String adRowInfo = String.valueOf(messageTemplate.get("%AD_ROW_INFO%"));
                    adRowInfo = keyReplacer(adRowInfo, adRowInfoArray.getJSONObject(i));
                    adRowsInfo = adRowsInfo + adRowInfo;
                }
                adInfo = adInfo.replace("%AD_ROWS_INFO%", adRowsInfo);
                adInfo = keyReplacer(adInfo, adModuleInfo.getJSONObject("generalInfo"));
            }

            String vmwareInfo = "";
            JSONObject vmwareData = data.getJSONObject("VMWare");
            JSONArray vmwareBackups = new JSONArray();
            boolean isAllBackupsSelectedVMWare = vmwareData.getBoolean("isAllBackupsSelected");
            if(!isAllBackupsSelectedVMWare) {
                vmwareBackups = vmwareData.getJSONArray("backups");
            }
            JSONArray vmwareOperationsConfigured = vmwareData.getJSONArray("OperationsToBeNotified");
            JSONArray vmwareMailData = MailInfoVM.setVMScheduledMailInfo(isAllBackupsSelectedVMWare, vmwareBackups, vmwareOperationsConfigured, VirtualConstants.VMWARE, fromDate, toDate);
            if(vmwareMailData.length() > 0) {
                JSONObject vmwareModuleInfo = new JSONObject();
                JSONObject vmwareGeneralInfo = new JSONObject();
                vmwareGeneralInfo.put("%MODULE_NAME%", "VMware");
                for(int i = 0; i < RmpConstants.VMWARE_OPERATIONS.length; i++) {
                    vmwareGeneralInfo.put("%OPERATION_" + RmpConstants.VMWARE_OPERATIONS[i] + "_NAME%", getOperationNameFromNotificationType(NotificationType.values()[RmpConstants.VMWARE_OPERATIONS[i]]));
                }
                vmwareModuleInfo.put("generalInfo", vmwareGeneralInfo);
                JSONArray vmwareRows = new JSONArray();
                for(int i = 0; i < vmwareMailData.length(); i++) {
                    JSONObject vmwareModuleRowInfo = new JSONObject();
                    vmwareModuleRowInfo.put("%HOST_NAME%", vmwareMailData.getJSONObject(i).getString("hostName"));
                    JSONArray operations = vmwareMailData.getJSONObject(i).getJSONArray("operationDetails");
                    for(int j = 0; j < operations.length(); j++) {
                        JSONObject operation = operations.getJSONObject(j);
                        vmwareModuleRowInfo.put("%OPERATION_" + operation.getInt("operation") + "_TOTAL%", operation.getInt("totalCount"));
                        vmwareModuleRowInfo.put("%OPERATION_" + operation.getInt("operation") + "_SUCCESS%", operation.getInt("successCount"));
                        vmwareModuleRowInfo.put("%OPERATION_" + operation.getInt("operation") + "_FAILURE%", operation.getInt("failureCount"));
                    }
                    vmwareRows.put(vmwareModuleRowInfo);
                }
                vmwareModuleInfo.put("rows", vmwareRows);

                vmwareInfo = String.valueOf(messageTemplate.get("%VMWARE_INFO%"));
                String vmwareRowsInfo = "";
                JSONArray vmwareRowInfoArray = vmwareModuleInfo.getJSONArray("rows");
                for(int i = 0; i < vmwareRowInfoArray.length(); i++) {
                    String vmwareRowInfo = String.valueOf(messageTemplate.get("%VMWARE_ROW_INFO%"));
                    vmwareRowInfo = keyReplacer(vmwareRowInfo, vmwareRowInfoArray.getJSONObject(i));
                    vmwareRowsInfo = vmwareRowsInfo + vmwareRowInfo;
                }
                vmwareInfo = vmwareInfo.replace("%VMWARE_ROWS_INFO%", vmwareRowsInfo);
                vmwareInfo = keyReplacer(vmwareInfo, vmwareModuleInfo.getJSONObject("generalInfo"));
            }

            String hypervInfo = "";
            JSONObject hyperVData = data.getJSONObject("HyperV");
            JSONArray hyperVBackups = new JSONArray();
            boolean isAllBackupsSelectedHyperV = hyperVData.getBoolean("isAllBackupsSelected");
            if(!isAllBackupsSelectedHyperV) {
                hyperVBackups = hyperVData.getJSONArray("backups");
            }
            JSONArray hyperVOperationsConfigured = hyperVData.getJSONArray("OperationsToBeNotified");
            JSONArray hyperVMailData = MailInfoVM.setVMScheduledMailInfo(isAllBackupsSelectedHyperV, hyperVBackups, hyperVOperationsConfigured, VirtualConstants.HYPERV, fromDate, toDate);
            if(hyperVMailData.length() > 0) {
                JSONObject hyperVModuleInfo = new JSONObject();
                JSONObject hyperVGeneralInfo = new JSONObject();
                hyperVGeneralInfo.put("%MODULE_NAME%", "Hyper-V");
                for(int i = 0; i < RmpConstants.HYPERV_OPERATIONS.length; i++) {
                    hyperVGeneralInfo.put("%OPERATION_" + RmpConstants.HYPERV_OPERATIONS[i] + "_NAME%", getOperationNameFromNotificationType(NotificationType.values()[RmpConstants.HYPERV_OPERATIONS[i]]));
                }
                hyperVModuleInfo.put("generalInfo", hyperVGeneralInfo);
                JSONArray hyperVRows = new JSONArray();
                for(int i = 0; i < hyperVMailData.length(); i++) {
                    JSONObject hyperVModuleRowInfo = new JSONObject();
                    hyperVModuleRowInfo.put("%HOST_NAME%", hyperVMailData.getJSONObject(i).getString("hostName"));
                    JSONArray operations = hyperVMailData.getJSONObject(i).getJSONArray("operationDetails");
                    for(int j = 0; j < operations.length(); j++) {
                        JSONObject operation = operations.getJSONObject(j);
                        hyperVModuleRowInfo.put("%OPERATION_" + operation.getInt("operation") + "_TOTAL%", operation.getInt("totalCount"));
                        hyperVModuleRowInfo.put("%OPERATION_" + operation.getInt("operation") + "_SUCCESS%", operation.getInt("successCount"));
                        hyperVModuleRowInfo.put("%OPERATION_" + operation.getInt("operation") + "_FAILURE%", operation.getInt("failureCount"));
                    }
                    hyperVRows.put(hyperVModuleRowInfo);
                }
                hyperVModuleInfo.put("rows", hyperVRows);

                hypervInfo = String.valueOf(messageTemplate.get("%HYPERV_INFO%"));
                String hyperVRowsInfo = "";
                JSONArray hyperVRowInfoArray = hyperVModuleInfo.getJSONArray("rows");
                for(int i = 0; i < hyperVRowInfoArray.length(); i++) {
                    String hyperVRowInfo = String.valueOf(messageTemplate.get("%HYPERV_ROW_INFO%"));
                    hyperVRowInfo = keyReplacer(hyperVRowInfo, hyperVRowInfoArray.getJSONObject(i));
                    hyperVRowsInfo = hyperVRowsInfo + hyperVRowInfo;
                }
                hypervInfo = hypervInfo.replace("%HYPERV_ROWS_INFO%", hyperVRowsInfo);
                hypervInfo = keyReplacer(hypervInfo, hyperVModuleInfo.getJSONObject("generalInfo"));
            }

            String bmrInfo = "";
            JSONObject bmrData = data.getJSONObject("BMR");
            JSONArray bmrDomains = new JSONArray();
            boolean isAllDomainsSelectedBMR = bmrData.getBoolean("isAllDomainsSelected");
            if(!isAllDomainsSelectedBMR) {
                bmrDomains = bmrData.getJSONArray("domains");
            }
            JSONArray bmrOperationsConfigured = bmrData.getJSONArray("OperationsToBeNotified");
            JSONArray bmrMailData = MailInfoBMR.setBMRScheduledMailInfo(isAllDomainsSelectedBMR, bmrDomains, bmrOperationsConfigured, fromDate, toDate);
            if(bmrMailData.length() > 0) {
                JSONObject bmrModuleInfo = new JSONObject();
                JSONObject bmrGeneralInfo = new JSONObject();
                bmrGeneralInfo.put("%MODULE_NAME%", "Windows Server");
                for(int i = 0; i < RmpConstants.BMR_OPERATIONS.length; i++) {
                    if(RmpConstants.BMR_OPERATIONS.length != NotificationType.BMRNewISOCreation.ordinal()) {
                        bmrGeneralInfo.put("%OPERATION_" + RmpConstants.BMR_OPERATIONS[i] + "_NAME%", getOperationNameFromNotificationType(NotificationType.values()[RmpConstants.BMR_OPERATIONS[i]]));
                    }
                }
                bmrModuleInfo.put("generalInfo", bmrGeneralInfo);
                JSONArray bmrRows = new JSONArray();
                for(int i = 0; i < bmrMailData.length(); i++) {
                    JSONObject bmrModuleRowInfo = new JSONObject();
                    bmrModuleRowInfo.put("%DOMAIN_NAME%", bmrMailData.getJSONObject(i).getString("domainName"));
                    JSONArray operations = bmrMailData.getJSONObject(i).getJSONArray("operationDetails");
                    for(int j = 0; j < operations.length(); j++) {
                        if(RmpConstants.BMR_OPERATIONS.length != NotificationType.BMRNewISOCreation.ordinal()) {
                            JSONObject operation = operations.getJSONObject(j);
                            bmrModuleRowInfo.put("%OPERATION_" + operation.getInt("operation") + "_TOTAL%", operation.getInt("totalCount"));
                            bmrModuleRowInfo.put("%OPERATION_" + operation.getInt("operation") + "_SUCCESS%", operation.getInt("successCount"));
                            bmrModuleRowInfo.put("%OPERATION_" + operation.getInt("operation") + "_FAILURE%", operation.getInt("failureCount"));
                        }
                    }
                    bmrRows.put(bmrModuleRowInfo);
                }
                bmrModuleInfo.put("rows", bmrRows);

                bmrInfo = String.valueOf(messageTemplate.get("%BMR_INFO%"));
                String bmrRowsInfo = "";
                JSONArray bmrRowInfoArray = bmrModuleInfo.getJSONArray("rows");
                for(int i = 0; i < bmrRowInfoArray.length(); i++) {
                    String bmrRowInfo = String.valueOf(messageTemplate.get("%BMR_ROW_INFO%"));
                    bmrRowInfo = keyReplacer(bmrRowInfo, bmrRowInfoArray.getJSONObject(i));
                    bmrRowsInfo = bmrRowsInfo + bmrRowInfo;
                }
                bmrInfo = bmrInfo.replace("%BMR_ROWS_INFO%", bmrRowsInfo);
                bmrInfo = keyReplacer(bmrInfo, bmrModuleInfo.getJSONObject("generalInfo"));
            }
            boolean isISOCreationConfigured = false;
            for(int i = 0; i < bmrOperationsConfigured.length(); i++) {
                if(bmrOperationsConfigured.getInt(i) == NotificationType.BMRNewISOCreation.ordinal()) {
                    isISOCreationConfigured = true;
                    break;
                }
            }
            String iSOCreationMessage = "";
            if(isISOCreationConfigured && !MailInfoBMR.getISOCreationMessage().equals("")) {
                iSOCreationMessage = String.valueOf(messageTemplate.get("%ISO_CREATION_MESSAGE%")).replace("%MESSAGE%", MailInfoBMR.getISOCreationMessage());
            }

            message = message.replace("%HEADER%", String.valueOf(messageTemplate.get("%HEADER%")))
                    .replace("%FOOTER_MESSAGE%", String.valueOf(messageTemplate.get("%FOOTER_MESSAGE%")))
                    .replace("%GENERAL_INFO%", generalInfo)
                    .replace("%AD_INFO%", adInfo)
                    .replace("%BMR_INFO%", bmrInfo)
                    .replace("%ISO_CREATION_MESSAGE%", iSOCreationMessage)
                    .replace("%VMWARE_INFO%", vmwareInfo)
                    .replace("%HYPERV_INFO%", hypervInfo)
                    .replaceAll("%OPERATION_.*?%", "-")
                    .replace("%FROM%", MailTemplate.getMailDateFormat().format(fromDate))
                    .replace("%TO%", MailTemplate.getMailDateFormat().format(toDate))
                    .replace("%doublequote%", "\"");
            mailerContent.put("MESSAGE", message);
            mailerContent.put("SUBJECT", subject);
        } catch (Exception e) {
            LogWriter.general.severe("MailTemplate.getScheduledMailContent: " + LogWriter.getStackTrace(e));
            return null;
        }
        return mailerContent;
    }

    public static String keyReplacer(String input, JSONObject data) {
        try {
            Iterator keys = data.keys();
            while (keys.hasNext()) {
                String key = (String) keys.next();
                input = input.replaceAll(key, Matcher.quoteReplacement(String.valueOf(data.get(key))));
            }
            return input;
        }
        catch (Exception e){
            LogWriter.general.severe("keyReplacer" + LogWriter.getStackTrace(e));
            return null;
        }
    }

    public static String getOperationNameFromNotificationType(NotificationType notificationType){
        try{
            ADSResourceBundle resBundle = Rmpi18n.getInstance().getBundle(I18NUtil.getDefaultLocale());
            String operationName;
            switch (notificationType){
                case ADBackup:
                case VMWareBackup:
                case HyperVBackup:
                case BMRBackup:{
                    operationName = resBundle.getString("rmp.notification.operations.Backup");
                    break;
                }
                case ADRestore:
                case HyperVRestore:
                case VMWareRestore:
                case BMRRestore:{
                    operationName = resBundle.getString("rmp.notification.operations.Restore");
                    break;
                }
                case ADRecycle:{
                    operationName = resBundle.getString("rmp.notification.operations.Recycle");
                    break;
                }
                case ADRollback:{
                    operationName = resBundle.getString("rmp.notification.operations.Rollback");
                    break;
                }
                default: {
                    operationName= "";
                }
            }
            return operationName;
        } catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

    public static SimpleDateFormat getMailDateFormat(){
        return new SimpleDateFormat("MMM-dd-yyyy HH:mm");
    }

    public static JSONArray getAllDomainIDs() {
        JSONArray returnValue = new JSONArray();
        try {
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.ADS_DOMAIN_CONFIGURATION));
            selectQuery.addSelectColumn(Column.getColumn(TableName.ADS_DOMAIN_CONFIGURATION, "DOMAIN_ID"));
            selectQuery.setCriteria(new Criteria(Column.getColumn(TableName.ADS_DOMAIN_CONFIGURATION, "ADMIN_STATUS"), 1, QueryConstants.EQUAL));
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if(!dataObject.isEmpty()) {
                Iterator rows = dataObject.getRows(TableName.ADS_DOMAIN_CONFIGURATION);
                while (rows.hasNext()) {
                    Row row = (Row) rows.next();
                    returnValue.put((Long) row.get("DOMAIN_ID"));
                }
            }
        } catch (Exception e) {
            LogWriter.general.severe("MailTemplate.getAllDomainIDs: " + LogWriter.getStackTrace(e));
        }
        return returnValue;
    }

    public static boolean isDomainEnabled(long domainID) {
        try {
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.ADS_DOMAIN_CONFIGURATION));
            selectQuery.addSelectColumn(Column.getColumn(TableName.ADS_DOMAIN_CONFIGURATION, "DOMAIN_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.ADS_DOMAIN_CONFIGURATION, "ADMIN_STATUS"));
            selectQuery.setCriteria(new Criteria(Column.getColumn(TableName.ADS_DOMAIN_CONFIGURATION, "DOMAIN_ID"), domainID, QueryConstants.EQUAL));
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if(!dataObject.isEmpty()) {
                if((int) dataObject.getFirstRow(TableName.ADS_DOMAIN_CONFIGURATION).get("ADMIN_STATUS") == 1) {
                    return true;
                } else {
                    return false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
//ignoreI18n_end