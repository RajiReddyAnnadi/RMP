package com.manageengine.rmp.admin.productnotifier;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.DateUtil;
import com.manageengine.rmp.ad.gpo.constants.GpoErrors;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.RMPCommonUtil;
import com.manageengine.rmp.constants.OperationStatus;
import com.manageengine.rmp.constants.OperationType;
import com.manageengine.rmp.constants.TableName;
import org.json.JSONArray;
import org.json.JSONObject;

import java.sql.Timestamp;
import java.util.Iterator;

//ignoreI18n_start

public class ProductNotifierUtil {
    // for REGISTRY_UPDATE_NOTIFIER start
    public static boolean isRegistryUpdateFailed() {
        try {
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_SYSTEM_PARAMS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_SYSTEM_PARAMS, "PARAM_NAME"), "IS_REGISTRY_UPDATE_FAILED", QueryConstants.EQUAL, false);
            selectQuery.setCriteria(criteria);
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if(!dataObject.isEmpty()) {
                Row row = dataObject.getFirstRow(TableName.RMP_SYSTEM_PARAMS);
                if(((String)row.get("PARAM_VALUE")).equalsIgnoreCase("true")) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.info("ProductNotifierUtil.isRegistryUpdateFailed(): " + e);
        }
        return false;
    }
    // for REGISTRY_UPDATE_NOTIFIER end


    // for GPO_ERROR_NOTIFIER start
    public static boolean isGPOFailedObjectsAvailable() {
        boolean isTableEmpty = RMPCommonUtil.isTableEmpty(TableName.GPO_ERROR_DETAILS, null, new String[]{"DOMAIN_ID", "OBJECT_GUID"});
        return (isAnyDomainEnabled() && !isTableEmpty);
    }
    
    public static boolean isAnyDomainEnabled(){
        try{
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.GPO_ERROR_DETAILS));
            Join join = new Join(TableName.GPO_ERROR_DETAILS, TableName.ADS_DOMAIN_CONFIGURATION, new String[] {"DOMAIN_ID"}, new String[] {"DOMAIN_ID"}, Join.LEFT_JOIN);
            selectQuery.addJoin(join);
            Criteria crit = new Criteria(Column.getColumn(TableName.ADS_DOMAIN_CONFIGURATION, "ADMIN_STATUS"), 1, QueryConstants.EQUAL);
            selectQuery.setCriteria(crit);
            selectQuery.addSelectColumn(Column.getColumn(TableName.ADS_DOMAIN_CONFIGURATION, "DOMAIN_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.ADS_DOMAIN_CONFIGURATION, "ADMIN_STATUS"));
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if(!dataObject.isEmpty()) {
                return true;
            }
        }catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.info("ProductNotifierUtil.isAnyDomainEnabled(): " + e);
        }
        return false;
    }

    public static JSONArray getFailedDomains() {
        JSONArray domains = new JSONArray();
        try {
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.GPO_ERROR_DETAILS));
            Join join = new Join(TableName.GPO_ERROR_DETAILS, TableName.ADS_DOMAIN_CONFIGURATION, new String[] {"DOMAIN_ID"}, new String[] {"DOMAIN_ID"}, Join.LEFT_JOIN);
            selectQuery.addJoin(join);
            Criteria crit = new Criteria(Column.getColumn(TableName.ADS_DOMAIN_CONFIGURATION, "ADMIN_STATUS"), 1, QueryConstants.EQUAL);
            selectQuery.setCriteria(crit);
            selectQuery.addSelectColumn(Column.getColumn(TableName.GPO_ERROR_DETAILS, "DOMAIN_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.GPO_ERROR_DETAILS, "OBJECT_GUID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.ADS_DOMAIN_CONFIGURATION, "DOMAIN_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.ADS_DOMAIN_CONFIGURATION, "DOMAIN_NAME"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.ADS_DOMAIN_CONFIGURATION, "ADMIN_STATUS"));
            selectQuery.addSortColumn(new SortColumn(TableName.ADS_DOMAIN_CONFIGURATION, "DOMAIN_NAME", true));
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if(!dataObject.isEmpty()) {
                Iterator rows = dataObject.getRows(TableName.ADS_DOMAIN_CONFIGURATION);
                while (rows.hasNext()) {
                    Row row = (Row) rows.next();
                    JSONObject domainData = new JSONObject();
                    domainData.put("domainId", (Long) row.get("DOMAIN_ID"));
                    domainData.put("domainName", (String) row.get("DOMAIN_NAME"));
                    domains.put(domainData);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.info("ProductNotifierUtil.getFailedDomains(): " + e);
        }
        return domains;
    }

    public static JSONArray getFailedObjectsNames(long domainId, int limit, String searchString) {
        JSONArray failedObjectsNames = new JSONArray();
        try {
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.GPO_ERROR_DETAILS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.GPO_ERROR_DETAILS, "OBJECT_NAME"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.GPO_ERROR_DETAILS, "DOMAIN_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.GPO_ERROR_DETAILS, "OBJECT_GUID"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.GPO_ERROR_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            if(!searchString.equalsIgnoreCase("")) {
                criteria = criteria.and(Column.getColumn(TableName.GPO_ERROR_DETAILS, "OBJECT_NAME"), searchString.replace("[", "\\["), QueryConstants.CONTAINS, false);
            }
            selectQuery.addSortColumn(new SortColumn(TableName.GPO_ERROR_DETAILS, "OBJECT_NAME", true));
            Range range = new Range(0, limit);
            selectQuery.setRange(range);
            selectQuery.setCriteria(criteria);
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if(!dataObject.isEmpty()) {
                Iterator rows = dataObject.getRows(TableName.GPO_ERROR_DETAILS);
                while (rows.hasNext()) {
                    Row row = (Row) rows.next();
                    failedObjectsNames.put((String) row.get("OBJECT_NAME"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.info("ProductNotifierUtil.getFailedObjectsNames(): " + e);
        }
        return failedObjectsNames;
    }

    public static JSONArray getFailedObjects(long domainId, int startIndex, String searchString, String searchType) {
        JSONArray failedObjects = new JSONArray();
        try {
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.GPO_ERROR_DETAILS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.GPO_ERROR_DETAILS, "*"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.GPO_ERROR_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            if(!searchString.equalsIgnoreCase("")) {
                int queryType = QueryConstants.EQUAL;
                if(searchType.equalsIgnoreCase("contains")) {
                    queryType = QueryConstants.CONTAINS;
                }
                criteria = criteria.and(Column.getColumn(TableName.GPO_ERROR_DETAILS, "OBJECT_NAME"), searchString.replace("[", "\\["), queryType, false);
            }
            selectQuery.addSortColumn(new SortColumn(TableName.GPO_ERROR_DETAILS, "OBJECT_NAME", true));
            selectQuery.setCriteria(criteria);
            Range range = new Range(startIndex, 100);
            selectQuery.setRange(range);
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if(!dataObject.isEmpty()) {
                Iterator rows = dataObject.getRows(TableName.GPO_ERROR_DETAILS);
                while (rows.hasNext()) {
                    Row row = (Row) rows.next();
                    JSONObject objectErrorData = new JSONObject();
                    GpoErrors error = GpoErrors.valueOf((String) row.get("ERROR"));
                    objectErrorData.put("name", (String) row.get("OBJECT_NAME"));
                    objectErrorData.put("errorMessage", GpoErrors.getErrorString((int) error.errorId));
                    objectErrorData.put("objectGuid", (String)row.get("OBJECT_GUID"));
                    objectErrorData.put("errorId", error.errorId);
                    failedObjects.put(objectErrorData);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.info("ProductNotifierUtil.getFailedObjects(): " + e);
        }
        return failedObjects;
    }

    public static long getFailedObjectsCount(long domainId, String searchString, String searchType) {
        long count = 0L;
        try {
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.GPO_ERROR_DETAILS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.GPO_ERROR_DETAILS, "DOMAIN_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.GPO_ERROR_DETAILS, "OBJECT_GUID"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.GPO_ERROR_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            if(!searchString.equalsIgnoreCase("")) {
                int queryType = QueryConstants.EQUAL;
                if(searchType.equalsIgnoreCase("contains")) {
                    queryType = QueryConstants.CONTAINS;
                }
                criteria = criteria.and(Column.getColumn(TableName.GPO_ERROR_DETAILS, "OBJECT_NAME"), searchString.replace("[", "\\["), queryType, false);
            }
            selectQuery.setCriteria(criteria);
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if (!dataObject.isEmpty()) {
                count = dataObject.size(TableName.GPO_ERROR_DETAILS);
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.info("ProductNotifierUtil.getFailedObjectsCount(): " + e);
        }
        return count;
    }

    public static boolean disableRetryBackup(long domainId, String objectGuid) {
        try {
            Criteria criteria = new Criteria(Column.getColumn(TableName.GPO_ERROR_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            criteria = criteria.and(new Criteria(Column.getColumn(TableName.GPO_ERROR_DETAILS, "OBJECT_GUID"), objectGuid, QueryConstants.EQUAL));
            DataObject dobj = CommonUtil.getPersistence().get(TableName.GPO_ERROR_DETAILS, criteria);
            if (!dobj.isEmpty()) {
                Row row = dobj.getFirstRow(TableName.GPO_ERROR_DETAILS);
                dobj.deleteRow(row);
                CommonUtil.getPersistence().update(dobj);
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.info("ProductNotifierUtil.disableRetryBackup(): " + e);
        }
        return false;
    }

    public static String getBackupDetails(long domainId, boolean getFirst) {
        try {
            SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OPERATION_INFO));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_OPERATION_INFO, "OPERATION_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_OPERATION_INFO, "START_TIME"));
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_OPERATION_INFO, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            criteria = criteria.and((new Criteria(Column.getColumn(TableName.RMP_OPERATION_INFO, "OPERATION_TYPE"), OperationType.Backup.ordinal(), QueryConstants.EQUAL))
                    .or(new Criteria(Column.getColumn(TableName.RMP_OPERATION_INFO, "OPERATION_TYPE"), OperationType.FullBackup.ordinal(), QueryConstants.EQUAL)));
            criteria = criteria.and(new Criteria(Column.getColumn(TableName.RMP_OPERATION_INFO, "STATUS"), OperationStatus.UnStarted.ordinal(), QueryConstants.NOT_EQUAL));
            selectQuery.setCriteria(criteria);
            selectQuery.addSortColumn(new SortColumn(Column.getColumn(TableName.RMP_OPERATION_INFO, "START_TIME"), getFirst ? true : false));
            selectQuery.setRange(new Range(0, 1));
            DataObject dataObject = CommonUtil.getPersistence().get(selectQuery);
            if(!dataObject.isEmpty()) {
                Row row = dataObject.getFirstRow(TableName.RMP_OPERATION_INFO);
                return DateUtil.getUtcDate((Timestamp)row.get("START_TIME"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.general.info("ProductNotifierUtil.getBackupDetails(): " + e);
        }
        return null;
    }
    // for GPO_ERROR_NOTIFIER end
}

//ignoreI18n_end