/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.client;

import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.RmpConstants;
import com.manageengine.rmp.dashboard.DashboardUtil;
import com.manageengine.rmp.settings.DomainSettings;
import java.io.IOException;
import java.util.logging.Level;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

/**
 *
 * @author praveen-3076
 */
public class DashboardSummary extends HttpServlet {
    public DashboardSummary() {
        super();
    }
     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                    // TODO Auto-generated method stub
            try 
            {
                response.setContentType(RmpConstants.CONTENT_TYPE);
               if(request.getRequestURI().equals("/dashboard/activedirectory/objInfo")){
                   long domainId = 1;
                    try {
                        JSONObject reqData = new JSONObject(request.getParameter("req"));
                        domainId = reqData.getLong("d");//No I18N
                    } catch (Exception e) {
                        LogWriter.general.log(Level.SEVERE, "dashboard.Dashboardget {0}", e);
                    }
                   response.getWriter().print(SummaryHandler.getADObjectInfo(domainId));
               }else if(request.getRequestURI().equals("/dashboard/activedirectory/isCompleted")){
                   boolean isCompleted=false;
                    try {
                        isCompleted=DomainSettings.isDomainDiscoveryCompleted();
                    } catch (Exception e) {
                        LogWriter.general.log(Level.SEVERE, "dashboard.Dashboardget {0}", e);
                    }
                   response.getWriter().print(isCompleted);
               }else if(request.getRequestURI().equals("/dashboard/activedirectory/operationInfo")){
                   long domainId = 1;
                   int rangeStart = 1, limit = 25;
                   JSONObject operationInfo = new JSONObject();
                    try {
                        JSONObject reqData = new JSONObject(request.getParameter("req"));
                        domainId = reqData.getLong("d");//No I18N
                        rangeStart = reqData.getInt("rangeStart");//No I18N
                        limit = reqData.getInt("limit");//No I18N
                    } catch (Exception e) {
                        LogWriter.general.log(Level.SEVERE, "dashboard.Dashboardget {0}", e);
                    }
                   operationInfo.put("count", DashboardUtil.getTotalOperationsCount(domainId));
                   operationInfo.put("info", DashboardUtil.getOperationInfoData(domainId, rangeStart, limit)); 
                   response.getWriter().print(operationInfo);
               }else if(request.getRequestURI().equals("/dashboard/virtualEnvironment/mainCard")){
                    try {
                        JSONObject reqData = new JSONObject(request.getParameter("req"));
                    } catch (Exception e) {
                        LogWriter.general.log(Level.SEVERE, "dashboard.Dashboardget {0}", e);
                    }
                   response.getWriter().print(SummaryHandler.generateVirtualEnvironmentInfoData());
               }
            }
           catch (Exception ex) {
                   // TODO Auto-generated catch block
               ex.printStackTrace();
           }

        }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
            doGet(request, response);
	}
   
}
