/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
//ignoreI18n_start
package com.manageengine.rmp.ad.backup;

import com.adventnet.ds.query.UpdateQuery;
import com.manageengine.me.util.RowHelper;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.util.LdapUtil;
import java.util.Properties;
import java.util.UUID;

public class OuConfig {

    public String name;
    public String distinguishedName;
    public String canonicalName;
    public UUID objectGuid;
    public UUID parentGuid;
    public boolean toBackup;
    public Boolean hasHistory;
    public Boolean isDeleted;
    public Integer selectionType;

    public OuConfig() {
    }

    public OuConfig(BackupObject ouObject) {
        name = ouObject.objNam;
        objectGuid = ouObject.objId;
        parentGuid = ouObject.ouId;
        isDeleted = ouObject.isDeleted;
        toBackup = ouObject.isBackupSet;
        if (ouObject.isDeleted) {
            canonicalName = ouObject.ouNam + "/" + ouObject.objNam;
            distinguishedName = "OU=" + ouObject.objNam + "," + ouObject.lastKnownParent;//ToDo: decide whether prefix is OU or CN
        } else {
            distinguishedName = ouObject.distinguishedName;
            canonicalName = LdapUtil.getCanonicalName(ouObject.distinguishedName);
        }
    }

    public OuConfig(Long domainId, Properties properties) {
        distinguishedName = BackupUtil.getString(properties, "distinguishedName");
        name = BackupUtil.getString(properties, "name");
        objectGuid = BackupUtil.getGuid(properties, "objectGUID");
        toBackup = hasHistory = true;
        Integer isDeleted = BackupUtil.getInteger(properties, "isDeleted");
        canonicalName = LdapUtil.getCanonicalName(distinguishedName);
        if (isDeleted != null && isDeleted == 1 && !LdapUtil.isDeletedObjectContainer(canonicalName)) {
            this.isDeleted = true;
//            String lastKnownParent =BackupUtil.getString(properties, "lastKnownParent");
//            distinguishedName= "OU=" + name + "," + lastKnownParent;//ToDo: decide whether prefix is OU or CN
            return;
        } else {
            this.isDeleted = false;

            String parentOuCanonicalName = LdapUtil.getParentCanonical(distinguishedName);
            //parentGuid = BackupUtil.getOuGuid(domainId, parentOuCanonicalName);
            parentGuid = BackupUtil.getGuid(properties, "parentguid");
            if(parentGuid == null)
            {
                parentGuid = new UUID(0, 0);
            }
        }
    }

    public OuConfig(RowHelper row) {
        this.name = row.getString("OBJECT_NAME");
        this.canonicalName = row.getString("CANONICAL_NAME");
        this.objectGuid = row.getUUID("OBJECT_GUID");
        this.toBackup = row.getBoolean("TO_BACKUP");
        this.distinguishedName = row.getString("DISTINGUISHED_NAME");
        this.parentGuid = row.getUUID("PARENT_GUID");
        this.isDeleted = row.getBoolean("IS_DELETED");
        this.hasHistory = row.getBoolean("HAS_HISTORY");
        this.selectionType = row.getInteger("SELECTION_TYPE");
    }

    public Boolean addColumnsToUpdate(OuConfig oldConfig, UpdateQuery updateObject) {
        try {
            if (oldConfig == null) {
                addColumnsToUpdate(updateObject);
                return true;
            }
            if (!name.equals(oldConfig.name)) {
                updateObject.setUpdateColumn("OBJECT_NAME", LdapUtil.getObjectAttributeValue(name));
            }
            if (!canonicalName.equals(oldConfig.canonicalName)) {
                updateObject.setUpdateColumn("CANONICAL_NAME", LdapUtil.getObjectAttributeValue(canonicalName));
            }
            if (!distinguishedName.equals(oldConfig.distinguishedName)) {
                //sample from dn as OU=abc\0ADEL:bd5faca1-a3e0-4149-99c9-721cfda7a0a3,DC=test,DC=com to
                //OU=abc,DC=test,DC=com occurs when OU is deselected from backupSettings and that OU is deleted
                if(distinguishedName.contains("DEL:") && !distinguishedName.contains("CN=Deleted Objects")){
                    String split [] = distinguishedName.split("\\x00");
                    distinguishedName = split[0] + split[1].subSequence((split[1].indexOf(",")), split[1].length());
                }
                updateObject.setUpdateColumn("DISTINGUISHED_NAME", distinguishedName);
            }
            if (!parentGuid.equals(oldConfig.parentGuid) && !oldConfig.parentGuid.equals(BackupUtil.emptyGuid)) {//!parentGuid.equals(objectGuid) - to avoid changing the parentGuid of domain root node
                updateObject.setUpdateColumn("PARENT_GUID", parentGuid.toString());
            }
            if (!isDeleted.equals(oldConfig.isDeleted)) {
                updateObject.setUpdateColumn("IS_DELETED", isDeleted);
            }
            return true;
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("OuConfig.addColumnsToUpdate DN:%s %s",oldConfig.distinguishedName,e));
            return false;
        }
    }

    public Boolean addColumnsToUpdate(UpdateQuery updateObject) {
        updateObject.setUpdateColumn("OBJECT_NAME", name);
        updateObject.setUpdateColumn("CANONICAL_NAME", canonicalName);
        updateObject.setUpdateColumn("DISTINGUISHED_NAME", distinguishedName);
        updateObject.setUpdateColumn("PARENT_GUID", parentGuid.toString());
        updateObject.setUpdateColumn("IS_DELETED", isDeleted);
        return true;
    }
}
//ignoreI18n_end
