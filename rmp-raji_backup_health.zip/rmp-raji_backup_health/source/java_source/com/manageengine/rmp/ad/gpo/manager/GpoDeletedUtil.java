/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.manager;

import com.manageengine.rmp.ad.backup.BackupUtil;
import com.manageengine.rmp.ad.backup.BackupImpl;
import com.manageengine.rmp.common.PsOperations;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.BackupType;
import com.manageengine.rmp.constants.ModificationResult;
import com.manageengine.rmp.util.DataTypeUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import com.manageengine.rmp.util.winutil.DirectoryUtil;
import com.manageengine.rmp.util.winutil.UNCAccess;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

/**
 * $Id$
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class GpoDeletedUtil {

    public HashMap<String, Properties> gpoDeletedDuplicate;
    GpoProp gpoProp;
    String gpoId;

    public GpoDeletedUtil() {
        gpoDeletedDuplicate = new HashMap<String, Properties>();
    }

    public GpoDeletedUtil(Properties domainDetails, String dName) {//Deletes GPO during GpoRestore
        try {
            gpoProp = new GpoProp(domainDetails);
            this.gpoId = GpoUtil.getGpoId(dName);
            gpoProp.bkpGpoMainDir = gpoProp.getGpoBackupDir(gpoProp.domainId);
            gpoProp.dcMainDir = UNCAccess.getRemoteFile(GpoProp.DC_MAIN_DIR, gpoProp.dcName);
            String dcGpoMainDirPath = UUID.randomUUID().toString();
            gpoProp.dcGpoMainDir = new File(gpoProp.dcMainDir, GpoProp.DC_GPO_BACKUP_DIR + dcGpoMainDirPath + "\\");
            gpoProp.tmpGpoMainDir = new File(gpoProp.bkpGpoMainDir, "TempGpo");
        } catch (Exception e) {
            LogWriter.gpo.severe("Exception caught: " + e);
        }
    }

    public Boolean deleteGroupPolicy(GpoRestore gpoRestore) {//Deletes GPO during Restore
        try {
            String computerName = GpoUtil.getComputerName(gpoProp.dcName, gpoProp.domainName);
            int exitCode = -1;
            UNCAccess.deleteDirectory(gpoProp.dcGpoMainDir);
            DirectoryUtil.emptyDirectory(gpoProp.tmpGpoMainDir);
            gpoProp.dcGpoLocalDir = UNCAccess.getLocalFilePath(gpoProp.dcGpoMainDir);
            HashMap result = GpoDcExec.restoreGpoRemote(PsOperations.GpoDelete, gpoProp.domainName, computerName,gpoProp.userDomainName ,gpoProp.userName, gpoProp.password, gpoId, gpoProp.dcGpoLocalDir.getPath(), gpoRestore.isPowerShell());
            if(result != null){
                exitCode = (Integer) result.get("ExitCode");
                gpoRestore.setPowerShell((Boolean) result.get("PowerShell"));
            }if(exitCode!=0){
                return false;
            }
        } catch (Exception ex) {
            LogWriter.gpo.severe("Exception caught: " + ex.getMessage());
            return false;
        } finally {
            UNCAccess.deleteDirectory(gpoProp.dcGpoMainDir);
        }
        return true;
    }

    public boolean deletedDuplicateHandler(Properties prop, boolean isDeleted, boolean isLastBackupDeleted, boolean isFullBackup, String gpoID, Long domainId) {
        if (isDeleted) {
            if (!GpoUtil.hasGpoHistory(domainId, gpoID)) {
                return true;
            }
            if (!gpoDeletedDuplicate.containsKey(gpoID)) {
                gpoDeletedDuplicate.put(gpoID, prop);
            }
            return true;
        } else {
            gpoDeletedDuplicate.put(gpoID, null);
        }
        return false;
    }

    public void deletedGpoBackup(BackupImpl backupImpl) {
        if (!backupImpl.isInitBackup) {
            BackupType tempBackupType = backupImpl.backupType;
            backupImpl.backupType = BackupType.DeletedGpoBackup;
            for (Map.Entry<String, Properties> propEntry : gpoDeletedDuplicate.entrySet()) {
                if (propEntry.getValue() != null) {
                    Properties propTemp = propEntry.getValue();
                    String displayName = propTemp.getProperty("displayName");
                    if(displayName == null || displayName.isEmpty()) {
                        propTemp.put("displayName", propTemp.get("name"));
                    }
                    propTemp.remove("name");
                    backupImpl.backupObject(propTemp);
                }
            }
            backupImpl.backupType = tempBackupType;//Check if necessary
            gpoDeletedDuplicate.clear();
        }
    }

    //backup deleted GPO Objects // Not Used
    public void backupDeletedGpo(int[] objWiseCount, BackupImpl backupImpl) {
        backupImpl.backupType = BackupType.DeletedGpoBackup;
        LogWriter.gpo.info("--Backup deleted Gpo Starts--");
        for (Map.Entry<String, Properties> obj : gpoDeletedDuplicate.entrySet()) {
            try {
                if (obj != null) {
                    String dName = BackupUtil.getString(obj.getValue(), "distinguishedName");
                    LogWriter.gpo.info(String.format("Backup deleted Gpo : %s", dName));
                    backupImpl.addRow(obj.getValue());
                }
            } catch (RuntimeException e) {
                LogWriter.gpo.severe(String.format("Backup deleted Gpo : %s", e));
            }
        }
    }

    public static boolean isGpoDeleted(byte[] objectGuid, String domainName) {
        try {
            String objGuid = DataTypeUtil.getHexStringFromGuid(objectGuid);
            Properties properties = RMPDomainHandler.getDomainDetailsByName(domainName);
            ArrayList attributes = new ArrayList();//ADSNativeHandler.executeADQuery(properties, new String[]{"distinguishedName"}, String.format("(objectGuid=%s", objGuid), GpoUtil.policiesContainerDN(domainName));//NO I18N
            if (!(attributes == null || attributes.isEmpty())) {
                return true;
            }
        } catch (Exception e) {
            LogWriter.gpo.severe("Exception caught: " + e.getMessage());
        }
        return false;
    }

    public static ModificationResult restoreDeletedGpo(String objectGuid, String dName, GpoRestore gpoRestore) {
        LogWriter.gpo.info("--Recover deleted Gpo Starts--");
        return gpoRestore.restoreDeletedGpo(objectGuid, dName);
    }
}

//ignoreI18n_end
