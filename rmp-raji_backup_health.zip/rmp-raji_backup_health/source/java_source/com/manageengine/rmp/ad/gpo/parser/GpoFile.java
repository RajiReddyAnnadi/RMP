/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.parser;

import com.manageengine.rmp.ad.gpo.constants.*;
import java.io.File;
import java.util.ArrayList;

/**
 *
 * @author lucky-2306
 */
public abstract class GpoFile {
    
    public ArrayList<AbstractGpoEntry> entries;
        
    public abstract java.util.ArrayList<AbstractGpoEntry> getEntries();

    public abstract GpoFileType getType();

    public abstract String getFileName();

    public abstract void setFileName(String value);

    public abstract Object fillPolicies(String rootFolder, GpoConfigType gpoUserMach, GpoFileType gpoFileType, String domainName, String dcName, String adminName, String password);
    
    public abstract Object fillPolicies(File rootFolder, GpoConfigType gpoUserMach, GpoFileType gpoFileType, String domainName, String dcName, String adminName, String password);

    public abstract boolean contains(AbstractGpoEntry gpoEntry);

    public abstract void deleteValue(AbstractGpoEntry gpoEntry);

    public abstract AbstractGpoEntry getValue(AbstractGpoEntry gpoEntry);

    public abstract void setValue(AbstractGpoEntry gpoEntry);

    public static GpoFile getGpoFileType(GpoFileType gpoFileType, GpoFile gpoFile) {
        if (gpoFileType == GpoFileType.Pol) {
            gpoFile = (PolFile) new PolFile();
        } else if (gpoFileType == GpoFileType.Gpt) {
            gpoFile = (GptFile) new GptFile();
        } else if (gpoFileType == GpoFileType.Audit) {
            gpoFile = (AuditFile) new AuditFile();
        } else {
            throw new UnsupportedOperationException();
        }
        return gpoFile;
    }
}
