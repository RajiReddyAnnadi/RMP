package com.manageengine.rmp.ad.backup;
import com.manageengine.ads.fw.adsync.ADSyncHandler;
import com.manageengine.ads.fw.domain.ADSDomainHandler;
import com.manageengine.me.clientSync.ClientSyncManager;
import com.manageengine.rmp.ad.adsync.SyncFilter;
import com.manageengine.rmp.admin.NotificationAPI;
import com.manageengine.rmp.admin.constants.NotificationType;
import com.manageengine.rmp.clientSync.RunningOperationSync;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.OperationsUtil;
import com.manageengine.rmp.constants.BackupType;
import com.manageengine.rmp.constants.DataStoreType;
import com.manageengine.rmp.constants.OperationStatus;
import com.manageengine.rmp.constants.OperationType;
import com.manageengine.rmp.constants.StatusId;
import com.manageengine.rmp.dashboard.ScheduleRetention;
import com.manageengine.rmp.dataobjects.OperationInfo;
import com.manageengine.rmp.settings.AddDomainServ;
import com.manageengine.rmp.settings.BackupSettings;
import com.manageengine.rmp.settings.DomainSettings;
import com.manageengine.rmp.settings.customattributes.CustomAttributesBackup;
import com.manageengine.rmp.settings.dataobjects.BackupSettingsObject;
import com.manageengine.rmp.util.ADObjectsUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import org.json.JSONException;

/**
 *
 * $Id$
 *
 * @author navarajan-1466
 */
//ignoreI18n_start
public class BackupInitiator implements Runnable {

    protected static HashMap<Long, Long> _currentBackupJobs = new HashMap<Long, Long>();
    private static final Object BACKUP_JOB_LOCK = new Object();
    public static HashMap<Long, OperationInfo> backupStatus = new HashMap<Long, OperationInfo>();

    public static OperationInfo doBackup(Long domainId, String initiator) throws IOException, JSONException {
        return doBackup(domainId, initiator, SyncFilter.getSyncObjects(), -1);
    }

    public static OperationInfo doBackup(final Long domainId, String initiator, String[] syncFilter, long operationId) {
        try {
            BackupImpl backupImpl;
            BackupType backupType = BackupUtil.getBackupStat(domainId) == null ? BackupType.InitBackup : BackupType.Sync;
            Properties domainSettings = RMPDomainHandler.getDomainDetailsById(domainId);
            ArrayList dcList = (ArrayList)domainSettings.get("DOMAIN_CONTROLLER_LIST");
            if(dcList.size()==0){
                LogWriter.backup.severe(String.format("BackupInitiator.DoBackup No DC's configured domainId:%1$s initiator:%2$s ", domainId, initiator));
                return null;
            }
            CustomAttributesBackup customAttributeBackup;
            synchronized (BACKUP_JOB_LOCK) {
                if (_currentBackupJobs.containsKey(domainId)) {
                    BackupManager backupManager = new BackupManager();
                    backupManager.onTaskComplete(operationId, initiator);
                    return null;
                } else {
                    if (RMPDomainHandler.getDomainDetailsById(domainId).getProperty("IS_AUTHENTICATION_REQUIRED").equals("false")) {
                        String credentialError = DomainSettings.checkForCredentialError(domainId);
                        if (!credentialError.equals("success")) {
                            OperationInfo operationInfo = credentialErrorOperationInfo(domainId, credentialError, initiator);
                            return operationInfo;
                        }
                    }
                    Thread thread = new Thread() {
                        @Override
                        public void run() {
                            RMPDomainHandler.setDCTimeZoneOffset(domainId);
                        }
                    };
                    thread.start();
                    customAttributeBackup = new CustomAttributesBackup(domainId, domainSettings, backupType, initiator);
                    backupImpl = new BackupImpl(domainId, backupType, initiator, operationId, domainSettings.getProperty("DOMAIN_NAME"), customAttributeBackup);
                    _currentBackupJobs.put(domainId, backupImpl.backupInfo.operationId);
                }
            }
            backupStatus.put(domainId, backupImpl.backupInfo);
            customAttributeBackup.backupCustomAttributes();
            BackupInitiator backupInitiator = new BackupInitiator(backupImpl, domainSettings, syncFilter);
            Thread backupThread = new Thread(backupInitiator);
            backupThread.start();
            ClientSyncManager.update("0", DataStoreType.RecentOperationInfo.id, backupImpl.backupInfo.operationId, backupImpl.backupInfo);
            return backupImpl.backupInfo;
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupInitiator.DoBackup domainId:%1$s initiator:%2$s \nexcep:%3$s", domainId, initiator, e));
            e.printStackTrace();
            return null;
        }
    }
    public static OperationInfo credentialErrorOperationInfo(Long domainId, String credentialError, String initiator) {
        try {
            long statusId = credentialError.contains("user/system.no_adminprivilege") ? StatusId.AccessDeniedCredentials.value : StatusId.InvalidCredentials.value;
            OperationInfo operationInfo = new OperationInfo(domainId, OperationType.Backup, initiator, statusId, -1);
            operationInfo.status = OperationStatus.Failed;
            BackupUpdater updater = new BackupUpdater();
            updater.updateBackupStartInfo(operationInfo);
            //JSONObject mailerContent = BackupUpdater.setBackupMailInfo(operationInfo);

            LogWriter.general.info("Mail: Calling NotificationAPI.notifyAD() from BackupInitiator.credentialErrorOperationInfo()");
            NotificationAPI.notifyAD(NotificationType.ADBackup, operationInfo);

            RunningOperationSync.remove(operationInfo);
            return operationInfo;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    //The below method is used for OuSync using DirSync approach
    public static Boolean DoOuSync(String domainIdString, String initiator) {
        try {
            Long domainId = Long.parseLong(domainIdString);
            Properties prop = RMPDomainHandler.getDomainDetailsById(domainId);
            BackupImpl backup = new BackupImpl(domainId, BackupType.OuSync, initiator, -1, prop.getProperty("DOMAIN_NAME"), new CustomAttributesBackup());
            String[] objects = {"organizationalunit"};
            ADSyncHandler.synchronizeData(prop, objects, false, false, backup);
        } catch (Exception e) {
            LogWriter.backup.severe("Error in DoOuSync. domainId=" + domainIdString + " " + e.toString());
            e.printStackTrace();
        }
        return true;
    }
    private BackupImpl backupImpl;
    private Properties domainSettings;
    private String[] syncFilters;

    public BackupInitiator(BackupImpl backupInfo, Properties domainSettings, String[] syncFilters) {
        this.backupImpl = backupInfo;
        this.domainSettings = domainSettings;
        this.syncFilters = syncFilters;
    }

    @Override
    public void run() {
        try {
            BackupUtil.checkForDataMigration();
            if (ScheduleRetention.isRetentionSchedulerRunning()) {
                OperationsUtil.waitForRunningOperations(backupImpl.domainId, 3000);
            }
            BackupSettingsObject backupSettings = BackupSettings.getBackupSettings(backupImpl.backupInfo.domainId);
            backupImpl.defaultNamingContext = this.domainSettings.getProperty("DEFAULT_NAMING_CONTEXT");
            backupImpl.trackDisabledObjects = backupSettings.trackDisabled;
            backupImpl.isOUSelectionChanged = backupSettings.isOUSelectionChanged;
            if (backupSettings.isReplicate) {
                ADObjectsUtil.forceReplicate(domainSettings);
            }
            ADSyncHandler.synchronizeData(domainSettings, syncFilters, false, false, backupImpl);
        } catch (Exception e) {
            LogWriter.backup.info(String.format("BackupInitiator.run %s %s", backupImpl.backupInfo.domainId, e));
            e.printStackTrace();
        } finally {
            removeCurrentBackupJob(backupImpl.backupInfo.domainId, backupImpl.backupInfo.operationId);
        }
    }

    public static void removeCurrentBackupJob(long domainId, long operationId) {
        try {
            synchronized (BACKUP_JOB_LOCK) {
                if (backupStatus.containsKey(domainId) && backupStatus.get(domainId).operationId == operationId) {
                    _currentBackupJobs.remove(domainId);
                    backupStatus.remove(domainId);
                }
            }
        } catch (Exception e) {
            LogWriter.backup.info(String.format("BackupInitiator.removeCurrentBackupJob %s %s", domainId, e));
        }
    }
    
    
}
//ignoreI18n_end
