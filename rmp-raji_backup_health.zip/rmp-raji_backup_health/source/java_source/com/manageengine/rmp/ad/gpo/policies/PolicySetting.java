/**
 *
 * $Id$ :
 *
 * @author lucky-2306
 */
package com.manageengine.rmp.ad.gpo.policies;

import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.ad.gpo.constants.GpoConfigType;
import com.manageengine.rmp.ad.gpo.constants.GpoFileType;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ObjectType;
import java.util.ArrayList;
import java.util.Properties;

//ignoreI18n_start
public class PolicySetting {

    public Integer settingId;
    public Integer uniqueId;
    public Integer multivalMap;
    public String policyName;
    public GpoConfigType configType;
    public GpoFileType settingType;
    public String policyPath;
    public String adDatatype;
    public boolean isCustom;
    public boolean isMultiValued;
    public boolean isMultiPolicy;
    public boolean isRanged;
    public boolean specialCaseonBackup;
    public boolean specialCaseonRecovery;
    public String backupDatatype;
    public Integer attributeMaskIndex;
    public String specialAttribute;
    public String fileName;

    public PolicySetting() {
    }

    public PolicySetting(Integer polId, String columnName) {
        init(polId, columnName, columnName);
    }

    public PolicySetting(Integer polId, String columnName1, String columnName2) {
        init(polId, columnName1, columnName2);
    }

    public PolicySetting(Integer polId) {
        init(polId, PolicySettingUtil.GPO_SETTING_ID, PolicySettingUtil.GPO_ATTRIB_MASK_INDEX);
    }

    private void init(Integer polId, String columnName1, String columnName2) {
        try {
            Properties adProperties = PolicySettingUtil.getPolicyProperties(polId, columnName1, PolicySettingUtil.GPO_TABLE_GENERAL).get(0);
            Properties rmpProperties = PolicySettingUtil.getPolicyProperties(polId, columnName2, PolicySettingUtil.GPO_TABLE_RMP).get(0);
            assignValues(adProperties, rmpProperties);
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format("PolicySetting.Construct1 SettingId:%s exception:%s", settingId, LogWriter.getStackTrace(e)));//No I18N
        }
    }

    public PolicySetting(Properties adProperties, Properties rmpProperties) {
        try {
            assignValues(adProperties, rmpProperties);
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format("PolicySetting.Construct1 SettingId:%s exception:%s", settingId, e));//No I18N
        }
    }

    public PolicySetting(String policyPath) {
        try {
            Properties adProperties = PolicySettingUtil.getPolicyProperties(policyPath, PolicySettingUtil.GPO_RAW_FILE_ENTRY, PolicySettingUtil.GPO_TABLE_GENERAL).get(0);
            this.uniqueId = Integer.parseInt(adProperties.getProperty(PolicySettingUtil.GPO_UNIQUE_ID));
            Properties rmpProperties = PolicySettingUtil.getPolicyProperties(uniqueId, PolicySettingUtil.GPO_UNIQUE_ID, PolicySettingUtil.GPO_TABLE_RMP).get(0);
            assignValues(adProperties, rmpProperties);
        } catch (Exception e) {
            LogWriter.general.warning(String.format("PolicySetting.Construct2 policyPath:%s exception:%s", policyPath, e));//No I18N
        }
    }

    public static ArrayList<PolicySetting> getPolicySettings(int settingId) {
        try {
            ArrayList<PolicySetting> multiSetting = new ArrayList<PolicySetting>();
            ArrayList<Properties> adPropList = PolicySettingUtil.getPolicyProperties(settingId, PolicySettingUtil.GPO_SETTING_ID, PolicySettingUtil.GPO_TABLE_GENERAL);
            
            for (Properties adProp : adPropList) {
                int uniqueID = Integer.parseInt(adProp.getProperty(PolicySettingUtil.GPO_UNIQUE_ID));
                Properties rmpProp = PolicySettingUtil.getPolicyProperties(uniqueID, PolicySettingUtil.GPO_UNIQUE_ID, PolicySettingUtil.GPO_TABLE_RMP).get(0);
                multiSetting.add(new PolicySetting(adProp, rmpProp));
            }
            return multiSetting;
        } catch (Exception e) {
            LogWriter.general.warning(String.format("PolicySetting.getPolicySettings exception:%s", e));//No I18N
            return null;
        }
    }

    public void assignValues(String specialAttribute) {
        this.attributeMaskIndex = null;
        this.specialAttribute = specialAttribute;
    }

    public void assignValues(Properties adProp, Properties rmpProp) {
        try {
            this.settingId = Integer.parseInt(adProp.getProperty(PolicySettingUtil.GPO_SETTING_ID));
            this.uniqueId = Integer.parseInt(adProp.getProperty(PolicySettingUtil.GPO_UNIQUE_ID));
            this.multivalMap = Integer.parseInt(adProp.getProperty(PolicySettingUtil.GPO_MULTIVAL_MAP));
            this.policyPath = adProp.getProperty(PolicySettingUtil.GPO_RAW_FILE_ENTRY);
            this.policyName = adProp.getProperty(PolicySettingUtil.GPO_POLICY_NAME);// need to internationalise
            this.configType = GpoConfigType.getGpoConfigType(adProp.getProperty(PolicySettingUtil.GPO_CONFIG_TYPE));
            this.settingType = GpoFileType.getGpoFileType(adProp.getProperty(PolicySettingUtil.GPO_SETTING_TYPE));
            this.adDatatype = "1";//rmp.getProperty("DATATYPE").toString();
            this.isCustom = false;//Boolean.parseBoolean(ad.getProperty("IS_CUSTOM").toString());
            this.isRanged = Boolean.parseBoolean(adProp.getProperty(PolicySettingUtil.GPO_IS_RANGED));
            this.isMultiValued = Boolean.parseBoolean(adProp.getProperty(PolicySettingUtil.GPO_IS_MULTIVALUE));
            this.isMultiPolicy = Boolean.parseBoolean(adProp.getProperty(PolicySettingUtil.GPO_IS_MULTIPOLICY));
            this.specialCaseonBackup = Boolean.parseBoolean(rmpProp.getProperty(PolicySettingUtil.GPO_HAS_SPECIALCASE_ON_BACKUP));
            this.specialCaseonRecovery = Boolean.parseBoolean(rmpProp.getProperty(PolicySettingUtil.GPO_HAS_SPECIALCASE_ON_RECOVERY));
            this.backupDatatype = rmpProp.getProperty(PolicySettingUtil.GPO_BACKUP_DATATYPE);
            this.fileName = adProp.getProperty(PolicySettingUtil.GPO_FILE_NAME);
            this.attributeMaskIndex = (Integer.parseInt(rmpProp.getProperty("ATTRIB_MASK_INDEX"))) - ((ObjectType.GroupPolicy.id.intValue() - 1) * 256);
        } catch (Exception e) {
            LogWriter.general.warning(String.format("PolicySetting.assignValues ad:%s rmp:%s exception:%s", JSONObjectUtil.toJsonString(adProp), JSONObjectUtil.toJsonString(rmpProp), e));//No I18N
        }
    }
}

//ignoreI18n_end
