/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.manager;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.Query;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.jni.ADSNativeHandler;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.ad.adsync.BaseDNPrepender;
import com.manageengine.rmp.ad.adsync.SyncFilter;
import com.manageengine.rmp.ad.backup.BackupImpl;
import com.manageengine.rmp.ad.backup.BackupUpdater;
import com.manageengine.rmp.ad.backup.BackupUtil;
import com.manageengine.rmp.ad.rangedattributes.ForwardLink;
import com.manageengine.rmp.ad.rangedattributes.FrontLinkAttrManager;
import com.manageengine.rmp.ad.rangedattributes.LinkType;
import com.manageengine.rmp.ad.rangedattributes.LinkedAttributesUtil;
import static com.manageengine.rmp.ad.rangedattributes.LinkedAttributesUtil.updateRangedAttrMetaData;
import com.manageengine.rmp.ad.rangedattributes.RangedAttrObject;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.recovery.RecoveryHandler;
import com.manageengine.rmp.util.LdapUtil;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Objects;
import java.util.Properties;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author poornima-3055
 */
public class GPFrontLinkAttrManager extends FrontLinkAttrManager{

    private ObjectType objectType;

    public GPFrontLinkAttrManager(Long domainId, String domainName, Long backupId, boolean isInitBackup, boolean isFullSync, String orgObjectType, BackupUpdater backupUpdater, HashMap<String, RangedAttrObject> backLinkMetaInfo) {
        super(domainId, domainName, backupId, isInitBackup, isFullSync, backupUpdater, backLinkMetaInfo);
    }
    
    public void setObjectType(String orgObjectType)
    {
        this.objectType = orgObjectType.equalsIgnoreCase("ouGPLinksAttr") ? ObjectType.OU : ObjectType.Site;
    }
    
    @Override
    protected HashMap fillAllObjectDetails()
    {
        long[] objectTypeSelect = new long[]{ObjectType.OU.maskValue, ObjectType.Site.maskValue, ObjectType.GroupPolicy.maskValue};
        return RangedAttrObject.fillAllObjectDetails(domainId, isFullSync, objectTypeSelect);
    }
    
    @Override
    protected String setTableName()
    {
        return TableName.RMP_GPO_LINK_ATTRIBUTES+"_"+domainId;
    }
    
    @Override
    public Boolean dbDumperRangedAttributes() 
    {
        return backupUpdater.dumpGPLinkAttrInfoData();
    }
    
    @Override
    protected ArrayList<String> getMembersDN(Properties prop, String attributeName)
    {
        return GpoLinksUtil.getGPLinksArrayList((JSONObject) prop.get(attributeName));
    }

    @Override
    public Boolean updateLinkAttrInfo(Properties prop, ForwardLink forwardLink, Long backupId, LinkType linkType, String objectGUID, String backLinkGUID) throws Exception
    {
        String attributeName = forwardLink.getAttributeName() + (Objects.equals(linkType.memberTypeId, LinkType.Total.memberTypeId) ? LinkType.getLinkRangeType(LinkType.Added.memberTypeId) : LinkType.getLinkRangeType(linkType.memberTypeId));
        JSONObject gpoInfo = (JSONObject) prop.get(attributeName);
        String gpoDN = GpoUtil.getGpoDn(backLinkGUID.toUpperCase(), domainName);
        JSONObject memberInfo = gpoInfo.getJSONObject(gpoDN);
        if(memberInfo == null){
            gpoDN = GpoUtil.getGpoDn(backLinkGUID.toLowerCase(), domainName);
            memberInfo = gpoInfo.getJSONObject(gpoDN);
        }
        return backupUpdater.updateGpoLinkAttrInfo(forwardLink.linkId, backupId, linkType.memberTypeId, objectType.maskValue, objectGUID.toLowerCase(), backLinkGUID.toLowerCase(), memberInfo.getInt("status"), memberInfo.getInt("priority")); //No I18N
    }
    
    @Override
     public RangedAttrObject getRangedAttrObject(Properties prop, BackupObject backupObject, BackupObject lastBackupObject) throws Exception {
         if(lastBackupObject.linkId == null) {
                updateRangedAttrMetaData(backupObject.objId.toString(), backupObject.distinguishedName, domainId, objectType,backupObject.backupId);
        }
         RangedAttrObject object = super.getRangedAttrObject(prop, backupObject, lastBackupObject);
         backupObject.objTyp = lastBackupObject.objTyp = object.objType = objectType;
         return object;
     }
    
    @Override
    public Boolean modifyLinksFromCurrentBackup(Properties prop, String objectGuid, ArrayList<String> linkGuidList) 
    {
        String[] linkGuid = (String[]) linkGuidList.toArray(new String[linkGuidList.size()]);
        try 
        {
            Criteria criteria = new Criteria(Column.getColumn(tableName, "LINKS_TYPE"), 0, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(tableName, "FORWARD_LINK_ID"), forwardLink.linkId, QueryConstants.EQUAL); //No I18N
            criteria = criteria.and(Column.getColumn(tableName, "FRONTLINK_OBJECT_GUID"), objectGuid, QueryConstants.EQUAL); //No I18N
            criteria = criteria.and(Column.getColumn(tableName, "BACKLINK_OBJECT_GUID"), linkGuid, QueryConstants.IN); //No I18N
            String attributeName = forwardLink.getAttributeName() + LinkType.getLinkRangeType(LinkType.Modified.memberTypeId);
            DataObject dobj= CommonUtil.getPersistence().get(tableName, criteria);
            if(dobj.size(tableName) > 0)
            {
                Iterator itr = dobj.getRows(tableName);
                while(itr.hasNext())
                {
                    Row row = (Row)itr.next();
                    String backLinkGuid = (String) row.get("BACKLINK_OBJECT_GUID");
                    JSONObject backLinkInfo = ((JSONObject) prop.get(attributeName)).getJSONObject(GpoUtil.getGpoDn(backLinkGuid.toUpperCase(), domainName));
                    row.set("STATUS", backLinkInfo.getInt("status")); //No I18N
                    row.set("PRIORITY", backLinkInfo.getInt("priority")); //No I18N
                    dobj.updateRow(row);
                }
                CommonUtil.getPersistence().update(dobj);
            }
        } catch (Exception e) 
        {
            e.printStackTrace();
        }
        return true;
    }

    @Override
    public Boolean finalUpdateToObject(BackupImpl backupImpl) 
    {
        backupUpdater.updateRangedAttrMetadatainObj(frontLinkMetaInfo, backupImpl, true, backupImpl.isInitBackup);
        return true;
    }
    
    public static Properties restoreRangedAttr(Properties domainDetails, Long restoreBackupId, String objectGuid, int maskIndex, ObjectType objectType) 
    {
        Connection con = null;
        DataSet dset = null;
        Boolean result = true;
        long added = 0, skipped = 0, removed = 0, modified = 0;
        try  
        {
            Long domainId = Long.parseLong(domainDetails.getProperty("DOMAIN_ID"));
            String domainName = domainDetails.getProperty("DOMAIN_NAME");
            con = RelationalAPI.getInstance().getConnection();
            JSONObject restoreInfo = GpoLinksUtil.getNewRestoreInfo();
            JSONArray gpLinkBackupInfo;
            if(restoreBackupId != null) 
            {
                Query query = GpoLinksUtil.getLinksListFromRangedAttr(domainId, maskIndex, restoreBackupId, objectGuid, 0, "FRONTLINK_OBJECT_GUID", "BACKLINK_OBJECT_GUID", "BACKLINK_OBJECT_DN", false, 0, 0);// No I18N
                dset = RelationalAPI.getInstance().executeQuery(query, con);
                gpLinkBackupInfo = GpoLinksUtil.getGpLinkBackupInfo(domainDetails, dset, restoreInfo, domainId);
            }
            else
            {
                gpLinkBackupInfo = new JSONArray();
            }
            String searchString = "(objectGUID=" + LdapUtil.encodeObjectGUID(objectGuid) + ")"; //No I18N
            String defaultNamingContext = domainDetails.getProperty("DEFAULT_NAMING_CONTEXT");
            String namingContext = (objectType == ObjectType.Site ? BaseDNPrepender.getBaseDNPrepender(SyncFilter.site.filterId).baseDNString : "") + defaultNamingContext;
            ArrayList<Properties> ouProps = ADSNativeHandler.executeADQuery(domainDetails, new String[]{"gPLink", "distinguishedName"}, searchString, namingContext); //No I18N
            if(!ouProps.isEmpty())
            {
                Properties prop = ouProps.get(0);
                if (!prop.containsKey("distinguishedName") || (prop.containsKey("isDeleted") && BackupUtil.getBoolean(prop, "isDeleted") != null && BackupUtil.getBoolean(prop, "isDeleted")))
                {
                    skipped++;
                } 
                else
                {
                    String gpLink = prop.containsKey("gPLink") ? BackupUtil.getString(prop, "gPLink") : "" ;    //No I18N
                    String restoreGPLink = GpoLinksUtil.gpLinkRestoreInfo(domainName, restoreInfo, gpLink, gpLinkBackupInfo);
                    if(restoreBackupId == null && restoreGPLink.equalsIgnoreCase(" "))
                    {
                        String policiesContainerDN = GpoUtil.policiesContainerDNWithDNC(defaultNamingContext);
                        restoreInfo.put("removed", StringUtils.countMatches(gpLink, policiesContainerDN));
                    }
                    RecoveryHandler recoveryHandler = new RecoveryHandler(domainDetails, objectType, objectGuid, BackupUtil.getString(prop, "distinguishedName"));   //No I18N
                    Hashtable<String, Object> attributeValue = new Hashtable();
                    attributeValue.put(recoveryHandler.ATTR_VALUE_COUNT, (long) 1);
                    attributeValue.put(recoveryHandler.ATTR_NAME, "gPLink");
                    attributeValue.put(recoveryHandler.DATA_HANDLER_TYPE, (long) 3);
                    attributeValue.put(recoveryHandler.ATTR_VALUE, restoreGPLink);
                    recoveryHandler.propList.add(attributeValue);
                    boolean isRestored = true;
                    if(!(restoreGPLink.equalsIgnoreCase(gpLink)))
                    {
                        isRestored = recoveryHandler.recoverObject();
                    }
                    if(isRestored) 
                    {
                        added += restoreInfo.getLong("added");  //No I18N
                        modified += restoreInfo.getLong("modified");    //No I18N
                        removed += restoreInfo.getLong("removed");  //No I18N
                        skipped += restoreInfo.getLong("skipped");  //No I18N
                    }
                    result = result && isRestored;
                    recoveryHandler.clearRequiredLists();
                }
            }
            else
            {
                result = result && false;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally 
        {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        Properties restoreResult = new Properties();
        restoreResult.put("result", result);
        restoreResult.put("added", added);
        restoreResult.put("removed", removed);
        restoreResult.put("modified", modified);
        restoreResult.put("skipped",skipped);
        return restoreResult;
    }
    
}
