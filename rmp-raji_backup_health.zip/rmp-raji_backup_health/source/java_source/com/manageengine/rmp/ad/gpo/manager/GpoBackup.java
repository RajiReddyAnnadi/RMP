/**
 * $Id$
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.manager;

import com.adventnet.persistence.DataObject;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.ad.backup.BackupImpl;
import com.manageengine.rmp.ad.backup.BackupUtil;
import com.manageengine.rmp.ad.gpo.constants.GpoAddRem;
import com.manageengine.rmp.ad.gpo.constants.GpoConfigType;
import com.manageengine.rmp.ad.gpo.constants.GpoErrors;
import com.manageengine.rmp.ad.gpo.constants.GpoFileType;
import com.manageengine.rmp.ad.gpo.parser.*;
import com.manageengine.rmp.ad.gpo.policies.PolicySetting;
import com.manageengine.rmp.ad.rangedattributes.LinkedAttributesUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.PsOperations;
import com.manageengine.rmp.constants.BackupType;
import com.manageengine.rmp.constants.ChangeType;
import com.manageengine.rmp.constants.ModificationResult;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.util.winutil.DirectoryUtil;
import com.manageengine.rmp.util.winutil.UNCAccess;

import java.io.File;
import java.util.*;
import java.util.Map.Entry;
import java.util.logging.Level;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class GpoBackup extends GpoDeletedUtil {

    private final PsOperations gpoOperation;
    public String gpoBackupId;
    public String gpoId;
    public String backupId;
    public boolean isUserConfig, isMachConfig;
    public BackupObject backupObject, lastBackupObject;
    private BackupImpl backupImpl;
    public GpoProp gpoProp;
    private HashMap<Integer, ArrayList<PolEntryConcise>> multivalPolicies;
    private boolean hasRemConnection;
    public long gpoErrorCode;
    private boolean isPowerShell = true;
    private String error = null;
    private static boolean isGpoBackedup;
    public GpoBackup(BackupImpl backupImpl, Long domainId, Long backupId) {//backup
        LogWriter.gpo.log(Level.INFO, "GpoBackup Constructor . . . ");
        gpoDeletedDuplicate = new HashMap<String, Properties>();
        multivalPolicies = new HashMap<Integer, ArrayList<PolEntryConcise>>();
        init(domainId);
        this.backupImpl = backupImpl;
        gpoProp.backupId = String.valueOf(backupId);
        isGpoBackedup=true;
        isMachConfig = true;//ToDo: check backupObject.attributeList.Get(1792 + 93);
        isUserConfig = true;//ToDo: check backupObject.attributeList.Get(1792 + 94);
        gpoOperation = PsOperations.GpoBackup;//remove
        hasRemConnection = false;
    }

    public GpoBackup(Long domainMask, String backupId) { //restore
        LogWriter.gpo.log(Level.INFO, "GpoBackup Constructor for Restore. . . ");
        init(domainMask);
        gpoProp.backupId = backupId;
        gpoOperation = PsOperations.GpoRestore;
    }

    private void init(long domainMask) {
        gpoProp = new GpoProp(domainMask);
        gpoProp.bkpGpoMainDir = gpoProp.getGpoBackupDir(domainMask);
        gpoProp.tmpGpoMainDir = new File(gpoProp.bkpGpoMainDir, "TempGpo");
        DirectoryUtil.createDirectoryIfNotExists(gpoProp.tmpGpoMainDir);
        gpoProp.dcMainDir = UNCAccess.getRemoteFile(GpoProp.DC_MAIN_DIR, gpoProp.dcName);
        String dcGpoMainDirPath = GpoProp.DC_MAIN_DIR + "\\" + GpoProp.DC_GPO_BACKUP_DIR + "_" + UUID.randomUUID();
        gpoProp.dcGpoMainDir = UNCAccess.getRemoteFile(dcGpoMainDirPath, gpoProp.dcName);
    }

    //called during backup
    public void initBackupGpos(BackupObject backupObject, BackupObject lastBackupObject) {
        gpoId = null;
        this.backupObject = backupObject;
        this.lastBackupObject = lastBackupObject;
        multivalPolicies.clear();
        initBackupGpos();
    }

    public void initBackupGpos() {
        try {
            LogWriter.gpo.info(String.format("Initiating Backup for %s  %s ", backupObject.objNam, backupObject.distinguishedName));
            if (!hasRemConnection) {
                UNCAccess.openRemoteConnection(gpoProp.dcName, gpoProp.adminName, gpoProp.password);
                hasRemConnection = true;
            }
            DirectoryUtil.emptyDirectory(gpoProp.tmpGpoMainDir);
            GpoUtil.checkDcDirsPresent(gpoProp);
            boolean isDirCreated = UNCAccess.createDirectory(gpoProp.dcGpoMainDir);
            if (!isDirCreated) {
                gpoErrorCode = GpoErrors.RemoteDirCreationFail.errorId;
                GpoUtil.updateFailedGPO(gpoProp.domainId, GpoUtil.getGpoId(backupObject.distinguishedName), backupObject.objNam, backupObject.distinguishedName, GpoErrors.getName((int) gpoErrorCode), gpoErrorCode);
                return;
            }
            gpoId = GpoUtil.getGpoId(backupObject.distinguishedName);
            gpoProp.bkpGpoDir = new File(gpoProp.bkpGpoMainDir, GpoUtil.addBracesGpoID(gpoId));
            gpoProp.dcGpoLocalDir = UNCAccess.getLocalFilePath(gpoProp.dcGpoMainDir);
            HashMap result = GpoDcExec.backupGpoRemote(gpoProp, gpoProp.dcGpoLocalDir.getPath(), gpoId, true, isPowerShell);
            if(result != null){
                gpoErrorCode = (Long) result.get("ExitCode");
                isPowerShell = (Boolean) result.get("PowerShell");
                error = (String) result.get("Error");
            }
            else{
                gpoErrorCode = GpoErrors.unknownError.errorId;
            }
            if (gpoErrorCode == 0L) {
                this.backupId = gpoProp.dcGpoDir.getName();
                UNCAccess.copyDirFromRemote(gpoProp.dcGpoMainDir, gpoProp.tmpGpoMainDir);
                gpoProp.tmpGpoDir = new File(gpoProp.tmpGpoMainDir, this.backupId);
                ModificationResult modResult = gpoChangesBackup();//policies backup here
                if (modResult == ModificationResult.Modified) {
                    if ((gpoProp.bkpGpoDir).isDirectory()) {
                        DirectoryUtil.emptyDirectory(gpoProp.bkpGpoDir);
                    }
                    gpoProp.bkpGpoSubDir = new File (gpoProp.bkpGpoDir, gpoProp.tmpGpoDir.getName());
                    DirectoryUtil.copyDir(gpoProp.tmpGpoDir, gpoProp.bkpGpoSubDir);
                }
            }
            GpoUtil.updateFailedGPO(gpoProp.domainId, gpoId, backupObject.objNam, backupObject.distinguishedName, error, gpoErrorCode);
        } catch (Exception ex) {
            LogWriter.gpo.severe("Exception caught: " + ex + LogWriter.getStackTrace(ex));
            gpoErrorCode = GpoErrors.GpoFailed.errorId;
        } finally {
            isGpoBackedup = isGpoBackedup && (gpoErrorCode!=0L);
            UNCAccess.deleteDirectory(gpoProp.dcGpoMainDir);
            DirectoryUtil.deleteDirectory(gpoProp.tmpGpoDir);
        }
    }

    private ModificationResult gpoChangesBackup() {//backup
        try {
            for (GpoFileType fileType : GpoFileType.values()) {
                if (fileType == GpoFileType.Other) {
                    continue;
                }
                GpoFile gpoFileType = GpoFile.getGpoFileType(fileType, (GpoFile) null);
                for (GpoConfigType gpoUserMach : GpoConfigType.values) {
                    if ((gpoUserMach == GpoConfigType.Machine && isMachConfig) || (gpoUserMach == GpoConfigType.User && isUserConfig)) {
                        GpoFile gpoFileNew = (GpoFile) gpoFileType.fillPolicies(gpoProp.tmpGpoDir, gpoUserMach, fileType, gpoProp.domainName, gpoProp.dcName, gpoProp.adminName, gpoProp.password);
                        GpoFile gpoFileOld;
                        if ((backupObject.changeTyp & (ChangeType.Created.maskValue | ChangeType.Added.maskValue | ChangeType.ReAdded.maskValue | ChangeType.Recycled.maskValue)) > 0) {
                            gpoFileOld = gpoFileType;
                        } else {
                            File oldFileGpo = DirectoryUtil.findDirectory(gpoProp.bkpGpoDir, 1);
                            gpoFileOld = (GpoFile) gpoFileType.fillPolicies(oldFileGpo, gpoUserMach, fileType, gpoProp.domainName, gpoProp.dcName, gpoProp.adminName, gpoProp.password);
                        }
                        updateChangesInBackup(gpoFileOld, gpoFileNew);
                    }
                }
            }
            return ModificationResult.Modified;
        } catch (Exception ex) {
            LogWriter.gpo.severe("Exception caught: " + ex.getMessage());
            return ModificationResult.Failed;
        }
    }

    public ArrayList<Object> initBackupGpos(String gpoId, UUID objectGuid) {//restore
        try {
            DirectoryUtil.emptyDirectory(gpoProp.tmpGpoMainDir);
            UNCAccess.emptyDirectory(gpoProp.dcGpoMainDir);
            this.gpoId = gpoId;
            long isBackedUp;
            gpoProp.bkpGpoDir = GpoUtil.getGpoPath(gpoProp.bkpGpoMainDir, gpoId);
            gpoProp.dcGpoLocalDir = UNCAccess.getLocalFilePath(gpoProp.dcGpoMainDir);
            HashMap res = GpoDcExec.backupGpoRemote(gpoProp, gpoProp.dcGpoLocalDir.getPath(), gpoId, true, isPowerShell);
             if(res != null){
               isBackedUp  = (long) res.get("ExitCode");
               isPowerShell = (Boolean) res.get("PowerShell");
             }
             else{
                 isBackedUp = -1L;
             }
             if (isBackedUp == 0L) {
                Thread.sleep(5000);//To Do:Change Later. Find Root Cause
                this.backupId = gpoProp.dcGpoDir.getName().replace("\\", "");
                gpoProp.tmpGpoDir = new File(gpoProp.tmpGpoMainDir, this.backupId);
                UNCAccess.copyDirFromRemote(gpoProp.dcGpoDir, gpoProp.tmpGpoDir);
            } else {
                gpoProp.bkpGpoSubDir = DirectoryUtil.findDirectory(gpoProp.bkpGpoDir, 1);
                this.backupId = gpoProp.bkpGpoSubDir.getName();
                gpoProp.tmpGpoDir = new File(gpoProp.tmpGpoMainDir, this.backupId);
                DirectoryUtil.copyDir(gpoProp.bkpGpoSubDir, gpoProp.tmpGpoDir);
            }
            UNCAccess.emptyDirectory(gpoProp.dcGpoMainDir);
            ArrayList<Object> gpoFiles = new ArrayList<Object>();
            for (GpoFileType gpoFileType : GpoFileType.values()) {
                if (gpoFileType == GpoFileType.Other) {
                    continue;
                }
                GpoFile gpoFile = null;
                gpoFile = GpoFile.getGpoFileType(gpoFileType, gpoFile);
                for (GpoConfigType gpoUserMach : GpoConfigType.values()) {
                    gpoFiles.add(gpoFile.fillPolicies(gpoProp.tmpGpoDir, gpoUserMach, gpoFileType, gpoProp.domainName, gpoProp.dcName, gpoProp.adminName, gpoProp.password));
                }
            }
            LogWriter.gpo.info(String.format("Backup For Restore Done"));
            return gpoFiles;
        } catch (Exception ex) {
            LogWriter.gpo.severe(String.format("Backup For Restore is not done; Policies Are Not Filled Ex: %s", ex));//NO I18N
            return new ArrayList<Object>();
        }
    }

    private boolean specialCaseBackup(PolicySetting policyInfo, AbstractGpoEntry entry, String attr, boolean isPolFile, boolean toPreserve) {
        if (isPolFile) {
            PolEntryConcise entryCouch = new PolEntryConcise((PolEntry) entry);
            policyInfo = new PolicySetting(attr.substring(0, attr.length() - 38));
            if (policyInfo.attributeMaskIndex != null) {
                switch (policyInfo.attributeMaskIndex) {
                    case 3687:
                        if(GpoUtil.toBackupEntry(multivalPolicies, toPreserve, policyInfo.attributeMaskIndex)) {
                            setMultivalue(policyInfo, entryCouch);
                        }
                        return true;
                } 
            } else {
                int lastInd = attr.lastIndexOf("!");
                if (lastInd > 0) {
                    String attrStr = attr.substring(0, lastInd);
                    lastInd = attr.lastIndexOf("\\");
                    //attrStr = new StringBuilder(attrStr).replace(lastInd, lastInd + 1, "!").toString();
                    policyInfo = new PolicySetting(attrStr);
                    if (policyInfo.attributeMaskIndex == null) {
                        attrStr = new StringBuilder(attrStr).replace(lastInd, lastInd + 1, "!").toString();
                        policyInfo = new PolicySetting(attrStr);
                    }
                    if (policyInfo.attributeMaskIndex != null) {
                        if(GpoUtil.toBackupEntry(multivalPolicies, toPreserve, policyInfo.attributeMaskIndex)) {
                            setMultivalue(policyInfo, entryCouch);
                        }
                        return true;
                    }
                }
            }
        } else if (GpoUtil.DUPLICATE_GPO.contains(attr)) {
            String gptEntrySuffix = String.valueOf(((GptEntry) entry).gptType.gptId);
            policyInfo = new PolicySetting(attr + gptEntrySuffix);
            if (policyInfo.attributeMaskIndex != null) {
                writeEntity(policyInfo, entry);
                return true;
            }
        }
        LogWriter.gpo.severe("Special Case Not Backed Up : " + attr);
        return false;
    }

    private boolean multivalueBackup(PolicySetting policyInfo, PolEntryConcise entryCouch, String attr, boolean isPreserved) {
        if (policyInfo.isMultiValued) {
            setMultivalue(policyInfo, entryCouch);
            return true;
        }
        return false;
    }

    private void setMultivalue(PolicySetting policyInfo, PolEntryConcise polEntryCouch) {
        try {
            if (multivalPolicies.containsKey(policyInfo.attributeMaskIndex)) {
                multivalPolicies.get(policyInfo.attributeMaskIndex).add(polEntryCouch);
            } else {
                ArrayList<PolEntryConcise> polEntryList = new ArrayList<PolEntryConcise>();
                polEntryList.add(polEntryCouch);
                multivalPolicies.put(policyInfo.attributeMaskIndex, polEntryList);
            }
        } catch (Exception ex) {
            LogWriter.gpo.severe(String.format("EX : %s", ex));
        }
    }

    private void writeEntity(PolicySetting policyInfo, Object entryCouch) {
        String stringValue = JSONObjectUtil.toJsonString(entryCouch);
        backupImpl.isChanged |= backupImpl.updateAttributeValue(backupObject, lastBackupObject, policyInfo.attributeMaskIndex, policyInfo.isMultiValued, stringValue, true, false);
    }
    
    private void writeMultiPolicyEntity() {
        for (Entry multivalPolicy : multivalPolicies.entrySet()) {
            String stringValue = JSONObjectUtil.toJsonString(multivalPolicy.getValue());
            backupImpl.isChanged |= backupImpl.updateAttributeValue(backupObject, lastBackupObject, (Integer)multivalPolicy.getKey(), true, stringValue, true, false);
        }
    }
    
    private void getIndexAndWrite(GpoFile changedFile) {
        getIndexAndWrite(changedFile, false);
    }

    private void getIndexAndWrite(GpoFile changedFile, boolean toPreserve) {
        boolean isPolFile = changedFile.getType() == GpoFileType.Pol;
        for (AbstractGpoEntry entry : changedFile.getEntries()) {
            String attr = "";
            try {
                PolicySetting policyInfo;
                if (isPolFile) {
                    attr = (((PolEntry) entry).gpoUserMach == GpoConfigType.User ? "HKCU\\" : "HKLM\\") + entry.keyName + "!" + entry.valueName;//NO I18N
                } else {
                    attr = entry.keyName;
                }
                LogWriter.gpo.info(String.format("GetIndexAndWrite : %s", attr));
                policyInfo = new PolicySetting(attr);
                if (policyInfo.attributeMaskIndex != null) {
                    if(GpoUtil.toBackupEntry(multivalPolicies, toPreserve, policyInfo.attributeMaskIndex)) {
                        Object entryCouch;
                        if (isPolFile) {
                            entryCouch = new PolEntryConcise((PolEntry) entry);
                        } else {
                            entryCouch = entry;
                        }
                        if (!isPolFile || (isPolFile && !multivalueBackup(policyInfo, (PolEntryConcise) entryCouch, attr, toPreserve))) {
                            writeEntity(policyInfo, entryCouch);
                        } else {
                            LogWriter.gpo.severe("GPO Set Not Backedup : " + attr);
                        }
                    }
                } else if (!specialCaseBackup(policyInfo, entry, attr, isPolFile, toPreserve)) {
                    LogWriter.gpo.severe("GPO Set Not Backedup : " + attr);
                }
            } catch (Exception e) {
                LogWriter.gpo.severe(String.format(" %s\n%s", e, LogWriter.getStackTrace(e)));
            }
        }
    }

    private boolean updateChangesInBackup(GpoFile oldFile, GpoFile newFile) {
        try {
            boolean isPolFile = newFile.getType() == GpoFileType.Pol;
            GpoFile preservedFile = GpoFile.getGpoFileType(newFile.getType(), (GpoFile) null);
            for (AbstractGpoEntry entry : newFile.getEntries()) {
                if (oldFile.contains(entry)) {
                    AbstractGpoEntry oldEntry = oldFile.getValue(entry);
                    boolean equals = entry.compareTo(oldEntry);
                    if (!equals && newFile.getType() == GpoFileType.Gpt) {
                        GptEntry newGptEntry = (GptEntry)entry;
                        GptEntry oldGptEntry = (GptEntry)oldEntry;
                        equals = newGptEntry.compareSV(oldGptEntry, equals);
                    }
                    if(equals) {    
                        newFile.deleteValue(entry);
                        if(isPolFile) {
                            preservedFile.setValue(entry);
                        }
                    }
                    oldFile.deleteValue(entry);
                }
            }
            for (AbstractGpoEntry entry : oldFile.getEntries()) {
                entry.gpoAddRem = GpoAddRem.Rem;
                newFile.setValue(entry);
            }
            getIndexAndWrite(newFile);
            if(isPolFile && preservedFile != null){
                getIndexAndWrite(preservedFile, true);
            }
            writeMultiPolicyEntity();
            return true;
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format("GpoBackup.fileCompare : " + e + LogWriter.getStackTrace(e)));
            return false;
        }
    }

    public boolean gpoBackupHandler(BackupObject backupObj, BackupObject lastBackupObj, Properties prop) {
        try {
            backupObj.isDeleted = prop.containsKey("isDeleted") && BackupUtil.getBoolean(prop, "isDeleted") != null && BackupUtil.getBoolean(prop, "isDeleted");
            String gpoID = GpoUtil.getGpoId(backupObj.distinguishedName);
            if (backupImpl.backupType != BackupType.DeletedGpoBackup) {
                boolean toStopBackup = deletedDuplicateHandler(prop, backupObj.isDeleted, lastBackupObj.isDeleted, backupImpl.isFullSync, gpoID, backupImpl.domainId);
                if (toStopBackup) {
                    return toStopBackup;
                }
            }
            objMetadataHandler(backupObj, lastBackupObj, prop, backupImpl.domainId, gpoID);
            LogWriter.gpo.info(String.format("Gpo  prop: %s", gpoId));
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.gpo.severe(String.format("Gpo  prop: %s", e));
            //return true;
        }
        return false;
    }

    private void objMetadataHandler(BackupObject backupObj, BackupObject lastBackupObj, Properties prop, Long domainId, String gpoID) {

        backupObj.objNam = GpoUtil.getGpoName(domainId, gpoID, backupObj, lastBackupObj, backupObj.distinguishedName, prop);
        backupObj.objId = UUID.fromString(gpoID);
        backupObj.isBackupSet = true;
        if (lastBackupObj.ouId != null) {
            if(lastBackupObj.ouId.equals(BackupUtil.emptyGuid)) { // GPO deselected previously and if dummy entry added
                backupObj.ouId =  backupObj.ouId != null ? backupObj.ouId : lastBackupObj.ouId;
            } else {
                backupObj.ouId = lastBackupObj.ouId;
            }
        } else {
            backupObj.ouId = getGuidForDNSpecialCase(backupObj.distinguishedName.substring(backupObj.distinguishedName.indexOf(",") + 1), domainId);//UUID.randomUUID();////ToDo: Handle
        }
    }

    private UUID getGuidForDNSpecialCase(String dName, Long domainId) {//Get Guid For OU not returned in sync //Move to OUManager Later
        try {
            ArrayList<String> dnList = new ArrayList<String>();
            dnList.add(dName);
            Properties ouValuePair = LinkedAttributesUtil.getGuidForLinks(dnList, domainId, backupImpl.domainName,Long.parseLong(backupId));
            Enumeration eNum = ouValuePair.propertyNames();
            if (eNum.hasMoreElements()) {
                String objGuid = (String) eNum.nextElement();
                return UUID.fromString(objGuid);
            }
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format("Gpo  prop: "));
        }
        return UUID.randomUUID();
    }

    public void closeRemoteConnection() {
        UNCAccess.closeRemoteConnection(gpoProp.dcName);
        hasRemConnection = false;
    }
    
    public static Iterator checkAllGpoBackedup(Long domainId){
        try{
            DataObject dObj = GpoUtil.getFailedGPOs(domainId);
            if(dObj != null){
               return dObj.getRows(TableName.GPO_ERROR_DETAILS);
            }
        }catch(Exception e){
            LogWriter.gpo.severe(String.format("Failed GPO backup: "+ e));
            e.printStackTrace();
        }
      return null;
    }
}

//ignoreI18n_end
