/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.parser;

import com.manageengine.rmp.ad.gpo.constants.GpoAddRem;
import com.manageengine.rmp.ad.gpo.constants.GpoConfigType;
import com.manageengine.rmp.ad.gpo.constants.GpoFileType;
import com.manageengine.rmp.common.LogWriter;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * $Id$
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class AuditFile extends GpoFile {

    private HashMap<String, AbstractGpoEntry> entries;

    @Override
    public ArrayList<AbstractGpoEntry> getEntries() {
        ArrayList<AbstractGpoEntry> gpoEntry = new ArrayList<AbstractGpoEntry>(entries.values());
        //pl.Sort();
        return gpoEntry;
    }
    private String fileName;

    @Override
    public String getFileName() {
        return fileName;
    }

    @Override
    public void setFileName(String value) {
        fileName = value;
    }

    public AuditFile() {
        this.setFileName("");
        this.entries = new HashMap<String, AbstractGpoEntry>();
    }

    @Override
    public void setValue(AbstractGpoEntry gpoEntry) {
        entries.put(((AuditEntry) gpoEntry).subcategory, (AuditEntry) gpoEntry);
    }

    public final AbstractGpoEntry getValue(String key, String value) {
        AbstractGpoEntry gpoEntry = null;
        gpoEntry = this.entries.get(key);
        return gpoEntry;
    }

    @Override
    public AbstractGpoEntry getValue(AbstractGpoEntry gpoEntry) {
        return this.getValue(gpoEntry.keyName, "");
    }

    public final String getStringValue(String key) {
        try {
            AuditEntry gpoEntry = (AuditEntry) this.getValue(key, "");
            if (gpoEntry == null) {
                return "";
            }
            return gpoEntry.valueName;
        } catch (java.lang.Exception e) {
            return "";
        }
    }

    public final String getStringValue(AuditEntry gpoEntry) {
        return gpoEntry.valueName;
    }

    public final boolean contains(String key, String value) {
        return (this.getValue(key, "") != null);
    }

    @Override
    public boolean contains(AbstractGpoEntry gpoEntry) {
        return contains(gpoEntry.keyName, "");
    }

    public final void loadFile(GpoConfigType gpType) throws IOException {
        this.loadFile(null, gpType);
    }

    @Override
    public void deleteValue(AbstractGpoEntry gpoEntry) {
        deleteValue(gpoEntry.keyName, "");
    }

    public final void deleteValue(String key, String value) {
        if (this.entries.containsKey(key) == true) {
            this.entries.remove(key);
        }
    }

    public final void loadFile(String file, GpoConfigType gpoUserMach) throws FileNotFoundException, IOException {
        File auditFile = null;
        BufferedReader bReader = null;
        try {
            if (!(file == null || file.isEmpty())) {
                this.fileName = file;
                auditFile = new File(file);
            }

            String line = "";
            if (auditFile != null && auditFile.exists()) {
                bReader = new BufferedReader(new InputStreamReader(new FileInputStream(this.fileName)));
                bReader.readLine();
                while ((line = bReader.readLine()) != null) {
                    AuditEntry auditEntry = newAuditEntry(line, gpoUserMach);
                    //auditEntry.gpoUserMach = gpoUserMach;
                    this.setValue(auditEntry);
                }

            } //else log
        } catch (Exception e) {
            LogWriter.gpo.severe("Audit File : " + e + LogWriter.getStackTrace(e));
        } finally {
            if (bReader != null) {
                bReader.close();
            }
        }
    }

    public final AuditEntry newAuditEntry(String rawAuditEntry, GpoConfigType gpType) {
        try {
            AuditEntry auditEntry = new AuditEntry();
            //auditEntry.gpoUserMach = gpType;
            auditEntry.gpoAddRem = GpoAddRem.Add;
            String[] values = this.parseAuditEntry(rawAuditEntry);
            setAuditEntryValues(values, auditEntry);
            return auditEntry;
        } catch (Exception e) {
            LogWriter.gpo.severe("Audit File : " + e + LogWriter.getStackTrace(e));
            return new AuditEntry();
        }
    }

    public final String[] parseAuditEntry(String rawAuditEntry) {
        String[] parsedVals = rawAuditEntry.split("[,]", -1);
        if (parsedVals.length == 7) {
            return parsedVals;
        }
        return new String[0];
    }

    public final void setAuditEntryValues(String[] values, AuditEntry auditEntry) {
        if (values.length == 7) {
            auditEntry.machineName = values[0];
            auditEntry.policyTarget = values[1];
            auditEntry.subcategory = values[2];
            auditEntry.subcategoryGUID = values[3];
            auditEntry.inclusionSetting = values[4];
            auditEntry.exclusionSetting = values[5];
            auditEntry.settingValue = values[6];
            auditEntry.keyName = auditEntry.subcategory;
            if (!auditEntry.inclusionSetting.equals("")) {
                auditEntry.valueName = auditEntry.inclusionSetting;
            } else {
                auditEntry.valueName = auditEntry.settingValue;
            }
        }
    }

    public final void saveFile() throws IOException {
        this.saveFile(null);
    }

    private String writeDefault() {
        return "Machine Name,Policy Target,Subcategory,Subcategory GUID,Inclusion Setting,Exclusion Setting,Setting Value";//No I18N
    }

    public final void saveFile(String file) throws IOException {
        BufferedWriter writer = null;
        try {
            if (!(file == null || file.isEmpty())) {
                this.fileName = file;
            }
            File auditFile = new File(this.fileName);
            if (this.entries.size() > 0) {
                if (!auditFile.isFile()) {
                    auditFile.createNewFile();
                    writer = new BufferedWriter(new FileWriter(file));
                    writer.write(writeDefault());
                } else {
                    writer = new BufferedWriter(new FileWriter(file));
                }
                String line;
                line = writeDefault();
                writer.write(line);
                writer.newLine();
                for (java.util.Map.Entry<String, AbstractGpoEntry> entry : entries.entrySet()) {
                    line = csvWriteLine(entry.getValue());
                    writer.write(line);
                    writer.newLine();
                }
            } else {
                if ((auditFile).isFile()) {
                    writer = new BufferedWriter(new FileWriter(file));
                    writer.write(writeDefault());
                    writer.newLine();
                }
            }
        } catch (Exception e) {
            LogWriter.gpo.severe("Audit File : " + e + LogWriter.getStackTrace(e));
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

    private String csvWriteLine(AbstractGpoEntry auditEntry) {
        StringBuilder writeLine = new StringBuilder();
        AuditEntry auditEntry1 = (AuditEntry) auditEntry;
        writeLine.append(auditEntry1.machineName);
        writeLine.append(",");
        writeLine.append(auditEntry1.policyTarget);
        writeLine.append(",");
        writeLine.append(auditEntry1.subcategory);
        writeLine.append(",");
        writeLine.append(auditEntry1.subcategoryGUID);
        writeLine.append(",");
        writeLine.append(auditEntry1.inclusionSetting);
        writeLine.append(",");
        writeLine.append(auditEntry1.exclusionSetting);
        writeLine.append(",");
        writeLine.append(auditEntry1.settingValue);
        return writeLine.toString();
    }

    @Override
    public GpoFileType getType() {
        return GpoFileType.Audit;
    }

    @Override
    public Object fillPolicies(String rootFolder, GpoConfigType gpoUserMach, GpoFileType gpoFileType, String domainName, String dcName, String adminName, String password) {
        return fillPolicies(new File(rootFolder), gpoUserMach, gpoFileType, domainName, dcName, adminName, password);
    }

    @Override
    public Object fillPolicies(File rootFolder, GpoConfigType gpoUserMach, GpoFileType gpoFileType, String domainName, String dcName, String adminName, String password) {
        try {
            if (rootFolder != null) {
                String filePath = "";
                String pathType = gpoUserMach == GpoConfigType.Machine ? "Machine" : "User";//No I18N
                filePath = rootFolder + "\\DomainSysvol\\GPO\\" + pathType + "\\Microsoft\\Windows NT\\Audit\\audit.csv";//No I18N
                AuditFile auditFile = new AuditFile();
                auditFile.loadFile(filePath, gpoUserMach);
                return auditFile;
            }
        } catch (Exception e) {
            LogWriter.gpo.severe("Audit File : " + e + LogWriter.getStackTrace(e));
        }
        return new AuditFile();
    }
}
//ignoreI18n_end
