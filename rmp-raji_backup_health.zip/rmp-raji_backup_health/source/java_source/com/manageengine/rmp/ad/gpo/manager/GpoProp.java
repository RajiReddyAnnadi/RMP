/**
 * $Id$
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.manager;

import com.manageengine.ads.fw.domain.ADSDomainHandler;
import com.manageengine.rmp.constants.OsVersion;
import com.manageengine.rmp.util.winutil.DirectoryUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import static com.manageengine.rmp.util.RmpPaths.DATA_DIR;
import java.io.File;
import java.util.List;
import java.util.Properties;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class GpoProp {

    public static final String GPO_DIR_NAME = DATA_DIR + "\\GroupPolicy";//No I18N
    public static final String RMP_GPO_UTIL_DIR = "\\GpoUtil";//No I18N
    public static final String GPO_SCRIPT_FILE = "\\RMPGpo.wsf";//No I18N
    public static final String DC_MAIN_DIR = "RecoveryManagerPlus";//No I18N
    public static final String DC_GPO_BACKUP_DIR = "GroupPolicy";//No I18N
    public static final String GPO_BATCH = "GpoBatch.vbs";//No I18N

    public File tmpGpoMainDir;//Temporary Root Gpo Directory (in Local)
    public File tmpGpoDir;//Temporary Directory of single GPO inside tmpGpoMainDir (in Local)
    public File dcMainDir;//Root Dir for RMP (in DC)
    public File dcGpoMainDir;//Root Gpo Directory (in DC)
    public File dcGpoLocalDir;//Root Gpo Directory (in DC, local path)
    public File dcGpoDir;//Directory of single GPO inside dcGpoMainDir (in DC)
    public File bkpGpoMainDir;//Permanent Backup Root Gpo Directory (in Local)
    public File bkpGpoDir;//Permanent Backup Directory of single GPO inside tmpGpoMainDir (in Local)
    public File bkpGpoSubDir;//Permanent Exact Backup Directory of single GPO inside bkpGpoDir (in Local)

    public String dcName, adminName, domainName, password, backupId,userDomainName,userName;
    public long domainId;
    OsVersion dcOsType;

    public GpoProp() {

    }

    public GpoProp(long domainMask) {

        Properties domainSettings = RMPDomainHandler.getDomainDetailsById(domainMask);
        construct(domainSettings);
    }

    public GpoProp(Properties domainSettings) {
        construct(domainSettings);
    }

    private void construct(Properties domainSettings) {
        //LogWriter.gpo.finest("domainSettings :\n" + domainSettings.toString());
        this.domainId = Long.valueOf((String) domainSettings.get("DOMAIN_ID"));
        this.domainName = (String) domainSettings.get("DOMAIN_NAME");
        this.userDomainName = (String) domainSettings.get("USER_DOMAIN_NAME");
        List<String> dcList = ADSDomainHandler.getDCList(domainName);
        this.dcName = GpoUtil.getComputerName(dcList.get(0), this.domainName);
        this.adminName = (String) domainSettings.get("USER_DISTINGUISHED_NAME");
        this.password = (String) domainSettings.get("PASSWORD");
        this.userName = (String) domainSettings.get("USER_NAME");
    }

    public String getGpoBackupDirAsString(long domainId) {
        String dir = DATA_DIR + "\\" + domainId + "\\GPO";//No I18N
        DirectoryUtil.createDirectoryIfNotExists(dir);
        return dir;
    }

    public File getGpoBackupDir(long domainId) {
        File dir = new File(DATA_DIR + "\\" + domainId + "\\GPO");//No I18N
        DirectoryUtil.createDirectoryIfNotExists(dir);
        return dir;
    }    
}

//ignoreI18n_end
