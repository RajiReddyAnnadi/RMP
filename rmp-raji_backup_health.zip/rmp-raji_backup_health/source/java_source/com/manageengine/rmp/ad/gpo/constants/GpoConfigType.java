/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.constants;

/**
 *
 * @author lucky-2306
 */
public enum GpoConfigType {

    User(1),
    Machine(2);
    public int id;
    public static GpoConfigType[] values;

    static {
        values = GpoConfigType.values();
    }

    GpoConfigType(int id) {
        this.id = id;
    }

    public static GpoConfigType getGpoConfigType(String type) {
        if (type.equalsIgnoreCase("MACHINE")) {
            return GpoConfigType.Machine;
        }
        if (type.equalsIgnoreCase("USER")) {
            return GpoConfigType.User;
        }
        return GpoConfigType.Machine;
    }

    public static GpoConfigType getType(int configId) {
        switch (configId) {
            case 1:
                return User;
            case 2:
                return Machine;
            default:
                return Machine;
        }
    }
}
