/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
package com.manageengine.rmp.ad.backup;
//ignoreI18n_start

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.me.util.RowHelper;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.licensing.ProductSubscriptionInfo;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.RMPCommonUtil;
import com.manageengine.rmp.constants.BackupType;
import com.manageengine.rmp.constants.ChangeType;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.RMPCommonFlags;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.licensing.LicenseUtil;
import com.manageengine.rmp.metracker.InfoTracker;
import com.manageengine.rmp.metracker.MeTrackFormName;
import com.manageengine.rmp.settings.ConfigureBackupSettings;
import com.me.tools.zcutil.METrack;
import java.sql.Connection;
import java.sql.Types;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import java.util.logging.Level;

public class BackupTracker implements Cloneable{

    public ArrayList<ArrayList<Integer>> data;//data[ObjectType][ChangeType]
    public ArrayList<ArrayList<Integer>> notTrackedData;
    private ArrayList<Integer> trackCount;
    private ArrayList<Integer> disabledCount;
    private int dnsZoneAdjust = 0;
    private int dnsNodeAdjust = 0;

    public BackupTracker() {
        data = new ArrayList<ArrayList<Integer>>();
        notTrackedData = new ArrayList<ArrayList<Integer>>();
        trackCount = new ArrayList<Integer>();
        disabledCount = new ArrayList<Integer>();
        for (int i = 0; i <= ObjectType.highValue; i++) {
            data.add(i, new ArrayList<Integer>());
            notTrackedData.add(i, new ArrayList<Integer>());
            trackCount.add(i, 0);
            disabledCount.add(i, 0);
            ArrayList<Integer> objectTypeHandle = data.get(i);
            for (int j = 0; j <= ChangeType.highValue; j++) {
                objectTypeHandle.add(j, 0);
                notTrackedData.get(i).add(j, 0);
            }
        }
    }
    
    public Object clone(){
        try{
            BackupTracker backupTracker = (BackupTracker) super.clone();
            backupTracker.data =  (ArrayList) backupTracker.data.clone();
            backupTracker.notTrackedData = (ArrayList) backupTracker.notTrackedData.clone();
            backupTracker.trackCount = (ArrayList) backupTracker.trackCount.clone();
            backupTracker.disabledCount = (ArrayList) backupTracker.disabledCount.clone();
            return backupTracker;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public void track(BackupObject backupObject, Boolean isFilterChange, Boolean isFullSync, Boolean isFreeEdition) {
        Integer objectType = backupObject.objTyp.id.intValue();
        trackCount.set(objectType, trackCount.get(objectType) + backupObject.trackingData);
        ArrayList<Integer> dataHandle, allObjHandle;
        if ((backupObject.isBackupSet && !(!backupObject.hasHistory && backupObject.isDeleted) && (!isFreeEdition || (isFreeEdition && backupObject.isDeleted))) /* ||  ( backupObject.trackingData!=0 && !isFreeEdition)*/) {
            dataHandle = data.get(objectType);
            allObjHandle = data.get(0);
        } else {
            dataHandle = notTrackedData.get(objectType);
            allObjHandle = notTrackedData.get(0);
        }
        Integer[] changeTypes = ChangeType.getChangeTypeIdsFromMaskedValue(backupObject.changeTyp);
        //int maxChangeTypeId=ChangeType.getMaxChangeTypeId(backupObject.changeTyp);
          for (int i = 0; i < changeTypes.length; i++) {
            dataHandle.set(changeTypes[i], dataHandle.get(changeTypes[i]) + 1);
            allObjHandle.set(changeTypes[i], allObjHandle.get(changeTypes[i]) + 1);//To hold allObject changeType count
          }
        dataHandle.set(ChangeType.UnTracked.id, dataHandle.get(ChangeType.UnTracked.id) + 1);//To hold objectType wise count
        allObjHandle.set(ChangeType.UnTracked.id, allObjHandle.get(ChangeType.UnTracked.id) + 1);//To hold allObject count
    }

    public void updateUsageDetails(BackupImpl backupImpl, ObjectType objectType, Boolean syncDone) {
        try {//ToDo: use transaction for DB commit
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.RMP_AD_OBJECTS_INFO, "DOMAIN_ID"), backupImpl.domainId, 0);//NO I18N
            Criteria objectTypeCriteria = new Criteria(Column.getColumn(TableName.RMP_AD_OBJECTS_INFO, "OBJECT_TYPE"), objectType.id.toString(), 0);
            DataObject dataObject = CommonUtil.getPersistence().get(TableName.RMP_AD_OBJECTS_INFO, domainCriteria.and(objectTypeCriteria));
            Properties meTrackerData = new Properties();
            int objectId = objectType.id.intValue();
            ArrayList<Integer> changeTypeCount = data.get(objectId);
            int totalcount = trackCount.get(objectId);
            if (objectType == ObjectType.DnsZone) {
                if (dnsZoneAdjust == 0) {
                    dnsZoneAdjust = totalcount;
                } else {
                    totalcount = totalcount - dnsZoneAdjust;
                    dnsZoneAdjust = 0;
                }
            }
            if (objectType == ObjectType.DnsNode) {
                if (dnsNodeAdjust == 0) {
                    dnsNodeAdjust = totalcount;
                } else {
                    totalcount = totalcount - dnsNodeAdjust;
                    dnsNodeAdjust = 0;
                }
            }
            //int counttToIncrement = changeTypeCount.get((int) ChangeType.Added.id) + changeTypeCount.get((int) ChangeType.Created.id) + changeTypeCount.get((int) ChangeType.ReAdded.id) + changeTypeCount.get((int) ChangeType.Recycled.id);
            // int countToDecrement = changeTypeCount.get((int) ChangeType.Deleted.id) + changeTypeCount.get((int) ChangeType.UnTracked.id);
            Row row;
            if(dataObject.isEmpty()){
                row = new Row(TableName.RMP_AD_OBJECTS_INFO);
                row.set("DOMAIN_ID", backupImpl.domainId);
                row.set("OBJECT_TYPE", objectId);
                row.set("COUNT_INITIAL", changeTypeCount.get((int) ChangeType.Added.id));
                row.set("COUNT_DELETED", changeTypeCount.get((int) ChangeType.Deleted.id));
                row.set("COUNT_TRACKED", totalcount);
                row.set("COUNT_DISABLED", disabledCount.get(objectId));
                dataObject.addRow(row);
            }else{
                row = (Row) dataObject.getFirstRow(TableName.RMP_AD_OBJECTS_INFO);
                row.set("COUNT_TRACKED", (Integer) row.get("COUNT_TRACKED") + totalcount);
                row.set("COUNT_DELETED", (Integer) row.get("COUNT_DELETED") + changeTypeCount.get((int) ChangeType.Deleted.id) - changeTypeCount.get((int) ChangeType.Recycled.id));
                row.set("COUNT_INITIAL", (Integer) row.get("COUNT_INITIAL") + changeTypeCount.get((int) ChangeType.Created.id) + changeTypeCount.get((int) ChangeType.Added.id));
                row.set("COUNT_DISABLED",(Integer) row.get("COUNT_DISABLED") + disabledCount.get(objectId));
                dataObject.updateRow(row);
            }
            if ((Integer)row.get("OBJECT_TYPE") == ObjectType.User.id.intValue()) {
                ProductSubscriptionInfo.trackedObjectCt =  LicenseUtil.getEnableUserCount();
                if((ProductSubscriptionInfo.subscribedObjectCt != -1) && (ProductSubscriptionInfo.trackedObjectCt> ProductSubscriptionInfo.subscribedObjectCt) && !ProductSubscriptionInfo.isObjectLimitExceeded){
                    ConfigureBackupSettings.configureSettingsforFreeEdition();
                    ProductSubscriptionInfo.isObjectLimitExceeded=true;
                }
            }
            if (backupImpl.backupType == BackupType.InitBackup) {
                meTrackerData.put("BackedupDomain_" + ObjectType.values()[objectId].name(), String.valueOf(changeTypeCount.get((int) ChangeType.Added.id)));
                meTrackerData.put("Domain_" + ObjectType.values()[objectId].name(), "" + (Integer) row.get("COUNT_INITIAL"));
            }

            Persistence per = (Persistence) BeanUtil.lookup("Persistence");
            per.update(dataObject);

            if (backupImpl.backupType == BackupType.InitBackup) {
                meTrackerData.put("DomainName", backupImpl.domainName);
                meTrackerData.put("RecordType", (Integer.toString(InfoTracker.RecordType.ADObjectInfo.ordinal())));
               METrack.updateRecord(meTrackerData, MeTrackFormName.environmentInfo, null);
            }
        } catch (Exception e) {
            LogWriter.backup.severe("RmpBackupImpl.updateUsageDetails exception: " + e);
        }
    }

    public static void updateUsageDetails(Long domainId) {
        DataSet trackingObjInfoDataSet = null;
        RelationalAPI relApi;
        Connection connection = null;
        try {//ToDo: use transaction for DB commit
            if (RMPCommonUtil.checkIsTableExist(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId))
            {
                ArrayList<Integer> trackCount = new ArrayList<Integer>();
                for (int i = 0; i <= ObjectType.highValue; i++) {
                    trackCount.add(i, 0);
                }
                LogWriter.general.info("Update usage details");
                SelectQuery objectTrackerQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId));
                Column isBackupSet = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "IS_BACKUP_SET"), RMPCommonFlags.IsBackupSet.maskValue);
                isBackupSet.setType(Types.INTEGER);
                Column isDeleted = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "SYNC_STATUS"), RMPCommonFlags.IsDeleted.maskValue|RMPCommonFlags.IsNotPresentInDC.maskValue);
                isDeleted.setType(Types.INTEGER);
                Column hasHistory = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "SYNC_STATUS"), RMPCommonFlags.HasHistory.maskValue);
                hasHistory.setType(Types.INTEGER);
                Criteria backupStatusCriteria = new Criteria(isBackupSet, 0, QueryConstants.GREATER_THAN); //object backup set
                Criteria notDeletedCriteria = new Criteria(isDeleted, 0, QueryConstants.EQUAL); // object not deleted
                Criteria hasHistoryCriteria = new Criteria(hasHistory, 0, QueryConstants.GREATER_THAN); // object not deleted
                objectTrackerQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_TYPE"));
                Column countColumn = Column.getColumn(null, "*", "OBJECT_COUNT").count();
                objectTrackerQuery.addSelectColumn(countColumn);
                countColumn.setType(Types.INTEGER);
                objectTrackerQuery.addGroupByColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_TYPE"));
                objectTrackerQuery.setCriteria((backupStatusCriteria) .and(notDeletedCriteria) .and(hasHistoryCriteria));
                relApi = RelationalAPI.getInstance();
                connection = relApi.getConnection();
                trackingObjInfoDataSet = relApi.executeQuery(objectTrackerQuery, connection);
                Iterator iter;
                while (trackingObjInfoDataSet.next()) {
                    Long objMask = trackingObjInfoDataSet.getLong("OBJECT_TYPE");
                    Integer count = trackingObjInfoDataSet.getInt(2);
                    Integer parsedObjType = ObjectType.parse(objMask).id.intValue();
                    trackCount.set(parsedObjType, count);
                }
                Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_AD_OBJECTS_INFO, "DOMAIN_ID"), domainId, 0);//NO I18N
                DataObject dataObject = CommonUtil.getPersistence().get(TableName.RMP_AD_OBJECTS_INFO, criteria);
                iter = dataObject.getRows(TableName.RMP_AD_OBJECTS_INFO);
                while (iter.hasNext()) {
                    RowHelper row = new RowHelper((Row) iter.next());
                    Integer objectId = row.getInteger("OBJECT_TYPE");
                    /*if (row.getInteger("OBJECT_TYPE") == ObjectType.User.id.intValue()) {
                        Integer oldTrackingCount = row.getInteger("COUNT_TRACKED");
                       LogWriter.general.info("old=" + oldTrackingCount + " proSub.trackct=" + ProductSubscriptionInfo.trackedObjectCt + " Newtc=" + trackCount.get(objectId));
                        ProductSubscriptionInfo.trackedObjectCt = ProductSubscriptionInfo.trackedObjectCt - oldTrackingCount + trackCount.get(objectId);
                    }*/
                    row.row.set("COUNT_TRACKED", trackCount.get(objectId));
                    dataObject.updateRow(row.row);
                }
                Persistence per = (Persistence) BeanUtil.lookup("Persistence");
                per.update(dataObject);
                ProductSubscriptionInfo.trackedObjectCt=LicenseUtil.getEnableUserCount();
            }
        } catch (Exception e) {
            LogWriter.backup.severe("RmpBackupImpl.updateUsageDetails exception: " + e);
        } finally {
            DBUtil.closeDataSetAndConnection(trackingObjInfoDataSet, connection);
        }
    }

    public String getData(Boolean writeLogs) {
        try {
            String dataString = JSONObjectUtil.toJsonString(data);
            if (writeLogs) {
                LogWriter.backup.info("trackCount     : " + JSONObjectUtil.toJsonString(trackCount));
                LogWriter.backup.info("notTrackedData : " + JSONObjectUtil.toJsonString(notTrackedData));
                LogWriter.backup.info("TrackedData*** : " + JSONObjectUtil.toJsonString(data));
            }
            return dataString;
        } catch (Exception e) {
            LogWriter.backup.log(Level.INFO, "BackupTracker.getData : {0}", e);
        }
        return "[]";
    }
    
    public void updateDisableCount(BackupObject backupObject, int trackCount) {
        disabledCount.set(backupObject.objTyp.id.intValue(), disabledCount.get(backupObject.objTyp.id.intValue()) + (backupObject.isDisabled ? 1 : (0 + trackCount)));
    }
}
//ignoreI18n_end
