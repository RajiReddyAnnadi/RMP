//$Id$
package com.manageengine.rmp.ad.backup;

import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Properties;
import java.util.UUID;

import com.manageengine.rmp.ad.gpo.manager.GpoBackup;
import com.manageengine.ads.fw.adsync.ADSyncInterface;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.ad.adsync.SyncFilter;
import com.manageengine.rmp.ad.bitlocker.BitLockerManager;
import com.manageengine.rmp.ad.gpo.manager.GPBackLinkAttrManager;
import com.manageengine.rmp.ad.gpo.manager.GPFrontLinkAttrManager;
import com.manageengine.rmp.ad.gpo.manager.GpoLinksUtil;
import com.manageengine.rmp.ad.gpo.manager.GpoUtil;
import com.manageengine.rmp.ad.rangedattributes.BackLinkAttrManager;
import com.manageengine.rmp.ad.rangedattributes.FrontLinkAttrManager;
import com.manageengine.rmp.ad.rangedattributes.LinkedAttributesUtil;
import com.manageengine.rmp.ad.rangedattributes.PrimaryGroupManager;
import com.manageengine.rmp.admin.NotificationAPI;
import com.manageengine.rmp.admin.constants.NotificationType;
import com.manageengine.rmp.clientSync.RunningOperationSync;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.BackupType;
import com.manageengine.rmp.constants.ChangeType;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.OperationStatus;
import com.manageengine.rmp.constants.StatusId;
import com.manageengine.rmp.db.dbhelper.DomainTablesUtil;
import com.manageengine.rmp.dataobjects.OperationInfo;
import com.manageengine.rmp.oumanager.OUManager;
import com.manageengine.rmp.queue.RmpBackupQueue;
import com.manageengine.rmp.settings.ConfigureBackupSettings;
import com.manageengine.rmp.settings.customattributes.CustomAttributesBackup;
import com.manageengine.rmp.util.GeneralUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import java.util.Arrays;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

//ignoreI18n_start
/**
 *
 * @author lucky-2306
 */
public class BackupImpl extends AbstractBackup implements ADSyncInterface, RmpBackupQueue.BackupQueuePopper<Properties, String>, Cloneable 
{

    RmpBackupQueue<Properties> backupQueue;

    public BackupImpl() 
    {
        backupQueue = new RmpBackupQueue<>(100);
    }

    public BackupImpl(Long domainId, BackupType backupType, String initiator, long backupId, String domainName, CustomAttributesBackup customAttribute) 
    {
        backupQueue = new RmpBackupQueue<>(100);
        construct(domainId, backupType, initiator, backupId, domainName, customAttribute, this);
    }

    public BackupImpl(Long domainId, String initiator) 
    {
        backupQueue = new RmpBackupQueue<>(100);
        construct(domainId, BackupType.Sync, initiator, -1, null, new CustomAttributesBackup(), this);
    }

    public BackupImpl clone() 
    {
        try 
        {
            return (BackupImpl) super.clone();
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void initialize(String objectType, boolean isFullSync) 
    {
        try 
        {
            this.isFullSync = isFullSync;
            this.isFinalUpdate=false;
            LogWriter.backup.info("RmpBackupImpl.initialize(string,bool): isFullSync - " + isFullSync+" "+objectType);
            backupUpdater.dbImporter.backupFileWriterInit(domainId);
            this.objectType = ObjectType.parse(objectType);
            backupQueue.setObjectType(this.objectType);
            this.orgObjectType = objectType;
            this.backupInfo.statusId = StatusId.BackedUpObjects.value;
            if (isFullSync) 
            {
                if (ouCache == null) 
                {
                    ouCache = OUManager.getOuCache(domainId);
                }
            }
            if (objectType.equalsIgnoreCase("rangedAttr")) 
            {
                this.backupInfo.statusId = StatusId.BackingUpLinkedAttributes.value;
                tempUpdate();
                backLinkManager = new BackLinkAttrManager(domainId, backupInfo.operationId, this);
                forwardLinkManager = new FrontLinkAttrManager(domainId, domainName, backupInfo.operationId, isInitBackup, isFullSync, backupUpdater, backLinkManager.backLinkMetaInfo);
            } 
            else if(this.objectType == ObjectType.Site)
            {
                isSiteSelected = true;
            }
            else if(objectType.equalsIgnoreCase("ouGPLinksAttr") || objectType.equalsIgnoreCase("siteGPLinksAttr"))
            {
                this.backupInfo.statusId = StatusId.BackingUpGPOLinkedAttributes.value;
                tempUpdate();
                if(gpBackLinkManager == null) {
                    gpBackLinkManager = new GPBackLinkAttrManager(domainId, backupInfo.operationId, this.backupImpl);
                    gpFrontLinkManager = new GPFrontLinkAttrManager(domainId, domainName, backupInfo.operationId, isInitBackup, isFullSync, this.orgObjectType, backupUpdater, gpBackLinkManager.backLinkMetaInfo);
                }
                gpFrontLinkManager.setObjectType(objectType);
            }
            else if (objectType.equalsIgnoreCase("bitlocker"))
            {
                bitLocker = new BitLockerManager(domainId);
            } 
            else if (objectType.contains(SyncFilter.CUSTOM_SYNC_PREPENDER)) 
            {
                objectType = objectType.replace(SyncFilter.CUSTOM_SYNC_PREPENDER, "");
                this.isInitBackup = false;
                this.isFullSync = true;
            }
            else if(objectType.equalsIgnoreCase("primaryGroupAttr")){
                backLinkManager = new BackLinkAttrManager(domainId, backupInfo.operationId, this);
                forwardLinkManager = new FrontLinkAttrManager(domainId, domainName, backupInfo.operationId, isInitBackup, isFullSync, backupUpdater, backLinkManager.backLinkMetaInfo);
                primaryGroupManager=new PrimaryGroupManager(domainId,backupUpdater.backupId);
                
            }
            threadBackupTracker = new BackupTracker();
            objectFinalUpdation = new ObjectBatchDump(objectType);
        }
        catch(Exception e) 
        {
            LogWriter.backup.severe("RmpBackupImpl.initialize "+LogWriter.getStackTrace(e));
        }
    }

    @Override
    public void initialize(String domainName, ArrayList objectTypes, boolean isFullSync) 
    {
        try 
        {
            processedObjInfo = new HashSet<UUID>();
            objectsPresentInDC = new HashSet<UUID>();
            this.domainName = domainName;
            LogWriter.backup.info("RmpBackupImpl.initialize(string,ArrayList, bool): domainName-" + domainName + " objectTypes-" + objectTypes + " isFullSync-" + isFullSync + " BackupId-" + backupInfo.operationId);
            this.changeId = 0;
            if (DomainTablesUtil.isInitBackup(domainId)) 
            {
                LogWriter.backup.info("init backup for domain " + domainName + ", creating tables");
                DomainTablesUtil.createDomainTables(domainId);
            }
        } 
        catch (Exception e) 
        {
            LogWriter.backup.severe(String.format("RmpBackupImpl.initialize %s %s", domainName, LogWriter.getStackTrace(e)));
        }
    }

    public void addRow(Properties prop) 
    {
        backupQueue.insertBackupQueue(prop, this);
    }

    @Override
    public void handleDeletedObjects(String arg0) throws Exception 
    {
        LogWriter.backup.info("RmpBackupImpl.handleDeletedObjects: arg-" + arg0);
    }

    @Override
    public boolean isCompleted() 
    {
        LogWriter.backup.info("RmpBackupImpl.isCompleted");
        return false;
    }

    @Override
    public void postNativeUpdation(Hashtable arg0) 
    {
        LogWriter.backup.info("RmpBackupImpl.postNativeUpdation =" + JSONObjectUtil.toJsonString(arg0));
    }

    @Override
    public void updateOtherObjects(Properties arg0) throws Exception 
    {
        LogWriter.backup.info("RmpBackupImpl.updateOtherObjects =" + JSONObjectUtil.toJsonString(arg0));
    }

    @Override
    public void waitForCompletion() 
    {
        try 
        {
            LogWriter.backup.info("RmpBackupImpl.waitForCompletion");
            if(backupType != BackupType.InitBackup)
            {
                backupSyncUpdater.updateObjectSyncInfo();
            }
            if (backupType == BackupType.OuSync) 
            {
                BackupUtil.removeOuCookie(domainName);
                OuUpdater.revalidateParentGuids(domainId);
            } 
            else 
            {
                backupInfo.data = backupTracker.getData(true);
                Integer updatedCount = backupTracker.data.get(ObjectType.Other.id.intValue()).get(ChangeType.UnTracked.id);
                if (backupInfo.status != OperationStatus.Failed) 
                {
                    backupInfo.finish(this, updatedCount);
                }
                LogWriter.backup.info(String.format("Calculated Count : %s  UpdatedCount : %s", changeId, updatedCount));
                backupInfo.count = updatedCount;
                backupUpdater.updateBackupFinalInfo(backupInfo, backupType == backupType.InitBackup);//todo: directly pass BackupType
                RunningOperationSync.remove(backupInfo);
                BackupInitiator.removeCurrentBackupJob(backupInfo.domainId, backupInfo.operationId);
                BackupManager backupManager = new BackupManager();
                backupManager.onTaskComplete(backupInfo.operationId, backupInfo.initiator);
                if (backupInfo.status == OperationStatus.Completed || backupInfo.status == OperationStatus.Failed || backupInfo.status == OperationStatus.PartiallyCompleted)
                {
                    LogWriter.general.info("Mail: Calling NotificationAPI.notifyAD() from BackupImpl.waitForCompletion()");
                    NotificationAPI.notifyAD(NotificationType.ADBackup, backupInfo);
                }
            }
            ConfigureBackupSettings.updateOuSelectionChange(domainId, isOUSelectionChanged);
            customAttribute.finalSyncObjectsUpdate(this);
            BackupUtil.SetNewlySelectedForBackup(domainId);
            RMPDomainHandler.prioritizeLastSyncDc(domainId);
        } 
        catch (Exception e) 
        {
            LogWriter.backup.severe(String.format("RmpBackupImpl.waitForCompletion domainId:%s \nexcep:%s", domainId, LogWriter.getStackTrace(e)));
        }
    }

    @Override
    public boolean waitForCompletion(String type) 
    {
        LogWriter.backup.info("RmpBackupImpl.WaitforCompletion(ObjectType):" + type);
        if(type.equals("grouppolicy") && !isFullSync){
            LogWriter.gpo.info("Adding failed GPOs in queue started");
            Iterator itr = GpoBackup.checkAllGpoBackedup(domainId);
            if(itr != null){
                while(itr.hasNext()){
                    Row row = (Row) itr.next();
                    Properties prop = new Properties();
                    String guid = row.get("OBJECT_GUID").toString();
                    ArrayList objId = GeneralUtil.getArrayList(guid);
                    ArrayList distinguishedName = GeneralUtil.getArrayList(row.get("DISTINGUISHED_NAME").toString());
                    if(!backupQueue.hasPopGuid(guid)){
                        LogWriter.gpo.info(String.format("Adding GPO : %s",objId));
                        prop.put("objectGUID", objId);
                        prop.put("distinguishedName", distinguishedName);
                        prop.put("versionNumber", GeneralUtil.getArrayList("000000")); //dummy version number
                        addRow(prop);
                    }
                    else {
                        LogWriter.gpo.info(String.format("GPO Id exists in queue: %s",objId));
                    }
                }
            }
            LogWriter.gpo.info("Adding failed GPOs in queue completed");
        }
        backupQueue.emptyBackupQueue(this);
        LogWriter.backup.info("RmpBackupImpl.waitForCompletion Emptied Queue");
        boolean result = true;
        objectFinalUpdate(type);
        return result;
    }
    
    private void objectFinalUpdate(String type) {
        try {
            isFinalUpdate=true;
            if (objectFinalUpdation.isAlive()) {
                objectFinalUpdation.syncDone = true;
                objectFinalUpdation.dumpQueue.notifyQueue();
                objectFinalUpdation.join();
                objectFinalUpdation = null;
            }
            if ("rangedAttr".equalsIgnoreCase(type)) 
            {                
                //recycle bin fix
                  if(forwardLinkManager!=null && forwardLinkManager.recycledRangedObjects!=null && !forwardLinkManager.recycledRangedObjects.isEmpty()){
        Object[] keyList=forwardLinkManager.recycledRangedObjects.keySet().toArray();
                for(int i=0;i<keyList.length;i++){
                    LinkedAttributesUtil.updateRecycledLinks(forwardLinkManager.recycledRangedObjects.get(keyList[i]), forwardLinkManager, this); 
                }
               
                forwardLinkManager.recycledRangedObjects.clear();
            }
    
                
                forwardLinkManager.dbDumperRangedAttributes();
                forwardLinkManager.finalUpdateToObject(this);
                LinkedAttributesUtil.clearData(forwardLinkManager);
                backupQueue.emptyBackupQueue(this);
                backupUpdater.dumpObjectVersionData();
                backupInfo.statusId = StatusId.VerifyingBackLinkAttributes.value;
                tempUpdate();
                backLinkManager.updateBackLinks();
                backupQueue.emptyBackupQueue(this);
            } 
            else if(type.equalsIgnoreCase("siteGPLinksAttr") || type.equalsIgnoreCase("ouGPLinksAttr")) 
            {   
                for(String key : gpFrontLinkManager.recycledRangedObjects.keySet())
                {
                    GpoLinksUtil.updateRecycledLinks(gpFrontLinkManager.recycledRangedObjects.get(key), gpFrontLinkManager, this);     
                }
                gpFrontLinkManager.recycledRangedObjects.clear();
                gpFrontLinkManager.dbDumperRangedAttributes();
                gpFrontLinkManager.finalUpdateToObject(this);
                LinkedAttributesUtil.clearFrontLinks(gpFrontLinkManager);
                backupQueue.emptyBackupQueue(this);
                backupUpdater.dumpObjectVersionData();
            } 
            else if (ObjectType.DnsNode.toString().equalsIgnoreCase(type)) 
            {
                backupUpdater.dumprangedAttrInfoData();
                dnsManager.updateZoneChangeMask(backupUpdater, this);
            }
            else if(type.equalsIgnoreCase("primaryGroupAttr")){
                backupUpdater.dumprangedAttrInfoData();
                primaryGroupManager.backupMetaData(backupImpl);
                backupQueue.emptyBackupQueue(this);
                 backupUpdater.dumpObjectVersionData(); 
            }
            else if ("groupPolicy".equalsIgnoreCase(type))
            {
                gpoBackup.deletedGpoBackup(this);
                gpoBackup.closeRemoteConnection();
            }
            else if ("bitlocker".equalsIgnoreCase(type)) 
            {
                bitLocker.updateBitLockerInBackup(this);
            } 
            else if (objectType == ObjectType.OU || objectType == ObjectType.DnsZone) //ToDO: update only if any Ou newly created / moved / deleted
            {
                OUManager.setHasChildren(domainId);
            }
            if(type.equalsIgnoreCase("siteGPLinksAttr")) 
            { 
                backupQueue.emptyBackupQueue(this);
                backupUpdater.dumpObjectVersionData();
                LinkedAttributesUtil.clearData(gpFrontLinkManager);
                gpBackLinkManager.updateBackLinks();
            }            
            backupQueue.emptyBackupQueue(this);
            backupUpdater.dumpObjectVersionData();
            backupInfo.data = backupTracker.getData(false);
            backupInfo.count = backupTracker.data.get(ObjectType.Other.id.intValue()).get(ChangeType.UnTracked.id);
            backupUpdater.updateFinalInfo(backupInfo);
            if (!("rangedAttr".equalsIgnoreCase(type) || "bitlocker".equalsIgnoreCase(type) || "ouGPLinksAttr".equalsIgnoreCase(type) || "siteGPLinksAttr".equalsIgnoreCase(type)))
            {
                //ToDo: update simulated object data count in backupTracker (need to check whetehr this case necessary)
                threadBackupTracker.updateUsageDetails(this, objectType, true);
                updateObjectNotInDcStatus(type);
                backupUpdater.updateBackupProgressInfo(backupInfo);
            }
        } 
        catch (Exception e) 
        {
            LogWriter.backup.severe("RmpBackupImpl.objectFinalUpdate "+LogWriter.getStackTrace(e));
        }
    }

    public void updateObjectNotInDcStatus(String type) 
    {
        if(isFullSync || !objectsPresentInDC.isEmpty())
        {
            duplicateCount++;
            //Objects present in full sync is present in currently selected DC || Objects which is previously not found in DC is now present in DC
            if((ObjectType.parse(type) == ObjectType.DnsNode || ObjectType.parse(type) == ObjectType.DnsZone ) && duplicateCount != 2) 
            {
                return;
            }
            duplicateCount = 0;
            if(!isInitBackup) 
            {
                if(!type.startsWith(SyncFilter.CUSTOM_SYNC_PREPENDER))
                {
                    BackupSetter.updateObjectsNotInDC(domainId, processedObjInfo, type);
                }
                if(!objectsPresentInDC.isEmpty())
                {
                    BackupSetter.updateObjectsInDC(domainId, objectsPresentInDC, type);
                }
            }
            BackupTracker.updateUsageDetails(domainId);
        }
        processedObjInfo = new HashSet<UUID>();
        objectsPresentInDC = new HashSet<UUID>();
    }

    public void queueProcessing() 
    {
        if (objectFinalUpdation != null && backupUpdater.dbImporter.filetoDBDump()) 
        {
            BackupUpdater queueBackupUpdater = (BackupUpdater) this.backupUpdater.clone();
            BackupTracker queueBackupTracker = (BackupTracker) this.threadBackupTracker.clone();
            OperationInfo queueOperationInfo = (OperationInfo) this.backupInfo.clone();
            ArrayList details = new ArrayList();
            details.add(0, this);
            details.add(1, queueBackupUpdater);
            details.add(2, queueBackupTracker);
            details.add(3, queueOperationInfo);
            objectFinalUpdation.dumpQueue.add(details);
            if (!objectFinalUpdation.isAlive()) 
            {
                objectFinalUpdation.start();
            }
            this.backupUpdater.dbImporter.backupFileWriterInit(domainId);
            this.threadBackupTracker = new BackupTracker();
        }
    }

    @Override
    public boolean handleError(Properties prop) 
    {
        try 
        {
            LogWriter.backup.info(String.format("RmpBackupImpl.handleError domainId:%s \nproperties: %s", domainId, prop));
            String errorMsg = prop.containsKey("ERROR_MESSAGE")?prop.getProperty("ERROR_MESSAGE"):"";
            String objectName = prop.containsKey("OBJECT_TYPE")?prop.getProperty("OBJECT_TYPE"): "";
            waitForCompletion(orgObjectType);
            boolean isSuccessful = false;
            if (errorMsg.contains("invalid_user_pwd")) 
            {
                backupInfo.statusId = StatusId.InvalidCredentials.value;
            } 
            else if (errorMsg.contains("user/system.no_adminprivilege") && objectName.equals("organizationalunit")) 
            {
                backupInfo.statusId = StatusId.AccessDeniedCredentials.value;
            } 
            else if (errorMsg.contains("no_read_permission") && !(objectName.equals("dnsNode") || objectName.equals("dnsZone"))) 
            {
                backupInfo.statusId = StatusId.AccessDeniedCredentials.value;
            } else if(errorMsg.contains("authentication_problem")){
             backupInfo.statusId = StatusId.AuthenticationProblem.value;
             } else if (errorMsg.contains("servers_not_operational")) {
                backupInfo.statusId = StatusId.ServerNotOperational.value;
            }
            else
            {
                isSuccessful = true;
            }
            if (!isSuccessful)
            {
                backupInfo.status = OperationStatus.Failed;
                //backupTracker.updateUsageDetails(this, objectType);
            }
            return isSuccessful;
        }
        catch (Exception e) 
        {
            // backupTracker.updateUsageDetails(this, objectType);
            LogWriter.backup.severe(String.format("RmpBackupImpl.updateException domainId:%s \nexcep: %s", domainId, LogWriter.getStackTrace(e)));
            return true;
        }
    }

    @Override
    public void queuePopBackup(Properties prop) 
    {
        try{
            if(forwardLinkManager!=null && forwardLinkManager.recycledRangedObjects!=null && !forwardLinkManager.recycledRangedObjects.isEmpty()){
        Object[] keyList=forwardLinkManager.recycledRangedObjects.keySet().toArray();
                for(int i=0;i<keyList.length;i++){
                    LinkedAttributesUtil.updateRecycledLinks(forwardLinkManager.recycledRangedObjects.get(keyList[i]), forwardLinkManager, this); 
                }
                this.backupUpdater.dumprangedAttrRecycleInfoData();
                forwardLinkManager.recycledRangedObjects.clear();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        backupObject(prop);
        this.queueProcessing();
    }

    @Override
    public void queuePopGuid(ArrayList<String> objectGuids) 
    {
        DataObject lastBackedupObject = BackupUtil.getLastBackedupObjects(domainId, objectGuids);
        setPreviousBackupValues(lastBackedupObject);
    }
}

class ObjectBatchDump extends Thread
{

    protected DumpQueue dumpQueue;
    public Boolean syncDone;
    public String objectType;

    public ObjectBatchDump(String objectType) 
    {
        dumpQueue = new DumpQueue();
        syncDone = false;
        this.objectType = objectType;
    }

    @Override
    public void run()
    {
        while (true)
        {
            if (waitOrNotify()) 
            {
                break;
            }
            ArrayList details = (ArrayList) dumpQueue.remove();
            if (details != null) 
            {
                BackupImpl backupHook = (BackupImpl) details.get(0);
                BackupUpdater backupUpdater = (BackupUpdater) details.get(1);
                BackupTracker threadBackupTracker = (BackupTracker) details.get(2);
                OperationInfo backupInfo = (OperationInfo) details.get(3);
                if ("rangedAttr".equalsIgnoreCase(objectType) || ObjectType.DnsNode.toString().equalsIgnoreCase(objectType)) 
                {
                    backupUpdater.dumprangedAttrInfoData();
                }
                else if("ouGPLinksAttr".equalsIgnoreCase(objectType) || "siteGPLinksAttr".equalsIgnoreCase(objectType))
                {
                    backupUpdater.dumpGPLinkAttrInfoData();
                }
                else if("primaryGroupAttr".equalsIgnoreCase(objectType)){
                     backupUpdater.dumprangedAttrInfoData();
                }
                backupUpdater.dumpObjectVersionData();
                if (!("rangedAttr".equalsIgnoreCase(objectType) || "ouGPLinksAttr".equalsIgnoreCase(objectType) || "siteGPLinksAttr".equalsIgnoreCase(objectType))) 
                {
                    threadBackupTracker.updateUsageDetails(backupHook, backupHook.objectType, false);
                    backupUpdater.updateBackupProgressInfo(backupInfo);
                }
            }
        }
    }

    public boolean waitOrNotify() 
    {
        if (dumpQueue.isEmpty()) 
        {
            if (syncDone) 
            {
                return true;
            }
            else 
            {
                dumpQueue.waitQueue();
            }
        }
        return false;
    }
}

class DumpQueue 
{

    Queue dumpQueue = new LinkedList();

    public synchronized void add(ArrayList details) 
    {
        dumpQueue.add(details);
        notify();
    }

    public synchronized ArrayList remove() 
    {
        return dumpQueue.isEmpty() ? null : (ArrayList) dumpQueue.remove();
    }

    public synchronized boolean waitQueue() 
    {
        try 
        {
            wait();
        } 
        catch (InterruptedException e) 
        {
            Thread.interrupted();
        }
        return dumpQueue.isEmpty();
    }

    public boolean isEmpty() 
    {
        return dumpQueue.isEmpty();
    }

    public synchronized void notifyQueue()
    {
        notify();
    }
}
//ignoreI18n_end
