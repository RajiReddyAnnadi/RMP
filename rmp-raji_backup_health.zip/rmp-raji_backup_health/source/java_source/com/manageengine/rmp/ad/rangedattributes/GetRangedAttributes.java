package com.manageengine.rmp.ad.rangedattributes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.manageengine.rmp.db.dbutil.DBUtil;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.Query;
import com.adventnet.ds.query.QueryConstructionException;
import com.manageengine.rmp.ad.gpo.manager.GpoLinksUtil;
import com.manageengine.rmp.ad.gpo.manager.GpoUtil;
import com.manageengine.rmp.constants.RmpConstants;
import com.manageengine.rmp.util.LdapUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import java.util.Properties;

/**
 *
 * $Id$
 * 
* @author balachandar-3185
 */
//ignoreI18n_start
public class GetRangedAttributes extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public GetRangedAttributes() {
        super();
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
        Connection con;
        try 
        {
            con = RelationalAPI.getInstance().getConnection();
            DataSet dset = null;
            Query query;
            try 
            {
                String displayGuid, displayDN, queryGuid;
                JSONObject reqParams = new JSONObject(req.getParameter("req"));
                String objectGuid = (String) reqParams.get("objGuid");
                Long domainId = reqParams.getLong("d");//NO I18N
                Long backupId = reqParams.getLong("bid");//NO I18N
                int type = reqParams.getInt("type");//NO I18N
                int linkId = reqParams.getInt("attrId");//NO I18N
                int startIndex = reqParams.getInt("startIndex");//NO I18N
                int endIndex = reqParams.getInt("endIndex");//NO I18N
                boolean isGPOLinks =  linkId == ForwardLink.gPLink.linkId || linkId == BackwardLink.gpBackLinks.linkId;
                JSONObject resultSet = new JSONObject();
                
                if(ForwardLink.isForwardLink(linkId)) 
                {
                    displayGuid = "BACKLINK_OBJECT_GUID";
                    displayDN = "BACKLINK_OBJECT_DN";
                    queryGuid = "FRONTLINK_OBJECT_GUID";
                } 
                else 
                {
                    linkId = ForwardLink.getForwardLink(linkId).linkId;
                    displayGuid = "FRONTLINK_OBJECT_GUID";
                    displayDN = "FRONTLINK_OBJECT_DN";
                    queryGuid = "BACKLINK_OBJECT_GUID";
                }
                if(isGPOLinks)
                {
                    query = GpoLinksUtil.getLinksListFromRangedAttr(domainId, linkId, backupId, objectGuid, type, queryGuid, displayGuid, displayDN, true, startIndex, endIndex);//NO I18N
                }
                else
                {
                    query = LinkedAttributesUtil.getLinksListFromRangedAttr(domainId, linkId, backupId, objectGuid, type, queryGuid, displayGuid, displayDN, true, startIndex, endIndex);//NO I18N
                }
                Properties domainDetails = RMPDomainHandler.getDomainDetailsById(domainId);
                dset = RelationalAPI.getInstance().executeQuery(query, con);
                JSONArray data = new JSONArray();
                if (dset != null) 
                {
                    while (dset.next()) 
                    {
                        JSONArray temp = new JSONArray();
                        String guid = (String) dset.getValue(displayGuid);
                        if(!isGPOLinks || displayGuid.equalsIgnoreCase("FRONTLINK_OBJECT_GUID"))
                        {
                            String dist = (String) dset.getValue(displayDN);
                            if(LdapUtil.isObjectDeleted(dist))
                            {
                                dist = dist.replace("\\0ADEL:"+guid, "");
                            }
                            temp.put(0, LdapUtil.getCommonName(dist));
                            temp.put(1, LdapUtil.getCanonicalName(dist));
                        }
                        else
                        {
                            temp.put(0, dset.getString("OBJECT_NAME"));
                            temp.put(1, dset.getString("OBJECT_NAME"));
                        }
                        
                        temp.put(2, guid);
                        temp.put(3, isGPOLinks);
                        if(isGPOLinks) 
                        {
                            temp.put(4, GpoLinksUtil.linkStatus[dset.getInt("STATUS")]);
                            temp.put(5, dset.getInt("PRIORITY"));
                        }
                        data.put(temp);
                    }
                }
                resultSet.put("d", data);
                resp.setContentType(RmpConstants.CONTENT_TYPE);
                resp.getWriter().write(resultSet.toString());

            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (QueryConstructionException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } finally {
                DBUtil.closeDataSetAndConnection(dset, con);
            }
        } catch (SQLException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        //FrontLinkAttrManager.getAddRemoveAttrforRestore(3l, 150820202752757l, "CN=g6,OU=o,DC=me,DC=local", "c2c09079-6d8d-451a-b5af-820ba982c29f", 74);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
};

//ignoreI18n_end
