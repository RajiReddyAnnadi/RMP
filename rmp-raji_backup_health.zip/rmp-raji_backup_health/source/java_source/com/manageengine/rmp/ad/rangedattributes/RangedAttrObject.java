/**
 * $Id$
 */
package com.manageengine.rmp.ad.rangedattributes;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.util.CommonUtil;
import java.util.ArrayList;
import java.util.HashMap;

import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.TableName;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;

//ignoreI18n_start
public class RangedAttrObject {

    public String objectGuid;
    public String objectDn;
    public ObjectType objType;
    public HashMap<Integer, ArrayList> metadata;
    public ArrayList<String> rangedList;//BackwardLink Restore

    public RangedAttrObject(String objectGuid, String objectDn, ObjectType objType) {
        this.objectGuid = objectGuid;
        this.objectDn = objectDn;
        this.objType = objType;
        metadata = new HashMap();
    }
 
    public RangedAttrObject(String objectGuid, String objectDn) {//BackwardLink Restore
        this.objectGuid = objectGuid;
        this.objectDn = objectDn;
        this.objType = null;
        this.rangedList = new ArrayList();
    }

    public void setMetadata(int linkId, int total, int added, int removed, int modified) {
        ArrayList rangedMetaData = new ArrayList();
        rangedMetaData.add(total);
        rangedMetaData.add(added);
        rangedMetaData.add(removed);
        rangedMetaData.add(modified);
        metadata.put(linkId, rangedMetaData);
    }

    public void updateMetadata(int linkId, int total, int added, int removed, int modified) {
        ArrayList<Object> rangedMetaData = metadata.get(linkId);
        if (rangedMetaData != null) {
            added = added + (int) rangedMetaData.get(1);
            removed = removed + (int) rangedMetaData.get(2);
            modified = modified + (int) rangedMetaData.get(3);
            rangedMetaData.set(0, total);
            rangedMetaData.set(1, added);
            rangedMetaData.set(2, removed);
            rangedMetaData.set(3, modified);
        } else {
            setMetadata(linkId, total, added, removed, modified);
        }
    }

    public void setAllObjectsMetadata(int linkId, int added, int removed, int modified) {
        if (metadata.containsKey(linkId)) {
            ArrayList rangedMetaData = metadata.get(linkId);
            int oldTotal = (int) rangedMetaData.get(0);
            rangedMetaData.set(0, oldTotal + added - removed);
            rangedMetaData.set(1, (int) rangedMetaData.get(1) + added);
            rangedMetaData.set(2, (int) rangedMetaData.get(2) + removed);
            rangedMetaData.set(3, (int) rangedMetaData.get(3) + modified);
        } else {
            ArrayList rangedMetaData = new ArrayList();
            rangedMetaData.add(added - removed);
            rangedMetaData.add(added);
            rangedMetaData.add(removed);
            rangedMetaData.add(modified);
            metadata.put(linkId, rangedMetaData);
        }
    }

    public void setNewBacklinkMetadata(Integer linkId, Integer count, Long linksType, Long backupId) {
        ArrayList rangedMetaData = new ArrayList();
        rangedMetaData.add(0);
        rangedMetaData.add(0);
        rangedMetaData.add(0);
        rangedMetaData.add(0);
        rangedMetaData.set(linksType.intValue(), count);
        rangedMetaData.add(backupId);
        metadata.put(linkId, rangedMetaData);
    }

    public void setBacklinkMetadata(Integer linkId, Integer count, Long linksType, Long backupId) {
        if (metadata.containsKey(linkId)) {
            metadata.get(linkId).set(linksType.intValue(), count);
        } else {
            setNewBacklinkMetadata(linkId, count, linksType, backupId);
        }
    }

    public static void setObjectType(Long domainId, Map<String, RangedAttrObject> objectList, boolean isFullSync, HashMap<String, Object[]> allObjects) {
        try {
            if (isFullSync) {
                for (Map.Entry<String, RangedAttrObject> object : objectList.entrySet()) {
                    objectList.get(object.getKey()).objType = (ObjectType) allObjects.get(object.getValue().objectDn.toLowerCase())[1];
                }
            } else {
                SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId));
                Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_GUID"), objectList.keySet().toArray(), QueryConstants.IN);
                query.setCriteria(criteria);
                query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "CURRENTINFO_ID"));
                query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_GUID"));
                query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_TYPE"));
                DataObject dataObject = DataAccess.get(query);
                if (!dataObject.isEmpty()) {
                    Iterator iterator = dataObject.getRows(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId);
                    while (iterator.hasNext()) {
                        Row row = (Row) iterator.next();
                        objectList.get(row.get("OBJECT_GUID").toString()).objType = ObjectType.parse(Long.valueOf(row.get("OBJECT_TYPE").toString()));
                    }
                }
            }
        } catch (Exception e) {
            LogWriter.backup.log(Level.SEVERE, "RangedAttrObject setObjectType : {0}", e);
        }
    }

    public static HashMap<String, Object[]> fillAllObjectDetails(long domainId, boolean isFullSync, long[] objectTypeSelect) {
        HashMap<String, Object[]> allObjects = null;
        try {
           // if (isFullSync) {
                allObjects = new HashMap();
                SelectQuery allObjectsQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "CURRENTINFO_ID"));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_GUID"));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_DN"));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_TYPE"));
                Criteria allObjectsCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+ "_" +domainId, "OBJECT_TYPE"), objectTypeSelect, QueryConstants.IN);
                allObjectsQuery.setCriteria(allObjectsCriteria);
                DataObject dataObject = CommonUtil.getPersistence().get(allObjectsQuery);
                if (!dataObject.isEmpty()) {
                    Iterator iterator = dataObject.getRows(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId);
                    while (iterator.hasNext()) {
                        Row row = (Row) iterator.next();
                        Object[] allObjectsMetaval = new Object[]{(String) row.get("OBJECT_GUID"), ObjectType.parse((Long) row.get("OBJECT_TYPE"))};
                        allObjects.put(((String) row.get("OBJECT_DN")).toLowerCase(), allObjectsMetaval);
                    }
                }
          //  }
        } catch (Exception e) {
            LogWriter.backup.log(Level.SEVERE, "RangedAttrObject fillAllObjectDetails: {0}", e);
        }
        return allObjects;
    }

    public static void setBackLinkDetails(HashMap<String, RangedAttrObject> backwardLinkMetadata, HashMap<String, Object[]> allObjects, String objectDn, String objectGuid, boolean isFullSync, int linkId, int added, int removed, int modified) {
        RangedAttrObject rangedAttrObject;
        try {
            objectGuid = objectGuid.toLowerCase();
            if (!backwardLinkMetadata.containsKey(objectGuid)) {
                rangedAttrObject = new RangedAttrObject(objectGuid, objectDn, isFullSync ? (ObjectType) allObjects.get(objectDn.toLowerCase())[1] : null);
                backwardLinkMetadata.put(objectGuid, rangedAttrObject);
            } else {
                rangedAttrObject = backwardLinkMetadata.get(objectGuid);
            }
            rangedAttrObject.setAllObjectsMetadata(linkId, added, removed, modified);
        } catch (Exception e) {
            LogWriter.backup.log(Level.SEVERE, "RangedAttrObject setBackLinkDetails: {0}", e);
        }
    }
}
//ignoreI18n_end
