/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.parser;

import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.ad.gpo.constants.GpoAddRem;
import com.manageengine.rmp.ad.gpo.constants.GptTmplType;
import java.io.Serializable;
import java.util.Set;
import org.json.JSONArray;

/**
 *
 * @author lucky-2306
 */
public class GptEntry extends AbstractGpoEntry  implements Serializable{

    public GptTmplType gptType;
    public String sv;

    public GptEntry() {
        this.gpoAddRem = GpoAddRem.Add;
        this.sv = "";
    }

    @Override
    public boolean compareTo(AbstractGpoEntry gptEntry) {
        return this.valueName.equals(gptEntry.valueName) && this.gpoAddRem.addRemId == gptEntry.gpoAddRem.addRemId;
    }
    
    public boolean compareSV(GptEntry gptEntry, boolean isEqual) {
        try
        {
            boolean equals = this.valueName.equals(gptEntry.valueName);
            if(!equals) {
                Set newData = JSONObjectUtil.fromJsonString(this.sv, Set.class);
                Set oldData = JSONObjectUtil.fromJsonString(gptEntry.sv, Set.class);
                if(newData.equals(oldData)) {
                    equals = true;
                }
            }
            return equals && this.gpoAddRem.addRemId == gptEntry.gpoAddRem.addRemId;
        }
        catch(Exception e){
            return isEqual;
        }
    }
}
