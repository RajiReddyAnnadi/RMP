/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.parser;

import com.manageengine.rmp.ad.gpo.constants.*;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.util.BitConverter;
import com.manageengine.rmp.util.DataTypeUtil;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import org.apache.commons.lang.ArrayUtils;

/**
 * $Id$
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class PolEntry extends AbstractGpoEntry implements Serializable {

    public ArrayList<Byte> byteList;
    public PolEntryType type;

    public GpoConfigType gpoUserMach;
    public String appendVN;

    public long dWORDValue;
    public Long qWORDValue;
    public String stringValue;
    public String[] multiStringValue;
    public byte[] binaryValue;
    public ArrayList<Byte> dataBytes;

    public PolEntry(PolEntryConcise polEntryCouch) {
        this.byteList = polEntryCouch.bl;
        this.keyName = polEntryCouch.kn;
        this.valueName = polEntryCouch.vn;
        this.setType(PolEntryType.getType(polEntryCouch.pt));
        this.gpoAddRem = GpoAddRem.getType(polEntryCouch.ar);
        this.setgpoUserMach(GpoConfigType.getType(polEntryCouch.um));
        this.setappendVN(polEntryCouch.ka);
    }

    public PolEntry() {
        this.byteList = new ArrayList<Byte>();
        type = PolEntryType.REG_NONE;
        gpoAddRem = GpoAddRem.Add;
        keyName = "";
        valueName = "";
        this.appendVN = "";
    }

    public PolEntry(String rawEntry) {
        int splitIndex;
        if (rawEntry.contains("!")) {
            splitIndex = rawEntry.indexOf("!");
        } else {
            splitIndex = rawEntry.lastIndexOf("\\");
        }
        this.keyName = rawEntry.substring(rawEntry.indexOf("\\") + 1, splitIndex);
        this.valueName = rawEntry.substring(splitIndex + 1);
    }

    public final PolEntryType getType() {
        return type;
    }

    public final void setType(PolEntryType value) {
        type = value;
    }

    public final GpoConfigType getgpoUserMach() {
        return gpoUserMach;
    }

    public final void setgpoUserMach(GpoConfigType value) {
        gpoUserMach = value;
    }

    public final String getappendVN() {
        return appendVN;
    }

    public final void setappendVN(String value) {
        appendVN = value;
    }

    public final ArrayList<Byte> createDataBytes() {
        return this.dataBytes = getDataBytes();
    }

    public final ArrayList<Byte> getDataBytes() {
        return this.byteList;
    }

    public final long createDWORDValue() throws Exception {
        return this.dWORDValue = getDWORDValue();
    }

    public final long getDWORDValue() throws Exception {
        byte[] bytes = DataTypeUtil.arrayListToByteArray(byteList);
        switch (this.type) {
            case REG_NONE:
            case REG_SZ:
            case REG_MULTI_SZ:
            case REG_EXPAND_SZ:
                long result = 0;
                try {
                    result = Long.parseLong(this.stringValue);
                    return result;
                } catch (Exception e) {
                    throw new ClassCastException();
                }
            case REG_DWORD:
                if (bytes.length != 4) {
                    throw new IllegalStateException();
                }
                if (DataTypeUtil.isBigEndian()) {
                    ArrayUtils.reverse(bytes);
                }
                return BitConverter.toUInt32(bytes, 0);
            case REG_DWORD_BIG_ENDIAN:
                if (bytes.length != 4) {
                    throw new IllegalStateException();
                }
                if (DataTypeUtil.isLittleEndian()) {
                    ArrayUtils.reverse(bytes);
                }
                return BitConverter.toUInt32(bytes, 0);
            case REG_QWORD:
                if (bytes.length != 8) {
                    throw new IllegalStateException();
                }
                if (DataTypeUtil.isBigEndian()) {
                    ArrayUtils.reverse(bytes);
                }
                Long lvalue = BitConverter.toUInt64(bytes, 0);
                if (lvalue > Long.MAX_VALUE || lvalue < 0) {
                    throw new RuntimeException("QWORD value '" + (new Long(lvalue)).toString() + "' cannot fit into an UInt32 value.");//No I18N
                }
                return lvalue;
            case REG_BINARY:
                if (bytes.length != 4) {
                    throw new IllegalStateException();
                }
                return BitConverter.toUInt32(bytes, 0);
            default:
                throw new RuntimeException("Reached default cast that should be unreachable in PolEntry.UIntValue");//No I18N
        }
    }

    public final void setDWORDValue(int value) {
        this.setType(PolEntryType.REG_DWORD);
        this.byteList.clear();
        byte[] arrBytes = BitConverter.getBytes(value);
        if (DataTypeUtil.isBigEndian()) {
            ArrayUtils.reverse(arrBytes);
        }
        this.byteList.addAll(DataTypeUtil.bytesArraytoArrayList(arrBytes));
    }

    public final Long createQWORDValue() {
        return this.qWORDValue = getQWORDValue();
    }

    public final Long getQWORDValue() {
        try {
            byte[] bytes = DataTypeUtil.arrayListToByteArray(this.byteList);

            switch (this.type) {
                case REG_NONE:
                case REG_SZ:
                case REG_MULTI_SZ:
                case REG_EXPAND_SZ:
                    Long result = 0L;
                    try {
                        result = Long.parseLong(this.stringValue);
                        return result;
                    } catch (Exception e) {
                        return 0L;
                    }
                case REG_DWORD:
                    if (bytes.length != 4) {
                        LogWriter.gpo.severe("Val Conv : " + this.keyName + " " + this.valueName);
                        return 0L;
                    }
                    if (DataTypeUtil.isBigEndian()) {
                        ArrayUtils.reverse(bytes);
                    }
                    return (Long) BitConverter.toUInt32(bytes, 0);
                case REG_DWORD_BIG_ENDIAN:
                    if (bytes.length != 4) {
                        LogWriter.gpo.severe("Val Conv : " + this.keyName + " " + this.valueName);
                        return 0L;
                    }
                    if (DataTypeUtil.isLittleEndian()) {
                        ArrayUtils.reverse(bytes);
                    }
                    return (Long) BitConverter.toUInt32(bytes, 0);
                case REG_QWORD:
                    if (bytes.length != 8) {
                        LogWriter.gpo.severe("Val Conv : " + this.keyName + " " + this.valueName);
                        return 0L;
                    }
                    if (DataTypeUtil.isBigEndian()) {
                        ArrayUtils.reverse(bytes);
                    }
                    return BitConverter.toUInt64(bytes, 0);
                case REG_BINARY:
                    if (bytes.length != 8) {
                        LogWriter.gpo.severe("Val Conv : " + this.keyName + " " + this.valueName);
                        return 0L;
                    }
                    if (DataTypeUtil.isBigEndian()) {
                        ArrayUtils.reverse(bytes);
                    }
                    return BitConverter.toUInt64(bytes, 0);
                default:
                    LogWriter.gpo.severe("Val Conv : " + this.keyName + " " + this.valueName);
                    return 0L;
            }
        } catch (Exception ex) {
            LogWriter.gpo.severe("Pol Entry : " + LogWriter.getStackTrace(ex));
            return 0L;
        }
    }

    public final void setQWORDValue(Long value) {
        this.type = PolEntryType.REG_QWORD;
        this.byteList.clear();
        byte[] arrBytes = BitConverter.getBytes(value);
        if (DataTypeUtil.isBigEndian()) {
            ArrayUtils.reverse(arrBytes);
        }
        this.byteList.addAll(DataTypeUtil.bytesArraytoArrayList(arrBytes));
    }

    public final String createStringValue() {
        return this.stringValue = getStringValue();
    }

    public final String getStringValue() {
        try {
            byte[] bytes = DataTypeUtil.arrayListToByteArray(this.byteList);

            StringBuilder sb = new StringBuilder(bytes.length * 2);

            switch (this.type) {
                case REG_NONE:
                    return "";
//                case REG_MULTI_SZ:
//                    String[] mstring = multiStringValue;
//                    for (int i = 0; i < mstring.length; i++) {
//                        if (i > 0) {
//                            sb.append("\\0");
//                        }
//                        sb.append(mstring[i]);
//                    }
//
//                    return sb.toString();
                case REG_DWORD:
                case REG_DWORD_BIG_ENDIAN:
                case REG_QWORD:
                    Long qWordVal = this.getQWORDValue();
                    return (qWordVal).toString();
                case REG_BINARY:
                    for (int i = 0; i < bytes.length; i++) {
                        sb.append(String.format("%02X", bytes[i]));//No I18N
                    }

                    return sb.toString();
                case REG_SZ:
                case REG_MULTI_SZ:
                case REG_EXPAND_SZ:
                    return new String(bytes, "UTF-8").replace("\0", "");//No I18N
                default:
                    LogWriter.gpo.severe("Val Conv : " + this.keyName + " " + this.valueName + " Reached default cast that should be unreachable in PolEntry.StringValue");
                    return "";
            }
        } catch (UnsupportedEncodingException ex) {
            LogWriter.gpo.severe("Pol Entry : " + LogWriter.getStackTrace(ex));
            return "";
        }
    }

    public final void setStringValue(String value) {
        try {
            if (value == null) {
                value = "";
            }
            this.type = PolEntryType.REG_SZ;
            this.byteList.clear();
            this.byteList.addAll(DataTypeUtil.bytesArraytoArrayList((value + "\0").getBytes("UTF-8")));//No I18N
        } catch (Exception ex) {
            LogWriter.gpo.severe("Pol Entry : " + LogWriter.getStackTrace(ex));
        }
    }

    public final String[] createMultiStringValue() {
        return this.multiStringValue = getMultiStringValue();
    }

    public final String[] getMultiStringValue() {
        byte[] bytes = DataTypeUtil.arrayListToByteArray(this.byteList);

        switch (this.type) {
            case REG_NONE:
                LogWriter.gpo.severe("Val Conv : " + this.keyName + " " + this.valueName + " StringValue cannot be used on the REG_NONE type.");
                return new String[0];
            case REG_DWORD:
            case REG_DWORD_BIG_ENDIAN:
            case REG_QWORD:
            case REG_BINARY:
            case REG_SZ:
            case REG_EXPAND_SZ:
                return new String[]{this.stringValue};
            case REG_MULTI_SZ:
                ArrayList<String> list = new ArrayList<String>();

                StringBuilder sb = new StringBuilder(256);

                for (int i = 0; i < (bytes.length - 1); i += 2) {
                    char[] curChar = DataTypeUtil.getCharsFromBytes(bytes, "UTF-8", i, 2);//No I18N

                    if (curChar[0] == '\0') {
                        if (sb.length() == 0) {
                            break;
                        }
                        list.add(sb.toString());
                        sb.setLength(0);
                    } else {
                        sb.append(curChar[0]);
                    }
                }

                return list.toArray(new String[0]);
            default:
                LogWriter.gpo.severe("Val Conv : " + this.keyName + " " + this.valueName + " Reached default cast that should be unreachable in PolEntry.MultiStringValue");
                return new String[0];
        }
    }

    public final void setMultiStringValue(String[] value) {
        try {
            this.type = PolEntryType.REG_MULTI_SZ;
            this.byteList.clear();

            if (value != null) {
                for (int i = 0; i < value.length; i++) {
                    if (i > 0) {
                        this.byteList.addAll(DataTypeUtil.bytesArraytoArrayList(("\0").getBytes("UTF-8")));//No I18N
                    }

                    if (value[i] != null) {
                        this.byteList.addAll(DataTypeUtil.bytesArraytoArrayList(value[i].getBytes("UTF-8")));//No I18N
                    }
                }
            }
            this.byteList.addAll(DataTypeUtil.bytesArraytoArrayList(("\0\0").getBytes("UTF-8")));//No I18N
        } catch (UnsupportedEncodingException ex) {
            LogWriter.gpo.severe("Pol Entry : " + LogWriter.getStackTrace(ex));
        }
    }

    public final byte[] createBinaryValue() {
        return this.binaryValue = getBinaryValue();
    }

    public final byte[] getBinaryValue() {
        return DataTypeUtil.arrayListToByteArray(this.byteList);
    }

    public final void setBinaryValue(byte[] value) {
        this.type = PolEntryType.REG_BINARY;
        this.byteList.clear();

        if (value != null) {
            this.byteList.addAll(DataTypeUtil.bytesArraytoArrayList(value));
        }
    }

    public final void setDWORDBigEndianValue(long value) {
        this.type = PolEntryType.REG_DWORD_BIG_ENDIAN;
        this.byteList.clear();
        byte[] arrBytes = BitConverter.getBytes(value);
        if (DataTypeUtil.isLittleEndian()) {
            ArrayUtils.reverse(arrBytes);
        }
        this.byteList.addAll(DataTypeUtil.bytesArraytoArrayList(arrBytes));
    }

    public final void setExpandStringValue(String value) {
        this.stringValue = value;
        this.type = PolEntryType.REG_EXPAND_SZ;
    }

    protected void finalize() throws Throwable {
        this.byteList = null;
    }

    @Override
    public boolean compareTo(AbstractGpoEntry other) {
        return this.stringValue.equals(((PolEntry) other).stringValue) && (this.gpoAddRem.addRemId == other.gpoAddRem.addRemId);
    }
}

//ignoreI18n_end
