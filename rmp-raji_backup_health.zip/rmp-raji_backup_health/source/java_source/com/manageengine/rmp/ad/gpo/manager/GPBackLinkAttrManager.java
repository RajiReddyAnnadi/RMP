/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.manager;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.Query;
import com.manageengine.ads.fw.jni.ADSNativeHandler;
import com.manageengine.rmp.ad.adsync.BaseDNPrepender;
import com.manageengine.rmp.ad.adsync.SyncFilter;
import com.manageengine.rmp.ad.backup.BackupImpl;
import com.manageengine.rmp.ad.backup.BackupUtil;
import com.manageengine.rmp.ad.rangedattributes.BackLinkAttrManager;
import com.manageengine.rmp.ad.rangedattributes.ForwardLink;
import com.manageengine.rmp.ad.rangedattributes.LinkType;
import com.manageengine.rmp.ad.rangedattributes.LinkedAttributesUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.recovery.RecoveryHandler;
import com.manageengine.rmp.util.LdapUtil;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Objects;
import java.util.Properties;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author poornima-3055
 */
public class GPBackLinkAttrManager extends BackLinkAttrManager 
{

    public GPBackLinkAttrManager(long domainId, long backupId, BackupImpl backupImpl) 
    {
        super(domainId, backupId, backupImpl);
    }
    
    protected String setTableName()
    {
        return TableName.RMP_GPO_LINK_ATTRIBUTES+"_"+DOMAIN_ID;
    }
    
    public static Properties restoreRangedAttr(Properties domainDetails, Long restoreBackupId, String objectGuid, int maskIndex, ObjectType objectType) 
    {
        Boolean result = true;
        Connection con = null;
        DataSet dset = null;
        long added = 0, removed = 0, skipped = 0, modified = 0;
        try 
        {
            con = RelationalAPI.getInstance().getConnection();
            JSONArray restoreGPOLinks = new JSONArray();
            ArrayList<String> restorelinks = new ArrayList();
            try
            {
                Query query = GpoLinksUtil.getLinksListFromRangedAttr(Long.parseLong(domainDetails.getProperty("DOMAIN_ID")), ForwardLink.getForwardLink(maskIndex).linkId, restoreBackupId == null ? 0L : restoreBackupId, objectGuid, 0, "BACKLINK_OBJECT_GUID", "FRONTLINK_OBJECT_GUID", "FRONTLINK_OBJECT_DN", false, 0, 0);//NO I18N
                dset = RelationalAPI.getInstance().executeQuery(query, con);
                while (dset.next()) 
                {
                    String backLinkGuid = (String) dset.getValue("FRONTLINK_OBJECT_GUID");// No I18N
                    restorelinks.add(backLinkGuid);
                    skipped += getRestoreGPOLinks(restoreGPOLinks, dset, objectGuid, backLinkGuid, domainDetails, false);
                }
            }
            catch (Exception e) 
            {
                LogWriter.backup.severe("GPBackLinkAttrManager: " + Arrays.toString(e.getStackTrace()));    //No I18N
                e.printStackTrace();
            }
            finally 
            {
                DBUtil.closeDataSetAndConnection(dset, con);
            }
            getRestoreCurrentLink(restoreGPOLinks, restoreBackupId, domainDetails, maskIndex, objectGuid, restorelinks);
            if(restoreGPOLinks.length() > 0)
            {
                for(int i = 0; i < restoreGPOLinks.length(); i++)
                {
                    JSONObject restoreGPOLink = restoreGPOLinks.getJSONObject(i);
                    String newGPLink = restoreGPOLink.get("gPLink").toString();
                    String gpoId = restoreGPOLink.get("gpoId").toString();
                    int status = restoreGPOLink.getInt("status");   //No I18N
                    int priority = restoreGPOLink.getInt("priority");   //No I18N
                    int linkType = restoreGPOLink.getInt("linkType");   //No I18N
                    String backLinkGuid = restoreGPOLink.get("restoreObjId").toString();
                    ObjectType restoreObjType = (ObjectType) restoreGPOLink.get("frontLinkType");
                    JSONObject restoreInfo = GpoLinksUtil.getNewRestoreInfo();
                    String gPLink = GpoLinksUtil.gpBackLinksRestoreInfo(domainDetails.getProperty("DOMAIN_NAME"), restoreInfo, newGPLink, gpoId, restoreBackupId == null, status, priority, linkType);
                    RecoveryHandler recoveryHandler = new RecoveryHandler(domainDetails, restoreObjType, backLinkGuid, BackupUtil.getString(domainDetails, "distinguishedName"));  //No I18N
                    Hashtable<String, Object> attributeValue = new Hashtable();
                    attributeValue.put(recoveryHandler.ATTR_VALUE_COUNT, new Long(1));
                    attributeValue.put(recoveryHandler.ATTR_NAME, "gPLink");
                    attributeValue.put(recoveryHandler.DATA_HANDLER_TYPE, new Long(3));
                    attributeValue.put(recoveryHandler.ATTR_VALUE, gPLink);
                    recoveryHandler.propList.add(attributeValue);
                    boolean isRestored = recoveryHandler.recoverObject();
                    if(isRestored) 
                    {
                        added += restoreInfo.getLong("added");  //No I18N
                        modified += restoreInfo.getLong("modified");    //No I18N
                        removed += restoreInfo.getLong("removed");  //No I18N
                        skipped += restoreInfo.getLong("skipped");  //No I18N
                    }
                    result = result && isRestored;
                    recoveryHandler.clearRequiredLists();
                }   
            }
        } 
        catch (Exception e) 
        {
            LogWriter.backup.severe("GPBackLinkAttrManager: " + Arrays.toString(e.getStackTrace()));    //No I18N
            e.printStackTrace();
        }
        finally 
        {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        Properties restoreprop = new Properties();
        restoreprop.put("result", result);
        restoreprop.put("added", added);
        restoreprop.put("skipped", skipped);
        restoreprop.put("removed", removed);
        restoreprop.put("modified", modified);
        return restoreprop;
    }
    
    private static int getRestoreGPOLinks(JSONArray restoreGPOLinks, DataSet dset, String gpoId, String backLinkGuid, Properties domainDetails, boolean isCurrentLink) throws Exception
    {
        int skipped = 0;
        int status = (int) dset.getValue("STATUS");// No I18N
        int priority = (int) dset.getValue("PRIORITY");// No I18N
        int linksType = (int) dset.getValue("LINKS_TYPE");  //No I18N
        ObjectType frontLinkType = ObjectType.parse((Long) dset.getValue("FRONTLINK_TYPE"));    //No I18N
        String defaultNamingContext = domainDetails.getProperty("DEFAULT_NAMING_CONTEXT");
        if(frontLinkType == ObjectType.Site)
        {
            defaultNamingContext = BaseDNPrepender.getBaseDNPrepender(SyncFilter.site.filterId).baseDNString + defaultNamingContext;
        }
        String searchString = "(objectGUID=" + LdapUtil.encodeObjectGUID(backLinkGuid) + ")";   //No I18N
        ArrayList<Properties> ouProps = ADSNativeHandler.executeADQuery(domainDetails, new String[]{"isDeleted", "gPLink", "distinguishedName"}, searchString, defaultNamingContext);    //No I18N
        if(!ouProps.isEmpty())
        {
            Properties prop = ouProps.get(0);
            if (!isCurrentLink && !prop.containsKey("distinguishedName") || (prop.containsKey("isDeleted") && BackupUtil.getBoolean(prop, "isDeleted") != null && BackupUtil.getBoolean(prop, "isDeleted")))
            {
                skipped++;
            } 
            else
            {
                String gpLink = prop.containsKey("gPLink") ? BackupUtil.getString(prop, "gPLink") : ""; //No I18N
                if((isCurrentLink && gpLink.toLowerCase().contains(gpoId.toLowerCase())) || !isCurrentLink && !(!gpLink.toLowerCase().contains(gpoId.toLowerCase()) && linksType == LinkType.Removed.memberTypeId.intValue()))
                {
                    JSONObject restoreGPOLink = new JSONObject();
                    restoreGPOLink.put("gpoId", gpoId);
                    restoreGPOLink.put("gPLink", gpLink);
                    restoreGPOLink.put("status", status);
                    restoreGPOLink.put("frontLinkType", frontLinkType);
                    restoreGPOLink.put("linkType", isCurrentLink ? LinkType.Removed.memberTypeId.intValue() : linksType);
                    restoreGPOLink.put("priority", priority);
                    restoreGPOLink.put("restoreObjId", backLinkGuid);
                    restoreGPOLink.put("restoreObjDn", BackupUtil.getString(prop, "distinguishedName"));
                    restoreGPOLinks.put(restoreGPOLink);
                }
            }
        }
        else
        {
            skipped++;
        }
        return skipped;
    }
    
    private static void getRestoreCurrentLink(JSONArray restoreGPOLinks, Long restoreBackupId, Properties domainDetails, int maskIndex, String objectGuid, ArrayList<String> restoreLinks) throws Exception 
    {
        if(restoreBackupId != null )
        {
            Connection con = null;
            DataSet dset = null;
            try
            {
                con = RelationalAPI.getInstance().getConnection();
                Query query = GpoLinksUtil.getLinksListFromRangedAttr(Long.parseLong(domainDetails.getProperty("DOMAIN_ID")), ForwardLink.getForwardLink(maskIndex).linkId, 0L, objectGuid, 0, "BACKLINK_OBJECT_GUID", "FRONTLINK_OBJECT_GUID", "FRONTLINK_OBJECT_DN", false, 0, 0);//NO I18N
                dset = RelationalAPI.getInstance().executeQuery(query, con);
                while (dset.next()) 
                {
                    String backLinkGuid = (String) dset.getValue("FRONTLINK_OBJECT_GUID");// No I18N
                    if(!restoreLinks.contains(backLinkGuid))
                    {
                        getRestoreGPOLinks(restoreGPOLinks, dset, objectGuid, backLinkGuid, domainDetails, true);
                    }
                }
            }
            catch (Exception e) 
            {
                LogWriter.backup.severe("GPBackLinkAttrManager: " + Arrays.toString(e.getStackTrace()));    //No I18N
                e.printStackTrace();
            }
            finally 
            {
                DBUtil.closeDataSetAndConnection(dset, con);
            }
        }
    }

}
