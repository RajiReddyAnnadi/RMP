/* $Id$ :
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.manager;

import com.manageengine.rmp.common.PsOperations;
import com.manageengine.rmp.ad.gpo.policies.PolicyModifier;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ModificationResult;
import com.manageengine.rmp.util.winutil.DirectoryUtil;
import com.manageengine.rmp.util.winutil.UNCAccess;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.UUID;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class GpoRestore {

    private String backupId;
    private String gpoId;
    private String computerName;
    public GpoProp gpoProp;
    private PolicyModifier policyModifier;
    public int exitCode;
    private boolean powerShell = true;

    public GpoRestore(long domainId) {
        this.gpoProp = new GpoProp(domainId);
        construct();
    }

    public GpoRestore(Properties domainDetails) {
        this.gpoProp = new GpoProp(domainDetails);
        construct();
    }

    private void construct() {
        try {
            this.computerName = GpoUtil.getComputerName(gpoProp.dcName, gpoProp.domainName);
            gpoProp.bkpGpoMainDir = gpoProp.getGpoBackupDir(gpoProp.domainId);
            gpoProp.tmpGpoMainDir = new File(gpoProp.bkpGpoMainDir, "TempGpo");//NO I18N   
            gpoProp.dcMainDir = UNCAccess.getRemoteFile(GpoProp.DC_MAIN_DIR, gpoProp.dcName);
            gpoProp.dcGpoMainDir = new File(gpoProp.dcMainDir, GpoProp.DC_GPO_BACKUP_DIR + "\\");
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format("%s", LogWriter.getStackTrace(e)));
        }
    }

    public boolean isPowerShell(){
        return this.powerShell;
    }
    
    public void setPowerShell(boolean powerShell){
        this.powerShell = powerShell;
    }
    
    public final void initRestoreGpo(String distinguishedName, UUID objId, boolean isDeleted) {
        try {
            UNCAccess.openRemoteConnection(gpoProp.dcName, gpoProp.adminName, gpoProp.password);
            gpoId = GpoUtil.getGpoId(distinguishedName);
            gpoProp.bkpGpoDir = GpoUtil.getGpoPath(gpoProp.bkpGpoMainDir, gpoId);
            GpoBackup gpoBackup = new GpoBackup(gpoProp.domainId, "");//ToDo: Remove Hardcode
            ArrayList<Object> gpoFiles = gpoBackup.initBackupGpos(gpoId, objId);
            this.backupId = gpoBackup.backupId;
            gpoProp.dcGpoMainDir = gpoBackup.gpoProp.dcGpoMainDir;
            gpoProp.tmpGpoDir = gpoBackup.gpoProp.tmpGpoDir;
            if(gpoBackup.gpoProp.dcGpoDir == null){
                gpoProp.dcGpoDir = new File(gpoProp.dcGpoMainDir, backupId);
            }
            else{
                gpoProp.dcGpoDir = gpoBackup.gpoProp.dcGpoDir;
            }
            policyModifier = new PolicyModifier(gpoFiles);
        } catch (Exception ex) {
            LogWriter.gpo.severe(String.format("%s %s", ex, LogWriter.getStackTrace(ex)));
        }
    }

    public ModificationResult restoreDeletedGpo(String objectGuid, String dName) {
        try {
            gpoId = GpoUtil.getGpoId(dName);
            UNCAccess.openRemoteConnection(gpoProp.dcName, gpoProp.adminName, gpoProp.password);
            GpoUtil.checkDcDirsPresent(gpoProp);
            String dcGpoMainDirPath = GpoProp.DC_MAIN_DIR + "\\" + GpoProp.DC_GPO_BACKUP_DIR + "_" + UUID.randomUUID();
            gpoProp.dcGpoMainDir = UNCAccess.getRemoteFile(dcGpoMainDirPath, gpoProp.dcName);
            gpoProp.dcGpoMainDir.mkdirs();
            gpoProp.bkpGpoDir = new File(gpoProp.bkpGpoMainDir, GpoUtil.addBracesGpoID(gpoId));
            gpoProp.bkpGpoSubDir = DirectoryUtil.findDirectory(gpoProp.bkpGpoDir, 1);
            backupId = gpoProp.bkpGpoSubDir.getName();
            gpoProp.dcGpoDir = new File(gpoProp.dcGpoMainDir, backupId);
            if (finalizeRestoreGpo(true)) {
                return ModificationResult.Modified;
            } else {
                return ModificationResult.Failed;
            }
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format("%s  %s", e, LogWriter.getStackTrace(e)));
            return ModificationResult.Failed;
        } finally {
            UNCAccess.closeRemoteConnection(gpoProp.dcName);
        }
    }

    public final boolean finalizeRestoreGpo(boolean isDeleted) {
        try {
            if (isDeleted) {
                UNCAccess.copyDirToRemote(gpoProp.bkpGpoSubDir, gpoProp.dcGpoDir);
            } else {
                restoreChangedPol(); //Not Deleted Gpo
                restoreChangedGpt();
                restoreChangedAudit();
                UNCAccess.emptyDirectory(gpoProp.dcGpoMainDir);
                UNCAccess.copyDirToRemote(gpoProp.tmpGpoDir, gpoProp.dcGpoDir);
                DirectoryUtil.deleteDirectory(gpoProp.tmpGpoDir);
            }
            gpoProp.dcGpoLocalDir = UNCAccess.getLocalFilePath(gpoProp.dcGpoMainDir);
            HashMap result = restoreGpoRemoteCmd(PsOperations.GpoRestore, gpoProp.dcGpoLocalDir.getPath());
            if (result != null){
                exitCode = (Integer) result.get("ExitCode");
                powerShell = (Boolean) result.get("PowerShell");
            }
            else{
                exitCode = -1;
            }
            LogWriter.gpo.fine("Exit Code : " + exitCode);
        } catch (Exception ex) {
            LogWriter.gpo.severe("finalizeRestoreGpo : " + LogWriter.getStackTrace(ex));
            exitCode |= 1024;//2^10
        } finally {
            UNCAccess.deleteDirectory(gpoProp.dcGpoMainDir);
            DirectoryUtil.deleteDirectory(gpoProp.tmpGpoDir);
            UNCAccess.closeRemoteConnection(gpoProp.dcName);
        }
        return exitCode == 0;
    }

    private HashMap restoreGpoRemoteCmd(PsOperations gpoOperation, String dcGpoMainDirPath) {
        return GpoDcExec.restoreGpoRemote(gpoOperation, gpoProp.domainName, computerName,gpoProp.userDomainName, gpoProp.userName, gpoProp.password, this.backupId, dcGpoMainDirPath, powerShell);
    }

    private void restoreChangedPol() {
        try {
            policyModifier.newUserPol.saveFile(gpoProp.tmpGpoDir.getPath() + "\\DomainSysvol\\GPO\\User\\registry.pol");//No I18N
            policyModifier.newMachinePol.saveFile(gpoProp.tmpGpoDir.getPath() + "\\DomainSysvol\\GPO\\Machine\\registry.pol");//No I18N

        } catch (Exception ex) {
            LogWriter.gpo.severe(String.format("%s", ex));
        }
    }

    private void restoreChangedGpt() {
        try {
            policyModifier.newUserGpt.saveFile(gpoProp.tmpGpoDir.getPath() + "\\DomainSysvol\\GPO\\User\\Microsoft\\Windows NT\\SecEdit\\GptTmpl.inf");//No I18N
            policyModifier.newMachineGpt.saveFile(gpoProp.tmpGpoDir.getPath() + "\\DomainSysvol\\GPO\\Machine\\Microsoft\\Windows NT\\SecEdit\\GptTmpl.inf");//No I18N
        } catch (Exception ex) {
            LogWriter.gpo.severe(String.format("%s", ex));
        }
    }

    private void restoreChangedAudit() {
        try {
            policyModifier.newUserAudit.saveFile(gpoProp.tmpGpoDir.getPath() + "\\DomainSysvol\\GPO\\User\\Microsoft\\Windows NT\\Audit\\audit.csv");//No I18N
            policyModifier.newMachineAudit.saveFile(gpoProp.tmpGpoDir.getPath() + "\\DomainSysvol\\GPO\\Machine\\Microsoft\\Windows NT\\Audit\\audit.csv");//No I18N
        } catch (Exception ex) {
            LogWriter.gpo.severe(String.format("%s", LogWriter.getStackTrace(ex)));
        }
    }

    public final boolean modifyPolicy(Object serializedEntry, int attrId, Object oldValue) {
        try {
            if ((attrId >= 200 && attrId <= 4207) || (attrId >= 5208 && attrId <= 5387) || (attrId >= 8000)) {
                return policyModifier.modifyPolEntry(serializedEntry, oldValue, attrId);
            } else if (attrId >= 4208 && attrId <= 4400) {
                return policyModifier.modifyGptEntry(serializedEntry, oldValue, attrId);
            } else if (attrId >= 4400 && attrId <= 4500) {
                return policyModifier.modifyAuditEntry(serializedEntry, oldValue, attrId);
            } else {
                oldValue = "";
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }
}

//ignoreI18n_end
