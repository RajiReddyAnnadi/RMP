/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.rangedattributes;

import java.util.ArrayList;

/**
 * $Id$
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public enum BackwardLink {

    //Add Enum here and its AttributeMask for Backward Link Backup/Restore
    memberOf(12),
    managedObjects(13),
    directReports(14),
    records(87),
    gpBackLinks(100),
    msExchModeratedObjectsBL(163),
    none(-1);

    public int linkId;

    BackwardLink(int linkId) {
        this.linkId = linkId;
    }

    public String getAttributeName() {
        switch (this.linkId) {
            case 74:
            case 12:
                return "memberOf";
            case 61:
            case 13:
                return "managedObjects";
            case 44:
            case 14:
                return "directReports";
            case 87:
                return "records";
            case 100:
                return "gpBackLinks";
            case 162:
            case 163:
                return "msExchModeratedObjectsBL";

            default:
                return "";
        }
    }

    public static String getAttributeName(int linkId) {
        return getBackwardLink(linkId).getAttributeName();
    }

    public ForwardLink getForwardLink() {
        switch (this) {
            case memberOf:
                return ForwardLink.member;
            case managedObjects:
                return ForwardLink.managedBy;
            case directReports:
                return ForwardLink.manager;
            case gpBackLinks:
                return ForwardLink.gPLink;
            case msExchModeratedObjectsBL:
                return ForwardLink.msExchModeratedByLink;

            default:
                return ForwardLink.none;
        }
    }

    public static BackwardLink getBackwardLink(int linkId) {
        switch (linkId) {
            case 12:
            case 74:
                return memberOf;
            case 61:
            case 13:
                return managedObjects;
            case 44:
            case 14:
                return directReports;
            case 100:
                return gpBackLinks;
            case 162:
            case 163:
                return msExchModeratedObjectsBL;

            default:
                return none;
        }
    }
    
    public static boolean isSingleValued(int linkId)
    {
        if(linkId == 13 || linkId == 14 )
        {
            return true;
        }
        return false;
    }
    
    public static boolean isBackwardLink(int attrMask) {
        return attrMask == BackwardLink.directReports.linkId ||attrMask == BackwardLink.managedObjects.linkId ||attrMask == BackwardLink.memberOf.linkId || attrMask == BackwardLink.gpBackLinks.linkId || attrMask == BackwardLink.msExchModeratedObjectsBL.linkId;
    }

    public static ArrayList<Integer> getValues() {
        ArrayList<Integer> backwardLink = new ArrayList<>();
        for (BackwardLink link : BackwardLink.values()) {
            backwardLink.add(link.linkId);
        }
        return backwardLink;
    }
}
//ignoreI18n_end
