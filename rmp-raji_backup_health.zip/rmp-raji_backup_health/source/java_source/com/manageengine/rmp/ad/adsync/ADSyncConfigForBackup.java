//$Id$
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.adsync;

import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ObjectType;
import static com.manageengine.rmp.db.dbhelper.RmpAttributeUtil.getAttributeIdFromMask;
import com.manageengine.rmp.settings.customattributes.CustomAttributesManager;

import com.manageengine.rmp.util.Attribute;
import com.manageengine.rmp.util.DataTypeUtil;
import com.manageengine.rmp.util.RMPDomainHandler;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashSet;
import java.util.Properties;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class ADSyncConfigForBackup {

    public static void deleteSyncConfigForDomain(long domainId, int objectTypes) {
        try {
            for (SyncFilter syncFilterType : SyncFilter.values()) {
                deleteSyncConfigForObject(domainId, syncFilterType.filterId.longValue());
            }
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncConfigForBackup : " + e);
        }
    }

    public static void deleteSyncConfig(long domainId) {
        ArrayList<Long> objectTypes = new ArrayList<Long>();
        Long objectIDIndex = getObjectID(domainId, 0);
        Long maxIndex = objectIDIndex + SyncFilter.values().length;
        while (objectIDIndex < maxIndex) {
            objectTypes.add(++objectIDIndex);
        }
        ADSyncAttributesConfig.deleteSyncConfigRow(objectTypes);
        ADSyncObjectsConfig.deleteSyncConfigRows(objectTypes);
    }

    public static void deleteSyncConfigForObject(long domainId, Long objectType) {
        long objectID = getObjectID(domainId, objectType);
        ADSyncAttributesConfig.deleteSyncConfigRow(objectID);
        ADSyncObjectsConfig.deleteSyncConfigRow(objectID);
    }

    public static void addSyncConfigForDomain(long domainId, int objectTypes, BitSet selectedAttributes) {
        try {
            LogWriter.general.info("objecttypes" + objectTypes);
            for (int objectType : getSelectedObjects(objectTypes)) {
                for (Integer syncObjectType : SyncFilter.getSyncObjectType(objectType)) {
                    long objectID = getObjectID(domainId, syncObjectType);
                    boolean isRowSelected = addSyncConfigForObject(domainId, syncObjectType, objectID);
                    if (isRowSelected) {
                        selectedAttributes = addSyncConfigForAttribute(domainId, objectID, objectType, syncObjectType, selectedAttributes);
                    }
                }
            }
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncConfigForBackup : " + e);
        }
    }

    public static boolean addSyncConfigForObject(long domainId, int objectType, long objectID) {
        //long priorityID = getPriorityID(domainId, objectType, objectID);
        Properties syncObjRow = RMPADSyncConfig.getRMPSyncObjectRow(objectType);
        long priorityID = getObjectID(domainId, (Long) syncObjRow.get("PRIORITY_ID"));
        LogWriter.general.info("syncObjRow" + syncObjRow.toString());
        return ADSyncObjectsConfig.addSyncConfigRow(domainId, objectID, syncObjRow.getProperty("OBJECT_TYPE"), syncObjRow.getProperty("SEARCH_STRING"), BaseDNPrepender.getBaseDNPrepender(objectType), (Boolean) syncObjRow.get("IS_ENABLED"), priorityID, (long) syncObjRow.get("SEARCH_PREFERENCE"));
    }

    public static BitSet addSyncConfigForAttribute(Long domainId, long objectID, int objectType, int syncObjectType, BitSet selectedAttributes) {
        HashSet<String> syncAttrRows = RMPADSyncConfig.getRMPSyncAttributesRow(syncObjectType);
        for (int index = selectedAttributes.nextSetBit(0); index >= 0; index = selectedAttributes.nextSetBit(index + 1)) {
            try {
                Attribute attribute = new Attribute(getAttributeIdFromMask(index).longValue());
                Long attrObjID = Long.valueOf(attribute.objectType);
                if (objectType == attrObjID && attribute.toSync) {
                    String attrName = attribute.attrName;
                    syncAttrRows.add(attrName);
                    selectedAttributes.clear(index);
                } else if (attrObjID > objectType) {
                    break;
                }
                CustomAttributesManager.getCustomAttributesForSync(syncAttrRows);
            } catch (Exception e) {
                LogWriter.general.severe("ADSyncConfigForBackup : " + e);
            }
        }
        ADSyncAttributesConfig.addSyncConfigRows(objectID, syncAttrRows);
        return selectedAttributes;
    }

    //*******************
    //Utilities
    //******************
    public static long getObjectID(long domainId, long objectType) {
        return SyncFilter.DOMAIN_ID_OFFSET * domainId + objectType;
    }

    private static int[] getSelectedObjects(int objectTypes) {
        ArrayList<Integer> selectedObjects = new ArrayList<Integer>();
        selectedObjects.add(0);
        for (int i = 0; i < ObjectType.values().length;) {
            if ((objectTypes & (1 << i)) != 0) {
                selectedObjects.add(++i);
            } else {
                i++;
            }
        }
        return DataTypeUtil.getArrayListAsIntArray(selectedObjects);
    }

    public static ArrayList<Long> getAllObjectIds(int objectType) {

        ArrayList<Long> objectIds = new ArrayList<Long>();
        for (Properties domainDetails : RMPDomainHandler.getRMPDomainDetails()) {
            Boolean isBackupConfigured = Boolean.valueOf(domainDetails.get("IS_BACKUP_CONFIGURED").toString());
            if (isBackupConfigured) {
                Long domainId = Long.valueOf(domainDetails.get("DOMAIN_ID").toString());
                Long objectId = getObjectID(domainId, SyncFilter.getObjectType(objectType) + SyncFilter.CUSTOM_ATTR_OFFSET);
                objectIds.add(objectId);
            }
        }
        return objectIds;
    }
}

//ignoreI18n_end
