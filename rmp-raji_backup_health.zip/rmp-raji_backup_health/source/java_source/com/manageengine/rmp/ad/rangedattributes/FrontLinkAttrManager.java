package com.manageengine.rmp.ad.rangedattributes;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.ad.backup.BackupUpdater;
import com.manageengine.rmp.ad.backup.BackupImpl;
import com.manageengine.rmp.ad.gpo.manager.GPFrontLinkAttrManager;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.RMPCommonFlags;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.recovery.RecoveryHandler;
import com.manageengine.rmp.recovery.retreiverClass;
import com.manageengine.rmp.util.Attribute;
import com.manageengine.rmp.util.GeneralUtil;
import com.manageengine.rmp.util.LdapUtil;
import java.util.logging.Level;
import org.json.JSONObject;

/**
 *
 * $Id$
 * 
* @author balachandar-3185
 */
//ignoreI18n_start
public class FrontLinkAttrManager {

    public Long domainId;
    public String domainName;
    public Long backupId;
    public boolean isFullSync;
    public boolean isInitBackup;
    public BackupUpdater backupUpdater;
    public ForwardLink forwardLink;
    public Map<String, RangedAttrObject> frontLinkMetaInfo;
    public HashMap<String, RangedAttrObject> backLinkMetaInfo;
    public static final int ADDED = 1, REMOVED = 2, MODIFIED = 3;
    public HashMap<String, Object[]> allObjects = null;//String[] = {[0]-Guid, [1]-ObjectType}
    public HashMap<String, BackupObject> recycledRangedObjects;
    public HashMap<String, ArrayList<BackupObject>> deletedRangedObjects;
    public String tableName;
    
    public FrontLinkAttrManager(Long domainId, String domainName, Long backupId, boolean isInitBackup, boolean isFullSync, BackupUpdater backupUpdater, HashMap<String, RangedAttrObject> backLinkMetaInfo) {
        this.domainId = domainId;
        this.domainName = domainName;
        this.backupId = backupId;
        this.isInitBackup = isInitBackup;
        this.isFullSync = isFullSync;
        this.allObjects = fillAllObjectDetails();
        this.backupUpdater = backupUpdater;
        frontLinkMetaInfo = new HashMap();
        this.backLinkMetaInfo = backLinkMetaInfo;
        recycledRangedObjects = new HashMap();
        deletedRangedObjects = new HashMap();
        tableName = setTableName();
    }

    public FrontLinkAttrManager(Long domainId, Long backupId) {
        this.domainId = domainId;
        this.backupId = backupId;
    }
    
    protected String setTableName()
    {
        return TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId;
    }
    
    protected HashMap fillAllObjectDetails()
    {
        long[] objectTypeSelect = new long[]{ObjectType.User.maskValue, ObjectType.Computer.maskValue, ObjectType.Contact.maskValue, ObjectType.Group.maskValue, ObjectType.OU.maskValue};
        return RangedAttrObject.fillAllObjectDetails(domainId, isFullSync, objectTypeSelect);
    }
    
    //this will update the members of group in db
    public Boolean updateFrontLinks(Properties prop, BackupObject backupObject, BackupObject lastBackupObject)
    {
        try 
        {
            ArrayList<String> addedMembersDn = new ArrayList(), removedMembersDn = new ArrayList(), modifiedMembersDn = new ArrayList();
            RangedAttrObject linkObject = getRangedAttrObject(prop, backupObject, lastBackupObject);
            
            for (ForwardLink forwardLink : ForwardLink.values()) 
            {
                JSONObject linkCount = LinkedAttributesUtil.getDefaultLinksCount();
                if(linkCount == null)
                {
                    continue;
                }
                if (forwardLink.linkId != ForwardLink.none.linkId) 
                {
                    String attributeName = forwardLink.getAttributeName();
                    if (LinkedAttributesUtil.isLinkChanged(prop, attributeName)) 
                    {
                        this.forwardLink = forwardLink;
                        if (isInitBackup) 
                        {

                            updateInitialBackupLinks(backupObject, linkObject, prop, attributeName, addedMembersDn, linkCount);
                            LogWriter.backup.log(Level.INFO, "Full Sync---Total:{0}Added:{1}Removed:{2}", new Object[]{linkCount.getInt("totalCount"), linkCount.getInt("addedCount"), linkCount.getInt("removedCount")});
                        } 
                        else 
                        { 
                            updateTotalCountFromPreviousBackup(lastBackupObject, linkObject, forwardLink, linkCount);
                            updateIncrementalBackupAddedRange(backupObject, prop, attributeName, addedMembersDn, linkCount);
                            updateIncrementalBackupRemovedRange(backupObject, prop, attributeName, removedMembersDn, linkCount);
                            updateIncrementalBackupModifiedRange(backupObject, prop, attributeName, modifiedMembersDn, linkCount);
                            
                            linkCount.put("totalCount", linkCount.getInt("totalCount") + linkCount.getInt("addedCount") - linkCount.getInt("removedCount"));
                            LogWriter.backup.log(Level.INFO, "changessync---Total:{0}Added:{1}Removed:{2}", new Object[]{linkCount.getInt("totalCount"), linkCount.getInt("addedCount"), linkCount.getInt("removedCount")});
                        }

                        if (linkCount.getInt("addedCount") != 0 || linkCount.getInt("removedCount") != 0 || linkCount.getInt("modifiedCount") != 0) 
                        {
                            if (frontLinkMetaInfo.containsKey(backupObject.objId.toString())) 
                            {
                                linkObject.updateMetadata(forwardLink.linkId, linkCount.getInt("totalCount"), linkCount.getInt("addedCount"), linkCount.getInt("removedCount"), linkCount.getInt("modifiedCount"));
                            } 
                            else 
                            {
                                linkObject.setMetadata(forwardLink.linkId, linkCount.getInt("totalCount"), linkCount.getInt("addedCount"), linkCount.getInt("removedCount"), linkCount.getInt("modifiedCount"));
                            }
                        }
                    }
                }
            }
            if (!linkObject.metadata.isEmpty()) 
            {
                frontLinkMetaInfo.put(backupObject.objId.toString(), linkObject);
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
            LogWriter.backup.log(Level.SEVERE, "FrontLinkAttrManager: updateFrontLinks domainId-{0}{1}{2}", new Object[]{domainId, e, LogWriter.getStackTrace(e)});
        }
        return true;
    }

    public RangedAttrObject getRangedAttrObject(Properties prop, BackupObject backupObject, BackupObject lastBackupObject) throws Exception
    {
        RangedAttrObject linkObject;
        if (frontLinkMetaInfo.containsKey(backupObject.objId.toString())) 
        {
            linkObject = frontLinkMetaInfo.get(backupObject.objId.toString());
        } 
        else 
        {
            linkObject = new RangedAttrObject(backupObject.objId.toString(), GeneralUtil.getADProperty(prop, "distinguishedName"), lastBackupObject.objTyp);
        }
        return linkObject;
    }
    
    public void updateInitialBackupLinks(BackupObject backupObject, RangedAttrObject linkObject, Properties prop, String attributeName, ArrayList<String> addedMembersDn, JSONObject linkCount) throws Exception
    {
        attributeName = attributeName + LinkedAttributesUtil.ADDED_RANGE;
        if(prop.containsKey(attributeName))
        {
            addedMembersDn = getMembersDN(prop, attributeName);
            linkCount.put("addedCount", updateAddedFrontLinks(backupObject.objId.toString(), prop, addedMembersDn, linkCount.getInt("totalCount"), null));
            if (linkObject.metadata.containsKey(forwardLink.linkId)) 
            {
                linkCount.put("totalCount", linkCount.getInt("addedCount") + (int) linkObject.metadata.get(forwardLink.linkId).get(0));
            } 
            else 
            {
                linkCount.put("totalCount", linkCount.getInt("addedCount"));
            }
        }
    }
    
    protected ArrayList<String> getMembersDN(Properties prop, String attributeName)
    {
        return prop.containsKey(attributeName) ? (ArrayList<String>) prop.get(attributeName) : new ArrayList();
    }
        
    public void updateTotalCountFromPreviousBackup(BackupObject lastBackupObject, RangedAttrObject linkObject, ForwardLink forwardLink, JSONObject linkCount) throws Exception
    {
        if (linkObject.metadata.containsKey(forwardLink.linkId)) 
        {
            linkCount.put("totalCount", (int) linkObject.metadata.get(forwardLink.linkId).get(0));
        } 
        else if (lastBackupObject.linksData.has("b" + forwardLink.linkId))
        {
            ArrayList<Object> tempMeta = new ArrayList();
            tempMeta = JSONObjectUtil.getObjectFromJsonString(lastBackupObject.linksData.get("b" + forwardLink.linkId).toString(), tempMeta.getClass());
            Double tempDouble = (Double) tempMeta.get(0);
            linkCount.put("totalCount", tempDouble.intValue());
        }
    }
    
    public void updateIncrementalBackupAddedRange(BackupObject backupObject, Properties prop, String attributeName, ArrayList<String> addedMembersDn, JSONObject linkCount) throws Exception
    {
        attributeName = attributeName + LinkedAttributesUtil.ADDED_RANGE;
        if (prop.containsKey(attributeName)) 
        {
            addedMembersDn = getMembersDN(prop, attributeName);
            removeDeletedObjectsWithNoHistory(domainId, addedMembersDn);
            if (prop.containsKey("backlinkGuid") && addedMembersDn.size() == 1) 
            {
                linkCount.put("addedCount", updateAddedFrontLinks(backupObject.objId.toString(), prop, addedMembersDn, linkCount.getInt("totalCount") , (String) prop.get("backlinkGuid")));
            } 
            else 
            {
                linkCount.put("addedCount", updateAddedFrontLinks(backupObject.objId.toString(), prop, addedMembersDn, linkCount.getInt("totalCount") , null));
            }
        }
    }
    
    public void updateIncrementalBackupRemovedRange(BackupObject backupObject, Properties prop, String attributeName, ArrayList<String> removedMembersDn, JSONObject linkCount) throws Exception
    {
        boolean isGPLink = attributeName.equalsIgnoreCase(ForwardLink.gPLink.getAttributeName());
        attributeName = attributeName + LinkedAttributesUtil.REMOVED_RANGE;
        if (prop.containsKey(attributeName)) 
        {
            removedMembersDn = getMembersDN(prop, attributeName);
            removeDeletedObjectsWithNoHistory(domainId, removedMembersDn);
            if (prop.containsKey("backlinkGuid") && removedMembersDn.size() == 1) 
            {
                linkCount.put("removedCount", updateRemovedFrontLinks(backupObject.objId.toString(), prop, removedMembersDn, (String) prop.get("backlinkGuid"), isGPLink));
            } 
            else
            {
                linkCount.put("removedCount", updateRemovedFrontLinks(backupObject.objId.toString(), prop, removedMembersDn, null, isGPLink));
            }
        }
    }
    
    public void updateIncrementalBackupModifiedRange(BackupObject backupObject, Properties prop, String attributeName, ArrayList<String> modifiedMembersDn, JSONObject linkCount) throws Exception
    {
        attributeName = attributeName + LinkedAttributesUtil.MODIFIED_RANGE;
        if (prop.containsKey(attributeName)) 
        {
            modifiedMembersDn = getMembersDN(prop, attributeName);
            removeDeletedObjectsWithNoHistory(domainId, modifiedMembersDn);
            if (prop.containsKey("backlinkGuid") && modifiedMembersDn.size() == 1) 
            {
                linkCount.put("modifiedCount", updateModifiedFrontLinks(backupObject.objId.toString(), prop, modifiedMembersDn, (String) prop.get("backlinkGuid")));
            } 
            else
            {
                linkCount.put("modifiedCount", updateModifiedFrontLinks(backupObject.objId.toString(), prop, modifiedMembersDn, null));
            }
        }
    }

    //this will update added member of group in db//
    public int updateAddedFrontLinks(String objectGuid, Properties backupProps, ArrayList<String> addedMembersDn, int totalMembers, String backlinkGuid) throws Exception{
        Properties linkGuidVsDn = new Properties();
        if (backlinkGuid != null) {
            linkGuidVsDn.put(backlinkGuid, addedMembersDn.get(0));
        } else {
            linkGuidVsDn = LinkedAttributesUtil.getGuidForLinks(addedMembersDn, domainId, domainName, isFullSync, allObjects,backupId);
        }
        Iterator<Map.Entry<Object,Object>> iter = linkGuidVsDn.entrySet().iterator();
        while(iter.hasNext())
        {
            Map.Entry<Object,Object> property = iter.next();
            if(LdapUtil.isObjectDeleted((String)property.getValue()))
            {
                updateLinkAttrInfo(backupProps, forwardLink, backupId, LinkType.Removed, objectGuid,(String) property.getKey());
                iter.remove();
            }
           /* if(recycledRangedObjects.containsKey((String) property.getKey()))
            {
                recycledRangedObjects.remove((String) property.getKey());
            }*/
        }
        if (isInitBackup) {
            updateAddedFrontLinkAttrs(backupProps, objectGuid, linkGuidVsDn);
            return linkGuidVsDn.size();
        } else {
            if (totalMembers != 0) {
                ArrayList tempMemberGuid = new ArrayList(linkGuidVsDn.keySet());
                ArrayList<String> linksToRemove = getCommonFrontLinkFromBackup(objectGuid, tempMemberGuid);
                for (String linkToRemove : linksToRemove) {
                    linkGuidVsDn.remove(linkToRemove);
                }
                updateAddedFrontLinkAttrs(backupProps, objectGuid, linkGuidVsDn);
                return linkGuidVsDn.size();
            } else {
                updateAddedFrontLinkAttrs(backupProps, objectGuid, linkGuidVsDn);
                return linkGuidVsDn.size();
            }
        }
    }

    //update the removed members of group in db
    public int updateRemovedFrontLinks(String objectGuid, Properties backupProps, ArrayList removedMembersDn, String backlinkGuid, boolean isDeletedGPLink) throws Exception{
        Properties linkGuidVsDn = new Properties();
        if (backlinkGuid != null) {
            linkGuidVsDn.put(backlinkGuid, removedMembersDn.get(0));
        } else if (isDeletedGPLink) {
            linkGuidVsDn = LinkedAttributesUtil.getGuidForLinks(removedMembersDn, domainId, domainName, isDeletedGPLink,backupId);
        } else {
            linkGuidVsDn = LinkedAttributesUtil.getGuidForLinks(removedMembersDn, domainId, domainName,backupId);
        }
        ArrayList<String> tempMemberGuid = new ArrayList(linkGuidVsDn.keySet());
        ArrayList<String> currentMembersGuid = getCommonFrontLinkFromBackup(objectGuid, tempMemberGuid);
        if (!currentMembersGuid.isEmpty()) {
            updateRemovedFrontLinkAttrs(backupProps, objectGuid, linkGuidVsDn, currentMembersGuid);
            removeLinksFromCurrentBackup(objectGuid, currentMembersGuid);
        }
        return currentMembersGuid.size();
    }
    
    //update the removed members of group in db
    public int updateModifiedFrontLinks(String objectGuid, Properties backupProps, ArrayList modifiedMembersDn, String backlinkGuid) throws Exception{
        Properties linkGuidVsDn = new Properties();
        if (backlinkGuid != null) {
            linkGuidVsDn.put(backlinkGuid, modifiedMembersDn.get(0));
        } else {
            linkGuidVsDn = LinkedAttributesUtil.getGuidForLinks(modifiedMembersDn, domainId, domainName,backupId);
        }
        ArrayList<String> tempMemberGuid = new ArrayList(linkGuidVsDn.keySet());
        ArrayList<String> currentMembersGuid = getCommonFrontLinkFromBackup(objectGuid, tempMemberGuid);
        if (!currentMembersGuid.isEmpty()) {
            updateModifiedFrontLinkAttrs(backupProps, objectGuid, linkGuidVsDn, currentMembersGuid);
            modifyLinksFromCurrentBackup(backupProps, objectGuid, currentMembersGuid);
        }
        return currentMembersGuid.size();
    }

    // compare get the common list from the table
    public ArrayList<String> getCommonFrontLinkFromBackup(String objectGuid, ArrayList linksGuid) {
        ArrayList commonList = new ArrayList();
        String[] linkGuidArray = (String[]) linksGuid.toArray(new String[0]);
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(tableName));
            Criteria criteria = new Criteria(Column.getColumn(tableName, "FORWARD_LINK_ID"), forwardLink.linkId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(tableName, "FRONTLINK_OBJECT_GUID"), objectGuid, QueryConstants.EQUAL, false);
            criteria = criteria.and(Column.getColumn(tableName, "LINKS_TYPE"), LinkType.Total.memberTypeId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(tableName, "BACKLINK_OBJECT_GUID"), linkGuidArray, QueryConstants.IN, false);
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(tableName, "*"));
            DataObject dataObject = DataAccess.get(query);
            if (!dataObject.isEmpty()) {
                Iterator iterator = dataObject.getRows(tableName);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    commonList.add((String) row.get("BACKLINK_OBJECT_GUID"));
                }
                return commonList;
            }
            return commonList;
        } catch (Exception e) {
            LogWriter.backup.log(Level.SEVERE, "FrontLinkAttrManager: getCommonMembersListFromBackup domainId-{0}{1}", new Object[]{domainId, e});
            e.printStackTrace();
            return commonList;
        }
    }
    
    public static ArrayList<String> getCommonFrontLinkDnFromBackup(long domainId,ForwardLink flink,String guid,ArrayList linkDns)
    {
        ArrayList<String> commonList = new ArrayList<String>();
        String[] linkdnArray = (String[]) linkDns.toArray(new String[0]);
        String ranged = TableName.RMP_RANGED_ATTRIBUTES + "_" + domainId;
        String current = TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId;
        Connection con = null;
        DataSet dset = null;
        try
        {
            SelectQuery query = new SelectQueryImpl(Table.getTable(ranged));
            Join join = new Join(ranged, current, new String[]{"BACKLINK_OBJECT_GUID"}, new String[]{"OBJECT_GUID"}, Join.INNER_JOIN);
            query.addJoin(join);
            Criteria criteria = new Criteria(Column.getColumn(ranged, "FORWARD_LINK_ID"), flink.linkId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(ranged, "FRONTLINK_OBJECT_GUID"), guid, QueryConstants.EQUAL,false);
            criteria = criteria.and(Column.getColumn(ranged, "LINKS_TYPE"), LinkType.Total.memberTypeId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(current, "OBJECT_DN"), linkdnArray, QueryConstants.IN);
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(current, "OBJECT_DN"));
            con = RelationalAPI.getInstance().getConnection();
            dset = RelationalAPI.getInstance().executeQuery(query, con);
            if (dset != null)
            {
                while (dset.next())
                {
                    commonList.add(dset.getAsString("OBJECT_DN"));
                }
            }
        } catch (Exception e)
        {
            e.printStackTrace();
        } finally
        {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        return commonList;
    }

    //it will get memberobject with dn and guid and will send one by one to addGroupMemberInfo
    public Boolean updateAddedFrontLinkAttrs(Properties backupProps, String objectGuid, Properties linkGuidAndDn) throws Exception{
        for (Map.Entry<Object, ?> property : linkGuidAndDn.entrySet()) {
            updateLinkAttrInfo(backupProps, forwardLink, backupId, LinkType.Added, objectGuid, (String) property.getKey());
            updateLinkAttrInfo(backupProps, forwardLink, LinkType.Total.memberTypeId, LinkType.Total, objectGuid, (String) property.getKey());
            RangedAttrObject.setBackLinkDetails(backLinkMetaInfo, allObjects, (String) property.getValue(), (String) property.getKey(), isFullSync, forwardLink.getBackwardLink().linkId, 1, 0, 0);
        }
        return true;
    }
    
    public Boolean updateLinkAttrInfo(Properties prop, ForwardLink forwardLink, Long backupId, LinkType linkType, String objectGUID, String backLinkGUID) throws Exception
    {
        return backupUpdater.updateLinkAttrInfo(forwardLink.linkId, backupId, linkType.memberTypeId, objectGUID, backLinkGUID);
    }

    public Boolean updateRemovedFrontLinkAttrs(Properties backupProps, String forwardLinkGuid, Properties linkGuidAndDn, ArrayList<String> backwardLinkGuids) throws Exception{
        for (String backwardLinkGuid : backwardLinkGuids) {
            updateLinkAttrInfo(backupProps, forwardLink, backupId, LinkType.Removed, forwardLinkGuid, backwardLinkGuid);
            RangedAttrObject.setBackLinkDetails(backLinkMetaInfo, allObjects, (String) linkGuidAndDn.get(backwardLinkGuid), backwardLinkGuid, isFullSync, forwardLink.getBackwardLink().linkId, 0, 1, 0);
        }
        return true;
    }
    
    public Boolean updateModifiedFrontLinkAttrs(Properties backupProps, String forwardLinkGuid, Properties linkGuidAndDn, ArrayList<String> backwardLinkGuids) throws Exception{
        for (String backwardLinkGuid : backwardLinkGuids) {
            updateLinkAttrInfo(backupProps, forwardLink, backupId, LinkType.Modified, forwardLinkGuid, backwardLinkGuid);
            RangedAttrObject.setBackLinkDetails(backLinkMetaInfo, allObjects, (String) linkGuidAndDn.get(backwardLinkGuid), backwardLinkGuid, isFullSync, forwardLink.getBackwardLink().linkId, 0, 0, 1);
        }
        return true;
    }

    public Boolean removeLinksFromCurrentBackup(String objectGuid, ArrayList<String> linkGuidList) {
        String[] linkGuid = (String[]) linkGuidList.toArray(new String[linkGuidList.size()]);
        try {
            Criteria criteria = new Criteria(Column.getColumn(tableName, "LINKS_TYPE"), 0, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(tableName, "FORWARD_LINK_ID"), forwardLink.linkId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(tableName, "FRONTLINK_OBJECT_GUID"), objectGuid, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(tableName, "BACKLINK_OBJECT_GUID"), linkGuid, QueryConstants.IN);
            CommonUtil.getPersistence().delete(criteria);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }
    
    public Boolean modifyLinksFromCurrentBackup(Properties prop, String objectGuid, ArrayList<String> linkGuidList) {
        return true;
    }

    public Boolean finalUpdateToObject(BackupImpl backupImpl) {
        backupUpdater.updateRangedAttrMetadatainObj(frontLinkMetaInfo, backupImpl, true, backupImpl.isInitBackup);
        return true;
    }

    public Boolean dbDumperRangedAttributes() {
        backupUpdater.dumprangedAttrInfoData();
        return true;
    }

    public static Properties restoreLinkedAttr(Properties domainDetails, Long restoreBackupId, String objectDn, String objectGuid, int maskIndex, ObjectType objectType, Attribute attrInfo,Properties adValue,boolean toReanimate,ArrayList<String> deletedObjectList) 
    {
        if(maskIndex == ForwardLink.gPLink.linkId)
        {
            return GPFrontLinkAttrManager.restoreRangedAttr(domainDetails, restoreBackupId, objectGuid, maskIndex, objectType);
        }
        else
        {
            return restoreRangedAttr(domainDetails, restoreBackupId, objectDn, objectGuid, maskIndex, objectType, attrInfo,adValue,toReanimate,deletedObjectList) ;
        }
    }
    
    public static Properties restoreRangedAttr(Properties domainDetails, Long restoreBackupId, String objectDn, String objectGuid, int maskIndex, ObjectType objectType, Attribute attrInfo,Properties adValue,boolean toReanimate,ArrayList<String> deletedObjectList) {
        Connection con = null;
        DataSet dset = null;
        Properties restoreResult = new Properties();
        Boolean result = true;
        long added = 0, skipped=0, removed=0,addSkipped=0,rmvSkipped=0;
        try {
            con = RelationalAPI.getInstance().getConnection();
            Long domainId = Long.parseLong((String) domainDetails.get("DOMAIN_ID"));
            RecoveryHandler obj = new RecoveryHandler(domainDetails, objectType, objectGuid, objectDn);
            int addCount = 0, removeCount = 0;
            SelectQuery addSQ = null, removeSQ = null;
            if(toReanimate && LdapUtil.isRecycleBinEnabled(domainDetails.get("DOMAIN_NAME").toString())){
                clearFrontLink(obj, attrInfo);
            }
            if (restoreBackupId != null) {
                addSQ = LinkedAttributesUtil.compareForRestoreFrontLink(domainId, maskIndex, restoreBackupId, objectGuid, "FRONTLINK_OBJECT_GUID", "BACKLINK_OBJECT_GUID", "BACKLINK_OBJECT_DN", ADDED,toReanimate);
                String test1=RelationalAPI.getInstance().getSelectSQL(addSQ);
                removeSQ = LinkedAttributesUtil.compareForRestoreFrontLink(domainId, maskIndex, restoreBackupId, objectGuid, "FRONTLINK_OBJECT_GUID", "BACKLINK_OBJECT_GUID", "BACKLINK_OBJECT_DN", REMOVED,toReanimate);
                test1=RelationalAPI.getInstance().getSelectSQL(addSQ);
            } else {
                removeSQ = LinkedAttributesUtil.compareForRestoreFrontLink(domainId, maskIndex, -1L, objectGuid, "FRONTLINK_OBJECT_GUID", "BACKLINK_OBJECT_GUID", "BACKLINK_OBJECT_DN", REMOVED,toReanimate);//To Remove The Whole List
            }
            ArrayList dbRemoved = new ArrayList<String>();
             if(!toReanimate || !LdapUtil.isRecycleBinEnabled(domainDetails.get("DOMAIN_NAME").toString())){
            dset = RelationalAPI.getInstance().executeQuery(removeSQ, con);
            if(dset != null)
            {
                while(dset.next())
                {
                    String linkDN = dset.getAsString("BACKLINK_OBJECT_DN");
                    dbRemoved.add(linkDN);
                }
            }
                 DBUtil.closeDataSet(dset);
            }
            ArrayList dbAdded = new ArrayList<String>();
            if (addSQ != null)
            {
                dset = RelationalAPI.getInstance().executeQuery(addSQ, con);
                if (dset != null)
                {
                    while (dset.next())
                    {
                        String linkDN = dset.getAsString("BACKLINK_OBJECT_DN");
                        dbAdded.add(linkDN);
                    }
                }
                DBUtil.closeDataSet(dset);
            }
            ArrayList adAdded,adRemoved;
            adAdded = new ArrayList<String>();
            adRemoved = new ArrayList<String>();
            if(adValue.containsKey(attrInfo.attrName+LinkedAttributesUtil.ADDED_RANGE))
            {
                adAdded = (ArrayList)adValue.get(attrInfo.attrName+LinkedAttributesUtil.ADDED_RANGE);
                ArrayList common = getCommonFrontLinkDnFromBackup(domainId, ForwardLink.getForwardLink(maskIndex), objectGuid, adAdded);
                adAdded.removeAll(common);
            }
             if(!toReanimate || !LdapUtil.isRecycleBinEnabled(domainDetails.get("DOMAIN_NAME").toString())){
            if(adValue.containsKey(attrInfo.attrName+LinkedAttributesUtil.REMOVED_RANGE))
            {
                adRemoved = (ArrayList)adValue.get(attrInfo.attrName+LinkedAttributesUtil.REMOVED_RANGE);
                ArrayList common = getCommonFrontLinkDnFromBackup(domainId, ForwardLink.getForwardLink(maskIndex), objectGuid, adRemoved);
                adRemoved.retainAll(common);
            }
             }
            
            
            ArrayList exclude = new ArrayList();
            exclude.addAll(retreiverClass.getIntersection(dbAdded, adAdded));
            exclude.addAll(retreiverClass.getIntersection(dbRemoved, adRemoved));
            
            adRemoved.removeAll(dbAdded);
            adAdded.removeAll(dbRemoved);
            
            dbAdded.addAll(adRemoved);
            dbAdded.removeAll(exclude);
            
            dbRemoved.addAll(adAdded);
            dbRemoved.removeAll(exclude);

            ArrayList<String> valueList = new ArrayList<>();

            for(Object linkDn : dbRemoved)
            {
                removeCount++;
                String dist = (String) linkDn;
                if (!LdapUtil.isObjectDeleted(dist))
                {
                    valueList.add(dist);
                }
                if (removeCount == 1000)
                {
                    //result = result && restoreFrontLink(obj, attrInfo, valueList, 4);
                    if(restoreFrontLink(obj, attrInfo, valueList, 4))
                    {
                        removed+= valueList.size();
                    }
                    else
                    {
                        skipped += valueList.size();
                        rmvSkipped+=valueList.size();
                    }
                    removeCount = 0;
                    valueList.clear();
                }

            }
            if (removeCount > 0)
            {
                //result = result && restoreFrontLink(obj, attrInfo, valueList, 4);
                if (restoreFrontLink(obj, attrInfo, valueList, 4))
                {
                    removed+= valueList.size();
                } else
                {
                    skipped += valueList.size();
                    rmvSkipped+=valueList.size();
                }
                removeCount = 0;
                valueList.clear();
            }

            valueList = new ArrayList<>();

            for (Object linkDn : dbAdded)
            {
                addCount++;
                String dist = (String) linkDn;
                if (!LdapUtil.isObjectDeleted(dist))
                {
                    valueList.add(dist);
                } else
                {
                    skipped++;
                    addSkipped++;
                }
                if (addCount == 1000)
                {
                    //result = result && restoreFrontLink(obj, attrInfo, valueList, 3);
                    if (restoreFrontLink(obj, attrInfo, valueList, 3))
                    {
                        added+= valueList.size();
                    }/* else
                    {
                        skipped += valueList.size();
                    }*/
                    addCount = 0;
                    valueList.clear();
                }
            }
            if (addCount > 0)
            {
                //result = result && restoreFrontLink(obj, attrInfo, valueList, 3);
                if (restoreFrontLink(obj, attrInfo, valueList, 3))
                {
                    added+= valueList.size();
                } else
                {
                    skipped += valueList.size();
                    addSkipped+= valueList.size();
                }
                addCount = 0;
                valueList.clear();
            }
            if(deletedObjectList.size()>0){
            skipped+=LinkedAttributesUtil.getFrontLinkaddedSkippedCount(domainId, maskIndex, restoreBackupId, objectGuid, "FRONTLINK_OBJECT_GUID", "BACKLINK_OBJECT_GUID", "BACKLINK_OBJECT_DN", ADDED,deletedObjectList);
            }
            
        } catch (SQLException e1) {
            e1.printStackTrace();
        } catch (QueryConstructionException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeDataSet(dset);
            DBUtil.closeConnection(con);
        }
        restoreResult.put("result", result);
        restoreResult.put("added", added);
        restoreResult.put("removed", removed);
        restoreResult.put("skipped",skipped);
        restoreResult.put("addSkipped",addSkipped);
        restoreResult.put("rmvSkipped",rmvSkipped);
        return restoreResult;
    }

    public static Boolean restoreFrontLink(RecoveryHandler obj, Attribute attrInfo, ArrayList<String> valueList, int controlCode) {
        if(valueList.isEmpty())
        {
            return true;
        }
        Hashtable<String, Object> attributeValue = new Hashtable();
        attributeValue.put(obj.ATTR_NAME, attrInfo.attrName);
        attributeValue.put(obj.DATA_HANDLER_TYPE, (long) 1);
        if (valueList.size() == 1) {
            attributeValue.put(obj.ATTR_VALUE, valueList.get(0));
            attributeValue.put(obj.ATTR_VALUE_COUNT, Long.parseLong(valueList.size() + ""));
        } else {
            attributeValue.put(obj.ATTR_VALUE, valueList);
            attributeValue.put(obj.ATTR_VALUE_COUNT, Long.parseLong(valueList.size() + ""));
        }
        attributeValue.put(obj.DW_CONTROL_CODE, (long) controlCode);
        obj.propList.add(attributeValue);
        Boolean result = obj.recoverObject();
        obj.clearRequiredLists();
        return result;
    }
    
    public static void clearFrontLink(RecoveryHandler obj, Attribute attrInfo) {
        try{
        Hashtable<String, Object> attributeValue = new Hashtable<String, Object>();
        attributeValue.put(obj.ATTR_NAME, attrInfo.attrName);
        attributeValue.put(obj.DATA_HANDLER_TYPE, new Long(1));
        attributeValue.put(obj.ATTR_VALUE, "");
        attributeValue.put(obj.DW_CONTROL_CODE, new Long(1));
        obj.propList.add(attributeValue);
        Boolean result = obj.recoverObject();
        obj.clearRequiredLists();
        }
        catch(Exception e){
                
                }
        
    }
    
    public static void removeDeletedObjectsWithNoHistory(Long domainId, ArrayList<String> memberDNs)
    {
        try
        {
            Iterator<String> it = memberDNs.iterator();
            while (it.hasNext()) {
                String memberDN = it.next();
                if(LdapUtil.isObjectDeleted(memberDN)) {
                    String objectGUID = LdapUtil.getGuidFromDeletedObjectDN(memberDN);
                    SelectQuery selectQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId));
                    selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"));
                    selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "SYNC_STATUS"));
                    Criteria objectGUIDCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"), objectGUID, QueryConstants.EQUAL, false); 
                    selectQuery.setCriteria(objectGUIDCriteria);
                    DataObject dobj = CommonUtil.getPersistence().get(selectQuery);
                    if(!dobj.isEmpty()) {
                        Row row = dobj.getFirstRow(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId);
                        int syncStatus = (Integer) row.get("SYNC_STATUS");
                        if((syncStatus & RMPCommonFlags.HasHistory.maskValue) == 0) {
                            it.remove();
                        }
                    }
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}

//ignoreI18n_end
