/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.backup;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.RowHelper;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.RMPCommonUtil;
import com.manageengine.rmp.constants.ChangeType;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.RMPCommonFlags;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.licensing.EditionType;
import com.manageengine.rmp.licensing.ProductSubscriptionInfo;
import com.manageengine.rmp.common.querygenerator.FiletoDBImporter;
import com.manageengine.rmp.util.BitSetUtil;
import java.sql.Connection;
import java.sql.Types;
import java.util.Iterator;
import java.util.UUID;
import java.util.logging.Level;
import org.json.JSONObject;

/**
 *
 * @author poornima-3055
 */
//ignoreI18n_start
public class BackupSyncUpdater{
    
    public Long domainId, backupId;
    private final BackupImpl backupHook;
    private final Boolean isFreeEdition;
    protected FiletoDBImporter dbImporter;
    
    public BackupSyncUpdater(Long domainId, Long backupId, BackupImpl backupHook) {
        this.domainId = domainId;
        this.backupId = backupId;
        this.backupHook = backupHook;
        this.dbImporter = new FiletoDBImporter();
        dbImporter.backupFileWriterInit(domainId);
        this.isFreeEdition = ProductSubscriptionInfo.subscriptionType == EditionType.Free.ordinal();
        LogWriter.backup.info(String.format("BackupSyncUpdater initialized domainId: %s, backupId: %s, isFreeEdition: %s ", domainId,backupId,isFreeEdition));
    }
    
    public void updateObjectSyncInfo() {
        LogWriter.backup.info("BackupSyncUpdater.updateObjectSyncInfo");
        try{
            
            if(!backupHook.isInitBackup) {
                      
                Column isBackupSet = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+backupHook.domainId, "IS_BACKUP_SET"), RMPCommonFlags.IsBackupSet.maskValue);  //NO I18N
                isBackupSet.setType(Types.INTEGER);
                Column isDeleted = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+backupHook.domainId, "SYNC_STATUS"), RMPCommonFlags.IsDeleted.maskValue);  //NO I18N
                isDeleted.setType(Types.INTEGER);
                Column hasHistory = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+backupHook.domainId, "SYNC_STATUS"), RMPCommonFlags.HasHistory.maskValue);    //NO I18N
                hasHistory.setType(Types.INTEGER);
                Column hasChange = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+backupHook.domainId, "SYNC_STATUS"), RMPCommonFlags.HasChange.maskValue);  //NO I18N
                hasChange.setType(Types.INTEGER);
                Criteria objectHistoryCriteria, objectChangeCriteria, objectDeletedCriteria;
                Criteria objectisBackupSet = new Criteria(isBackupSet, 0, QueryConstants.GREATER_THAN);

                SelectQuery selectionQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO+"_"+backupHook.domainId));   
                Column selectAllColumns = Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+backupHook.domainId, "*");
                selectionQuery.addSelectColumn(selectAllColumns); 
                backupHook.threadBackupTracker = new BackupTracker();
                
                //If before product downgraded to free edition, any OU's which were deselected previously are selected and objects in that OU have Changes
                //and if backup initiated by scheduelr after downgraded to free edition, then avoiding those objects including in the backup.
                if(!isFreeEdition) {
                    
                    objectHistoryCriteria = new Criteria(hasHistory, 0, QueryConstants.EQUAL);  // object has no previous version(s) of backup
                    objectChangeCriteria = new Criteria(hasChange, 0, QueryConstants.GREATER_THAN); //object has change
                    objectDeletedCriteria = new Criteria(isDeleted, 0, QueryConstants.EQUAL);      //object not deleted
                    selectionQuery.removeSelectColumn(selectAllColumns); 
                    JSONObject data = getMinMaxUniqueId(selectionQuery, domainId);
                    selectionQuery.addSelectColumn(selectAllColumns); 
                    
                    if(data != null  && data.has("MINIMUM_ID") && data.has("MAXIMUM_ID"))
                    {
                        int minId = data.getInt("MINIMUM_ID");
                        int maxId = data.getInt("MAXIMUM_ID");
                        float ceil =(float) (maxId - minId + 1) / (float)RMPCommonUtil.MAX_BATCH_COMMIT_COUNT;
                        int loopCount = ((int) Math.ceil(ceil)) + 1;
                        int startCount, endCount;
                        if(loopCount > 0)
                        {
                            for(int i =0 ; i < loopCount ; i++)
                            {
                                startCount =  RMPCommonUtil.MAX_BATCH_COMMIT_COUNT * i + minId;
                                endCount = (RMPCommonUtil.MAX_BATCH_COMMIT_COUNT * (i+1)) + minId;
                                Criteria selectionCriteira = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"), startCount, QueryConstants.GREATER_EQUAL);
                                selectionCriteira = selectionCriteira .and(new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"), endCount, QueryConstants.LESS_THAN));
                                selectionQuery.setCriteria(selectionCriteira .and(objectisBackupSet) .and(objectChangeCriteria) .and(objectHistoryCriteria) .and(objectDeletedCriteria));
                                updateAddedObjects(selectionQuery);
                            }
                        }
                    }
                    
                    objectHistoryCriteria = new Criteria(hasHistory, 0, QueryConstants.GREATER_THAN);  // object has previous version(s) of backup 
                    objectChangeCriteria = new Criteria(hasChange, 0, QueryConstants.GREATER_THAN); //object has change
                    objectDeletedCriteria = new Criteria(isDeleted, 0, QueryConstants.EQUAL);      //object not deleted
                    selectionQuery.removeSelectColumn(selectAllColumns); 
                    selectionQuery.setCriteria((Criteria) null);
                    data = getMinMaxUniqueId(selectionQuery, domainId);
                    selectionQuery.addSelectColumn(selectAllColumns); 
                    
                    if(data != null  && data.has("MINIMUM_ID") && data.has("MAXIMUM_ID"))
                    {
                        int minId = data.getInt("MINIMUM_ID");
                        int maxId = data.getInt("MAXIMUM_ID");
                        float ceil =(float) (maxId - minId + 1) / (float)RMPCommonUtil.MAX_BATCH_COMMIT_COUNT;
                        int loopCount = ((int) Math.ceil(ceil)) + 1;
                        int startCount, endCount;
                        if(loopCount > 0)
                        {
                            for(int i =0 ; i < loopCount ; i++)
                            {
                                startCount =  RMPCommonUtil.MAX_BATCH_COMMIT_COUNT * i + minId;
                                endCount = (RMPCommonUtil.MAX_BATCH_COMMIT_COUNT * (i+1)) + minId;
                                Criteria selectionCriteira = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"), startCount, QueryConstants.GREATER_EQUAL);
                                selectionCriteira = selectionCriteira .and(new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"), endCount, QueryConstants.LESS_THAN));
                                selectionQuery.setCriteria(selectionCriteira .and(objectisBackupSet) .and(objectChangeCriteria) .and(objectHistoryCriteria) .and(objectDeletedCriteria));
                                updateReAddedObjects(selectionQuery);
                            }
                        }                       
                    }
                }
                
                objectHistoryCriteria = new Criteria(hasHistory, 0, QueryConstants.EQUAL);  // object has no previous version(s) of backup 
                objectChangeCriteria = new Criteria(hasChange, 0, QueryConstants.GREATER_THAN); //object has change
                objectDeletedCriteria = new Criteria(isDeleted, 0, QueryConstants.GREATER_THAN);      //object deleted
                selectionQuery.removeSelectColumn(selectAllColumns); 
                selectionQuery.setCriteria((Criteria) null);
                JSONObject data = getMinMaxUniqueId(selectionQuery, domainId);
                selectionQuery.addSelectColumn(selectAllColumns); 
                
                if(data != null  && data.has("MINIMUM_ID") && data.has("MAXIMUM_ID"))
                {
                    int minId = data.getInt("MINIMUM_ID");
                    int maxId = data.getInt("MAXIMUM_ID");
                    float ceil =(float) (maxId - minId + 1) / (float)RMPCommonUtil.MAX_BATCH_COMMIT_COUNT;
                    int loopCount = ((int) Math.ceil(ceil)) + 1;
                    int startCount, endCount;
                    if(loopCount > 0)
                    {
                        for(int i =0 ; i < loopCount ; i++)
                        {
                            startCount =  RMPCommonUtil.MAX_BATCH_COMMIT_COUNT * i + minId;
                            endCount = (RMPCommonUtil.MAX_BATCH_COMMIT_COUNT * (i+1)) + minId;
                            Criteria selectionCriteira = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"), startCount, QueryConstants.GREATER_EQUAL);
                            selectionCriteira = selectionCriteira .and(new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"), endCount, QueryConstants.LESS_THAN));
                            selectionQuery.setCriteria(selectionCriteira .and(objectDeletedCriteria) .and(objectisBackupSet) .and(objectHistoryCriteria) .and(objectChangeCriteria));
                            updateDeletedNoHistoryObjects(selectionQuery);
                        }
                    }  
                }

                objectHistoryCriteria = new Criteria(hasHistory, 0, QueryConstants.GREATER_THAN);  // object has no previous version(s) of backup 
                objectChangeCriteria = new Criteria(hasChange, 0, QueryConstants.GREATER_THAN); //object has change
                objectDeletedCriteria = new Criteria(isDeleted, 0, QueryConstants.GREATER_THAN);      //object deleted
                selectionQuery.removeSelectColumn(selectAllColumns); 
                selectionQuery.setCriteria((Criteria) null);
                data = getMinMaxUniqueId(selectionQuery, domainId);
                selectionQuery.addSelectColumn(selectAllColumns); 
                
                if(data != null  && data.has("MINIMUM_ID") && data.has("MAXIMUM_ID"))
                {
                    int minId = data.getInt("MINIMUM_ID");
                    int maxId = data.getInt("MAXIMUM_ID");
                    float ceil =(float) (maxId - minId + 1) / (float)RMPCommonUtil.MAX_BATCH_COMMIT_COUNT;
                    int loopCount = ((int) Math.ceil(ceil)) + 1;
                    int startCount, endCount;
                    if(loopCount > 0)
                    {
                        for(int i =0 ; i < loopCount ; i++)
                        {
                            startCount =  RMPCommonUtil.MAX_BATCH_COMMIT_COUNT * i + minId;
                            endCount = (RMPCommonUtil.MAX_BATCH_COMMIT_COUNT * (i+1)) + minId;
                            Criteria selectionCriteira = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"), startCount, QueryConstants.GREATER_EQUAL);
                            selectionCriteira = selectionCriteira .and(new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"), endCount, QueryConstants.LESS_THAN));
                            selectionQuery.setCriteria(selectionCriteira .and(objectDeletedCriteria) .and(objectisBackupSet) .and(objectHistoryCriteria) .and(objectChangeCriteria));
                            updateDeletedHistoryObjects(selectionQuery);
                        }
                    }  
                }
                
                for(int i = 1; i <= ObjectType.values().length; i++) {
                    backupHook.threadBackupTracker.updateUsageDetails(backupHook, ObjectType.parse(i), true);
                }
            }
        }catch(Exception e){  
            LogWriter.backup.log(Level.SEVERE, "Error in BackupSyncUpdater.updateCurrentObjectVerInfo :{0}", e);
            e.printStackTrace();
        }
    }
    
    public BackupObject getBackupObjectData(Row row){
        try{
            RowHelper rowhelper =  new RowHelper(row);
            BackupObject backupObject = BackupUtil.getBackupObjectInfo(rowhelper, domainId);
            backupObject.changeId = backupHook.changeId++;    
            backupObject.isObjNewlySelected = true;
            backupObject.backupId = backupId;
            if(backupObject.data.has("trackingData")){
                backupObject.trackingData = backupObject.data.getInt("trackingData");
                backupObject.data.remove("trackingData");
            }
            return backupObject;
        }catch(Exception e){
            LogWriter.backup.severe("getBackupObjectData, BackupObject formation error:"+e);
            e.printStackTrace();
        }
        return null;
    }
    
    private Boolean commitObjectInfo(BackupObject backupObject, int isMetaVerInfo) {
        try {
            if(isMetaVerInfo != 0){
                dbImporter.commitObjectMetaVersionInfo(backupObject);
            }
            String changes = BitSetUtil.bitSetToHexadecimalString(backupObject.changeMask);
            backupObject.data.put("ct", backupObject.changeTyp);//Storing changeType in changeData.
            Row row = new Row(TableName.RMP_OBJ_VER_INFO+"_"+backupHook.domainId);
            DataAccess.generateValues(row);
            dbImporter.commitObjectVersion(row.get("UNIQUE_ID").toString(), backupObject, changes);
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupSyncUpdater.commitObjectVersion " + e);
        }
        return false;
    }

    private Boolean updateAttributeInfo(UUID objId, Integer changeId, Integer attribId) {
        try {
            Row row = new Row(TableName.RMP_ATTRIBUTES_BACKUP_INFO+"_"+backupHook.domainId);
            DataAccess.generateValues(row);
            return dbImporter.updateAttributeInfo(row.get("UNIQUE_ID").toString(), backupId, objId, changeId, attribId);
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupSyncUpdater.updateAttributeInfo " + e);
            return false;
        }
    }

    public Boolean updateAttributeInfo(BackupObject backupObject) {
        for (Integer attribId = backupObject.changeMask.nextSetBit(0); attribId != -1; attribId = backupObject.changeMask.nextSetBit(attribId + 1)) {
            updateAttributeInfo(backupObject.objId, backupObject.changeId, attribId);
        }
        return true;
    }
        
    public void updateBackupTracker(BackupObject backupObject){
        backupHook.backupTracker.track(backupObject, false, backupHook.isInitBackup, isFreeEdition);
        backupHook.threadBackupTracker.track(backupObject, false, backupHook.isInitBackup, isFreeEdition);
    }
    
    public Boolean dumpObjectVersionData() {
        //metaVersionDataTableDumper.dumpDataBase();
        try {
            dbImporter.importBackupDataToDB();
            return true;
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupSyncUpdater.dumpObjectVersionData " + e);
            return false;
        }
    }
    
    public void updateAddedObjects(SelectQuery query)
    {
        try
        {
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if(!dobj.isEmpty())
            {
                Iterator iterator = dobj.getRows(TableName.RMP_OBJ_CURRENT_INFO+"_"+backupHook.domainId);
                while(iterator.hasNext())
                {
                    Row row = (Row) iterator.next();
                    BackupObject backupObject = getBackupObjectData(row);
                    backupObject.changeTyp = ChangeType.Added.maskValue;
                    backupObject.trackingData = 1;
                    if(backupObject.data.has("changeType")) 
                    {
                        backupObject.linkId = BackupUtil.getNewLinkId(domainId);
                        backupObject.data.remove("changeType");    //NO I18N
                        row.set("CHANGE_DATA", backupObject.data); //NO I18N
                    }
                    commitObjectInfo(backupObject, backupObject.linkId.compareTo((Long)row.get("LINK_ID")));
                    updateAttributeInfo(backupObject);
                    row.set("IS_BACKUP_SET", BackupUtil.getIsBackupSet(backupObject));
                    row.set("LINK_ID", backupObject.linkId);       //NO I18N
                    row.set("SYNC_STATUS", (Integer)row.get("SYNC_STATUS") - RMPCommonFlags.HasChange.maskValue + RMPCommonFlags.HasHistory.maskValue); //NO I18N
                    dobj.updateRow(row);
                    updateBackupTracker(backupObject);
                }
                dumpObjectVersionData();
                CommonUtil.getPersistence().update(dobj);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public void updateReAddedObjects(SelectQuery query)
    {
        try
        {
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if(!dobj.isEmpty())
            {
                Iterator iterator = dobj.getRows(TableName.RMP_OBJ_CURRENT_INFO+"_"+backupHook.domainId);
                while(iterator.hasNext()) 
                {
                    Row row = (Row) iterator.next();
                    BackupObject backupObject = getBackupObjectData(row);
                    backupObject.trackingData = 0;
                    backupObject.changeTyp = ChangeType.ReAdded.maskValue;
                    backupObject.linkId = BackupUtil.getNewLinkId(domainId);
                    commitObjectInfo(backupObject, backupObject.linkId.compareTo((Long)row.get("LINK_ID")));
                    updateAttributeInfo(backupObject);
                    row.set("IS_BACKUP_SET", BackupUtil.getIsBackupSet(backupObject));
                    row.set("SYNC_STATUS", (Integer)row.get("SYNC_STATUS") - RMPCommonFlags.HasChange.maskValue); //NO I18N   
                    row.set("LINK_ID", backupObject.linkId);   //NO I18N
                    dobj.updateRow(row);
                    updateBackupTracker(backupObject);
                }
                dumpObjectVersionData();
                CommonUtil.getPersistence().update(dobj);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public void updateDeletedNoHistoryObjects(SelectQuery query)
    {
        try
        {
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if(!dobj.isEmpty())
            {
                Iterator iterator = dobj.getRows(TableName.RMP_OBJ_CURRENT_INFO+"_"+backupHook.domainId);
                while(iterator.hasNext())
                {
                    Row row = (Row) iterator.next();
                    BackupObject backupObject = getBackupObjectData(row);
                    backupObject.changeTyp = ChangeType.Deleted.maskValue;
                    backupObject.trackingData = 0;
                    if(backupObject.data.has("changeType")) 
                    {
                        backupObject.linkId = BackupUtil.getNewLinkId(domainId);
                        backupObject.data.remove("changeType");    //NO I18N
                        commitObjectInfo(backupObject, backupObject.linkId.compareTo((Long)row.get("LINK_ID")));
                        row.set("CHANGE_DATA", backupObject.data); //NO I18N
                    }
                    row.set("IS_BACKUP_SET", BackupUtil.getIsBackupSet(backupObject));
                    row.set("LINK_ID", backupObject.linkId);   //NO I18N
                    row.set("SYNC_STATUS", (Integer)row.get("SYNC_STATUS") - RMPCommonFlags.HasChange.maskValue); //NO I18N 
                    dobj.updateRow(row);
                    updateBackupTracker(backupObject);
                }
                dumpObjectVersionData();
                CommonUtil.getPersistence().update(dobj);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public void updateDeletedHistoryObjects(SelectQuery query)
    {
        try
        {
            DataObject dobj = CommonUtil.getPersistence().get(query);
            if(!dobj.isEmpty())
            {
                Iterator iterator = dobj.getRows(TableName.RMP_OBJ_CURRENT_INFO+"_"+backupHook.domainId);
                while(iterator.hasNext()) 
                {
                    Row row = (Row) iterator.next();
                    BackupObject backupObject = getBackupObjectData(row);
                    backupObject.trackingData = -1;
                    backupObject.changeTyp = ChangeType.Deleted.maskValue;
                    backupObject.linkId = BackupUtil.getNewLinkId(domainId);
                    commitObjectInfo(backupObject, backupObject.linkId.compareTo((Long)row.get("LINK_ID")));
                    updateAttributeInfo(backupObject);
                    row.set("IS_BACKUP_SET", BackupUtil.getIsBackupSet(backupObject));
                    row.set("SYNC_STATUS", (Integer)row.get("SYNC_STATUS") - RMPCommonFlags.HasChange.maskValue); //NO I18N   
                    row.set("LINK_ID", backupObject.linkId);   //NO I18N
                    dobj.updateRow(row);
                    updateBackupTracker(backupObject);
                }
                dumpObjectVersionData();
                CommonUtil.getPersistence().update(dobj);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public static JSONObject getMinMaxUniqueId(SelectQuery query, Long domainId)
    {
        Column minCol = Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID").minimum();
        minCol.setColumnAlias("MINIMUM_ID");
        query.addSelectColumn(minCol);
        Column maxCol = Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID").maximum();
        maxCol.setColumnAlias("MAXIMUM_ID");
        query.addSelectColumn(maxCol);
        JSONObject object = null;
        Connection connection = null;
        DataSet dset = null;
        try
        {
            RelationalAPI relAPI = RelationalAPI.getInstance();
            connection = relAPI.getConnection();
            dset = relAPI.executeQuery(query, connection);
            while(dset.next())
            {
                Long minId = dset.getAsLong("MINIMUM_ID");
                Long maxId = dset.getAsLong("MAXIMUM_ID");
                object = new JSONObject();
                object.put("MINIMUM_ID", minId.intValue());
                object.put("MAXIMUM_ID", maxId.intValue());
            }
        } 
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally {
            DBUtil.closeDataSetAndConnection(dset, connection);
        }
        query.removeSelectColumn(minCol);
        query.removeSelectColumn(maxCol);
        return object;
    }
}
//ignoreI18n_end
