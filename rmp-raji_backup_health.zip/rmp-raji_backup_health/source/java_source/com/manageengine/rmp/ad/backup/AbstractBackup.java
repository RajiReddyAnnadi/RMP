/*
 * T
 o change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.backup;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.ad.bitlocker.BitLockerManager;
import com.manageengine.rmp.ad.gpo.manager.*;
import com.manageengine.rmp.ad.rangedattributes.*;
import com.manageengine.rmp.clientSync.RunningOperationSync;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.*;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.dataobjects.LdapAttribute;
import com.manageengine.rmp.dataobjects.OperationInfo;
import com.manageengine.rmp.scheduler.BackupScheduler;
import com.manageengine.rmp.settings.RecoverySettings;
import com.manageengine.rmp.settings.customattributes.CustomAttributesBackup;
import com.manageengine.rmp.settings.dataobjects.RecoverySettingsObject;
import com.manageengine.rmp.util.ADObjectsUtil;
import com.manageengine.rmp.util.Attribute;
import com.manageengine.rmp.util.LdapUtil;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.*;
import java.util.logging.Level;
import java.util.regex.Pattern;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public abstract class AbstractBackup {

    public int changeId;
    public ObjectType objectType;
    protected Boolean isAllOusConfiguredForBackup;
    public BackupTracker backupTracker;
    protected HashSet<UUID> processedObjInfo;
    protected HashSet<UUID> objectsPresentInDC;
    protected HashMap<String, OuConfig> ouCache;
    public Long domainId;
    public String domainName;
    public boolean isRecyleBinEnabled;
    public BackupUpdater backupUpdater;
    public BackupSyncUpdater backupSyncUpdater;
    public BackupType backupType;
    public Boolean isInitBackup;
    public Boolean isFullSync;
    public OperationInfo backupInfo;
    public OuUpdater ouUpdater;
    public RangedAttrObject groupObject;
    public FrontLinkAttrManager forwardLinkManager;
    public BackLinkAttrManager backLinkManager;
    public DnsManager dnsManager;
    public BitLockerManager bitLocker;
    public GpoBackup gpoBackup;
    public String orgObjectType;
    public RecoverySettingsObject recoverySettings;
    public Boolean isChanged;
    public CustomAttributesBackup customAttribute;
    public BackupImpl backupImpl;
    public DataObject lastBackedupDO;
    public String defaultNamingContext;
    public ObjectBatchDump objectFinalUpdation;
    public BackupTracker threadBackupTracker;
    public boolean isOUSelectionChanged;
    public boolean isFinalUpdate;
    protected int duplicateCount;
    public GPFrontLinkAttrManager gpFrontLinkManager;
    public GPBackLinkAttrManager gpBackLinkManager;
    public PrimaryGroupManager primaryGroupManager;
    public boolean trackDisabledObjects;
    public boolean isSiteSelected;
    public OuConfig ouConfig = null;

    protected void construct(Long domainId, BackupType backupType, String initiator, long backupId, String domainName, CustomAttributesBackup customAttribute, BackupImpl backupImpl) {
        this.domainId = domainId;
        this.domainName = domainName;
        this.isRecyleBinEnabled = LdapUtil.isRecycleBinEnabled(domainName);
        this.backupType = backupType;
        this.backupImpl = backupImpl;
        this.customAttribute = customAttribute;
        this.backupInfo = new OperationInfo(domainId, OperationType.Backup, initiator, StatusId.InitiatingBackup.value, backupId);//ToDo: initialize this outside of this class
        backupUpdater = new BackupUpdater(domainId, backupInfo, backupImpl);
        backupSyncUpdater = new BackupSyncUpdater(domainId, backupInfo.operationId, backupImpl);
        //backupCase.put(BackupCase.OuUpdate, temp);
        if (backupType == BackupType.Sync || backupType == BackupType.InitBackup) {
            backupUpdater.updateBackupStartInfo(backupInfo);
            RunningOperationSync.add(backupInfo);
        }
        backupTracker = new BackupTracker();
        isAllOusConfiguredForBackup = true;//ToDo: move this flag to backupSettings. 
        ouUpdater = new OuUpdater(domainId, backupType, domainName);
        dnsManager = new DnsManager(domainId);
        gpoBackup = new GpoBackup(backupImpl, domainId, backupId);
        this.isInitBackup = BackupUtil.getBackupStat(domainId) == null;
        BackupScheduler.updateScheduleStat(domainId, isInitBackup);
        recoverySettings = RecoverySettings.getRecoverySettings(domainId);
        ouCache = null;
        this.isChanged = false;
        duplicateCount = 0;
        isSiteSelected= false;
    }

    protected void setPreviousBackupValues(DataObject lastBackedupDO) {
        this.lastBackedupDO = lastBackedupDO;
    }

    public void backupObjectNotInCache(Properties prop) {
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId));
            Criteria crit = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_GUID"), BackupUtil.getString(prop, "objectGUID"), QueryConstants.EQUAL, false);
            query.setCriteria(crit);
            query.addSelectColumn(Column.getColumn(null, "*"));
            DataObject temp = CommonUtil.getPersistence().get(query);
            if (!temp.isEmpty()) {
                Row row = temp.getFirstRow(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId);
                lastBackedupDO.addRow(row);
            }
        } catch (Exception e) {
            
        } finally {
            backupObject(prop);
        }
    }

    public void backupObject(Properties prop) {
        try {
            if(isRecyleBinEnabled && (prop.containsKey("isRecycled") && BackupUtil.getBoolean(prop, "isRecycled") != null && BackupUtil.getBoolean(prop, "isRecycled"))) {
                return;
            }
            if (backupType == BackupType.OuSync) {
                //ToDo: for initial ouSync only retrieve the required 5 attributes of the object
                ouUpdater.initialOuSync(prop);
                return;
            }
            if (!isAllOusConfiguredForBackup)
            {
                /* ToDo:
                 * For objects other than Ou get the OuConfig of their parent container. If the parent container configured for backup then contiue else return
                 * For ou object get that ouConfig. If this OU is configured for backup then contiue else return
                 */
                ouConfig = new OuConfig();
            }
            if (prop.containsKey("objectType")) 
            {
                if ("Other".equalsIgnoreCase((String) prop.get("objectType"))) 
                {
                    return;
                } 
                else 
                {
                    this.objectType = ObjectType.parse((String) prop.get("objectType"));
                    this.orgObjectType = (String) prop.get("objectType");
                }
            }
            if (objectType == ObjectType.GroupPolicy && BackupUtil.getString(prop, "distinguishedName").contains("\\0ACNF:")){
                return;
            }
            if (objectType == ObjectType.Other && backupType == BackupType.InitBackup) 
            {
                if (prop.containsKey("isDeleted") && BackupUtil.getBoolean(prop, "isDeleted") != null && BackupUtil.getBoolean(prop, "isDeleted"))
                {
                    return;
                } 
                else if (prop.size() <= 2) 
                {
                    return;
                }
            } 
            else if (objectType == ObjectType.DnsZone) 
            {
                if (!dnsManager.deletedZonesHandling(prop, backupType)) 
                {
                    return;
                }
            } 
            else if (objectType == objectType.DnsNode) 
            {
                if (!dnsManager.checkDnsNodeIsBackup(prop, backupType)) 
                {
                    return;
                }
            }
            BackupObject backupObject = new BackupObject(objectType, orgObjectType, domainId, backupInfo.operationId, changeId, prop);
            if(isFullSync && backupObject.isDeleted && objectType == ObjectType.OU && backupObject.distinguishedName.equals("CN=Deleted Objects,"+backupImpl.defaultNamingContext))
            {
                LogWriter.backup.severe("obj not backedup : " + backupObject.distinguishedName);
                return;
            }
            //check for both objects (deleted and not deleted) parentDN - stores lastKnownparent for deleetd objects and parent ou Dn for non deleted objects
            if (objectType == ObjectType.OU && LdapUtil.isChildOfPolicyContainer(backupObject.ouNam)) 
            {
                LogWriter.backup.severe("Policy obj not backedup : " + backupObject.distinguishedName);
                return;
            }

            BackupObject lastBackupData;
            if (isInitBackup && objectType != ObjectType.Other && !prop.containsKey("objectType")) 
            {
                lastBackupData = new BackupObject();
                lastBackupData.objId = BackupUtil.emptyGuid;//toDo: remove this 
            } 
            else 
            {
                lastBackupData = BackupUtil.getLastBackedupObjectInfo(domainId, backupObject.objId, lastBackedupDO);
                backupObject.isDisabled = lastBackupData.isDisabled;
            }
            if((prop.containsKey("gPLink") || (backupObject.isDeleted && lastBackupData.linkId != null ))&& !prop.containsKey("notInADSync"))
            {
                if(orgObjectType.endsWith("GPLinksAttr"))
                {
                    GpoLinksUtil.updateGpoLinksCache(backupObject, lastBackupData, backupImpl, prop);
                }
                prop.remove("gPLink");
            }
            if(prop.containsKey("notInADSync"))
            {
                prop.remove("notInADSync");
            }
            if((objectType == ObjectType.Site || orgObjectType.equalsIgnoreCase("siteGPLinksAttr")) && backupObject.isDeleted && lastBackupData.linkId == null) 
            {
                LogWriter.backup.info(String.format("Deleted sites not backed up %s", backupObject.distinguishedName));
                return;
            }

            if((isInitBackup || isFullSync) && (objectType != ObjectType.Other && !prop.containsKey("objectType")))
            {
                if (processedObjInfo.contains(backupObject.objId) && objectType != ObjectType.GroupPolicy) 
                {
                    LogWriter.backup.info(String.format("Object reappeared1 - objName:%s objType:%s objId:%s", backupObject.objNam, objectType, backupObject.objId));
                    return;
                } 
                else if(!customAttribute.isCustomAttrBackingUp.contains(domainId))
                {
                    processedObjInfo.add(backupObject.objId);
                }
            }
            if(lastBackupData.isNotPresentInDC)
            {
                objectsPresentInDC.add(lastBackupData.objId);
            }
            
            if (prop.containsKey("objectType")) 
            {
                if (lastBackupData.objId == null)
                {
                    return;
                }
                if(lastBackupData.isBackupSet == false) 
                {
                    boolean isRangedAttributeBackedup=false;
                    for (Map.Entry<Object, ?> property : prop.entrySet()) 
                    {
                        String key = property.getKey().toString();
                        if(!key.equalsIgnoreCase("distinguishedName"))
                        {
                            isRangedAttributeBackedup |= backupAttribute(backupObject, lastBackupData, prop, property,true);
                        }
                    }
                    if(isRangedAttributeBackedup)
                    {
                        lastBackupData.cnt++;
                        lastBackupData.hasChange = true;
                        backupUpdater.updateObjectCurrentInfo(lastBackupData);
                    }
                    return;
                }
                prop.remove("objectType");
            }

            if (objectType == ObjectType.GroupPolicy) 
            {
                boolean toStopBackup = gpoBackup.gpoBackupHandler(backupObject, lastBackupData, prop);
                if (toStopBackup) 
                {
                    String gpoId = GpoUtil.getGpoId(backupObject.distinguishedName);
                    GpoUtil.updateFailedGPO(backupObject.domainId, gpoId, backupObject.objNam, backupObject.distinguishedName, null, 0L);
                    return;
                }
            } 
            else if(backupObjectCheck(lastBackupData, backupObject)) 
            {
                //case: object backed up for first time or ouName changed from last backup OR deleted objects found deleted in initial backup and it is recycled now(we need to check wheter the destination ou is under tracking, but if backup settings was changed after initial backup then no need of checking this one)
                UUID ouId = null;
                //deleted policies 
                if(backupObject.objTyp == ObjectType.OU && lastBackupData.linkId != null && lastBackupData.ouId == null) 
                {
                    LogWriter.backup.info(String.format("Object parent guid is null - objName:%s objType:%s objId:%s", backupObject.objNam, objectType, backupObject.objId));
                    return;
                }
                if(!isInitBackup && lastBackupData.linkId != null && !lastBackupData.ouId.equals(backupObject.ouId) && lastBackupData.ouNam.equals(backupObject.ouNam) && (!backupObject.isDeleted || lastBackupData.changeTyp != ChangeType.Deleted.maskValue))
                {
                    ouId = backupObject.ouId;
                }
                ouConfig = getOuConfig(backupObject, lastBackupData);
                if (ouConfig == null) 
                {
                    LogWriter.backup.log(Level.INFO, "Not backedup 1 : {0}", backupObject.distinguishedName);
                    return;
                }
                //OU Deselected from backupSettings but the parentOU not deselected, avoid the case to set isBackupSet to false when OU is deleted
                //If not then instead of new entry in rmpobjmetaverinfo with changeType as Deleted, Except changeTYpe other fields will be updated in rmpobjetaverinfo
                if(!isInitBackup && lastBackupData.isBackupSet && backupObject.objTyp == ObjectType.OU && (backupObject.isDeleted || lastBackupData.changeTyp == ChangeType.Deleted.maskValue))
                {
                    backupObject.isBackupSet = lastBackupData.isBackupSet;
                }
                else
                {
                     backupObject.isBackupSet = (lastBackupData.isDisabled && !trackDisabledObjects) ? false : ouConfig.toBackup;
                }
                if (ouId != null) 
                {
                    backupObject.ouId = ouId;
                }
            } 
            else if(objectType != ObjectType.Other)
            {
                backupObject.isBackupSet = lastBackupData.isBackupSet;
                if (lastBackupData.ouId != null) 
                {
                    backupObject.ouId = lastBackupData.ouId;
                }
            }
            if(isInitBackup || lastBackupData.linkId == null)
            {
               backupObject.isObjNewlySelected = lastBackupData.isObjNewlySelected = true;
            } 
            else
            {
               backupObject.isObjNewlySelected = lastBackupData.isObjNewlySelected;
            }
            if (backupObject.objTyp == ObjectType.DnsNode) 
            {
                if (prop.containsKey("dNSTombstoned")) 
                {
                    if (BackupUtil.getBoolean(prop, "dNSTombstoned") != null) 
                    {
                        if (BackupUtil.getBoolean(prop, "dNSTombstoned")) 
                        {
                            if (lastBackupData.ouNam == null) 
                            {
                                LogWriter.backup.log(Level.SEVERE, "Not backedup : dNSTombstoned has set to true props: {0}", prop);
                                return;
                            }
                            backupObject.changeTyp = ChangeType.Deleted.maskValue;
                        }
                    }
                }
                if (LdapUtil.isObjectDeleted(BackupUtil.getString(prop, "distinguishedName"))) 
                {
                    if (lastBackupData.ouNam == null) 
                    {
                        LogWriter.backup.log(Level.SEVERE, "Not backedup : dnsNode deleted and does not have parent name props: {0}", prop);
                        return;
                    }
                }
            }
            isChanged = false;
            for (Map.Entry<Object, ?> property : prop.entrySet()) {
                boolean isBackedUp = backupAttribute(backupObject, lastBackupData, prop, property,false);
                isChanged |= isBackedUp;//For GPO; overwrite error; isChanged value wrong.
            }
            if(isChanged && backupObject.isDeleted)
            {
                    updateOldValueOfCurrrentInfo(backupObject.changeMask, lastBackupData.data);
                    updateOldValueOfCurrrentInfo(backupObject.changeMask, lastBackupData.linksData);               
            } 
            if(backupObject.objNam == null) 
            {
                try 
                {
                    if(lastBackupData.objNam != null) 
                    {
                        backupObject.objNam = lastBackupData.objNam;
                    } 
                    else 
                    {
                        LogWriter.backup.log(Level.INFO, "BackupObject name is null props: {0}", prop);
                        backupObject.objNam = LdapUtil.getCommonNameFromDeletedObjectDN(backupObject.distinguishedName);
                    }
                } 
                catch(Exception e) 
                {
                    LogWriter.backup.log(Level.INFO, "Exception while assigning name from distinguishedName excep - {0}", e);
                    return; 
                }   
            }
            if(backupType != BackupType.InitBackup && !backupObject.isBackupSet)
            {
                backupObject.linkId = lastBackupData.linkId;
            }
            if ((isChanged || backupObject.isDeleted || (lastBackupData.linkId != null && !backupObject.isDeleted && lastBackupData.changeTyp != ChangeType.Deleted.maskValue && backupObject.ouId != null && !backupObject.ouId.equals(lastBackupData.ouId) && backupObject.ouNam != null && backupObject.ouNam.equals(lastBackupData.ouNam)))
                        && backupType != BackupType.OuSync && backupObject.objTyp != ObjectType.Other) 
            {
                if (!(backupObject.isDeleted && lastBackupData.changeTyp == ChangeType.Deleted.maskValue)) 
                {
                    backupUpdater.commit(backupObject, lastBackupData);
                    changeId++;
                } 
                else 
                {
                    BackupUtil.updateDeleteObjectState(domainId, backupObject.objId.toString(), true, null);
                }
            }
            if (backupObject.objTyp == objectType.DnsNode && isChanged) 
            {
                dnsManager.updateNodeTable(backupInfo.operationId, backupObject, backupUpdater);
            }
            if (backupObject.objTyp == objectType.DnsZone) 
            {
                dnsManager.addtoOUTable(ouUpdater, backupObject);
            }
            if (objectType == ObjectType.OU) 
            {
                //ToDo: Skip if it is come under GroupPolicyContainer
                OuConfig newOuConfig = ouUpdater.update(backupObject, ouConfig);    //ToDo: if the ou has child, update child dn also in rmpouinfo
                if(newOuConfig!=null && ouCache!=null)
                {
                    ouCache.put(newOuConfig.canonicalName, newOuConfig);
                }
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
            LogWriter.backup.severe(String.format("AbstractBackup.addRows prop:%s \nexcep:%s \nstack:", JSONObjectUtil.toJsonString(prop), e, LogWriter.getStackTrace(e)));
        }
    }
    
    private Boolean backupObjectCheck(BackupObject lastBackupData, BackupObject backupObject) 
    {
        //case: object backed up for first time or ouName changed from last backup OR deleted objects found deleted in initial backup and it is recycled now(we need to check wheter the destination ou is under tracking, but if backup settings was changed after initial backup then no need of checking this one)
        if((lastBackupData.linkId == null 
            || (backupObject.objTyp == ObjectType.OU && !orgObjectType.equalsIgnoreCase("rangedAttr"))
            || orgObjectType.equalsIgnoreCase("ouGPLinksAttr")
            || backupObject.objTyp == ObjectType.Site
            || orgObjectType.equalsIgnoreCase("siteGPLinksAttr")
            || !backupObject.ouNam.equals(lastBackupData.ouNam)
            || (lastBackupData.changeTyp == ChangeType.Deleted.maskValue 
                    && !lastBackupData.hasHistory 
                    && !lastBackupData.isBackupSet
                    && !orgObjectType.equalsIgnoreCase("rangedAttr")
                )
            || ((!backupObject.isDeleted && lastBackupData.changeTyp != ChangeType.Deleted.maskValue) 
                    && backupObject.ouId != null 
                    && !backupObject.ouId.equals(lastBackupData.ouId) 
                    && backupObject.ouNam != null 
                    && backupObject.ouNam.equals(lastBackupData.ouNam) 
                )
            )
        && (objectType!=ObjectType.Other || backupObject.ouId==null)) 
        { //for bitlocker
            return true;
        }
        return false;
    }

    public Boolean backupAttribute(BackupObject backupObject, BackupObject lastBackupData, Properties prop, Map.Entry<Object, ?> property,boolean isSpecialBackup) {
        boolean toBackup = true;
        try
        {
            Attribute attribInfo = new Attribute(objectType.id.intValue(), (String) property.getKey());
            if (attribInfo.attributeMaskIndex != null) //&& !propertyValues.isEmpty()
            {    
                Object propertyValue = null;
                if (attribInfo.specialCaseonBackup) 
                {
                   /* if(attribInfo.attributeMaskIndex>=0){
                        backupObject.syncChangeMask.set(attribInfo.attributeMaskIndex);
                    }*/
                    toBackup = BackupSpecial.handler.get(attribInfo.attributeMaskIndex).invoke(prop, backupObject, lastBackupData, backupImpl);
                   if(attribInfo.attributeMaskIndex==LdapAttribute.distinguishedName.ldapAttributeId && !toBackup && !isSpecialBackup && prop!=null && prop.containsKey("isDeleted") && lastBackupData.linkId!=null && lastBackupData.objTyp.maskValue!=0 && (orgObjectType.equals("user")||orgObjectType.equals("computer")||orgObjectType.equals("contact")||orgObjectType.equals("group"))){
                       try{
                            if(lastBackupData.data.has( RmpConstants.BACKUP_VALUE_PREFIX + attribInfo.attributeMaskIndex)){
                                Object oldValue = JSONObjectUtil.getValue(lastBackupData.data,  RmpConstants.BACKUP_VALUE_PREFIX + attribInfo.attributeMaskIndex);
                                lastBackupData.data.put(RmpConstants.OLD_VALUE_PREFIX + attribInfo.attributeMaskIndex, oldValue);   

                                 UpdateQuery updQry = new UpdateQueryImpl(TableName.RMP_OBJ_CURRENT_INFO+"_"+lastBackupData.domainId);
                                 Criteria crt = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"), lastBackupData.objId, QueryConstants.EQUAL);
                                 updQry.setUpdateColumn("CHANGE_DATA",  lastBackupData.data.toString());   //No I18N
                                 updQry.setCriteria(crt);
                                 CommonUtil.getPersistence().update(updQry); 
                            }
                       }
                       catch(Exception e){
                          LogWriter.backup.severe(String.format("AbstractBackup.backupAttribute Id:%s \nexcep:%s", attribInfo.attributeMaskIndex, LogWriter.getStackTrace(e)));
                        }
                    } 
                }
                if (toBackup) 
                {
                    ArrayList propertyValues = (ArrayList) property.getValue();
                    boolean isByteArray = attribInfo.adDatatye.equalsIgnoreCase("byte[]");
                    if (isByteArray && !attribInfo.attrName.equalsIgnoreCase("nTSecurityDescriptor")) 
                    {
                        for (int i = 0; i < propertyValues.size(); i++) 
                        {
                            String val = (String) propertyValues.get(i);
                            String numval = "[";
                            for (int j = 0; j < val.length(); j += 2)
                            {
                                String sub = val.substring(j, j + 2);
                                Integer num = Integer.parseInt(sub, 16);
                                numval += num.toString();
                                if (j != val.length() - 2) 
                                {
                                    numval += ",";
                                }
                                else
                                {
                                    numval += "]";
                                }
                            }
                            propertyValues.set(i, numval);
                        }
                    }
                    if (attribInfo.isMultiValued && !isByteArray) 
                    {
                        propertyValue = JSONObjectUtil.toJsonString(propertyValues);
                    }
                    else if (isByteArray) 
                    {
                        propertyValue = propertyValues.toString();
                    } 
                    else if (!propertyValues.isEmpty()) 
                    {
                        propertyValue = propertyValues.get(0);
                    }
                    if (attribInfo.adDatatye.compareToIgnoreCase("boolean") == 0) 
                    {
                        propertyValue = BackupUtil.getBooleanValue(propertyValue, attribInfo);
                    }
                    return updateAttributeValue(backupObject, lastBackupData, attribInfo, propertyValue);
                }
                //lastBackupData.changeMask.set(attribId); ToDo: save changeMask field in currentObjectInfo table
            } 
            else 
            {
                if (((String) property.getKey()).equalsIgnoreCase("records")) 
                {
                    return true;// for the dns zone update case
                }
                return false;
            }
        } 
        catch (Exception e) 
        {
            LogWriter.backup.severe(String.format("AbstractBackup.backupAttribute attr:%s \nexcep:%s", property.getKey(), LogWriter.getStackTrace(e)));
            return false;
        }
        return toBackup;
    }

    private boolean updateAttributeValue(BackupObject backupObject, BackupObject lastBackupData, Attribute attribInfo, Object propertyVal) 
    {
        return updateAttributeValue(backupObject, lastBackupData, attribInfo.attributeMaskIndex, attribInfo.isMultiValued, propertyVal, attribInfo.toSync, attribInfo.isCustom);
    }

    public boolean updateAttributeValue(BackupObject backupObject, BackupObject lastBackupData, int attributeMask, boolean isMultiVal, Object propertyVal, boolean toSync, boolean isCustom)
    {
        try 
        {
            String bkpAttrId = RmpConstants.BACKUP_VALUE_PREFIX + attributeMask;
                             String oldAttrId = RmpConstants.OLD_VALUE_PREFIX + attributeMask;
           /* if(!backupObject.syncChangeMask.get(attributeMask)){
                        backupObject.syncChangeMask.set(attributeMask);
             }*/
            if (toSync) {
                Object oldValue = JSONObjectUtil.getValue(lastBackupData.data, bkpAttrId);
                Boolean isChanged=compareChanges(oldValue, propertyVal, isMultiVal, attributeMask, backupObject);
                if (isChanged || (backupObject.objTyp == ObjectType.DnsNode && attributeMask == 52 && backupObject.changeTyp == ChangeType.Deleted.maskValue)
                        || (!backupObject.ouId.equals(backupObject.ouId) && backupObject.ouNam.equals(backupObject.ouNam) && (!backupObject.isDeleted && lastBackupData.changeTyp != ChangeType.Deleted.maskValue) && attributeMask == 52)) {
                   
                    backupObject.data.put(bkpAttrId, propertyVal);
                    if (customAttribute.hasBackup && isCustom && lastBackupData.linkId != null) 
                    {
                        lastBackupData.changeMask.set(attributeMask);
                        oldValue = propertyVal;
                    }
                    if (lastBackupData.changeMask.get(attributeMask)) 
                    {
                        backupObject.data.put(oldAttrId, oldValue);
                        lastBackupData.data.put(oldAttrId, oldValue);
                    } 
                    else 
                    {
                        lastBackupData.changeMask.set(attributeMask);
                    }
                    lastBackupData.data.put(bkpAttrId, propertyVal);
                    backupObject.changeMask.set(attributeMask);
                    return true;
                }
            } 
            else {
                Object oldValue = JSONObjectUtil.getValue(lastBackupData.linksData, bkpAttrId);
                if (compareChanges(oldValue, propertyVal, isMultiVal, attributeMask, backupObject)) {
                    backupObject.linksData.put(bkpAttrId, propertyVal);
                    if (lastBackupData.changeMask.get(attributeMask)) 
                    {
                        backupObject.linksData.put(oldAttrId, oldValue);
                        lastBackupData.linksData.put(oldAttrId, oldValue);
                    } 
                    else 
                    {
                        lastBackupData.changeMask.set(attributeMask);
                    }
                    lastBackupData.linksData.put(bkpAttrId, propertyVal);
                    backupObject.changeMask.set(attributeMask);
                    return true;
                }
            }
        } 
        catch (JSONException ex) 
        {
            LogWriter.backup.severe(String.format("AbstractBackup.updateAttributeValue Id:%s \nexcep:%s", attributeMask, LogWriter.getStackTrace(ex)));
        }
        return false;
    }

    public static void updateOldValueOfCurrrentInfo(BitSet backupChangeMask, JSONObject lastBackupData)
    {
        try {
            if (lastBackupData != null || lastBackupData.length() > 0) 
            {
                JSONArray keyList = lastBackupData.names();
                if(keyList==null)
                {
                    return;
                }
                for (int i = 0; i < keyList.length(); i++) 
                {
                    String key = keyList.get(i).toString();
                   
                    if((key.startsWith(RmpConstants.BACKUP_VALUE_PREFIX) ||  key.startsWith(RmpConstants.OLD_VALUE_PREFIX)) &&  StringUtils.isNumeric(key.substring(1))){
                    Integer attrMask = Integer.parseInt(key.substring(1));
                    if (key.startsWith(RmpConstants.BACKUP_VALUE_PREFIX)) {
                        try {
                            if (!backupChangeMask.get(attrMask)) {
                                lastBackupData.put(RmpConstants.OLD_VALUE_PREFIX + attrMask.toString(), JSONObjectUtil.getValue(lastBackupData, RmpConstants.BACKUP_VALUE_PREFIX + attrMask.toString()));
                            }
                        } catch (Exception e) {

                        }
                    }
                    else if(!backupChangeMask.get(attrMask) && (attrMask != LdapAttribute.CountryCode.ldapAttributeId) && key.startsWith(RmpConstants.OLD_VALUE_PREFIX) && (!lastBackupData.has(RmpConstants.BACKUP_VALUE_PREFIX+key.substring(1))) ){
                        lastBackupData.remove(key);
                    }
                    }
                }
            }
        } 
        catch (Exception e) 
        {
            LogWriter.backup.severe(String.format("AbstractBackup.updateOldValueOfCurrrentInfo : %s", LogWriter.getStackTrace(e)));
        }
    }
    
    private static void updateGPOLinkProperties(Properties prop)
    {
        try 
        {
            //ToDo: Implement GPO Links 
        } 
        catch (Exception e) 
        {
            LogWriter.backup.severe(String.format("AbstractBackup.updateGPOLinkProperties : %s", LogWriter.getStackTrace(e)));
        }
    }

    public static Boolean compareChanges(Object oldValue, Object newValue, boolean isMultiVal, int attribuiteMask, BackupObject backupObject)
    {
        try 
        {
            if (newValue == null)
            {
                if (oldValue == null) 
                {
                    return false;
                }
            } 
            else if (newValue.equals(oldValue)) 
            {
                return false;
            }
            if (isMultiVal) 
            {
                String tempNewValue, tempOldValue, pattern;

                if (attribuiteMask == LdapAttribute.RangedAttrs.ldapAttributeId || attribuiteMask == LdapAttribute.dnsRecord.ldapAttributeId) 
                {
                    tempNewValue = newValue.toString();
                    tempOldValue = (String) oldValue;
                    pattern = "], [";
                } 
                else 
                {
                    tempOldValue = (String) oldValue;
                    tempNewValue = (String) newValue;
                    pattern = "\",\"";
                }
                if (oldValue == null) 
                {
                    oldValue = "[]";
                }
                if (newValue == null)
                {
                    newValue = "[]";
                }
                if (!tempNewValue.equals(tempOldValue) && (newValue.equals("[]") || oldValue.equals("[]"))) 
                {
                    return true;
                }
                if (tempNewValue.equals(tempOldValue))
                {
                    return false;
                }

                String[] newValueList = (tempNewValue).substring(2, (tempNewValue).length() - 2).split(Pattern.quote(pattern));
                String[] oldValueList = (tempOldValue).substring(2, (tempOldValue).length() - 2).split(Pattern.quote(pattern));
                if (oldValueList.length != newValueList.length) 
                {
                    return true;
                }
                Arrays.sort(oldValueList);
                Arrays.sort(newValueList);
                if (attribuiteMask == LdapAttribute.dnsRecord.ldapAttributeId) {
                    DnsManager.dnsRemoveSerialTimeStamp(oldValueList);
                    DnsManager.dnsRemoveSerialTimeStamp(newValueList);
                }	 
                if (Arrays.equals(oldValueList, newValueList)) 
                {
                    return false;
                }
                return true;
                //ToDo: handle multivale comparsion
            } 
            else
            {
                return true;
            }
        }
        catch (Exception e) 
        {
            LogWriter.backup.severe("AbstractBackup.tempUpdate " + LogWriter.getStackTrace(e));
        }
        return true;
    }

    public void tempUpdate() 
    {
        try 
        {
            backupInfo.data = backupTracker.getData(false);
            backupInfo.count = backupTracker.data.get(ObjectType.Other.id.intValue()).get(ChangeType.UnTracked.id);
            backupInfo.status = OperationStatus.Processing;
            RunningOperationSync.update(backupInfo);
        } 
        catch (Exception e) 
        {
            LogWriter.backup.severe("AbstractBackup.tempUpdate " + LogWriter.getStackTrace(e));
        }
    }

    public void updateRangedAttrBackupStatus(int count) 
    {
        try 
        {
            JSONObject data = new JSONObject();
            data.put("linksCount", count);
            backupInfo.data = data;
            RunningOperationSync.update(backupInfo);
        } 
        catch (Exception e)
        {
            LogWriter.backup.severe("AbstractBackup.updateRangedAttrBackupStatus " + LogWriter.getStackTrace(e));
        }
    }

    protected void setOuToBackup(OuConfig ouConfig, UUID ouId) 
    {
        //ToDo: If OU 1 moved to OU2 (has_children true /false) -> have to update selection type for parent ou config reciversively if needed and to backup for child ou's recursively based on parentou to backup if needed
        OuConfig parentOuConfig = BackupUtil.getOuConfig(domainId, ouId);
        if(parentOuConfig==null && (orgObjectType.equalsIgnoreCase("dnsZone") || orgObjectType.equalsIgnoreCase("dnsNode") )){
                     ouConfig.toBackup = false; 
                      LogWriter.backup.severe("AbstractBackup.setOuToBackup dns object skipped " + ouConfig.distinguishedName);
        }
//        else if (parentOuConfig.selectionType == OuSelectionType.Partial.ordinal())
//        {
//            ouConfig.toBackup = true;
//        }
        else 
        {
            //ToDo:If Tracked OU is moved to NonTracking OU then all the child object backupTracking should be set to false
            if(parentOuConfig!=null) {
                if(!ADObjectsUtil.getExcludeChild(domainId)) {
                    ouConfig.toBackup = parentOuConfig.toBackup;
                }
                else {
                    if(ouConfig.parentGuid.toString().equalsIgnoreCase(ADObjectsUtil.getDomainRootGuid(domainId))) {
                        ouConfig.toBackup = true;
                    }
                    else {
                        ouConfig.toBackup = false;
                    }
                }
            }
            else {
                ouConfig.toBackup = true;
            }
        }
    }

    protected OuConfig setDeletedObjectProperties(BackupObject backupObject, BackupObject lastBackupData, boolean ouorDnsZone) 
    {
        String objectName = LdapUtil.getCommonNameFromDeletedObjectDN(backupObject.distinguishedName);
        String lastSnapShotParentDN=LdapUtil.getParentDNFromDN(lastBackupData.distinguishedName);
        backupObject.objNam = backupObject.objTyp != ObjectType.GroupPolicy ? LdapUtil.getObjectAttributeValue(objectName) : objectName;        
        if (backupObject.lastKnownParent == null)
        {
            backupObject.ouNam = lastBackupData.ouNam;//ToDo: need to query the latest name using lastSnapshot.ouId (Reason: OU might be renamed / If lastKnown parent is also in deleted state need to get the non deleted location)
        }
        else 
        {
            backupObject.ouNam = LdapUtil.getCanonicalName(backupObject.lastKnownParent);
        }
        OuConfig ouDetails = new OuConfig();
        if (backupObject.lastKnownParent != null && LdapUtil.isObjectDeleted(backupObject.lastKnownParent))
        {
            ouDetails.objectGuid = UUID.fromString(LdapUtil.getGuidFromDeletedObjectDN(backupObject.lastKnownParent));
            //ToDo: Need to get toBackup value recursively from parent
            if(lastBackupData.linkId==null || lastBackupData.isBackupSet){
            ouDetails.toBackup = true;
            }
            backupObject.ouId = ouDetails.objectGuid;
            if (ouorDnsZone) 
            {
                ouDetails.parentGuid = ouDetails.objectGuid;
                ouDetails.objectGuid = backupObject.objId;
            }
        }
        else if(backupObject.ouNam!=null && StringUtils.containsIgnoreCase(backupObject.ouNam,"/Deleted Objects") &&  lastSnapShotParentDN!=null && StringUtils.containsIgnoreCase(lastSnapShotParentDN,"CN=Deleted Objects") && StringUtils.containsIgnoreCase(lastSnapShotParentDN,"DEL:")){
            OuConfig parentOuConfig = BackupUtil.getOuConfig(backupObject.domainId, UUID.fromString(LdapUtil.getGuidFromDeletedObjectDN(lastSnapShotParentDN)));
            backupObject.ouId = parentOuConfig.objectGuid;
            if (ouorDnsZone) 
            {
                ouDetails.objectGuid = backupObject.objId;
                ouDetails.parentGuid = parentOuConfig.objectGuid;
                ouDetails.name = backupObject.objNam;
                ouDetails.canonicalName = LdapUtil.getCanonicalName(backupObject.distinguishedName);
                ouDetails.distinguishedName = backupObject.distinguishedName;
                ouDetails.toBackup = parentOuConfig.toBackup;
            } 
            else 
            {
                ouDetails = parentOuConfig;
            }
            
        }
        else 
        {
           OuConfig parentOuConfig = getOuConfig(backupObject.domainId, backupObject.ouNam,backupObject.distinguishedName, null);
            backupObject.ouId = parentOuConfig.objectGuid;
            if (ouorDnsZone) 
            {
                ouDetails.objectGuid = backupObject.objId;
                ouDetails.parentGuid = parentOuConfig.objectGuid;
                ouDetails.name = backupObject.objNam;
                ouDetails.canonicalName = LdapUtil.getCanonicalName(backupObject.distinguishedName);
                ouDetails.distinguishedName = backupObject.distinguishedName;
                ouDetails.toBackup = parentOuConfig.toBackup;
            } 
            else 
            {
                ouDetails = parentOuConfig;
            }
        }
        backupObject.isDeleted = true;
        ouDetails.isDeleted = true;
        ouDetails.hasHistory = false;
        return ouDetails;
    }

    protected OuConfig getOuConfig(BackupObject backupObject, BackupObject lastBackupData)
    {
        OuConfig ouConfig;
        boolean ouorDnsZone;
        try {
            if (ouorDnsZone = (backupObject.objTyp == ObjectType.OU || backupObject.objTyp == ObjectType.DnsZone || orgObjectType.equalsIgnoreCase("ouGPLinksAttr"))) //ToDo: generate ouConfig from lastBackupSnapshot instead of fetching from table
            { 
                ouConfig = BackupUtil.getOuConfig(domainId, backupObject.objId);
                if (ouConfig == null)  //OU not in table
                {
                    if (LdapUtil.isDeletedObjectContainer(backupObject.ouNam))     //Initial Backup Deleted OU's, Incremetnal Backup - created and Deleted OU's
                    {
                        return setDeletedObjectProperties(backupObject, lastBackupData, ouorDnsZone);
                    } 
                    else 
                    {                                                          // newly created OU's                           
                        ouConfig = new OuConfig(backupObject);
                        ouConfig.hasHistory = ouConfig.hasHistory = !(backupType == BackupType.InitBackup && backupObject.objNam.equals("Deleted Objects")) ? false : null;
                        setOuToBackup(ouConfig, backupObject.ouId);
                    }
                } 
                else if (LdapUtil.isDeletedObjectContainer(backupObject.ouNam))     // OU in table and deleted in incremental backup
                {
                    backupObject.isDeleted = true;
                    backupObject.ouNam = lastBackupData.ouNam == null ? LdapUtil.getParentCanonical(ouConfig.distinguishedName) : lastBackupData.ouNam;
                    backupObject.ouId = lastBackupData.ouId == null ? ouConfig.parentGuid : lastBackupData.ouId;
                } 
                else if (backupObject.ouId != null && !backupObject.ouId.toString().equals(ouConfig.parentGuid.toString())) 
                {  
                    setOuToBackup(ouConfig, backupObject.ouId);
                } 
                else 
                {
                    backupObject.ouId = ouConfig.parentGuid;
                    backupObject.ouNam = backupObject.ouNam == null ? lastBackupData.ouNam == null ? LdapUtil.getParentCanonical(ouConfig.distinguishedName) : lastBackupData.ouNam : backupObject.ouNam;
                }
                if (ouCache != null) 
                {
                    ouCache.put(LdapUtil.getCanonicalName(backupObject.ouNam, ouConfig.name), ouConfig);
                }
                return ouConfig;
            } 
            else if(backupObject.objTyp == ObjectType.Site || orgObjectType.equalsIgnoreCase("siteGPLinksAttr")) 
            {
                ouConfig = new OuConfig();
                ouConfig.objectGuid = lastBackupData.linkId != null ? lastBackupData.ouId : backupObject.ouId != null ? backupObject.ouId : BackupUtil.emptyGuid;
                ouConfig.distinguishedName = backupObject.parentDN;
                ouConfig.canonicalName = LdapUtil.getCanonicalName(ouConfig.distinguishedName);
                ouConfig.toBackup = isSiteSelected;
                lastBackupData.ouId = backupObject.ouId = ouConfig.objectGuid;
                backupObject.ouNam = ouConfig.canonicalName;
                if(backupObject.isDeleted)
                {
                    backupObject.objNam = lastBackupData.objNam != null ? lastBackupData.objNam : LdapUtil.getObjectAttributeValue(backupObject.distinguishedName);
                }
                return ouConfig;
            } 
            else 
            {
                if (LdapUtil.isDeletedObjectContainer(backupObject.ouNam)) //ToDo: include deleted objContainer check for DNS zone
                {
                    if(lastBackupData.linkId == null || LdapUtil.isDeletedObjectContainer(backupObject.ouNam)) 
                    {
                        return setDeletedObjectProperties(backupObject, lastBackupData, ouorDnsZone);
                    }
                    if (lastBackupData.linkId != null && lastBackupData.linkId > 0) 
                    {
                        backupObject.isDeleted = true;
                        backupObject.ouNam = !lastBackupData.hasHistory ? backupObject.ouNam : lastBackupData.ouNam;
                        backupObject.objNam = backupObject.objNam != null ? backupObject.objNam : lastBackupData.objNam;
                    }
                    
                    
                }
                  OuConfig ouconfig = getOuConfig(backupObject.domainId, backupObject.ouNam,backupObject.distinguishedName, backupObject.ouId);
                backupObject.ouId = ouconfig.objectGuid;
                backupObject.ouNam = ouconfig.canonicalName;
                return ouconfig;
            }
        } 
        catch (Exception e) 
        {
            LogWriter.backup.severe(String.format("RmpBackupImpl.getOuConfig1 domainId:%s dn:%s ouName:%s \nexcep: %s", domainId, backupObject.distinguishedName, backupObject.ouNam, LogWriter.getStackTrace(e)));
        }
        return null;
    }

     protected OuConfig getOuConfig(Long domainId, String ouName,String distinguishedName, UUID ouId) 
    {
        try 
        {
           if (ouName == null) 
            {
                return null;
            }
            if (isInitBackup || ouCache != null) 
            {
                if (ouCache.containsKey(ouName)) 
                {
                    return ouCache.get(ouName);
                }
            }
            else 
            {
             OuConfig ouConfig;
               if(!LdapUtil.isObjectDeleted(distinguishedName)){
                ouConfig = BackupUtil.getOuConfig(domainId, LdapUtil.getParentDNFromDN(distinguishedName));
               }
               else{
                     ouConfig=BackupUtil.getOuConfigFromCanonical(domainId, ouName);
               }
                if (ouConfig == null && ouId != null)
                {
                    return BackupUtil.getOuConfig(domainId, ouId);//ToDo: temp fix. Need to query using ouId by default
                } 
                else
                {
                    return ouConfig;
                }
           }
        } 
        catch (Exception e)
        {
            LogWriter.backup.severe(String.format("AbstractBackup.getOuConfig2 domainId:%s ouName:%s \nexcep: %s", domainId, ouName, LogWriter.getStackTrace(e)));
        }
        return null;
    }
}

//ignoreI18n_end
