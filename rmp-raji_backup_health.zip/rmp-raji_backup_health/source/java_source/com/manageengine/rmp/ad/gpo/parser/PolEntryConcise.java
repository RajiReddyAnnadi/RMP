/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.parser;

import com.manageengine.rmp.ad.gpo.constants.*;
import java.io.Serializable;

/**
 * $Id:$
 * @author lucky-2306
 */
public class PolEntryConcise implements Serializable {

    public java.util.ArrayList<Byte> bl; //Binary List
    public String kn; //Key Name
    public String vn; //Value Name
    public String sv; //String Value
    public long pt; //Policy Entry Type
    public int ar; //Add or Remove
    public int um; //Machine or User
    public String ka; //Key Append

    public PolEntryConcise() {
        this.bl = new java.util.ArrayList<Byte>();
        this.pt = PolEntryType.REG_NONE.polId;
        this.ar = GpoAddRem.Add.addRemId;
        this.um = GpoConfigType.Machine.id;
        this.sv = "";
        this.ka = "";
    }

    public PolEntryConcise(PolEntry polEntry) {
        if (polEntry != null) {
            this.bl = polEntry.byteList;
            this.kn = polEntry.keyName;
            this.vn = polEntry.valueName;
            this.pt = polEntry.type.polId;
            if (polEntry.stringValue == null || polEntry.stringValue.isEmpty()) {
                this.sv = polEntry.getStringValue();
            } else {
                this.sv = polEntry.stringValue;
            }
            this.ar = polEntry.gpoAddRem.addRemId;
            this.um = polEntry.gpoUserMach.id;
            this.ka = polEntry.appendVN;
        }
    }
}
