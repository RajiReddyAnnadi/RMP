/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.manager;

import com.manageengine.rmp.ad.gpo.constants.GpoErrors;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.PsOperations;
import com.manageengine.rmp.common.RMPCommonUtil;
import com.manageengine.rmp.jni.powershellmanager.PowershellHandler;
import com.manageengine.rmp.util.ExecUtil;
import com.manageengine.rmp.util.RmpPaths;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class GpoDcExec {

    public static HashMap backupGpoRemote(GpoProp gpoProp, String dcGpoMainDirPath, String gpoId, boolean toCatchEx, boolean isPowerShell) throws Exception {
        return backupGpoRemote(gpoProp, dcGpoMainDirPath, gpoId, toCatchEx, true, isPowerShell);
    }
    
    public static HashMap backupGpoRemote(GpoProp gpoProp, String dcGpoMainDirPath, String gpoId, boolean toCatchEx, boolean toRetry, boolean isPowerShell) throws IOException, Exception {

        HashMap result = new HashMap();
        boolean isBackedUp = false;
        int isPowershellSuccess = -1;
        //method1 - using Powershell
        if(isPowerShell)
        {
            LogWriter.gpo.info(String.format("Backup GPO from SYSVOL to Temp Folder using Powershell Remote Cmdlet"));
            isPowershellSuccess = PowershellHandler.groupPolicyBackup(gpoProp.userDomainName, gpoProp.dcName, gpoProp.userName, gpoProp.password, gpoId, dcGpoMainDirPath);
            LogWriter.gpo.finest("Powershell Exit Code : " + isPowershellSuccess);
            if (isPowershellSuccess == 0) {
                isBackedUp = getBackupDirectory(gpoProp, isPowershellSuccess, true);
            } else {
                isBackedUp = false;
                LogWriter.gpo.info(String.format("PowerShell initialization failed for domain "+gpoProp.domainName));
                isPowerShell = false;
            }
        }
        if (!isBackedUp) {
            //method2 - using PaExec
            LogWriter.gpo.info(String.format("Backup GPO from SYSVOL to Temp Folder using Remote Cmd Execution"));
            int exitCode;
            ArrayList<String> arguments;
            arguments = RMPCommonUtil.remoteCmdArgs(gpoProp.domainName, gpoProp.dcName, gpoProp.userName, gpoProp.password,gpoProp.userDomainName,  gpoId, PsOperations.GpoBackup, dcGpoMainDirPath);
            exitCode = ExecUtil.executeProcess(RmpPaths.RMP_BIN_DIR, RmpPaths.REM_CMD_EXEC, arguments, true, true, true);
            LogWriter.gpo.info(String.format("Exit Code For Gpo Backup : " + exitCode));
            isBackedUp = getBackupDirectory(gpoProp, exitCode, toCatchEx);
            LogWriter.gpo.info(String.format("GPO backed up : " + isBackedUp));
        }
        if(!isBackedUp){
            isPowerShell = true;
        }
        result.put("ExitCode", isBackedUp ? 0L : isPowershellSuccess);
        result.put("PowerShell", isPowerShell);
        result.put("Error", GpoErrors.getName(isPowershellSuccess));
        return result;
    }

    public static HashMap restoreGpoRemote(PsOperations gpoOperation, String domainName, String computerName, String userDomainName , String admin, String password, String gpoId, String dcGpoMainDirPath, boolean isPowerShell) {
        HashMap result = new HashMap();
        try {
            String backupId = gpoId.replace("{", "").replace("}", "");
            int isPowershellSuccess = -1;

            //method1 - using Powershell
            if(isPowerShell){
                LogWriter.gpo.info(String.format("Restore GPO from SYSVOL to Temp Folder using Powershell Remote Cmdlet"));
                isPowershellSuccess = PowershellHandler.groupPolicyChange(userDomainName, computerName, admin, password, backupId, dcGpoMainDirPath, gpoOperation);
                LogWriter.gpo.finest("Powershell Exit Code : " + isPowershellSuccess);
            }
            if (isPowershellSuccess != 0) {
                //method2 - using PaExec
                LogWriter.gpo.info(String.format("Restore GPO from SYSVOL to Temp Folder using Remote Cmd Execution"));
                ArrayList<String> arguments = RMPCommonUtil.remoteCmdArgs(domainName, computerName, admin, password,userDomainName, backupId, gpoOperation, dcGpoMainDirPath);//No I18N
                result.put("ExitCode", ExecUtil.executeProcess(RmpPaths.RMP_BIN_DIR, RmpPaths.REM_CMD_EXEC, arguments, true, true, true));
                isPowerShell = false;
            } 
            else {
                result.put("ExitCode", isPowershellSuccess);
            }
            result.put("PowerShell", isPowerShell);
            return result;
        } catch (Exception ex) {
            LogWriter.gpo.severe(String.format("%s", LogWriter.getStackTrace(ex)));
            return null;
        }
    }

    private static boolean getBackupDirectory(GpoProp gpoProp, int exitCode, boolean toCatchEx) throws Exception {
        try {
            gpoProp.dcGpoDir = GpoUtil.getNewGpoDirName(gpoProp.dcGpoMainDir, 1);
        } catch (Exception e) {
            return exceptionThrower(toCatchEx);
        }
        if (gpoProp.dcGpoDir == null) {
            return exceptionThrower(toCatchEx);
        }
        return exitCode == 0;
    }

    private static boolean exceptionThrower(boolean toCatchEx) throws Exception {
        if (!toCatchEx) {
            throw new Exception("Gpo Backup/Restore Failed.");
        } else {
            return false;
        }
    }
}

//ignoreI18n_end
