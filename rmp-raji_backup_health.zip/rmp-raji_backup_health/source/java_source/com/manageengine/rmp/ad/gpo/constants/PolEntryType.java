/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.constants;

/**
 *
 * @author lucky-2306
 */
public enum PolEntryType {

    REG_NONE(0),
    REG_SZ(1),
    REG_EXPAND_SZ(2),
    REG_BINARY(3),
    REG_DWORD(4),
    REG_DWORD_BIG_ENDIAN(5),
    REG_MULTI_SZ(7),
    REG_QWORD(11);

    public Long polId;
    static PolEntryType[] polEntryTypeVal;

    static {
        polEntryTypeVal = PolEntryType.values();
    }

    PolEntryType(long polId) {
        this.polId = polId;
    }

//    public static PolEntryType getPolEntryType(long polId) {
//        return In [(int)polId];
//    }

    public static boolean isEnum(long type) {
        return (type >= 0 && type <= polEntryTypeVal[polEntryTypeVal.length-1].polId);
    }

    public static PolEntryType getType(long entryId) {
//        switch ((int)entryId) {
//            case 1:
//                return REG_SZ;
//            case 2:
//                return REG_EXPAND_SZ;
//            case 3:
//                return REG_BINARY;
//            case 4:
//                return REG_DWORD;
//            case 5:
//                return REG_DWORD_BIG_ENDIAN;
//            case 7:
//                return REG_MULTI_SZ;
//            case 11:
//                return REG_QWORD;
//            default:
//                return REG_NONE;
//        }
//    }
        for(PolEntryType entryType : polEntryTypeVal) {
            if(entryType.polId.equals(entryId)){ 
                return entryType;
            }
        }
        
    return REG_NONE;
    }
}
