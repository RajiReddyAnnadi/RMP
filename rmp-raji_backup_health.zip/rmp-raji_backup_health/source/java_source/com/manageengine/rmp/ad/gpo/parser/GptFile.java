/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.parser;

import com.google.gson.reflect.TypeToken;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.ad.gpo.constants.GpoConfigType;
import com.manageengine.rmp.ad.gpo.constants.GpoFileType;
import com.manageengine.rmp.ad.gpo.constants.GptTmplType;
import com.manageengine.rmp.ad.gpo.manager.GpoUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.util.LdapUtil;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * $Id$
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class GptFile extends GpoFile {

    private HashMap<String, AbstractGpoEntry> entries;

    @Override
    public ArrayList<AbstractGpoEntry> getEntries() {
        ArrayList<AbstractGpoEntry> gpoEntry = new ArrayList<AbstractGpoEntry>(entries.values());
        return gpoEntry;
    }
    private java.util.HashMap<GptTmplType, java.util.HashMap<String, GptEntry>> arrangeEntries; //object = GptEntry | PolEntry
    public String domainName, dcName, adminName, password;
    private String fileName;

    @Override
    public String getFileName() {
        return fileName;
    }

    @Override
    public void setFileName(String value) {
        fileName = value;
    }

    public GptFile() {
        this.setFileName("");
        this.entries = new HashMap<String, AbstractGpoEntry>();//to ignore case
        this.arrangeEntries = new HashMap<GptTmplType, java.util.HashMap<String, GptEntry>>();
    }

    public GptFile(String domainName, String dcName, String adminName, String password) {
        this.domainName = domainName;
        this.dcName = dcName;
        this.adminName = adminName;
        this.password = password;
        this.setFileName("");
        this.entries = new HashMap<String, AbstractGpoEntry>();//ignore case
        this.arrangeEntries = new HashMap<GptTmplType, HashMap<String, GptEntry>>();
    }

    @Override
    public void setValue(AbstractGpoEntry ge1) {
        GptEntry ge = (GptEntry) ge1;
        this.entries.put(ge.keyName + String.valueOf(ge.gptType.gptId), ge);
        if (!this.arrangeEntries.containsKey(ge.gptType)) {
            this.arrangeEntries.put(ge.gptType, new java.util.HashMap<String, GptEntry>());
        }
        this.arrangeEntries.get(ge.gptType).put(ge.keyName, ge);
    }

    public final AbstractGpoEntry getValue(String key, String value) {
        AbstractGpoEntry gpoEntry = null;
        key = getKey(key, value);
        gpoEntry = this.entries.get(key + value);
        return gpoEntry;
    }

    @Override
    public AbstractGpoEntry getValue(AbstractGpoEntry gpoEntry) {
        return this.getValue(gpoEntry.keyName, String.valueOf(((GptEntry) gpoEntry).gptType.gptId));
    }

    public final String getStringValue(String key, String value) {
        try {
            GptEntry ge = (GptEntry) this.getValue(key, value);
            if (ge == null) {
                return "";
            }
            return ge.valueName;
        } catch (Exception e) {
            return "";
        }
    }

    public final String getStringValue(GptEntry ge) {
        return ge.valueName;
    }

    public final boolean contains(String key, String value) {
        return (this.getValue(key, value) != null);
    }

    @Override
    public boolean contains(AbstractGpoEntry gpoEntry) {
        return contains(gpoEntry.keyName, String.valueOf(((GptEntry) gpoEntry).gptType.gptId));
    }

    public final void loadFile(GpoConfigType gpType) throws IOException {
        this.loadFile(null, gpType);
    }

    @Override
    public void deleteValue(AbstractGpoEntry gpoEntry) {
        deleteValue(gpoEntry.keyName, String.valueOf(((GptEntry) gpoEntry).gptType.gptId));
    }
    
    public final void deleteValue(String key, String value) {
        key = getKey(key, value);
        String entryKey = key + value;
        if (this.entries.containsKey(entryKey)) {
            this.entries.remove(entryKey);
            GptTmplType gptType = GptTmplType.values[Integer.parseInt(value)];
            if (this.arrangeEntries.containsKey(gptType) && this.arrangeEntries.get(gptType).containsKey(key)) {
                this.arrangeEntries.get(gptType).remove(key);
            }
        }
    }

    private String getKey(String key, String value) {
        if (key.endsWith(value)) {
            return key.substring(0, key.length() - 1);
        }
        return key;
    }

    private String getEncoding(String fileName) {
        BufferedReader bReader = null;
        try {
            bReader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-16"));
            String temp = bReader.readLine();
            if (temp.contains("[") && temp.contains("]")) {
                return "UTF-16";
            }
        } catch (Exception e) {
            LogWriter.gpo.severe("Cannot find Encoding Type in getEncoding : " + e);
        } finally {
            try {
                if (bReader != null) {
                    bReader.close();
                }
            } catch (Exception e) {
                LogWriter.gpo.severe("Cannot close Buffere Reader in getEncoding : " + e);
            }
        }
        return "UTF-8";
    }

    public final void loadFile(String file, GpoConfigType gpType) throws IOException {
        File gptFile = null;
        BufferedReader bReader = null;
        if (!(file == null || file.isEmpty())) {
            this.fileName = file;
            gptFile = new File(file);
        }

        String line = "";
        try {
            if (gptFile != null && gptFile.exists()) {
                bReader = new BufferedReader(new InputStreamReader(new FileInputStream(this.fileName), getEncoding(this.fileName)));//NO I18N
                GptTmplType gptType = GptTmplType.Unknown;
                GptTmplType gptTempType;
                while ((line = bReader.readLine()) != null) {
                    if ((gptTempType = GptTmplType.setGptType(line)) != GptTmplType.NotGptType) {
                        gptType = gptTempType;
                        continue;
                    } else {
                        GptEntry gptEntry = newGptEntry(line, gptType, gpType);
                        //gptEntry.gpoUserMach = gpType;
                        this.setValue(gptEntry);
                    }
                }
            }
            //else part AgentLogger.Gpo.Info("Load GptFile file not present : " + this.FileName);
        } catch (Exception e) {
            LogWriter.gpo.severe("Gpt File : " + LogWriter.getStackTrace(e));
        } finally {
            if (bReader != null) {
                bReader.close();
            }
        }
    }

    public final String multivalueGptSettings(String rawGptEntry, GptEntry gptEntry) {
        ArrayList<String> valueNames = new ArrayList<String>();
        if (this.arrangeEntries.containsKey(gptEntry.gptType) && this.arrangeEntries.get(gptEntry.gptType).containsKey(gptEntry.keyName)) {
            valueNames = JSONObjectUtil.fromJsonString(this.arrangeEntries.get(gptEntry.gptType).get(gptEntry.keyName).valueName, new TypeToken<ArrayList<String>>() {
            }.getType());
        }
        valueNames.add(rawGptEntry);
        return JSONObjectUtil.toJsonString(valueNames);
    }

    public final String getGroupMembershipValue(String valueNames, GptEntry gptEntry) {
        try {
            ArrayList<String> sidValues = new ArrayList<String>();
            sidValues = JSONObjectUtil.fromJsonString(valueNames, sidValues.getClass());
            String sidValue = sidValues.get(sidValues.size() - 1); //Latest
            ArrayList<ArrayList<String>> allGMValues = new ArrayList<ArrayList<String>>();
            if (this.arrangeEntries.containsKey(gptEntry.gptType) && this.arrangeEntries.get(gptEntry.gptType).containsKey(gptEntry.keyName)) {
                allGMValues = JSONObjectUtil.fromJsonString(this.arrangeEntries.get(gptEntry.gptType).get(gptEntry.keyName).sv, allGMValues.getClass());
            }
            ArrayList<String> eachGMValue = parseRestrictedGroup(sidValue);
            if (sidValue.contains("__Memberof")) {
                eachGMValue.add(1, "MemberOf");//No I18N
            } else if (sidValue.contains("__Members")) {//No I18N
                eachGMValue.add(1, "Members");//No I18N
            } else {
                eachGMValue.add(1, "");
            }
            allGMValues.add(eachGMValue);
            return JSONObjectUtil.toJsonString(allGMValues);
        } catch (Exception e) {
            LogWriter.gpo.severe("Gpt File : " + e);
            return "";
        }
    }

    public final ArrayList<String> parseRestrictedGroup(String rawSid) {
        ArrayList<String> parsedValues = new ArrayList<String>();
        if (rawSid.contains("=") && (rawSid.contains("__Memberof") || rawSid.contains("__Members"))) {
            String[] tempSid = GpoUtil.parseGpoValues(rawSid);
            String sID = tempSid[0].substring(0, tempSid[0].lastIndexOf("__")); //Remove * from SID
            parsedValues.add(sID);
            if (tempSid.length == 1) {
                parsedValues.add("[]");
            } else {
                String[] membership = tempSid[1].split(",");
                parsedValues.add(JSONObjectUtil.toJsonString(membership));
            }
        } else {
            parsedValues.add(rawSid);
            parsedValues.add("[]");
        }
        return parsedValues;
    }

    public final GptEntry newGptEntry(String rawGptEntry, GptTmplType gptType, GpoConfigType gpType) {
        try {
            GptEntry gptEntry = new GptEntry();
            String[] values = GpoUtil.parseGpoValues(rawGptEntry);
            gptEntry.gptType = gptType;
            switch (gptType) {

                case FileSecurity:
                    gptEntry.keyName = "File System security settings";//No I18N
                    gptEntry.valueName = multivalueGptSettings(rawGptEntry, gptEntry);
                    gptEntry = gptEntry;
                    break;

                case GroupMembership:
                    gptEntry.keyName = "Restricted Groups";//No I18N
                    gptEntry.valueName = multivalueGptSettings(rawGptEntry, gptEntry);
                    gptEntry.sv = getGroupMembershipValue(gptEntry.valueName, gptEntry);
                    break;

                case RegistryKeys:
                    gptEntry.keyName = "Registry security settings";//No I18N
                    gptEntry.valueName = multivalueGptSettings(rawGptEntry, gptEntry);
                    break;

                case ServiceGeneralSetting:
                    gptEntry.keyName = "System Services security settings";//No I18N
                    gptEntry.valueName = multivalueGptSettings(rawGptEntry, gptEntry);
                    break;
                case PrivilegeRights:
                    parseAndSetGptKeyValue(values, gptEntry);
                    gptEntry.sv = JSONObjectUtil.toJsonString(gptEntry.valueName.split(","));
                    break;
                default:
                    parseAndSetGptKeyValue(values, gptEntry);
                    break;
            }
            return gptEntry;
        } catch (Exception e) {
            LogWriter.gpo.severe("Gpt File : " + e);
            return new GptEntry();
        }
    }

    public final String setGuidForSid(String valueName) {
        String[] splitValues = valueName.split(",");
        ArrayList<String> guidValues = new ArrayList<String>();
        String tempGuid;
        for (int i = 0; i < splitValues.length; i++) {
            try {
                tempGuid = LdapUtil.getPropertyFromSid(splitValues[i].substring(1, splitValues[i].length()), domainName, "objectGuid");//No I18N
                if (tempGuid == null) {
                    guidValues.add(splitValues[i]);
                } else {
                    guidValues.add(tempGuid.toUpperCase());
                }
            } catch (Exception e) {
                LogWriter.gpo.severe("Gpt File : " + e);
            }
        }
        return JSONObjectUtil.toJsonString(guidValues);
    }

    public final void parseAndSetGptKeyValue(String[] splitValues, GptEntry gptEntry) {
        if (splitValues.length == 2) {
            gptEntry.keyName = splitValues[0];
            gptEntry.valueName = splitValues[1];
        } else if (splitValues.length == 1) {
            if (splitValues[0].substring(splitValues[0].length() - 1).equals(" ")) {
                gptEntry.keyName = splitValues[0].substring(0, splitValues[0].length() - 1);
            } else {
                gptEntry.keyName = splitValues[0];
            }
            gptEntry.valueName = "";
        }
    }

    public final void saveFile() throws IOException {
        this.saveFile(null);
    }

    private void writeDefault(BufferedWriter br) throws IOException {
        br.write("[Unicode]");//No I18N
        br.newLine();
        br.write("Unicode = yes");//No I18N
        br.newLine();
        br.write("[Version]");//No I18N
        br.newLine();
        br.write("signature=\"$CHICAGO$\"");//No I18N
        br.newLine();
        br.write("Revision=1");//No I18N
        br.newLine();
    }

    public final void saveFile(String file) throws IOException {
        BufferedWriter brWriter = null;
        try {
            if (file == null || file.isEmpty()) {
                this.fileName = file;
            }

            File gptFile = new File(this.fileName);
            if (this.entries.size() > 0) {
                if (!gptFile.isFile()) {
                    gptFile.createNewFile();
                    brWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.fileName), "UTF-8"));
                    writeDefault(brWriter);
                } else {
                    brWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.fileName), "UTF-8"));
                }
                HashMap<String, GptEntry> gptValues = new HashMap<String, GptEntry>();
                String line;

                for (GptTmplType type : GptTmplType.values()) {
                    if (arrangeEntries.containsKey(type)) {
                        gptValues = arrangeEntries.get(type);
                        if (gptValues.size() > 0) {
                            brWriter.write(type.value);
                            brWriter.newLine();
                        } else {
                            continue;
                        }
                        for (Map.Entry<String, GptEntry> gptEntry : gptValues.entrySet()) {
                            if (gptEntry.getValue().gptType == GptTmplType.FileSecurity || gptEntry.getValue().gptType == GptTmplType.RegistryKeys || gptEntry.getValue().gptType == GptTmplType.ServiceGeneralSetting || gptEntry.getValue().gptType == GptTmplType.GroupMembership) {
                                ArrayList<String> allValues = new ArrayList<String>();
                                allValues = JSONObjectUtil.fromJsonString(gptEntry.getValue().valueName, allValues.getClass());
                                for (String val : allValues) {
                                    line = val;
                                    brWriter.write(line);
                                    brWriter.newLine();
                                }
                            } else {
                                line = gptEntry.getValue().keyName + " = " + gptEntry.getValue().valueName;
                                brWriter.write(line);
                                brWriter.newLine();
                            }
                        }
                    }
                }
            } else {
                if (gptFile.isFile()) {
                    brWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.fileName), "UTF-8"));
                    writeDefault(brWriter);
                }
                //AgentLogger.Gpo.Info("Gpo Restore Save File " + file + " No entries to write");
            }
            if (brWriter != null) {
                brWriter.close();
            }
        } catch (Exception e) {
            LogWriter.gpo.severe("Gpt File : " + e);
        } finally {
            if (brWriter != null) {
                brWriter.close();
            }
        }
    }

    @Override
    public GpoFileType getType() {
        return GpoFileType.Gpt;
    }

    @Override
    public Object fillPolicies(String rootFolder, GpoConfigType gpoUserMach, GpoFileType gpoFileType, String domainName, String dcName, String adminName, String password) {
        return fillPolicies(new File(rootFolder), gpoUserMach, gpoFileType, domainName, dcName, adminName, password);
    }

    @Override
    public Object fillPolicies(File rootFolder, GpoConfigType gpoUserMach, GpoFileType gpoFileType, String domainName, String dcName, String adminName, String password) {
        try {
            if (rootFolder != null) {
                String filePath = "";
                String pathType = gpoUserMach == GpoConfigType.Machine ? "Machine" : "User";//No I18N
                filePath = rootFolder + "\\DomainSysvol\\GPO\\" + pathType + "\\Microsoft\\Windows NT\\SecEdit\\GptTmpl.inf";//No I18N
                GptFile gptFile = new GptFile(domainName, dcName, adminName, password);
                gptFile.loadFile(filePath, gpoUserMach);
                //AgentLogger.Gpo.Info("FillPolicy : " + filePath);
                return gptFile;
            }
        } catch (Exception e) {
            LogWriter.gpo.severe("Gpt File : " + e);
        }
        return new GptFile();
    }
}
//ignoreI18n_end
