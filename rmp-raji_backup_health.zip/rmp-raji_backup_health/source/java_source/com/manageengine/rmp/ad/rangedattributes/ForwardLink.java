/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * $Id$
 */
package com.manageengine.rmp.ad.rangedattributes;

import java.util.ArrayList;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public enum ForwardLink {

    //Add Enum here and its AttributeMask for Forward Link Backup/Restore
//Add Enum here and its AttributeMask for Forward Link Backup/Restore

    member(74),
    managedBy(61),
    manager(44),
    records(87),
    gPLink(77),
    msExchModeratedByLink(162),
    none(-1);

    public int linkId;

    ForwardLink(int linkId) {
        this.linkId = linkId;
    }

    public String getAttributeName() {
        switch (this.linkId) {
            case 74:
                return "member";
            case 61:
                return "managedBy";
            case 44:
                return "manager";
            case 87:
                return "records";
            case 77:
                return "gPLink";
            case 162:
                return "msExchModeratedByLink";

            default:
                return "";
        }
    }

    public static String getAttributeName(int linkId) {
        return getForwardLink(linkId).getAttributeName();
    }

    public BackwardLink getBackwardLink() {
        switch (this) {
            case member:
                return BackwardLink.memberOf;
            case managedBy:
                return BackwardLink.managedObjects;
            case manager:
                return BackwardLink.directReports;
            case records:
                return BackwardLink.records;
            case gPLink:
                return BackwardLink.gpBackLinks;
            case msExchModeratedByLink:
                return BackwardLink.msExchModeratedObjectsBL;

            default:
                return BackwardLink.none;
        }
    }

    public static ForwardLink getForwardLink(int linkId) {
        switch (linkId) {
            case 12:
            case 74:
                return ForwardLink.member;
            case 13:
            case 61:
                return ForwardLink.managedBy;
            case 14:
            case 44:
                return ForwardLink.manager;
            case 87:
                return ForwardLink.records;
            case 77:
            case 100:
                return ForwardLink.gPLink;
            case 162:
            case 163:
                return ForwardLink.msExchModeratedByLink;

            default:
                return ForwardLink.none;
        }
    }

    public static boolean isForwardLink(int linkId) {
        if (linkId == 74 || linkId == 61 || linkId == 44 || linkId == 87 || linkId == 77 || linkId==162) {
            return true;
        }
        return false;
    }

    public static ArrayList<Integer> getValues() {
        ArrayList<Integer> forwardLink = new ArrayList<Integer>();
        for (ForwardLink link : ForwardLink.values()) {
            forwardLink.add(link.linkId);
        }
        return forwardLink;
    }
}

//ignoreI18n_end
