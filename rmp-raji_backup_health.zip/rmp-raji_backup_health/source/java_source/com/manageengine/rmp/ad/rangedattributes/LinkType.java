//$Id$
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.rangedattributes;

/**
 *
 * @author lucky-2306
 */
public enum LinkType {

    Total(0),
    Added(1),
    Removed(2),
    Modified(3);
    public int maskValue;
    public Long memberTypeId;

    LinkType(Integer memberTypeId) {
        this.memberTypeId = (long) memberTypeId;
        this.maskValue = (int) (memberTypeId == 0 ? 0L : 1 << memberTypeId - 1);
    }
    
    public static String getLinkRangeType(Long memberTypeId)
    {
        String linkRangeType = "";
        switch(memberTypeId.intValue()) {
            case 1:
                linkRangeType = LinkedAttributesUtil.ADDED_RANGE;
                break;
            case 2:
                linkRangeType = LinkedAttributesUtil.REMOVED_RANGE;
                break;
            case 3:
                linkRangeType = LinkedAttributesUtil.MODIFIED_RANGE;
                break;
        }
        return linkRangeType;
    }
}
