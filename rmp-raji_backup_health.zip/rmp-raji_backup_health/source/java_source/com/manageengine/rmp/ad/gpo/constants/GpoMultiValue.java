/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.constants;

/**
 *
 * @author vincy-4480
 */
public enum GpoMultiValue {
    Unknown(0),
    FileSystem(6024),
    Registry(6113),
    RestrictedGroups(6120),
    SystemServices(6131),
    Accessthiscomputerfromthenetwork(6132),
    AccessCredentialManagerasatrustedcaller(6133),
    Actaspartoftheoperatingsystem(6134),
    Addworkstationstoadomain(6135),
    Adjustmemoryquotasforaprocess(6136),
    Allowlogonlocally(6137),
    AllowlogonthroughRemoteDesktopServices(6138),
    Backupfilesanddirectories(6139),
    Bypasstraversechecking(6140),
    Changethesystemtime(6141),
    Changethetimezone(6142),
    Createapagefile(6143),
    Createatokenobject(6144),
    Createglobalobjects(6145),
    Createpermanentsharedobjects(6146),
    CreateSymbolicLinks(6147),
    Debugprograms(6148),
    Denyaccesstothiscomputerfromthenetwork(6149),
    Denylogonasabatchjob(6150),
    Denylogonasaservice(6151),
    Denylogonlocally(6152),
    DenylogonthroughRemoteDesktopServices(6153),
    Enablecomputeranduseraccountstobetrustedfordelegation(6154),
    Forceshutdownfromaremotesystem(6155),
    Generatesecurityaudits(6156),
    Impersonateaclientafterauthentication(6157),
    Increaseaprocessworkingset(6158),
    Increaseschedulingauthority(6159),
    Loadandunloaddevicedrivers(6160),
    Lockpagesinmemory(6161),
    Logonasabatchjob(6162),
    Logonasaservice(6163),
    Logonlocally(6164),
    Manageauditingandsecuritylog(6165),
    Modifyanobjectlabel(6166),
    Modifyfirmwareenvironmentvalues(6167),
    Performvolumemaintenancetasks(6168),
    Profilesingleprocess(6169),
    Profilesystemperformance(6170),
    Removecomputerfromdockingstation(6171),
    Replaceaprocessleveltoken(6172),
    Restorefilesanddirectories(6173),
    Shutdownthesystem(6174),
    Synchronizedirectoryservicedata(6175),
    Takeownershipoffilesorotherobjects(6176);

    public int id;
    
    GpoMultiValue(int id)
    {
        this.id = id;
    }

    public static GpoMultiValue getType(String GpoVal)
    {
        switch(GpoVal)
        {
            case "File System"://No I18N
                return FileSystem;
            case "Registry"://No I18N
                return Registry;
            case "Restricted Groups"://No I18N
                return RestrictedGroups;
            case "System Services"://No I18N
                return SystemServices;
            case "Access this computer from the network"://No I18N
                return Accessthiscomputerfromthenetwork;
            case "Access Credential Manager as a trusted caller"://No I18N
                return AccessCredentialManagerasatrustedcaller;
            case "Act as part of the operating system"://No I18N
                return Actaspartoftheoperatingsystem;
            case "Add workstations to a domain"://No I18N
                return Addworkstationstoadomain;
            case "Adjust memory quotas for a process"://No I18N
                return Adjustmemoryquotasforaprocess;
            case "Allow log on locally"://No I18N
                return Allowlogonlocally;
            case "Allow log on through Remote Desktop Services"://No I18N
                return AllowlogonthroughRemoteDesktopServices;
            case "Backup files and directories"://No I18N
                return Backupfilesanddirectories;
            case "Bypass traverse checking"://No I18N
                return Bypasstraversechecking;
            case "Change the system time"://No I18N
                return Changethesystemtime;
            case "Change the time zone"://No I18N
                return Changethetimezone;
            case "Create a pagefile"://No I18N
                return Createapagefile;
            case "Create a token object"://No I18N
                return Createatokenobject;
            case "Create global objects"://No I18N
                return Createglobalobjects;
            case "Create permanent shared objects"://No I18N
                return Createpermanentsharedobjects;
            case "Create Symbolic Links"://No I18N
                return CreateSymbolicLinks;
            case "Debug programs"://No I18N
                return Debugprograms;
            case "Deny access to this computer from the network"://No I18N
                return Denyaccesstothiscomputerfromthenetwork;
            case "Deny log on as a batch job"://No I18N
                return Denylogonasabatchjob;
            case "Deny log on as a service"://No I18N
                return Denylogonasaservice;
            case "Deny log on locally"://No I18N
                return Denylogonlocally;
            case "Deny log on through Remote Desktop Services"://No I18N
                return DenylogonthroughRemoteDesktopServices;
            case "Enable computer and user accounts to be trusted for delegation"://No I18N
                return Enablecomputeranduseraccountstobetrustedfordelegation;
            case "Force shutdown from a remote system"://No I18N
                return Forceshutdownfromaremotesystem;
            case "Generate security audits"://No I18N
                return Generatesecurityaudits;
            case "Impersonate a client after authentication"://No I18N
                return Impersonateaclientafterauthentication;
            case "Increase a process working set"://No I18N
                return Increaseaprocessworkingset;
            case "Increase scheduling authority"://No I18N
                return Increaseschedulingauthority;
            case "Load and unload device drivers"://No I18N
                return Loadandunloaddevicedrivers;
            case "Lock pages in memory"://No I18N
                return Lockpagesinmemory;
            case "Log on as a batch job"://No I18N
                return Logonasabatchjob;
            case "Log on as a service"://No I18N
                return Logonasaservice;
            case "Log on locally"://No I18N
                return Logonlocally;
            case "Manage auditing and security log"://No I18N
                return Manageauditingandsecuritylog;
            case"Modify an object label"://No I18N
                return Modifyanobjectlabel;
            case "Modify firmware environment values"://No I18N
                return Modifyfirmwareenvironmentvalues;
            case "Perform volume maintenance tasks"://No I18N
                return Performvolumemaintenancetasks;
            case "Profile single process"://No I18N
                return Profilesingleprocess;
            case "Profile system performance"://No I18N
                return Profilesystemperformance;
            case "Remove computer from docking station"://No I18N
                return Removecomputerfromdockingstation;
            case "Replace a process level token"://No I18N
                return Replaceaprocessleveltoken;
            case "Restore files and directories"://No I18N
                return Restorefilesanddirectories;
            case "Shut down the system"://No I18N
                return Shutdownthesystem;
            case "Synchronize directory service data"://No I18N
                return Synchronizedirectoryservicedata;
            case "Take ownership of files or other objects"://No I18N
                return Takeownershipoffilesorotherobjects;
            default:
                return Unknown;
        }
    }
}
