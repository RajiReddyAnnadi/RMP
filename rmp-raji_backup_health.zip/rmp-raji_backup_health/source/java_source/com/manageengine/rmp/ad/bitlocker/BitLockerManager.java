package com.manageengine.rmp.ad.bitlocker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Properties;

import com.adventnet.persistence.DataAccessException;
import com.manageengine.ads.fw.jni.ADSNativeHandler;
import com.manageengine.ads.fw.ldap.ad.ADSADErrorHandler;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.ad.backup.BackupUtil;
import com.manageengine.rmp.ad.backup.BackupImpl;
import com.manageengine.rmp.ad.rangedattributes.LinkedAttributesUtil;
import com.manageengine.rmp.constants.BackupType;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.dataobjects.BitLockerObject;
import com.manageengine.rmp.errors.RMPErrorId;
import com.manageengine.rmp.util.GeneralUtil;
import com.manageengine.rmp.util.LdapUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import com.manageengine.rmp.recovery.RecoveryHandler;

/**
 *
 * $Id$
 * 
* @author balachandar-3185
 */
public class BitLockerManager {

    public HashMap<String, ArrayList<BitLockerObject>> bitLockerDict;
    public Long domainId;
    private Properties domainDetails;

    public BitLockerManager(Long domainId) {
        bitLockerDict = new HashMap<String, ArrayList<BitLockerObject>>();
        this.domainId = domainId;
    }

    public BitLockerManager(Properties domainDetails) {
        this.domainDetails = domainDetails;
    }

    public Boolean addBitLockerObject(Properties prop, BackupImpl backupImpl, BackupObject backupObject) {
        try {
            if (prop.containsKey("isDeleted") && BackupUtil.getBoolean(prop, "isDeleted") != null && BackupUtil.getBoolean(prop, "isDeleted")) {
                if (backupImpl.backupType != BackupType.InitBackup) {
                    if (BackupUtil.getSingleValue(prop, "isDeleted") != null && BackupUtil.getSingleValue(prop, "isDeleted").toString().equalsIgnoreCase("1")) {
                        String lastKnownParentGuid = new String();
                        String lastKnownParentDn = new String();
                        if(backupObject.lastKnownParent!=null && !(backupObject.lastKnownParent.endsWith("CN=Deleted Objects,"+backupImpl.defaultNamingContext))) {
                            lastKnownParentDn = backupObject.lastKnownParent;
                        }
                        else if (prop.containsKey("lastKnownParent")) {
                            lastKnownParentDn = GeneralUtil.getADProperty(prop, "lastKnownParent");//No I18N
                        } else {
                            lastKnownParentDn = GeneralUtil.getObjectDnFromGuid(backupObject.objId.toString(),domainId);
                        }
                        LinkedAttributesUtil.updateRangedAttrMetaData(backupObject.objId.toString(), lastKnownParentDn, domainId,backupObject.backupId);
                        UUID lastKnownParentGuidTemp = LinkedAttributesUtil.getGuidForDN(lastKnownParentDn, domainId);
                        if(lastKnownParentGuidTemp!=null) {
                            lastKnownParentGuid = lastKnownParentGuidTemp.toString();
                        }
                        BitLockerObject bitLockerObjectTemp = new BitLockerObject(backupObject.objId.toString(), lastKnownParentGuid, backupObject.isDeleted);
                        if (bitLockerDict.containsKey(lastKnownParentGuid)) {
                            bitLockerDict.get(lastKnownParentGuid).add(bitLockerObjectTemp);
                        } else {
                            ArrayList<BitLockerObject> tempList = new ArrayList<BitLockerObject>();
                            tempList.add(bitLockerObjectTemp);
                            bitLockerDict.put(lastKnownParentGuid, tempList);
                        }
                    } else {
                        Properties domainProp = RMPDomainHandler.getDomainDetailsById(domainId);
                        ArrayList<String> attribute = new ArrayList<String>();
                        attribute.add("objectGUID");//No I18N
                        attribute.add("distinguishedName");//No I18N
                        attribute.add("msFVE-RecoveryPassword");//No I18N
                        attribute.add("msFVE-RecoveryGuid");//No I18N
                        attribute.add("msFVE-VolumeGuid");//No I18N
                        attribute.add("msFVE-KeyPackage");//No I18N
                        ArrayList<Properties> linkAttributes = new ArrayList<Properties>();
                        linkAttributes = ADSNativeHandler.getObjectsWithOutListener(domainProp, GeneralUtil.getADProperty(prop, "distinguishedName"), attribute, "(objectClass=msFVE-RecoveryInformation)");//No I18N
                        String tempGuid = GeneralUtil.getADProperty(linkAttributes.get(0), "objectGUID");//No I18N
                        BitLockerObject bitLockerObjectTemp = new BitLockerObject(UUID.fromString(tempGuid.substring(1, tempGuid.length() - 1)).toString(), linkAttributes.get(0));
                        String parentGuid = backupObject.ouId.toString();
                        if (bitLockerDict.containsKey(parentGuid)) {
                            bitLockerDict.get(parentGuid).add(bitLockerObjectTemp);
                        } else {
                            ArrayList<BitLockerObject> tempList = new ArrayList<BitLockerObject>();
                            tempList.add(bitLockerObjectTemp);
                            bitLockerDict.put(parentGuid, tempList);
                        }
                    }

                } else {
                    return true;
                }

            } else {
                if(backupObject.lastKnownParent!=null) {
                    LinkedAttributesUtil.updateRangedAttrMetaData(backupObject.objId.toString(), backupObject.lastKnownParent, domainId,backupObject.backupId);
                }
                BitLockerObject bitLockerObjectTemp = new BitLockerObject(backupObject.objId.toString(), prop);
                String parentGuid = backupObject.ouId.toString();
                if (bitLockerDict.containsKey(parentGuid)) {
                    bitLockerDict.get(parentGuid).add(bitLockerObjectTemp);
                } else {
                    ArrayList<BitLockerObject> tempList = new ArrayList<BitLockerObject>();
                    tempList.add(bitLockerObjectTemp);
                    bitLockerDict.put(parentGuid, tempList);
                }
            }
        } catch (DataAccessException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return true;
    }

    public Boolean updateBitLockerInBackup(BackupImpl backupImpl) {
        return backupImpl.backupUpdater.updateBitLockerInComputer(bitLockerDict, backupImpl);
    }

    public Boolean restoreBitLockerObject(Object currentValue, Object restoreValue, String computerDN, Properties domainDetails,RecoveryHandler recoveryHandler) throws Exception
    {
        Boolean result = true;
        HashMap<String, ArrayList> bitLockerCurrent = new HashMap<String, ArrayList>();
        bitLockerCurrent = JSONObjectUtil.fromJsonString(currentValue.toString(), bitLockerCurrent.getClass());
        HashMap<String, ArrayList> bitLockerRestore = new HashMap<String, ArrayList>();
        bitLockerRestore = JSONObjectUtil.fromJsonString(restoreValue.toString(), bitLockerRestore.getClass());
        ArrayList<String> toRemove = new ArrayList<String>(bitLockerCurrent.keySet());
        ArrayList<String> toAdd = new ArrayList<String>(bitLockerRestore.keySet());
        ArrayList<String> temp = new ArrayList<String>(toAdd);
        temp.retainAll(toRemove);

        toAdd.removeAll(temp);
        toRemove.removeAll(temp);
        if (toAdd.size() == 0 && toRemove.size() == 0) {
            toAdd = new ArrayList<String>(bitLockerRestore.keySet());
            temp = new ArrayList<String>(toAdd);
            try {
                ArrayList keyList = ADSNativeHandler.executeADQuery(domainDetails, new String[]{"objectGUID"}, "(objectClass=msFVE-RecoveryInformation)", computerDN); //No I18N
                for (int i = 0; i < keyList.size(); i++) {
                    Properties prop = (Properties) keyList.get(i);
                    toRemove.add(BackupUtil.getGuid(prop, "objectGUID").toString()); //No I18N
                }
                temp.retainAll(toRemove);
                toAdd.removeAll(temp);
                toRemove.removeAll(temp);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        for (String objGuid : toRemove) {
            ADSADErrorHandler errHandler = ADSNativeHandler.deleteObject(domainDetails, bitLockerCurrent.get(objGuid).get(0).toString());
            if (errHandler.getErrors() == null || errHandler.getErrors().isEmpty()) {
                result = result && true;
            }
        }
        for (String objGuid : toAdd) {
            try {
                long errorCode = ADSNativeHandler.restoreDeletedObject(domainDetails, LdapUtil.getDeletedObjectDN(bitLockerRestore.get(objGuid).get(0).toString(), objGuid), bitLockerRestore.get(objGuid).get(0).toString());
                
                Logger.getLogger(ADSNativeHandler.class.getName()).log(Level.INFO, "ErrorCode: ", errorCode);
                if (errorCode != 0 )// LDAP_SUCCESS =0, LDAP_ALREADY_EXISTS = 68
                {
                    result = result && true;
                }
                else{
                 recoveryHandler.recoverObjErrorId.add(RMPErrorId.getErrorMsgFromNativeErrorCode(errorCode));
                }
            } catch (Exception e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return result;
    }
}
