/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.parser;

import java.io.Serializable;

/**
 *
 * @author lucky-2306
 */
public class AuditEntry extends AbstractGpoEntry implements Serializable {

    public String machineName;
    public String policyTarget;
    public String subcategory;
    public String subcategoryGUID;
    public String inclusionSetting;
    public String exclusionSetting;
    public String settingValue;

    @Override
    public boolean compareTo(AbstractGpoEntry gpoEntry) {
        return this.valueName.equals(gpoEntry.valueName) && (this.gpoAddRem.addRemId == gpoEntry.gpoAddRem.addRemId);
    }
}
