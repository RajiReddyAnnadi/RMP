package com.manageengine.rmp.ad.backup;

import java.io.ByteArrayInputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.DateUtil;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.licensing.EditionType;
import com.manageengine.rmp.licensing.ProductSubscriptionInfo;
import com.manageengine.rmp.ad.rangedattributes.LinkedAttributesUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.BackupType;
import com.manageengine.rmp.constants.ChangeType;
import com.manageengine.rmp.constants.OperationStatus;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.dataobjects.BitLockerObject;
import com.manageengine.rmp.dataobjects.LdapAttribute;
import com.manageengine.rmp.dataobjects.OperationInfo;
import com.manageengine.rmp.ad.rangedattributes.RangedAttrObject;
import com.manageengine.rmp.common.RMPCommonUtil;
import com.manageengine.rmp.common.querygenerator.FiletoDBImporter;
import com.manageengine.rmp.common.querygenerator.NoSqlWriterObject;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.scheduler.BackupScheduler;
import com.manageengine.rmp.util.BitSetUtil;
import com.manageengine.rmp.util.GeneralUtil;
import com.manageengine.rmp.util.LdapUtil;

import java.util.Date;
import javax.naming.ldap.LdapName;

/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
//ignoreI18n_start
public class BackupUpdater implements Cloneable{
    public Long domainId, backupId;
    public int maxBatchCount;
    private BackupImpl backupHook;
    protected FiletoDBImporter dbImporter;
    private ArrayList<ArrayList<BackupObject>> backupObjects;
    private Boolean isBatchEnabled;
    private Boolean isFreeEdition;
    public OperationInfo backupOperation;

    public BackupUpdater() {
    }
    
    public BackupUpdater(Long domainId, OperationInfo backupOp, BackupImpl backupHook) {
        maxBatchCount = 100;
        this.isBatchEnabled = false;
        this.backupOperation = backupOp;
        this.domainId = domainId;
        this.backupId = backupOp.operationId;
        this.backupHook = backupHook;
        this.dbImporter = new FiletoDBImporter();
        dbImporter.backupFileWriterInit(domainId);
        this.isFreeEdition = ProductSubscriptionInfo.subscriptionType == EditionType.Free.ordinal();
        backupObjects = new ArrayList();
        LogWriter.backup.info(String.format("BackupUpdater initialized domainId: %s, backupId: %s, isFreeEdition: %s ", domainId, backupId, isFreeEdition));
    }
    
     public BackupUpdater clone(){
        try{
            BackupUpdater backupUpdater = (BackupUpdater) super.clone();
            backupUpdater.dbImporter = (FiletoDBImporter) backupUpdater.dbImporter.clone();
            return backupUpdater;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
     
    public Boolean initiateTempTableWriterObj(String tableCurr, String tableVer,String attribInfo) {
        return dbImporter.tempTableWriterObjInit(tableCurr, tableVer, attribInfo);
    }

    public Boolean updateTempTableObjCurr(String objectGuid, BitSet changeMask, JsonObject linksData, String currentInfoId) {
        return dbImporter.updateTempTableObjCurr(this.domainId, objectGuid, changeMask, linksData, currentInfoId, BitSetUtil.bitSetToHexadecimalString(changeMask));
    }

    public Boolean updateTempTableObjVer(Long changeId, BitSet changeMask, JsonObject linksData, String uniqueId) {
        return dbImporter.updateTempTableObjVer(domainId, this.backupId, changeId, changeMask, linksData, uniqueId, BitSetUtil.bitSetToHexadecimalString(changeMask));
    }

    public Boolean updateRangedAttrMetadatainObj(Map<String, RangedAttrObject> linkedAttrList, BackupImpl backupImpl, boolean isForwardLink, boolean isFullSync) {
        try {
            float ceil =(float) linkedAttrList.size() / (float)RMPCommonUtil.MAX_BATCH_DUMP_COUNT;
            int loopCount = (int) Math.ceil(ceil);
            if(loopCount > 0){
                SelectQuery selectVerAndCur = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_VER_INFO+"_"+domainId));
                Join join = new Join(TableName.RMP_OBJ_VER_INFO+"_"+domainId, TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, new String[]{"OBJECT_GUID"}, new String[]{"OBJECT_GUID"}, Join.INNER_JOIN);
                selectVerAndCur.addJoin(join);
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CHANGE_MASK"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "LINKS_DATA"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "UNIQUE_ID"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "BACKUP_ID"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "CHANGE_ID"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "CHANGE_MASK"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "LINKS_DATA"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "OBJECT_GUID"));
                selectVerAndCur.addSortColumn(new SortColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"), true));
                Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "BACKUP_ID"), backupId, QueryConstants.EQUAL);
                Criteria objectCriteria;
                List<String> objectGuids = null;
                int startCount, endCount;
                for(int i = 0; i < loopCount; i++){
                    if(objectGuids == null){
                        objectGuids = new ArrayList(linkedAttrList.keySet());
                    }
                    startCount = RMPCommonUtil.MAX_BATCH_DUMP_COUNT * i;
                    endCount = (RMPCommonUtil.MAX_BATCH_DUMP_COUNT * i) + RMPCommonUtil.MAX_BATCH_DUMP_COUNT;
                    if(objectGuids.size() >= endCount){
                        objectCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "OBJECT_GUID"), objectGuids.subList(startCount, endCount).toArray(new String[endCount-startCount]) , QueryConstants.IN, false);
                    }else{
                        endCount = objectGuids.size();
                        objectCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "OBJECT_GUID"), objectGuids.subList(startCount, objectGuids.size()).toArray(new String[endCount-startCount]) , QueryConstants.IN, false);
                    }                
                    selectVerAndCur.setCriteria(criteria .and(objectCriteria));
                    DataObject dobVersion = DataAccess.get(selectVerAndCur);
                    if (dobVersion.isEmpty()) {
                        LogWriter.backup.info("dob is empty domain id" + domainId + " backup id" + backupId);
                    } else {
                        linkedAttrList = LinkedAttributesUtil.updateRangedObjectInBackup(linkedAttrList, dobVersion, domainId, backupId, isForwardLink, this);
                    }
                }
                LinkedAttributesUtil.updateRangedObjectNotInBackup(linkedAttrList, backupImpl, isForwardLink, backupId, isFullSync);
            }
        } catch (Exception e) {
            LogWriter.backup.severe("line 95 exception backup updater. updateGroupMemberMetadata " + e);
            e.printStackTrace();
        }
        return true;
    }

    public Boolean updateBitLockerInComputer(HashMap<String, ArrayList<BitLockerObject>> bitLockerDict, BackupImpl backupImpl) {
        String[] objGuid = bitLockerDict.keySet().toArray(new String[0]);

        try {
            SelectQuery selectVerAndCur = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_VER_INFO+"_"+domainId));
            Join join = new Join(TableName.RMP_OBJ_VER_INFO+"_"+domainId, TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, new String[]{ "OBJECT_GUID"}, new String[]{"OBJECT_GUID"}, Join.INNER_JOIN);
            selectVerAndCur.addJoin(join);
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "BACKUP_ID"), backupId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "OBJECT_GUID"), objGuid, QueryConstants.IN, false);
            selectVerAndCur.setCriteria(criteria);
            selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "UNIQUE_ID"));
            selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "CHANGE_ID"));
            selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "OBJECT_GUID"));
            selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "CHANGE_MASK"));
            selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "LINKS_DATA"));
            selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"));
            selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CHANGE_MASK"));
            selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "LINKS_DATA"));
             selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"));
            DataObject dobVersion = DataAccess.get(selectVerAndCur);
            if (!dobVersion.isEmpty()) {
                List<String> currCols = new ArrayList<String>();
                currCols.add("CURRENTINFO_ID");
                currCols.add("OBJECT_GUID");
                currCols.add("CHANGE_MASK");
                currCols.add("LINKS_DATA");
                DBUtil.createTable(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId,"_temp", currCols,false,false);
                List<String> verCols = new ArrayList<String>();
                verCols.add("UNIQUE_ID");
                verCols.add("BACKUP_ID");
                verCols.add("CHANGE_ID");
                verCols.add("CHANGE_MASK");
                verCols.add("LINKS_DATA");
                DBUtil.createTable(TableName.RMP_OBJ_VER_INFO+"_"+domainId,"_temp", verCols,false,false);
                initiateTempTableWriterObj(DBUtil.getTempTableName(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId), DBUtil.getTempTableName(TableName.RMP_OBJ_VER_INFO+"_"+domainId),TableName.RMP_ATTRIBUTES_BACKUP_INFO+"_"+domainId);

                Iterator verIterator = dobVersion.getRows(TableName.RMP_OBJ_VER_INFO+"_"+domainId);
                while (verIterator.hasNext()) {
                    String tempJson;
                    ByteArrayInputStream tempByteInputStream;
                    byte[] tempByte;
                    
                    //get row data for updation
                    Row rowVersion = (Row) verIterator.next();
                    Criteria objectCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"), (String)rowVersion.get("OBJECT_GUID"), QueryConstants.EQUAL);
                    Row rowCurrent = dobVersion.getRow(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, objectCriteria);

                    tempJson = (String) rowVersion.get("LINKS_DATA");
                    JsonObject dataVersion = (JsonObject) new JsonParser().parse(tempJson);
                    //get bitset for updation
                    tempByteInputStream = (ByteArrayInputStream) rowVersion.get("CHANGE_MASK");
                    tempByte = IOUtils.toByteArray(tempByteInputStream);
                    BitSet changeMaskVersion = BitSetUtil.fromByteArray(tempByte);
                    //get json for updation
                    tempJson = (String) rowCurrent.get("LINKS_DATA");
                    JsonObject dataCurrent = (JsonObject) new JsonParser().parse(tempJson);
                    //get current biset for updation
                    tempByteInputStream = (ByteArrayInputStream) rowCurrent.get("CHANGE_MASK");
                    tempByte = IOUtils.toByteArray(tempByteInputStream);
                    BitSet changeMaskCurrent = BitSetUtil.fromByteArray(tempByte);

                    //values setters for updation
                    //update bitset
                    changeMaskVersion.set(LdapAttribute.BitLocker.ldapAttributeId, true);
                    //update current info
                    if (dataCurrent.has("b" + LdapAttribute.BitLocker.ldapAttributeId)) {
                        dataCurrent.addProperty("o" + LdapAttribute.BitLocker.ldapAttributeId, dataCurrent.get("b" + LdapAttribute.BitLocker.ldapAttributeId).toString());
                        dataVersion.addProperty("o" + LdapAttribute.BitLocker.ldapAttributeId, dataCurrent.get("b" + LdapAttribute.BitLocker.ldapAttributeId).toString());
                        HashMap<String, ArrayList<String>> tempMapforBitLocker = new HashMap<String, ArrayList<String>>();
                        tempMapforBitLocker = JSONObjectUtil.fromJsonString(dataCurrent.get("b" + LdapAttribute.BitLocker.ldapAttributeId).getAsString(), tempMapforBitLocker.getClass());
                        for (BitLockerObject bitLockerObj : bitLockerDict.get(rowVersion.get("OBJECT_GUID"))) {
                            if (bitLockerObj.isDeleted == false) {
                                tempMapforBitLocker.put(bitLockerObj.objectGuid, bitLockerObj.arraySerialize());
                            } else {
                                tempMapforBitLocker.remove(bitLockerObj.objectGuid);
                            }
                        }
                        dataCurrent.addProperty("b" + LdapAttribute.BitLocker.ldapAttributeId, JSONObjectUtil.toJsonString(tempMapforBitLocker));
                        dataVersion.addProperty("b" + LdapAttribute.BitLocker.ldapAttributeId, JSONObjectUtil.toJsonString(tempMapforBitLocker));

                    }
                    else {
                        HashMap<String, ArrayList<String>> tempMapforBitLocker = new HashMap<String, ArrayList<String>>();
                        ArrayList<BitLockerObject> tempListForObj = bitLockerDict.get(rowVersion.get("OBJECT_GUID"));
                        for (BitLockerObject bitLockerObj : tempListForObj) {
                            if (bitLockerObj.isDeleted == false) {
                                tempMapforBitLocker.put(bitLockerObj.objectGuid, bitLockerObj.arraySerialize());
                            } else {
                                tempMapforBitLocker.remove(bitLockerObj.objectGuid);
                            }
                        }
                        dataCurrent.addProperty("b" + LdapAttribute.BitLocker.ldapAttributeId, JSONObjectUtil.toJsonString(tempMapforBitLocker));
                        dataVersion.addProperty("b" + LdapAttribute.BitLocker.ldapAttributeId, JSONObjectUtil.toJsonString(tempMapforBitLocker));
                    }
                    //

                    //update current bitset
                    if (!changeMaskCurrent.get(LdapAttribute.BitLocker.ldapAttributeId)) {
                        changeMaskCurrent.set(LdapAttribute.BitLocker.ldapAttributeId, true);
                    }

                    updateTempTableObjCurr(rowVersion.get("OBJECT_GUID").toString(), changeMaskCurrent, dataCurrent, rowCurrent.get("CURRENTINFO_ID").toString());
                    updateTempTableObjVer(Long.parseLong(rowVersion.get("CHANGE_ID").toString()), changeMaskVersion, dataVersion, rowVersion.get("UNIQUE_ID").toString());
                    updateAttributeInfo(UUID.fromString(rowVersion.get("OBJECT_GUID").toString()),Integer.parseInt(rowVersion.get("CHANGE_ID").toString()), LdapAttribute.BitLocker.ldapAttributeId);
                    bitLockerDict.remove(rowVersion.get("OBJECT_GUID"));
                }
                dumpTempTables();
                List<String> columns = new ArrayList<String>();
                columns.add("CHANGE_MASK");
                columns.add("LINKS_DATA");
                DBUtil.updateDB(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, DBUtil.getTempTableName(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId), columns);
                DBUtil.updateDB(TableName.RMP_OBJ_VER_INFO+"_"+domainId, DBUtil.getTempTableName(TableName.RMP_OBJ_VER_INFO+"_"+domainId), columns);
                dumpAttribInfoTable();
                DBUtil.dropTempTable(DBUtil.getTempTableName(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId));
                DBUtil.dropTempTable(DBUtil.getTempTableName(TableName.RMP_OBJ_VER_INFO+"_"+domainId));
            } else {
                LogWriter.backup.info("Error empty");
            }
            //objects not in backup
            for (Map.Entry<String, ArrayList<BitLockerObject>> mapBitLocker : bitLockerDict.entrySet()) {
                Properties tempProp = new Properties();
                ArrayList<String> guid = new ArrayList<String>();
                if (GeneralUtil.getStringAsArrayList(mapBitLocker.getKey()) != null) {
                    tempProp.put("objectGUID", GeneralUtil.getStringAsArrayList(mapBitLocker.getKey()));
                }

                SelectQuery selectCur = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId));
                selectCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "*"));
                Criteria criteriaCurrent = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_GUID"), mapBitLocker.getKey(), QueryConstants.EQUAL, false);
                selectCur.setCriteria(criteriaCurrent);
                DataObject dobCurrent = DataAccess.get(selectCur);
                Row rowCurrent = dobCurrent.getFirstRow(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId);

                String tempJson = (String) rowCurrent.get("LINKS_DATA");
                JsonObject dataCurrent = (JsonObject) new JsonParser().parse(tempJson);
                tempJson = (String) rowCurrent.get("CHANGE_DATA");
                JsonObject datadn = (JsonObject) new JsonParser().parse(tempJson);

                HashMap<String, ArrayList<String>> tempMapforBitLocker = new HashMap<String, ArrayList<String>>();
                if (dataCurrent.has("b" + LdapAttribute.BitLocker.ldapAttributeId)) {
                    tempMapforBitLocker = JSONObjectUtil.fromJsonString(dataCurrent.get("b" + LdapAttribute.BitLocker.ldapAttributeId).getAsString(), tempMapforBitLocker.getClass());
                }
                if(datadn.has("dn")) {
                    tempProp.put("distinguishedName", GeneralUtil.getStringAsArrayList(datadn.get("dn").getAsString()));
                } else {  // for deleted obejcts which have no history dn not formed
                    continue;
                }
                for (BitLockerObject bitLockerObj : bitLockerDict.get(mapBitLocker.getKey())) {
                    if (bitLockerObj.isDeleted == false) {
                        tempMapforBitLocker.put(bitLockerObj.objectGuid, bitLockerObj.arraySerialize());
                    } else {
                        tempMapforBitLocker.remove(bitLockerObj.objectGuid);
                    }
                }
                tempProp.put("bitLockerRecoveryInformation", GeneralUtil.getStringAsArrayList(JSONObjectUtil.toJsonString(tempMapforBitLocker)));
                tempProp.put("objectType", "Computer");
                backupImpl.addRow(tempProp);
            }

        } catch (Exception e) {
            LogWriter.backup.severe("line 226 exception backup updater. updateGroupMemberMetadata " + e);
            e.printStackTrace();
        }
        return true;
    }

    public Boolean updateBackupStartInfo(OperationInfo backupInfo) {
        try {
            DataObject dataObject = new WritableDataObject();
            Row row = new Row(TableName.RMP_OPERATION_INFO);
            row.set("DOMAIN_ID", backupInfo.domainId);
            row.set("OPERATION_ID", backupInfo.operationId);
            row.set("OPERATION_TYPE", backupInfo.operationType.ordinal());
            row.set("COUNTS", backupInfo.count);
            row.set("START_TIME", backupInfo.startTimeToTimestamp());//ToDo: get the next scheduled backup time from scheduler
            row.set("TIME_TAKEN", backupInfo.timeTaken);
            row.set("STATUS", backupInfo.status.ordinal());
            row.set("STATUS_ID", backupInfo.statusId);
            row.set("INITIATOR", backupInfo.initiator);
            row.set("DATA", "{}");
            dataObject.addRow(row);
            CommonUtil.getPersistence().add(dataObject);
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe(String.format("BackupUpdater.updateBackupStartInfo domainId:%s backupId:%s initiator:%s /n ex:%s", backupInfo.domainId, backupInfo.operationId, backupInfo.initiator, e));
        }
        return false;
    }
    
    public Boolean updateFinalInfo(OperationInfo backupInfo) {
        try {
            UpdateQuery updateObj = new UpdateQueryImpl(TableName.RMP_OPERATION_INFO);
            updateObj.setUpdateColumn("COUNTS", backupInfo.count);
            updateObj.setUpdateColumn("TIME_TAKEN", backupInfo.timeTaken);
            updateObj.setUpdateColumn("STATUS", backupInfo.status.ordinal());
            updateObj.setUpdateColumn("STATUS_ID", backupInfo.statusId);
            updateObj.setUpdateColumn("DATA", backupInfo.data);
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.RMP_OPERATION_INFO, "DOMAIN_ID"), backupInfo.domainId, QueryConstants.EQUAL);
            Criteria operationIdCriteria = new Criteria(Column.getColumn(TableName.RMP_OPERATION_INFO, "OPERATION_ID"), backupInfo.operationId, QueryConstants.EQUAL);
            updateObj.setCriteria(domainCriteria.and(operationIdCriteria));
            CommonUtil.getPersistence().update(updateObj);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.updateFinalInfo " + e);
            return false;
        }
    }
    
    public Boolean updateBackupProgressInfo(OperationInfo backupInfo){
        try {
            UpdateQuery updateObj = new UpdateQueryImpl(TableName.RMP_OPERATION_INFO);
            updateObj.setUpdateColumn("COUNTS", backupInfo.count);
            updateObj.setUpdateColumn("DATA", backupInfo.data);
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.RMP_OPERATION_INFO, "DOMAIN_ID"), backupInfo.domainId, QueryConstants.EQUAL);
            Criteria operationIdCriteria = new Criteria(Column.getColumn(TableName.RMP_OPERATION_INFO, "OPERATION_ID"), backupInfo.operationId, QueryConstants.EQUAL);
            updateObj.setCriteria(domainCriteria.and(operationIdCriteria));
            CommonUtil.getPersistence().update(updateObj);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.updateBackupProgressInfo " + e);
            return false;
        }
    }

    public Boolean updateBackupFinalInfo(OperationInfo backupInfo, Boolean isInitialBackup) throws JSONException {
        try {
            updateFinalInfo(backupInfo);
            if ((backupInfo.status != OperationStatus.Failed) || (backupInfo.status == OperationStatus.Failed && backupInfo.count > 0)) {
                updateBackupStat(backupInfo, isInitialBackup);
           }
            dumpObjectVersionData();
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.UpdateBackupFinalInfo "+e);
        }
        return false;
    }

    private Boolean updateBackupStat(OperationInfo backupInfo, Boolean isInitialBackup) {
        try {
            Row row;
            if (isInitialBackup) {
                DataObject dataObject = new WritableDataObject();
                row = new Row(TableName.RMP_BACKUP_STAT);
                row.set("DOMAIN_ID", domainId);
                row.set("OLDEST_BACKUP_ID", backupInfo.operationId);
                row.set("LATEST_BACKUP_ID", backupInfo.operationId);
                row.set("LAST_SYNC_TIME", backupInfo.startTimeToTimestamp());
                Date nextScheduleDate = new Date(BackupScheduler.nextBackupSchedule(domainId));
                row.set("NEXT_SYNC_TIME", DateUtil.DateToTimestamp(nextScheduleDate));
                row.set("TOTAL_BACKUP", 1);
                dataObject.addRow(row);
                CommonUtil.getPersistence().add(dataObject);
                return true;
            }
            UpdateQuery updateObj = new UpdateQueryImpl(TableName.RMP_BACKUP_STAT);
            if (backupInfo.count > 0) {
                row = BackupUtil.getBackupStat(domainId);
                if (row != null) {
                    Integer oldBackupCount = (Integer) row.get("TOTAL_BACKUP");
                    updateObj.setUpdateColumn("TOTAL_BACKUP", ++oldBackupCount);
                } else {
                    LogWriter.backup.warning("BackupUpdater.updateBackupStat domainId-" + domainId + " OLD BACKUP STAT WAS NULL");
                }
                updateObj.setUpdateColumn("LATEST_BACKUP_ID", backupInfo.operationId);
            }
            updateObj.setUpdateColumn("LAST_SYNC_TIME", backupInfo.startTimeToTimestamp());
            Timestamp nextSync = new Timestamp(BackupScheduler.nextBackupSchedule(domainId));
            updateObj.setUpdateColumn("NEXT_SYNC_TIME", DateUtil.DateToTimestamp(nextSync));//ToDo: get the next scheduled backup time from scheduler
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.RMP_BACKUP_STAT, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            updateObj.setCriteria(domainCriteria);
            CommonUtil.getPersistence().update(updateObj);
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.updateBackupStat domainId-" + domainId + " /n" + e);
        }
        return false;
    }

    public Boolean updateAttributeInfo(UUID objId, Integer changeId, Integer attribId) {
        try {
            Row row = new Row(TableName.RMP_ATTRIBUTES_BACKUP_INFO+"_"+domainId);
            DataAccess.generateValues(row);
            return dbImporter.updateAttributeInfo(row.get("UNIQUE_ID").toString(),  backupId, objId, changeId, attribId);
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.updateAttributeInfo " + e);
            return false;
        }
    }

    public Boolean updateAttributeInfo(BackupObject backupObject) {
        for (Integer attribId = backupObject.changeMask.nextSetBit(0); attribId != -1; attribId = backupObject.changeMask.nextSetBit(attribId + 1)) {
            updateAttributeInfo(backupObject.objId, backupObject.changeId, attribId);
        }
        return true;
    }

    public Boolean updateLinkAttrInfo(Object forwardLinkType, Long backupId, Long linksType, String frontlinkGuid, String backlinkGuid) {
        try {
            //LogWriter.backup.info("inside db dumper");
            Row row = new Row(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId);
            DataAccess.generateValues(row);
            return dbImporter.updateLinkAttrInfo(row.get("UNIQUE_ID").toString(),  forwardLinkType, backupId, linksType, frontlinkGuid, backlinkGuid);
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.updateGroupMemberInfo " + e);
            return false;
        }
    }
    
    public Boolean updateGpoLinkAttrInfo(Object forwardLinkType, Long backupId, Long linksType, Long frontLinkType, String frontlinkGuid, String backlinkGuid, int status, int priority) {
        try {
            //LogWriter.backup.info("inside db dumper");
            Row row = new Row(TableName.RMP_GPO_LINK_ATTRIBUTES+"_"+domainId);
            DataAccess.generateValues(row);
            return dbImporter.updateGpoLinkAttrInfo(row.get("UNIQUE_ID").toString(), forwardLinkType, backupId, linksType, frontLinkType, frontlinkGuid, backlinkGuid, status, priority);
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.updateGroupMemberInfo " + e);
            return false;
        }
    }

    public Boolean commit(BackupObject currentChange, BackupObject lastSnapshot) {
        if (isBatchEnabled) {
            ArrayList<BackupObject> backupCombo = new ArrayList<BackupObject>();
            backupCombo.add(0, currentChange);
            backupCombo.add(1, lastSnapshot);
            backupObjects.add(backupCombo);
            if (backupObjects.size() == maxBatchCount) {
                batchCommit();
            }
        } else {
            prepareData(currentChange, lastSnapshot);
            backupHook.backupTracker.track(currentChange, false, backupHook.isInitBackup, isFreeEdition); // After filterChange backup module is implemented , update accordingly
            backupHook.threadBackupTracker.track(currentChange, false, backupHook.isInitBackup, isFreeEdition); 
            if (currentChange.isBackupSet) {
                backupHook.tempUpdate();
            }
        }
        return true;
    }

    private Boolean batchCommit() {
        Iterator iterator = backupObjects.iterator();
        while (iterator.hasNext()) {
            ArrayList<BackupObject> backupCombo = (ArrayList<BackupObject>) iterator.next();
            BackupObject currentChange = backupCombo.get(0);
            prepareData(currentChange, backupCombo.get(1));
            backupHook.backupTracker.track(currentChange, false, backupHook.isInitBackup, isFreeEdition);
            //backupHook.threadBackupTracker.track(currentChange, false, backupHook.isFullSync, isFreeEdition); 
        }
        backupObjects = new ArrayList<ArrayList<BackupObject>>();
        dbImporter.writeBackupDataToFile();
        backupHook.tempUpdate();
        return true;
    }

    public Boolean prepareData(BackupObject currentChange, BackupObject lastSnapshot) {
        try {
            if (BackupUtil.compare(currentChange, lastSnapshot, backupHook)) {
                currentChange.cnt = lastSnapshot.cnt;
                if ((currentChange.isBackupSet)|| (!currentChange.isBackupSet && lastSnapshot.cnt == 0)) {
                    commitObjectMetaVersionInfo(currentChange);
                } 
                else {
                    LogWriter.backup.finest("BackupUpdater.commit unhandledCase");
                }
            }

            if (currentChange.hasHistory && currentChange.isBackupSet && (!isFreeEdition || (isFreeEdition && currentChange.isDeleted))) {
                currentChange.data.put("sid", currentChange.objectSid);
                currentChange.data.put("dn", currentChange.distinguishedName);//Temp addition
                commitObjectVersion(currentChange);
                updateAttributeInfo(currentChange);
            }
            lastSnapshot.cnt++;
            lastSnapshot.data.put("dn", currentChange.distinguishedName);
            lastSnapshot.data.put("bid", currentChange.backupId);
            lastSnapshot.data.put("parentDN", currentChange.parentDN);
            lastSnapshot.data.put("ct",currentChange.changeTyp);
            lastSnapshot.hasHistory = currentChange.hasHistory;
            lastSnapshot.hasChange = currentChange.hasChange;
            lastSnapshot.ouId = currentChange.ouId;
            lastSnapshot.ouNam = currentChange.ouNam;
            lastSnapshot.isDeleted = ChangeType.isDeleted(currentChange.changeTyp);
            lastSnapshot.data.put("del", lastSnapshot.isDeleted);
            lastSnapshot.changeTyp = currentChange.changeTyp;
            lastSnapshot.objTyp = currentChange.objTyp;
            lastSnapshot.distinguishedName = currentChange.distinguishedName;
            lastSnapshot.isBackupSet = currentChange.isBackupSet;
            lastSnapshot.isDisabled = currentChange.isDisabled;
            lastSnapshot.isObjNewlySelected = currentChange.isObjNewlySelected;
            lastSnapshot.hasChange = currentChange.hasChange;
            if (backupHook.backupType != BackupType.InitBackup && (lastSnapshot.objTyp == backupHook.objectType.User || lastSnapshot.objTyp == backupHook.objectType.Computer)) {
                    lastSnapshot.data.put("isPwdPreserved", backupHook.recoverySettings.isPreservePassword);
            }
            if(!backupHook.isInitBackup && currentChange.isDeleted && LdapUtil.isObjectDeleted(currentChange.parentDN)){
                lastSnapshot.ouId = UUID.fromString(LdapUtil.getGuidFromDeletedObjectDN(currentChange.parentDN));
            }
            if(backupHook.isInitBackup && (lastSnapshot.isDeleted || lastSnapshot.distinguishedName.equals(backupHook.defaultNamingContext) || lastSnapshot.distinguishedName.equals("CN=Deleted Objects,"+backupHook.defaultNamingContext))){
                lastSnapshot.hasChange = false;
            }
            if(!lastSnapshot.isBackupSet){
                lastSnapshot.data.put("trackingData", currentChange.nontrackingData);
            }else if(lastSnapshot.data.has("trackingData")){
                lastSnapshot.data.remove("trackingData");
            }else if(lastSnapshot.data.has("changeType")){
                lastSnapshot.data.remove("changeType");
            }
            updateObjectCurrentInfo(lastSnapshot);
            return true;
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.commit " + e);
            return false;
        }
    }

    
    public Boolean updateObjectCurrentInfo(BackupObject lastSnapshot) {
        try {
            if (lastSnapshot.cnt == 1) {
                commitObjectCurrentInfo(lastSnapshot);
                return true;
            } else {
                UpdateQuery updateObject = new UpdateQueryImpl(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId);
                updateObject.setUpdateColumn("LINK_ID", lastSnapshot.linkId);
                updateObject.setUpdateColumn("OBJECT_DN", lastSnapshot.distinguishedName);
                updateObject.setUpdateColumn("OBJECT_TYPE", lastSnapshot.objTyp.maskValue);
                updateObject.setUpdateColumn("OBJECT_SID", lastSnapshot.objectSid);
                updateObject.setUpdateColumn("PARENT_GUID", lastSnapshot.ouId.toString());
                updateObject.setUpdateColumn("COUNT", lastSnapshot.cnt);
                updateObject.setUpdateColumn("CHANGE_TYPE", lastSnapshot.changeTyp);
                updateObject.setUpdateColumn("CHANGE_MASK", new ByteArrayInputStream(BitSetUtil.bitSetToByteArray(lastSnapshot.changeMask)));
                updateObject.setUpdateColumn("CHANGE_DATA", lastSnapshot.data.toString());
                updateObject.setUpdateColumn("LINKS_DATA", lastSnapshot.linksData.toString());
                updateObject.setUpdateColumn("IS_BACKUP_SET", BackupUtil.getIsBackupSet(lastSnapshot));
                updateObject.setUpdateColumn("SYNC_STATUS", BackupUtil.getSyncStatus(lastSnapshot));
                updateObject.setUpdateColumn("BACKUP_ID", this.backupId);
                Criteria objectGuidCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"), lastSnapshot.objId.toString(), QueryConstants.EQUAL);
                updateObject.setCriteria((objectGuidCriteria));
                CommonUtil.getPersistence().update(updateObject);
            }
            return true;
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.updateObjectCurrentInfo " + e);
        }
        return false;
    }
    

    private Boolean commitObjectCurrentInfo(BackupObject lastSnapshot) {
        try {
            String changes = BitSetUtil.bitSetToHexadecimalString(lastSnapshot.changeMask);
            Row row = new Row(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId);
            DataAccess.generateValues(row);
            return dbImporter.commitObjectCurrentInfo(row.get("CURRENTINFO_ID").toString(), lastSnapshot, changes, BackupUtil.getSyncStatus(lastSnapshot),this.backupId);
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.commitObjectVersion " + e);
        }
        return false;
    }

    private Boolean commitObjectMetaVersionInfo(BackupObject backupObject) {
        try {
            if (backupObject.cnt == 0) {
                return dbImporter.commitObjectMetaVersionInfo(backupObject);
            } else {
                DataObject dataObject = new WritableDataObject();
                Row row = new Row(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId);
                row.set("OBJECT_GUID", backupObject.objId.toString());
                row.set("OBJECT_SID", backupObject.objectSid);
                row.set("LINK_ID", backupObject.linkId);
                row.set("OBJECT_NAME",backupObject.objNam);//ToDo: get the next scheduled backup time from scheduler
                row.set("OBJECT_LOCATION", LdapUtil.isObjectDeleted(backupObject.parentDN)?LdapUtil.getCanonicalName(LdapUtil.getDistinguishedNameFromDeletedDN(backupObject.parentDN)):backupObject.ouNam);
                row.set("PARENT_GUID", backupObject.ouId.toString());
                row.set("OBJECT_TYPE", backupObject.objTyp.maskValue);
                row.set("CHANGE_TYPE", backupObject.changeTyp); 
                dataObject.addRow(row);
                CommonUtil.getPersistence().add(dataObject);
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.commitObjectMetaVersionInfo " + e);
        }
        return false;
    }

    private Boolean updateObjectMetaVersionInfo(BackupObject backupObject) {
        try {
            UpdateQuery updateObject = new UpdateQueryImpl(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId);
            if (backupObject.objNam != null) {
                updateObject.setUpdateColumn("OBJECT_NAME", LdapUtil.getObjectAttributeValue(backupObject.objNam));//ToDo: get the next scheduled backup time from scheduler
            }
            updateObject.setUpdateColumn("OBJECT_LOCATION", backupObject.ouNam);
            updateObject.setUpdateColumn("PARENT_GUID", backupObject.ouId.toString());
            Criteria objectGuidCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "OBJECT_GUID"), backupObject.objId.toString(), QueryConstants.EQUAL);
            updateObject.setCriteria(objectGuidCriteria);
            CommonUtil.getPersistence().update(updateObject);
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.commitObjectMetaVersionInfo " + e);
        }
        return false;
    }

    private Boolean commitObjectVersion(BackupObject backupObject) {
        try {
            String changes = BitSetUtil.bitSetToHexadecimalString(backupObject.changeMask);
            backupObject.data.put("ct", backupObject.changeTyp);//Storing changeType in changeData.
            Row row = new Row(TableName.RMP_OBJ_VER_INFO+"_"+domainId);
            DataAccess.generateValues(row);
            dbImporter.commitObjectVersion(row.get("UNIQUE_ID").toString(), backupObject, changes);
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.commitObjectVersion " + e);
        }
        return false;
    }

    public Boolean dumpObjectVersionData() {
        //metaVersionDataTableDumper.dumpDataBase();
        try {
            if (isBatchEnabled) {
                batchCommit();
            }
            dbImporter.importBackupDataToDB();
            return true;
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.dumpObjectVersionData " + e);
            return false;
        }
    }

    public Boolean dumprangedAttrInfoData() {
        try {
            dbImporter.rangedAttributesTD.dumpDataBase();
            return true;
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.dumprangedAttrInfoData " + e);
            return false;
        }
    }
    
     public Boolean dumprangedAttrRecycleInfoData() {
        try {
            if(dbImporter.rangedAttributesTD.noOfRecords>0){
            dbImporter.rangedAttributesTD.dumpDataBase();
            dbImporter.rangedAttributesTD = new NoSqlWriterObject(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId);
            }
            
            return true;
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.dumprangedAttrInfoData " + e);
            return false;
        }
    }
    
     public Boolean dumpGPLinkAttrInfoData() {
        try {
            dbImporter.gpoLinkAttributesTD.dumpDataBase();
            return true;
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.dumpGPLinkAttrInfoData " + e);
            return false;
        }
    }
    
    public Boolean dumpTempTables() {
        try {
            dbImporter.importTempTableDataToDB();
            return true;
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.dump temptables " + e);
            return false;
        }
    }
    public Boolean dumpAttribInfoTable(){
        try {
            dbImporter.importAttribTableToDB();
            return true;
        } catch (Exception e) {
        	e.printStackTrace();
            LogWriter.backup.severe("BackupUpdater.dumpAttribInfoTable " + e);
            return false;
        }
    }
}
//ignoreI18n_end
