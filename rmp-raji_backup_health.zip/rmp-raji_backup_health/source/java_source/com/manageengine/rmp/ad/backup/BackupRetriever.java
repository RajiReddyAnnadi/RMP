/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
//ignoreI18n_start
package com.manageengine.rmp.ad.backup;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.Range;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.me.util.RowHelper;
import com.manageengine.rmp.ad.gpo.manager.GpoUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.RMPCommonFlags;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.util.LdapUtil;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONArray;

import org.json.JSONObject;

public class BackupRetriever {

    public static JSONObject getBackupData(Long domainId, String backupId, String changeId) {
        try {

            RowHelper row = getBackupEntity(domainId, backupId, changeId);
            if (row != null) {
                return JSONObjectUtil.merge(row.getJSONObject("CHANGE_DATA"), row.getJSONObject("LINKS_DATA"));
            }
        } catch (Exception e) {
            LogWriter.general.severe(String.format("BackupRetriever.getBackupData domainId:%1$s backupId:%2$s chagneId:%3$s", domainId, backupId, changeId));
        }
        //LogWriter.general.severe(String.format("BackupRetriever.getBackupData Backup not found domainId:%1$s backupId:%2$s changeId:%3$s", domainId, backupId, changeId));
        return null;
    }
    
    public static long getLinkData(Long domainId, String backupId, String changeId) {
        long linkId = 0L;
        try {

            RowHelper row = getBackupEntity(domainId, backupId, changeId);

            if (row != null) {
                linkId = (Long) row.getLong("LINK_ID");

            }
        } catch (Exception e) {
            LogWriter.general.severe(String.format("BackupRetriever.getLinkData domainId:%1$s backupId:%2$s chagneId:%3$s", domainId, backupId, changeId));
        }
        //LogWriter.general.severe(String.format("BackupRetriever.getBackupData Backup not found domainId:%1$s backupId:%2$s changeId:%3$s", domainId, backupId, changeId));
         return linkId;
    }
    
    public static long getPreLinkData(Long domainId, String backupId, String objguid) {
        long linkId = 0L;
           try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_VER_INFO+"_"+domainId));
            query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "*"));
            Criteria backupIdCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "BACKUP_ID"), backupId, QueryConstants.LESS_THAN);
            Criteria guidCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "OBJECT_GUID"), objguid, QueryConstants.EQUAL);
            SortColumn sortColumn = new SortColumn((TableName.RMP_OBJ_VER_INFO+"_"+domainId),"BACKUP_ID",false);
            query.addSortColumn(sortColumn);
            query.setCriteria(backupIdCriteria.and(guidCriteria));
            DataObject dataObject = CommonUtil.getPersistence().get(query);
            if (!dataObject.isEmpty()) {
                RowHelper row1 = new RowHelper(dataObject.getFirstRow(TableName.RMP_OBJ_VER_INFO+"_"+domainId));
                linkId = row1.getLong("LINK_ID");
            }
        } catch (Exception e) {
            LogWriter.general.severe(String.format("BackupRetriever.getPreLinkData domainId:%1$s backupId:%2$s Objectguid:%3$s", domainId, backupId, objguid));
        }
           return linkId;
    }
    
    public static String getParentId(long domainId,long linkId) {
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId)); 
            query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "*"));
            Criteria getParentCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "LINK_ID"), linkId, QueryConstants.EQUAL); 
            query.setCriteria(getParentCriteria);
            DataObject dataObject = CommonUtil.getPersistence().get(query);
            if (!dataObject.isEmpty()) {   
                RowHelper row = new RowHelper(dataObject.getFirstRow(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId));
                return row.getString("PARENT_GUID");
            }

        } catch (Exception e) {
        LogWriter.backup.severe(String.format("BackupUtil.getParentId B domain id :%s linkid: %s \nexcep:%s",domainId , linkId, LogWriter.getStackTrace(e)));
      }
        return null;
    }
    
    public static String getDnInfo(Long domainId, String objectGuid) {
        String distinguishedName = "";
        try {
            ArrayList columns = new ArrayList();
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId));
            columns.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "*"));
            query.addSelectColumns(columns);
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_GUID"), objectGuid, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            DataObject dataObject = CommonUtil.getPersistence().get(query);
            if (!dataObject.isEmpty()) {
               RowHelper row1 = new RowHelper(dataObject.getFirstRow(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId));
               distinguishedName =  row1.getString("OBJECT_DN");
               return distinguishedName;
            }
        } catch (Exception e) {
            LogWriter.general.severe(String.format("BackupRetriever.getDnInfo domainId:%1$s objectId:%2$s", domainId, objectGuid));
          
        } 
          return distinguishedName;
    }
    
    public static RowHelper getBackupEntity(Long domainId, String backupId, String changeId) {
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_VER_INFO+"_"+domainId));
            //query.addSelectColumn(Column.getColumn(RmpConstants.RMP_OU_INFO, "OBJECT_GUID"));
            query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "*"));//"CHANGE_DATA"
            Criteria backupIdCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "BACKUP_ID"), backupId, QueryConstants.EQUAL);
            Criteria changeIdCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "CHANGE_ID"), changeId, QueryConstants.EQUAL);
            query.setCriteria(backupIdCriteria.and(changeIdCriteria));
            DataObject dataObject = CommonUtil.getPersistence().get(query);
            if (!dataObject.isEmpty()) {
                return new RowHelper(dataObject.getFirstRow(TableName.RMP_OBJ_VER_INFO+"_"+domainId));
            } else {
                LogWriter.general.severe(String.format("BackupRetriever.getBackupEntity Backup not found domainId:%1$s backupId:%2$s changeId:%3$s", domainId, backupId, changeId));
            }
        } catch (Exception e) {
            LogWriter.general.severe(String.format("BackupRetriever.getBackupEntity domainId:%1$s backupId:%2$s chagneId:%3$s", domainId, backupId, changeId));
        }
        return null;
    }

    public static JSONObject getCurrentData(Long domainId, String objectGuid) {
        try {
            RowHelper row = getCurrentEntity(domainId, objectGuid);
            if (row != null) {
                return JSONObjectUtil.merge(row.getJSONObject("CHANGE_DATA"), row.getJSONObject("LINKS_DATA"));
            }
        } catch (Exception e) {
            LogWriter.general.severe(String.format("BackupRetriever.getCurrentData domainId:%1$s objectId:%2$s", domainId, objectGuid));
        }
        return null;
    }

    public static RowHelper getCurrentEntity(Long domainId, String objectGuid) {
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId));
            query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "*"));
            Criteria objectGuidCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_GUID"), objectGuid, QueryConstants.EQUAL);
            query.setCriteria(objectGuidCriteria);
            DataObject dataObject = CommonUtil.getPersistence().get(query);
            if (!dataObject.isEmpty()) {
                return new RowHelper(dataObject.getFirstRow(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId));
            } else {
                LogWriter.general.severe(String.format("BackupRetriever.getCurrentEntity Backup not found domainId:%1$s objectId:%2$s", domainId, objectGuid));
            }
        } catch (Exception e) {
            LogWriter.general.severe(String.format("BackupRetriever.getCurrentEntity domainId:%1$s objectId:%2$s", domainId, objectGuid));
        }
        return null;
    }

    public static JSONObject getLatestInfo(Long domainId, String objectGuid) {
        JSONObject latestInfo = new JSONObject();
        Connection connection = null;
        DataSet dataSet = null;
        try {
            RelationalAPI relApi = RelationalAPI.getInstance();
            ArrayList columns = new ArrayList();
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId));
            columns.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "CURRENTINFO_ID"));
            columns.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_TYPE"));
            columns.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_DN"));
            columns.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "CHANGE_DATA"));
            columns.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "LINKS_DATA"));
            columns.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "BACKUP_ID"));
            columns.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "PARENT_GUID"));
            columns.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "SYNC_STATUS"));
            query.addSelectColumns(columns);
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_GUID"), objectGuid, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            connection = relApi.getConnection();
            dataSet = relApi.executeQuery(query, connection);
            dataSet.next();
            String distinguishedName = dataSet.getAsString("OBJECT_DN");
            if (dataSet.getAsLong("OBJECT_TYPE").longValue() == ObjectType.GroupPolicy.maskValue) {
                latestInfo.put("OBJECT_NAME", GpoUtil.getGpoName(domainId, objectGuid));
            } else {
                latestInfo.put("OBJECT_NAME", LdapUtil.getCommonName(distinguishedName));
            }
            latestInfo.put("BACKUP_ID", dataSet.getValue("BACKUP_ID"));
            latestInfo.put("PARENT_GUID", dataSet.getAsString("PARENT_GUID"));
            latestInfo.put("OBJECT_LOCATION", LdapUtil.getParentCanonical(distinguishedName));
            latestInfo.put("CHANGE_DATA", new JSONObject(JSONObjectUtil.merge(dataSet.getAsString("CHANGE_DATA"), dataSet.getAsString("LINKS_DATA")).toString()));
            int syncStatus = (Integer) dataSet.getValue("SYNC_STATUS");
            Boolean hashistory = (syncStatus & RMPCommonFlags.HasHistory.maskValue) > 0;
            latestInfo.put("HAS_HISTORY", hashistory);
            return latestInfo;
        } catch (Exception e) {
            LogWriter.general.severe(String.format("BackupRetriever.getLatestInfo domainId:%1$s objectId:%2$s", domainId, objectGuid));
            return null;
        } finally {
            DBUtil.closeDataSetAndConnection(dataSet, connection);
        }
    }
    
    public static JSONArray getChildObjects(long domainId, String objectGuid, int pageNo, int pageSize) {
         JSONArray childObjects = new JSONArray();
         ArrayList childCol = new ArrayList();
         long backupId = getBackupId(domainId, objectGuid);
         SelectQuery childQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId));
         childCol.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "CURRENTINFO_ID"));
         childCol.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_GUID"));
         childCol.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_TYPE"));
         childCol.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "SYNC_STATUS"));
         //childCol.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "BACKUP_ID"));
         childQuery.addSelectColumns(childCol);
         Criteria childCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "PARENT_GUID"), objectGuid, QueryConstants.EQUAL);
         childCriteria = childCriteria.and(new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "BACKUP_ID"), backupId, QueryConstants.EQUAL));
         childQuery.setCriteria(childCriteria);
         childQuery.setRange(new Range((pageNo * pageSize) + 1, pageSize));
         childQuery.addSortColumn(new SortColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "CURRENTINFO_ID", true));
         try {
             DataObject childObj = CommonUtil.getPersistence().get(childQuery);
             if (!childObj.isEmpty()) {
                 Iterator childItr = childObj.getRows(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId);
                 while(childItr.hasNext()) {
                     Row childRow = (Row) childItr.next();
                     JSONArray childArray = new JSONArray();
                     childArray.put(childRow.get("OBJECT_GUID").toString());
                     childArray.put(childRow.get("OBJECT_TYPE").toString());
                     childArray.put(new JSONArray());
                     Boolean isdeleted = (((int) childRow.get("SYNC_STATUS")) & RMPCommonFlags.IsDeleted.maskValue) > 0;
                     childArray.put(isdeleted);
                     childObjects.put(childArray);
                 }
                 return childObjects;
             }
             return childObjects;
         }
         catch (Exception e) {
             LogWriter.general.severe(String.format("BackupRetriever.getChildObjects domainId:%1$s objectId:%2$s", domainId, objectGuid));
             e.printStackTrace();
         }
         return null;
     }
     
     public static long getBackupId(long domainId, String objectGuid) {
         long backupId = 0L;
         ArrayList backupIdCol = new ArrayList();
         SelectQuery backupIdQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId));
         backupIdCol.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "CURRENTINFO_ID"));
         backupIdCol.add(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "BACKUP_ID"));
         backupIdQuery.addSelectColumns(backupIdCol);
         Criteria backupIdCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_GUID"), objectGuid, QueryConstants.EQUAL);
         backupIdQuery.setCriteria(backupIdCriteria);
         try {
             DataObject backupIdObj = CommonUtil.getPersistence().get(backupIdQuery);
             if (!backupIdObj.isEmpty()) {
                 Row backupIdRow = backupIdObj.getFirstRow(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId);
                 backupId = (Long) backupIdRow.get("BACKUP_ID");
                 return backupId;
             }
         }
         catch (Exception e){
             LogWriter.general.severe(String.format("BackupRetriever.getBackupId domainId:%1$s objectId:%2$s", domainId, objectGuid));
         }
         return backupId;
     }
}
//ignoreI18n_end
