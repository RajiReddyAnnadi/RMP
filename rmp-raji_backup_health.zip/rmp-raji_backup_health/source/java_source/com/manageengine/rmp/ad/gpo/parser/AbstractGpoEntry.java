/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.parser;

import com.manageengine.rmp.ad.gpo.constants.GpoAddRem;
import java.io.Serializable;

/**
 *
 * @author lucky-2306
 */
public abstract class AbstractGpoEntry implements Serializable{

    public GpoAddRem gpoAddRem;
    public String keyName;
    public String valueName;

    public abstract boolean compareTo(AbstractGpoEntry gpoEntry);
}
