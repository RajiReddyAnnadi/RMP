/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.policies;

import com.google.gson.reflect.TypeToken;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.ad.gpo.constants.GpoAddRem;
import com.manageengine.rmp.ad.gpo.constants.GpoConfigType;
import com.manageengine.rmp.ad.gpo.constants.GptTmplType;
import com.manageengine.rmp.ad.gpo.manager.GpoUtil;
import com.manageengine.rmp.ad.gpo.parser.AbstractGpoEntry;
import com.manageengine.rmp.ad.gpo.parser.AuditEntry;
import com.manageengine.rmp.ad.gpo.parser.AuditFile;
import com.manageengine.rmp.ad.gpo.parser.GptEntry;
import com.manageengine.rmp.ad.gpo.parser.GptFile;
import com.manageengine.rmp.ad.gpo.parser.PolEntry;
import com.manageengine.rmp.ad.gpo.parser.PolEntryConcise;
import com.manageengine.rmp.ad.gpo.parser.PolFile;
import com.manageengine.rmp.common.LogWriter;
import java.util.ArrayList;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class PolicyModifier {

    public PolFile newUserPol, newMachinePol;
    public GptFile newUserGpt, newMachineGpt;
    public AuditFile newUserAudit, newMachineAudit;

    public PolicyModifier(ArrayList<Object> gpoFiles) {
        init((PolFile) gpoFiles.get(0), (PolFile) gpoFiles.get(1), (GptFile) gpoFiles.get(2), (GptFile) gpoFiles.get(3), (AuditFile) gpoFiles.get(4), (AuditFile) gpoFiles.get(5));
    }

    public PolicyModifier(PolFile newUserPol, PolFile newMachinePol, GptFile newUserGpt, GptFile newMachineGpt, AuditFile newUserAudit, AuditFile newMachineAudit) {
        init(newUserPol, newMachinePol, newUserGpt, newMachineGpt, newUserAudit, newMachineAudit);
    }

    private void init(PolFile newUserPol, PolFile newMachinePol, GptFile newUserGpt, GptFile newMachineGpt, AuditFile newUserAudit, AuditFile newMachineAudit) {
        try {
            this.newUserPol = newUserPol;
            this.newMachinePol = newMachinePol;
            this.newUserGpt = newUserGpt;
            this.newMachineGpt = newMachineGpt;
            this.newMachineAudit = newMachineAudit;
            this.newUserAudit = newUserAudit;
        } catch (Exception e) {
            LogWriter.gpo.severe("Policy Modifier : " + LogWriter.getStackTrace(e));
        }
    }

    public boolean modifyGptEntry(Object serializedEntry, Object oldValue, int attrId) {
        oldValue = null;
        if (serializedEntry.equals("")) {
            for (PolicySetting policy : PolicySetting.getPolicySettings(GpoUtil.getAttributeMask(attrId))) {
                AbstractGpoEntry oldGptEntry = newMachineGpt.getValue(policy.policyPath, GptTmplType.getGptType(policy.fileName).gptId.toString());
                oldValue = oldGptEntry == null ? null : JSONObjectUtil.toJsonString(oldGptEntry);
                newMachineGpt.deleteValue(policy.policyPath, GptTmplType.getGptType(policy.fileName).gptId.toString());
            }
            return true;
        } else {
            GptEntry gptEntry = new GptEntry();
            gptEntry = JSONObjectUtil.getObjectFromJsonString((String) serializedEntry, gptEntry.getClass());
            if (attrId >= 4208 && attrId <= 4400) {
                AbstractGpoEntry oldGptEntry = newMachineGpt.getValue(gptEntry.keyName, (new Integer(gptEntry.gptType.gptId)).toString());
                oldValue = oldGptEntry == null ? null : JSONObjectUtil.toJsonString(oldGptEntry);
                if (gptEntry.gpoAddRem == GpoAddRem.Add) {
                    newMachineGpt.setValue(gptEntry);
                } else if (gptEntry.gpoAddRem == GpoAddRem.Rem) {
                    newMachineGpt.deleteValue(gptEntry.keyName, (new Integer(gptEntry.gptType.gptId)).toString());
                }
                return true;
            } else {
                AbstractGpoEntry oldGptEntry = newUserGpt.getValue(gptEntry.keyName, (new Integer(gptEntry.gptType.gptId)).toString());
                oldValue = oldGptEntry == null ? null : JSONObjectUtil.toJsonString(oldGptEntry);
                if (gptEntry.gpoAddRem == GpoAddRem.Add) {
                    newUserGpt.setValue(gptEntry);
                } else if (gptEntry.gpoAddRem == GpoAddRem.Rem) {
                    if (newUserGpt.contains(gptEntry)) {
                        newUserGpt.deleteValue(gptEntry);
                    }
                }
                return true;
            }
        }
    }

    public boolean modifyAuditEntry(Object serializedEntry, Object oldValue, int attrId) {
        oldValue = null;
        if (serializedEntry.equals("")) {
            for (PolicySetting policy : PolicySetting.getPolicySettings(GpoUtil.getAttributeMask(attrId))) {
                AbstractGpoEntry oldAuditEntry = newMachineAudit.getValue(policy.policyPath, "");
                oldValue = oldAuditEntry == null ? null : JSONObjectUtil.toJsonString(oldAuditEntry);
                newMachineAudit.deleteValue(policy.policyPath, "");
            }
            return true;
        } else {
            AuditEntry auditEntry = new AuditEntry();
            auditEntry = JSONObjectUtil.getObjectFromJsonString((String) serializedEntry, auditEntry.getClass());
            AbstractGpoEntry oldAuditEntry = newMachineAudit.getValue(auditEntry.keyName, "");
            oldValue = oldAuditEntry == null ? null : JSONObjectUtil.toJsonString(oldAuditEntry);
            if (auditEntry.gpoAddRem == GpoAddRem.Add) {
                newMachineAudit.setValue(auditEntry);
            } else if (auditEntry.gpoAddRem == GpoAddRem.Rem) {
                newMachineAudit.deleteValue(auditEntry.keyName, "");
            }
            return true;
        }
    }

    public void removeDisabledEntries(PolicySetting policy) {
        if (policy.isMultiValued) {
            LogWriter.gpo.finest("check");
            ArrayList<PolicySetting> policySettings = PolicySetting.getPolicySettings(policy.settingId);
            for (PolicySetting policySetting : policySettings) {
                PolEntry tempPolEntry = new PolEntry(policySetting.policyPath);
                if (policySetting.configType == GpoConfigType.Machine) {
                    AbstractGpoEntry entryCheck = newMachinePol.getValue(tempPolEntry);
                    if (entryCheck != null) {
                        PolEntry polEntryCheck = (PolEntry) entryCheck;
                        if (!polEntryCheck.appendVN.equals("")) {
                            newMachinePol.deleteValue(tempPolEntry);
                        }
                    }
                } else {
                    AbstractGpoEntry entryCheck = newUserPol.getValue(tempPolEntry);
                    if (entryCheck != null) {
                        PolEntry polEntryCheck = (PolEntry) entryCheck;
                        if (!polEntryCheck.appendVN.equals("")) {
                            newUserPol.deleteValue(tempPolEntry);
                        }
                    }
                }
            }
        }
    }

    public boolean modifyPolEntry(Object serializedEntry, Object oldValue, int attrId) {
        oldValue = null;
        try {
            ArrayList<Object> oldValues = new ArrayList<Object>();
            if (serializedEntry.equals("")) //not Set in Rollback
            {
                for (PolicySetting policy : PolicySetting.getPolicySettings(GpoUtil.getAttributeMask(attrId))) {
                    if ("HKLM".equalsIgnoreCase(policy.policyPath.substring(0, 4))) //Machine
                    {
                        oldValues.add(newMachinePol.getOldValue(policy.policyPath));
                        newMachinePol.deleteValue(policy.policyPath);
                    } else {
                        oldValues.add(newUserPol.getOldValue(policy.policyPath));
                        newUserPol.deleteValue(policy.policyPath);
                    }
                }
            } else {
                ArrayList<PolEntryConcise> polEntryConcise = new ArrayList<PolEntryConcise>();
                PolicySetting policy = new PolicySetting(GpoUtil.getAttributeMask(attrId));
                if (policy.isMultiValued) {
                    polEntryConcise = JSONObjectUtil.fromJsonString((String) serializedEntry, new TypeToken<ArrayList<PolEntryConcise>>() {
                    }.getType());
                } else {
                    PolEntryConcise polEntryCouch = new PolEntryConcise();
                    polEntryCouch = JSONObjectUtil.getObjectFromJsonString((String) serializedEntry, polEntryCouch.getClass());
                    polEntryConcise.add(polEntryCouch);
                }
                removeDisabledEntries(policy);
                for (PolEntryConcise polEntryCon : polEntryConcise) {
                    PolEntry polEntry = new PolEntry(polEntryCon);
                    if (polEntry.gpoUserMach == GpoConfigType.User) {
                        oldValues.add(newUserPol.getOldValue(polEntry));
                        if (polEntry.gpoAddRem == GpoAddRem.Add) {
                            newUserPol.setValue(polEntry);
                        } else if (polEntry.gpoAddRem == GpoAddRem.Rem) {
                            newUserPol.deleteValue(polEntry);
                        }
                    } else if (polEntry.gpoUserMach == GpoConfigType.Machine) {
                        oldValues.add(newMachinePol.getOldValue(polEntry));
                        if (polEntry.gpoAddRem == GpoAddRem.Add) {
                            newMachinePol.setValue(polEntry);
                        } else if (polEntry.gpoAddRem == GpoAddRem.Rem) {
                            newMachinePol.deleteValue(polEntry.keyName, polEntry.valueName);
                        }
                    } else {
                        oldValues.add(new PolEntryConcise());
                        //return false; //Should Not Be Executed
                    }
                }
            }
            if (oldValues.size() == 1) {
                oldValue = JSONObjectUtil.toJsonString(oldValues.get(0));
            } else if (oldValues.size() != 0) {
                oldValue = JSONObjectUtil.toJsonString(oldValues);
            }
            return true;
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format("%s", LogWriter.getStackTrace(e)));
            return false;
        }
    }
}

//ignoreI18n_end
