/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.constants;

/**
 * $Id$
 * @author lucky-2306
 */
//ignoreI18n_start
public enum GptTmplType {

    Unicode(0),
    Version(1),//1
    SystemAccess(2),
    KerberosPolicy(3),
    EventAudit(4),
    PrivilegeRights(5),//5
    ApplicationLog(6),
    SecurityLog(7),
    SystemLog(8),
    GroupMembership(9),
    RegistryKeys(10),
    FileSecurity(11),
    ServiceGeneralSetting(12),//10
    RegistryValues(13),
    NotGptType(14),
    Unknown(15);
    public Integer gptId;
    public String value;
    public static GptTmplType[] values;

    static {
        values = GptTmplType.values();
    }

    GptTmplType(int gptId) {
        this.gptId = gptId;
        
        switch (this.gptId) {
            case 0:
                value = "[Unicode]";//No I18N
                break;
            case 1:
                value = "[Version]";//No I18N
                break;
            case 2:
                value = "[System Access]";//No I18N
                break;
            case 3:
                value = "[Kerberos Policy]";//No I18N
                break;
            case 4:
                value = "[Event Audit]";//No I18N
                break;
            case 5:
                value = "[Privilege Rights]";//No I18N
                break;
            case 6:
                value = "[Application Log]";//No I18N
                break;
            case 7:
                value = "[Security Log]";//No I18N
                break;
            case 8:
                value = "[System Log]";//No I18N
                break;
            case 9:
                value = "[Group Membership]";//No I18N
                break;
            case 10:
                value = "[Registry Keys]";//No I18N
                break;
            case 11:
                value = "[File Security]";//No I18N
                break;
            case 12:
                value = "[Service General Setting]";//No I18N
                break;
            case 13:
                value = "[Registry Values]";//No I18N
                break;
            default:
                value = "[]";//No I18N
        }
    }

    public static GptTmplType getGptType(String gptValue) {
        switch (gptValue.toUpperCase()) {
            case "UNICODE":
                return Unicode;
            case "VERSION":
                return Version;
            case "SYSTEM ACCESS":
                return SystemAccess;
            case "KERBEROS POLICY":
                return KerberosPolicy;
            case "EVENT AUDIT":
                return EventAudit;
            case "PRIVILEGE RIGHTS":
                return PrivilegeRights;
            case "APPLICATION LOG":
                return ApplicationLog;
            case "SECURITY LOG":
                return SecurityLog;
            case "SYSTEM LOG":
                return SystemLog;
            case "GROUP MEMBERSHIP":
                return GroupMembership;
            case "REGISTRY KEYS":
                return RegistryKeys;
            case "FILE SECURITY":
                return FileSecurity;
            case "SERVICE GENERAL SETTING":
                return ServiceGeneralSetting;
            case "REGISTRY VALUES":
                return RegistryValues;
            default:
                return Unknown;
        }
    }

    public static GptTmplType setGptType(String gptLineType) {
        if (gptLineType.startsWith("[") && gptLineType.endsWith("]") && !gptLineType.contains("=")) {
            switch (gptLineType) {
                case "[Unicode]"://No I18N
                    return GptTmplType.Unicode;
                case "[Version]"://No I18N
                    return GptTmplType.Version;
                case "[System Access]"://No I18N
                    return GptTmplType.SystemAccess;
                case "[Kerberos Policy]"://No I18N
                    return GptTmplType.KerberosPolicy;
                case "[Event Audit]"://No I18N
                    return GptTmplType.EventAudit;
                case "[Privilege Rights]"://No I18N
                    return GptTmplType.PrivilegeRights;
                case "[Application Log]"://No I18N
                    return GptTmplType.ApplicationLog;
                case "[Security Log]"://No I18N
                    return GptTmplType.SecurityLog;
                case "[System Log]"://No I18N
                    return GptTmplType.SystemLog;
                case "[Group Membership]"://No I18N
                    return GptTmplType.GroupMembership;
                case "[Registry Keys]"://No I18N
                    return GptTmplType.RegistryKeys;
                case "[File Security]"://No I18N
                    return GptTmplType.FileSecurity;
                case "[Service General Setting]"://No I18N
                    return GptTmplType.ServiceGeneralSetting;
                case "[Registry Values]"://No I18N
                    return GptTmplType.RegistryValues;
                default:
                    return GptTmplType.Unknown;
            }
        } else {
            return GptTmplType.NotGptType;
        }
    }
}

//ignoreI18n_end