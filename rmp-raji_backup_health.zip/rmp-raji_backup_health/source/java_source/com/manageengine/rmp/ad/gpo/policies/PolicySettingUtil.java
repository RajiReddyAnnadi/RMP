/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.policies;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.RowHelper;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.TableName;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import com.manageengine.rmp.db.dbutil.DBUtil;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.io.FilenameFilter;
import java.sql.Connection;
import java.sql.SQLException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import org.json.JSONArray;
import org.json.JSONObject;


/**
 * $Id$
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class PolicySettingUtil {

    protected static HashMap tableColumns;
    public static final String GPO_SETTING_ID = "SETTING_ID";//No I18N
    public static final String GPO_UNIQUE_ID = "UNIQUE_ID";//No I18N
    public static final String GPO_STATUS_ID = "STATUS_ID";//No I18N
    public static final String GPO_STATUS_VALUE = "STATUS_VALUE";//No I18N
    public static final String GPO_MULTIVAL_MAP = "MULTIVAL_MAP";//No I18N
    public static final String GPO_FILE_NAME = "FILE_NAME";//No I18N
    public static final String GPO_POLICY_NAME = "POLICY_NAME";//No I18N
    public static final String GPO_CONFIG_TYPE = "CONFIG_TYPE";//No I18N
    public static final String GPO_DISPLAY_NAME = "DISPLAY_NAME";//No I18N
    public static final String GPO_POLICY_PATH = "POLICY_PATH";//No I18N
    public static final String GPO_MULTI_KEY = "GPO_MULTI_KEY";//No I18N
    public static final String GPO_MULTI_VALUE = "GPO_MULTI_VALUE";//No I18N
    public static final String GPO_SETTING_TYPE = "SETTING_TYPE";//No I18N
    public static final String GPO_RAW_FILE_ENTRY = "RAW_FILE_ENTRY";//No I18N
    public static final String GPO_IS_MULTIVALUE = "IS_MULTIVALUE";//No I18N
    public static final String GPO_IS_MULTIPOLICY = "IS_MULTIPOLICY";//No I18N
    public static final String GPO_IS_RANGED = "IS_RANGED";//No I18N
    public static final String GPO_REBOOT_REQ = "LOGOFF_REQ";//No I18N
    public static final String GPO_AD_REQ = "AD_REQ";//No I18N
    public static final String GPO_HELP_TEXT = "HELP_TEXT";//No I18N

    public static final String GPO_ATTRIB_MASK_INDEX = "ATTRIB_MASK_INDEX";//No I18N
    public static final String GPO_BACKUP_DATATYPE = "BACKUP_DATATYPE";//No I18N
    public static final String GPO_HAS_SPECIALCASE_ON_BACKUP = "HAS_SPECIALCASE_ON_BACKUP";//No I18N
    public static final String GPO_HAS_SPECIALCASE_ON_RECOVERY = "HAS_SPECIALCASE_ON_RECOVERY";//No I18N
    public static final String GPO_TABLE_GENERAL = "GPOSettingDetails";//No I18N
    public static final String GPO_TABLE_RMP = "RMPGPOSettingDetails";//No I18N

    private static JSONObject  multiGpoKeys;
    private static JSONObject multiGpoValues;
    static {
        PolicySettingUtil.tableColumns = new HashMap();
        tableColumns.put(GPO_TABLE_GENERAL, new String[]{GPO_SETTING_ID, GPO_UNIQUE_ID, GPO_MULTIVAL_MAP, GPO_FILE_NAME, GPO_POLICY_NAME, GPO_CONFIG_TYPE, GPO_SETTING_TYPE,
            GPO_RAW_FILE_ENTRY, GPO_IS_MULTIVALUE, GPO_IS_MULTIPOLICY, GPO_IS_RANGED, GPO_REBOOT_REQ, GPO_AD_REQ/*, GPO_HELP_TEXT*/});

        tableColumns.put(GPO_TABLE_RMP, new String[]{GPO_UNIQUE_ID, GPO_HAS_SPECIALCASE_ON_BACKUP, GPO_HAS_SPECIALCASE_ON_RECOVERY, GPO_ATTRIB_MASK_INDEX, GPO_BACKUP_DATATYPE});
        
    }
    public PolicySettingUtil(){
            multiGpoKeys=new JSONObject();
            multiGpoValues=new JSONObject();
    }
    public static int getNewId(String colName)
    {
        int max=0;
        Connection con = null;
        DataSet dset = null;
        try
        {
            SelectQuery query = new SelectQueryImpl(Table.getTable(GPO_TABLE_GENERAL));
            Column maxId = Column.getColumn(GPO_TABLE_GENERAL, colName).maximum();// No I18N
            maxId.setColumnAlias("MAXID");
            query.addSelectColumn(maxId);
            String dbQuery=RelationalAPI.getInstance().getSelectSQL(query);
            con = RelationalAPI.getInstance().getConnection();
            dset = RelationalAPI.getInstance().executeQuery(query, con);
            if (dset != null)
            {
                if(dset.next())
                {
                    max = (int)dset.getValue("MAXID");// No I18N
                    max++;
                    if(max<10000){
                          max=10000;
                     }
                    return max;
                }
            }
        } catch (Exception e)
        {
            LogWriter.gpo.severe(String.format(" %s", LogWriter.getStackTrace(e)));//No I18N
        } finally
        {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        return 0;
    }

    
    public static void updateTable(int settingId,String fileName,String displayName,String configType, String rawEntryName){
    try{
            boolean isDuplicateEntry=checkIfDuplicate(rawEntryName);
//            boolean isDuplicateEntry=false;
            if(!isDuplicateEntry){
               Persistence per = CommonUtil.getPersistence();
               DataObject addCustomAttr = new WritableDataObject();
               Row row = new Row(GPO_TABLE_GENERAL);
               DataAccess.generateValues(row);
               int uniqId=(int)row.get(GPO_UNIQUE_ID);
               row.set(GPO_SETTING_ID, settingId);
               row.set(GPO_UNIQUE_ID, uniqId);
               row.set(GPO_MULTIVAL_MAP, uniqId);
               row.set(GPO_FILE_NAME, fileName);
               row.set(GPO_DISPLAY_NAME, displayName);
               row.set(GPO_POLICY_PATH, displayName);
               row.set(GPO_POLICY_NAME, displayName);
               row.set(GPO_CONFIG_TYPE, configType);
               row.set(GPO_SETTING_TYPE, "REG_KEY");
               row.set(GPO_RAW_FILE_ENTRY, rawEntryName);
               row.set(GPO_IS_MULTIVALUE, false);
               row.set(GPO_IS_MULTIPOLICY, false);
               row.set(GPO_IS_RANGED, false);
               row.set(GPO_REBOOT_REQ, false);
               row.set(GPO_AD_REQ, false);
               Row row2 = new Row(GPO_TABLE_RMP);
               row2.set(GPO_UNIQUE_ID, uniqId);
               row2.set(GPO_ATTRIB_MASK_INDEX, settingId);
               row2.set(GPO_BACKUP_DATATYPE,1);
               row2.set(GPO_HAS_SPECIALCASE_ON_BACKUP, false);
               row2.set(GPO_HAS_SPECIALCASE_ON_RECOVERY, false);
               addCustomAttr.addRow(row);
               addCustomAttr.addRow(row2);
               per.update(addCustomAttr);
               LogWriter.gpo.info("Custom GPO - SettingId : "+settingId+", RawFile Entry : "+rawEntryName+" , DisplayName : "+displayName+", From file : "+fileName);//No I18N
            }
    }
    catch(Exception e){
            LogWriter.gpo.severe(String.format("Could not update the admx data %s", e));//No I18N
    }
    }
    public static void modifyAndUpdate(int settingId,String fileName,String displayName,int classType, String rawEntryName){
        try{
            if(classType==1 ){
                updateTable(settingId,fileName,displayName+" (User)["+fileName.toUpperCase()+"]","USER","HKCU\\"+rawEntryName);
                updateTable(settingId+1,fileName,displayName+" (Machine)["+fileName.toUpperCase()+"]","MACHINE","HKLM\\"+rawEntryName);
            }
            else if(classType ==2){
                updateTable(settingId,fileName,displayName+" (User)["+fileName.toUpperCase()+"]","USER","HKCU\\"+rawEntryName);
            }
            else{
                updateTable(settingId,fileName,displayName+" (Machine)["+fileName.toUpperCase()+"]","MACHINE","HKLM\\"+rawEntryName);
            }
        }
        catch(Exception e){
            LogWriter.gpo.severe(String.format("Could not update the admx data %s", e));//No I18N
        }
    }
    
    public static void updateMultiValueGeneral(int settingId) {
        try {
            Criteria objectIdCriteria = new Criteria(Column.getColumn(GPO_TABLE_GENERAL, GPO_SETTING_ID), settingId, QueryConstants.EQUAL);
            Persistence per = CommonUtil.getPersistence();
            UpdateQuery updateQuery = new UpdateQueryImpl(GPO_TABLE_GENERAL);
            updateQuery.setCriteria(objectIdCriteria);
            updateQuery.setUpdateColumn(GPO_IS_MULTIVALUE, true);
            per.update(updateQuery);
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format("Policyutil.java error %s", e));//No I18N
        }
    }
    public static File[] finder (String dirName, final String type) {
            File dir = new File(dirName);

    return dir.listFiles(new FilenameFilter() {
             public boolean accept(File dir, String filename)
                  { return filename.endsWith("." + type); }
    } );
    }
    
    public static void updateSingleValueDB(int settingId,String statusId,String statusValue){
        try{
                   Persistence per = CommonUtil.getPersistence();
                   DataObject addSingleAttr = new WritableDataObject();
                   Row row = new Row(TableName.RMP_GPO_SETTINGS_DATA);
//                   DataAccess.generateValues(row);
//                   int uniqId=(int)row.get(GPO_UNIQUE_ID);
//                   row.set(GPO_UNIQUE_ID, uniqId);
                   row.set(GPO_SETTING_ID, settingId);
                   row.set(GPO_STATUS_ID, statusId);
                   row.set(GPO_STATUS_VALUE, statusValue);
                   addSingleAttr.addRow(row);
                   per.update(addSingleAttr);

        }
        catch(Exception e){
                LogWriter.gpo.severe(String.format("Could not update the single valued DB data %s", e));//No I18N
        }
    }
      public static void updateSingleValue(Element eElement,int settingId,Document docAdml){
        try {
                String [] enabledStatus={"enabledValue","trueValue"};
                String [] disabledStatus={"falseValue","disabledValue"};
                Element elementValue;
                boolean isDefault=true;
                for(int i=0;i<enabledStatus.length;i++){
                    elementValue = (Element)  eElement.getElementsByTagName(enabledStatus[i]).item(0); 
                    if(elementValue!=null){
                        String statusId=getElementValue(elementValue);
                        if(statusId.length()>0){
                            updateSingleValueDB(settingId,statusId,"Enabled");
                            isDefault=false;
                        }
                        break;
                    }
                }
                for(int i=0;i<disabledStatus.length;i++){
                    elementValue = (Element)  eElement.getElementsByTagName(disabledStatus[i]).item(0); 
                    if(elementValue!=null){
                        String statusId=getElementValue(elementValue);
                        if(statusId.length()>0){
                            updateSingleValueDB(settingId,statusId,"Disabled");
                            isDefault=false;
                        }
                        break;
                    }
                }
                Element enumEle = (Element)  eElement.getElementsByTagName("enum").item(0); 
                if(enumEle!=null){
                    XPath xpath = XPathFactory.newInstance().newXPath();
                    
                    NodeList itemNodeList =   enumEle.getElementsByTagName("item"); 
                    NodeList valueNodeList =   enumEle.getElementsByTagName("value"); 
                    for(int j=0;j<itemNodeList.getLength();j++){
                        Element item= (Element)itemNodeList.item(j);
                        Element value= (Element)valueNodeList.item(j);
                        String itemName= item.getAttribute("displayName");
                        itemName=itemName.replaceAll("\\(", "").replaceAll("\\)", "").replaceAll("\\$", "");
                        itemName=itemName.substring(7);
                        String statusId=getElementValue(value);
                        String itemAdmlName = (String) xpath.evaluate("/policyDefinitionResources/resources/stringTable/string[@id='"+itemName+"']", docAdml, XPathConstants.STRING);
                       if(itemAdmlName.length()>0){
                            itemName=itemAdmlName;
                        }
                       else{
                           itemName=splitCamelCase(itemName);
                       }
                         if(statusId.length()>0){
                            updateSingleValueDB(settingId,statusId,itemName);
                            isDefault=false;
                        }
                    }
                }
                if(isDefault){
                    updateSingleValueDB(settingId,"1","Enabled");
                    updateSingleValueDB(settingId,"0","Disabled");
                }
            } catch (Exception e) {
                  e.printStackTrace();
            }
    }
      
    public static void updateEnbledDisabled(Element eElement ,int settingId,Document docAdml,String presentationName){
        try {
            String value="";
            boolean isDefault=true;
            String valueName =   eElement.getAttribute("valueName");
            String updateCol=splitCamelCase(valueName);
            Element trueValue = (Element)  eElement.getElementsByTagName("enabledValue").item(0); 
            JSONObject gpoOptions=new JSONObject();
            multiGpoKeys.put(valueName, updateCol);
            if(trueValue!=null){
                value=getElementValue(trueValue);
                gpoOptions.put(value, "Enabled");
                isDefault=false;
            }
            Element falseValue = (Element)  eElement.getElementsByTagName("disabledValue").item(0); 
            if(falseValue!=null){
                value=getElementValue(falseValue);
                gpoOptions.put(value, "Disabled");
                isDefault=false;
            }
            if(isDefault){
                gpoOptions.put("1", "Enabled");
                gpoOptions.put("0", "Disabled");
            }
            multiGpoValues.put(valueName,gpoOptions);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static String splitCamelCase(String strData) {
        strData=strData.replaceAll("_"," ");
        return strData.replaceAll(
           String.format("%s|%s|%s",
              "(?<=[A-Z])(?=[A-Z][a-z])",
              "(?<=[^A-Z])(?=[A-Z])",
              "(?<=[A-Za-z])(?=[^A-Za-z])"
           ),
           " "
        );
     }
    
    public static String getElementValue(Element eElement){
        String result="undefined";
        try {
                Element decimalNodeEle = (Element) eElement.getElementsByTagName("decimal").item(0);
                Element stringNodeEle  = (Element)eElement.getElementsByTagName("string").item(0);
                Element longDecimalNodeEle  = (Element)eElement.getElementsByTagName("longDecimal").item(0);
                if (stringNodeEle!= null) {
                    result=stringNodeEle.getTextContent();
                }
                else if (decimalNodeEle!= null) {
                    result=decimalNodeEle.getAttribute("value");
                }
                else if (longDecimalNodeEle!= null) {
                    result=longDecimalNodeEle.getAttribute("value");
                }
            } catch (Exception e) {
                  e.printStackTrace();
              }
        return result;
    }
    
    public static void updateBoolean(NodeList booleanNodeList,int settingId,Document docAdml,String presentationName){
        try {
                String value="";
                for(int i=0;i<booleanNodeList.getLength();i++){ 
                    XPath xpath = XPathFactory.newInstance().newXPath();
                    JSONObject gpoOptions=new JSONObject();
                    boolean isDefault=true;
                    Element eElement=(Element) booleanNodeList.item(i);
                    String enumColId =   eElement.getAttribute("id");
                    String valueName =   eElement.getAttribute("valueName");
                    String enumColName ="";
                    if(docAdml!=null){
                        enumColName = (String) xpath.evaluate("/policyDefinitionResources/resources/presentationTable/presentation[@id='"+presentationName+"']/*[@refId='"+enumColId+"']", docAdml, XPathConstants.STRING);
                    }
                    String updateCol=enumColId;
                    enumColName=enumColName.replaceAll("\\\\n", "").trim();
                    if(enumColName.length()>0){
                        updateCol=enumColName;
                    }
                    else{
                        updateCol=splitCamelCase(updateCol);
                    }
                    multiGpoKeys.put(valueName, updateCol);
                    Element trueValue = (Element)  eElement.getElementsByTagName("trueValue").item(0); 
                    if(trueValue!=null){
                        value=getElementValue(trueValue);
                        gpoOptions.put(value, "Enabled");
                        isDefault=false;
                    }
                    Element falseValue = (Element)  eElement.getElementsByTagName("falseValue").item(0); 
                    if(falseValue!=null){
                        value=getElementValue(falseValue);
                        gpoOptions.put(value, "Disabled");
                        isDefault=false;
                    }
                    if(isDefault){
                        gpoOptions.put("1", "Enabled");
                        gpoOptions.put("0", "Disabled");
                    }
                    multiGpoValues.put(valueName,gpoOptions);
                }
            }catch (Exception e) {
                  e.printStackTrace();
            }
    }
      public static void updateEnum(NodeList enumNodeList,int settingId,Document docAdml,String presentationName){
        try {
            for(int i=0;i<enumNodeList.getLength();i++){
                Element enumELe=(Element) enumNodeList.item(i);
                if(enumELe!=null){
                XPath xpath = XPathFactory.newInstance().newXPath();
                JSONObject gpoOptions=new JSONObject();
                String valueName =   enumELe.getAttribute("valueName"); 
                NodeList itemNodeList =   enumELe.getElementsByTagName("item"); 
                NodeList valueNodeList =   enumELe.getElementsByTagName("value");
                String enumColId =   enumELe.getAttribute("id");
                String enumColName="";
                if(docAdml!=null){
                    enumColName = (String) xpath.evaluate("/policyDefinitionResources/resources/presentationTable/presentation[@id='"+presentationName+"']/*[@refId='"+enumColId+"']", docAdml, XPathConstants.STRING);
                }
                String updateCol=enumColId;
                enumColName=enumColName.replaceAll("\\\\n", "").trim();
                if(enumColName.length()>0){
                        updateCol=enumColName;
                }
                else{
                    updateCol=splitCamelCase(updateCol);
                }
                multiGpoKeys.put(valueName, updateCol);
                for(int j=0;j<itemNodeList.getLength();j++){
                    Element item= (Element)itemNodeList.item(j);
                    Element value= (Element)valueNodeList.item(j);
                    String itemName= item.getAttribute("displayName");
                    if(itemName.isEmpty()){
                        continue;   // For ValuList In Enum
                    }
                    itemName=itemName.replaceAll("\\(", "").replaceAll("\\)", "").replaceAll("\\$", "");
                    itemName=itemName.substring(7);
                    String statusValue=getElementValue(value);
                    String itemAdmlName="";
                    if(docAdml!=null){
                        itemAdmlName = (String) xpath.evaluate("/policyDefinitionResources/resources/stringTable/string[@id='"+itemName+"']", docAdml, XPathConstants.STRING);
                    }
                    if(itemAdmlName.length()>0){
                        itemName=itemAdmlName;
                    }
                    else{
                        itemName=splitCamelCase(itemName);
                    }
                    gpoOptions.put(statusValue, itemName);
                }
                multiGpoValues.put(valueName,gpoOptions);
            }

        }
        } catch (Exception e) {
              e.printStackTrace();
        }
    }  
    public static void updateOtherColNames(Element eElement ,int settingId,Document docAdml,String presentationName){
        try {
            String[] otherElements={"decimal","longDecimal","multiText","text"};
            for(int i=0;i<otherElements.length;i++){
                NodeList otherNodeList =  eElement.getElementsByTagName(otherElements[i]); 
                if(otherNodeList.getLength()>0){
                    for(int j=0;j<otherNodeList.getLength();j++){
                        Element otherElement=(Element) otherNodeList.item(j);
                        String valueName=otherElement.getAttribute("valueName");
                        String colId=otherElement.getAttribute("id");
                        String colName=colId;
                        String textLabel="";
                        if(otherElements[i].equals("text")){
                            textLabel="/label";
                        }
                        if(colId.length()>0){
                            XPath xpath = XPathFactory.newInstance().newXPath();
                            String enumColName="";
                            if(docAdml!=null){
                                enumColName = (String) xpath.evaluate("/policyDefinitionResources/resources/presentationTable/presentation[@id='"+presentationName+"']/*[@refId='"+colId+"']"+textLabel, docAdml, XPathConstants.STRING);
                            }
                            enumColName=enumColName.replaceAll("\\\\n", "").trim();
                            if(enumColName.length()>0){
                                colName=enumColName;
                            }
                            else{
                                colName=splitCamelCase(colName);
                            }
                            multiGpoKeys.put(valueName, colName);
                        }
                    }
                }
            }
        } catch (Exception e) {
              e.printStackTrace();
        }
    }
      
    public static void updateMultiValue(Element eElement,int settingId,Document docAdml,String presentationName){
        try {
            multiGpoKeys=new JSONObject();
            multiGpoValues=new JSONObject();
            updateMultiValueGeneral(settingId);
            String keyName=eElement.getAttribute("key");
            String valueName=eElement.getAttribute("valueName");
            if(valueName.length()>0){
                updateEnbledDisabled(eElement,settingId,docAdml,presentationName);
            }
            Element elementList = (Element)  eElement.getElementsByTagName("elements").item(0); 
            if(elementList!=null){
                NodeList booleanNodeList =  elementList.getElementsByTagName("boolean"); 
                if(booleanNodeList.getLength()>0){
                    updateBoolean(booleanNodeList,settingId,docAdml,presentationName);
                }
                NodeList enumNodeList =  elementList.getElementsByTagName("enum"); 
                if(enumNodeList.getLength()>0){
                    updateEnum(enumNodeList,settingId,docAdml,presentationName);
                }
                updateOtherColNames(elementList,settingId,docAdml,presentationName);
                updateMultivalueDb(settingId);
            }
            } catch (Exception e) {
                LogWriter.gpo.severe(String.format("Error in Multivalues data extraction %s", e));//No I18N
            }       
    }
    public static void updateMultivalueDb(int settingId){
        try{
            Persistence per = CommonUtil.getPersistence();
            DataObject addSingleAttr = new WritableDataObject();
            Row row = new Row("rmpmultivaluegpodata");
//            DataAccess.generateValues(row);
//            int uniqId=(int)row.get(GPO_UNIQUE_ID);
//            row.set(GPO_UNIQUE_ID, uniqId);
            row.set(GPO_MULTI_VALUE, multiGpoValues.toString());
            row.set(GPO_MULTI_KEY, multiGpoKeys.toString());
            row.set(GPO_SETTING_ID, settingId);
            addSingleAttr.addRow(row);
            per.update(addSingleAttr);
        }
        catch(Exception e){
                LogWriter.gpo.severe(String.format("Could not update the single valued DB data %s", e));//No I18N
        }
    }
    public static int readAdmlFile(String filePath){
        String language="en-US";
        boolean isNewEntryAdded=false;
        int noOfAdmxUploaded=0;
        try {
            File[] admxFiles = finder(filePath, "admx");	
            for(int i=0;i<admxFiles.length;i++){
                //ADMX files
                try{
                    isNewEntryAdded=false;
                    File fXmlFileAdmx = admxFiles[i];
                    DocumentBuilderFactory dbFactoryAdmx = DocumentBuilderFactory.newInstance();
                    DocumentBuilder dBuilderAdmx = dbFactoryAdmx.newDocumentBuilder();
                    Document docAdmx= dBuilderAdmx.parse(fXmlFileAdmx);
                    docAdmx.getDocumentElement().normalize(); 
                    String filename=admxFiles[i].getName();
                    //ADML Files
                    File admlFile = new File(filePath+"\\"+language + "\\" + (filename.split("[.]"))[0] + ".adml");
                    boolean isAdmlExist=true;
                    DocumentBuilderFactory dbFactoryAdml = DocumentBuilderFactory.newInstance();
                    DocumentBuilder dBuilderAdml = dbFactoryAdml.newDocumentBuilder();
                    Document docAdml=null;
                    if(admlFile.exists()) {
                        try{
                            docAdml = dBuilderAdml.parse(admlFile); 
                            docAdml.getDocumentElement().normalize();
                        }
                        catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                    else{
                        isAdmlExist=false;
                    }
                    XPath xpath = XPathFactory.newInstance().newXPath();
                    Node policyDef = docAdmx.getElementsByTagName("policyDefinitions").item(0); 
                    String[] listArray={"trueList","falseList","enabledList","disabledList","valueList"};
                    if (policyDef.getNodeType() == policyDef.ELEMENT_NODE) {
                        Element polDefele = (Element) policyDef; 
                        NodeList policy = polDefele.getElementsByTagName("policy");
                        String policyName="",elementValue="",elementKey="",rawFileEntry="",className="",displayName="",presentationName="";
                        int classType=0;
                        for (int temp = 0; temp < policy.getLength(); temp++) {
                            int settingId=getNewId(GPO_SETTING_ID);
                            Node nNode = policy.item(temp);
                            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                               boolean isMultiValued=false;
                               Element eElement = (Element) nNode;
                                policyName= eElement.getAttribute("displayName");
                                policyName=policyName.replaceAll("\\(", "").replaceAll("\\)", "").replaceAll("\\$", "");
                                policyName=policyName.substring(7);
                                presentationName= eElement.getAttribute("presentation");
                                if(presentationName.length()>0){
                                    presentationName=presentationName.replaceAll("\\(", "").replaceAll("\\)", "").replaceAll("\\$", "");
                                    presentationName=presentationName.substring(13);
                                }
                               className=eElement.getAttribute("class");
                               elementKey=eElement.getAttribute("key");
                               elementValue=eElement.getAttribute("valueName");
                               if(isAdmlExist){
                                    String displayNameStr = (String) xpath.evaluate("/policyDefinitionResources/resources/stringTable/string[@id='"+policyName+"']", docAdml, XPathConstants.STRING);	//NO I18N
                                    if(displayNameStr.length()>0){
                                        displayName=displayNameStr;
                                    }
                                    else{
                                        displayName=policyName;
                                    }
                                }
                                else{
                                    displayName=policyName;
                                }
                               if(className.equals("Both")){
                                    classType=1;
                               }
                               else if(className.equals("User")){
                                   classType=2;
                               }
                               else{ // Machine
                                   classType=3;
                               }
                               boolean flag=false;
                               if(elementValue.length()>0){
                                    rawFileEntry=elementKey+"!"+elementValue;
                                    modifyAndUpdate(settingId,filename,displayName,classType,rawFileEntry);
                                    flag=true;
                                }
                                for(int q=0;q<5;q++){
                                    NodeList nodeElementList=  eElement.getElementsByTagName(listArray[q]);
                                   for(int k=0;k<nodeElementList.getLength();k++){
                                       Element elementList=(Element)nodeElementList.item(k);
                                       NodeList itemList=elementList.getElementsByTagName("item");
                                       for(int p=0;p<itemList.getLength();p++){
                                           Element elementitem=(Element)itemList.item(p);
                                           String itemValue=elementitem.getAttribute("valueName");
                                           String key=elementitem.getAttribute("key");
                                           if(key.isEmpty()){
                                                continue;
                                           }
                                           rawFileEntry=key+"!"+itemValue;
                                            modifyAndUpdate(settingId,filename,displayName,classType,rawFileEntry);
                                            isMultiValued=true;
                                       }
                                   }
                                }
                                NodeList carNameList = eElement.getElementsByTagName("elements"); 
                                if(carNameList.getLength()!=0){
                                    Node node1 = carNameList.item(0); 
                                    if (node1.getNodeType() == node1.ELEMENT_NODE) {
                                        Element car = (Element) node1;
                                        NodeList text = car.getChildNodes();
                                        for (int x = 0; x < text.getLength(); x++) {
                                            Node textNode = text.item(x);
                                            if (textNode.getNodeType() == Node.ELEMENT_NODE) { 
                                                if(!flag){
                                                    flag=true;
                                                }
                                                else{
                                                    isMultiValued=true;
                                                }
                                                Element textelement = (Element) textNode;
                                                String textKey=textelement.getAttribute("key");
                                                String textValue=textelement.getAttribute("valueName");
                                                if(textelement.getTagName().equalsIgnoreCase("list")){
                                                    if(textKey.length()>0){
                                                        rawFileEntry=textKey;
                                                    }
                                                    else{
                                                        rawFileEntry=elementKey;
                                                    }
                                                    modifyAndUpdate(settingId,filename,displayName,classType,rawFileEntry);
                                                    isMultiValued=true;
                                                }
                                                if(textValue.length()>0){
                                                    if(textKey.length()>0){
                                                        rawFileEntry=textKey+"!"+textValue;
                                                    }
                                                    else{
                                                        rawFileEntry=elementKey+"!"+textValue;
                                                    }
                                                    modifyAndUpdate(settingId,filename,displayName,classType,rawFileEntry);
                                                }
                                            }
                                        }
                                    }
                                }
                                boolean addedNewEntry=checkIfPolicyAdded(settingId);
                                if(addedNewEntry){
                                    isNewEntryAdded=true;
                                    if(isMultiValued){
                                        updateMultiValue(eElement,settingId,docAdml,presentationName);
                                        if(classType==1 ){
                                           updateMultiValue(eElement,settingId+1,docAdml,presentationName);
                                        }
                                    }
                                    else{
                                        updateSingleValue(eElement,settingId,docAdml);
                                        if(classType==1 ){
                                            updateSingleValue(eElement,settingId+1,docAdml);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                catch(Exception e){
                    LogWriter.gpo.info(e.getMessage());//No I18N
                }
                if(isNewEntryAdded){
                    noOfAdmxUploaded++;
                }
            }
        } catch (Exception e) {
                    LogWriter.gpo.info(e.getMessage());//No I18N
        }
        return noOfAdmxUploaded;
    }
     public static boolean checkIfPolicyAdded(int settingId) {
        boolean addedNewEntry=false;
        try {
            Column col = Column.getColumn(GPO_TABLE_GENERAL, "*");
            SelectQuery sQuery = new SelectQueryImpl(Table.getTable(GPO_TABLE_GENERAL));
            Criteria criteria = new Criteria(Column.getColumn(GPO_TABLE_GENERAL, GPO_SETTING_ID), settingId, QueryConstants.EQUAL, false);
            sQuery.addSelectColumn(col);
            sQuery.setCriteria(criteria);
            DataObject policyTable = CommonUtil.getPersistence().get(sQuery);
            if (!policyTable.isEmpty()) {
                    addedNewEntry=true;
            }
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format(" %s", LogWriter.getStackTrace(e)));//No I18N
        }
        return addedNewEntry;
    }

    public static ArrayList<Properties> getPolicyProperties(String policyPath, String columnName, String tableName) {
        try {
            Properties attributeProperties = new Properties();
            Column col = Column.getColumn(tableName, "*");
            SelectQuery sQuery = new SelectQueryImpl(Table.getTable(tableName));
            sQuery.addSelectColumn(col);
            //sq.setCriteria(c);
            DataObject policyTable = CommonUtil.getPersistence().get(sQuery);
            if (!policyTable.isEmpty()) {
                ArrayList<Properties> values = new ArrayList<Properties>();
                Criteria criteria = new Criteria(Column.getColumn(tableName, columnName), policyPath, QueryConstants.LIKE, false);
                Iterator iterator = policyTable.getRows(tableName, criteria);
                if (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    for (String column : (String[]) tableColumns.get(tableName)) {
                        Object columnVal = row.get(column);
                        String strVal = columnVal == null ? "" : columnVal.toString();
                        attributeProperties.setProperty(column, strVal);
                    }
                    values.add(attributeProperties);
                } else {
                    LogWriter.gpo.info(String.format("The given attrName:%s is not present in the table %s", policyPath, tableName));//No I18N
                }
                return values;
            } else {
                LogWriter.gpo.info(String.format("The given attrName:%s is not present in the table %s", policyPath, tableName));//No I18N
            }
            return null;
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format(" %s", e));//No I18N
            return null;
        }
    }
    public static boolean checkIfDuplicate(String rawFileEntry) {
        boolean isDuplicate=true;
        try {
            Column col = Column.getColumn(GPO_TABLE_GENERAL, "*");
            SelectQuery sQuery = new SelectQueryImpl(Table.getTable(GPO_TABLE_GENERAL));
            sQuery.addSelectColumn(col);
            Criteria criteria = new Criteria(Column.getColumn(GPO_TABLE_GENERAL, GPO_RAW_FILE_ENTRY), rawFileEntry, QueryConstants.EQUAL, false);
            sQuery.setCriteria(criteria);
            DataObject policyTable = CommonUtil.getPersistence().get(sQuery);
            if (policyTable.isEmpty()) {
                     isDuplicate=false;
            }
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format(" %s", LogWriter.getStackTrace(e)));//No I18N
        }
        return isDuplicate;
    }

    public static ArrayList<Properties> getPolicyProperties(Integer settingId, String columnName, String tableName) {
        try {
            Criteria criteria = new Criteria(Column.getColumn(tableName, columnName), settingId, QueryConstants.EQUAL);
            Column col = Column.getColumn(tableName, "*");
            SelectQuery sQuery = new SelectQueryImpl(Table.getTable(tableName));
            sQuery.addSelectColumn(col);
            //sq.setCriteria(c);
            DataObject attributeTable = CommonUtil.getPersistence().get(sQuery);
            if (!attributeTable.isEmpty()) {
                ArrayList<Properties> values = new ArrayList<Properties>();
                Iterator iter = attributeTable.getRows(tableName, criteria);
                while (iter.hasNext()) {
                    Properties attributeProperties = new Properties();
                    Row row = (Row) iter.next();
                    for (String column : (String[]) tableColumns.get(tableName)) {
                        Object colVal = row.get(column);
                        attributeProperties.setProperty(column, colVal == null ? "" : colVal.toString());
                    }
                    values.add(attributeProperties);
                }
                return values;
            } else {
                LogWriter.gpo.info(String.format("The given policy Id:%s is not present in the table %s", settingId, tableName));//No I18N
            }
            return null;
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format(" %s", LogWriter.getStackTrace(e)));//No I18N
            return null;
        }
    }

    public static ArrayList<Properties> getPolicySettings(String tableName) {
        try {
            ArrayList attributeList = new ArrayList<Properties>();
            SelectQuery sQuery = new SelectQueryImpl(Table.getTable(tableName));
            Column col = Column.getColumn(tableName, "*");
            sQuery.addSelectColumn(col);
            DataObject dataobj = CommonUtil.getPersistence().get(sQuery);
            if (!dataobj.isEmpty()) {
                Iterator iterator = dataobj.getRows(tableName);
                while (iterator.hasNext()) {
                    Properties attributeProperties = new Properties();
                    Row row = (Row) iterator.next();
                    for (String column : (String[]) tableColumns.get(tableName)) {
                        attributeProperties.setProperty(column, row.get(column).toString());
                    }
                    attributeList.add(attributeProperties);
                }
                return attributeList;
            } else {
                LogWriter.gpo.info(String.format("The given table %s is empty", tableName));//No I18N
            }
            return null;

        } catch (Exception e) {
            LogWriter.gpo.severe(String.format(" %s", e));//No I18N
            return null;
        }
    }
}

//ignoreI18n_end