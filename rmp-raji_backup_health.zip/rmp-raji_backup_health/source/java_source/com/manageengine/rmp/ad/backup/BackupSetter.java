/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.backup;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DerivedColumn;
import com.adventnet.ds.query.DerivedTable;
import com.adventnet.ds.query.Operation;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.RMPCommonFlags;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.db.dbutil.DBUtil;
import java.sql.Types;
import java.util.HashSet;
import java.util.UUID;

/**
 *
 * @
 */
//ignoreI18n_start
public class BackupSetter {

    public static void updatePreviousObjectSelection(Long domainId) {
        try {
            Column isDisabled = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "SYNC_STATUS"), RMPCommonFlags.IsDisabled.maskValue);
            isDisabled.setType(Types.INTEGER);
            Criteria disabledCriteria = new Criteria(isDisabled, 0, QueryConstants.GREATER_THAN); // object disabled
            BackupUtil.updateCurrentInfoPreviousBackupSettings(domainId, disabledCriteria);
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.backup.severe(String.format("BackupSetter.updateCurrentInfoPreviousBackupSettings domainId:%s \nexcep:%s", domainId, e));
        }
    }

    public static void disabledObjectUpdate(Long domainId, boolean trackDisabledObjects) {
        try {
            String currentInfoTable = TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId;
            Column isBackupSet = Column.createFunction("AND_OPERATOR", Column.getColumn(currentInfoTable, "IS_BACKUP_SET"), RMPCommonFlags.IsBackupSet.maskValue);
            isBackupSet.setType(Types.INTEGER);
            Column isDisabled = Column.createFunction("AND_OPERATOR", Column.getColumn(currentInfoTable, "SYNC_STATUS"), RMPCommonFlags.IsDisabled.maskValue);
            isDisabled.setType(Types.INTEGER);
            Criteria disabledCriteria = new Criteria(isDisabled, 0, QueryConstants.GREATER_THAN); //disabled objects
            Criteria parentSelectForBackup = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "TO_BACKUP"), true, QueryConstants.EQUAL);
           
            SelectQuery subQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OU_INFO));
            subQuery.addSelectColumn(Column.getColumn(TableName.RMP_OU_INFO, "OBJECT_GUID"));
            subQuery.setCriteria(parentSelectForBackup);

            DerivedTable objectGuidTable = new DerivedTable("OBJECT_GUIDTABLE",subQuery);
            SelectQuery objectGuidSelect = new SelectQueryImpl(objectGuidTable);
            objectGuidSelect.addSelectColumn(Column.getColumn("OBJECT_GUIDTABLE", "OBJECT_GUID"));
            
            Criteria objectGuidFilter = new Criteria(Column.getColumn(currentInfoTable, "PARENT_GUID"), new DerivedColumn("OBJECT_GUID",objectGuidSelect), QueryConstants.IN);
            
            UpdateQuery updateQuery = new UpdateQueryImpl(currentInfoTable);
            Column setBackup;
            if (trackDisabledObjects == true) {
                Criteria notSetCriteria = new Criteria(isBackupSet, 0, QueryConstants.EQUAL);//Backup not set
                setBackup = Column.createFunction("OR_OPERATOR", Column.getColumn(currentInfoTable, "IS_BACKUP_SET"), RMPCommonFlags.IsBackupSet.maskValue);
                updateQuery.setCriteria(disabledCriteria.and(notSetCriteria).and(objectGuidFilter));

            } else {
                int notsetBackupMask = RMPCommonFlags.IsBackupSet.maskValue;
                notsetBackupMask += 1;
                Criteria setCriteria = new Criteria(isBackupSet, 0, QueryConstants.GREATER_THAN);//Backup set
                updateQuery.setCriteria(disabledCriteria.and(setCriteria).and(objectGuidFilter));
                setBackup = Column.createFunction("AND_OPERATOR", Column.getColumn(currentInfoTable, "IS_BACKUP_SET"), -notsetBackupMask);
            }
            setBackup.setType(Types.INTEGER);
            updateQuery.setUpdateColumn("IS_BACKUP_SET", setBackup);
            
            DBUtil.executeUpdate(currentInfoTable, "IS_BACKUP_SET", setBackup, updateQuery.getCriteria());
            //CommonUtil.getPersistence().update(updateQuery);
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.backup.severe(String.format("BackupUtil.disabledObjectUpdate domainId:%s \nexcep:%s", domainId, e));
        }
    }
    
    public static void updateObjectsNotInDC(Long domainId, HashSet<UUID> objectsInDC, String objectType){
        try{
            LogWriter.backup.info(String.format("BackupUtil.updateObjectsNotInDC domainId:%s", domainId));
            String currentInfo = TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId;            
            Column isNotInDC = Column.createFunction("OR_OPERATOR", Column.getColumn(currentInfo, "SYNC_STATUS"),RMPCommonFlags.IsNotPresentInDC.maskValue);
            isNotInDC.setType(Types.INTEGER);
            Criteria criteria = new Criteria(Column.getColumn(currentInfo, "OBJECT_GUID"), objectsInDC.toArray(), QueryConstants.NOT_IN, false);
            criteria = criteria.and(new Criteria(Column.getColumn(currentInfo, "OBJECT_TYPE"),ObjectType.parse(objectType).maskValue, QueryConstants.EQUAL));
            DBUtil.executeUpdate(currentInfo, "SYNC_STATUS", isNotInDC, criteria);
            //CommonUtil.getPersistence().update(query);
        }
        catch(Exception e){
            e.printStackTrace();
            LogWriter.backup.severe(String.format("BackupUtil.updateObjectsNotInDC domainId:%s \nexcep:%s", domainId, e));
        }
    }
    
     public static void updateObjectsInDC(Long domainId, HashSet<UUID> objectsInDC, String objectType){
        try{
            LogWriter.backup.info(String.format("BackupUtil.updateObjectsInDC domainId:%s", domainId));
            String currentInfo= TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId;            
            Column objectsNotInDC = Column.createFunction("AND_OPERATOR", Column.getColumn(currentInfo, "SYNC_STATUS"), RMPCommonFlags.IsNotPresentInDC.maskValue);
            objectsNotInDC.setType(Types.INTEGER);
            Criteria criteria = new Criteria(Column.getColumn(currentInfo, "OBJECT_GUID"),objectsInDC.toArray(), QueryConstants.IN);
            criteria = criteria.and(new Criteria(Column.getColumn(currentInfo, "OBJECT_TYPE"),ObjectType.parse(objectType).maskValue, QueryConstants.EQUAL));
            criteria = criteria .and (new Criteria(objectsNotInDC, 0, QueryConstants.GREATER_EQUAL));
            Column oper = Column.createOperation(Operation.operationType.SUBTRACT, Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "SYNC_STATUS"), RMPCommonFlags.IsNotPresentInDC.maskValue);
            oper.setType(Types.INTEGER);
            DBUtil.executeUpdate(currentInfo, "SYNC_STATUS", oper, criteria);
            //CommonUtil.getPersistence().update(query);
        }
        catch(Exception e){
            e.printStackTrace();
            LogWriter.backup.severe(String.format("BackupUtil.updateObjectsInDC domainId:%s \nexcep:%s", domainId, e));
        }
    }
    
}

//ignoreI18n_end
