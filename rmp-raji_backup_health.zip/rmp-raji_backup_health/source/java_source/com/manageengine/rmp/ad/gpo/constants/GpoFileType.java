/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.constants;

/**
 *
 * @author lucky-2306
 */
public enum GpoFileType {

    Pol(1),
    Gpt(2),
    Audit(3),
    Other(0);
    
    public int id;
    public static GpoFileType[] values;
    static {
        values = GpoFileType.values();
    }
    GpoFileType(int id) {
        this.id = id;
    }
    public static GpoFileType getGpoFileType(String type) {
        if (type.equalsIgnoreCase("REG_KEY")) {
            return GpoFileType.Pol;
        }
        if (type.equalsIgnoreCase("SECURITY")) {
            return GpoFileType.Gpt;
        }
        if (type.equalsIgnoreCase("AUDIT")) {
            return GpoFileType.Audit;
        }
        return GpoFileType.Other;
    }
}
