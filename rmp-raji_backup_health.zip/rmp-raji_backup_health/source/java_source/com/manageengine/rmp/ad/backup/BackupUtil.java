/**
 * $Id$
 */
//ignoreI18n_start
package com.manageengine.rmp.ad.backup;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.DerivedColumn;
import com.adventnet.ds.query.Operation;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.Range;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;

import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.DeepClone;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.me.util.RowHelper;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.constants.ChangeType;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.RMPCommonFlags;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.oumanager.OUManager;
import com.manageengine.rmp.patch.PatchManager;
import com.manageengine.rmp.util.Attribute;
import com.manageengine.rmp.util.BitSetUtil;
import com.manageengine.rmp.util.LdapUtil;

import java.io.ByteArrayInputStream;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.logging.Level;

import org.json.JSONArray;
import org.json.JSONObject;

public class BackupUtil {

    public static DataObject getLastBackedupObjects(long domainId, ArrayList<String> objectGuids) {
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId));
            query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "*"));
            Criteria objectGuidCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"), objectGuids.toArray(), QueryConstants.IN);
            query.setCriteria(objectGuidCriteria);
            return CommonUtil.getPersistence().get(query);
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.getLastBackedupObjects B domainId:%s \nnexcep:%s", domainId, LogWriter.getStackTrace(e)));
            return null;
        }
    }

    public static BackupObject getLastBackedupObjectInfo(Long domainId, UUID objectGuid, DataObject dataObject) {
        BackupObject backupObject = new BackupObject();
        try {
            Criteria criteria =new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"), objectGuid.toString(), QueryConstants.EQUAL);
            Iterator rmpObjCurrentInfoIterator = dataObject.getRows(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, criteria);
            if (!rmpObjCurrentInfoIterator.hasNext()) {
                backupObject.objId = BackupUtil.emptyGuid;
                return backupObject;
            } else {
                RowHelper rowHelper = new RowHelper((Row) rmpObjCurrentInfoIterator.next());
                backupObject = getBackupObjectInfo(rowHelper, domainId);
            }
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.getLastBackedupObjectInfo B domainId:%s objectGuid:%s \nnexcep:%s", domainId, objectGuid,  LogWriter.getStackTrace(e)));
        }
        return backupObject;
    }
    
    public static BackupObject getBackupObjectInfo(RowHelper rowHelper, Long domainId){
        BackupObject backupObject = new BackupObject();
        try{
            backupObject.objId = rowHelper.getUUID("OBJECT_GUID");
            backupObject.objectSid = rowHelper.getString("OBJECT_SID");
            backupObject.objTyp = ObjectType.parse(rowHelper.getLong("OBJECT_TYPE"));
            backupObject.changeTyp = rowHelper.getInteger("CHANGE_TYPE");
            backupObject.domainId = domainId;
            backupObject.linkId = rowHelper.getLong("LINK_ID");
            backupObject.cnt = rowHelper.getInteger("COUNT");
            int isBackupSet = rowHelper.getInteger("IS_BACKUP_SET");
            backupObject.isBackupSet = (isBackupSet & RMPCommonFlags.IsBackupSet.maskValue) > 0 ;
            backupObject.isObjNewlySelected = (isBackupSet & RMPCommonFlags.IsObjNewlySelected.maskValue) > 0 ;
            backupObject.initChangeMask();
            backupObject.changeMask = rowHelper.getBitSet("CHANGE_MASK");
            backupObject.data = new JSONObject(rowHelper.getString("CHANGE_DATA"));
            if(backupObject.data.length() > 0) {
                backupObject.distinguishedName = backupObject.data.get("dn").toString();
                if (backupObject.data.has("b11")) {
                    backupObject.objNam = LdapUtil.getObjectAttributeValue(backupObject.data.get("b11").toString());
                }
                if (backupObject.data.has("o52")) {
                    backupObject.oldDn = backupObject.data.get("o52").toString();
                }
                if(backupObject.data.has("PARENT_DN")) {
                    backupObject.ouNam = LdapUtil.getCanonicalName(backupObject.data.get("PARENT_DN").toString());
                }
            }else {
                backupObject.distinguishedName = rowHelper.getString("OBJECT_DN"); 
            }
            if(backupObject.objNam == null) {
                backupObject.objNam = LdapUtil.getCommonNameFromDeletedObjectDN(backupObject.distinguishedName);
            }
            if(backupObject.ouNam == null) {
                backupObject.ouNam = LdapUtil.getParentCanonical(backupObject.distinguishedName);
            }
            backupObject.linksData = new JSONObject(rowHelper.getString("LINKS_DATA"));
            int syncStatus = rowHelper.getInteger("SYNC_STATUS");
            backupObject.hasHistory = (syncStatus & RMPCommonFlags.HasHistory.maskValue) > 0;
            backupObject.hasChange = (syncStatus & RMPCommonFlags.HasChange.maskValue) > 0;
            backupObject.isDeleted = (syncStatus & RMPCommonFlags.IsDeleted.maskValue) > 0;
            backupObject.isDisabled = (syncStatus & RMPCommonFlags.IsDisabled.maskValue) > 0;
            backupObject.isNotPresentInDC =  (syncStatus & RMPCommonFlags.IsNotPresentInDC.maskValue) > 0;
            try {
                backupObject.ouId = rowHelper.getUUID("PARENT_GUID");
            } catch (Exception e) {}
        }catch(Exception e){
            LogWriter.backup.severe(String.format("BackupUtil.getBackupObjectInfo B domainId:%s objectGuid:%s \nnexcep:%s", backupObject.domainId, backupObject.objId, LogWriter.getStackTrace(e)));
        }
        return backupObject;
    }
    
    private static int ouIdCompare(BackupObject currentChange, BackupObject lastSnapshot)
    {
        currentChange.changeTyp |= ChangeType.Moved.maskValue;
        lastSnapshot.ouId = currentChange.ouId;
        return 1;
    }

    public static Boolean compare(BackupObject currentChange, BackupObject lastSnapshot, BackupImpl backupHook) {
        Boolean isChanged = false;
        try {
            if (lastSnapshot.isBackupSet != currentChange.isBackupSet) {
                currentChange.trackingData = currentChange.isBackupSet ? 1 : -1;
            }
            if (backupHook.isInitBackup && currentChange.isDeleted && currentChange.isBackupSet) {
                currentChange.hasHistory = false;
                currentChange.trackingData = 0;
            }
            if (!currentChange.isBackupSet) {
                currentChange.hasChange = true;
                if (lastSnapshot.linkId == null) {

                    currentChange.linkId = getNewLinkId(backupHook.domainId);
                    lastSnapshot.hasHistory = currentChange.hasHistory = false;
                    currentChange.changeTyp = currentChange.isDeleted ? ChangeType.Deleted.maskValue : ChangeType.Added.maskValue;
                    currentChange.objNam = currentChange.objTyp != ObjectType.GroupPolicy ? LdapUtil.getObjectAttributeValue(currentChange.objNam) : currentChange.objNam;
                    DeepClone.copyTo(currentChange, lastSnapshot);
                    lastSnapshot.cnt = 0;
                    return true;
                }else if (currentChange.isDeleted) {
                    currentChange.changeTyp = ChangeType.Deleted.maskValue;
                }else{
                    checkChangeType(currentChange, lastSnapshot, true, backupHook.trackDisabledObjects);
                }
                currentChange.hasHistory = lastSnapshot.hasHistory;
                if ((currentChange.objNam != null && !currentChange.objNam.equals(lastSnapshot.objNam)) || (currentChange.ouNam != null && !currentChange.ouNam.equals(lastSnapshot.ouNam)) 
                        || (currentChange.ouId != null && !currentChange.ouId.equals(lastSnapshot.ouId) && currentChange.ouNam != null && currentChange.ouNam.equals(lastSnapshot.ouNam) && (!currentChange.isDeleted && lastSnapshot.changeTyp != ChangeType.Deleted.maskValue))){
                    if (currentChange.objTyp == ObjectType.OU) {
                        OUManager.ouChangeLocationUpdate(currentChange.domainId, currentChange.objId, currentChange.objNam, currentChange.ouNam, currentChange.distinguishedName,false);//Location Update instantly //ToDo:change accordingly later
                    }
                    return true;
                }
                return false;
            }
            currentChange.hasChange = false;
            currentChange.hasHistory = true;
            boolean lastSnapshot_linkId = true;
            Integer propertyChangeCount = BitSetUtil.getNumberOfSetBits(currentChange.changeMask);
            if (currentChange.isDeleted) {
                currentChange.changeTyp = ChangeType.Deleted.maskValue;
                propertyChangeCount = -1;
                currentChange.objNam = currentChange.objTyp != ObjectType.GroupPolicy ? LdapUtil.getObjectAttributeValue(currentChange.objNam) : currentChange.objNam;
                if (lastSnapshot.linkId == null || (lastSnapshot.linkId != null && !lastSnapshot.hasHistory)) {
                    currentChange.trackingData = 0;
                    lastSnapshot.hasHistory = currentChange.hasHistory = false;
                    currentChange.isObjNewlySelected =  true;
                }
                else if (lastSnapshot.isBackupSet && lastSnapshot.hasHistory) {
                    currentChange.trackingData = -1;
                }
            }
            if (lastSnapshot.linkId == null) {//case: object backed up for first time
                lastSnapshot_linkId = false;
                if (!currentChange.isDeleted) {
                    if (backupHook.isFullSync) {
                        currentChange.changeTyp = ChangeType.Added.maskValue;
                        propertyChangeCount = -1;
                    } else {
                        //ToDo: set changeType to added if OU deselcetd for previous sync
                        currentChange.changeTyp = ChangeType.Created.maskValue;
                        propertyChangeCount = -1;
                    }
                }
                DeepClone.copyTo(currentChange, lastSnapshot);
                currentChange.linkId = lastSnapshot.linkId = getNewLinkId(backupHook.domainId);
                lastSnapshot.cnt = 0;
                return true;
            }
            if (((lastSnapshot.changeTyp & ChangeType.Deleted.maskValue) > 0) && !currentChange.isDeleted) {
                currentChange.changeTyp = ChangeType.Recycled.maskValue;
                backupDN(currentChange, lastSnapshot, backupHook);
                propertyChangeCount = -1;
                currentChange.trackingData = 1;
            }
            if (!currentChange.ouNam.equals(lastSnapshot.ouNam)) {//This logic wont work if one object is moved from one to another. And both of the source and destination ou names are interchanged, both of the OUs are in same level. This is not a practical use case, so to avoid unneeded db ref to get parentGuid This logic is implemented
                if (currentChange.objTyp == ObjectType.OU) {
                    OUManager.ouChangeLocationUpdate(currentChange.domainId, currentChange.objId, currentChange.objNam, currentChange.ouNam, currentChange.distinguishedName,false);//Location Update instantly //ToDo:change accordingly later
                }
                if (!currentChange.ouId.equals(lastSnapshot.ouId) && !currentChange.isDeleted) {
                    propertyChangeCount = propertyChangeCount - ouIdCompare(currentChange, lastSnapshot);
                }
                lastSnapshot.ouNam = currentChange.ouNam;
                isChanged = true;
            } else if (lastSnapshot.ouId != null) {
                if( !lastSnapshot.ouId.equals(currentChange.ouId) && lastSnapshot.ouNam != null && lastSnapshot.ouNam.equals(currentChange.ouNam) && (!currentChange.isDeleted && lastSnapshot.changeTyp != ChangeType.Deleted.maskValue)) {
                    propertyChangeCount = propertyChangeCount - ouIdCompare(currentChange, lastSnapshot);
                    isChanged = true;
                 } else { 
                    currentChange.ouId = lastSnapshot.ouId;
                 }
            } 
            if (currentChange.objNam == null) {
                currentChange.objNam = lastSnapshot.objNam;
            } else if (!lastSnapshot.objNam.equals(currentChange.objNam)) {
                currentChange.changeTyp |= ChangeType.Renamed.maskValue;
                propertyChangeCount--;
                lastSnapshot.objNam = currentChange.objNam;
                if (currentChange.objTyp == ObjectType.OU) {
                    OUManager.ouChangeLocationUpdate(currentChange.domainId, currentChange.objId, currentChange.objNam, currentChange.ouNam, currentChange.distinguishedName,false);//Location Update instantly //ToDo:change accordingly later
                }
                isChanged = true;
            }
            if (lastSnapshot.changeTyp != currentChange.changeTyp && !(!currentChange.isObjNewlySelected && currentChange.isBackupSet)) {
                lastSnapshot.changeTyp = currentChange.changeTyp;
                isChanged = true;
            }
            if (propertyChangeCount > 0 && !ChangeType.isDeleted(currentChange.changeTyp)) {
                currentChange.changeTyp |= ChangeType.Modified.maskValue;
            }
            if(!backupHook.isInitBackup && checkChangeType(currentChange, lastSnapshot, lastSnapshot_linkId, backupHook.trackDisabledObjects)){
                isChanged = true;
            } else {
                lastSnapshot.changeTyp = currentChange.changeTyp;
                isChanged = true;
            }
            //ToDo: objectSid field comparison
            currentChange.objectSid = lastSnapshot.objectSid;
            if (isChanged == false) {
                currentChange.linkId = lastSnapshot.linkId;
                return false;
            } else {
                currentChange.linkId = getLinkId(backupHook.domainId,currentChange);
                if (currentChange.linkId == null) {
                    currentChange.linkId = getNewLinkId(backupHook.domainId);
                    lastSnapshot.linkId = currentChange.linkId;
                    return true;
                }
                lastSnapshot.linkId = currentChange.linkId;
                return false;
            }
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.compare object:%s/%s \nexcep:%s %S", currentChange.ouNam, currentChange.objNam, e, LogWriter.getStackTrace(e)));
            return false;
        }
    }
    private static Boolean checkChangeType(BackupObject currentChange, BackupObject lastSnapshot, Boolean lastSnapshot_linkId, boolean isDisabledTracking){
        boolean hasChange = false, toTrack = true;
        try{
            if(lastSnapshot_linkId && !currentChange.isDeleted && (!currentChange.isBackupSet || lastSnapshot.hasChange)) {
                hasChange = true;
                if(lastSnapshot.changeTyp == ChangeType.Deleted.maskValue && (!lastSnapshot.hasHistory && !lastSnapshot.hasChange)) {
                    currentChange.changeTyp = ChangeType.ReAdded.maskValue;
                } else if(lastSnapshot.hasHistory) {
                    toTrack = false;
                    currentChange.changeTyp = ChangeType.ReAdded.maskValue;
                } else {
                    currentChange.changeTyp = ChangeType.Added.maskValue;
                }  
                copyFromLastSnapshot(currentChange, lastSnapshot);
                currentChange.isObjNewlySelected = currentChange.isBackupSet;
                if (isDisabledTracking || currentChange.isDisabled == lastSnapshot.isDisabled || currentChange.changeTyp == ChangeType.Recycled.maskValue) {
                    currentChange.trackingData = currentChange.isBackupSet && toTrack ? 1 : 0;
                }
            }
        }catch(Exception e){
            LogWriter.backup.severe(String.format("BackupUtil.isObjectPreviouslyDeselected domainId:%s \nexcep:%s", currentChange.domainId, LogWriter.getStackTrace(e)));
        }
        return hasChange;
    }
    
    private static void copyFromLastSnapshot(BackupObject currentChange, BackupObject lastSnapshot) {
        currentChange.data = lastSnapshot.data;
        currentChange.changeMask = lastSnapshot.changeMask;
	currentChange.linksData = lastSnapshot.linksData;
    }

    private static Boolean backupDN(BackupObject currentChange, BackupObject lastSnapshot, BackupImpl backupHook) {
        ArrayList<String> value = new ArrayList<String>();
        value.add(currentChange.distinguishedName);
        Map.Entry<Object, ?> prop = new AbstractMap.SimpleEntry<Object, ArrayList>("distinguishedName", value);
        backupHook.backupAttribute(currentChange, lastSnapshot, null, prop,true);
        return true;
    }
    public static UUID emptyGuid = new UUID(0, 0);

    public static UUID getOuGuid(Long domainId, String ouCanonicalName) {//ToDo: remove this function usage. use getOuConfig instead
        try {
            Criteria ouCanoicalNameCriteria = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "CANONICAL_NAME"), ouCanonicalName, QueryConstants.EQUAL);
            OuConfig ouConfig = getOuConfig(domainId, ouCanoicalNameCriteria);
            if (ouConfig != null) {
                return ouConfig.objectGuid;
            }
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.getOuConfig domainId:%s ouCanonicalName:%s \nexcep:%s", domainId, ouCanonicalName, LogWriter.getStackTrace(e)));
            return null;
        }
        return emptyGuid;
    }

    private static Long getLinkId(long domainId,BackupObject currentChange) {

        try {
            //String query = "select linkId from rmpobjmetaverinfo where domainId=" + currentChange.domainId + " and objId=cast('" + currentChange.objId + "' as uuid) and ouId=cast('" + currentChange.ouId + "' as uuid) and objTyp=" + currentChange.objTyp + " and changeTyp=" + currentChange.changeTyp + " and ouNam = '" + currentChange.ouNam + "' and objNam= '" + currentChange.objNam + "'";
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId));
            query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "LINK_ID"));
            Criteria objectGuidCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "OBJECT_GUID"), currentChange.objId.toString(), QueryConstants.EQUAL);
            Criteria parentGuidCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "PARENT_GUID"), currentChange.ouId.toString(), QueryConstants.EQUAL);
            Criteria objectTypeCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "OBJECT_TYPE"), currentChange.objTyp.maskValue, QueryConstants.EQUAL);
            Criteria changeTypeCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "CHANGE_TYPE"), currentChange.changeTyp, QueryConstants.EQUAL);
            Criteria locationCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "OBJECT_LOCATION"), currentChange.ouNam, QueryConstants.EQUAL);
            Criteria objectNameCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "OBJECT_NAME"), currentChange.objNam, QueryConstants.EQUAL);
            query.setCriteria(objectGuidCriteria.and(parentGuidCriteria).and(objectTypeCriteria).and(changeTypeCriteria).and(locationCriteria).and(objectNameCriteria));
            DataObject dataObject = CommonUtil.getPersistence().get(query);
            if (!dataObject.isEmpty()) {
                RowHelper row = new RowHelper(dataObject.getFirstRow(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId));
                return row.getLong("LINK_ID");
            }
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.getLinkId B object:%s/%s \nexcep:%s", currentChange.ouNam, currentChange.objNam, LogWriter.getStackTrace(e)));
        }
        return null;
    }

    public static Row getBackupStat(Long domainId) {
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_BACKUP_STAT));
            query.addSelectColumn(Column.getColumn(TableName.RMP_BACKUP_STAT, "*"));
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.RMP_BACKUP_STAT, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            query.setCriteria(domainCriteria);
            DataObject dataObject = CommonUtil.getCachedPersistence().get(query);
            if (dataObject.isEmpty()) {
                return null;
            }
            Row row = dataObject.getFirstRow(TableName.RMP_BACKUP_STAT);
            //String parentGuid_string = (String) row.get("OBJECT_GUID");
            return row;
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.getBackupStat domainId:%s \nexcep:%s", domainId, LogWriter.getStackTrace(e)));
            return null;
        }
    }

    public static OuConfig getOuConfig(Long domainId, UUID ouGuid) {
        try {
            Criteria ouGuidCriteria = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "OBJECT_GUID"), ouGuid.toString(), QueryConstants.EQUAL);
            return getOuConfig(domainId, ouGuidCriteria);
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.getOuConfig domainId:%s ouGuid:%s \nexcep:%s", domainId, ouGuid.toString(), LogWriter.getStackTrace(e)));
            return null;
        }
    }

    public static OuConfig getOuConfig(Long domainId, String ouCanonicalName) {
        try {
            Criteria ouCanoicalNameCriteria = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "CANONICAL_NAME"), ouCanonicalName, QueryConstants.EQUAL);
            return getOuConfig(domainId, ouCanoicalNameCriteria);
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.getOuConfig domainId:%s ouCanonicalName:%s \nexcep:%s", domainId, ouCanonicalName, LogWriter.getStackTrace(e)));
            return null;
        }
    }
    
    public static OuConfig getOuConfigFromCanonical(Long domainId, String canonicalName) {
        try {
            Criteria ouCanoicalNameCriteria = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "CANONICAL_NAME"), canonicalName, QueryConstants.EQUAL);
            return getOuConfig(domainId, ouCanoicalNameCriteria);
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.getOuConfig domainId:%s ouCanonicalName:%s \nexcep:%s", domainId, canonicalName, LogWriter.getStackTrace(e)));
            return null;
        }
    }

    private static OuConfig getOuConfig(Long domainId, Criteria criteria) {
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OU_INFO));
            query.addSelectColumn(Column.getColumn(TableName.RMP_OU_INFO, "*"));
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            //domainCriteria = domainCriteria.and(new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "IS_DELETED"),false,QueryConstants.EQUAL));
            query.setCriteria(domainCriteria.and(criteria));
            DataObject dataObject = CommonUtil.getPersistence().get(query);
            if (dataObject.isEmpty()) {
                return null;
            }
            /*Iterator iterator = dataObject.getRows(TableName.RMP_OU_INFO);
            
             RowHelper row=null;
             while(iterator.hasNext()) {
             row =  new RowHelper((Row)iterator.next());
             }*/
            RowHelper row = new RowHelper(dataObject.getFirstRow(TableName.RMP_OU_INFO));
            return new OuConfig(row);
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.backup.severe(String.format("BackupUtil.getOuConfig domainId:%s ouGuid:%s \nexcep:%s", domainId, criteria.toString(), LogWriter.getStackTrace(e)));
            return null;
        }
    }

//    public static OuConfig getOuConfig(Long domainId, String canonicalName,DataObject dataObject) {
//        try {
//            Criteria ouCanoicalNameCriteria = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "CANONICAL_NAME"), canonicalName, QueryConstants.EQUAL);
//            RowHelper row = new RowHelper(dataObject.getRow(TableName.RMP_OU_INFO, ouCanoicalNameCriteria));
//            return new OuConfig(row,true);
//        } catch (Exception e) {
//            LogWriter.backup.severe(String.format("BackupUtil.getOuConfig domainId:%s canonical:%s \nexcep:%s", domainId, canonicalName, e));
//            return null;
//        }
//    }
    public static void removeOuCookie(String domainName) {
        try {
            Criteria c = new Criteria(Column.getColumn(TableName.ADS_AD_SYNCHRONIZATION, "DOMAIN_NAME"), domainName, QueryConstants.EQUAL);
            CommonUtil.getPersistence().delete(c);
        } catch (Exception e) {
            e.printStackTrace();
            LogWriter.backup.severe(String.format("BackupUtil.removeOuCookie domainName:%s \nexcep:%s", domainName, LogWriter.getStackTrace(e)));
        }
    }

    public static void updateBackupSettings(Long domainId, Integer objectTypesSelected, Integer objectTypesDeselected) {
        try {
            LogWriter.general.info("update backup settings : start update rmpcurrentinfo by objecttype");
            Column isBackupSet = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "IS_BACKUP_SET"), RMPCommonFlags.IsBackupSet.maskValue);
            isBackupSet.setType(Types.INTEGER);
            if(objectTypesSelected != 0) {
            	Criteria objectSeletionCriteria = getObjectTypeCriteria(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, objectTypesSelected);
                Criteria backupStatusCriteria = new Criteria(isBackupSet, 0, QueryConstants.EQUAL);
                DBUtil.executeUpdate(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "IS_BACKUP_SET", 1, (backupStatusCriteria).and(objectSeletionCriteria));
            }            
            if(objectTypesDeselected != 0) {
            	Criteria objectDeseletionCriteria = getObjectTypeCriteria(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, objectTypesDeselected);
                Criteria backupStatusCriteria = new Criteria(isBackupSet, 0, QueryConstants.GREATER_THAN);
                DBUtil.executeUpdate(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "IS_BACKUP_SET", 2, (backupStatusCriteria).and(objectDeseletionCriteria));
            }
            LogWriter.general.info("End update rmpcurrentinfo by objecttype");
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.updateBackupSettings domainId:%s \nexcep:%s", domainId, LogWriter.getStackTrace(e)));
        }
    }

    public static void updateOUCurrentInfoPreviousBackupSettings(Long domainId, String[] parentGuid) {
        try {
            Criteria parentGuidCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "PARENT_GUID"), parentGuid, QueryConstants.IN);
            Criteria objectGuidCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_GUID"), parentGuid, QueryConstants.IN);
            updateCurrentInfoPreviousBackupSettings(domainId, parentGuidCriteria.or(objectGuidCriteria));
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.updateCurrentInfoPreviousBackupSettings domainId:%s \nexcep:%s", domainId, LogWriter.getStackTrace(e)));
        }
    }

    public static void updateCurrentInfoPreviousBackupSettings(Long domainId, Criteria otherCriteria) {
        try {
            LogWriter.general.info("updateCurrentInfoPreviousBackupSettings: start update");
            if(DBUtil.isTableExists(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId))
            {
                String currentInfoTable =  TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId;
                Column isBackupSet = Column.createFunction("AND_OPERATOR", Column.getColumn(currentInfoTable, "IS_BACKUP_SET"), RMPCommonFlags.IsBackupSet.maskValue);
                isBackupSet.setType(Types.INTEGER);
                Column isObjNewlySelected = Column.createFunction("AND_OPERATOR", Column.getColumn(currentInfoTable, "IS_BACKUP_SET"), RMPCommonFlags.IsObjNewlySelected.maskValue);
                isObjNewlySelected.setType(Types.INTEGER);
                UpdateQuery updateQuery = new UpdateQueryImpl(currentInfoTable);

                updateQuery.setCriteria((otherCriteria). and(isBackupSet, 0, QueryConstants.EQUAL) .and(isObjNewlySelected, 0, QueryConstants.GREATER_THAN));
                Column operation = Column.createOperation(Operation.operationType.SUBTRACT, Column.getColumn(currentInfoTable, "IS_BACKUP_SET"), RMPCommonFlags.IsObjNewlySelected.maskValue);
                operation.setType(Types.INTEGER);
                updateQuery.setUpdateColumn("IS_BACKUP_SET", operation);

                DBUtil.executeUpdate(currentInfoTable, "IS_BACKUP_SET", operation, updateQuery.getCriteria());
                //CommonUtil.getPersistence().update(updateQuery);

                updateQuery.setCriteria((otherCriteria) .and(isBackupSet, 0, QueryConstants.GREATER_THAN) .and(isObjNewlySelected, 0, QueryConstants.EQUAL));
                operation = Column.createOperation(Operation.operationType.ADD, Column.getColumn(currentInfoTable, "IS_BACKUP_SET"), RMPCommonFlags.IsObjNewlySelected.maskValue);
                operation.setType(Types.INTEGER);
                updateQuery.setUpdateColumn("IS_BACKUP_SET", operation);

                DBUtil.executeUpdate(currentInfoTable, "IS_BACKUP_SET", operation, updateQuery.getCriteria());
                //CommonUtil.getPersistence().update(updateQuery);
            }
            LogWriter.general.info("updateCurrentInfoPreviousBackupSettings: end update");
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.updateCurrentInfoPreviousBackupSettings domainId:%s \nexcep:%s", domainId, LogWriter.getStackTrace(e)));
        }
    }
  

    private static Criteria getObjectTypeCriteria(String tableName, Integer objectType) {
        Column objTypeDeselected = Column.createFunction("AND_OPERATOR", Column.getColumn(tableName, "OBJECT_TYPE"), objectType);
        objTypeDeselected.setType(Types.BIGINT);
        return new Criteria(objTypeDeselected, 0, QueryConstants.NOT_EQUAL);
    }

    public static Object getSingleValue(Properties properties, String propertyName) {
        ArrayList value = (ArrayList) properties.get(propertyName);
        if (value != null && value.size() > 0) {
            return value.get(0);
        }
        return null;
    }

    public static String getString(Properties properties, String propertyName) {
        Object obj = getSingleValue(properties, propertyName);
        if (obj != null) {
            return (String) obj;
        }
        return null;
    }

    public static UUID getGuid(Properties properties, String propertyName) {
        Object obj = getSingleValue(properties, propertyName);
        if (obj != null && ((String) obj).contains("{")) {
            obj = ((String) obj).replaceAll("[{}]", "");
        }
        if (obj != null) {
            return UUID.fromString((String) obj);
        }
        return null;
    }

    public static Boolean getBoolean(Properties properties, String propertyName) {
        Object obj = getSingleValue(properties, propertyName);
        if (obj != null) {
            if (obj.toString().equalsIgnoreCase("0")) {
                return false;
            } else {
                return true;
            }
        }
        return null;
    }
    
    
    public static Object getBooleanValue(Object propertyValue, Attribute attrInfo) {
        if (!attrInfo.isMultiValued) {
            if (propertyValue != null) {
                return !propertyValue.toString().equalsIgnoreCase("0");
            }
        } else {
            JSONArray multiValues = new JSONArray();
            ArrayList<String> propertyValues = new ArrayList<String>();
            propertyValues = JSONObjectUtil.fromJsonString(propertyValue.toString(), propertyValues.getClass());
            for (String propVal : propertyValues) {
                multiValues.put(!propVal.equalsIgnoreCase("0"));
            }
            return multiValues.toString();
        }
        return propertyValue;
    }

    public static Integer getInteger(Properties properties, String propertyName) {
        Object obj = getSingleValue(properties, propertyName);
        if (obj != null) {
            return Integer.parseInt((String) obj);
        }
        return null;
    }

    public static String converByteArrtoNumString(Properties prop, String string) {
        // TODO Auto-generated method stub
        ArrayList propertyValues = (ArrayList) prop.get(string);
        String val = (String) propertyValues.get(0);
        String numval = "[";
        for (int j = 0; j < val.length(); j += 2) {
            String sub = val.substring(j, j + 2);
            //byte b = (byte) val.charAt(j);
            //Integer n = (int) b& 0xFF;
            Integer num = Integer.parseInt(sub, 16);
            numval += num.toString();
            if (j != val.length() - 2) {
                numval += ",";
            } else {
                numval += "]";
            }
        }
        return numval;
    }

    public static void updateDeleteObjectState(long domainId,String objectGuid, Boolean state,String restoreDN) {
        try {
            Column isDeleted = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "SYNC_STATUS"), RMPCommonFlags.IsDeleted.maskValue);
            isDeleted.setType(Types.INTEGER);
            UpdateQuery updQry = new UpdateQueryImpl(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId);
            Criteria crt = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"), objectGuid, QueryConstants.EQUAL);
            Column oper;
            if(state){
                crt = crt .and(new Criteria(isDeleted, 0, QueryConstants.EQUAL)); // object in not deleted state
                oper = Column.createOperation(Operation.operationType.ADD, Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "SYNC_STATUS"), RMPCommonFlags.IsDeleted.maskValue);
                oper.setType(Types.INTEGER);  
            }else{
                crt = crt .and(new Criteria(isDeleted, 0, QueryConstants.GREATER_THAN)); //object in deleted state
                oper = Column.createOperation(Operation.operationType.SUBTRACT, Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "SYNC_STATUS"), RMPCommonFlags.IsDeleted.maskValue);
                oper.setType(Types.INTEGER);
            }
            updQry.setCriteria(crt);
            updQry.setUpdateColumn("SYNC_STATUS", oper);   //No I18N
            if(restoreDN != null)
            {
                updQry.setUpdateColumn("OBJECT_DN", restoreDN);
            }
            CommonUtil.getPersistence().update(updQry);
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.updateDeleteObjectState objectId:%s \n excep:%s", objectGuid, LogWriter.getStackTrace(e)));
        }
    }

    public static long getNewLinkId(long domainId) {
        try {
            Row row = new Row(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId);
            DataAccess.generateValues(row);
            return (long) row.get("LINK_ID");
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("BackupUtil.getNewLinkId excep:%s", LogWriter.getStackTrace(e)));
            return 0L;
        }
    }  
    
    public static void SetNewlySelectedForBackup(Long domainId)
    {
        try {
            Criteria ouDomainCriteria = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria ouSelectedCriteria = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "TO_BACKUP"), true, QueryConstants.EQUAL);
            SelectQuery ouSelectionQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OU_INFO));
            ouSelectionQuery.addSelectColumn(Column.getColumn(TableName.RMP_OU_INFO, "OBJECT_GUID"));
            ouSelectionQuery.setCriteria(ouDomainCriteria.and(ouSelectedCriteria));   
            Criteria parentCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "PARENT_GUID"), new DerivedColumn("OBJECT_GUID", ouSelectionQuery), QueryConstants.IN);
            Column hasChange = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "SYNC_STATUS"), RMPCommonFlags.HasChange.maskValue);  //NO I18N
            hasChange.setType(Types.INTEGER);
            Column isNewlySelected = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "IS_BACKUP_SET"), RMPCommonFlags.IsObjNewlySelected.maskValue);  //NO I18N
            isNewlySelected.setType(Types.INTEGER);
            UpdateQuery updateQuery = new UpdateQueryImpl(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId);
            updateQuery.setCriteria(parentCriteria .and(new Criteria(isNewlySelected, 0, QueryConstants.EQUAL)) .and(new Criteria(hasChange, 0, QueryConstants.EQUAL)));
            Column operation = Column.createOperation(Operation.operationType.ADD, Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "IS_BACKUP_SET"), RMPCommonFlags.IsObjNewlySelected.maskValue);
            operation.setType(Types.INTEGER);
            updateQuery.setUpdateColumn("IS_BACKUP_SET", operation);
            CommonUtil.getPersistence().update(updateQuery);
        } catch(Exception e) {
            LogWriter.backup.severe("BackupUtil.SetNewlySelectedForBackup error: "+ e);
            e.printStackTrace();
        }
    }
    
    public static Row getObjectVersionInfoRow(BackupObject backupObject){
        try{
            Row verRow = new Row(TableName.RMP_OBJ_VER_INFO+"_"+backupObject.domainId);
            verRow.set("OBJECT_GUID", backupObject.objId.toString());
            verRow.set("BACKUP_ID", backupObject.backupId);
            verRow.set("CHANGE_ID", backupObject.changeId);
            verRow.set("LINK_ID", backupObject.linkId);
            verRow.set("CHANGE_MASK",  new ByteArrayInputStream(BitSetUtil.bitSetToByteArray(backupObject.changeMask)));
            verRow.set("CHANGE_DATA", backupObject.data.toString());
            verRow.set("LINKS_DATA",backupObject.linksData.toString());
            return verRow;
        }catch(Exception e){
            LogWriter.backup.severe("BackupUtil.getObjectVersionInfoRow, BackupObject obj_ver row construct error:"+LogWriter.getStackTrace(e));
        }
        return null;
    }
    
    public static Row getObjectMetaVersionInfoRow(BackupObject backupObject){
        try{
            Row metaVerRow = new Row(TableName.RMP_OBJ_META_VER_INFO+"_"+backupObject.domainId);
            metaVerRow.set("OBJECT_GUID", backupObject.objId.toString());
            metaVerRow.set("OBJECT_SID", backupObject.data.has("sid")? backupObject.data.get("sid").toString() : "");
            metaVerRow.set("LINK_ID", backupObject.linkId);
            if(backupObject.changeTyp == ChangeType.Deleted.maskValue){
                metaVerRow.set("OBJECT_NAME", LdapUtil.getObjectAttributeValue(backupObject.data.get("b11").toString()));
            }
            else{
                metaVerRow.set("OBJECT_NAME", backupObject.data.get("b11").toString());
            }
            metaVerRow.set("OBJECT_LOCATION", backupObject.ouNam);
            metaVerRow.set("PARENT_GUID", backupObject.ouId.toString());
            metaVerRow.set("OBJECT_TYPE",backupObject.objTyp.maskValue);
            metaVerRow.set("CHANGE_TYPE",backupObject.changeTyp);
            return metaVerRow;
        }catch(Exception e){
            LogWriter.backup.severe("BackupUtil.getObjectMetaVersionInfoRow, BackupObject obj_meta_ver row construct error:"+LogWriter.getStackTrace(e));
        }
        return null;
    }
    public static int getIsBackupSet(BackupObject backupObject){
        int isBackupSet = 0;
        if(backupObject.isObjNewlySelected){
            isBackupSet |= RMPCommonFlags.IsObjNewlySelected.maskValue;
        }
        if(backupObject.isBackupSet){
            isBackupSet |= RMPCommonFlags.IsBackupSet.maskValue;
        }
        return isBackupSet;
    }

    public static int getSyncStatus(BackupObject backupObject) {
        int syncStatus = 0;
        if (backupObject.isDeleted) {
            syncStatus |= RMPCommonFlags.IsDeleted.maskValue;
        }
        if (backupObject.hasHistory) {
            syncStatus |= RMPCommonFlags.HasHistory.maskValue;
        }
        if (backupObject.hasChange) {
            syncStatus |= RMPCommonFlags.HasChange.maskValue;
        }
        if (backupObject.isDisabled) {
            syncStatus |= RMPCommonFlags.IsDisabled.maskValue;
        }
        return syncStatus;
    }
    
    public static void updateQueryRangeAndExecute(long domainId,Iterator iterator, DataObject dobj, SelectQuery selectQuery, SortColumn sortColumn, int startingRowNumber, int pageSize){
        try{
            Range range = new Range(startingRowNumber, pageSize);
            selectQuery.setRange(range);
            selectQuery.addSortColumn(sortColumn);
            dobj = CommonUtil.getPersistence().get(selectQuery);
            iterator = dobj.getRows(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId);
        }catch(Exception e){
            LogWriter.backup.severe("BackupUtil.updateQueryAndExecute error:"+LogWriter.getStackTrace(e));
        }
    }
    public static int getMaxChangeID(long domainId, Long backupId)
    {
        String objTable = TableName.RMP_OBJ_VER_INFO + "_" + domainId;
        Connection con = null;
        DataSet dset = null;
        try
        {
            SelectQuery query = new SelectQueryImpl(Table.getTable(objTable));
            Column maxId = Column.getColumn(objTable, "CHANGE_ID").maximum();// No I18N
            maxId.setColumnAlias("MAXID");
            query.setCriteria(new Criteria(Column.getColumn(objTable, "BACKUP_ID"), backupId, QueryConstants.EQUAL));
            query.addSelectColumn(maxId);
            con = RelationalAPI.getInstance().getConnection();
            dset = RelationalAPI.getInstance().executeQuery(query, con);
            if (dset != null)
            {
                if(dset.next())
                {
                    int retval = (int)dset.getValue("MAXID");// No I18N
                    return retval;
                }
            }

        } catch (Exception e)
        {
            LogWriter.backup.info("BackupUtil.getMaxChangeID domainId: " + domainId + " backupId: " +backupId + " message:"+LogWriter.getStackTrace(e));
        } finally
        {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        return 0;
    }

    public static long getInitBackupId(long domainID)
    {
        try
        {
            return Long.parseLong(BackupUtil.getBackupStat(domainID).get("OLDEST_BACKUP_ID").toString());// No I18N
        } catch (Exception e)
        {
        }
        return 0;
    }
    
    public static void deleteBackups(Long domainId) {
        try {
            DataAccess.delete(TableName.RMP_OBJ_META_VER_INFO + "_" + domainId, (Criteria)null);
            DataAccess.delete(TableName.RMP_ATTRIBUTES_BACKUP_INFO + "_" + domainId, (Criteria)null);
        } catch (Exception e) {
            LogWriter.backup.severe(e + LogWriter.getStackTrace(e));
        }
    }
    
    public static void checkForDataMigration()
    {
        try {
            while(PatchManager.getDataMigrationStatus()) {
                LogWriter.backup.info("Waiting for data migration to complete"); // No I18N
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    LogWriter.backup.log(Level.SEVERE, "Thread interruptedd: Waiting for data migration to complete,  exception{0}", e); // No I18N
                }
            }
        } catch(Exception e) {
            LogWriter.backup.info(String.format("BackupInitiator.checkForDataMigration %s", e));
        }
    }

}

//ignoreI18n_end
