/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * $Id$
 */
package com.manageengine.rmp.ad.rangedattributes;

import com.adventnet.db.api.RelationalAPI;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.io.IOUtils;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.manageengine.ads.fw.jni.ADSNativeHandler;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.ad.backup.BackupUpdater;
import com.manageengine.rmp.ad.backup.BackupUtil;
import com.manageengine.rmp.ad.backup.BackupImpl;
import com.manageengine.rmp.ad.gpo.manager.GpoLinksUtil;
import com.manageengine.rmp.ad.gpo.manager.GpoUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ChangeType;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.RMPCommonFlags;
import com.manageengine.rmp.constants.RmpConstants;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.dataobjects.LdapAttribute;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.util.BitSetUtil;
import com.manageengine.rmp.util.GeneralUtil;
import com.manageengine.rmp.util.LdapUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.TreeSet;
import java.util.Set;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class LinkedAttributesUtil {

    public static final String ADDED_RANGE = ";range\u003d1-1";
    public static final String REMOVED_RANGE = ";range\u003d0-0";
    public static final String MODIFIED_RANGE = ";range\u003d2-2";

    public static String removeRangeInLdapName(String ldapString) {
        if (ldapString.contains(ADDED_RANGE) || ldapString.contains(ADDED_RANGE)) {
            return ldapString.substring(0, ldapString.length() - 10);
        }
        return ldapString;
    }

    //this will update deleted member of group in db//
    public static Boolean updateDeletedLinks(BackupObject backupObject, BackupObject lastSnapshot, Properties prop, FrontLinkAttrManager frontLink, BackupImpl backupImpl) throws Exception{
        if (!frontLink.isFullSync) {
            //forward link
            for (ForwardLink forwardLink : ForwardLink.values()) {
                if (forwardLink != ForwardLink.none) {
                    frontLink.forwardLink = forwardLink;
                    Properties totalDnAndGuid;
                    totalDnAndGuid = getTotalDnAndGuidHashFromBackup(frontLink.domainId, forwardLink.linkId, backupObject.objId.toString(), "FRONTLINK_OBJECT_GUID", "BACKLINK_OBJECT_GUID", "BACKLINK_OBJECT_DN", false);
                    //ArrayList<String> totalGuidList=getTotalDnorGuidListFromBackup(frontLink.domainId, forwardLink.linkId, backupObject.objId.toString(),"FRONTLINK_OBJECT_GUID","BACKLINK_OBJECT_GUID");
                    if (!totalDnAndGuid.isEmpty()) {
                        ArrayList<String> totalGuidList = new ArrayList(totalDnAndGuid.stringPropertyNames());
                        frontLink.updateRemovedFrontLinkAttrs(prop, backupObject.objId.toString(), totalDnAndGuid, totalGuidList);
                        frontLink.removeLinksFromCurrentBackup(backupObject.objId.toString(), totalGuidList);
                        if (frontLink.frontLinkMetaInfo.containsKey(backupObject.objId.toString())) {
                            RangedAttrObject temp = frontLink.frontLinkMetaInfo.get(backupObject.objId.toString());
                            temp.setMetadata(forwardLink.linkId, 0, 0, 0, 0);
                        } else {
                            RangedAttrObject temp = new RangedAttrObject(backupObject.objId.toString(), lastSnapshot.oldDn!=null?lastSnapshot.oldDn:backupObject.distinguishedName,  (lastSnapshot.objTyp!=null)?lastSnapshot.objTyp:backupObject.objTyp);
                            temp.setMetadata(forwardLink.linkId, 0, 0, 0,0);
                            frontLink.frontLinkMetaInfo.put(backupObject.objId.toString(), temp);
                        }
                    }
                }
                if (forwardLink != ForwardLink.none) {
                    frontLink.forwardLink = forwardLink;
                    Properties totalDnAndGuid;
                    totalDnAndGuid = getTotalDnAndGuidHashFromBackup(frontLink.domainId, forwardLink.linkId, backupObject.objId.toString(), "BACKLINK_OBJECT_GUID", "FRONTLINK_OBJECT_GUID", "BACKLINK_OBJECT_DN", false);
                    for (Map.Entry<Object, ?> property : totalDnAndGuid.entrySet()) {
                        if (frontLink.frontLinkMetaInfo.containsKey(property.getKey())) {
                            RangedAttrObject tempRangObj = frontLink.frontLinkMetaInfo.get(property.getKey());
                            if (tempRangObj.metadata.containsKey(forwardLink.linkId)) {
                                ArrayList<String> backLinkGuid = new ArrayList();
                                backLinkGuid.add(backupObject.objId.toString());
                                Properties backLinkGuidDn = new Properties();
                                backLinkGuidDn.put(backupObject.objId.toString(), lastSnapshot.oldDn);
                                frontLink.updateRemovedFrontLinkAttrs(prop, (String) property.getKey(), backLinkGuidDn, backLinkGuid);
                                frontLink.removeLinksFromCurrentBackup((String) property.getKey(), backLinkGuid);

                                int tempTotal = (int) tempRangObj.metadata.get(forwardLink.linkId).get(0);
                                tempRangObj.updateMetadata(forwardLink.linkId, tempTotal - 1, 0, 1, 0);
                            } else {
                                Properties tempProp = new Properties();
                                if (GeneralUtil.getStringAsArrayList((String) property.getKey()) != null) {
                                    tempProp.put("objectGUID", GeneralUtil.getStringAsArrayList((String) property.getKey()));
                                }
                                if (GeneralUtil.getStringAsArrayList((String) property.getValue()) != null) {
                                    tempProp.put("distinguishedName", GeneralUtil.getStringAsArrayList((String) property.getValue()));

                                }
                                tempProp.put(forwardLink.toString() + REMOVED_RANGE, GeneralUtil.getStringAsArrayList(lastSnapshot.oldDn));
                                tempProp.put("backlinkGuid", lastSnapshot.objId.toString());
                                backupImpl.backupObjectNotInCache(tempProp);
                            }
                        } else {
                            Properties tempProp = new Properties();
                            if (GeneralUtil.getStringAsArrayList((String) property.getKey()) != null) {
                                tempProp.put("objectGUID", GeneralUtil.getStringAsArrayList((String) property.getKey()));
                            }
                            if (GeneralUtil.getStringAsArrayList((String) property.getValue()) != null) {
                                tempProp.put("distinguishedName", GeneralUtil.getStringAsArrayList((String) property.getValue()));
                            }
                            tempProp.put(forwardLink.toString() + REMOVED_RANGE, lastSnapshot.oldDn!=null?GeneralUtil.getStringAsArrayList(lastSnapshot.oldDn):GeneralUtil.getStringAsArrayList(backupObject.distinguishedName));
                            tempProp.put("backlinkGuid", lastSnapshot.objId.toString());

                            backupImpl.backupObjectNotInCache(tempProp);
                        }
                    }
                }
            }
            return true;
        }
        return true;
    }

    public static int getCountOfRangedAttr(long domainId, int forwardLinkType, long backupId, long linksType, String columnName, String columnVal) {
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId));
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "FORWARD_LINK_ID"), forwardLinkType, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), backupId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "LINKS_TYPE"), linksType, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, columnName), columnVal, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "*"));
            int count = DataAccess.get(query).size(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId);
            return count < 0 ? 0 : count;
        } catch (DataAccessException ex) {
            Logger.getLogger(LinkedAttributesUtil.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }

//Deleted Ranged Attributes handling Start
    public static void updateDeletedRangedAttr(long domainId, long backupId, String objectGuid, Properties attrValues) {
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId));
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "FRONTLINK_OBJECT_GUID"), objectGuid, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), LinkType.Total.memberTypeId, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "*"));
            DataObject dataObject = DataAccess.get(query);
            if (!dataObject.isEmpty()) {
                Iterator iterator = dataObject.getRows(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    Row newRow = new Row(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId);
                    newRow.set("FORWARD_LINK_ID", row.get("FORWARD_LINK_ID"));
                    newRow.set("BACKUP_ID", backupId);
                    newRow.set("LINKS_TYPE", LinkType.Removed.memberTypeId);
                    newRow.set("FRONTLINK_OBJECT_GUID", objectGuid);
                    newRow.set("BACKLINK_OBJECT_GUID", row.get("BACKLINK_OBJECT_GUID"));
                    dataObject.addRow(newRow);
                }
            }
            CommonUtil.getPersistence().add(dataObject);
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("LinkedAttributesUtil.updateDeletedRangedAttr Ex: ", e));
        }
    }

    public static ArrayList<String> getTotalDnorGuidListFromBackup(Long domainId, int linkId, String objectGuid, String linkGuid, String resultDnorGuid) {
        ArrayList<String> dnOrGuid = new ArrayList();
        try {
            SelectQuery query = getLinksListFromRangedAttr(domainId, linkId, (long) 0, objectGuid, 0, linkGuid, null, null, false, 0, 0);
            DataObject dataObject = DataAccess.get(query);
            if (!dataObject.isEmpty()) {
                Iterator iterator = dataObject.getRows(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    dnOrGuid.add((String) row.get(resultDnorGuid));
                }
            }
            return dnOrGuid;
        } catch (DataAccessException e) {
            // TODO Auto-generated catch block
            LogWriter.backup.log(Level.SEVERE, "GroupMemberManager: getCurrentMembersDnListFromBackup domainId-{0}{1}", new Object[]{domainId, e});
            return dnOrGuid;
        }
    }

    public static ArrayList<String> getTotalDnOrGuidFromBackup(Long domainId, int linkId, Long backupId, String objectGuid, int changes, String linkForeGuid, String linkBackGuid, String linkBackDn, Boolean isRanged, int startIndex, int endIndex, String resultDnorGuid) throws QueryConstructionException {
        ArrayList<String> dnOrGuid = new ArrayList();
        Connection con = null;
        DataSet dset = null;
        try {
            SelectQuery query = getLinksListFromRangedAttr(domainId, linkId, backupId, objectGuid, changes, linkForeGuid, linkBackGuid, linkBackDn, isRanged, startIndex, endIndex);
            con = RelationalAPI.getInstance().getConnection();
            dset = RelationalAPI.getInstance().executeQuery(query, con);
            while(dset.next())
            {
                dnOrGuid.add(dset.getAsString(resultDnorGuid));
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            LogWriter.backup.log(Level.SEVERE, "GroupMemberManager: getCurrentMembersDnListFromBackup domainId-{0}{1}", new Object[]{domainId, e});
            e.printStackTrace();
        }
        finally
        {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        return dnOrGuid;
    }

    public static Properties getTotalDnAndGuidHashFromBackup(Long domainId, int linkId, String objectGuid, String linkGuid, String resultGuid, String resultDN, boolean isGPOLinks)
    {
        Properties linkedAttrList = new Properties();
        Connection con = null;
        DataSet dset = null;
        try
        {
            con = RelationalAPI.getInstance().getConnection();
            try
            {
                SelectQuery query;
                Properties domainDetails = RMPDomainHandler.getDomainDetailsById(domainId);
                String policiesContainer = GpoUtil.policiesContainerDNWithDNC(domainDetails.getProperty("DEFAULT_NAMING_CONTEXT"));
                if(isGPOLinks && linkId == LdapAttribute.gpLink.ldapAttributeId)
                {
                    query = GpoLinksUtil.getLinksListFromRangedAttr(domainId, linkId, (long) 0, objectGuid, 0, linkGuid, resultGuid, resultDN, false, 0, 0, true);
                }
                else if(!isGPOLinks && linkId != LdapAttribute.gpLink.ldapAttributeId)
                {
                    query = getLinksListFromRangedAttr(domainId, linkId, (long) 0, objectGuid, 0, linkGuid, resultGuid, resultDN, false, 0, 0);
                }
                else
                {
                    return linkedAttrList;
                }
                dset = RelationalAPI.getInstance().executeQuery(query, con);
                if (dset != null)
                {
                    while (dset.next())
                    {
//                        if(isGPOLinks)
//                        {
//                            linkedAttrList.put((String) dset.getValue(resultGuid), dset.getValue(resultDN));
//                        }
//                        else
//                        {
                            linkedAttrList.put((String) dset.getValue(resultGuid), dset.getValue(resultDN));
//                        }
                    }
                }
            } catch (QueryConstructionException e)
            {
                LogWriter.backup.log(Level.SEVERE, "query exception in GroupMemberManager: getCurrentMembersDnListFromBackup domainId-{0}{1}", new Object[]{domainId, e});
            } catch (SQLException e)
            {
                LogWriter.backup.log(Level.SEVERE, "sql exception in GroupMemberManager: getCurrentMembersDnListFromBackup domainId-{0}{1}", new Object[]{domainId, e});
            }
        } catch (Exception e)
        {
            LogWriter.general.log(Level.SEVERE, "getTotalDnAndGuidHashFromBackup, exception {0}", e.getMessage());
        } finally {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        return linkedAttrList;
    }

    public static SelectQuery compareForRestoreFrontLink(Long domainId, int linkId, Long backupId, String objectGuid, String linkForeGuid, String linkBackGuid, String linkBackDN, int addremove,boolean toReanimate) {
        return compareForRestoreFrontLink(domainId, TableName.RMP_RANGED_ATTRIBUTES, linkId, backupId, objectGuid, linkForeGuid, linkBackGuid, linkBackDN, addremove,toReanimate);
    }

    public static SelectQuery compareForRestoreFrontLink(Long domainId, String tableName, int linkId, Long backupId, String objectGuid, String linkForeGuid, String linkBackGuid, String linkBackDN, int addremove,boolean toReanimate)
    {
        try
        {
            SelectQuery query3 = new SelectQueryImpl(Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId));
            query3.addSelectColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid));

            Criteria criteria2 = new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);
            criteria2 = criteria2.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), 0, QueryConstants.EQUAL);
            criteria2 = criteria2.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkForeGuid), objectGuid, QueryConstants.EQUAL);

            Table table1 = Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "out");
            SelectQuery query = new SelectQueryImpl(table1);
            //query.addSelectColumn(Column.getColumn(null, "*"));
            query.addSelectColumn(Column.getColumn("out", linkBackGuid));
            query.addSelectColumn(Column.getColumn("out", linkForeGuid));

            SelectQuery query2 = new SelectQueryImpl(Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId));
            query2.addSelectColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid));
            Column col2 = Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "UNIQUE_ID").maximum();
            col2.setColumnAlias("latest_uniqueId");
            query2.addSelectColumn(col2);
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), backupId, QueryConstants.LESS_EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), 0, QueryConstants.NOT_EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkForeGuid), objectGuid, QueryConstants.EQUAL);
            query2.setCriteria(criteria);
            GroupByColumn gbc = new GroupByColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid), false);
            List<GroupByColumn> gbcs = new ArrayList();
            gbcs.add(gbc);
            query2.setGroupByClause(new GroupByClause(gbcs));
            DerivedTable table2 = new DerivedTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, query2);

            Criteria jCriteria = new Criteria(Column.getColumn("out", "UNIQUE_ID"), Column.getColumn(table2.getTableAlias(), "latest_uniqueId"), QueryConstants.EQUAL);
            jCriteria = jCriteria.and(Column.getColumn("out", linkBackGuid), Column.getColumn(table2.getTableAlias(), linkBackGuid), QueryConstants.EQUAL);
            query.addJoin(new Join(table1, table2, jCriteria, Join.INNER_JOIN));

            Criteria mainCriteria = new Criteria(Column.getColumn("out", "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);
            mainCriteria = mainCriteria.and(Column.getColumn("out", linkForeGuid), objectGuid, QueryConstants.EQUAL);
            mainCriteria = mainCriteria.and(Column.getColumn("out", "BACKUP_ID"), backupId, QueryConstants.LESS_EQUAL);
            mainCriteria = mainCriteria.and(Column.getColumn("out", "BACKUP_ID"), 0, QueryConstants.NOT_EQUAL);
            mainCriteria = mainCriteria.and(Column.getColumn("out", "LINKS_TYPE"), 1, QueryConstants.EQUAL);
            if (addremove == 1) {
                query3.setCriteria(criteria2);
                if(!toReanimate){
                mainCriteria = mainCriteria.and(Column.getColumn("out", linkBackGuid), new DerivedColumn(linkBackGuid, query3), QueryConstants.NOT_IN);
                }
                query.setCriteria(mainCriteria);
                //String queryStr = RelationalAPI.getInstance().getSelectSQL(query);
                //LogWriter.backup.info("Add query: " + queryStr);
                DerivedTable guidTable = new DerivedTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, query);
                SelectQuery finalQuery = new SelectQueryImpl(guidTable);
                Table dnTable = Table.getTable(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "dnTable");
                finalQuery.addSelectColumn(Column.getColumn("dnTable", "OBJECT_DN", linkBackDN));
                finalQuery.addSelectColumn(Column.getColumn(guidTable.getTableAlias(), linkBackGuid));
                Criteria joinCriteria = (new Criteria(Column.getColumn("dnTable", "OBJECT_GUID"), Column.getColumn(guidTable.getTableAlias(), linkBackGuid), QueryConstants.EQUAL));
                finalQuery.addJoin(new Join(guidTable, dnTable, joinCriteria, Join.INNER_JOIN));
                return finalQuery;
            } else if (addremove == 2) {
                //query.removeSelectColumn(Column.getColumn(null, "*"));      
                query.removeSelectColumn(Column.getColumn("out", linkForeGuid));
                //query.addSelectColumn(Column.getColumn(table1.getTableAlias(), linkBackGuid));
                query.setCriteria(mainCriteria);
                //query3.addSelectColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES, linkBackDN));
                criteria2 = criteria2.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid), new DerivedColumn(linkBackGuid, query), QueryConstants.NOT_IN);
                query3.setCriteria(criteria2);
                //String queryStr = RelationalAPI.getInstance().getSelectSQL(query3);
                //LogWriter.backup.info("Remove query: " + queryStr);
                DerivedTable guidTable = new DerivedTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, query3);
                SelectQuery finalQuery = new SelectQueryImpl(guidTable);
                Table dnTable = Table.getTable(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "dnTable");
                finalQuery.addSelectColumn(Column.getColumn("dnTable", "OBJECT_DN", linkBackDN));
                finalQuery.addSelectColumn(Column.getColumn(guidTable.getTableAlias(), linkBackGuid));
                Criteria joinCriteria = (new Criteria(Column.getColumn("dnTable", "OBJECT_GUID"), Column.getColumn(guidTable.getTableAlias(), linkBackGuid), QueryConstants.EQUAL));
                finalQuery.addJoin(new Join(guidTable, dnTable, joinCriteria, Join.INNER_JOIN));
                return finalQuery;
            }
        } catch (Exception e) {
            LogWriter.recovery.log(Level.SEVERE, "compareForRestoreFrontLink: {0}{1}", new Object[]{e, LogWriter.getStackTrace(e)});
        }
        return null;

    }
    public static long getFrontLinkaddedSkippedCount(Long domainId, int linkId, Long backupId, String objectGuid, String linkForeGuid, String linkBackGuid, String linkBackDN, int addremove,ArrayList<String> deletedGuid){
         Connection con = null;
        DataSet dset = null;
          long skippedCount=0;
        try{
      
        
         con = RelationalAPI.getInstance().getConnection();
         dset = RelationalAPI.getInstance().executeQuery(getFrontLinkaddededSkippedCountQuery(domainId, linkId, backupId, objectGuid, linkForeGuid, linkBackGuid, linkBackDN, addremove,deletedGuid,true), con);
         if(dset!=null && dset.next()){
             skippedCount=dset.getAsLong(1);
         }
            DBUtil.closeDataSet(dset);
         dset = RelationalAPI.getInstance().executeQuery(getFrontLinkaddededSkippedCountQuery(domainId, linkId, backupId, objectGuid, linkForeGuid, linkBackGuid, linkBackDN, addremove,deletedGuid,false), con);
         if(dset!=null && dset.next()){
              skippedCount=skippedCount-dset.getAsLong(1);
         }
       
        }
        
        catch(Exception e){
            
        }
        finally {
            DBUtil.closeDataSet(dset);
            DBUtil.closeConnection(con);
        }
        return skippedCount;
    }
    public static SelectQuery getFrontLinkaddededSkippedCountQuery(Long domainId, int linkId, Long backupId, String objectGuid, String linkForeGuid, String linkBackGuid, String linkBackDN, int addremove,ArrayList<String> deletedGuid,boolean istotalSkippedCount){
        try{
             SelectQuery query3 = new SelectQueryImpl(Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId));
            query3.addSelectColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid));

            Criteria criteria2 = new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);
            criteria2 = criteria2.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), 0, QueryConstants.EQUAL);
            criteria2 = criteria2.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkForeGuid), objectGuid, QueryConstants.EQUAL);

            Table table1 = Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "out");
            SelectQuery query = new SelectQueryImpl(table1);
            //query.addSelectColumn(Column.getColumn(null, "*"));
            query.addSelectColumn(Column.getColumn("out", linkForeGuid).count());

            SelectQuery query2 = new SelectQueryImpl(Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId));
            query2.addSelectColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid));
            Column col2 = Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID").maximum();
            col2.setColumnAlias("latest_time");
            query2.addSelectColumn(col2);
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), backupId, QueryConstants.LESS_EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), 0, QueryConstants.NOT_EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkForeGuid), objectGuid, QueryConstants.EQUAL);
            query2.setCriteria(criteria);
            GroupByColumn gbc = new GroupByColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid), false);
            List<GroupByColumn> gbcs = new ArrayList<GroupByColumn>();
            gbcs.add(gbc);
            query2.setGroupByClause(new GroupByClause(gbcs));
            DerivedTable table2 = new DerivedTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, query2);

            Criteria jCriteria = new Criteria(Column.getColumn("out", "BACKUP_ID"), Column.getColumn(table2.getTableAlias(), "latest_time"), QueryConstants.EQUAL);
            jCriteria = jCriteria.and(Column.getColumn("out", linkBackGuid), Column.getColumn(table2.getTableAlias(), linkBackGuid), QueryConstants.EQUAL);
            query.addJoin(new Join(table1, table2, jCriteria, Join.INNER_JOIN));

            Criteria mainCriteria = new Criteria(Column.getColumn("out", "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);
            mainCriteria = mainCriteria.and(Column.getColumn("out", linkForeGuid), objectGuid, QueryConstants.EQUAL);
            mainCriteria = mainCriteria.and(Column.getColumn("out", "BACKUP_ID"), backupId, QueryConstants.LESS_EQUAL);
            mainCriteria = mainCriteria.and(Column.getColumn("out", "BACKUP_ID"), 0, QueryConstants.NOT_EQUAL);
            mainCriteria = mainCriteria.and(Column.getColumn("out", "LINKS_TYPE"), 1, QueryConstants.EQUAL);
            query3.setCriteria(criteria2);
                if(!istotalSkippedCount){
                mainCriteria = mainCriteria.and(Column.getColumn("out", linkBackGuid), new DerivedColumn(linkBackGuid, query3), QueryConstants.NOT_IN);
                }  
                mainCriteria = mainCriteria.and(Column.getColumn("out", linkBackGuid), deletedGuid.toArray(), QueryConstants.IN);
                query.setCriteria(mainCriteria);
                String  test = RelationalAPI.getInstance().getSelectSQL(query).toString();
                return query;
            
        }
        catch(Exception e){
            
        }
        return null;
    }


    public static SelectQuery getLinksListFromRangedAttr(Long domainId, int linkId, Long backupId, String objectGuid, int changes, String linkForeGuid, String linkBackGuid, String linkBackDn, Boolean isRanged, int startIndex, int endIndex) {
        // take the common return query and perform the required join
        // check if linkbackdn is for front or back and join accordingly
        SelectQuery query = null;
        if (backupId == 0) {
            query = new SelectQueryImpl(Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId));
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkForeGuid), objectGuid, QueryConstants.EQUAL,false);
//            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), LinkType.Total.memberTypeId, QueryConstants.EQUAL);
            if (linkId != ForwardLink.none.linkId) {
                criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);
                criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "LINKS_TYPE"),0,QueryConstants.EQUAL); //to ensure forward link index
            }
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid));
            if (isRanged) {
                Range range = new Range(startIndex, endIndex);
                query.setRange(range);
                query.addSortColumn(new SortColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid), true));
            }
            //return query;
        } else if (changes == LinkType.Total.memberTypeId) {
            Table table = Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "temp");
            SelectQuery query2 = new SelectQueryImpl(Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId));
            query2.addSelectColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid));
            Column col2 = Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "UNIQUE_ID").maximum();
            col2.setColumnAlias("latest_uniqueId");
            query2.addSelectColumn(col2);
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), backupId, QueryConstants.LESS_EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), 0, QueryConstants.NOT_EQUAL);
             criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "LINKS_TYPE"), 0, QueryConstants.NOT_EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkForeGuid), objectGuid, QueryConstants.EQUAL,false);
            query2.setCriteria(criteria);
            GroupByColumn gbc = new GroupByColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid), false);
            List<GroupByColumn> gbcs = new ArrayList<GroupByColumn>();
            gbcs.add(gbc);
            query2.setGroupByClause(new GroupByClause(gbcs));
            DerivedTable dertable2 = new DerivedTable("temp", query2);
            query = new SelectQueryImpl(dertable2);
            //query.addSelectColumn(Column.getColumn(null, "*"));
            Table table3 = Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "table3");
            SelectQuery query3 = new SelectQueryImpl(table3);
            query3.addSelectColumn(Column.getColumn("table3", "UNIQUE_ID"));
            query3.addSelectColumn(Column.getColumn("table3", "BACKUP_ID"));
            query3.addSelectColumn(Column.getColumn("table3", linkBackGuid));
            Criteria criteria3 = new Criteria(Column.getColumn("table3", "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);
            criteria3 = criteria3.and(Column.getColumn("table3", linkForeGuid), objectGuid, QueryConstants.EQUAL,false);
            criteria3 = criteria3.and(Column.getColumn("table3", "BACKUP_ID"), backupId, QueryConstants.LESS_EQUAL);
            criteria3 = criteria3.and(Column.getColumn("table3", "BACKUP_ID"), 0, QueryConstants.NOT_EQUAL);
             criteria3 = criteria3.and(Column.getColumn("table3", "LINKS_TYPE"), 0, QueryConstants.NOT_EQUAL);
            criteria3 = criteria3.and(Column.getColumn("table3", "LINKS_TYPE"), 1, QueryConstants.EQUAL);
            criteria3 = criteria3.or(Column.getColumn("table3", "LINKS_TYPE"), 3, QueryConstants.EQUAL);
            query3.setCriteria(criteria3);
            DerivedTable dertable3 = new DerivedTable("table3", query3);
            Criteria jCriteria = new Criteria(Column.getColumn(dertable3.getTableAlias(), "UNIQUE_ID"), Column.getColumn(dertable2.getTableAlias(), "latest_uniqueId"), QueryConstants.EQUAL);
            jCriteria = jCriteria.and(Column.getColumn(dertable3.getTableAlias(), linkBackGuid), Column.getColumn(dertable2.getTableAlias(), linkBackGuid), QueryConstants.EQUAL);
            query.addJoin(new Join(dertable2, dertable3, new String[]{"latest_uniqueId", linkBackGuid}, new String[]{"UNIQUE_ID", linkBackGuid}, Join.LEFT_JOIN));
            query.addSelectColumn(Column.getColumn("table3", linkBackGuid));
            
            if (isRanged) {
                Range range = new Range(startIndex, endIndex);
                query.setRange(range);
                query.addSortColumn(new SortColumn(Column.getColumn("table3", linkBackGuid), true));
            }
            //return query;
        } else if (changes == LinkType.Added.memberTypeId || changes == LinkType.Removed.memberTypeId || changes == LinkType.Modified.memberTypeId) {
            query = new SelectQueryImpl(Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId));
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkForeGuid), objectGuid, QueryConstants.EQUAL,false);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), backupId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "LINKS_TYPE"), changes, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid));
            if (isRanged) {
                Range range = new Range(startIndex, endIndex);
                query.setRange(range);
                query.addSortColumn(new SortColumn(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, linkBackGuid), true));
            }
            //return query;
        }
        DerivedTable pagedGuidTable = new DerivedTable("PAGEDGUIDTABLE", query);
        SelectQuery pagedGuidQuery = new SelectQueryImpl(pagedGuidTable);
        pagedGuidQuery.addSelectColumn(Column.getColumn("PAGEDGUIDTABLE", linkBackGuid));
        
        SelectQuery finalQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId));
        //Table dnTable = Table.getTable(TableName.RMP_OBJ_CURRENT_INFO);
        finalQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "LINK_ID"));
        finalQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_DN", linkBackDn));
        finalQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID", linkBackGuid));
                
        Criteria finalCrit = (new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId,"OBJECT_GUID"),new DerivedColumn(linkBackGuid, pagedGuidQuery),QueryConstants.IN,false));
        finalQuery.setCriteria(finalCrit);
        /*Criteria joinCriteria = new Criteria(Column.getColumn(guidTable.getTableAlias(), "DOMAIN_ID"), Column.getColumn("dnTable", "DOMAIN_ID"), QueryConstants.EQUAL);
        joinCriteria = joinCriteria.and(new Criteria(Column.getColumn("dnTable", "OBJECT_GUID"), Column.getColumn(guidTable.getTableAlias(), linkBackGuid), QueryConstants.EQUAL));
        finalQuery.addJoin(new Join(guidTable, dnTable, joinCriteria, Join.INNER_JOIN));*/
        return finalQuery;
    }

    public static void updateRangedObjectNotInBackup(Map<String, RangedAttrObject> linkedAttrList, BackupImpl backupImpl, boolean isForwardLink, Long backupId, boolean isFullSync) {
        if (!isForwardLink && !isFullSync) {
            RangedAttrObject.setObjectType(backupImpl.domainId, linkedAttrList, isFullSync, null);
        }
        for (Map.Entry<String, RangedAttrObject> property : linkedAttrList.entrySet()) {
            if (property.getValue().metadata != null) {
                Properties tempProp = new Properties();
                if (GeneralUtil.getStringAsArrayList(property.getValue().objectGuid) != null) {
                    tempProp.put("objectGUID", GeneralUtil.getStringAsArrayList(property.getValue().objectGuid));
                }
                if (GeneralUtil.getStringAsArrayList(property.getValue().objectDn) != null) {
                    tempProp.put("distinguishedName", GeneralUtil.getStringAsArrayList(property.getValue().objectDn));
                    if(LdapUtil.isObjectDeleted(property.getValue().objectDn)){
                      tempProp.put("isDeleted", GeneralUtil.getStringAsArrayList("1"));
                    }
                    //tempProp.put("name", arg1)
                }
                if (property.getValue().objType != null) {
                    ObjectType objType = property.getValue().objType;
                    tempProp.put("objectType", objType.toString());
                } else {
                    tempProp.put("objectType", "Other");
                }
                for (Entry<Integer, ArrayList> metaVal : property.getValue().metadata.entrySet()) {
                    String attrName;
                    int attribId = metaVal.getKey();
                    if (isForwardLink) {
                        attrName = ForwardLink.getAttributeName(attribId);
                    } else {
                        attrName = BackwardLink.getAttributeName(attribId);
                    }
                    ArrayList metaValue = metaVal.getValue();
                    updateIfNoModifiedTypeNeeded(metaValue, attribId);        
                    metaValue.add(backupId);
                    ArrayList<String> metadataUpdate = new ArrayList();
                    metadataUpdate.add(JSONObjectUtil.toJsonString(metaValue));
                    tempProp.put(attrName, metadataUpdate);
                }
                tempProp.put("notInADSync", "true");
                backupImpl.addRow(tempProp);
            }
        }
    }

    public static Map<String, RangedAttrObject> updateRangedObjectInBackup(Map<String, RangedAttrObject> linkedAttrList, DataObject dobVersion, long domainId, long backupId, boolean isForwardLink, BackupUpdater backupUpdater) {
        try {
            List<String> currCols = new ArrayList<>();
            currCols.add("CURRENTINFO_ID");
            currCols.add("OBJECT_GUID");
            currCols.add("CHANGE_MASK");
            currCols.add("LINKS_DATA");
            DBUtil.createTable(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId,"_temp", currCols,false,false);
            List<String> verCols = new ArrayList<>();
            verCols.add("UNIQUE_ID");
            verCols.add("BACKUP_ID");
            verCols.add("CHANGE_ID");
            verCols.add("CHANGE_MASK");
            verCols.add("LINKS_DATA");
            Row rowVersion = null;
            Row rowCurrent = null;
            DBUtil.createTable(TableName.RMP_OBJ_VER_INFO+"_"+domainId,"_temp", verCols,false,false);
            backupUpdater.initiateTempTableWriterObj(DBUtil.getTempTableName(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId), DBUtil.getTempTableName(TableName.RMP_OBJ_VER_INFO+"_"+domainId), TableName.RMP_ATTRIBUTES_BACKUP_INFO+"_"+domainId);
            boolean traverseNext=true;
            Iterator verIterator = dobVersion.getRows(TableName.RMP_OBJ_VER_INFO+"_"+domainId);
            Iterator curIterator = dobVersion.getRows(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId);
            while (verIterator.hasNext()) {
                String tempJson;
                ByteArrayInputStream tempByteInputStream;
                byte[] tempByte;
                String objectGuid;
                //get row data for updation
               
                if(traverseNext){
                rowVersion = (Row) verIterator.next();
                rowCurrent = (Row) curIterator.next();
                }
                else{
                  rowCurrent = (Row) curIterator.next();  
                }
                String rowCurrentObjId= (String)rowCurrent.get("OBJECT_GUID");
                String rowObjVerObjId=(String)rowVersion.get("OBJECT_GUID");
                if(rowCurrentObjId.equalsIgnoreCase(rowObjVerObjId)){
                    traverseNext=true;
                    
                }
                else{
                    traverseNext=false;
                    continue;
                }
                tempJson = (String) rowVersion.get("LINKS_DATA");
                JsonObject dataVersion = (JsonObject) new JsonParser().parse(tempJson);
                //get bitset for updation
                tempByteInputStream = (ByteArrayInputStream) rowVersion.get("CHANGE_MASK");
                tempByte = IOUtils.toByteArray(tempByteInputStream);
                BitSet changeMaskVersion = BitSetUtil.fromByteArray(tempByte);
                //get json for updation
                tempJson = (String) rowCurrent.get("LINKS_DATA");
                JsonObject dataCurrent = (JsonObject) new JsonParser().parse(tempJson);
                //get current biset for updation
                tempByteInputStream = (ByteArrayInputStream) rowCurrent.get("CHANGE_MASK");
                tempByte = IOUtils.toByteArray(tempByteInputStream);
                BitSet changeMaskCurrent = BitSetUtil.fromByteArray(tempByte);
                //values setters for updation
                objectGuid = (String) rowCurrent.get("OBJECT_GUID");
                if (linkedAttrList.containsKey(objectGuid) && linkedAttrList.get(objectGuid).metadata != null) {
                    for (Entry<Integer, ArrayList> metaVal : linkedAttrList.get(objectGuid).metadata.entrySet()) {
                        int attribId = metaVal.getKey();
                        ArrayList metaValue = metaVal.getValue();
                        updateIfNoModifiedTypeNeeded(metaValue, attribId);                       
                        metaValue.add(backupId);
                        if (dataCurrent.get("b" +attribId) != null) {
                            if (!isForwardLink) {
                                int[] metaString = new int[4];
                                JsonElement backupVal = dataCurrent.get("b" + attribId);
                                metaString = (int[]) JSONObjectUtil.getObjectFromJsonString(backupVal.getAsString(), metaString.getClass());
                                metaValue.set(0, metaString[0] + (int) metaValue.get(0));
                            }
                            dataCurrent.add("o" + attribId, dataCurrent.get("b" + attribId));
                            dataVersion.add("o" + attribId, dataCurrent.get("b" + attribId));
                        }
                        String updateMetaVal = JSONObjectUtil.toJsonString(metaValue);
                        dataVersion.addProperty("b" + attribId, updateMetaVal);
                        changeMaskVersion.set(metaVal.getKey(), true);
                        dataCurrent.addProperty("b" + attribId, updateMetaVal);
                        if (!changeMaskCurrent.get(attribId)) {
                            changeMaskCurrent.set(attribId, true);
                        }
                        backupUpdater.updateAttributeInfo(UUID.fromString(rowCurrent.get("OBJECT_GUID").toString()),Integer.parseInt(rowVersion.get("CHANGE_ID").toString()), attribId);
                    }
                }
                backupUpdater.updateTempTableObjCurr(rowCurrent.get("OBJECT_GUID").toString(), changeMaskCurrent, dataCurrent, rowCurrent.get("CURRENTINFO_ID").toString());
                backupUpdater.updateTempTableObjVer(Long.parseLong(rowVersion.get("CHANGE_ID").toString()), changeMaskVersion, dataVersion, rowVersion.get("UNIQUE_ID").toString());
                linkedAttrList.remove(rowCurrent.get("OBJECT_GUID").toString());
            }
            backupUpdater.dumpTempTables();
            List<String> columns = new ArrayList<>();
            columns.add("CHANGE_MASK");
            columns.add("LINKS_DATA");
            DBUtil.updateDB(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, DBUtil.getTempTableName(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId), columns);
            DBUtil.updateDB(TableName.RMP_OBJ_VER_INFO+"_"+domainId, DBUtil.getTempTableName(TableName.RMP_OBJ_VER_INFO+"_"+domainId), columns);
            backupUpdater.dumpAttribInfoTable();
            DBUtil.dropTempTable(DBUtil.getTempTableName(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId));
            DBUtil.dropTempTable(DBUtil.getTempTableName(TableName.RMP_OBJ_VER_INFO+"_"+domainId));
        } catch (Exception e) {
            LogWriter.backup.log(Level.SEVERE, "linked attribute util update in backup{0}", e);
            e.printStackTrace();
        }
        return linkedAttrList;
    }
    
    public static void updateIfNoModifiedTypeNeeded(ArrayList metaValue, int attribId){
        if(attribId != ForwardLink.records.linkId && attribId != ForwardLink.gPLink.linkId && attribId != BackwardLink.records.linkId && attribId != BackwardLink.gpBackLinks.linkId && metaValue.size() == 4) {
            metaValue.remove(metaValue.size()-1);
        }
    }

    public static boolean isLinkChanged(Properties prop, String forwardLink) {

        return prop.containsKey(forwardLink + ADDED_RANGE) || prop.containsKey(forwardLink + REMOVED_RANGE) || prop.containsKey(forwardLink + MODIFIED_RANGE);
    }

    //get guid from ad
    public static String getGuidfromAD(String linkDn, Long domainId) {
        try {
            Properties domainProp = RMPDomainHandler.getDomainDetailsById(domainId);
            ArrayList<String> attribute = new ArrayList();
            attribute.add("objectGUID");
            //attribute.add("distinguishedName");
            ArrayList<Properties> linkAttributes = new ArrayList();
            linkAttributes = ADSNativeHandler.getObjectsWithOutListener(domainProp, linkDn, attribute, "(objectClass=*)");
            Properties prop = (Properties) linkAttributes.get(0);
            if (linkAttributes.isEmpty()) {
                LogWriter.backup.log(Level.SEVERE, "the following object is not present in dc--{0}", linkDn);
                return "n0gu1d";
            }
            //LogWriter.backup.info(memberAttributes.toString());
            ArrayList<String> guid = (ArrayList<String>) prop.get("objectGUID");
            return guid.get(0).substring(1, guid.get(0).length() - 1).toLowerCase();
        } catch (Exception e) {
            LogWriter.backup.log(Level.SEVERE, "FrontLinkAttrManager: getGuidfromAD domainId-{0} /n linkdn{1}{2}", new Object[]{domainId, linkDn, e});
            return "n0gu1d";
        }
    }

    public static void getByteArrayAttributes(Long domainId, Properties prop) {
        try {
            Properties domainProp = RMPDomainHandler.getDomainDetailsById(domainId);
            ArrayList<String> attributeList = new ArrayList();
            Enumeration enumerate = prop.propertyNames();
            while (enumerate.hasMoreElements()) {
                String attrName = (String) enumerate.nextElement();
                ArrayList value = (ArrayList) prop.get(attrName);
                if (value.isEmpty()) {
                    attributeList.add(attrName);
                }
            }
            ArrayList<Properties> propList = new ArrayList();
            if (!attributeList.isEmpty()) {
                propList = ADSNativeHandler.getObjectsWithOutListener(domainProp, BackupUtil.getString(prop, "distinguishedName"), attributeList, "(objectClass=*)");
                Properties attributes = (Properties) propList.get(0);
                for (String att : attributeList) {
                    prop.setProperty(att, attributes.getProperty(att));
                }
            }
        } catch (Exception e) {
            LogWriter.backup.log(Level.SEVERE, "getByteArrayAttribute:{0}", e);
        }
    }

    public static Properties getGuidForLinks(ArrayList<String> linkDn, long domainId, String domainName,long backupId) {
        return getGuidForLinks(linkDn, domainId, domainName, false, null, false,backupId);
    }
    
    public static Properties getGuidForLinks(ArrayList<String> linkDn, long domainId, String domainName, boolean isDeletedGPLink,long backupId) {
        if(isDeletedGPLink) {
            GpoLinksUtil.updateDeletedGPLinks(linkDn, domainId);
        }
        return getGuidForLinks(linkDn, domainId, domainName, false, null, isDeletedGPLink,backupId);
    }

    public static Properties getGuidForLinks(ArrayList<String> linkDns, long domainId, String domainName, boolean isFullSync, HashMap<String, Object[]> allObjects,long backupId){
        return getGuidForLinks(linkDns, domainId, domainName, isFullSync, allObjects, false,backupId);
    }

    public static Properties getGuidForLinks(ArrayList<String> linkDns, long domainId, String domainName, boolean isFullSync, HashMap<String, Object[]> allObjects, boolean isDeletedGPLink,long backupId) {
        Properties memberGuidVsDn = new Properties();
        ObjectType objectType;
        try {
            if (isFullSync) {
                for (String linkDn : linkDns) {
                    try {
                        memberGuidVsDn.put(allObjects.get(linkDn.toLowerCase())[0], linkDn);
                    } catch (Exception e) {//ToDo : Check Reason
                        LogWriter.backup.log(Level.SEVERE, "No guid for the Member : {0}{1}", new Object[]{linkDn, LogWriter.getStackTrace(e)});
                        String guid;
                        
                        if(LdapUtil.isChildOfPolicyContainer(LdapUtil.getCanonicalName(linkDn))) {
                            guid = GpoUtil.getGpoId(linkDn);
                            String gpoName = GpoUtil.getGPONameFromAD(domainId, guid, linkDn);
                            GpoUtil.updateGpoDetails(domainId, guid, gpoName);
                            objectType = guid.equalsIgnoreCase(gpoName) ? ObjectType.Other : ObjectType.GroupPolicy;
                        } else {
                            guid = getGuidfromAD(linkDn, domainId);
                            objectType = ObjectType.Other;
                        }
                        LogWriter.backup.log(Level.INFO, "get guid from AD for DN:{0} guid:{1}", new Object[]{linkDn, guid});
                        memberGuidVsDn.put(guid, linkDn);
                        updateRangedAttrMetaData(guid, linkDn, domainId, objectType,backupId);
                        allObjects.put(linkDn.toLowerCase(), new Object[]{guid, objectType});
                    }
                }
            } else {

                 Set<String> dnSetCopy=  new TreeSet(String.CASE_INSENSITIVE_ORDER);
                LogWriter.backup.info("inside added get guid for front links");
                Connection connection = null;
                DataSet dataSet = null;
                try
                {
                    SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId));
                    Criteria criteria = (new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_DN"), linkDns.toArray(), QueryConstants.IN, false));
                    query.setCriteria(criteria);
                    query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"));
                    query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"));
                    query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_DN"));
                    query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_TYPE"));
                    RelationalAPI relApi = RelationalAPI.getInstance();
                    connection = relApi.getConnection();
                    dataSet = relApi.executeQuery(query, connection);
                    Set<String> set=  new TreeSet(String.CASE_INSENSITIVE_ORDER);
                    set.addAll(linkDns);
                    linkDns.clear();
                    while (dataSet.next()) {
                        String objectDN = dataSet.getAsString("OBJECT_DN");
                        set.remove(objectDN);
                        memberGuidVsDn.put(dataSet.getAsString("OBJECT_GUID"), objectDN);
                    }
                    linkDns.addAll(set);
                    for(int i = 0; i <linkDns.size(); i++){
                        String linkDn = linkDns.get(i);                
                        if(LdapUtil.isChildOfPolicyContainer(LdapUtil.getCanonicalName(linkDn))){
                            String gpoId = GpoUtil.getGpoId(linkDn);
                            String gpoName = GpoUtil.getGPONameFromAD(domainId, gpoId, linkDn);
                            GpoUtil.updateGpoDetails(domainId, gpoId, gpoName);
                            memberGuidVsDn.put(gpoId, linkDn);
                            updateRangedAttrMetaData(gpoId, linkDn, domainId, gpoId.equalsIgnoreCase(gpoName) ? ObjectType.Other : ObjectType.GroupPolicy,backupId);
                        }
                        else{
                             LogWriter.backup.severe("No guid for the Member : " +linkDn );
                        String guid = getGuidfromAD(linkDn, domainId);
                        LogWriter.backup.info("get guid from AD for DN:"+linkDns.get(i)+" guid:"+guid);
                        memberGuidVsDn.put(guid, linkDn);
                         updateRangedAttrMetaData(guid, linkDn, domainId,ObjectType.Other,backupId);
                          allObjects.put(linkDn, new Object[]{guid,ObjectType.Other});
                        }
                    }
                } catch (Exception e) {
                    LogWriter.backup.severe(String.format("LinkedAttributesUtil.getGuidForLinks : {0}", new Object[]{ LogWriter.getStackTrace(e)}));
                    return null;
                } finally {
                    DBUtil.closeDataSetAndConnection(dataSet, connection);
                }
               
            }
        } catch (Exception e) {
            LogWriter.backup.log(Level.SEVERE, "getGuidForLinks{0}{1}", new Object[]{e, LogWriter.getStackTrace(e)});
        }
        return memberGuidVsDn;
    }
    
    public static Boolean updateRangedAttrMetaData(String linkGuid, String linkDn, long domainId,long backupId) throws Exception {
        return updateRangedAttrMetaData(linkGuid, linkDn, domainId, ObjectType.Other,backupId);
    }

    public static Boolean updateRangedAttrMetaData(String linkGuid, String linkDn, long domainId, ObjectType objectType,long backupId) {//DummyEntries
        try {
            String currentInfoTable = TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId;
            SelectQuery query = new SelectQueryImpl(Table.getTable(currentInfoTable));
            query.addSelectColumn(Column.getColumn(currentInfoTable, "CURRENTINFO_ID"));
            query.addSelectColumn(Column.getColumn(currentInfoTable, "OBJECT_GUID"));
            Criteria criteria = (new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"), linkGuid, QueryConstants.EQUAL, false));
            query.setCriteria(criteria);
            DataObject dObject = CommonUtil.getPersistence(new boolean[0]).get(query);
            if(!dObject.isEmpty()){
               return  false;
            }
            
            DataObject dataObject = new WritableDataObject();            
            Row metaInfoRow = new Row(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId);
            metaInfoRow.set("OBJECT_GUID", linkGuid);
            metaInfoRow.set("OBJECT_NAME", LdapUtil.getCommonName(linkDn));
            metaInfoRow.set("OBJECT_LOCATION", LdapUtil.getParentCanonical(linkDn));
            metaInfoRow.set("OBJECT_SID", "");
            metaInfoRow.set("CHANGE_TYPE",4);
            metaInfoRow.set("OBJECT_TYPE",objectType.maskValue);
            metaInfoRow.set("PARENT_GUID","" );
            DataAccess.generateValues(metaInfoRow);
            dataObject.addRow(metaInfoRow);
            CommonUtil.getPersistence().add(dataObject);
            dataObject = new WritableDataObject();
            
            Row currentInfoRow;
            currentInfoRow = new Row(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId);
            DataAccess.generateValues(currentInfoRow);
            currentInfoRow.set("OBJECT_GUID", linkGuid.toLowerCase());
            currentInfoRow.set("OBJECT_DN", linkDn);
            currentInfoRow.set("OBJECT_SID", "");
            currentInfoRow.set("PARENT_GUID", BackupUtil.emptyGuid.toString());
            currentInfoRow.set("OBJECT_TYPE", objectType.maskValue);
            currentInfoRow.set("LINK_ID", metaInfoRow.get("LINK_ID"));
            currentInfoRow.set("COUNT", 1);
            currentInfoRow.set("SYNC_STATUS", RMPCommonFlags.HasChange.maskValue);  //value: 0 - bits{HAS_CHANGE-false, HAS_HISTORY-false, IS_DELETED-false --> 0}
            currentInfoRow.set("IS_BACKUP_SET", 0); //value: 0 - bits{IS_BACKUP_SET_PREVIOUSLY-false, IS_BACKUP_SET_PREVIOUSLY-false --> 0}
            currentInfoRow.set("CHANGE_TYPE", 0);
            currentInfoRow.set("CHANGE_MASK",  new ByteArrayInputStream("".getBytes(StandardCharsets.UTF_8)));
            currentInfoRow.set("CHANGE_DATA", new JsonObject().toString());
            currentInfoRow.set("LINKS_DATA", new JsonObject().toString());
            currentInfoRow.set("BACKUP_ID", backupId);
            dataObject.addRow(currentInfoRow);
            CommonUtil.getPersistence().add(dataObject);
            return true;
        } catch (Exception e) {
            LogWriter.backup.log(Level.SEVERE, "FrontLinkAttrManager.updateGroupMemeberMetadata domainId-{0} /n linkdn{1}{2}", new Object[]{domainId, linkDn, e});
            e.printStackTrace();
        }
        return false;
    }

    /*public static String getGuidForDN(String distinguishedName, Long domainId) {
     String objectGuid = new String();
     Properties tempProp = getGuidForLinks(GeneralUtil.getStringAsArrayList(distinguishedName), domainId);
     for (Entry<Object, Object> temp : tempProp.entrySet()) {
     if (((String) temp.getValue()).equalsIgnoreCase(distinguishedName)) {
     objectGuid = (String) temp.getKey();
     }
     }
     return objectGuid;
     }*/
    public static UUID getGuidForDN(String distinguishedName, Long domainId) throws DataAccessException {
        SelectQuery query = new SelectQueryImpl((Table.getTable(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId)));
        query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"));
        query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"));
        Criteria crit = (new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_DN"), distinguishedName, QueryConstants.EQUAL));
        Criteria emptyGuid = (new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "PARENT_GUID"), new UUID(0, 0), QueryConstants.NOT_EQUAL));
        query.setCriteria(crit.and(emptyGuid));
        DataObject obj = CommonUtil.getPersistence().get(query);
        if (!obj.isEmpty()) {
            Row row = obj.getRow(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId);
            return UUID.fromString(row.get("OBJECT_GUID").toString());
        }
        return null;
    }

    public static void clearData(FrontLinkAttrManager forwardLinkManager) {
        forwardLinkManager = null;
    }
    
    public static void clearFrontLinks(FrontLinkAttrManager forwardLinkManager) {
        forwardLinkManager.frontLinkMetaInfo.clear();
    }
    public static long getBackupIdFromLinksData(String versionInfoTable,String objId,long bId){
        Connection con =null;
            DataSet dset = null;
            long bkpId=0;
            int attrId=0;
            try{
        SelectQuery query = new SelectQueryImpl(Table.getTable(versionInfoTable));
         query.addSelectColumn( Column.getColumn(versionInfoTable, "LINKS_DATA"));
         Criteria criteria=new Criteria(Column.getColumn(versionInfoTable, "OBJECT_GUID"),objId,QueryConstants.EQUAL);
         criteria=criteria.and(new Criteria(Column.getColumn(versionInfoTable, "BACKUP_ID"),bId,QueryConstants.EQUAL));
         query.setCriteria(criteria);
         con = RelationalAPI.getInstance().getConnection();
          dset = RelationalAPI.getInstance().executeQuery(query, con);
          while(dset.next())
                {
                    JSONObject linksData =new JSONObject( dset.getAsString(1));
                    if(linksData!=null ){
                      for(ForwardLink forwardLink : ForwardLink.values()) {
                           if(forwardLink != ForwardLink.none){
                               if(linksData.has(RmpConstants.BACKUP_VALUE_PREFIX+forwardLink.linkId)){
                                   attrId=forwardLink.linkId;
                                   break;
                               }
                               
                           }
                      }
                      if(attrId==0){
                      for(BackwardLink backwardLink:BackwardLink.values()){
                          if(backwardLink != BackwardLink.none){
                               if(linksData.has(RmpConstants.BACKUP_VALUE_PREFIX+backwardLink.linkId)){
                                   attrId=backwardLink.linkId;
                                   break;
                               }
                               
                           }
                          
                      }
                      }
                      if(attrId!=0){
                           JSONArray linkBackupData=new JSONArray(linksData.get(RmpConstants.BACKUP_VALUE_PREFIX+attrId).toString());
                           bkpId=linkBackupData.getLong(linkBackupData.length()-1);
                      }
                      
                      
                    }
                    
                }
          if(bkpId!=0){
          return bkpId;
          }
            }
            catch(Exception e){
                e.printStackTrace();
            }
            finally
            {
                DBUtil.closeDataSetAndConnection(dset, con);
            }
        return bId;
        
    }
     public static long getLatestDeletedBackupId(long domainId,String linkGuid) // move method to Util Class
    {
        String version = TableName.RMP_OBJ_VER_INFO + "_" + domainId;
        String meta = TableName.RMP_OBJ_META_VER_INFO+"_"+domainId;
        
        long bkpId = 0;
        Connection con = null;
        DataSet dset = null;
        try
        {
            SelectQuery query = new SelectQueryImpl(Table.getTable(meta));
            Join join = new Join(meta, version, new String[]{"LINK_ID"},new String[]{"LINK_ID"}, Join.INNER_JOIN);
            query.addJoin(join);
            Column maxBackup = Column.getColumn(version, "BACKUP_ID");
            maxBackup = maxBackup.maximum();
            query.addSelectColumn(maxBackup);
            Criteria isdeleted = new Criteria(Column.getColumn(meta, "CHANGE_TYPE"),ChangeType.Deleted.maskValue,QueryConstants.EQUAL);
            Criteria guidCrit = new Criteria(Column.getColumn(meta, "OBJECT_GUID"),linkGuid,QueryConstants.EQUAL);
            query.setCriteria(guidCrit.and(isdeleted));
            con = RelationalAPI.getInstance().getConnection();
            
            try
            {
                String que = RelationalAPI.getInstance().getSelectSQL(query);
                dset = RelationalAPI.getInstance().executeQuery(query, con);
                while(dset.next())
                {
                    bkpId = dset.getAsLong(1);
                    
                }
                if(bkpId!=0){
                    bkpId=getBackupIdFromLinksData(version,linkGuid,bkpId);
                }
                
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        } catch (Exception e)
        {
            e.printStackTrace();
        } finally {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        return bkpId;
    }
     
     public static long getMaxBackupIdForObject(long domainId,String linkGuid)
    {
        String ranged = TableName.RMP_RANGED_ATTRIBUTES + "_" + domainId;
        long bkpId = 0;
        Connection con = null;
        DataSet dset = null;
        try
        {
            SelectQuery query = new SelectQueryImpl(Table.getTable(ranged));
            Column max = Column.getColumn(ranged, "BACKUP_ID");
            max = max.maximum();
            query.addSelectColumn(max);
            query.setCriteria((new Criteria(Column.getColumn(ranged, "FRONTLINK_OBJECT_GUID"),linkGuid,QueryConstants.EQUAL).or(new Criteria(Column.getColumn(ranged, "BACKLINK_OBJECT_GUID"),linkGuid,QueryConstants.EQUAL))).and(new Criteria(Column.getColumn(ranged, "LINKS_TYPE"),2,QueryConstants.EQUAL)));
            con = RelationalAPI.getInstance().getConnection();
            
            try
            {
                dset = RelationalAPI.getInstance().executeQuery(query, con);
                while(dset.next())
                {
                    bkpId = dset.getAsLong(1);
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        } catch (Exception e)
        {
            e.printStackTrace();
        } finally {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        return bkpId;
    }
    
    //update ranged att for recycled objects
    public static Boolean updateRecycledLinks(BackupObject backupObject,FrontLinkAttrManager frontLink,BackupImpl backupImpl){
        try
        {
            long backupId = getLatestDeletedBackupId(backupObject.domainId,backupObject.objId.toString());
            backupId = (backupId==0)?getMaxBackupIdForObject(backupObject.domainId,backupObject.objId.toString()):backupId;
            Properties tempProp = new Properties();
            for(ForwardLink forwardLink : ForwardLink.values()) {
                if(forwardLink != ForwardLink.none){
                    frontLink.forwardLink = forwardLink;
                    ArrayList totalDnAndGuid = getTotalDnOrGuidFromBackup(frontLink.domainId, forwardLink.linkId, backupId, backupObject.objId.toString(), 2,"FRONTLINK_OBJECT_GUID", "BACKLINK_OBJECT_GUID", "BACKLINK_OBJECT_DN", false, 0, 0,"BACKLINK_OBJECT_DN"); 
                    if(!totalDnAndGuid.isEmpty()) {
                        if(!tempProp.containsKey("objectGUID")) {
                            tempProp.put("objectGUID",GeneralUtil.getStringAsArrayList(backupObject.objId.toString()));
                            tempProp.put("distinguishedName", GeneralUtil.getStringAsArrayList(backupObject.distinguishedName));
                        }                        
                        tempProp.put(forwardLink.toString()+ADDED_RANGE, totalDnAndGuid);
                    }
                }
                if(forwardLink != forwardLink.none) {
                    frontLink.forwardLink = forwardLink;
                    Properties totalDnAndGuid = getTotalDnAndGuidFromBackup(frontLink.domainId, forwardLink.linkId, backupId, backupObject.objId.toString(), 2,"BACKLINK_OBJECT_GUID", "FRONTLINK_OBJECT_GUID", "FRONTLINK_OBJECT_DN", false, 0, 0);
                    for(Map.Entry<Object,Object> backlnk:totalDnAndGuid.entrySet())                  
                    {
                        Properties backtempProp = new Properties();
                        backtempProp.put("objectGUID",GeneralUtil.getStringAsArrayList((String) backlnk.getKey()));
                        backtempProp.put("distinguishedName",GeneralUtil.getStringAsArrayList((String) backlnk.getValue()));
                        backtempProp.put(forwardLink.toString()+ADDED_RANGE,GeneralUtil.getStringAsArrayList( backupObject.distinguishedName));
                        backtempProp.put("backlinkGuid", backupObject.objId.toString());
                        backupImpl.backupObjectNotInCache(backtempProp);
                    }
                }
            }     
            if(!tempProp.isEmpty()) {
                backupImpl.backupObjectNotInCache(tempProp);
            }
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return false;
    }
    public static Properties getTotalDnAndGuidFromBackup(Long domainId, int linkId, Long backupId, String objectGuid, int changes, String linkForeGuid, String linkBackGuid, String linkBackDn, Boolean isRanged, int startIndex, int endIndex) throws QueryConstructionException {
        Properties dnOrGuid = new Properties();
        Connection con = null;
        DataSet dset = null;
        try {
            SelectQuery query = getLinksListFromRangedAttr(domainId, linkId, backupId, objectGuid, changes, linkForeGuid, linkBackGuid, linkBackDn, isRanged, startIndex, endIndex);
            String que = RelationalAPI.getInstance().getSelectSQL(query);
            con = RelationalAPI.getInstance().getConnection();
            try
            {
                dset = RelationalAPI.getInstance().executeQuery(query, con);
                while(dset.next())
                {
                    dnOrGuid.put(dset.getAsString(linkBackGuid),dset.getAsString(linkBackDn));
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            LogWriter.backup.severe("GroupMemberManager: getCurrentMembersDnListFromBackup domainId-" + domainId + e);
            e.printStackTrace();
        } finally {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        return dnOrGuid;
    }
    
    public static JSONObject getDefaultLinksCount()
    {
        JSONObject linkCount = new JSONObject();
        try
        {
            linkCount.put("addedCount", 0);
            linkCount.put("removedCount", 0);
            linkCount.put("modifiedCount", 0);
            linkCount.put("totalCount", 0);
            return linkCount;
        }
        catch(Exception e)
        {
            return null;
        }
    }
}

//ignoreI18n_start
