//$Id$
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.rangedattributes;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.DerivedColumn;
import com.adventnet.ds.query.DerivedTable;
import com.adventnet.ds.query.GroupByClause;
import com.adventnet.ds.query.GroupByColumn;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.QueryConstructionException;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.ad.backup.BackupImpl;
import com.manageengine.rmp.ad.backup.BackupUtil;
import com.manageengine.rmp.ad.gpo.manager.GPBackLinkAttrManager;
import static com.manageengine.rmp.ad.rangedattributes.FrontLinkAttrManager.ADDED;
import static com.manageengine.rmp.ad.rangedattributes.FrontLinkAttrManager.REMOVED;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.recovery.RecoveryHandler;
import com.manageengine.rmp.recovery.retreiverClass;
import com.manageengine.rmp.util.Attribute;
import com.manageengine.rmp.util.LdapUtil;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class BackLinkAttrManager {

    protected final Long DOMAIN_ID;
    protected final Long BACKUP_ID;
    public HashMap<String, RangedAttrObject> backLinkMetaInfo;
    private BackupImpl backupImpl;
    private String tableName;

    public BackLinkAttrManager(long domainId, long backupId, BackupImpl backupImpl) {
        this.DOMAIN_ID = domainId;
        this.BACKUP_ID = backupId;
        this.backupImpl = backupImpl;
        backLinkMetaInfo = new HashMap<>();
        tableName = setTableName();
    }

    protected String setTableName()
    {
        return TableName.RMP_RANGED_ATTRIBUTES+"_"+DOMAIN_ID;
    }
    
    public boolean updateBackLinks() {
        try {
            backupImpl.backupUpdater.updateRangedAttrMetadatainObj(backLinkMetaInfo, backupImpl, false, backupImpl.isInitBackup);
        } catch (Exception e) {
            LogWriter.backup.severe("updateBackLinks- " + e + LogWriter.getStackTrace(e));
        }
        return true;
    }

    public static boolean updateBackLinkCount(int linkType, Properties prop, BackupObject lastBackup) {
        try {
            String backupKey = "b" + linkType;
            if (lastBackup.linksData.has(backupKey)) {
                String attrName = BackwardLink.getAttributeName(linkType);
                int[] metaArray = new int[4];
                String backupVal = lastBackup.linksData.get(backupKey).toString();
                metaArray =  JSONObjectUtil.getObjectFromJsonString(backupVal, metaArray.getClass());
                int[] linkMetadata = new int[4];
                linkMetadata = JSONObjectUtil.getObjectFromJsonString(BackupUtil.getString(prop, attrName), linkMetadata.getClass());
                linkMetadata[0] = metaArray[0] + linkMetadata[0];// - linkMetadata[2];
                ArrayList backupValue = new ArrayList();
                backupValue.add(JSONObjectUtil.toJsonString(linkMetadata));
                prop.put(attrName, backupValue);
            }
        } catch (Exception e) {
            LogWriter.backup.severe("updateBackLinks- " + e + LogWriter.getStackTrace(e));
        }
        return true;
    }

    public boolean updateFailedBackLinks() {//For Failure Case - Later
        try {
            DataSet dataObject = null;
            SelectQuery rangedCount = getBackwardLinkQuery();
            Connection connection = null;
            try {
                connection = RelationalAPI.getInstance().getConnection();
                dataObject = RelationalAPI.getInstance().executeQuery(rangedCount, connection);
                String objectGuid = null;
                Integer attributeType = null;
                Integer count = null;
                if (dataObject != null) {
                    while (dataObject.next()) {
                        objectGuid = (String) dataObject.getValue("BACKLINK_OBJECT_GUID");
                        attributeType = BackwardLink.getBackwardLink((Integer) dataObject.getValue("FORWARD_LINK_ID")).linkId;
                        count = (Integer) dataObject.getValue("COUNT_VALUE");
                        Long linksType = ((Integer) dataObject.getValue("LINKS_TYPE")).longValue();
                        if (!backLinkMetaInfo.containsKey(objectGuid)) {
                            RangedAttrObject backwardLinkObject = new RangedAttrObject(objectGuid, (String) dataObject.getValue("BACKLINK_OBJECT_DN"), null);
                            backwardLinkObject.setNewBacklinkMetadata(attributeType, count, linksType, this.BACKUP_ID);
                            backLinkMetaInfo.put(objectGuid, backwardLinkObject);
                            backupImpl.updateRangedAttrBackupStatus(backLinkMetaInfo.size());
                        } else {
                            backLinkMetaInfo.get(objectGuid).setBacklinkMetadata(attributeType, count, linksType, this.BACKUP_ID);
                        }
                    }
                }
            } finally {
                DBUtil.closeDataSetAndConnection(dataObject, connection);
            }
        } catch (Exception e) {
            LogWriter.backup.severe("updateBackLinks- " + e + LogWriter.getStackTrace(e));
        }
        backupImpl.backupUpdater.updateRangedAttrMetadatainObj(backLinkMetaInfo, backupImpl, false, backupImpl.isInitBackup);//ToDo: Try to page it
        return true;
    }

    private SelectQuery getBackwardLinkQuery() {
        try {
            SelectQuery dnJoin = new SelectQueryImpl(Table.getTable(tableName));
            dnJoin.addSelectColumn(Column.getColumn(tableName, "BACKUP_ID"));
            dnJoin.addSelectColumn(Column.getColumn(tableName, "FORWARD_LINK_ID"));
            dnJoin.addSelectColumn(Column.getColumn(tableName, "BACKLINK_OBJECT_GUID"));
            dnJoin.addSelectColumn(Column.getColumn(tableName, "FRONTLINK_OBJECT_GUID"));
            dnJoin.addSelectColumn(Column.getColumn(tableName, "LINKS_TYPE"));
            dnJoin.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_"+DOMAIN_ID, "OBJECT_DN", "BACKLINK_OBJECT_DN"));
            if(tableName.equalsIgnoreCase(TableName.RMP_GPO_LINK_ATTRIBUTES+"_"+DOMAIN_ID))
            {
                dnJoin.addSelectColumn(Column.getColumn(tableName, "STATUS"));
                dnJoin.addSelectColumn(Column.getColumn(tableName, "PRIORITY"));
            }

            dnJoin.addJoin(new Join(Table.getTable(tableName), Table.getTable(TableName.RMP_OBJ_CURRENT_INFO+"_"+DOMAIN_ID), new String[]{ "BACKLINK_OBJECT_GUID"}, new String[]{ "OBJECT_GUID"}, Join.INNER_JOIN));
            DerivedTable table1 = new DerivedTable(tableName, dnJoin);

            Criteria critBackupId = new Criteria(Column.getColumn(table1.getTableAlias(), "BACKUP_ID"), BACKUP_ID, QueryConstants.EQUAL);
            Criteria critCurrentBackup = new Criteria(Column.getColumn(table1.getTableAlias(), "BACKUP_ID"), 0, QueryConstants.EQUAL);
            Criteria critNotDNS = new Criteria(Column.getColumn(table1.getTableAlias(), "FORWARD_LINK_ID"), ForwardLink.records.linkId, QueryConstants.NOT_EQUAL);

            SelectQuery backlinkObjects1 = new SelectQueryImpl(table1); //select query to select all FORWARD_LINK_ID for one particular backup
            backlinkObjects1.addSelectColumn(Column.getColumn(table1.getTableAlias(), "FORWARD_LINK_ID"));
            backlinkObjects1.setCriteria(critBackupId.and(critNotDNS));
            DerivedColumn backlinkDerived1 = new DerivedColumn("FORWARD_LINK_ID", backlinkObjects1);
            Criteria derivedForwardLink = new Criteria(Column.getColumn(table1.getTableAlias(), "FORWARD_LINK_ID"), backlinkDerived1, QueryConstants.IN);

            SelectQuery backlinkObjects2 = new SelectQueryImpl(table1); // select all backlink guids for one backup
            backlinkObjects2.addSelectColumn(Column.getColumn(table1.getTableAlias(), "BACKLINK_OBJECT_GUID"));
            backlinkObjects2.setCriteria(critBackupId.and(critNotDNS));
            DerivedColumn backlinkDerived2 = new DerivedColumn("BACKLINK_OBJECT_GUID", backlinkObjects2);
            Criteria derivedBacklinkGuid = new Criteria(Column.getColumn(table1.getTableAlias(), "BACKLINK_OBJECT_GUID"), backlinkDerived2, QueryConstants.IN);

            Column frontlinkCount = Column.getColumn(table1.getTableAlias(), "FRONTLINK_OBJECT_GUID").count();
            frontlinkCount.setColumnName("COUNT_VALUE");
            frontlinkCount.setColumnAlias("COUNT_VALUE");
            frontlinkCount.setColumnIndex(2);

            SelectQuery rangedCount = new SelectQueryImpl(table1); // query to select the below values from the rangedattributes table
            rangedCount.addSelectColumn(Column.getColumn(table1.getTableAlias(), "BACKLINK_OBJECT_GUID"));
            rangedCount.addSelectColumn(Column.getColumn(table1.getTableAlias(), "BACKLINK_OBJECT_DN"));
            rangedCount.addSelectColumn(frontlinkCount);
            rangedCount.addSelectColumn(Column.getColumn(table1.getTableAlias(), "LINKS_TYPE"));
            rangedCount.addSelectColumn(Column.getColumn(table1.getTableAlias(), "FORWARD_LINK_ID"));
            if(tableName.equalsIgnoreCase(TableName.RMP_GPO_LINK_ATTRIBUTES+"_"+DOMAIN_ID))
            {
                rangedCount.addSelectColumn(Column.getColumn(table1.getTableAlias(), "STATUS"));
                rangedCount.addSelectColumn(Column.getColumn(table1.getTableAlias(), "PRIORITY"));
            }

            rangedCount.setCriteria(critBackupId.or(critCurrentBackup).and(derivedForwardLink).and(derivedBacklinkGuid));

            GroupByColumn rangedGroup1 = new GroupByColumn(Column.getColumn(table1.getTableAlias(), "BACKLINK_OBJECT_GUID"), true); // grouping to get the count of the frontlink guid grouped by backlink object link type and link ID
            GroupByColumn rangedGroup2 = new GroupByColumn(Column.getColumn(table1.getTableAlias(), "BACKLINK_OBJECT_DN"), true);
            GroupByColumn rangedGroup3 = new GroupByColumn(Column.getColumn(table1.getTableAlias(), "LINKS_TYPE"), true);
            GroupByColumn rangedGroup4 = new GroupByColumn(Column.getColumn(table1.getTableAlias(), "FORWARD_LINK_ID"), true);

            List<GroupByColumn> rangedGroupList = new ArrayList<GroupByColumn>();
            rangedGroupList.add(rangedGroup1);
            rangedGroupList.add(rangedGroup2);
            rangedGroupList.add(rangedGroup3);
            rangedGroupList.add(rangedGroup4);
            GroupByClause gc = new GroupByClause(rangedGroupList);

            rangedCount.setGroupByClause(gc);
            //String query = RelationalAPI.getInstance().getSelectSQL(rangedCount);
            //LogWriter.backup.info(query);
            return rangedCount;
        } catch (Exception e) {
            LogWriter.backup.severe("Back LinkAttrManager.getBackwardLinkQuery: - " + LogWriter.getStackTrace(e));
        }
        return null;
    }
    /*
     private boolean updateMetaInObject(int total, int added, int removed, int linkId, String objectGuid, String dName) {
     backwardLinkObject.setRangedAttrData(objectGuid, dName, null, linkId, total, added, removed);
     backLinkMetaInfo.put(objectGuid, backwardLinkObject);
     return true;
     }
     */

    public static ArrayList<String> getCurrentBackLinksDnListFromBackup(Long domainId, BackwardLink backwardLink, String objectGuid) {
        return LinkedAttributesUtil.getTotalDnorGuidListFromBackup(domainId, backwardLink.linkId, objectGuid, "BACKLINK_OBJECT_GUID", "FRONTLINK_OBJECT_DN");
    }

    /*public static ArrayList getDnFromRangedAttrInfo(Long domainId, BackwardLink backwardLink, Long backupId, String objectGuid, int changes) {
     return LinkedAttributesUtil.getDnGuidFromRangedAttrInfo(domainId, backwardLink.getForwardLink().linkId, backupId, objectGuid, changes, "BACKLINK_OBJECT_GUID", "FRONTLINK_OBJECT_GUID", "FRONTLINK_OBJECT_DN");
     }*/
    //Backward Link Restore Handling
    public static Properties restoreLinkedAttr(Properties domainDetails, Long restoreBackupId, String objectDn, String objectGuid, int maskIndex, ObjectType objectType, Attribute attrInfo,Properties adValue,boolean toReanimate) 
    {
        if(maskIndex == BackwardLink.gpBackLinks.linkId) 
        {
            return GPBackLinkAttrManager.restoreRangedAttr(domainDetails, restoreBackupId, objectGuid, maskIndex, objectType);
        }
        else
        {
            return restoreRangedAttr(domainDetails, restoreBackupId, objectDn, objectGuid, maskIndex, objectType, attrInfo,adValue,toReanimate);
        }
    }
    
    public static Properties restoreRangedAttr(Properties domainDetails, Long restoreBackupId, String objectDn, String objectGuid, int maskIndex, ObjectType objectType, Attribute attrInfo,Properties adValue,boolean toReanimate) {
        Boolean result = true;
        Properties restoreprop = new Properties();
        Connection con = null;
        DataSet dset = null;
        long added = 0,removed = 0,skipped = 0,addSkip=0,rmvSkip=0;
        ArrayList dbCurrent,adCurrent,adAdded,adRemoved,dbAdded,dbRemoved,adCurrentdnlist;
        try {
            Long domainId = Long.parseLong((String) domainDetails.get("DOMAIN_ID"));
            ForwardLink forwardLink = ForwardLink.getForwardLink(attrInfo.attributeMaskIndex);
            SelectQuery addSQ = null, removeSQ = null;
            if (restoreBackupId != null)
            {
                addSQ = LinkedAttributesUtil.compareForRestoreFrontLink(domainId, ForwardLink.getForwardLink(maskIndex).linkId, restoreBackupId, objectGuid, "BACKLINK_OBJECT_GUID", "FRONTLINK_OBJECT_GUID", "FRONTLINK_OBJECT_DN", ADDED,toReanimate);
                removeSQ = LinkedAttributesUtil.compareForRestoreFrontLink(domainId, ForwardLink.getForwardLink(maskIndex).linkId, restoreBackupId, objectGuid, "BACKLINK_OBJECT_GUID", "FRONTLINK_OBJECT_GUID", "FRONTLINK_OBJECT_DN", REMOVED,toReanimate);
            } else
            {
                removeSQ = LinkedAttributesUtil.compareForRestoreFrontLink(domainId, ForwardLink.getForwardLink(maskIndex).linkId, -1L, objectGuid, "BACKLINK_OBJECT_GUID", "FRONTLINK_OBJECT_GUID", "FRONTLINK_OBJECT_DN", REMOVED,toReanimate);//To Remove The Whole List
            }
            
            HashMap<String, String> localguid = new HashMap<>();
            dbRemoved = new ArrayList();
            dbAdded = new ArrayList();
            adAdded = new ArrayList();
            adRemoved = new ArrayList();
            try
            {
                con = RelationalAPI.getInstance().getConnection();
                adCurrentdnlist = (ArrayList) adValue.get(attrInfo.attrName);
                adCurrent = new ArrayList();
                if(adCurrentdnlist != null)
                {
                    for (Object linkDn : adCurrentdnlist)
                    {
                        String dist = (String) linkDn;
                        String guid = LinkedAttributesUtil.getGuidfromAD(dist, domainId);
                        localguid.put(guid, dist);
                        adCurrent.add(guid);
                    }
                }
                dbCurrent = new ArrayList<String>();
                
                SelectQuery totalList = LinkedAttributesUtil.getLinksListFromRangedAttr(domainId, ForwardLink.getForwardLink(maskIndex).linkId, (long) 0, objectGuid, 0, "BACKLINK_OBJECT_GUID", "FRONTLINK_OBJECT_GUID", "FRONTLINK_OBJECT_DN", false, 0, 0);
                
                dset = RelationalAPI.getInstance().executeQuery(totalList, con);
                if (dset != null)
                {
                    while (dset.next())
                    {
                        String linkDn = dset.getAsString("FRONTLINK_OBJECT_DN");
                        String guid = dset.getAsString("FRONTLINK_OBJECT_GUID");
                        dbCurrent.add(guid);
                        if (!localguid.containsKey(guid))
                        {
                            localguid.put(guid, linkDn);
                        }
                    }
                }
                DBUtil.closeDataSet(dset);
                adRemoved = new ArrayList(dbCurrent);
                adRemoved.removeAll(retreiverClass.getIntersection(adCurrent, dbCurrent));
                adAdded = new ArrayList(adCurrent);
                adAdded.removeAll(retreiverClass.getIntersection(adCurrent, dbCurrent));
                adCurrent = null;
                dbCurrent = null;

                if (addSQ != null)
                {
                    dset = RelationalAPI.getInstance().executeQuery(addSQ, con);
                    if (dset != null)
                    {
                        while (dset.next())
                        {
                            String linkguid = dset.getAsString("FRONTLINK_OBJECT_GUID");
                            String linkDn = dset.getAsString("FRONTLINK_OBJECT_DN");
                            if (!localguid.containsKey(linkguid))
                            {
                                localguid.put(linkguid, linkDn);
                            }
                            dbAdded.add(linkguid);
                        }
                    }
                    DBUtil.closeDataSet(dset);
                }
                dset = RelationalAPI.getInstance().executeQuery(removeSQ, con);
                if (dset != null)
                {
                    while (dset.next())
                    {
                        String linkguid = dset.getAsString("FRONTLINK_OBJECT_GUID");
                        String linkDn = dset.getAsString("FRONTLINK_OBJECT_DN");
                        if (!localguid.containsKey(linkguid))
                        {
                            localguid.put(linkguid, linkDn);
                        }
                        dbRemoved.add(linkguid);
                    }
                }
                DBUtil.closeDataSet(dset);
                
            } catch (Exception e)
            {
                e.printStackTrace();
            } finally
            {
                DBUtil.closeDataSet(dset);
                DBUtil.closeConnection(con);
            }
            
            ArrayList exclude = new ArrayList();
            exclude.addAll(retreiverClass.getIntersection(adAdded, dbAdded));
            exclude.addAll(retreiverClass.getIntersection(adRemoved, dbRemoved));

            adRemoved.removeAll(dbAdded);
            adAdded.removeAll(dbRemoved);
            dbAdded.addAll(adRemoved);
            dbAdded.removeAll(exclude);
            dbRemoved.addAll(adAdded);
            dbRemoved.removeAll(exclude);
            
            
            
            Properties temp = fillRestoreObjects(domainDetails, dbRemoved, 4, forwardLink, objectDn,localguid,true);
//            result = result && fillRestoreObjects(domainDetails, removeSQ, 4, forwardLink, objectDn);
            result = result && (Boolean)temp.get("result");
            removed += (long) temp.get("added");
            skipped += (long) temp.get("skipped");
            rmvSkip=skipped;
            if (restoreBackupId == null) {//revert to not set
//                return result;
                restoreprop.put("added", added);
                restoreprop.put("removed", removed);
                restoreprop.put("skipped", skipped);
                restoreprop.put("result", result);
                return restoreprop;
            }
            int controlCode = (BackwardLink.isSingleValued(attrInfo.attributeMaskIndex)) ? 2 : 3 ; // 2 - update, 3- append
            temp = fillRestoreObjects(domainDetails, dbAdded, controlCode, forwardLink, objectDn,localguid,false);
//            result = result && fillRestoreObjects(domainDetails, addSQ, controlCode, forwardLink, objectDn);
            result = result && (Boolean)temp.get("result");
            added+= ((long)temp.get("added"));
            addSkip= (long) temp.get("skipped");
            skipped += addSkip;
        } catch (Exception e) {
            LogWriter.backup.severe("BackLinkAttrManager: " + Arrays.toString(e.getStackTrace()));
            e.printStackTrace();
        }
        restoreprop.put("result", result);
        restoreprop.put("added", added);
        restoreprop.put("skipped", skipped);
        restoreprop.put("removed", removed);
        restoreprop.put("addSkipped",addSkip);
        restoreprop.put("rmvSkipped",rmvSkip);
//        return result;
        return restoreprop;
    }

    public static Properties fillRestoreObjects(Properties domainDetails,ArrayList linkguid, int controlCode, ForwardLink forwardLink, String objDn,HashMap<String,String> localguid,boolean isRemoved) {
        Boolean result = true;
        Properties restoreresult = new Properties();
        long added = 0,skipped = 0;
        try {
            int count = 0;
                HashMap<String, RangedAttrObject> objectList = new HashMap<String, RangedAttrObject>();
                for(Object guid : linkguid) {
                    String objectGuid = (String) guid;//dset.getValue("FRONTLINK_OBJECT_GUID").toString();
                    String objectDn = localguid.get(objectGuid);//dset.getValue("FRONTLINK_OBJECT_DN").toString();
                    if(!LdapUtil.isObjectDeleted(objectDn))
                    {
//                        added++;
                        if (!objectList.containsKey(objectGuid))
                        {
                            objectList.put(objectGuid, new RangedAttrObject(objectGuid, objDn));
                        }
                        objectList.get(objectGuid).rangedList.add(objDn);
                        count++;
                    }
                    else
                    {
                        skipped++;
                    }
                    if (count == 1000)
                    {
//                        result = result && initiateRestore(domainDetails, objectList, controlCode, forwardLink);
                        int failed = initiateRestore(domainDetails, objectList, controlCode, forwardLink);
                        if (failed > 0)
                        {
                            if(isRemoved){
                                skipped += failed;
                                added += count-failed;
                            }
                            else{
                                added += (count-1);
                            }
                        } else
                        {
                            added += count;
                        }
                        count = 0;
                    }
                    
                }
                if (count > 0) {
//                    result = result && initiateRestore(domainDetails, objectList, controlCode, forwardLink);
                    int failed = initiateRestore(domainDetails, objectList, controlCode, forwardLink);
                    if (failed > 0)
                    {
                        if(isRemoved){
                            skipped += failed;
                            added += count-failed;
                        }else{
                            added += (count-1);
                        }
                    } else
                    {
                        added += count;
                    }
                    count = 0;
                }
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } 
        restoreresult.put("added", added);
        restoreresult.put("skipped", skipped);
        restoreresult.put("result", result);
//        return result;
        return restoreresult;
    }

    private static int initiateRestore(Properties domainDetails, HashMap<String, RangedAttrObject> objectList, int controlCode, ForwardLink forwardLink) {
        RangedAttrObject.setObjectType(Long.valueOf(domainDetails.getProperty("DOMAIN_ID")), objectList, false, null);
        int result = restoreBackwardLink(domainDetails, objectList, controlCode, forwardLink);
        objectList.clear();
        return result;
    }

    public static int restoreBackwardLink(Properties domainDetails, HashMap<String, RangedAttrObject> objectList, int controlCode, ForwardLink forwardLink) {
//        Boolean result = true;
        int failed=0;
        try {
            for (Map.Entry<String, RangedAttrObject> rangedAttrObject : objectList.entrySet()) {
                RecoveryHandler recoveryHandler = new RecoveryHandler(domainDetails, rangedAttrObject.getValue().objType, rangedAttrObject.getValue().objectGuid, rangedAttrObject.getValue().objectDn);
                Hashtable<String, Object> attributeValue = new Hashtable<String, Object>();
                attributeValue.put(recoveryHandler.ATTR_NAME, forwardLink.getAttributeName());
                attributeValue.put(recoveryHandler.DATA_HANDLER_TYPE, new Long(1));
                if (rangedAttrObject.getValue().rangedList.size() == 1) {
                    attributeValue.put(recoveryHandler.ATTR_VALUE, rangedAttrObject.getValue().rangedList.get(0));
                    attributeValue.put(recoveryHandler.ATTR_VALUE_COUNT, Long.parseLong(rangedAttrObject.getValue().rangedList.size() + ""));
                } else {
                    attributeValue.put(recoveryHandler.ATTR_VALUE, rangedAttrObject.getValue().rangedList);
                    attributeValue.put(recoveryHandler.ATTR_VALUE_COUNT, Long.parseLong(rangedAttrObject.getValue().rangedList.size() + ""));
                }
                attributeValue.put(recoveryHandler.DW_CONTROL_CODE, new Long(controlCode));
                recoveryHandler.propList.add(attributeValue);
//                result = result && recoveryHandler.recoverObject();
                if(!recoveryHandler.recoverObject())
                {
                    failed++;
                }
                recoveryHandler.clearRequiredLists();
            }
        } catch (Exception e) {
            LogWriter.backup.severe("BackLinkAttrManager: " + e);
        }
//        return result;
        return failed;
    }
}
//ignoreI18n_end
