//$Id$
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.adsync;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DerivedColumn;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.common.LogWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class ADSyncAttributesConfig {

    public static final String TABLE = "ADSADSyncObjAttributes";

    public static void deleteSyncConfigRow(long objectID) {
        try {
            Persistence per = CommonUtil.getPersistence();
            DataObject delrow = per.get(TABLE, (Criteria) null);
            Criteria criteria = new Criteria(Column.getColumn(TABLE, "OBJECT_ID"), objectID, QueryConstants.EQUAL);
            delrow.deleteRows(TABLE, criteria);
            per.update(delrow);
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncAttributesConfig : " + e);
        }
    }

    public static void deleteSyncConfigRow(ArrayList<Long> objectIds, String ldapName) {
        try {
            Persistence per = CommonUtil.getPersistence();
            DataObject delrow = per.get(TABLE, (Criteria) null);
            Criteria objectIDCriteria = new Criteria(Column.getColumn(TABLE, "OBJECT_ID"), objectIds.toArray(), QueryConstants.IN);
            Criteria ldapNameCriteria = new Criteria(Column.getColumn(TABLE, "ATTRIB_LDAP_NAME"), ldapName, QueryConstants.EQUAL);
            delrow.deleteRows(TABLE, objectIDCriteria.and(ldapNameCriteria));
            per.update(delrow);
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncAttributesConfig : " + e);
        }
    }

    public static void deleteSyncConfigRow(ArrayList<Long> objectIDs) {
        try {
            Persistence per = CommonUtil.getPersistence();
            DataObject delrow = per.get(TABLE, (Criteria) null);
            Criteria criteria = new Criteria(Column.getColumn(TABLE, "OBJECT_ID"), objectIDs, QueryConstants.CONTAINS);
            delrow.deleteRows(TABLE, criteria);
            per.update(delrow);
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncAttributesConfig : " + e);
        }
    }

    public static void addSyncConfigRows(long objectID, HashSet<String> syncAttrRows) {
        try {
            Persistence per = CommonUtil.getPersistence();
            DataObject addrowDO = new WritableDataObject();
            for (String syncAttrRow : syncAttrRows) {
                if (syncAttrRow != null) {//ToDo: Identify root cause
                    addrowDO.addRow(addRow(objectID, syncAttrRow));
                }
            }
            per.add(addrowDO);
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncAttributesConfig : " + e);
        }
    }

    public static void addSyncConfigRows(ArrayList<Long> objectIDs, String attributeLdapName) {
        try {
            Persistence per = CommonUtil.getPersistence();
            DataObject addrow = new WritableDataObject();
            for (Long objectID : objectIDs) {
                addrow.addRow(addRow(objectID, attributeLdapName));
            }
            per.add(addrow);
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncAttributesConfig : " + e);
        }
    }

    public static void updateSyncConfigRow(long objectID, String attributeLdapName) {
        try {
            Criteria objectIdCriteria = new Criteria(Column.getColumn(TABLE, "OBJECT_ID"), objectID, QueryConstants.EQUAL);
            Criteria ldapNameCriteria = new Criteria(Column.getColumn(TABLE, "ATTRIB_LDAP_NAME"), attributeLdapName, QueryConstants.EQUAL);
            Persistence per = CommonUtil.getPersistence();
            UpdateQuery updateQuery = new UpdateQueryImpl(TABLE);
            updateQuery.setCriteria(objectIdCriteria.and(ldapNameCriteria));
            updateQuery.setUpdateColumn("ATTRIB_LDAP_NAME", attributeLdapName);
            per.update(updateQuery);
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncAttributesConfig : " + e);
        }
    }

    //util
    public static Row addRow(long objectID, String attributeLdapName) {
        Row row = new Row(TABLE);
        row.set("OBJECT_ID", objectID);
        row.set("ATTRIB_LDAP_NAME", attributeLdapName);
        return row;
    }

    public static int updateCustomAttrRow(Long domainId) {
        try {
            Persistence per = CommonUtil.getPersistence();
            DataObject addCustomAttr = new WritableDataObject();

            SelectQuery customAttributeId = new SelectQueryImpl(Table.getTable(ADSyncObjectsConfig.TABLE));
            customAttributeId.addSelectColumn(Column.getColumn(ADSyncObjectsConfig.TABLE, "OBJECT_ID"));
            Criteria domainIdCriteria = new Criteria(Column.getColumn(ADSyncObjectsConfig.TABLE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria customAttrCriteria = new Criteria(Column.getColumn(ADSyncObjectsConfig.TABLE, "OBJECT_TYPE"), SyncFilter.CUSTOM_SYNC_PREPENDER, QueryConstants.STARTS_WITH);
            customAttributeId.setCriteria(domainIdCriteria.and(customAttrCriteria));
            DerivedColumn customAttrIDs = new DerivedColumn("OBJECT_ID", customAttributeId);

            SelectQuery customAttrs = new SelectQueryImpl(Table.getTable(TABLE));
            customAttrs.addSelectColumn(Column.getColumn(TABLE, "OBJECT_ID"));
            customAttrs.addSelectColumn(Column.getColumn(TABLE, "ATTRIB_LDAP_NAME"));
            Criteria customAttrsCrit = new Criteria(Column.getColumn(TABLE, "OBJECT_ID"), customAttrIDs, QueryConstants.IN);
            customAttrs.setCriteria(customAttrsCrit);
            HashMap<Integer, HashSet<String>> existingAttrs = new HashMap<Integer, HashSet<String>>();
            DataObject obj = CommonUtil.getPersistence().get(customAttrs);
            Iterator iterator = obj.getRows(TABLE);
            while (iterator.hasNext()) {
                Row row = (Row) iterator.next();
                Long objectID = (Long) row.get("OBJECT_ID") - SyncFilter.CUSTOM_ATTR_OFFSET;
                Integer syncObjectId = objectID.intValue() % SyncFilter.DOMAIN_ID_OFFSET;
                if (!existingAttrs.containsKey(syncObjectId)) {
                    existingAttrs.put(syncObjectId, RMPADSyncConfig.getRMPSyncAttributesRow(syncObjectId));
                }
                String attrLdapName = (String) row.get("ATTRIB_LDAP_NAME");
                if (!existingAttrs.get(syncObjectId).contains(attrLdapName)) {
                    Row toAdd = addRow(objectID, attrLdapName);
                    addCustomAttr.addRow(toAdd);
                }
            }
            per.update(addCustomAttr);
            return 0;
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncAttributesConfig : " + e);
        }
        return -8;
    }
}

//ignoreI18n_end
