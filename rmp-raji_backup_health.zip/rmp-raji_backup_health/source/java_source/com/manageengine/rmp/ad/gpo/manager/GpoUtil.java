/**
 * $Id$
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.manager;

import com.adventnet.ds.query.*;
import com.adventnet.persistence.*;
import com.manageengine.ads.fw.jni.ADSNativeHandler;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.ad.gpo.parser.PolEntryConcise;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.util.*;
import com.manageengine.rmp.util.winutil.DirectoryUtil;
import com.manageengine.rmp.util.winutil.UNCAccess;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

import static com.manageengine.rmp.util.RmpPaths.DATA_DIR;
import static com.manageengine.rmp.util.winutil.UNCAccess.getRemoteFile;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class GpoUtil {

    public static final HashSet<String> DUPLICATE_GPO = new HashSet<String>(Arrays.asList("MaximumLogSize", "RestrictGuestAccess", "RetentionDays", "AuditLogRetentionPeriod"));
    public static String appendVN = "**del.";
    public static String appendVNs = "**delvals.";

    public static String[] parseGpoValues(String gpoValues) {
        return gpoValues.split("( = )|(=)|( =)|(= )", 2);
    }

    public static String policiesContainerDN(String domainName) {
        String domainComponent = LdapUtil.GetDomainComponents(domainName);
        return "CN=Policies,CN=System," + domainComponent;//No I18N
    }
    
    public static void deleteGpoBackupDirInFullSync(long domainId, String gpoId) {
        String dir = DATA_DIR + "\\" + domainId + "\\GPO" + "\\{" +gpoId.toUpperCase()+"}";//No I18N
        DirectoryUtil.deleteDirectory(dir);
    }
    
    public static String policiesContainerDNWithDNC(String defaultNamingContext) {
        return "CN=Policies,CN=System," + defaultNamingContext;//No I18N
    }

    public static String getGpoDn(String objectGuid, String domainName) {
        return "CN={" + objectGuid + "}," + policiesContainerDN(domainName);
    }

    public static String getGpoGuid(String gpoId, Properties domainProp) {
        try {
            String dName = getGpoDn(gpoId, domainProp.get("DOMAIN_NAME").toString());
            String objectGuid = LdapUtil.getADPropFromDn(dName, domainProp, "objectGuid");
            return objectGuid;
        } catch (Exception e) {
            LogWriter.recovery.severe("Cannot get Gpo Guid : " + e);
            return "";
        }
    }

    public static boolean isPoliciesContainerChild(String dn, String domainName) {
        return isPoliciesContainerChild(dn, domainName, null);
    }

    public static boolean isPoliciesContainerChild(String dn, String domainName, String lastParent) {
        try {
            String policiesContainer = policiesContainerDN(domainName).toUpperCase();
            if (lastParent != null) {
                int domainLength = LdapUtil.GetDomainComponents(domainName).length();
                if (lastParent.length() > (policiesContainer.length() + 5) && lastParent.toUpperCase().contains(policiesContainer)) {
                    return true;
                }
                ArrayList<String> tempVar = new ArrayList<String>();
                tempVar.add("CN=User\\0ADEL:");//No I18N
                tempVar.add("CN=UserOld\\0ADEL:");//No I18N
                tempVar.add("CN=UserStaging\\0ADEL:");//No I18N
                tempVar.add("CN=Machine\\0ADEL:");//No I18N
                tempVar.add("CN=MachineOld\\0ADEL:");//No I18N
                tempVar.add("CN=MachineStaging\\0ADEL:");//No I18N
                java.util.ArrayList<String> delCases = tempVar;
                for (String delCase : delCases) {
                    if (((dn.length() == (56 + delCase.length() + domainLength)) && dn.contains(delCase)) || ((lastParent.length() == (56 + delCase.length() + domainLength)) && lastParent.contains(delCase))) {
                        return true;
                    }
                }
            } else {
                if (dn.length() <= (policiesContainer.length() + 44)) {
                    return false;
                }
                return dn.toUpperCase().contains(policiesContainer);
            }
            return false;
        } catch (RuntimeException e) {
            LogWriter.gpo.severe("IsPoliciesContainerChild" + e + LogWriter.getStackTrace(e));
            return false;
        }
    }

    public static String getGpoId(String dn) {
        try {
            return dn.substring(4, 40).toUpperCase();
        } catch (Exception e) {
            LogWriter.gpo.severe("getGpoId " + e + LogWriter.getStackTrace(e));
            return "";
        }
    }

    public static byte[] getGpoIdByteArray(String dn) {
        String gpoId = getGpoId(dn);
        UUID gpoGuid = UUID.fromString(gpoId);
        return DataTypeUtil.getUUIDAsByteArray(gpoGuid);
    }

    public static String getGpoPath(String rootFolder, String gpoId) {
        return rootFolder + "\\{" + gpoId + "}";
    }

    public static File getGpoPath(File rootFolder, String gpoId) {
        return new File(rootFolder, "\\{" + gpoId + "}");
    }

    public static String removeBracesGpoID(String cn) {
        return cn.replace("{", "").replace("}", "");
    }

    public static String addBracesGpoID(String gpoId) {
        return String.format("{%s}", gpoId);
    }

    public static String getNewGpoDirName(String rootFolder) throws FileNotFoundException {
        File file = new File(rootFolder);
        String[] names = file.list();
        if (names.length >= 1) {
            for (String name : names) {
                if (new File(rootFolder + "\\" + name).isDirectory()) {
                    return name;
                }
            }
        }
        throw new FileNotFoundException();
        //return string.Empty;
    }

    public static String getNewGpoDirName(String path, String dcName, int dirIndex) throws FileNotFoundException {
        return UNCAccess.findDirectory(path, dcName, dirIndex);
    }

    public static File getNewGpoDirName(File path, int dirIndex) {//ToDo: Change Implementation (Import)//Done
        File newDir = null;
        try {
            newDir = UNCAccess.findDirectory(path, dirIndex);
            if (newDir != null) {
                return newDir;
            }
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format("GpoUtil.getNewGpoDirName() Ex: %s", e));
        }
        return newDir;
    }

    public static String getComputerName(String dcName, String domainName) {
        try {
            /*
            if (dcName.contains(".")) {
                String splitName = dcName.split(domainName, java.util.regex.Pattern.CASE_INSENSITIVE)[0];
                if (splitName.charAt(splitName.length() - 1) == '.') {
                    splitName = splitName.substring(0, splitName.length() - 1);
                    return splitName;
                }
            }*/
            return dcName;
        } catch (Exception e) {
            return dcName;
        }
    }

    public static boolean checkDcDirsPresent(GpoProp gpoProp) {
        try {
            File fileSrc = getRemoteFile(GpoProp.DC_MAIN_DIR + GpoProp.RMP_GPO_UTIL_DIR + GpoProp.GPO_SCRIPT_FILE, gpoProp.dcName);
            if (!fileSrc.exists()) {
                UNCAccess.emptyDirectory(gpoProp.dcMainDir);
                File dirSrc = new File(RmpPaths.RMP_BIN_DIR + GpoProp.RMP_GPO_UTIL_DIR);
                File dirDest = getRemoteFile(GpoProp.DC_MAIN_DIR + GpoProp.RMP_GPO_UTIL_DIR, gpoProp.dcName);
                return UNCAccess.copyDirToRemote(dirSrc, dirDest);
            }
        } catch (Exception e) {
            LogWriter.gpo.severe("copyGpoScript " + e + LogWriter.getStackTrace(e));
        }
        return false;
    }

    public static String getGpoName(Long domainId, String gpoId, BackupObject backupObj, BackupObject oldObj, String dName, Properties prop) {
        try {
            gpoId = gpoId.toUpperCase();
            String oldGpoName = getGpoName(domainId, gpoId);//ToDo: handle - JSONObjectUtil.getValue(oldObj.data, "b" + LdapAttribute.Name.ldapAttributeId).toString();
            if (oldGpoName != null) {
                oldObj.objNam = oldGpoName;
            }
            if (prop.containsKey("displayName")) {
                String objectName = GeneralUtil.getADProperty(prop, "displayName");
                return gpoNameChecker(objectName, oldGpoName, backupObj, gpoId, domainId);
            }
            if (oldGpoName != null && !oldGpoName.equalsIgnoreCase(gpoId)) {
                return oldGpoName;
            }
            Properties domainProp = RMPDomainHandler.getDomainDetailsById(domainId);
            ArrayList properties = new ArrayList<String>();
            properties.add("displayName");
            ArrayList<Properties> gpoProp = ADSNativeHandler.getObjectsWithOutListener(domainProp, dName, properties, "(objectClass=groupPolicyContainer)");
            if (gpoProp.size() != 0) {
                String objectName = GeneralUtil.getADProperty(gpoProp.get(0), "displayName");
                return gpoNameChecker(objectName, oldGpoName, backupObj, gpoId, domainId);
            }
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format("GpoUtil.getGpoName() Ex: %s", e + LogWriter.getStackTrace(e)));
        }
        return gpoId;
    }

    private static String gpoNameChecker(String objectName, String oldGpoName, BackupObject backupObj, String gpoId, Long domainId) {
        if (objectName.contains("DEL:") && objectName.toUpperCase().contains(gpoId)) {
            backupObj.objNam = oldGpoName;
            return oldGpoName == null ? LdapUtil.getObjectAttributeValue(objectName) : oldGpoName;
        } else {
            backupObj.objNam = objectName;
            updateGpoDetails(domainId, gpoId, objectName);
            return objectName;
        }
    }

    public static String getGpoName(Long domainId, String gpoId) {
        Row row = getGpoDetails(domainId, gpoId.toUpperCase());
        if (row != null) {
            Object gpoName = row.get("OBJECT_NAME");
            if (gpoName != null) {
                return gpoName.toString();
            }
        }
        return null;
    }

    public static Row getGpoDetails(Long domainId, String gpoId) {
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_GPO_DETAILS));
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_GPO_DETAILS, "GPO_ID"), gpoId, QueryConstants.EQUAL, false);
            criteria = (new Criteria(Column.getColumn(TableName.RMP_GPO_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL)).and(criteria);
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(TableName.RMP_GPO_DETAILS, "*"));
            DataObject dataObject = DataAccess.get(query);
            if (!dataObject.isEmpty()) {
                Iterator iterator = dataObject.getRows(TableName.RMP_GPO_DETAILS);
                return (Row) iterator.next();
            }
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format("GpoUtil.getGpoDetails() Ex: %s", e + LogWriter.getStackTrace(e)));
        }
        return null;
    }
    
    public static String getGPONameFromAD(Long domainId, String guid, String gpoDN) {
        try {
            Properties domainProp = RMPDomainHandler.getDomainDetailsById(domainId);
            ArrayList properties = new ArrayList<String>();
            properties.add("displayName");
            ArrayList<Properties> gpoProp = ADSNativeHandler.getObjectsWithOutListener(domainProp, gpoDN, properties, "(objectClass=groupPolicyContainer)");
            if (gpoProp.size() != 0) {
                return GeneralUtil.getADProperty(gpoProp.get(0), "displayName");
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        return guid;
    }
    
    public static boolean hasGpoHistory(Long domainId, String gpoId) {
        return getGpoDetails(domainId, gpoId) != null;
    }

    public static void updateGpoDetails(Long domainId, String gpoId, String objectName) {
        try {
            SelectQuery selectQuery = new SelectQueryImpl(new Table(TableName.RMP_GPO_DETAILS));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_GPO_DETAILS, "*"));
            Criteria domainIdCriteria = new Criteria(Column.getColumn(TableName.RMP_GPO_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria objectGuidCriteria = new Criteria(Column.getColumn(TableName.RMP_GPO_DETAILS, "GPO_ID"), gpoId, QueryConstants.EQUAL);
            selectQuery.setCriteria(domainIdCriteria.and(objectGuidCriteria));
            DataObject dataObject = DataAccess.get(selectQuery);
            Persistence per = CommonUtil.getPersistence();
            if (dataObject != null) {
                Iterator iterator = dataObject.getRows(TableName.RMP_GPO_DETAILS);
                if (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    row.set("OBJECT_NAME", objectName);
                    dataObject.updateRow(row);
                } else {
                    Row row = new Row(TableName.RMP_GPO_DETAILS);
                    row.set("DOMAIN_ID", domainId);
                    row.set("GPO_ID", gpoId);
                    row.set("OBJECT_NAME", objectName);
                    dataObject.addRow(row);
                }
            }
            per.update(dataObject);
        } catch (Exception e) {
            LogWriter.gpo.severe(String.format("GpoUtil.updateGpoDetails() Ex: %s", e + LogWriter.getStackTrace(e)));
        }
    }

    public static String getDcGpoMainDirPath(File file) {
        try {
            String filePath = file.getPath();
            filePath = filePath.substring(0, filePath.length() - 2);
            filePath = filePath.substring(filePath.lastIndexOf("/") + 1);
            return GpoProp.DC_MAIN_DIR + "\\" + GpoProp.DC_GPO_BACKUP_DIR + filePath;
        } catch (Exception e) {
            LogWriter.gpo.severe("GpoUtil.getGpoName() Ex: " + e + LogWriter.getStackTrace(e));
        }
        return "";
    }

    public static int getAttributeMask(int attrId) {
        return attrId + (ObjectType.GroupPolicy.id.intValue() - 1) * 256;
    }
    public static Boolean isGPOSetting(Integer objectType, int attrMask){
       return ((objectType == ObjectType.GroupPolicy.id.intValue())  && ((attrMask >= 200 && attrMask <= 5500 )|| attrMask > 8000));
    }
    
    public static void updateSIDPrivelegeRights(JSONObject data, String key, Long domainId) {
        try {
            JSONObject attribData = new JSONObject(data.get(key).toString());
            if(attribData.has("gptType")) {
                String gptType = attribData.get("gptType").toString();
                if(gptType.equalsIgnoreCase("PrivilegeRights")) {
                    String svString = attribData.get("sv").toString();
                    String valueName = attribData.get("valueName").toString();
                    if(valueName != null || !valueName.isEmpty())
                    {
                        String valueNames[] = valueName.split(",");
                        ArrayList<String> sids = new ArrayList();
                        for(String value : valueNames) {
                            if(!value.isEmpty() && value.charAt(0) == '*') {
                                sids.add(value.substring(1).toLowerCase());
                            }
                        }
                        SelectQuery selectVerAndCur = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId));
                        Join join = new Join(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, new String[]{"LINK_ID"}, new String[]{"LINK_ID"}, Join.LEFT_JOIN);
                        selectVerAndCur.addJoin(join);
                        selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "OBJECT_SID"));
                        selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "OBJECT_NAME"));
                        selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "LINK_ID"));
                        Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_SID"), sids.toArray(new String[sids.size()]) , QueryConstants.IN, false);
                        selectVerAndCur.setCriteria(criteria);
                        DataObject dobj = CommonUtil.getPersistence().get(selectVerAndCur);
                        if(!dobj.isEmpty()) {
                            Iterator itr = dobj.getRows(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId);
                            while(itr.hasNext()) {
                                Row row = (Row) itr.next();
                                if(row.get("OBJECT_SID") != null) {
                                    String objectSid = (String) row.get("OBJECT_SID");
                                    String objName = (String) row.get("OBJECT_NAME");
                                    if(!objectSid.isEmpty()) {
                                        objectSid = "*" + objectSid;
                                        if(svString.contains(objectSid)) {
                                            svString = svString.replace(objectSid, objName);
                                        }
                                        if(valueName.contains(objectSid)) {
                                            valueName = valueName.replace(objectSid, objName);
                                        }
                                    }
                                }
                            }
                            attribData.put("sv", svString);
                            attribData.put("valueName", valueName);
                            data.put(key, attribData.toString());
                        }
                    }
                }
            }
        } catch(Exception e) {
            LogWriter.general.severe("restore.updateSIDPrivelegeRights  " + e);
            e.printStackTrace();
        }
    }
    
    public static boolean toBackupEntry(HashMap<Integer, ArrayList<PolEntryConcise>> multivalPolicies, boolean toPreserve, int attributeMaskIndex) {
        return !toPreserve || (toPreserve && multivalPolicies.containsKey(attributeMaskIndex));
    }
    
    public static void updateFailedGPO(Long domainId, String gpoId, String gpoName, String distinguishedName, String error, long errorCode){
        try{
            Persistence per = CommonUtil.getPersistence();
            DataObject dobj;
            //int errorCode = GpoErrors.valueOf(error).errorId;
            Criteria criteria = new Criteria(Column.getColumn(TableName.GPO_ERROR_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            criteria = criteria.and(new Criteria(Column.getColumn(TableName.GPO_ERROR_DETAILS, "OBJECT_GUID"), gpoId, QueryConstants.EQUAL));
            dobj = per.get(TableName.GPO_ERROR_DETAILS, criteria);
            if(errorCode == 0L){
                if(!dobj.isEmpty()){
                    Row existingRow = dobj.getFirstRow(TableName.GPO_ERROR_DETAILS);
                    dobj.deleteRow(existingRow);
                    per.update(dobj);
                }
            }
            else if (errorCode != 0L && !dobj.isEmpty()){
                Row updRow = dobj.getFirstRow(TableName.GPO_ERROR_DETAILS);
                String err = updRow.get("ERROR").toString();
                if(!err.equals(error)){
                    updRow.set("ERROR", error);
                    dobj.updateRow(updRow);
                    per.update(dobj);
                }
            }
            else {
                DataObject dObj1 = new WritableDataObject();
                Row row = new Row(TableName.GPO_ERROR_DETAILS); // No I18N
                row.set("DOMAIN_ID", domainId); // No I18N
                row.set("OBJECT_GUID", gpoId); // No I18N
                row.set("OBJECT_NAME", gpoName); // No I18N
                row.set("DISTINGUISHED_NAME", distinguishedName); // No I18N
                row.set("ERROR", error); // No I18N
                dObj1.addRow(row);
                per.add(dObj1);
            }
        }
        catch(Exception e){
            LogWriter.general.severe("Backup failed GPO update" + e);
            e.printStackTrace();
        }
    }
    
    public static DataObject getFailedGPOs(Long domainId){
        try{
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.GPO_ERROR_DETAILS));
            Criteria criteria = new Criteria(Column.getColumn(TableName.GPO_ERROR_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            query.addSelectColumn(Column.getColumn(TableName.GPO_ERROR_DETAILS, "*"));
            query.setCriteria(criteria);
            return CommonUtil.getPersistence().get(query);
        }
        catch(Exception e){
            LogWriter.general.severe("Get backup failed GPO" + e);
            e.printStackTrace();
        }
        return null;
    }
}

//ignoreI18n_end
