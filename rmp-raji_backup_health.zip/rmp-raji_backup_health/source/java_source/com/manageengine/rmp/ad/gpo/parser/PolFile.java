/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.parser;

import com.manageengine.rmp.ad.gpo.constants.GpoAddRem;
import com.manageengine.rmp.ad.gpo.constants.GpoConfigType;
import com.manageengine.rmp.ad.gpo.constants.GpoFileType;
import com.manageengine.rmp.ad.gpo.constants.PolEntryParseState;
import com.manageengine.rmp.ad.gpo.constants.PolEntryType;
import com.manageengine.rmp.ad.gpo.manager.GpoUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.util.BitConverter;
import com.manageengine.rmp.util.DataTypeUtil;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.commons.lang.ArrayUtils;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class PolFile extends GpoFile {

    private static final int POL_HEADER = 0x50526567;
    private static final int POL_VERSION = 0x01000000;
    private HashMap<String, AbstractGpoEntry> entriesHash;

    @Override
    public java.util.ArrayList<AbstractGpoEntry> getEntries() {
        ArrayList<AbstractGpoEntry> gpoEntry = new ArrayList<AbstractGpoEntry>(entriesHash.values());
        return gpoEntry;
    }
    private String fileName;
    
    @Override
    public String getFileName() {
        return fileName;
    }

    @Override
    public void setFileName(String value) {
        fileName = value;
    }

    public PolFile() {
        this.fileName = "";
        this.entriesHash = new HashMap<String, AbstractGpoEntry>();
    }

    @Override
    public void setValue(AbstractGpoEntry gpoEntry) {
        entriesHash.put(gpoEntry.keyName.toUpperCase() + "\\" + gpoEntry.valueName.toUpperCase(), (PolEntry) gpoEntry);
    }

    public void setStringValue(String key, String value, String data) {
        this.setStringValue(key, value, data, false);
    }

    public void setStringValue(String key, String value, String data, boolean bExpand) {
        PolEntry pe = new PolEntry();
        pe.keyName = key;
        pe.valueName = value;

        if (bExpand) {
            pe.setExpandStringValue(data);
        } else {
            pe.stringValue = data;
        }

        this.setValue(pe);
    }

    public void setDWORDValue(String key, String value, long data) {
        this.setDWORDValue(key, value, data, true);
    }

    public void setDWORDValue(String key, String value, long data, boolean bLittleEndian) {
        PolEntry pe = new PolEntry();
        pe.keyName = key;
        pe.valueName = value;

        if (bLittleEndian) {
            pe.dWORDValue = data;
        } else {
            pe.setDWORDBigEndianValue(data);
        }

        this.setValue(pe);
    }

    public int qWORDValue;

    public void setQWORDValue(String key, String value, Long data) {
        PolEntry pe = new PolEntry();
        pe.keyName = key;
        pe.valueName = value;
        pe.qWORDValue = data;
        this.setValue(pe);
    }

    public void setMultiStringValue(String key, String value, String[] data) {
        PolEntry pe = new PolEntry();
        pe.keyName = key;
        pe.valueName = value;
        pe.multiStringValue = data;
        this.setValue(pe);
    }

    public void setBinaryValue(String key, String value, byte[] data) {
        PolEntry pe = new PolEntry();
        pe.keyName = key;
        pe.valueName = value;
        pe.binaryValue = data;
        this.setValue(pe);
    }

    public AbstractGpoEntry getValue(String key, String value) {
        AbstractGpoEntry gpoEntry = null;
        try {
            gpoEntry = this.entriesHash.get(key.toUpperCase() + "\\" + value.toUpperCase());
        } catch (Exception ex) {
        }
        return gpoEntry;
    }

    @Override
    public AbstractGpoEntry getValue(AbstractGpoEntry gpoEntry) {
        return this.getValue(gpoEntry.keyName, gpoEntry.valueName);
    }

    public String getStringValue(String key, String value) {
        PolEntry pe = (PolEntry) this.getValue(key, value);
        if (pe == null) {
            return "";
        }
        return pe.stringValue;
    }

    //public String[] GetMultiStringValue(String key, String value)
    //{
    //    PolEntry pe = this.GetValue(key, value);
    //    if (pe == null) { throw new IllegalArgumentException(); }
    //    return pe.multiStringValue;
    //}
    //public uint GetDWORDValue(String key, String value)
    //{
    //    PolEntry pe = this.GetValue(key, value);
    //    if (pe == null) { throw new IllegalArgumentException(); }
    //    return pe.DWORDValue;
    //}
    //public ulong GetQWORDValue(String key, String value)
    //{
    //    PolEntry pe = this.GetValue(key, value);
    //    if (pe == null) { throw new IllegalArgumentException(); }
    //    return pe.qWORDValue;
    //}
    //public byte[] GetBinaryValue(String key, String value)
    //{
    //    PolEntry pe = this.GetValue(key, value);
    //    if (pe == null) { throw new IllegalArgumentException(); }
    //    return pe.binaryValue;
    //}
    public boolean contains(String key, String value) {
        return (this.getValue(key, value) != null);
    }

    @Override
    public boolean contains(AbstractGpoEntry gpoEntry) {
        return contains(gpoEntry.keyName, gpoEntry.valueName);
    }

    public boolean contains(String key, String value, PolEntryType type) {
        PolEntry pe = (PolEntry) this.getValue(key, value);
        return (pe != null && pe.type == type);
    }

    public PolEntryType getValueType(String key, String value) {
        PolEntry pe = (PolEntry) this.getValue(key, value);
        if (pe == null) {
            throw new IllegalArgumentException();
        }
        return pe.type;
    }

    public String GetStringValue(PolEntry polEntry) {
        try {
            return polEntry.stringValue;
        } catch (Exception e) {
            return "";
        }
    }
    
    public void deleteValue(String propertyName) {
        propertyName = propertyName.substring(5).replace("!", "\\").toUpperCase();
        if (this.entriesHash.containsKey(propertyName) == true) {
            this.entriesHash.remove(propertyName);
        }
         else{
            propertyName = propertyName + "\\";
            Iterator entriesIter = this.entriesHash.keySet().iterator();
            ArrayList<String> entriesArray = new ArrayList<String>();
            while(entriesIter.hasNext()) {
                String entryKey = (String) entriesIter.next();
                if(entryKey.contains(propertyName.toUpperCase())) {
                    entriesArray.add(entryKey);
                }
            }
            for(int i=0; i < entriesArray.size(); i++) {
                this.entriesHash.remove(entriesArray.get(i));
            }
        }
    }

    public void deleteValue(String key, String value) {
        String keyStr = key.toUpperCase() + "\\" + value.toUpperCase();
        if (this.entriesHash.containsKey(keyStr) == true) {
            this.entriesHash.remove(keyStr);
        }
    }

    @Override
    public void deleteValue(AbstractGpoEntry gpoEntry) {
        PolFile.this.deleteValue(gpoEntry.keyName, gpoEntry.valueName);
    }

    public void LoadFile(GpoConfigType gpType) throws IOException {
        this.loadFile(null, gpType);
    }

    public void loadFile(String file, GpoConfigType gpType) throws IOException {
        FileInputStream fileInputStream = null;
        try {
            if (!(file == null || file.isEmpty())) {
                this.fileName = file;
            }
            byte[] bytes = null;
            int nBytes = 0;
            File polFile = new File(this.fileName);
            if (polFile.exists()) {
                try {
                    nBytes = (int) polFile.length();
                    bytes = new byte[nBytes];
                    fileInputStream = new FileInputStream(polFile);
                    fileInputStream.read(bytes);
                    fileInputStream.close();
                } catch (Exception e) {
                    LogWriter.gpo.severe("PolFile load : %s" + e + LogWriter.getStackTrace(e));//NO I18N
                }
                // registry.pol files are an 8-byte fixed header followed by some number of entries in the following format:
                // [KeyName;ValueName;<type>;<size>;<data>]
                // The brackets, semicolons, KeyName and ValueName are little-endian Unicode text.
                // type and size are 4-byte little-endian unsigned integers.  Size cannot be greater than 0xFFFF, even though it's
                // stored as a 32-bit number.  type will be one of the values REG_SZ, etc as defined in the Win32 API.
                // Data will be the number of bytes indicated by size.  The next 2 bytes afterward must be unicode "]".
                // 
                // All Strings (KeyName, ValueName, and data when type is REG_SZ or REG_EXPAND_SZ) are terminated by a single
                // null character.
                //
                // Multi Strings are Strings separated by a single null character, with the whole list terminated by a double null.
                if (nBytes < 8) {
                    throw new IllegalArgumentException();
                }

                int header = ((bytes[0] & 0xFF) << 24) | ((bytes[1] & 0xFF) << 16) | ((bytes[2] & 0xFF) << 8) | (bytes[3] & 0xFF);
                int version = ((bytes[4] & 0xFF) << 24) | ((bytes[5] & 0xFF) << 16) | ((bytes[6] & 0xFF) << 8) | (bytes[7] & 0xFF);

                if (header != PolFile.POL_HEADER || version != PolFile.POL_VERSION) {
                    throw new IllegalArgumentException();
                }

                PolEntryParseState parseState = PolEntryParseState.Start;
                int i = 8;

                StringBuilder keyName = new StringBuilder(50);
                StringBuilder valueName = new StringBuilder(50);
                long type = 0;
                int size = 0;

                while (i < (nBytes - 1)) {
                    char[] curChar = DataTypeUtil.getCharsFromBytes(bytes, "UTF-8", i, 2);//No I18N

                    switch (parseState) {
                        case Start:
                            if (curChar[0] != '[') {
                                throw new IllegalArgumentException();
                            }
                            i += 2;
                            parseState = PolEntryParseState.Key;
                            continue;
                        case Key:
                            if (curChar[0] == '\0') {
                                if (i > (nBytes - 4)) {
                                    throw new IllegalArgumentException();
                                }
                                curChar = DataTypeUtil.getCharsFromBytes(bytes, "UTF-8", i + 2, 2);//No I18N
                                if (curChar[0] != ';') {
                                    throw new IllegalArgumentException();
                                }

                                // We've reached the end of the key name.  Switch to parsing value name.
                                i += 4;
                                parseState = PolEntryParseState.ValueName;
                            } else {
                                keyName.append(curChar[0]);
                                i += 2;
                            }
                            continue;
                        case ValueName:
                            if (curChar[0] == '\0') {
                                if (i > (nBytes - 16)) {
                                    throw new IllegalArgumentException();
                                }
                                curChar = DataTypeUtil.getCharsFromBytes(bytes, "UTF-8", i + 2, 2);//No I18N
                                if (curChar[0] != ';') {
                                    throw new IllegalArgumentException();
                                }

                                // We've reached the end of the value name.  Now read in the type and size fields, and the data bytes
                                type = (int) (((bytes[i + 7]& 0xFF) << 24) | ((bytes[i + 6] & 0xFF) << 16) | ((bytes[i + 5] & 0xFF) << 8) | (bytes[i + 4] & 0xFF));
                                if (!PolEntryType.isEnum(type)) {
                                    throw new IllegalArgumentException();
                                }

                                curChar = DataTypeUtil.getCharsFromBytes(bytes, "UTF-8", i + 8, 2);//No I18N
                                if (curChar[0] != ';') {
                                    throw new IllegalArgumentException();
                                }
                                size=((bytes[i + 13] & 0xFF) << 24) | ((bytes[i + 12] & 0xFF) << 16) | ((bytes[i + 11] & 0xFF) << 8) | (bytes[i + 10] & 0xFF);
                                if ((size > 0xFFFF) || (size < 0)) {
                                    throw new IllegalArgumentException();
                                    
                                }

                                curChar = DataTypeUtil.getCharsFromBytes(bytes, "UTF-8", i + 14, 2);//No I18N
                                if (curChar[0] != ';') {
                                    throw new IllegalArgumentException();
                                }

                                i += 16;

                                if (i > (nBytes - (size + 2))) {
                                    throw new IllegalArgumentException();
                                }
                                curChar = DataTypeUtil.getCharsFromBytes(bytes, "UTF-8", i + size, 2);//No I18N
                                if (curChar[0] != ']') {
                                    throw new IllegalArgumentException();
                                }

                                PolEntry pe = new PolEntry();
                                pe.keyName = keyName.toString();
                                pe.valueName = valueName.toString();
                                if (pe.valueName.contains(GpoUtil.appendVN)) {
                                    pe.valueName = pe.valueName.replace(GpoUtil.appendVN, "");
                                    pe.appendVN = GpoUtil.appendVN;
                                } else if (pe.valueName.contains(GpoUtil.appendVNs)) {
                                    pe.valueName = pe.valueName.replace(GpoUtil.appendVNs, "");
                                    pe.appendVN = GpoUtil.appendVNs;
                                }
                                pe.gpoAddRem = GpoAddRem.Add;
                                pe.gpoUserMach = gpType;
                                pe.type = PolEntryType.getType(type);

                                pe.createDataBytes();
                                for (int j = 0; j < size; j++) {
                                    //pe.getDataBytes().add(bytes[i + j]);
                                    pe.dataBytes.add(bytes[i + j]);
                                }
                                pe.stringValue = pe.getStringValue();
                                this.setValue(pe);

                                i += size + 2;

                                keyName.setLength(0);
                                valueName.setLength(0);
                                parseState = PolEntryParseState.Start;
                            } else {
                                valueName.append(curChar[0]);
                                i += 2;
                            }
                            continue;
                        default:
                            throw new Exception("Unreachable code");
                    }
                }

            } //log else
        } catch (Exception e) {
            LogWriter.gpo.severe("PolFile load : %s" + e + LogWriter.getStackTrace(e));//NO I18N
        } finally {
            if (fileInputStream != null) {
                fileInputStream.close();
            }
        }
    }

    public void saveFile() throws IOException {
        this.saveFile("");
    }

    public void saveFile(String file) throws IOException {
        FileOutputStream fStream = null;
        try {
            if (!(file.isEmpty())) {
                this.fileName = file;
            }
            // Because we maintain the byte array for each PolEntry in memory, writing back to the file
            // is a simple operation, creating entries of the format:
            // [KeyName;ValueName;type;size;data] after the fixed 8-byte header.
            // The only things we must do are add null terminators to KeyName and ValueName, which are
            // represented by C# Strings in memory, and make sure Size and Type are written in little-endian
            // byte order.
            File polFile = new File(this.fileName);
            fStream = new FileOutputStream(fileName);
            if (this.entriesHash.size() > 0) {
                if (!polFile.exists()) {
                    polFile.createNewFile();
                }
                fStream.write(new byte[]{0x50, 0x52, 0x65, 0x67, 0x01, 0x00, 0x00, 0x00}, 0, 8);
                writeFile(fStream, this.entriesHash.values());
                fStream.close();
            } else {
                if (polFile.exists()) {
                    fStream.write(new byte[]{0x50, 0x52, 0x65, 0x67, 0x01, 0x00, 0x00, 0x00}, 0, 8);
                }
                //AgentLogger.Gpo.Info("Gpo Restore Save File " + file + " No entries to write");
            }
        } catch (Exception e) {
            LogWriter.gpo.severe("PolFile save : %s" + e + LogWriter.getStackTrace(e));//NO I18N
        } finally {
            if (fStream != null) {
                fStream.close();
            }
        }
    }

    public static void writeFile(FileOutputStream fileStream, Collection<AbstractGpoEntry> entries) {
        try {
            byte[] openBracket = BitConverter.getUnicodeBytes("[");
            byte[] closeBracket = BitConverter.getUnicodeBytes("]");
            byte[] semicolon = BitConverter.getUnicodeBytes(";");
            byte[] nullChar = new byte[]{0, 0};

            byte[] bytes;
            for (AbstractGpoEntry peEntry : entries) {
                PolEntry pe = (PolEntry) peEntry;
                fileStream.write(openBracket, 0, 2);
                bytes = BitConverter.getUnicodeBytes(pe.keyName);//No I18N
                fileStream.write(bytes, 0, bytes.length);
                fileStream.write(nullChar, 0, 2);

                fileStream.write(semicolon, 0, 2);
                bytes = BitConverter.getUnicodeBytes(pe.appendVN + pe.valueName);//No I18N
                fileStream.write(bytes, 0, bytes.length);
                fileStream.write(nullChar, 0, 2);

                fileStream.write(semicolon, 0, 2);
                bytes = BitConverter.getBytes(pe.type.polId.intValue());
                if (DataTypeUtil.isBigEndian() == false) {
                    ArrayUtils.reverse(bytes);
                }
                fileStream.write(bytes, 0, 4);

                fileStream.write(semicolon, 0, 2);
                byte[] data = DataTypeUtil.arrayListToByteArray(pe.byteList);
                bytes = BitConverter.getBytes(data.length);
                if (DataTypeUtil.isBigEndian() == false) {
                    ArrayUtils.reverse(bytes);
                }
                fileStream.write(bytes, 0, 4);

                fileStream.write(semicolon, 0, 2);
                fileStream.write(data, 0, data.length);
                fileStream.write(closeBracket, 0, 2);
            }
        } catch (Exception ex) {
            LogWriter.gpo.severe("PolFile writer : %s" + ex + LogWriter.getStackTrace(ex));//NO I18N
        }
    }

    public PolEntryConcise getOldValue(PolEntry polEntry) {
        PolEntry polEntryOld = (PolEntry) this.getValue(polEntry.keyName, polEntry.valueName);
        if (polEntry != null) {
            PolEntryConcise polEntryCouch = new PolEntryConcise(polEntryOld);
            return polEntryCouch;
        } else {
            return new PolEntryConcise();
        }
    }

    public PolEntryConcise getOldValue(String propertyName) {
        try {
            propertyName = propertyName.substring(5);
            String[] keys = new String[2];
            keys[0] = propertyName.substring(0, propertyName.lastIndexOf("!"));
            keys[1] = propertyName.substring(propertyName.lastIndexOf("!") + 1);
            PolEntry polTemp = new PolEntry();
            polTemp.keyName = keys[0];
            polTemp.valueName = keys[1];
            return getOldValue(polTemp);
        } catch (Exception tx) {
            return new PolEntryConcise();
        }
    }

    @Override
    public GpoFileType getType() {
        return GpoFileType.Pol;
    }

    @Override
    public Object fillPolicies(String rootFolder, GpoConfigType gpoUserMach, GpoFileType gpoFileType, String domainName, String dcName, String adminName, String password) {
        return fillPolicies(new File(rootFolder), gpoUserMach, gpoFileType, domainName, dcName, adminName, password);
    }

    @Override
    public Object fillPolicies(File rootFolder, GpoConfigType gpoUserMach, GpoFileType gpoFileType, String domainName, String dcName, String adminName, String password) {
        try {
            if (rootFolder != null) {
                String filePath = "";
                String pathType = gpoUserMach == GpoConfigType.Machine ? "Machine" : "User";//No I18N
                filePath = rootFolder.getPath() + "\\DomainSysvol\\GPO\\" + pathType + "\\registry.pol";//No I18N
                PolFile polFile = new PolFile();
                polFile.loadFile(filePath, gpoUserMach);
                return polFile;
            }
        } catch (Exception e) {
            LogWriter.gpo.severe("PolFile Read : " + e + LogWriter.getStackTrace(e));
        }
        return new PolFile();
    }
}

//ignoreI18n_end
