/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.adsync;

import com.manageengine.ads.fw.domain.ADSDomainHandler;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.util.RMPDomainHandler;
import org.json.JSONObject;

/**
 *
 * $Id$ @author lucky-2306
 */
//ignoreI18n_start
public enum BaseDNPrepender {

    DefaultNamingContext(""),
    DomainDNSNode("DC=DomainDnsZones,"),
    ForestDNSNode("DC=ForestDnsZones,"),
    DomainDNSZone("DC=DomainDnsZones,"),
    ForestDNSZone("DC=ForestDnsZones,"),
    SiteGPLinks("CN=Configuration,");
    public String baseDNString;

    BaseDNPrepender(String baseDNString) {
        this.baseDNString = baseDNString;
    }

    public boolean isForestBase() {
        if (this == ForestDNSNode || this == ForestDNSZone || this == SiteGPLinks) {
            return true;
        }
        return false;
    }
	 
    public static BaseDNPrepender getBaseDNPrepender(int objectType) {
        switch (objectType) {
            case 8:
                return BaseDNPrepender.DomainDNSNode;
            case 9:
                return BaseDNPrepender.ForestDNSNode;
            case 10:
                return BaseDNPrepender.DomainDNSZone;
            case 11:
                return BaseDNPrepender.ForestDNSZone;
            case 13:
            case 15:
                return BaseDNPrepender.SiteGPLinks;
            default:
                return BaseDNPrepender.DefaultNamingContext;
        }
    }

    public static String getBaseDN(Long domainId, long objectID, BaseDNPrepender baseDN) {
        String baseDNString = null;
        try {
            baseDNString = baseDN.baseDNString;
            JSONObject domainDetails = ADSDomainHandler.getDomainDetailsFromID(domainId);
	    if (baseDN.isForestBase()) {
                String forestID = domainDetails.get("FOREST_ID").toString();
                JSONObject forestDetails = RMPDomainHandler.getForestDetailsFromID(forestID);
		if (baseDN.baseDNString.equalsIgnoreCase("DC=ForestDnsZones,")) {
                    if (forestDetails.has("FOREST_DNS_ZONES")) {
                        baseDNString = forestDetails.get("FOREST_DNS_ZONES").toString();
                    } else if(forestDetails.has("ROOT_DOMAIN_NAMING_CONTEXT")){
                        baseDNString += forestDetails.get("ROOT_DOMAIN_NAMING_CONTEXT").toString();
                    }
		    else{
			baseDNString += domainDetails.get("DEFAULT_NAMING_CONTEXT").toString();
		    }
                } else if(baseDN.baseDNString.equalsIgnoreCase("CN=Configuration,")){
			if(forestDetails.has("CONFIGURATION_NAMING_CONTEXT")){
				baseDNString = forestDetails.get("CONFIGURATION_NAMING_CONTEXT").toString();
			}
			else if(forestDetails.has("ROOT_DOMAIN_NAMING_CONTEXT")){
				baseDNString += forestDetails.get("ROOT_DOMAIN_NAMING_CONTEXT").toString();
			}
			else{
				baseDNString += domainDetails.get("DEFAULT_NAMING_CONTEXT").toString();
			}
		} else if (forestDetails.has("FOREST_DN")) {
                    baseDNString += forestDetails.get("FOREST_DN").toString();
                } else {
                    baseDNString += domainDetails.get("DEFAULT_NAMING_CONTEXT").toString();
                }
            } else {
                baseDNString += domainDetails.get("DEFAULT_NAMING_CONTEXT").toString();
            }
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncObjects getBaseDN: " + e);
        }
        return baseDNString;
    }
}
//ignoreI18n_end
