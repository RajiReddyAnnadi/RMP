/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.adsync;

import java.util.ArrayList;

/**
 * $Id$
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public enum SyncFilter {

    rangedAttr(1),
    bitlocker(2),
    user(3),
    computer(4),
    contact(5),
    group(6),
    organizationalunit(7),
    DnsNode_Domain(8),
    DnsNode_Forest(9),
    DnsZone_Forest(10),
    DnsZone_Domain(11),
    grouppolicy(12),
    site(13),
    ouGPLinksAttr(14),
    siteGPLinksAttr(15),
    dynamicDistributionGroup(16),

    primaryGroupAttr(17),
    DNSNode_2000(18),
    DNSZone_2000(19);

    public Integer filterId;
    public static final Integer CUSTOM_ATTR_OFFSET = 100;
    public static final Integer DOMAIN_ID_OFFSET = 1000;
    public static final String CUSTOM_SYNC_PREPENDER = "custom_";

    SyncFilter(Integer filterId) {
        this.filterId = filterId;
    }

    public static ArrayList<Integer> getSyncObjectType(Integer objType) {
        ArrayList<Integer> syncObjectTypes = new ArrayList<Integer>();
        switch (objType) {
            case 0:
                syncObjectTypes.add(rangedAttr.filterId);
                syncObjectTypes.add(bitlocker.filterId);
                syncObjectTypes.add(ouGPLinksAttr.filterId);
                syncObjectTypes.add(siteGPLinksAttr.filterId);
                syncObjectTypes.add(primaryGroupAttr.filterId);
                break;
            case 1:
                syncObjectTypes.add(user.filterId);
                break;
            case 2:
                syncObjectTypes.add(computer.filterId);
                break;
            case 3:
                syncObjectTypes.add(contact.filterId);
                break;
            case 4:
                syncObjectTypes.add(group.filterId);
                break;
            case 5:
                syncObjectTypes.add(organizationalunit.filterId);
                break;
            case 6:
                syncObjectTypes.add(DnsNode_Domain.filterId);
                syncObjectTypes.add(DnsNode_Forest.filterId);
                syncObjectTypes.add(DNSNode_2000.filterId);
                break;
            case 7:
                syncObjectTypes.add(DnsZone_Domain.filterId);
                syncObjectTypes.add(DnsZone_Forest.filterId);
                syncObjectTypes.add(DNSZone_2000.filterId);
                break;
            case 8:
                syncObjectTypes.add(grouppolicy.filterId);
                break;
            case 9:
                syncObjectTypes.add(site.filterId);
                break; 
            case 10:
                syncObjectTypes.add(dynamicDistributionGroup.filterId);
                break;

               
        }
        return syncObjectTypes;
    }

    public static Integer getObjectType(Integer objectType) {
        switch (objectType) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                return (objectType + 2);
            case 7:
                return (objectType + 3);
            case 8:
                return (objectType + 4);
            case 9:
                return (objectType + 4);
            case 10:
                return (objectType + 6);

            default:
                return 0;
        }
    }

    public static String[] getSyncObjects() {
        return new String[]{
            SyncFilter.rangedAttr.name(),
            SyncFilter.bitlocker.name(),
            SyncFilter.user.name(),
            SyncFilter.computer.name(),
            SyncFilter.contact.name(),
            SyncFilter.group.name(),
            SyncFilter.organizationalunit.name(),
            "dnsNode",
            "dnsZone",
            SyncFilter.grouppolicy.name(),
            SyncFilter.site.name(),
            SyncFilter.ouGPLinksAttr.name(),
            SyncFilter.siteGPLinksAttr.name(),
            SyncFilter.dynamicDistributionGroup.name(),

            SyncFilter.primaryGroupAttr.name()
        };
    }

    public static String[] getCustomSyncObjects() {
        return new String[]{
            CUSTOM_SYNC_PREPENDER + SyncFilter.rangedAttr.name(),
            CUSTOM_SYNC_PREPENDER + SyncFilter.bitlocker.name(),
            CUSTOM_SYNC_PREPENDER + SyncFilter.user.name(),
            CUSTOM_SYNC_PREPENDER + SyncFilter.computer.name(),
            CUSTOM_SYNC_PREPENDER + SyncFilter.contact.name(),
            CUSTOM_SYNC_PREPENDER + SyncFilter.group.name(),
            CUSTOM_SYNC_PREPENDER + SyncFilter.organizationalunit.name(),
            CUSTOM_SYNC_PREPENDER + "dnsNode",
            CUSTOM_SYNC_PREPENDER + "dnsZone",
            CUSTOM_SYNC_PREPENDER + SyncFilter.grouppolicy.name(),
            CUSTOM_SYNC_PREPENDER + SyncFilter.site.name(),
            CUSTOM_SYNC_PREPENDER + SyncFilter.ouGPLinksAttr.name(),
            CUSTOM_SYNC_PREPENDER + SyncFilter.siteGPLinksAttr.name(),
            CUSTOM_SYNC_PREPENDER + SyncFilter.dynamicDistributionGroup.name()
        };
    }
}
//ignoreI18n_end
