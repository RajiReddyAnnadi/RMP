//$Id$
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.adsync;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.manageengine.ads.fw.domain.ADSDomainHandler;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.ad.backup.BackupUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.util.RMPDomainHandler;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import org.json.JSONObject;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class ADSyncObjectsConfig {

    public static final String TABLE = "ADSADSyncObjects";

    public static void deleteSyncConfigRow(long objectID) {
        deleteSyncConfigRow(objectID, "OBJECT_ID");
    }

    public static void deleteSyncConfigRows(ArrayList<Long> objectID) {
        deleteSyncConfigRows(objectID, "OBJECT_ID");
    }

    public static void deleteSyncConfigRow(long columnID, String columnName) {
        try {
            Persistence per = CommonUtil.getPersistence();
            DataObject delrow = per.get(TABLE, (Criteria) null);
            Criteria criteria = new Criteria(Column.getColumn(TABLE, columnName), columnID, QueryConstants.EQUAL);
            delrow.deleteRows(TABLE, criteria);
            per.update(delrow);
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncObjects : " + e + LogWriter.getStackTrace(e));
        }
    }

    public static void deleteSyncConfigRows(ArrayList<Long> columnIDs, String columnName) {
        try {
            Persistence per = CommonUtil.getPersistence();
            DataObject delrow = per.get(TABLE, (Criteria) null);
            Criteria criteria = new Criteria(Column.getColumn(TABLE, columnName), columnIDs, QueryConstants.CONTAINS);
            delrow.deleteRows(TABLE, criteria);
            per.update(delrow);
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncObjects : " + e + LogWriter.getStackTrace(e));
        }
    }

    public static Row getSyncConfigRow(Long objectId, Long domainId) {
        try {
            SelectQuery hasRowQuery = new SelectQueryImpl(Table.getTable(TABLE));
            hasRowQuery.addSelectColumn(Column.getColumn(TABLE, "*"));
            Criteria domainIdCriteria = new Criteria(Column.getColumn(TABLE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria objectIdCriteria = new Criteria(Column.getColumn(TABLE, "OBJECT_ID"), objectId, QueryConstants.EQUAL);
            hasRowQuery.setCriteria(domainIdCriteria.and(objectIdCriteria));

            DataObject dataObject = CommonUtil.getPersistence().get(hasRowQuery);
            Iterator iterator = dataObject.getRows(TABLE);
            if (iterator.hasNext()) {
                return (Row) iterator.next();
            }
        } catch (Exception e) {

        }
        return null;
    }

    public static void addSyncConfigRow(long objectID, String objectType, String searchString, String baseDN, boolean isEnabled, long priorityID, long searchPref) {
        addSyncConfigRow(objectID, -1L, objectType, searchString, baseDN, isEnabled, priorityID, searchPref);
    }

    public static boolean addSyncConfigRow(long objectID, long domainId, String objectType, String searchString, String baseDN, boolean isEnabled, long priorityID, long searchPref) {
        try {
            Persistence per = CommonUtil.getPersistence();
            Row row = new Row(TABLE);
            row.set("OBJECT_ID", objectID);
            row.set("DOMAIN_ID", domainId);
            row.set("OBJECT_TYPE", objectType);
            row.set("SEARCH_STRING", searchString);
            row.set("IS_ENABLED", isEnabled);
            row.set("BASE_DN", baseDN);
            row.set("PRIORITY_ID", priorityID);
            row.set("SEARCH_PREFERENCE", searchPref);
            DataObject addrow = new WritableDataObject();
            addrow.addRow(row);
            per.add(addrow);
            return true;
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncObjects : " + e + LogWriter.getStackTrace(e));
        }
        return false;
    }

    public static boolean addSyncConfigRow(long domainId, long objectID, String objectType, String searchString, BaseDNPrepender baseDN, boolean isEnabled, long priorityID, long searchPref) {
        try {
            String baseDNString = BaseDNPrepender.getBaseDN(domainId, objectID, baseDN);
            if (baseDNString != null) {
                return addSyncConfigRow(objectID, domainId, objectType, searchString, baseDNString, isEnabled, priorityID, searchPref);
            } else {
                LogWriter.general.info("Base DN is empty . . .");
            }
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncObjects : " + e);
        }
        return false;
    }

    public static boolean addCustomAttributesSyncRows(ArrayList<Long> objectIds, int objectType, String ldapName) {
        try {
            DataObject addObjectRow = new WritableDataObject();
            DataObject addAttrRow = new WritableDataObject();
            for (int i = 0; i < objectIds.size(); i++) {
                Long domainId = objectIds.get(i) / SyncFilter.DOMAIN_ID_OFFSET;
                if (BackupUtil.getBackupStat(domainId) == null) {
                    objectIds.set(i, objectIds.get(i) - SyncFilter.CUSTOM_ATTR_OFFSET);
                    continue;
                }
                String oldSearchString = getSearchString(objectIds.get(i));
                String attrQueryString = String.format("(%s=*)",ldapName);
                if (oldSearchString!=null) {
                    StringBuffer stringBuffer = new StringBuffer(oldSearchString);
                    stringBuffer.insert(oldSearchString.length()-2, attrQueryString);
                    UpdateQuery updateQuery = new UpdateQueryImpl(TABLE);
                    updateQuery.setUpdateColumn("SEARCH_STRING", stringBuffer.toString());
                    Criteria objIdCriteria = new Criteria(Column.getColumn(TABLE, "OBJECT_ID"), objectIds.get(i), QueryConstants.EQUAL);
                    updateQuery.setCriteria(objIdCriteria);
                    CommonUtil.getPersistence().update(updateQuery);
                    continue;
                }
                int syncObjectType = SyncFilter.getObjectType(objectType);
                Properties objectSyncRow = RMPADSyncConfig.getRMPSyncObjectRow(syncObjectType);
                Row row = new Row(TABLE);
                JSONObject domainDetails = ADSDomainHandler.getDomainDetailsFromID(domainId);
                row.set("OBJECT_ID", objectIds.get(i));
                row.set("DOMAIN_ID", domainId);
                row.set("OBJECT_TYPE", SyncFilter.CUSTOM_SYNC_PREPENDER + objectSyncRow.get("OBJECT_TYPE"));
                String searchString = objectSyncRow.get("SEARCH_STRING").toString();
                StringBuffer stringBuffer = new StringBuffer(searchString);
                String baseAttrQueryString = String.format("(|(%s=*))",ldapName);
                if((objectType==ObjectType.User.ordinal()) || (objectType==ObjectType.OU.ordinal())) {
                    stringBuffer.insert(searchString.length()-1, baseAttrQueryString);
                }
                else {
                    stringBuffer = new StringBuffer(String.format("(&%s%s)", searchString, baseAttrQueryString));
                }
                row.set("SEARCH_STRING", stringBuffer.toString());
                row.set("IS_ENABLED", objectSyncRow.get("IS_ENABLED"));
                row.set("BASE_DN", domainDetails.get("DEFAULT_NAMING_CONTEXT").toString());
                Long priorityId = ADSyncConfigForBackup.getObjectID(domainId, (Long) objectSyncRow.get("PRIORITY_ID") + SyncFilter.CUSTOM_ATTR_OFFSET);
                row.set("PRIORITY_ID", priorityId);
                row.set("SEARCH_PREFERENCE", objectSyncRow.get("SEARCH_PREFERENCE"));
                addObjectRow.addRow(row);
                HashSet<String> defaultAttrs = RMPADSyncConfig.getRMPSyncAttributesRow(syncObjectType);
                if (BackupUtil.getBackupStat(domainId) != null) {
                    for (String attrName : defaultAttrs) {
                        Row attrRow = ADSyncAttributesConfig.addRow(objectIds.get(i), attrName);
                        addAttrRow.addRow(attrRow);
                    }
                }
            }
            CommonUtil.getPersistence().add(addObjectRow);
            CommonUtil.getPersistence().add(addAttrRow);
            return true;
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncObjects : " + e);
        }
        return false;
    }

    public static String getSearchString(Long objectId) throws DataAccessException {
        SelectQuery syncObjectId = new SelectQueryImpl(Table.getTable(TABLE));
        syncObjectId.addSelectColumn(Column.getColumn(TABLE, "*"));
        Criteria objectIdCriteria = new Criteria(Column.getColumn(TABLE, "OBJECT_ID"), objectId, QueryConstants.EQUAL);
        syncObjectId.setCriteria(objectIdCriteria);
        DataObject obj = CommonUtil.getPersistence().get(syncObjectId);
        Iterator iterator = obj.getRows(TABLE);
        if(iterator.hasNext()) {
            Row row = (Row) iterator.next();
            return (String) row.get("SEARCH_STRING");
        }
        return null;
    }

    public static boolean hasSyncFilter(String objectType, Long domainId) throws DataAccessException {

        SelectQuery syncObjectType = new SelectQueryImpl(Table.getTable(TABLE));
        syncObjectType.addSelectColumn(Column.getColumn(TABLE, "OBJECT_ID"));
        Criteria objectIdCriteria = new Criteria(Column.getColumn(TABLE, "OBJECT_TYPE"), objectType, QueryConstants.STARTS_WITH);
        Criteria domainIdCriteria = new Criteria(Column.getColumn(TABLE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
        syncObjectType.setCriteria(domainIdCriteria.and(objectIdCriteria));
        DataObject obj = CommonUtil.getPersistence().get(syncObjectType);
        Iterator iterator = obj.getRows(TABLE);
        return iterator.hasNext();
    }

    public static void deleteCustomAttrRows(Long domainId, Properties domainSettings) throws DataAccessException {
        Persistence per = CommonUtil.getPersistence();
        String adSyncResults = "ADSADSyncResults";

        String context = domainSettings.get("DEFAULT_NAMING_CONTEXT").toString();
        Criteria delCriteria = new Criteria(Column.getColumn(adSyncResults, "OBJECT_TYPE"), SyncFilter.CUSTOM_SYNC_PREPENDER, QueryConstants.STARTS_WITH);
        delCriteria = delCriteria.and(new Criteria(Column.getColumn(adSyncResults, "BASE_DN"), context, QueryConstants.EQUAL, false));
        DataObject deleteResultRow = per.get(adSyncResults, delCriteria);
        deleteResultRow.deleteRows(adSyncResults, delCriteria);
        per.update(deleteResultRow);

        Criteria criteria = new Criteria(Column.getColumn(TABLE, "OBJECT_TYPE"), SyncFilter.CUSTOM_SYNC_PREPENDER, QueryConstants.STARTS_WITH);
        criteria = criteria.and(new Criteria(Column.getColumn(TABLE, "DOMAIN_ID"), domainId, QueryConstants.EQUAL));
        DataObject delrow = per.get(TABLE, criteria);
        delrow.deleteRows(TABLE, criteria);
        per.update(delrow);
    }

    public static boolean deleteSyncResult(Long domainId, Integer objectType) {
        try {
            Long objectID = SyncFilter.getSyncObjectType(objectType).get(0).longValue();
            String baseDN = BaseDNPrepender.getBaseDN(domainId, objectID, BaseDNPrepender.getBaseDNPrepender(objectID.intValue()));

            final String syncResultTable = "ADSAdSyncResults";
            Persistence per = CommonUtil.getPersistence();
            Criteria delCriteria = new Criteria(Column.getColumn(syncResultTable, "BASE_DN"), baseDN, QueryConstants.EQUAL);
            delCriteria = delCriteria.and(new Criteria(Column.getColumn(syncResultTable, "OBJECT_TYPE"), ObjectType.parse(objectType).toString().toLowerCase(), QueryConstants.EQUAL));
            per.delete(delCriteria);
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncObjects.deleteSync() : " + e);
        }
        return false;
    }
    
    public static boolean deleteSyncResultOfAllDomains(Integer objectType) {
        try {
            final String syncResultTable = "ADSAdSyncResults";
            Persistence per = CommonUtil.getPersistence();
            Criteria delCriteria = new Criteria(Column.getColumn(syncResultTable, "OBJECT_TYPE"), ObjectType.parse(objectType).toString().toLowerCase(), QueryConstants.EQUAL);
            per.delete(delCriteria);
        } catch (Exception e) {
            LogWriter.general.severe("ADSyncObjects.deleteSyncResultOfAllDomains() : " + e);
        }
        return false;
    }
}

//ignoreI18n_end
