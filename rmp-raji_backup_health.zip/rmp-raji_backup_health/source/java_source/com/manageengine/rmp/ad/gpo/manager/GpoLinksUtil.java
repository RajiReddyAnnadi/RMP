/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.manager;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.DerivedTable;
import com.adventnet.ds.query.GroupByClause;
import com.adventnet.ds.query.GroupByColumn;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.QueryConstructionException;
import com.adventnet.ds.query.Range;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.domain.ADSDomainHandler;
import com.manageengine.ads.fw.jni.ADSNativeHandler;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.ad.backup.BackupImpl;
import com.manageengine.rmp.ad.backup.BackupUtil;
import com.manageengine.rmp.ad.rangedattributes.ForwardLink;
import com.manageengine.rmp.ad.rangedattributes.LinkType;
import com.manageengine.rmp.ad.rangedattributes.LinkedAttributesUtil;
import static com.manageengine.rmp.ad.rangedattributes.LinkedAttributesUtil.getLatestDeletedBackupId;
import static com.manageengine.rmp.ad.rangedattributes.LinkedAttributesUtil.getMaxBackupIdForObject;
import com.manageengine.rmp.ad.rangedattributes.RangedAttrObject;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.RMPCommonFlags;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.dataobjects.LdapAttribute;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.util.GeneralUtil;
import com.manageengine.rmp.util.LdapUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Properties;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;

import org.json.JSONObject;
import org.json.JSONArray;

/**
 *
 * @author poornima-3055
 */
public class GpoLinksUtil 
{
    public static final String[] linkStatus = new String[]{"Enabled", "Disabled", "Enabled, Enforced", "Disabled, Enforced"};   //No I18N
    private static final String addedRange = ForwardLink.gPLink + LinkedAttributesUtil.ADDED_RANGE;
    private static final String removedRange = ForwardLink.gPLink + LinkedAttributesUtil.REMOVED_RANGE;
    private static final String modifiedRange = ForwardLink.gPLink + LinkedAttributesUtil.MODIFIED_RANGE;
    
    public static String[] getGpoLinks(String ldapString) 
    {
        ldapString = ldapString.trim();
        ldapString = ldapString.substring(1, ldapString.length()-1);
        return ldapString.split("\\]");
    }
    
    public static String getGUIDFromGpoLink(String gpLink)
    {
        return gpLink.substring(11, 11+36).toUpperCase();
    }
    
    public static void updateGpoLinksCache(BackupObject backupObject, BackupObject lastsnapShot, BackupImpl backupImpl, Properties prop)
    {
        try
        {   
            String newGPLink = prop.containsKey("gPLink") ? ((ArrayList)prop.get("gPLink")).toString() : "";    //No I18N
            JSONObject newGPOLinks = getGPOLinksInfo(newGPLink);
            JSONObject oldGPOLinks = getOldGPOLinksInfo(ForwardLink.gPLink.linkId, backupImpl.domainId, backupObject.objId.toString());
            Iterator newGPOLinksItr = newGPOLinks.keys();
            while(newGPOLinksItr.hasNext())
            {
                String gpoID = (String)newGPOLinksItr.next();
                JSONObject newGPLinkInfo = newGPOLinks.getJSONObject(gpoID);
                if(oldGPOLinks.has(gpoID))
                {
                    JSONObject oldGPLinkInfo = oldGPOLinks.getJSONObject(gpoID);
                    if(oldGPLinkInfo.getInt("status") != newGPLinkInfo.getInt("status") || oldGPLinkInfo.getInt("priority") != newGPLinkInfo.getInt("priority"))
                    {
                        updateGpLinkData(prop, backupImpl, gpoID, modifiedRange, newGPLinkInfo);
                    }
                    oldGPOLinks.remove(gpoID);
                }
                else
                {
                    updateGpLinkData(prop, backupImpl, gpoID, addedRange, newGPLinkInfo);
                }
            }
            Iterator oldGPOLinksItr = oldGPOLinks.keys();
            while(oldGPOLinksItr.hasNext())
            {
                String gpoID = (String)oldGPOLinksItr.next();
                JSONObject oldGPLinkInfo = oldGPOLinks.getJSONObject(gpoID);
                updateGpLinkData(prop, backupImpl, gpoID, removedRange, oldGPLinkInfo);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public static Boolean updateDeletedLinks(BackupObject backupObject, BackupObject lastSnapshot, Properties prop, GPFrontLinkAttrManager frontLink, BackupImpl backupImpl) throws Exception
    {
        frontLink.forwardLink = ForwardLink.gPLink;
        Properties totalDnAndGuid = LinkedAttributesUtil.getTotalDnAndGuidHashFromBackup(frontLink.domainId, LdapAttribute.gpLink.ldapAttributeId, backupObject.objId.toString(), "FRONTLINK_OBJECT_GUID", "BACKLINK_OBJECT_GUID", "BACKLINK_OBJECT_DN", true);  //No I18N
        if (!totalDnAndGuid.isEmpty()) {
            ArrayList<String> totalGuidList = new ArrayList(totalDnAndGuid.stringPropertyNames());
            frontLink.updateRemovedFrontLinkAttrs(prop, backupObject.objId.toString(), totalDnAndGuid, totalGuidList);
            frontLink.removeLinksFromCurrentBackup(backupObject.objId.toString(), totalGuidList);
            if (frontLink.frontLinkMetaInfo.containsKey(backupObject.objId.toString())) {
                RangedAttrObject temp = frontLink.frontLinkMetaInfo.get(backupObject.objId.toString());
                temp.setMetadata(LdapAttribute.gpLink.ldapAttributeId, 0, 0, totalGuidList.size(), 0);
            } else {
                RangedAttrObject temp = new RangedAttrObject(backupObject.objId.toString(), lastSnapshot.oldDn, backupObject.objTyp);
                temp.setMetadata(LdapAttribute.gpLink.ldapAttributeId, 0, 0, totalGuidList.size(), 0);
                frontLink.frontLinkMetaInfo.put(backupObject.objId.toString(), temp);
            }
        }
        return true;
    }
    
    public static Properties getTotalDnOrGuidFromBackup(BackupImpl backupImpl, Long domainId, int linkId, Long backupId, String objectGuid, int changes, String linkForeGuid, String linkBackGuid, String linkBackDn, Boolean isRanged, int startIndex, int endIndex, String resultDnorGuid) throws QueryConstructionException {
        Properties prop = new Properties();
        Connection con = null;
        DataSet dset = null;
        try {
            SelectQuery query = GpoLinksUtil.getLinksListFromRangedAttr(domainId, linkId, backupId, objectGuid, changes, linkForeGuid, linkBackGuid, linkBackDn, isRanged, startIndex, endIndex, true);
            con = RelationalAPI.getInstance().getConnection();
            dset = RelationalAPI.getInstance().executeQuery(query, con);
            if(dset != null) {
                while(dset.next())
                {
                    JSONObject newGPLinkInfo = new JSONObject();
                    newGPLinkInfo.put("status", dset.getInt("STATUS"));
                    newGPLinkInfo.put("priority", dset.getInt("PRIORITY"));
                    updateGpLinkData(prop, backupImpl, dset.getAsString(linkBackGuid).toUpperCase(), addedRange, newGPLinkInfo);
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            LogWriter.backup.log(Level.SEVERE, "GroupMemberManager: getCurrentMembersDnListFromBackup domainId-{0}{1}", new Object[]{domainId, e});
            e.printStackTrace();
        }
        finally
        {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        return prop;
    }
    
    public static Boolean updateRecycledLinks(BackupObject backupObject, GPFrontLinkAttrManager frontLink, BackupImpl backupImpl)
    {
        try
        {
            frontLink.forwardLink = ForwardLink.gPLink;
            Properties prop = updateGPLinksFromAD(backupImpl, backupObject.objId.toString(), backupObject.distinguishedName, frontLink.domainId);
            if(prop != null) {
                prop.put("objectGUID",GeneralUtil.getStringAsArrayList(backupObject.objId.toString()));
                prop.put("distinguishedName", GeneralUtil.getStringAsArrayList(backupObject.distinguishedName));   
                prop.put("notInADSync", true);
                backupImpl.backupObjectNotInCache(prop);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return false;
    }
    
    private static Properties updateGPLinksFromAD(BackupImpl backupImpl, String objectGuid, String distinguishedName, Long domainId) throws Exception 
    {
        Properties domainDetails = RMPDomainHandler.getDomainDetailsById(domainId);
        ArrayList<Properties> keyList = ADSNativeHandler.executeADQuery(domainDetails, new String[]{"gPLink"}, "(objectGUID=" + LdapUtil.encodeObjectGUID(objectGuid) + ")",LdapUtil.getDomainDN(distinguishedName) ); //No I18N
        if(keyList.size() > 0) 
        {
            Properties propGPLink = keyList.get(0);
            if(propGPLink.containsKey("gPLink")) 
            {
                String gpLink = BackupUtil.getString(propGPLink, "gPLink");    //No I18N
                JSONObject newGPOLinks = getGPOLinksInfo(gpLink);
                if(newGPOLinks.length() > 0)
                {
                    Iterator newGPOLinksItr = newGPOLinks.keys();
                    Properties prop = new Properties();
                    while(newGPOLinksItr.hasNext())
                    {
                        String gpoID = (String)newGPOLinksItr.next();
                        JSONObject newGPLinkInfo = newGPOLinks.getJSONObject(gpoID);
                        updateGpLinkData(prop, backupImpl, gpoID.toUpperCase(), addedRange, newGPLinkInfo);
                    }
                    return prop;
                }
            }
        }
        return null;
    }
    
    public static SelectQuery getLinksListFromRangedAttr(Long domainId, int linkId, Long backupId, String objectGuid, int changes, String linkForeGuid, String linkBackGuid, String linkBackDn, Boolean isRanged, int startIndex, int endIndex) throws Exception
    {
        return getLinksListFromRangedAttr(domainId, linkId, backupId, objectGuid, changes, linkForeGuid, linkBackGuid, linkBackDn, isRanged, startIndex, endIndex, false);
    }
    
    public static SelectQuery getLinksListFromRangedAttr(Long domainId, int linkId, Long backupId, String objectGuid, int changes, String linkForeGuid, String linkBackGuid, String linkBackDn, Boolean isRanged, int startIndex, int endIndex, boolean isNeedDN) throws Exception
    {
        String tableName = TableName.RMP_GPO_LINK_ATTRIBUTES+"_"+domainId;
        SelectQuery query = null;
        if (backupId != 0 && changes == LinkType.Total.memberTypeId) 
        {
            Table table = Table.getTable(tableName, "temp");
            SelectQuery subQuery1 = new SelectQueryImpl(Table.getTable(tableName));
            subQuery1.addSelectColumn(Column.getColumn(tableName, linkBackGuid));
            Column col2 = Column.getColumn(tableName, "BACKUP_ID").maximum();   //No I18N
            col2.setColumnAlias("latest_time"); 
            subQuery1.addSelectColumn(col2);
            Criteria criteria = new Criteria(Column.getColumn(tableName, "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);
            criteria = criteria.and(Column.getColumn(tableName, "BACKUP_ID"), backupId, QueryConstants.LESS_EQUAL); //No I18N
            criteria = criteria.and(Column.getColumn(tableName, "BACKUP_ID"), 0, QueryConstants.NOT_EQUAL); //No I18N
            criteria = criteria.and(Column.getColumn(tableName, linkForeGuid), objectGuid, QueryConstants.EQUAL, false);
            subQuery1.setCriteria(criteria);
            GroupByColumn gbc = new GroupByColumn(Column.getColumn(tableName, linkBackGuid), false);
            List<GroupByColumn> gbcs = new ArrayList();
            gbcs.add(gbc);
            subQuery1.setGroupByClause(new GroupByClause(gbcs));
            DerivedTable dertable2 = new DerivedTable("temp", subQuery1);   //No I18N

            Table table3 = Table.getTable(tableName, "table3");
            SelectQuery query3 = new SelectQueryImpl(table3);
            query3.addSelectColumn(Column.getColumn("table3", "BACKUP_ID"));
            query3.addSelectColumn(Column.getColumn("table3", linkBackGuid));
            query3.addSelectColumn(Column.getColumn("table3", "LINKS_TYPE"));
            query3.addSelectColumn(Column.getColumn("table3", "STATUS"));
            query3.addSelectColumn(Column.getColumn("table3", "PRIORITY"));
            query3.addSelectColumn(Column.getColumn("table3", "FRONTLINK_TYPE"));
            Criteria criteria3 = new Criteria(Column.getColumn("table3", "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);
            criteria3 = criteria3.and(Column.getColumn("table3", linkForeGuid), objectGuid, QueryConstants.EQUAL,false);    //No I18N
            criteria3 = criteria3.and(Column.getColumn("table3", "LINKS_TYPE"), 0, QueryConstants.NOT_EQUAL);   //No I18N
            criteria3 = criteria3.and(Column.getColumn("table3", "LINKS_TYPE"), 2, QueryConstants.NOT_EQUAL);   //NO I18N
            query3.setCriteria(criteria3);
            DerivedTable dertable3 = new DerivedTable("table3", query3);     //No I18N

            DerivedTable dertable4 = null;
            if(linkBackGuid.equalsIgnoreCase("FRONTLINK_OBJECT_GUID"))	
            {	
                Table table4 = Table.getTable(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "table4");
                SelectQuery query4 = new SelectQueryImpl(table4);
                query4.addSelectColumn(Column.getColumn("table4", "OBJECT_DN"));  
                query4.addSelectColumn(Column.getColumn("table4", "OBJECT_GUID"));   	
                Criteria criteria4 = new Criteria(Column.getColumn("table4", "OBJECT_TYPE"), ObjectType.OU.maskValue, QueryConstants.EQUAL);
                criteria4 = criteria4.or(Column.getColumn("table4", "OBJECT_TYPE"), ObjectType.Site.maskValue, QueryConstants.EQUAL);   //No I18N
                criteria4 = criteria4.or(Column.getColumn("table4", "OBJECT_TYPE"), ObjectType.Other.maskValue, QueryConstants.EQUAL);   //No I18N
                query4.setCriteria(criteria4);
                dertable4 = new DerivedTable("table4", query4); //No I18N
            }
            
            DerivedTable derTable5 = null;
            if(linkBackGuid.equalsIgnoreCase("BACKLINK_OBJECT_GUID"))
            {
                Table table5 = Table.getTable(TableName.RMP_GPO_DETAILS, "table5");
                SelectQuery query5 = new SelectQueryImpl(table5);
                query5.addSelectColumn(Column.getColumn("table5", "OBJECT_NAME"));  
                query5.addSelectColumn(Column.getColumn("table5", "GPO_ID"));   		
                Criteria criteria5 = new Criteria(Column.getColumn("table5", "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
                query5.setCriteria(criteria5);
                derTable5 = new DerivedTable("table5", query5); //NO I18N
            }
            
            query = new SelectQueryImpl(dertable3);
            query.addJoin(new Join(dertable3, dertable2, new String[]{"BACKUP_ID", linkBackGuid}, new String[]{"latest_time", linkBackGuid}, Join.LEFT_JOIN));
            query.addSelectColumn(Column.getColumn("table3", linkBackGuid));
            query.addSelectColumn(Column.getColumn("table3", "LINKS_TYPE"));
            query.addSelectColumn(Column.getColumn("table3", "STATUS"));
            query.addSelectColumn(Column.getColumn("table3", "PRIORITY"));
            query.addSelectColumn(Column.getColumn("table3", "FRONTLINK_TYPE"));
            if(dertable4 != null) 
            {
                query.addJoin(new Join(dertable2, dertable4, new String[]{linkBackGuid}, new String[]{"OBJECT_GUID"}, Join.INNER_JOIN));
                query.addSelectColumn(Column.getColumn("table4", "OBJECT_DN", linkBackDn));
            }
            if(derTable5 != null)
            {
                query.addSelectColumn(Column.getColumn("table5", "OBJECT_NAME"));
                query.addJoin(new Join(dertable2, derTable5, new String[]{linkBackGuid}, new String[]{"GPO_ID"}, Join.INNER_JOIN));
            }
            if(isRanged) 
            {
                Range range = new Range(startIndex, endIndex);
                query.setRange(range);
                query.addSortColumn(new SortColumn(Column.getColumn("table3", linkBackGuid), true));    //No I18N
            }
        }
        else
        {
            query = new SelectQueryImpl(Table.getTable(tableName));
            Criteria criteria = new Criteria(Column.getColumn(tableName, linkForeGuid), objectGuid, QueryConstants.EQUAL,false);
            if (backupId == 0 & linkId != ForwardLink.none.linkId) 
            {
                criteria = criteria.and(Column.getColumn(tableName, "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);  //No I18N
                criteria = criteria.and(Column.getColumn(tableName, "LINKS_TYPE"), 0, QueryConstants.EQUAL);  //No I18N
            } 
            else if (changes == LinkType.Added.memberTypeId || changes == LinkType.Removed.memberTypeId || changes == LinkType.Modified.memberTypeId) 
            {
                criteria = criteria.and(Column.getColumn(tableName, "BACKUP_ID"), backupId, QueryConstants.EQUAL);  //No I18N
                criteria = criteria.and(Column.getColumn(tableName, "FORWARD_LINK_ID"), linkId, QueryConstants.EQUAL);  //No I18N
                criteria = criteria.and(Column.getColumn(tableName, "LINKS_TYPE"), changes, QueryConstants.EQUAL);  //No I18N
            }
            
            query.addSelectColumn(Column.getColumn(tableName, linkBackGuid));
            query.addSelectColumn(Column.getColumn(tableName, "STATUS"));
            query.addSelectColumn(Column.getColumn(tableName, "PRIORITY"));
            query.addSelectColumn(Column.getColumn(tableName, "LINKS_TYPE"));
            query.addSelectColumn(Column.getColumn(tableName, "FRONTLINK_TYPE"));
            
            if(linkBackGuid.equalsIgnoreCase("FRONTLINK_OBJECT_GUID") || isNeedDN)	
            {
                query.addJoin(new Join(tableName, TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, new String[]{linkBackGuid}, new String[]{"OBJECT_GUID"}, Join.INNER_JOIN));
                query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_DN", linkBackDn));                
            }
            if(linkBackGuid.equalsIgnoreCase("BACKLINK_OBJECT_GUID"))	
            {
                criteria = criteria .and(Column.getColumn(TableName.RMP_GPO_DETAILS, "DOMAIN_ID"), domainId, QueryConstants.EQUAL); //No I18N
                query.addJoin(new Join(tableName, TableName.RMP_GPO_DETAILS, new String[]{linkBackGuid}, new String[]{"GPO_ID"}, Join.INNER_JOIN));
                query.addSelectColumn(Column.getColumn(TableName.RMP_GPO_DETAILS, "OBJECT_NAME"));                
            }
            query.setCriteria(criteria); 
            if(isRanged) 
            {
                Range range = new Range(startIndex, endIndex);
                query.setRange(range);
                query.addSortColumn(new SortColumn(Column.getColumn(tableName, linkBackGuid), true));
            } 
        }
        return query;
    }
    
    private static JSONObject getOldGPOLinksInfo(int linkId, Long domainId, String objectGuid) throws Exception
    {
        JSONObject oldGPOLink = new JSONObject();
        Connection con = null;
        DataSet dset = null;
        try {
            SelectQuery query = getLinksListFromRangedAttr(domainId, linkId, 0L, objectGuid, 0, "FRONTLINK_OBJECT_GUID", "BACKLINK_OBJECT_GUID", "BACKLINK_OBJECT_DN", false, 0, 0);//NO I18N
            con = RelationalAPI.getInstance().getConnection();
            dset = RelationalAPI.getInstance().executeQuery(query, con);
            if (dset != null) {
                while (dset.next()) {
                    JSONObject gpoLinkInfo = new JSONObject();
                    gpoLinkInfo.put("status", dset.getInt("STATUS"));
                    gpoLinkInfo.put("priority", dset.getInt("PRIORITY"));
                    oldGPOLink.put(dset.getAsString("BACKLINK_OBJECT_GUID").toUpperCase(), gpoLinkInfo);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        return oldGPOLink;
    }
    
    public static ArrayList<String> getGPLinksArrayList(JSONObject members)
    {
        ArrayList<String> list = new ArrayList();
        if(members != null && members.length() > 0)
        {
            JSONArray jsonArray = members.names();
            try {
                for (int i = 0; i < jsonArray.length(); i++) {
                    list.add(jsonArray.get(i).toString());
                }
            } catch (Exception e) {
                LogWriter.general.warning(String.format("GpoLinksUtil.getGPLinksArrayList", e));    //No I18N
            }
        }
        return list;
    }
    
    public static JSONObject getGPOLinksInfo(String gpLink)
    {
        try
        {
            gpLink = gpLink.trim();
            if(gpLink.isEmpty() || gpLink.equalsIgnoreCase("[]") || gpLink.equalsIgnoreCase("[ ]"))
            {
                return new JSONObject();
            }
            JSONObject gpoLinksBackup = new JSONObject();
            ArrayList<String> gpoLinksList = new ArrayList(Arrays.asList(getGpoLinks(gpLink)));
            for (String gpoLink : gpoLinksList) 
            {
                String splitGPLink[] = gpoLink.split("\\;");
                splitGPLink[0] = splitGPLink[0].replaceAll("]", "");
                splitGPLink[0] = splitGPLink[0].replaceAll("\\[", "");
                String gpoId = getGUIDFromGpoLink(splitGPLink[0]);
                JSONObject gpoLinkInfo = new JSONObject();
                gpoLinkInfo.put("status", Integer.parseInt(""+splitGPLink[1].charAt(0)));
                gpoLinkInfo.put("priority", gpoLinksList.size() - gpoLinksList.indexOf(gpoLink));
                gpoLinksBackup.put(gpoId, gpoLinkInfo);
            }
            return gpoLinksBackup;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return new JSONObject();
        }
    }
   
    public static void updateGpLinkData(Properties prop, BackupImpl backupImpl, String gpoID, String range, JSONObject gpoLinkInfo) throws Exception
    {
        JSONObject member;
        String gpoDN = GpoUtil.getGpoDn(gpoID, backupImpl.domainName);
        if(prop.containsKey(range))
        {
            member = (JSONObject) prop.get(range);
            member.put(gpoDN, gpoLinkInfo);
        }
        else
        {
            member = new JSONObject();
            member.put(gpoDN, gpoLinkInfo);
        }
        prop.put(range, member);
    }
 
    public static String gpBackLinksRestoreInfo(String domainName, JSONObject restoreInfo, String currentGPLink, String gpObjectId, boolean hasNoOldValue, int backupStatus, int backupPriority, int linkType)
    {
        try
        {
            currentGPLink = currentGPLink.trim();
            Map<Integer, JSONObject> gpoLinksRestore = new TreeMap(Collections.reverseOrder());
            boolean toRemove = false;
            if(!currentGPLink.isEmpty())
            {
                ArrayList<String> gpoLinksList = new ArrayList(Arrays.asList(getGpoLinks(currentGPLink)));
                for (String gpoLink : gpoLinksList) 
                {
                    String splitGPLink[] = gpoLink.split("\\;");
                    splitGPLink[0]= splitGPLink[0].replaceAll("]", "");
                    splitGPLink[0]= splitGPLink[0].replaceAll("\\[", "");
                    String gpoId = getGUIDFromGpoLink(splitGPLink[0]).toLowerCase();
                    if(gpoId.equalsIgnoreCase(gpObjectId) && linkType == LinkType.Removed.memberTypeId.intValue())
                    {
                        int removed = restoreInfo.getInt("removed") + 1;  //No I18N
                        restoreInfo.put("removed", removed);
                        toRemove = true;
                        continue;
                    }
                    if(!(hasNoOldValue && gpoId.equalsIgnoreCase(gpObjectId))) 
                    {
                        JSONObject gpoLinkInfo = new JSONObject();
                        gpoLinkInfo.put("gpoId", gpoId);
                        gpoLinkInfo.put("status", Integer.parseInt(""+splitGPLink[1].charAt(0)));
                        gpoLinksRestore.put(gpoLinksList.size() - gpoLinksList.indexOf(gpoLink), gpoLinkInfo);
                    }
                }
            }
            if(!toRemove)
            {
                JSONObject gpoLinksInfo = getGPOLinksInfo(currentGPLink);
                if(gpoLinksInfo.has(gpObjectId.toUpperCase()))
                {
                    JSONObject gpLinkRestoreInfo = gpoLinksInfo.getJSONObject(gpObjectId.toUpperCase());
                    int currentStatus = gpLinkRestoreInfo.getInt("status"); //No I18N
                    int currentPriority = gpLinkRestoreInfo.getInt("priority"); //No I18N
                    if(currentStatus != backupStatus || currentPriority != backupPriority)
                    {
                        updateGPOLinkJSONObject(gpoLinksRestore, gpObjectId, backupStatus, backupPriority, currentPriority, false);
                        int modified = restoreInfo.getInt("modified") + 1;  //No I18N
                        restoreInfo.put("modified", modified);
                    }
                }
                else if(!hasNoOldValue)
                {
                    newGPOLinkJSONObject(gpoLinksRestore, gpObjectId, backupStatus, backupPriority);
                    int added = restoreInfo.getInt("added") + 1;    //No I18N
                    restoreInfo.put("added", added);
                }
            }
            return formGPLink(domainName, gpoLinksRestore);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }
    
    public static JSONObject getNewRestoreInfo() throws Exception
    {
        JSONObject restoreInfo = new JSONObject();
        restoreInfo.put("added", 0);
        restoreInfo.put("skipped", 0);
        restoreInfo.put("modified", 0);
        restoreInfo.put("removed", 0);
        return restoreInfo;
    }
    
    public static JSONArray getGpLinkBackupInfo(Properties domainDetails, DataSet dset, JSONObject restoreInfo, Long domainId) throws Exception
    {
        JSONArray gpLinksBackupInfo = new JSONArray();
        while (dset.next()) 
        {
            String gpoId = (String) dset.getValue("BACKLINK_OBJECT_GUID");  //No I18N
            String gpoDN = GpoUtil.getGpoDn(gpoId, domainDetails.getProperty("DOMAIN_NAME"));
            String searchString = "(distinguishedName=" + gpoDN + ")";  //No I18N
            ArrayList<Properties> ouProps = ADSNativeHandler.executeADQuery(domainDetails, new String[]{"isDeleted"}, searchString, domainDetails.getProperty("DEFAULT_NAMING_CONTEXT"));   //No I18N
            if(!ouProps.isEmpty())
            {
                Properties prop = ouProps.get(0);
                if (prop.containsKey("isDeleted") && BackupUtil.getBoolean(prop, "isDeleted") != null && BackupUtil.getBoolean(prop, "isDeleted"))
                {
                    int skipped = restoreInfo.getInt("skipped") + 1;    //No I18N
                    restoreInfo.put("skipped", skipped);
                }
                else
                {
                    JSONObject gpLinkBackupInfo = new JSONObject();
                    gpLinkBackupInfo.put("gpoId", gpoId);// No I18N
                    gpLinkBackupInfo.put("status", (int) dset.getValue("STATUS"));// No I18N
                    gpLinkBackupInfo.put("priority", (int) dset.getValue("PRIORITY"));// No I18N
                    gpLinksBackupInfo.put(gpLinkBackupInfo);
                }
            }
            else
            {
                int skipped = restoreInfo.getInt("skipped") + 1;    //No I18N
                restoreInfo.put("skipped", skipped);
            }
        }
        return gpLinksBackupInfo;
    }
    
    public static String gpLinkRestoreInfo(String domainName, JSONObject restoreInfo, String currentGPLink, JSONArray gpoLinksBackup)
    {
        try
        {
            currentGPLink = currentGPLink.trim();
            if(currentGPLink.isEmpty() || currentGPLink.equalsIgnoreCase("[ ]"))
            {
                currentGPLink = "";
            }
            JSONObject currentGPLinks = getGPOLinksInfo(currentGPLink);
            Map<Integer, JSONObject> gpoLinksRestore = new TreeMap(Collections.reverseOrder());
            for(int i=0; i < gpoLinksBackup.length(); i++)
            {
                JSONObject gpLinkBackupInfo = gpoLinksBackup.getJSONObject(i);
                String gpoId = gpLinkBackupInfo.get("gpoId").toString().toUpperCase();
                int backupStatus = gpLinkBackupInfo.getInt("status");   //No I18N
                int backupPriority = gpLinkBackupInfo.getInt("priority");   //No I18N
                if(currentGPLinks.has(gpoId))
                {
                    JSONObject gpLinkCurrentInfo = currentGPLinks.getJSONObject(gpoId);
                    int currentStatus = gpLinkCurrentInfo.getInt("status"); //No I18N
                    int currentPriority = gpLinkCurrentInfo.getInt("priority"); //No I18N
                    if(currentStatus != backupStatus || currentPriority != backupPriority)
                    {
                        updateGPOLinkJSONObject(gpoLinksRestore, gpoId, backupStatus, backupPriority, currentPriority, true);
                        int modified = restoreInfo.getInt("modified") + 1;  //No I18N
                        restoreInfo.put("modified", modified);
                    }
                    else
                    {
                        newGPOLinkJSONObject(gpoLinksRestore, gpoId, backupStatus, backupPriority);
                        int added = restoreInfo.getInt("added") + 1;    //No I18N
                        restoreInfo.put("added", added);
                    }
                    currentGPLinks.remove(gpoId);
                }
                else
                {
                    newGPOLinkJSONObject(gpoLinksRestore, gpoId, backupStatus, backupPriority);
                    int added = restoreInfo.getInt("added") + 1;    //No I18N
                    restoreInfo.put("added", added);
                }
            }
            if(currentGPLinks.length() != 0)
            {
                int removed = restoreInfo.getInt("removed") + currentGPLinks.length();  //No I18N
                restoreInfo.put("removed", removed);
                currentGPLinks = null;
            }
            return formGPLink(domainName, gpoLinksRestore);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }  
    }
    
    private static void updateGPOLinkJSONObject(Map<Integer, JSONObject> gpoLinksRestore, String gpoId, int backupStatus, int backupPriority, int currentPriority, boolean isGPLink) throws Exception
    {
        JSONObject gpoLinkInfo = new JSONObject();
        gpoLinkInfo.put("gpoId", gpoId);
        gpoLinkInfo.put("status", backupStatus);
        if(currentPriority != backupPriority && !isGPLink)
        {
            gpoLinksRestore.remove(currentPriority);
        }
        gpoLinksRestore.put(backupPriority , gpoLinkInfo);
    }
    
    private static void moveKeysPriority(Map<Integer, JSONObject> gpoLinksRestore, int backupPriority) throws Exception
    {
        if(gpoLinksRestore != null)
        {
            List<Integer> keyList = new ArrayList(gpoLinksRestore.keySet());
            for (Integer key : keyList)
            {
                if(key >= backupPriority)
                {
                    gpoLinksRestore.put(key+1, gpoLinksRestore.get(key));
                    gpoLinksRestore.remove(key);
                }
            }
        }
    }
    
    private static void newGPOLinkJSONObject(Map<Integer, JSONObject> gpoLinksRestore, String gpoId, int status, int priority) throws Exception
    {
        JSONObject gpoLinkInfo = new JSONObject();
        gpoLinkInfo.put("gpoId", gpoId);
        gpoLinkInfo.put("status", status);
        if(gpoLinksRestore.containsKey(priority))
        {
            moveKeysPriority(gpoLinksRestore, priority);
        }
        gpoLinksRestore.put(priority , gpoLinkInfo);
    }
    
    private static String formGPLink(String domainName, Map<Integer, JSONObject> gpoLinksRestore) throws Exception
    {
        if(gpoLinksRestore != null)
        {
            List<Integer> keyList = new ArrayList(gpoLinksRestore.keySet());
            if(!keyList.isEmpty())
            {
                String newGpLink = "";
                for (int i= 0 ; i < keyList.size(); i++) 
                {
                    int key = keyList.get(i);
                    JSONObject gpLinkInfo = (JSONObject) gpoLinksRestore.get(key);
                    newGpLink += "[LDAP://" + GpoUtil.getGpoDn(gpLinkInfo.get("gpoId").toString(), domainName) + ";" + gpLinkInfo.getInt("status") + "]";    //No I18N
                }
                return newGpLink;
            }
        }
        return " ";
    }
    
    
    public static void updateDeletedGPLinks(ArrayList<String> linkDns, Long domainId) { 
        try
        {
            ArrayList<String> guids = new ArrayList();
            for(int i=0;i<linkDns.size(); i++)
            {
                guids.add(i, GpoUtil.getGpoId((String)linkDns.get(i)).toLowerCase());
            }
            SelectQuery selectQuery = new SelectQueryImpl(new Table(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"));
            selectQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_DN"));
            Criteria guidCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"), guids.toArray(new String[guids.size()]), QueryConstants.IN, false);
            Column isDeleted = Column.createFunction("AND_OPERATOR", Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "SYNC_STATUS"), RMPCommonFlags.IsDeleted.maskValue);  //NO I18N
            isDeleted.setType(Types.INTEGER);
            selectQuery.setCriteria(guidCriteria .and(new Criteria(isDeleted, 0, QueryConstants.GREATER_THAN)));
            DataObject dobj = CommonUtil.getPersistence().get(selectQuery);
            Iterator itr = dobj.getRows(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId);
            while(itr.hasNext())
            {
                Row row = (Row) itr.next();
                String guid = (String) row.get("OBJECT_GUID");
                int index = guids.indexOf(guid.toLowerCase());
                linkDns.set(index, (String) row.get("OBJECT_DN"));
            }
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    public static boolean checkLinksBackup(Properties prop)
    {
        String attributeName = ForwardLink.getAttributeName(LdapAttribute.gpLink.ldapAttributeId);
        return prop.containsKey(attributeName + LinkedAttributesUtil.ADDED_RANGE) || prop.containsKey(attributeName + LinkedAttributesUtil.REMOVED_RANGE) || prop.containsKey(attributeName + LinkedAttributesUtil.MODIFIED_RANGE) ;
    }
}
