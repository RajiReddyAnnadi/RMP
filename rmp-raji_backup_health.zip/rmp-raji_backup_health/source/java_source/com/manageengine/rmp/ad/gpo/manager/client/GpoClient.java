/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.manager.client;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.TableName;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * $Id:$
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class GpoClient {

    public static String getGpoPrivilegeRights(Long domainId, String serializedValue) {
        try {
            ArrayList<String> allValues = new ArrayList<String>();
            allValues = JSONObjectUtil.getObjectFromJsonString(serializedValue.replace("*", ""), allValues.getClass());
            HashMap<String, String> values = getNameFromGuid(allValues, "OBJECT_SID", "OBJECT_NAME", domainId);
            return JSONObjectUtil.toJsonString(values.values());
        } catch (Exception e) {
            LogWriter.gpo.severe("GetGpoPrivilegeRight Webmethod : " + e);
            return new ArrayList<String>().toString();
        }
    }

    public static String getGpoRestrictedGroups(Long domainId, String serializedValue) {
        try {
            ArrayList<ArrayList<String>> attrVals = new ArrayList< ArrayList< String>>();
            attrVals = JSONObjectUtil.getObjectFromJsonString(serializedValue, attrVals.getClass());
            ArrayList<String> parsedAttrID = new ArrayList<String>();
            for (ArrayList<String> vals : attrVals) {
                for (int i = 0; i < vals.size(); i++) {
                    String[] splitSIDs = (i == 2) ? JSONObjectUtil.getObjectFromJsonString(vals.get(i), String[].class) : new String[]{vals.get(i)};
                    for (String splitSID : splitSIDs) {
                        if (splitSID.startsWith("*")) {
                            parsedAttrID.add(splitSID.substring(1));
                        }
                    }
                }
            }
            String serializedAttrVal = JSONObjectUtil.toJsonString(attrVals);
            HashMap<String, String> data = getNameFromGuid(parsedAttrID, "OBJECT_SID", "OBJECT_NAME", domainId);
            for (int i = 0; i < parsedAttrID.size(); i++) {
                String guid = parsedAttrID.get(i).toUpperCase();
                if (data.containsKey(guid)) {
                    serializedAttrVal = serializedAttrVal.replace("*" + guid, data.get(guid));
                }
            }
            //serializedAttrVal = System.Text.RegularExpressions.Regex.Replace(serializedAttrVal, "\\*", "");
            return serializedAttrVal;
        } catch (Exception e) {
            LogWriter.gpo.severe("GetGpoRestrictedGroup Webmethod : " + e);
            return "[]";
        }
    }

    public static String getGpoLinks(Long domainID, String serializedValue) {
        try {
            ArrayList<String> parsedAttrID = new ArrayList<String>();
            String[] vals = serializedValue.split("([)|(])", -1);
            for (String val : vals) {
                try {
                    String objID = val.substring(11, 36);
                    parsedAttrID.add(objID.toUpperCase());
                } catch (Exception e) {
                    LogWriter.gpo.severe("GetGpoLinks Webmethod : " + e);
                }
            }
            HashMap<String, String> data = getNameFromGuid(parsedAttrID, "OBJECT_GUID", "OBJECT_NAME", domainID);
            for (int i = 0; i < parsedAttrID.size(); i++) {
                if (data.containsKey(parsedAttrID.get(i))) {
                    parsedAttrID.set(i, data.get(parsedAttrID.get(i)));
                }
            }
            return JSONObjectUtil.toJsonString(parsedAttrID.toArray());
        } catch (Exception e) {
            LogWriter.gpo.severe("GetGpoLinks Webmethod : " + e);
            return "[]";
        }
    }

    public static HashMap<String, String> getNameFromGuid(ArrayList<String> valList, String colNameGet, String colNamePut, Long domainId) {
        HashMap<String, String> values = new HashMap<String, String>();
        try {
            SelectQuery query1 = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId));
            Criteria criteria1 = new Criteria(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, colNameGet), valList.toArray(), QueryConstants.IN);
            query1.setCriteria(criteria1);
            query1.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId, "*"));
            DataObject dataObject1 = DataAccess.get(query1);
            if (!dataObject1.isEmpty()) {
                Iterator iterator1 = dataObject1.getRows(TableName.RMP_OBJ_META_VER_INFO+"_"+domainId);
                while (iterator1.hasNext()) {
                    Row row1 = (Row) iterator1.next();
                    values.put(row1.get(colNameGet).toString().toUpperCase(), row1.get(colNamePut).toString());
                }
            }
        } catch (Exception e) {
            LogWriter.gpo.severe("GetGpoLinks Webmethod : " + e);
        }
        return values;
    }
}

//ignoreI18n_end
