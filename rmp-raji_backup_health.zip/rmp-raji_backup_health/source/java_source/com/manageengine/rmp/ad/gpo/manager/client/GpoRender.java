/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.manager.client;

import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.RmpConstants;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

/**
 * $Id$
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class GpoRender extends HttpServlet {

    public GpoRender() {
        super();
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            JSONObject reqParams = new JSONObject(request.getParameter("req"));//NO I18N
            response.setContentType(RmpConstants.CONTENT_TYPE);
            Long domainId = Long.valueOf(reqParams.get("domainId").toString());
            Integer multiVal = reqParams.getInt("multiVal");//NO I18N
            String serializedValue = reqParams.get("serializedValue").toString();//NO I18N
            String result;
            switch (multiVal) {
                case 1:
                    result = GpoClient.getGpoPrivilegeRights(domainId, serializedValue);
                    break;
                case 2:
                    result = GpoClient.getGpoRestrictedGroups(domainId, serializedValue);
                    break;
                case 3:
                    result = GpoClient.getGpoLinks(domainId, serializedValue);
                    break;
                default:
                    result = null;
            }
            response.getWriter().println(result);
        } catch (Exception e) {
            LogWriter.general.severe("GpoRender exception: " + e + LogWriter.getStackTrace(e));//NO I18N
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

//ignoreI18n_end