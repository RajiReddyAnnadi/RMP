/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
//ignoreI18n_start
package com.manageengine.rmp.ad.backup;

import com.manageengine.me.util.JSONObjectUtil;
import static com.manageengine.rmp.ad.backup.BackupImpl.compareChanges;
import com.manageengine.rmp.ad.gpo.manager.GpoUtil;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.Level;

import com.manageengine.rmp.ad.gpo.manager.GpoLinksUtil;
import com.manageengine.rmp.ad.rangedattributes.BackLinkAttrManager;
import com.manageengine.rmp.ad.rangedattributes.ForwardLink;
import com.manageengine.rmp.ad.rangedattributes.LinkType;
import com.manageengine.rmp.ad.rangedattributes.LinkedAttributesUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.RmpConstants;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.dataobjects.LdapAttribute;
import com.manageengine.rmp.util.LdapUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

interface Delegate 
{
    boolean invoke(Properties properties, BackupObject backupObject, BackupObject lastSnapshot, BackupImpl backupImpl);
}

public class BackupSpecial 
{
    public static HashMap<Integer, Delegate> handler = new HashMap<Integer, Delegate>();

    static 
    {
        handler.put(LdapAttribute.distinguishedName.ldapAttributeId, new Delegate() 
        {
            @Override
            public boolean invoke(Properties properties, BackupObject backupObject, BackupObject lastSnapshot, BackupImpl backupImpl) 
            {
                try 
                {
                    if (LdapUtil.isDeletedObjectContainer(LdapUtil.getParentCanonical(backupObject.distinguishedName))) //Todo:directly check whether deleted object DN ends with deleted object container's dn
                    {
                        return true;
                    }
                    else if (!backupObject.ouNam.equals(lastSnapshot.ouNam)) 
                    {
                        return true;
                    }
                    else if (lastSnapshot.ouId == null)
                    {
                        return true;
                    } 
                    else if (properties == null) 
                    {
                        return true;
                    } 
                    else if (backupObject.objTyp == ObjectType.DnsNode && !LdapUtil.isDeletedObjectContainer(LdapUtil.getParentCanonical(backupObject.distinguishedName)))
                    {
                        return true;
                    } 
                    else if (!backupObject.ouId.equals(lastSnapshot.ouId)) 
                    {
                        return true;
                    }
                } 
                catch (Exception e) 
                {
                    LogWriter.backup.severe("BackupSpecial DN_Handler " + e);
                }
                return false;
            }
        });

        handler.put(LdapAttribute.Gpo.ldapAttributeId, new Delegate() 
        {
            @Override
            public boolean invoke(Properties properties, BackupObject backupObject, BackupObject lastSnapshot, BackupImpl backupImpl) 
            {
                try 
                {
                    if(!LdapUtil.isObjectDeleted(BackupUtil.getString(properties, "distinguishedName"))){
                        if (BackupUtil.getSingleValue(properties, "versionNumber") != null) //Not Deleted
                        {
                            if(backupImpl.isFullSync && !backupObject.isDeleted)
                            {
                                GpoUtil.deleteGpoBackupDirInFullSync(backupImpl.domainId, backupObject.objId.toString());
                            }
                        backupImpl.gpoBackup.initBackupGpos(backupObject, lastSnapshot); //Enable GPO Backup
                        }
                    }
                }
                catch (Exception e) 
                {
                    LogWriter.backup.log(Level.SEVERE, "BackupSpecial LdapAttribute.Gpo_Handler {0}", e);
                }
                return false;
            }
        });
        
        handler.put(LdapAttribute.gpLink.ldapAttributeId, new Delegate()
        {
            @Override
            public boolean invoke(Properties properties, BackupObject backupObject, BackupObject lastSnapshot, BackupImpl backupImpl) 
            {
                try 
                {
                    if (!backupImpl.isInitBackup && properties.containsKey("isDeleted")) //&& isdeleted != null
                    {
                        Boolean isdeleted = BackupUtil.getBoolean(properties, "isDeleted");
                        if (isdeleted != null && isdeleted == true)  
                        {
                            LogWriter.backup.log(Level.INFO, " properties :{0}", properties.toString());
                            if(lastSnapshot.linkId != null)
                            {
                                GpoLinksUtil.updateDeletedLinks(backupObject, lastSnapshot, properties, backupImpl.gpFrontLinkManager, backupImpl);
                            }
                        } 
                        else if (isdeleted == null || isdeleted == false)
                        {
                            if(GpoLinksUtil.checkLinksBackup(properties))
                            {
                                backupImpl.gpFrontLinkManager.updateFrontLinks(properties, backupObject, lastSnapshot);
                                backupImpl.updateRangedAttrBackupStatus(backupImpl.gpFrontLinkManager.frontLinkMetaInfo.size());
                            }
                            else if (!backupImpl.gpFrontLinkManager.recycledRangedObjects.containsKey(backupObject.objId.toString()) && LdapUtil.isRecycleBinEnabled(backupImpl.domainName)) // dont think we need this check
                            {
                                backupImpl.gpFrontLinkManager.recycledRangedObjects.put(backupObject.objId.toString(), backupObject);
                            }
                        }
                    } 
                    else if (!lastSnapshot.isDeleted) 
                    {
                        backupImpl.gpFrontLinkManager.updateFrontLinks(properties, backupObject, lastSnapshot);
                        backupImpl.updateRangedAttrBackupStatus(backupImpl.gpFrontLinkManager.frontLinkMetaInfo.size());
                    } 
                    else 
                    {
                        for (ForwardLink forwardLink : ForwardLink.values()) 
                        {
                            if (forwardLink.linkId != ForwardLink.none.linkId) 
                            {
                                if (properties.containsKey(forwardLink.getAttributeName() + LinkedAttributesUtil.ADDED_RANGE)) 
                                {
                                    Properties linkGuidVsDn = new Properties();
                                    ArrayList<String> addedMembersDn = (ArrayList<String>) properties.get(forwardLink.getAttributeName() + LinkedAttributesUtil.ADDED_RANGE);
                                    {
                                        linkGuidVsDn = LinkedAttributesUtil.getGuidForLinks(addedMembersDn, backupImpl.backupUpdater.domainId, backupImpl.domainName, false, backupImpl.gpFrontLinkManager.allObjects,backupImpl.backupUpdater.backupId);
                                    }
                                    Iterator<Map.Entry<Object, Object>> iter = linkGuidVsDn.entrySet().iterator();
                                    while (iter.hasNext()) 
                                    {
                                        Map.Entry<Object, Object> property = iter.next();
                                        backupImpl.backupUpdater.updateLinkAttrInfo(forwardLink.linkId, backupImpl.backupUpdater.backupId, LinkType.Removed.memberTypeId, backupObject.objId.toString(), (String) property.getKey());
                                    }
                                }
                            }
                        }
                    }
                } 
                catch (Exception e) 
                {
                    e.printStackTrace();
                    LogWriter.backup.log(Level.SEVERE, "BackupSpecial LdapAttribute.GpoBackLinks {0}", e);
                }
                return false;
            }
        });

        
        handler.put(LdapAttribute.Other.ldapAttributeId, new Delegate() {
            @Override
            public boolean invoke(Properties properties, BackupObject backupObject,
                    BackupObject lastSnapshot, BackupImpl backupImpl) {
                try {
                    if ("rangedAttr".equalsIgnoreCase(backupImpl.orgObjectType)) {
                        if (!backupImpl.isInitBackup && properties.containsKey("isDeleted")) {//&& isdeleted != null
                            Boolean isdeleted = BackupUtil.getBoolean(properties, "isDeleted");
                            if ((isdeleted != null && isdeleted == true) || (!LdapUtil.isObjectDeleted(lastSnapshot.oldDn) && backupObject.isDeleted == false && !LdapUtil.isRecycleBinEnabled(backupImpl.domainName))) {
                                LogWriter.backup.info("  :" + properties.toString());
//                                if(!backupImpl.forwardLinkManager.deletedRangedObjects.containsKey(backupObject.objId.toString()))
//                                {
//                                    backupImpl.forwardLinkManager.deletedRangedObjects.put(backupObject.objId.toString(), new ArrayList<BackupObject>());
//                                    backupImpl.forwardLinkManager.deletedRangedObjects.get(backupObject.objId.toString()).add(backupObject);
//                                    backupImpl.forwardLinkManager.deletedRangedObjects.get(backupObject.objId.toString()).add(lastSnapshot);
//                                }
                                if(lastSnapshot.linkId!=null) {
                                    LinkedAttributesUtil.updateDeletedLinks(backupObject, lastSnapshot,properties, backupImpl.forwardLinkManager, backupImpl);
                                }
                            } else if ((isdeleted == null || isdeleted == false) && LdapUtil.isObjectDeleted(lastSnapshot.oldDn)) {
                                //LinkedAttributesUtil.updateRecycledLinks(backupObject,  backupImpl.forwardLinkManager, backupImpl);
                                if (!backupImpl.forwardLinkManager.recycledRangedObjects.containsKey(backupObject.objId.toString()) && LdapUtil.isRecycleBinEnabled(backupImpl.domainName)) // dont think we need this check
                                {
                                    backupImpl.forwardLinkManager.recycledRangedObjects.put(backupObject.objId.toString(), backupObject);
                                }
                                
                            }
                        } else if (!lastSnapshot.isDeleted) {
                            backupImpl.forwardLinkManager.updateFrontLinks(properties, backupObject, lastSnapshot);
                            backupImpl.updateRangedAttrBackupStatus(backupImpl.forwardLinkManager.frontLinkMetaInfo.size());   
                           
                        } else {
                            for (ForwardLink forwardLink : ForwardLink.values()) {
                                if (forwardLink.linkId != ForwardLink.none.linkId) {
                                    if (properties.containsKey(forwardLink.getAttributeName() + LinkedAttributesUtil.ADDED_RANGE)) {
                                        Properties linkGuidVsDn = new Properties();
                                        ArrayList<String> addedMembersDn = (ArrayList<String>) properties.get(forwardLink.getAttributeName() + LinkedAttributesUtil.ADDED_RANGE);
                                        {
                                            linkGuidVsDn = LinkedAttributesUtil.getGuidForLinks(addedMembersDn, backupImpl.backupUpdater.domainId, backupImpl.domainName, false, backupImpl.forwardLinkManager.allObjects,backupImpl.backupUpdater.backupId);
                                        }
                                        Iterator<Map.Entry<Object, Object>> iter = linkGuidVsDn.entrySet().iterator();
                                        while (iter.hasNext()) {
                                            Map.Entry<Object, Object> property = iter.next();
                                            backupImpl.backupUpdater.updateLinkAttrInfo(forwardLink.linkId, backupImpl.backupUpdater.backupId, LinkType.Removed.memberTypeId, backupObject.objId.toString(), (String) property.getKey());
                                        }
                                    }
                                }
                            }
                        }
                    } else if(backupImpl.orgObjectType.endsWith("GPLinksAttr")) {
                       BackupSpecial.handler.get(LdapAttribute.gpLink.ldapAttributeId).invoke(properties, backupObject, lastSnapshot, backupImpl);
                    }   else if ("bitlocker".equalsIgnoreCase(backupImpl.orgObjectType)) {
                        backupImpl.bitLocker.addBitLockerObject(properties, backupImpl, backupObject);
                    }
                    else if("bitlocker".equalsIgnoreCase(backupImpl.orgObjectType)){
                        BackupSpecial.handler.get(LdapAttribute.gpLink.ldapAttributeId).invoke(properties, backupObject, lastSnapshot, backupImpl);
                    }
                    else if(backupImpl.orgObjectType.equalsIgnoreCase("primaryGroupAttr")){
                        BackupSpecial.handler.get(LdapAttribute.primaryGroup.ldapAttributeId).invoke(properties, backupObject, lastSnapshot, backupImpl);
                        
                    }

                } catch (Exception e) {
                    LogWriter.backup.log(Level.SEVERE, "BackupSpecial other", e);
                    e.printStackTrace();
                }
                return false;
            }
        });
        
        handler.put(LdapAttribute.primaryGroup.ldapAttributeId,new Delegate(){
          @Override
            public boolean invoke(Properties properties, BackupObject backupObject,
                    BackupObject lastSnapshot, BackupImpl backupImpl) 
            {
                boolean isdeleted=false;
                if(properties.containsKey("isDeleted")){
                     Boolean isDeletedValue = BackupUtil.getBoolean(properties, "isDeleted");
                     if (isDeletedValue != null && isDeletedValue == true){
                    isdeleted=true;
                     }
                }
                Integer primaryGroupId=BackupUtil.getInteger(properties, "primaryGroupId");
                backupImpl.primaryGroupManager.addPrimaryGroup(backupImpl,primaryGroupId,backupObject,isdeleted);
                
                return false;
            }
        
        });
        
        handler.put(LdapAttribute.memberOf.ldapAttributeId, new Delegate() 
        {
            @Override
            public boolean invoke(Properties properties, BackupObject backupObject,
                    BackupObject lastSnapshot, BackupImpl backupImpl) 
            {
                if(properties.containsKey("orgObjectType") && properties.get("orgObjectType").equals("primaryGroupAttr")){
                    return true;
                }
                return BackLinkAttrManager.updateBackLinkCount(LdapAttribute.memberOf.ldapAttributeId, properties, lastSnapshot);
            }
        });
        
        handler.put(LdapAttribute.gpBackLinks.ldapAttributeId, new Delegate() 
        {
            @Override
            public boolean invoke(Properties properties, BackupObject backupObject,
                    BackupObject lastSnapshot, BackupImpl backupImpl) 
            {
                return BackLinkAttrManager.updateBackLinkCount(LdapAttribute.gpBackLinks.ldapAttributeId, properties, lastSnapshot);
            }
        });
        
        handler.put(LdapAttribute.managedObjects.ldapAttributeId, new Delegate() 
        {
            @Override
            public boolean invoke(Properties properties, BackupObject backupObject,
                    BackupObject lastSnapshot, BackupImpl backupImpl) 
            {
                return BackLinkAttrManager.updateBackLinkCount(LdapAttribute.managedObjects.ldapAttributeId, properties, lastSnapshot);
            }
        });
        
        handler.put(LdapAttribute.directReports.ldapAttributeId, new Delegate()
        {
            @Override
            public boolean invoke(Properties properties, BackupObject backupObject,
                    BackupObject lastSnapshot, BackupImpl backupImpl) 
            {
                return BackLinkAttrManager.updateBackLinkCount(LdapAttribute.directReports.ldapAttributeId, properties, lastSnapshot);
            }
        });
        
        handler.put(LdapAttribute.Co.ldapAttributeId, new Delegate() 
        {
            @Override
            public boolean invoke(Properties properties, BackupObject backupObject, BackupObject lastSnapshot, BackupImpl backupImpl) 
            {
                try 
                {
                    if (properties.containsKey("countryCode")) 
                    {
                        Object propertyVal = BackupUtil.getSingleValue(properties, "countryCode");
                        String bkpAttrId = "b" + LdapAttribute.CountryCode.ldapAttributeId;
                        Object oldValue = JSONObjectUtil.getValue(lastSnapshot.data, bkpAttrId);
                        if (compareChanges(oldValue, propertyVal, false, LdapAttribute.CountryCode.ldapAttributeId, backupObject)) 
                        {
                            String oldAttrId = "o" + LdapAttribute.CountryCode.ldapAttributeId;
                            backupObject.data.put(bkpAttrId, propertyVal);
                            if (lastSnapshot.changeMask.get(LdapAttribute.Co.ldapAttributeId)) 
                            {
                                backupObject.data.put(oldAttrId, oldValue);
                                lastSnapshot.data.put(oldAttrId, oldValue);
                            }
                            lastSnapshot.data.put(bkpAttrId, propertyVal);
                        }
                    }
                } 
                catch (Exception e) 
                {
                    LogWriter.backup.log(Level.SEVERE, "BackupSpecial LdapAttribute.Country_Handler {0}", e);
                }
                return true;
            }
        });

        handler.put(LdapAttribute.UserAccountControl.ldapAttributeId, new Delegate() 
        {
            @Override
            public boolean invoke(Properties properties, BackupObject backupObject, BackupObject lastSnapshot, BackupImpl backupImpl) 
            {
                try 
                {
                    String oldAttrId = RmpConstants.BACKUP_VALUE_PREFIX + LdapAttribute.UserAccountControl.ldapAttributeId;
                    int uacValue = BackupUtil.getInteger(properties, "userAccountControl");
                    int uacResult = uacValue & 2;
                    if (!backupImpl.isInitBackup && lastSnapshot.data != null && lastSnapshot.data.has(oldAttrId)) 
                    {
                        int oldUacValue = Integer.parseInt((String) lastSnapshot.data.get(oldAttrId));
                        if ((oldUacValue & 2) != uacResult) 
                        {
                            enableDisableToggle(backupImpl, backupObject, lastSnapshot, uacResult, -1);
                        }
                    }
                    else 
                    {
                        enableDisableToggle(backupImpl, backupObject, lastSnapshot, uacResult, 0);
                    }
                } 
                catch (Exception e) 
                {
                    LogWriter.backup.log(Level.SEVERE, "BackupSpecial LdapAttribute.UAC {0}", e);
                }
                return true;
            }
        });
        
        handler.put(LdapAttribute.msExchModeratedObjectsBL.ldapAttributeId, new Delegate() 
        {
            @Override
            public boolean invoke(Properties properties, BackupObject backupObject,
                    BackupObject lastSnapshot, BackupImpl backupImpl) 
            {
                return BackLinkAttrManager.updateBackLinkCount(LdapAttribute.msExchModeratedObjectsBL.ldapAttributeId, properties, lastSnapshot);
            }
        });
    }

    private static void enableDisableToggle(BackupImpl backupImpl, BackupObject backupObject, BackupObject lastSnapshot, int uacResult, int trackCount) 
    {
        backupObject.isDisabled = (uacResult == 2);
        backupImpl.backupTracker.updateDisableCount(backupObject, trackCount);
        backupImpl.threadBackupTracker.updateDisableCount(backupObject, trackCount);
        if (backupImpl.ouConfig == null) 
        {
            backupImpl.ouConfig = backupImpl.getOuConfig(backupObject, lastSnapshot);
        }
        if (!backupImpl.trackDisabledObjects && backupImpl.ouConfig.toBackup) 
        {
            backupObject.isBackupSet = !backupObject.isDisabled;
            if (!backupObject.isBackupSet)
            {
                backupObject.isObjNewlySelected = false;
            }
        }
    }
}
//ignoreI18n_end
