package com.manageengine.rmp.ad.backup;

import com.manageengine.rmp.ad.adsync.SyncFilter;
import com.manageengine.rmp.licensing.FunctionalityModel;
import com.manageengine.rmp.licensing.SubscriptionModel;
import com.manageengine.rmp.settings.DomainSettings;
import com.manageengine.rmp.workflow.TaskManager;
import com.manageengine.rmp.workflow.WorkflowManager;
import org.json.JSONObject;
/**
 *
 * @author suganya-1815
 */
//ignoreI18n_start
public class BackupManager extends WorkflowManager implements TaskManager{
    @Override
    public void startTask(long operationId, Object obj,String loginName) {
        try {
            JSONObject jsonObject = new JSONObject(obj.toString());
            if (!SubscriptionModel.checkSubscription(FunctionalityModel.InstantBackup) /*|| LicenseUtil.isObjectLimitExceeded()*/ || DomainSettings.getDomainStatus(jsonObject.getLong("domain")) == 0) {
                onTaskComplete(operationId,loginName);
            } else {
                BackupInitiator.doBackup(jsonObject.getLong("domain"), loginName, SyncFilter.getSyncObjects(), operationId);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onTaskComplete(long operationId,String loginName){
         try{
            super.onTaskComplete(operationId,loginName);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
//ignoreI18n_end
