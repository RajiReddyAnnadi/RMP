//$Id$
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.adsync;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.Table;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;

/**
 *
 * @author lucky-2306
 */
//ignoreI18n_start
public class RMPADSyncConfig {

    public static final String OBJECT_TABLE = "RMPADSyncObjects";
    public static final String ATTRIBUTE_TABLE = "RMPADSyncObjAttributes";

    public static Properties getRMPSyncObjectRow(int objectType) {
        Properties syncObjectRow = new Properties();
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(OBJECT_TABLE));
            Criteria criteria = new Criteria(Column.getColumn(OBJECT_TABLE, "OBJECT_ID"), objectType, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(OBJECT_TABLE, "*"));
            DataObject dataObject = DataAccess.get(query);
            if (!dataObject.isEmpty()) {
                Iterator iterator = dataObject.getRows(OBJECT_TABLE);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    syncObjectRow.put("OBJECT_ID", row.get("OBJECT_ID"));
                    syncObjectRow.put("OBJECT_TYPE", row.get("OBJECT_TYPE"));
                    syncObjectRow.put("SEARCH_STRING", row.get("SEARCH_STRING"));
                    syncObjectRow.put("IS_ENABLED", row.get("IS_ENABLED"));
                    syncObjectRow.put("PRIORITY_ID", row.get("PRIORITY_ID"));
                    syncObjectRow.put("SEARCH_PREFERENCE", row.get("SEARCH_PREFERENCE"));
                }
            }
            return syncObjectRow;
        } catch (Exception e) {
            return syncObjectRow;
        }
    }

    public static HashSet<String> getRMPSyncAttributesRow(int objectType) {
        HashSet<String> syncAttrRows = new HashSet<String>();
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(ATTRIBUTE_TABLE));
            Criteria criteria = new Criteria(Column.getColumn(ATTRIBUTE_TABLE, "OBJECT_ID"), objectType, QueryConstants.EQUAL);
            query.setCriteria(criteria);
            query.addSelectColumn(Column.getColumn(ATTRIBUTE_TABLE, "*"));
            DataObject dataObject = DataAccess.get(query);
            if (!dataObject.isEmpty()) {
                Iterator iterator = dataObject.getRows(ATTRIBUTE_TABLE);
                while (iterator.hasNext()) {
                    Row row = (Row) iterator.next();
                    syncAttrRows.add((String) row.get("ATTRIB_LDAP_NAME"));
                }
            }
            return syncAttrRows;
        } catch (Exception e) {
            return syncAttrRows;
        }
    }
}

//ignoreI18n_end
