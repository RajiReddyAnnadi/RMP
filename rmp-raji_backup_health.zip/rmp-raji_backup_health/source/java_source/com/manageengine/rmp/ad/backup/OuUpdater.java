/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
package com.manageengine.rmp.ad.backup;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.ds.query.UpdateQuery;
import com.adventnet.ds.query.UpdateQueryImpl;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.WritableDataObject;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.RMPCommonUtil;
import com.manageengine.rmp.constants.BackupType;
import com.manageengine.rmp.constants.ChangeType;
import com.manageengine.rmp.constants.OuSelectionType;
import com.manageengine.rmp.constants.RMPCommonFlags;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.oumanager.OUManager;
import com.manageengine.rmp.util.ADObjectsUtil;
import com.manageengine.rmp.util.LdapUtil;

import java.util.Iterator;
import java.util.Properties;
import java.util.UUID;
//ignoreI18n_start
public class OuUpdater {

    public static int changeTypeMask = (ChangeType.Created.maskValue | ChangeType.Added.maskValue | ChangeType.Moved.maskValue | ChangeType.Renamed.maskValue | ChangeType.Deleted.maskValue | ChangeType.ReAdded.maskValue | ChangeType.Recycled.maskValue);
    public String domainName = null;
    public String policiesContainer = null;
    public BackupType backupType;
    public Long domainId;
    
    public OuUpdater(Long domainId, BackupType backupType, String domainName) {
        this.domainId = domainId;
        this.backupType = backupType;
        this.domainName = domainName;
        policiesContainer = domainName + "/System/Policies/";
    }

    public OuConfig update(BackupObject ouObject, OuConfig oldConfig) {
        //ToDo: If new ou is created then we need to select the Ou for backup if its parent is configured for backup
        try {
            if ((ouObject.changeTyp & changeTypeMask) >= 1) {
                OuConfig ouConfig = new OuConfig(ouObject);
                if(ouObject.isDeleted && oldConfig.hasHistory != null && !oldConfig.hasHistory){ //OU created, deleted and backed up for the first time
                   return null;
                }else if(ouObject.changeTyp == ChangeType.Created.maskValue || (oldConfig.hasHistory != null && !oldConfig.hasHistory && !oldConfig.isDeleted)){  //OU newly created
                    LogWriter.backup.info(String.format("OuUpdater.insert <OU Inserted> domainId:%s name:%s loc:%s", ouObject.domainId, ouObject.objNam, ouObject.ouNam));
                    return insertRecord(ouConfig)?ouConfig:null;
                }else{
                    UpdateQuery updateObject = new UpdateQueryImpl(TableName.RMP_OU_INFO);
                    ouConfig.addColumnsToUpdate(oldConfig, updateObject);
                    if (updateObject.getUpdateColumns().size() > 0) {
                        LogWriter.backup.info(String.format("OuUpdater.Update <OU updated> domainId:%s name:%s loc:%s", ouObject.domainId, ouObject.objNam, ouObject.ouNam));
                        Criteria c1 = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "DOMAIN_ID"), ouObject.domainId, QueryConstants.EQUAL);
                        Criteria c2 = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "OBJECT_GUID"), ouObject.objId, QueryConstants.EQUAL);
                        updateObject.setCriteria(c1.and(c2));
                        CommonUtil.getPersistence().update(updateObject);
                        ADObjectsUtil.updateSelectedOUCount(domainId);
                        return ouConfig;
                    }
                }
            }
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("OuUpdater.Update domainId:%s name:%s guid:%s /n excep:%s", ouObject.domainId, ouObject.objNam, ouObject.objId, e));
        }
        return null;
    }

    public Boolean insertRecord(OuConfig ouConfig) {
        try {
            DataObject obj = new WritableDataObject();
            Row rowOUInfo = new Row(TableName.RMP_OU_INFO);
            rowOUInfo.set("DOMAIN_ID", domainId);
            rowOUInfo.set("OBJECT_GUID", ouConfig.objectGuid.toString());
            rowOUInfo.set("PARENT_GUID", ouConfig.parentGuid.toString());
            rowOUInfo.set("CANONICAL_NAME", ouConfig.canonicalName);
            rowOUInfo.set("DISTINGUISHED_NAME", ouConfig.distinguishedName);
            rowOUInfo.set("OBJECT_NAME", ouConfig.name);
            rowOUInfo.set("TO_BACKUP", ouConfig.toBackup);
            rowOUInfo.set("HAS_HISTORY", true);
            rowOUInfo.set("IS_DELETED", ouConfig.isDeleted);
            rowOUInfo.set("HAS_CHILDREN", false);
            rowOUInfo.set("SELECTION_TYPE", OuSelectionType.Child.ordinal());
            obj.addRow(rowOUInfo);
            CommonUtil.getPersistence().add(obj);
            ADObjectsUtil.updateSelectedOUCount(domainId);
            return true;
        } catch (DataAccessException e) {
            LogWriter.backup.severe(String.format("OuUpdater.InsertRecord SE domainId:%s name:%s guid:%s backupType:%s \n excep:%s \n nextExcep:%s \nstack:%s", domainId, ouConfig.name, ouConfig.objectGuid, backupType, e, e.getErrorString(), LogWriter.getStackTrace(e)));
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("OuUpdater.InsertRecord domainId:%s name:%s guid:%s backupType:%s \n excep:%s \nstack:%s", domainId, ouConfig.name, ouConfig.objectGuid, backupType, e, LogWriter.getStackTrace(e)));
        }
        return false;
    }

    public Boolean initialOuSync(Properties properties) {
        String objectName = null;
        UUID objectGuid = null;
        try {
            OuConfig ouConfig = new OuConfig(domainId, properties);
            if (ouConfig.canonicalName.toLowerCase().startsWith(policiesContainer.toLowerCase())) {
                return false;
            }
            insertRecord(ouConfig);
            return true;
        } catch (Exception e) {
            LogWriter.backup.severe(String.format("OuUpdater.InitialOuSync domainId:%s name:%s guid:%s /n excep:%s", domainId, objectName, objectGuid, e));
            LogWriter.backup.severe("OuUpdater.InitialOuSync stack : " + e.getStackTrace());
            return true;
        }
    }
    
    public static Boolean revalidateParentGuids(Long domainId) {
        try {
            SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OU_INFO));
            //query.addSelectColumn(Column.getColumn(RmpConstants.RMP_OU_INFO, "OBJECT_GUID"));
            query.addSelectColumn(Column.getColumn(TableName.RMP_OU_INFO, "*"));
            Criteria domainCriteria = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "DOMAIN_ID"), domainId, QueryConstants.EQUAL);
            Criteria parentGuidCriteria = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "PARENT_GUID"), BackupUtil.emptyGuid.toString(), QueryConstants.EQUAL);
            Criteria nonEmptyCanonicalNameCriteria = new Criteria(Column.getColumn(TableName.RMP_OU_INFO, "CANONICAL_NAME"), "", QueryConstants.NOT_EQUAL);
            query.setCriteria(domainCriteria.and(parentGuidCriteria).and(nonEmptyCanonicalNameCriteria));
            query.addSortColumn(new SortColumn(TableName.RMP_OU_INFO, "CANONICAL_NAME", true));
            DataObject dataObject = CommonUtil.getPersistence().get(query);
            if (dataObject.size(TableName.RMP_OU_INFO) == 1) {
                OUManager.setHasChildren(domainId);
                return true;
            }
            Iterator iterator = dataObject.getRows(TableName.RMP_OU_INFO);
            iterator.next();//skiping the domainRoot node
            int batchCount = 0;
            while (iterator.hasNext()) {
                Row row = (Row) iterator.next();  
                String canonicalName = (String) row.get("CANONICAL_NAME");
                String parentCanoncial = LdapUtil.getParentCanonicalFromChildCanonical(canonicalName);
                UUID parentGuid = BackupUtil.getOuGuid(domainId, parentCanoncial);
                if (!parentGuid.equals(BackupUtil.emptyGuid)) {
                    row.set("PARENT_GUID", parentGuid.toString());
                    dataObject.updateRow(row);
                    batchCount = RMPCommonUtil.batchCommit(++batchCount, RMPCommonFlags.UpdateDataObject.value, dataObject, false);
                }
            }
            if(batchCount != 0){
                RMPCommonUtil.batchCommit(batchCount, RMPCommonFlags.UpdateDataObject.value, dataObject, true);
            }

        } catch (Exception e) {
            LogWriter.backup.severe("OuUpdater.revalidateParentGuids excep: " + e);
            return false;
        }
        OUManager.setHasChildren(domainId);
        return true;
    }
}
//ignoreI18n_end
