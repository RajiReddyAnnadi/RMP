/**
 * $Id$
 */
package com.manageengine.rmp.ad.rangedattributes;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.Query;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.RowHelper;
import com.manageengine.rmp.ad.backup.BackupUpdater;
import com.manageengine.rmp.ad.backup.BackupUtil;
import com.manageengine.rmp.ad.backup.OuConfig;
import com.manageengine.rmp.ad.backup.OuUpdater;
import com.manageengine.rmp.ad.backup.BackupImpl;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.constants.BackupType;
import com.manageengine.rmp.constants.ChangeType;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.OperationType;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.oumanager.OUManager;
import com.manageengine.rmp.recovery.RecoveryManager;
import com.manageengine.rmp.recyclebin.RecycleBinManager;
import com.manageengine.rmp.util.LdapUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import javax.transaction.SystemException;
import org.json.JSONArray;
import org.json.JSONObject;
import com.manageengine.rmp.recovery.RecoveryHandler;
import java.util.Arrays;
import java.util.Enumeration;


/**
 *
 * @author sabareesh-2259
 */
//ignoreI18n_start
public class DnsManager {

    private static final int ADDED = 1, REMOVED = 2, CURRENT = 0, MODIFIED = 3;
    private Long domainId;
    public HashMap<String, ArrayList> DnsZonesHash;
    public HashMap<String, RangedAttrObject> changedZones;

    public DnsManager(Long domainId) {
        DnsZonesHash = new HashMap<>();
        this.domainId = domainId;
        this.changedZones = new HashMap<>();
    }

    public String getParentDn(String distinguishedName) {
        distinguishedName = distinguishedName.replaceFirst("DC=", "haha="); //No I18N
        return distinguishedName.substring(distinguishedName.indexOf("DC="));
    }

    public boolean deletedZonesHandling(Properties prop, BackupType backupType) {

        if (BackupUtil.getString(prop, "distinguishedName").contains("DC=..Deleted-")) {
            if (backupType == BackupType.InitBackup) {
                return false;
            }
            String dn = BackupUtil.getString(prop, "distinguishedName").replace("..Deleted-", "");// No I18N
            ArrayList temp = new ArrayList();
            temp.add(dn);
            prop.put("distinguishedName", temp);
            //prop.setProperty("distinguishedName","[" + BackupUtil.getString(prop,"distinguishedName").replace("..Deleted-", "")+"]");
            ArrayList temp2 = new ArrayList();
            String name = BackupUtil.getString(prop, "name").replace("..Deleted-", "");// No I18N
            temp2.add(name);
            prop.put("name", temp2);
            //prop.setProperty("name", "["+BackupUtil.getString(prop,"name").replace("..Deleted-", "")+"]");  
        }
        return true;
    }
    
    public static void dnsRemoveSerialTimeStamp (String[] record)
    {
        int[] dnsSkipBytes = new int[]
        {
            8, 9, 10, 11, 20, 21, 22, 23
        };
        for (int i = 0; i < record.length; i++)
        {
            String[] bytes = record[i].split(",", -1);
            for (int j : dnsSkipBytes)
            {
                bytes[j] = "0";
            }
            record[i] = Arrays.toString(bytes).replace("[", "").replace("]", "").replace(" ", "");
        }
    }

    public boolean checkDnsNodeIsBackup(Properties prop, BackupType backupType) {
        if (LdapUtil.isObjectDeleted(BackupUtil.getString(prop, "distinguishedName"))) {
            if (backupType == backupType.InitBackup) {
                return false;
            } else {
                if (BackupUtil.getString(prop, "lastKnownParent") != null) {
                    {
                        String lkp = BackupUtil.getString(prop, "lastKnownParent").replace("..Deleted-", "");// No I18N
                        ArrayList temp = new ArrayList();
                        temp.add(lkp);
                        prop.put("lastKnownParent", temp);
                    }
                }
            }
        } else if (prop.containsKey("dNSTombstoned")) {
            if (BackupUtil.getBoolean(prop, "dNSTombstoned")) {
                if (BackupUtil.getBoolean(prop, "dNSTombstoned")) {
                    if (backupType == backupType.InitBackup) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public void updateNodeTable(Long backupId, BackupObject node, BackupUpdater backupUpdater) throws IllegalStateException, SecurityException, SystemException {
        try {
            int changeType = node.changeTyp;
            if (!changedZones.containsKey(node.ouId.toString())) {
                changedZones.put(node.ouId.toString(), new RangedAttrObject(node.ouId.toString(), getParentDn(node.distinguishedName), ObjectType.DnsZone));
                changedZones.get(node.ouId.toString()).metadata = new HashMap<>();
                changedZones.get(node.ouId.toString()).metadata.put(87, new ArrayList<Integer>());
                changedZones.get(node.ouId.toString()).metadata.get(87).add(0);//total
                changedZones.get(node.ouId.toString()).metadata.get(87).add(0);//added
                changedZones.get(node.ouId.toString()).metadata.get(87).add(0);//removed             
                changedZones.get(node.ouId.toString()).metadata.get(87).add(0);//modified  
            }
            if (ChangeType.IsObjectAdded(changeType) || ChangeType.isRecycled(changeType)) {
                // GroupMemberManager.addGroupMemberInfo(domainId, backupId, zone.objId.toString(), changeType, nodeDetails.get(1).toString(), nodeDetails.get(0).toString());
                backupUpdater.updateLinkAttrInfo(87, backupId, (long) ADDED, node.ouId.toString(), node.objId.toString());
                changedZones.get(node.ouId.toString()).metadata.get(87).set(ADDED, (Integer) changedZones.get(node.ouId.toString()).metadata.get(87).get(ADDED) + 1);
                // GroupMemberManager.addGroupMemberInfo(domainId, backupId, zone.objId.toString(), CURRENT, nodeDetails.get(1).toString(), nodeDetails.get(0).toString());
                backupUpdater.updateLinkAttrInfo(87, (long) backupId, (long) CURRENT, node.ouId.toString(), node.objId.toString());
            } else if (ChangeType.isDeleted(changeType)) {
                removeFromCurrent(domainId, node.ouId.toString(), node.objId.toString());
                backupUpdater.updateLinkAttrInfo(87, backupId, (long) REMOVED, node.ouId.toString(), node.objId.toString());
                changedZones.get(node.ouId.toString()).metadata.get(87).set(REMOVED, (Integer) changedZones.get(node.ouId.toString()).metadata.get(87).get(REMOVED) + 1);
                // GroupMemberManager.removeGroupMemberInfo(domainId, zone.objId.toString(), nodeDetails.get(0).toString());
            } else {
                // GroupMemberManager.addGroupMemberInfo(domainId, backupId, zone.objId.toString(), changeType, nodeDetails.get(1).toString(), nodeDetails.get(0).toString());
                backupUpdater.updateLinkAttrInfo(87, backupId, (long) MODIFIED, node.ouId.toString(), node.objId.toString());
                changedZones.get(node.ouId.toString()).metadata.get(87).set(MODIFIED, (Integer) changedZones.get(node.ouId.toString()).metadata.get(87).get(MODIFIED) + 1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateZoneChangeMask(BackupUpdater backupUpdater, BackupImpl rmpbackupimpl) {
        try {
            for (String zoneId : changedZones.keySet()) {
                SelectQuery sel = new SelectQueryImpl((Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_"+domainId)));
                Criteria crit = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_"+domainId, "OBJECT_GUID"), zoneId, QueryConstants.EQUAL);
                sel.addSelectColumn(Column.getColumn(null, "*"));
                sel.setCriteria(crit);
                int total = 0;
                DataObject obj = CommonUtil.getPersistence().get(sel);
                if (!obj.isEmpty()) {
                    Row row = obj.getFirstRow(TableName.RMP_OBJ_CURRENT_INFO + "_"+domainId);
                    JSONObject jobj = new JSONObject(row.get("LINKS_DATA").toString());
                    if (jobj.has("b87")) {
                        //ArrayList metadata = (ArrayList) jobj.get("b87");
                        JSONArray metadata = new JSONArray(jobj.get("b87").toString());
                        total = (Integer) metadata.get(0);
                    }
                } else {
                    LogWriter.backup.severe("updateZoneChangeMask:-dataobj empty,objId" + zoneId); // No I18N
                }
                total = total + (Integer) changedZones.get(zoneId).metadata.get(87).get(ADDED);
                total = total - (Integer) changedZones.get(zoneId).metadata.get(87).get(REMOVED);
                total = (total < 0)?0:total;
                changedZones.get(zoneId).metadata.get(87).set(CURRENT, total);
            }
            backupUpdater.updateRangedAttrMetadatainObj(changedZones, rmpbackupimpl, true, rmpbackupimpl.isInitBackup);
            changedZones.clear();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void removeFromCurrent(long domainId, String zoneId, String nodeId) {
        try {
            Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "LINKS_TYPE"),  CURRENT, QueryConstants.EQUAL); //No I18N
            //criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "LINKS_TYPE"), CURRENT, QueryConstants.EQUAL); //No I18N
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "FRONTLINK_OBJECT_GUID"), zoneId, QueryConstants.EQUAL); //No I18N
            criteria = criteria.and(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKLINK_OBJECT_GUID"), nodeId, QueryConstants.EQUAL); //No I18N
            CommonUtil.getPersistence().delete(criteria);
        } catch (DataAccessException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void addtoOUTable(OuUpdater ouUpdater, BackupObject zone) {
        try {
            OUManager oumanager = new OUManager();
            if ((oumanager.getOuDn(domainId, zone.objId.toString()) == null) && !zone.isDeleted) {
                OuConfig ouConfig = new OuConfig(zone);
                ouUpdater.insertRecord(ouConfig);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public Properties RestoreZone(long domainId,long backupId,String zoneId,long operationId,RecoveryHandler recoveryHandler)
    {
        Properties restoreResult = new Properties();
        long added=0,removed=0,modified=0;
        try
        {
            RecoveryManager recoveryManager = new RecoveryManager(domainId, OperationType.Revert, operationId);
            ArrayList<String> nodesToDelete = new ArrayList<>();
            Properties domainDetails = RMPDomainHandler.getDomainDetailsById(domainId);
            int[] restoreAtt = new int[]{47, 82, 84};
            HashMap<String, Properties> restoreDetails = new HashMap<String, Properties>();
            SelectQuery sel = new SelectQueryImpl(Table.getTable(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId));
            sel.addSelectColumn(Column.getColumn(null, "*"));
            Criteria crit = new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "FORWARD_LINK_ID"), 87, QueryConstants.EQUAL);
            crit = crit.and(new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID"), backupId, QueryConstants.GREATER_THAN));
            crit = crit.and(new Criteria(Column.getColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "FRONTLINK_OBJECT_GUID"), zoneId, QueryConstants.EQUAL));
            sel.addSortColumn(new SortColumn(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId, "BACKUP_ID", true));//NO I18N
            sel.setCriteria(crit);
            DataObject obj = CommonUtil.getPersistence().get(sel);
            if (!obj.isEmpty()) {
                Iterator iter = obj.getRows(TableName.RMP_RANGED_ATTRIBUTES+"_"+domainId);
                while (iter.hasNext()) {
                    Row row = (Row) iter.next();
                    String nodeId = row.get("BACKLINK_OBJECT_GUID").toString();
                    long bkpId = Long.parseLong(row.get("BACKUP_ID").toString());
                    if (!restoreDetails.containsKey(nodeId)) {
                        restoreDetails.put(nodeId, new Properties());
                    }
                    int linkType = Integer.parseInt(row.get("LINKS_TYPE").toString());
                    if (linkType == ADDED) {
                        if (restoreDetails.get(nodeId).containsKey("endchanges")) {
                            continue;
                        }
                        restoreDetails.get(nodeId).clear();
                        restoreDetails.get(nodeId).put("endchanges", "");
                        restoreDetails.get(nodeId).put("added", "");
                        removed++;
                        //delete the node here
                        
                        //new RecycleBinManager().deleteObject(domainDetails, nodeDn, ObjectType.DnsNode);
                        nodesToDelete.add(nodeId);
                        if(nodesToDelete.size() > 1000)
                        {
                            deleteNodes(domainDetails,nodesToDelete,recoveryHandler);                        
                            nodesToDelete.clear();
                        }
                    }
                    else if(linkType == MODIFIED)
                    {
                        if(restoreDetails.get(nodeId).containsKey("endchanges"))
                        {
                            continue;
                        }
                        SelectQuery sel2 = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_VER_INFO+"_"+domainId));
                        sel2.addSelectColumn(Column.getColumn(null, "*"));
                        Criteria crt = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "BACKUP_ID"), bkpId, QueryConstants.EQUAL);
                        crt = crt.and(new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "OBJECT_GUID"), nodeId, QueryConstants.EQUAL));
                        sel2.setCriteria(crt);
                        DataObject dataObj = CommonUtil.getPersistence().get(sel2);
                        if (!dataObj.isEmpty()) {
                            Row objrow = dataObj.getRow(TableName.RMP_OBJ_VER_INFO+"_"+domainId);
                            String bkId = objrow.get("BACKUP_ID").toString();//NO I18N
                            String changeId = objrow.get("CHANGE_ID").toString();
                            bkId = bkId + ":" + changeId;
                            //byte[] cmask = (byte[])objrow.get("CHANGE_MASK");
                            //BitSet changemask = row.get//BitSetUtil.fromByteArray(cmask);
                            RowHelper rowhelp = new RowHelper(objrow);
                            BitSet changemask = rowhelp.getBitSet("CHANGE_MASK");//NO I18N
                            JSONArray modifyAttributes = new JSONArray();
                            //JSONObject changeData = JSONObjectUtil.toJsonObject(objrow.get("CHANGE_DATA").toString());
                            for (int att : restoreAtt) {
                                if (changemask.get(att)) {
                                    if (!restoreDetails.get(nodeId).containsKey(att)) {
                                        modifyAttributes.put(att);
                                        restoreDetails.get(nodeId).setProperty(Integer.toString(att), bkId);
                                        //call restore code here restore to O+att value for bkId
                                    }
                                }
                            }
                            if (modifyAttributes.length() > 0) {
                                JSONArray jarr = new JSONArray();
                                jarr.put(nodeId);
                                jarr.put(ObjectType.DnsNode.maskValue);
                                JSONObject modifyAttributesJSON = new JSONObject();
                                modifyAttributesJSON.put(bkId, modifyAttributes);
                                jarr.put(modifyAttributesJSON);
                                modified++;
                                recoveryManager.restore(jarr);
                            }

                        } else {
                            LogWriter.recovery.severe("getZoneRestoreDetails version info dataobj is empty");//NO I18N
                        }

                    } else if (linkType == REMOVED) {
                        if (restoreDetails.get(nodeId).containsKey("endchanges")) {
                            continue;
                        }
                        restoreDetails.get(nodeId).clear();
                        restoreDetails.get(nodeId).put("endchanges", "");
                        restoreDetails.get(nodeId).put("deleted", "");
                        // recover deleted nodes here.
                        added++;
                        recoverDeletedNode(domainId, backupId, nodeId, restoreAtt, operationId);
                    }
                }
                if(!nodesToDelete.isEmpty())
                {
                    deleteNodes(domainDetails,nodesToDelete,recoveryHandler);
                    nodesToDelete.clear();
                }
            }
            else
            {
                LogWriter.recovery.severe("getZoneRestoreDetails dataobj is empty");//NO I18N
            }
            //return restoreDetails;
//            return true;
            restoreResult.put("result", true);
            restoreResult.put("added", added);
            restoreResult.put("removed", removed);
            restoreResult.put("modified", modified);
            return restoreResult;
        } catch (Exception e) {
            e.printStackTrace();
            restoreResult.put("result", false);
            restoreResult.put("added", added);
            restoreResult.put("removed", removed);
            restoreResult.put("modified", modified);
            return restoreResult;
        }
    }
    
    public void deleteNodes(Properties domainDetails,ArrayList<String> nodesToDelete,RecoveryHandler recoveryHandler)
    {
        Properties nodeGuids = new Properties(); //LinkedAttributesUtil.getGuidForLinks(nodesToDelete, domainId);
        
        try
        {
        SelectQuery query = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId));
        Criteria criteria = (new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_GUID"), nodesToDelete.toArray(), QueryConstants.IN));
        query.setCriteria(criteria);
        query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "CURRENTINFO_ID"));
        query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_GUID"));
        query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_DN"));
        query.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "OBJECT_TYPE"));
        String queryString = RelationalAPI.getInstance().getSelectSQL(query);
        DataObject dataObject = DataAccess.get(query);
        if (!dataObject.isEmpty())
        {
            Iterator iterator = dataObject.getRows(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId);
            while (iterator.hasNext())
            {
                Row row = (Row) iterator.next();
                nodeGuids.put(row.get("OBJECT_GUID").toString(), row.get("OBJECT_DN").toString());
            }
        }
        
        
        Enumeration<Object> nodeslist = nodeGuids.elements();
        while(nodeslist.hasMoreElements())
        {
            String nodeDn = (String)nodeslist.nextElement();
            new RecycleBinManager().deleteObject(domainDetails, nodeDn, ObjectType.DnsNode,recoveryHandler, null);
        }
        }
        catch(Exception e)
        {            
            e.printStackTrace();
        }
    }

    public void recoverDeletedNode(long domainId, long backupId, String objectGuid, int[] attarray, long operationId) {
        try {
            RecoveryManager recoveryManager = new RecoveryManager(domainId, OperationType.Restore, operationId);
            JSONObject restoreAtt = new JSONObject();
            SelectQuery sel = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_VER_INFO+"_"+domainId));
            sel.addSelectColumn(Column.getColumn(null, "*"));
            Criteria crit = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "OBJECT_GUID"), objectGuid, QueryConstants.EQUAL);
            crit = crit.and(new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "BACKUP_ID"), backupId, QueryConstants.LESS_EQUAL));
            sel.addSortColumn(new SortColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "BACKUP_ID", false));//NO I18N
            sel.setCriteria(crit);
            DataObject obj = CommonUtil.getPersistence().get(sel);
            ArrayList<Integer> addedatt = new ArrayList<>();
            ArrayList<Integer> attributes = new ArrayList<>();
            for (int att : attarray) {
                attributes.add(att);
            }
            if (!obj.isEmpty()) {
                Iterator iter = obj.getRows(TableName.RMP_OBJ_VER_INFO+"_"+domainId);
                while (iter.hasNext()) {
                    Row row = (Row) iter.next();
                    RowHelper rowhelp = new RowHelper(row);
                    BitSet changemask = rowhelp.getBitSet("CHANGE_MASK");//NO I18N
                    String bkpId = row.get("BACKUP_ID").toString() + ":" + row.get("CHANGE_ID").toString();
                    for (int att : attributes) {
                        if (changemask.get(att)) {
                            if (restoreAtt.has(bkpId)) {
                                restoreAtt.getJSONArray(bkpId).put(att);
                            } else {
                                restoreAtt.put(bkpId, new JSONArray());
                                restoreAtt.getJSONArray(bkpId).put(att);
                            }
                            addedatt.add(att);
                        }
                    }
                    for (int att : addedatt) {
                        //attributes.remove(att);
                        boolean status = attributes.remove((Integer) att);
                    }
                    addedatt = new ArrayList<>();
                    if (attributes.isEmpty()) {
                        break;
                    }
                }
                JSONArray jarr = new JSONArray();
                jarr.put(objectGuid);
                jarr.put(ObjectType.DnsNode.maskValue);
                jarr.put(restoreAtt);
                recoveryManager.restore(jarr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean recycleZone(long domainId, String zoneId, long backupId) {
        DataSet dset = null;
        Connection con = null;
        try {
            //displayGuid = "BACKLINK_OBJECT_GUID";
            //displayDN = "BACKLINK_OBJECT_DN";
            ArrayList<String> records = new ArrayList<>();
            con = RelationalAPI.getInstance().getConnection();
            Query query = LinkedAttributesUtil.getLinksListFromRangedAttr(domainId, 87, backupId, zoneId, 0, "FRONTLINK_OBJECT_GUID", "BACKLINK_OBJECT_GUID", "BACKLINK_OBJECT_DN", false, 0, 0);// No I18N
            dset = RelationalAPI.getInstance().executeQuery(query, con);
            while (dset.next()) {
                records.add((String) dset.getValue("BACKLINK_OBJECT_GUID"));// No I18N
            }
            //ArrayList<String> records = LinkedAttributesUtil.getTotalDnOrGuidFromBackup(domainId,87,backupId,zoneId,0,"FRONTLINK_OBJECT_GUID","BACKLINK_OBJECT_GUID","BACKLINK_OBJECT_DN",false,0,0,"BACKLINK_OBJECT_GUID");             // No I18N
            int[] restoreAtt = new int[]{50, 82, 84};
            RecoveryManager recoveryManager = new RecoveryManager(domainId, OperationType.Recycle, domainId);
            for (String record : records) {
                JSONArray jarr = new JSONArray();
                jarr.put(record);
                jarr.put(ObjectType.DnsNode.maskValue);
                jarr.put(new JSONArray());
                recoveryManager.recycle(jarr);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            DBUtil.closeDataSetAndConnection(dset, con);
        }
        
        
    }
}

//ignoreI18n_end
