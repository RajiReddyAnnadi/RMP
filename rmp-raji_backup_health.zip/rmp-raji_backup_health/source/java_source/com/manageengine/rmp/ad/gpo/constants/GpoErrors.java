/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.constants;

/**
 *
 * @author lucky-2306
 */
public enum GpoErrors {
    SessionStateBroken(1),
    NoValidSession(2),
    PsSessionFail(3),
    NoPrivilege(4),
    CmdletInvocationException(5),
    ParseException(6),
    ParameterBindingException(7),
    CommandNotFoundException(8),
    PSArgumentException(9),
    RunspaceConnectionError(10),
    RemotePowershellFailed(11),
    LocalCmdletFailed(12),
    
    GPOIdNotFound(20),
    ObjectReferenceNotSet(21),
    CannotOpenDevice(22),
    COMReturned(23),
    EmptyLibrary(24),
    AttributeNotExists(25),
    CannotFindPath(26),
    InvalidData(27),
    
    unknownError(2048),
    RemoteDirCreationFail(4096),
    GpoFailed(8192);//general exception
    

    public long errorId;

    GpoErrors(long errorId) {
        this.errorId = errorId;
    }
    
    public static String getName(int errorId){
        switch(errorId){
            case 1:
                return "SessionStateBroken"; //No I18N
            case 2:
                return "NoValidSession"; //No I18N
            case 3:
                return "PsSessionFail"; //No I18N
            case 4:
                return "NoPrivilege"; //No I18N
            case 5:
                return "CmdletInvocationException"; //No I18N
            case 6:
                return "ParseException"; //No I18N
            case 7:
                return "ParameterBindingException"; //No I18N
            case 8:
                return "CommandNotFoundException"; //No I18N
            case 9:
                return "PSArgumentException"; //No I18N
            case 10:
                return "RunspaceConnectionError"; //No I18N
            case 11:
                return "RemotePowershellFailed"; //No I18N
            case 12:
                return "LocalCmdletFailed"; //No I18N
            case 20:
                return "GPOIdNotFound"; //No I18N
            case 21:
                return "ObjectReferenceNotSet"; //No I18N
            case 22:
                return "CannotOpenDevice"; //No I18N
            case 23:
                return "COMReturned"; //No I18N
            case 24:
                return "EmptyLibrary"; //No I18N
            case 25:
                return "AttributeNotExists"; //No I18N
            case 26:
                return "CannotFindPath"; //No I18N
            case 27:
                return "InvalidData"; //No I18N
            case 4096:
                return "RemoteDirCreationFail"; //No I18N
            case 8192:
                return "GpoFailed"; //No I18N
            default:
                return "unknownError"; //No I18N
        }
    }
    
    public static String getErrorString(int errorId){
        switch(errorId){
            case 1:
                return "Session state is broken"; //No I18N
            case 2:
                return "No valid session"; //No I18N
            case 3:
                return "PsSession failed"; //No I18N
            case 4:
                return "No privilege"; //No I18N
            case 5:
                return "Cmdlet invocation failed"; //No I18N
            case 6:
                return "Error in parsing data"; //No I18N
            case 7:
                return "Error in binding parameter"; //No I18N
            case 8:
                return "Command not found"; //No I18N
            case 9:
                return "PSArgument Exception"; //No I18N
            case 10:
                return "Error in runspace connection"; //No I18N
            case 11:
                return "Remote powershell failed"; //No I18N
            case 12:
                return "Local cmdlet failed"; //No I18N
            case 20:
                return "GPO was not found"; //No I18N
            case 21:
                return "Object reference not set to an instance of an object"; //No I18N
            case 22:
                return "The system cannot open the device or file specified"; //No I18N
            case 23:
                return "Error HRESULT E_FAIL has been returned from a call to a COM component"; //No I18N
            case 24:
                return "The library, drive, or media pool is empty"; //No I18N
            case 25:
                return "The specified directory service attribute or value does not exist"; //No I18N
            case 26:
                return "The system cannot find the path specified"; //No I18N
            case 27:
                return "The data is invalid"; //No I18N
            case 4096:
                return "Remote directory creation failed"; //No I18N
            case 8192:
                return "GPO Failed"; //No I18N
            default:
                return "Unknown Error"; //No I18N
        }
    }
}
