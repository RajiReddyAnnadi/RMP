/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.gpo.constants;

/**
 *
 * @author lucky-2306
 */
public enum GpoAddRem {

    Add(1),
    Rem(2),
    None(-1);

    public int addRemId;

    GpoAddRem(int addRemId) {
        this.addRemId = addRemId;
    }

    public static GpoAddRem getType(int addRemId) {
        switch (addRemId) {
            case 1:
                return Add;
            case 2:
                return Rem;
            default:
                return None;
        }
    }
}
