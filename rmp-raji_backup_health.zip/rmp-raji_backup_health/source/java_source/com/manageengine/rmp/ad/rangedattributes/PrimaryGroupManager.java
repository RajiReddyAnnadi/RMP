 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.ad.rangedattributes;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.Join;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.ds.query.SelectQueryImpl;
import com.adventnet.ds.query.SortColumn;
import com.adventnet.ds.query.Table;
import com.adventnet.persistence.DataAccess;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.manageengine.ads.fw.domain.ADSDomainHandler;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.ad.backup.BackupImpl;
import com.manageengine.rmp.ad.backup.BackupUpdater;
import static com.manageengine.rmp.ad.rangedattributes.LinkedAttributesUtil.updateIfNoModifiedTypeNeeded;
import com.manageengine.rmp.common.LogWriter;
import com.manageengine.rmp.common.RMPCommonUtil;
import com.manageengine.rmp.constants.ObjectType;
import com.manageengine.rmp.constants.RmpConstants;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.dataobjects.BackupObject;
import com.manageengine.rmp.db.dbutil.DBUtil;
import com.manageengine.rmp.util.BitSetUtil;
import com.manageengine.rmp.util.GeneralUtil;
import com.manageengine.rmp.util.LdapUtil;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.logging.Level;
import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author vijay-2377
 */
public class PrimaryGroupManager {
    Long domainId;
    Long backupId;
    public HashMap<Integer, String> ridVsGuid = null;
    public HashMap<String, JSONArray> primaryGroupList=null;
     public HashMap<String, JSONArray> primaryGroupbackLinks=null;
    public HashMap<String,JSONObject> linksDataList=null;
    
    public PrimaryGroupManager(Long domainId,Long backupId){
     this.domainId=domainId;
     this.backupId=backupId;
     this.ridVsGuid=getRidVsGuidList();
     this.primaryGroupList= new  HashMap<String,JSONArray>();
     this.linksDataList=fillCurrentInfoList();
      this.primaryGroupbackLinks= new  HashMap<String,JSONArray>();
    }
    
    public HashMap<Integer, String> getRidVsGuidList(){
        HashMap<Integer, String> ridVsGuidList=null;
        String domainSid="";
        try{
                JSONObject domainDetails = ADSDomainHandler.getDomainDetailsFromID(domainId);
                String namingContext=domainDetails.get("DEFAULT_NAMING_CONTEXT").toString();
                SelectQuery sidQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId));
                  sidQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "CURRENTINFO_ID"));
                sidQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_SID"));
                Criteria sidCriteria=new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+ "_" +domainId, "OBJECT_DN"), namingContext, QueryConstants.EQUAL);
                sidQuery.setCriteria(sidCriteria);
                DataObject sidDataObject = CommonUtil.getPersistence().get(sidQuery);
                if (!sidDataObject.isEmpty()) {
                    Iterator iterator = sidDataObject.getRows(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId);
                    while (iterator.hasNext()) {
                        Row row = (Row) iterator.next();
                        domainSid=(String)row.get("OBJECT_SID");
                    }
                }
                ridVsGuidList=new HashMap<Integer, String>();
                SelectQuery allObjectsQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId));
                 allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "CURRENTINFO_ID"));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_GUID"));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_SID"));
                Criteria allObjectsCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+ "_" +domainId, "OBJECT_SID"), domainSid+"-", QueryConstants.STARTS_WITH);
                allObjectsQuery.setCriteria(allObjectsCriteria);
                DataObject dataObject = CommonUtil.getPersistence().get(allObjectsQuery);
                 if (!dataObject.isEmpty()) {
                    Iterator iterator = dataObject.getRows(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId);
                    while (iterator.hasNext()) {
                        Row row = (Row) iterator.next();
                        String objectSid=row.get("OBJECT_SID").toString();
                        ridVsGuidList.put(Integer.parseInt(objectSid.replace(domainSid+"-", "")), row.get("OBJECT_GUID").toString());
                    }
                }
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return ridVsGuidList;
    }
    
    public static JSONObject getObjectDetailByRid(String domainId,String rid){
        JSONObject objectDetail=null;
        String domainSid="";
        try{
                JSONObject domainDetails = ADSDomainHandler.getDomainDetailsFromID(Long.valueOf(domainId));
                String namingContext=domainDetails.get("DEFAULT_NAMING_CONTEXT").toString();
                SelectQuery sidQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId));
                  sidQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "CURRENTINFO_ID"));
                sidQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_SID"));
                Criteria sidCriteria=new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+ "_" +domainId, "OBJECT_DN"), namingContext, QueryConstants.EQUAL);
                sidQuery.setCriteria(sidCriteria);
                DataObject sidDataObject = CommonUtil.getPersistence().get(sidQuery);
                if (!sidDataObject.isEmpty()) {
                    Iterator iterator = sidDataObject.getRows(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId);
                    while (iterator.hasNext()) {
                        Row row = (Row) iterator.next();
                        domainSid=(String)row.get("OBJECT_SID");
                    }
                }
                objectDetail=new JSONObject();
                SelectQuery allObjectsQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId));
                 allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "CURRENTINFO_ID"));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_GUID"));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_DN"));
                Criteria allObjectsCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+ "_" +domainId, "OBJECT_SID"), domainSid+"-"+rid, QueryConstants.EQUAL);
                allObjectsQuery.setCriteria(allObjectsCriteria);
                DataObject dataObject = CommonUtil.getPersistence().get(allObjectsQuery);
                 if (!dataObject.isEmpty()) {
                    Iterator iterator = dataObject.getRows(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId);
                    while (iterator.hasNext()) {
                        Row row = (Row) iterator.next();
                        objectDetail.put("OBJECT_GUID",row.get("OBJECT_GUID").toString());
                        objectDetail.put("OBJECT_DN",row.get("OBJECT_DN").toString());
                    }
                }
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return objectDetail;
    }
    
    public HashMap<String,JSONObject> fillCurrentInfoList(){
            HashMap<String,JSONObject> linksDataList=new  HashMap<String,JSONObject>();
            try{
                SelectQuery allObjectsQuery = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "CURRENTINFO_ID"));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_GUID"));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_DN"));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "OBJECT_TYPE"));
                allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "LINKS_DATA"));
                 allObjectsQuery.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId, "SYNC_STATUS"));
                DataObject dataObject = CommonUtil.getPersistence().get(allObjectsQuery);
                 if (!dataObject.isEmpty()) {
                      Iterator iterator = dataObject.getRows(TableName.RMP_OBJ_CURRENT_INFO + "_" +domainId);
                      while (iterator.hasNext()) {
                        Row row = (Row) iterator.next();
                        JSONObject objectData=new JSONObject();
                        objectData.put("OBJECT_DN", row.get("OBJECT_DN").toString());
                        objectData.put("LINKS_DATA", row.get("LINKS_DATA").toString());
                        objectData.put("OBJECT_TYPE", row.get("OBJECT_TYPE"));
                        objectData.put("SYNC_STATUS", row.get("SYNC_STATUS"));
                        linksDataList.put( row.get("OBJECT_GUID").toString(), objectData);
                    }
                 }
                 return linksDataList;
            }
            catch(Exception e){
                e.printStackTrace();
                
            }
            return null;
        
    }
    
    public void addPrimaryGroup(BackupImpl backupImpl,Integer primaryGroupId, BackupObject backupObject,boolean isDeleted){
      try{
        if(primaryGroupId!=null && ridVsGuid.containsKey(primaryGroupId) && linksDataList.containsKey(backupObject.objId.toString())){  
        String frontLinkGuid=ridVsGuid.get(primaryGroupId);
        ArrayList linksGuid=new ArrayList();
        linksGuid.add(backupObject.objId.toString());
         backupImpl.forwardLinkManager.forwardLink=ForwardLink.member;
        ArrayList<String> commonList= backupImpl.forwardLinkManager.getCommonFrontLinkFromBackup(frontLinkGuid, linksGuid);
        if(commonList.size()==0){
            if(isDeleted && backupImpl.isRecyleBinEnabled){
                backupImpl.backupUpdater.updateLinkAttrInfo(ForwardLink.member.linkId, backupObject.backupId, LinkType.Removed.memberTypeId, frontLinkGuid, backupObject.objId.toString());
            }
            else{
            backupImpl.backupUpdater.updateLinkAttrInfo(ForwardLink.member.linkId, backupObject.backupId, LinkType.Added.memberTypeId, frontLinkGuid, backupObject.objId.toString());
             backupImpl.backupUpdater.updateLinkAttrInfo(ForwardLink.member.linkId, 0L, LinkType.Total.memberTypeId, frontLinkGuid, backupObject.objId.toString());
             isDeleted=false;
            }
             updateMetaValue(primaryGroupList,frontLinkGuid,ForwardLink.member.linkId,isDeleted);
             updateMetaValue(primaryGroupbackLinks,backupObject.objId.toString(),BackwardLink.memberOf.linkId,isDeleted);
             
        }
        }
      }
       catch(Exception e){ 
               e.printStackTrace();
       }
        
    }
    
    public void updateMetaValue( HashMap<String, JSONArray> objectList,String objectGuid,int attrId,boolean isDeleted){
        try{
        if(objectList.containsKey(objectGuid)){
           JSONArray metaVal=objectList.get(objectGuid);
           if(!isDeleted){
           metaVal.put(0,(int)metaVal.get(0)+1);
           metaVal.put(1,(int)metaVal.get(1)+1);
           }
           else{
               metaVal.put(2,(int)metaVal.get(2)+1);
           }
           objectList.put(objectGuid, metaVal);
        }
        else{
            JSONObject objectData=linksDataList.get(objectGuid);
            JSONObject linksData=new JSONObject(objectData.get("LINKS_DATA").toString());
            if(linksData.has(RmpConstants.BACKUP_VALUE_PREFIX+attrId)){
                JSONArray metaVal=new JSONArray(linksData.get(RmpConstants.BACKUP_VALUE_PREFIX+attrId).toString());
                if(!isDeleted){
                metaVal.put(0,(int)metaVal.get(0)+1);
                }
                else{
                     metaVal.put(0,(int)metaVal.get(0));
                }
                int added=(int)metaVal.get(1);
                long bid=(long)metaVal.getInt(3);
                if(this.backupId!=bid){
                     if(!isDeleted){
                    metaVal.put(1,1);
                     metaVal.put(2,0);
                     }
                     else{
                         metaVal.put(1,0);
                         metaVal.put(2,1); 
                     }
                }
                else{
                    if(!isDeleted){
                    metaVal.put(1,added+1);
                    metaVal.put(2,(int)metaVal.get(2));
                    }
                    else{
                        metaVal.put(1,(int)metaVal.get(1));
                        metaVal.put(2,((int)metaVal.get(2))+1);
                    }
                }
                
                metaVal.put(3,this.backupId);
                objectList.put(objectGuid, metaVal); 
            }
            else{
                 JSONArray metaVal=new JSONArray();
                 if(!isDeleted){
                metaVal.put(0,1);
                metaVal.put(1,1);
                metaVal.put(2,0);
                 }
                 else{
                      metaVal.put(0,0);
                metaVal.put(1,0);
                metaVal.put(2,1);
                 }
                metaVal.put(3, backupId);
                objectList.put(objectGuid, metaVal); 
                
            }
            
            
        }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        
    }
    
    public Boolean backupMetaData(BackupImpl backupImpl){
        try{
            updateRangedAttrMetadatainObj(primaryGroupList,backupImpl,true ,backupImpl.isFullSync,ForwardLink.member.linkId);
            updateRangedAttrMetadatainObj(primaryGroupbackLinks,backupImpl,false ,backupImpl.isFullSync,BackwardLink.memberOf.linkId);
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return true;
    }
    
      public Boolean updateRangedAttrMetadatainObj(HashMap<String, JSONArray> linkedAttrList, BackupImpl backupImpl, boolean isForwardLink, boolean isFullSync,int attrId) {
        try {
            float ceil =(float) linkedAttrList.size() / (float)RMPCommonUtil.MAX_BATCH_DUMP_COUNT;
            int loopCount = (int) Math.ceil(ceil);
            if(loopCount > 0){
                SelectQuery selectVerAndCur = new SelectQueryImpl(Table.getTable(TableName.RMP_OBJ_VER_INFO+"_"+domainId));
                Join join = new Join(TableName.RMP_OBJ_VER_INFO+"_"+domainId, TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, new String[]{"OBJECT_GUID"}, new String[]{"OBJECT_GUID"}, Join.INNER_JOIN);
                selectVerAndCur.addJoin(join);
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CURRENTINFO_ID"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "CHANGE_MASK"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "LINKS_DATA"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "UNIQUE_ID"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "BACKUP_ID"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "CHANGE_ID"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "CHANGE_MASK"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "LINKS_DATA"));
                selectVerAndCur.addSelectColumn(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "OBJECT_GUID"));
                selectVerAndCur.addSortColumn(new SortColumn(Column.getColumn(TableName.RMP_OBJ_CURRENT_INFO+"_"+domainId, "OBJECT_GUID"), true));
                Criteria criteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "BACKUP_ID"), backupId, QueryConstants.EQUAL);
                Criteria objectCriteria;
                List<String> objectGuids = null;
                int startCount, endCount;
                for(int i = 0; i < loopCount; i++){
                    if(objectGuids == null){
                        objectGuids = new ArrayList(linkedAttrList.keySet());
                    }
                    startCount = RMPCommonUtil.MAX_BATCH_DUMP_COUNT * i;
                    endCount = (RMPCommonUtil.MAX_BATCH_DUMP_COUNT * i) + RMPCommonUtil.MAX_BATCH_DUMP_COUNT;
                    if(objectGuids.size() >= endCount){
                        objectCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "OBJECT_GUID"), objectGuids.subList(startCount, endCount).toArray(new String[endCount-startCount]) , QueryConstants.IN, false);
                    }else{
                        endCount = objectGuids.size();
                        objectCriteria = new Criteria(Column.getColumn(TableName.RMP_OBJ_VER_INFO+"_"+domainId, "OBJECT_GUID"), objectGuids.subList(startCount, objectGuids.size()).toArray(new String[endCount-startCount]) , QueryConstants.IN, false);
                    }                
                    selectVerAndCur.setCriteria(criteria .and(objectCriteria));
                    DataObject dobVersion = DataAccess.get(selectVerAndCur);
                    if (dobVersion.isEmpty()) {
                        LogWriter.backup.info("dob is empty domain id" + domainId + " backup id" + backupId);//NO I18N
                    } else {
                        linkedAttrList = updateRangedObjectInBackup(linkedAttrList, dobVersion, domainId, backupId, isForwardLink, backupImpl.backupUpdater,attrId);
                    }
                }
                updateRangedObjectNotInBackup(linkedAttrList, backupImpl, isForwardLink, backupId, isFullSync,attrId,linksDataList);
            }
        } catch (Exception e) {
            LogWriter.backup.severe("exception in primary group updateRangedAttrMetadatainObj " + e);//NO I18N
            e.printStackTrace();
        }
        return true;
    }
      
    public static HashMap<String, JSONArray> updateRangedObjectInBackup(HashMap<String, JSONArray> linkedAttrList, DataObject dobVersion, long domainId, long backupId, boolean isForwardLink, BackupUpdater backupUpdater,int attribId) {
        try {
            List<String> currCols = new ArrayList<>();
            currCols.add("CURRENTINFO_ID");//NO I18N
            currCols.add("OBJECT_GUID");//NO I18N
            currCols.add("CHANGE_MASK");//NO I18N
            currCols.add("LINKS_DATA");//NO I18N
            DBUtil.createTable(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, "_temp", currCols, false, false);
            List<String> verCols = new ArrayList<>();
            verCols.add("UNIQUE_ID");//NO I18N
            verCols.add("BACKUP_ID");//NO I18N
            verCols.add("CHANGE_ID");//NO I18N
            verCols.add("CHANGE_MASK");//NO I18N
            verCols.add("LINKS_DATA");//NO I18N
            DBUtil.createTable(TableName.RMP_OBJ_VER_INFO + "_" + domainId, "_temp", verCols, false, false);
            backupUpdater.initiateTempTableWriterObj(DBUtil.getTempTableName(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId), DBUtil.getTempTableName(TableName.RMP_OBJ_VER_INFO + "_" + domainId), TableName.RMP_ATTRIBUTES_BACKUP_INFO + "_" + domainId);

            Iterator verIterator = dobVersion.getRows(TableName.RMP_OBJ_VER_INFO + "_" + domainId);
            Iterator curIterator = dobVersion.getRows(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId);
            while (verIterator.hasNext()) {
                String tempJson;
                ByteArrayInputStream tempByteInputStream;
                byte[] tempByte;
                String objectGuid;
                //get row data for updation
                Row rowVersion = (Row) verIterator.next();
                Row rowCurrent = (Row) curIterator.next();
                tempJson = (String) rowVersion.get("LINKS_DATA");
                JsonObject dataVersion = (JsonObject) new JsonParser().parse(tempJson);
                //get bitset for updation
                tempByteInputStream = (ByteArrayInputStream) rowVersion.get("CHANGE_MASK");
                tempByte = IOUtils.toByteArray(tempByteInputStream);
                BitSet changeMaskVersion = BitSetUtil.fromByteArray(tempByte);
                //get json for updation
                tempJson = (String) rowCurrent.get("LINKS_DATA");
                JsonObject dataCurrent = (JsonObject) new JsonParser().parse(tempJson);
                //get current biset for updation
                tempByteInputStream = (ByteArrayInputStream) rowCurrent.get("CHANGE_MASK");
                tempByte = IOUtils.toByteArray(tempByteInputStream);
                BitSet changeMaskCurrent = BitSetUtil.fromByteArray(tempByte);
                //values setters for updation
                objectGuid = (String) rowCurrent.get("OBJECT_GUID");
                if (linkedAttrList.containsKey(objectGuid)) {
                        if (!changeMaskVersion.get(attribId)) {
                             changeMaskVersion.set(attribId, true);
                              if (dataCurrent.get("b" +attribId) != null) {
                                  dataCurrent.add("o" + attribId, dataCurrent.get("b" + attribId)); //No I18N
                                  dataVersion.add("o" + attribId, dataCurrent.get("b" + attribId)); //No I18N
                              }
                        }
                        String updateMetaVal = linkedAttrList.get(objectGuid).toString();
                        dataVersion.addProperty(RmpConstants.BACKUP_VALUE_PREFIX + attribId, updateMetaVal);
                       
                        dataCurrent.addProperty(RmpConstants.BACKUP_VALUE_PREFIX + attribId, updateMetaVal);
                        if (!changeMaskCurrent.get(attribId)) {
                            changeMaskCurrent.set(attribId, true);
                        }
                        backupUpdater.updateAttributeInfo(UUID.fromString(rowCurrent.get("OBJECT_GUID").toString()), Integer.parseInt(rowVersion.get("CHANGE_ID").toString()), attribId);
                    
                }
                backupUpdater.updateTempTableObjCurr(rowCurrent.get("OBJECT_GUID").toString(), changeMaskCurrent, dataCurrent, rowCurrent.get("CURRENTINFO_ID").toString());
                backupUpdater.updateTempTableObjVer(Long.parseLong(rowVersion.get("CHANGE_ID").toString()), changeMaskVersion, dataVersion, rowVersion.get("UNIQUE_ID").toString());
                linkedAttrList.remove(rowCurrent.get("OBJECT_GUID").toString());
            }
            backupUpdater.dumpTempTables();
            List<String> columns = new ArrayList<>();
            columns.add("CHANGE_MASK");//NO I18N
            columns.add("LINKS_DATA");//NO I18N
            DBUtil.updateDB(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId, DBUtil.getTempTableName(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId), columns);
            DBUtil.updateDB(TableName.RMP_OBJ_VER_INFO + "_" + domainId, DBUtil.getTempTableName(TableName.RMP_OBJ_VER_INFO + "_" + domainId), columns);
            backupUpdater.dumpAttribInfoTable();
            DBUtil.dropTempTable(DBUtil.getTempTableName(TableName.RMP_OBJ_CURRENT_INFO + "_" + domainId));
            DBUtil.dropTempTable(DBUtil.getTempTableName(TableName.RMP_OBJ_VER_INFO + "_" + domainId));
        } catch (Exception e) {
            LogWriter.backup.log(Level.SEVERE, "linked attribute util update in backup{0}", e);
            e.printStackTrace();
        }
        return linkedAttrList;
    }  
    
    public static void updateRangedObjectNotInBackup(HashMap<String, JSONArray> linkedAttrList, BackupImpl backupImpl, boolean isForwardLink, Long backupId, boolean isFullSync,int attribId,HashMap<String,JSONObject> linksDataList) {
      try{
        for (Map.Entry<String, JSONArray> property : linkedAttrList.entrySet()) {
           
            if (property != null) {
                Properties tempProp = new Properties();
                tempProp.put("objectGUID",GeneralUtil.getStringAsArrayList(property.getKey()) );
                String objectDn=linksDataList.get( property.getKey()).get("OBJECT_DN").toString(); 
                Long objectMask=(Long)linksDataList.get( property.getKey()).get("OBJECT_TYPE");
                tempProp.put("distinguishedName",GeneralUtil.getStringAsArrayList(objectDn));
                    if(LdapUtil.isObjectDeleted(objectDn)){
                      tempProp.put("isDeleted", GeneralUtil.getStringAsArrayList("1"));
                    }
                    //tempProp.put("name", arg1)
                
                if (objectMask != 0) {
                    ObjectType objectType=ObjectType.parse(objectMask);
                    tempProp.put("objectType",objectType.toString());
                } else {
                    tempProp.put("objectType", "Other");
                }
                
                    String attrName;
                    if (isForwardLink) {
                        attrName = ForwardLink.getAttributeName(attribId);
                    } else {
                        attrName = BackwardLink.getAttributeName(attribId);
                    }
                     ArrayList<String> metadataUpdate = new ArrayList();
                    metadataUpdate.add(property.getValue().toString());
                    tempProp.put(attrName,metadataUpdate);
                tempProp.put("notInADSync", "true");
                 tempProp.put("orgObjectType", "primaryGroupAttr");
                backupImpl.addRow(tempProp);
            }
        }
    }
      
      catch(Exception e){
          e.printStackTrace();
          
      }
        
    }
    
   
    
    
    
}
