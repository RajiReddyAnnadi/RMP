/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.api;

import com.manageengine.ads.fw.api.RestAPIErrorHandlerImpl;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author vincy-4480
 */
public class APIErrorHandler extends RestAPIErrorHandlerImpl{
    private static Logger logger = Logger.getLogger("ADSLogger");
    public static final String USER_NOT_AUTH = "00001001";
    public static final String API_NOT_AUTH = "00001002";

    public Properties getErrorProperties(String errorCode, Properties params)
    {
        logger.log(Level.INFO, "ErrorCode:" + errorCode);
        logger.log(Level.INFO, "Parameters: " + params);
        if (errorCode.equals("00001001")) {
            return getFormattedStatus("SEVERE", "User is not authorized to perform this action.", "00001001");// NO I18N
        }
        if (errorCode.equals("00001002")) {
            return getFormattedStatus("SEVERE", "User is not authorized to access this API.", "00001002");// NO I18N
        }
        return super.getErrorProperties(errorCode, params);
    }
}
