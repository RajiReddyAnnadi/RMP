/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.api;


import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.rmp.common.i18n.Rmpi18n;
import com.manageengine.ads.fw.i18n.ADSResourceBundle;
import com.manageengine.ads.fw.i18n.I18NUtil;
import com.manageengine.ads.fw.license.LicenseManager;
import com.manageengine.rmp.licensing.EditionType;
import com.manageengine.rmp.licensing.LicenseUtil;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

/**
 *
 * @author vincy-4480
 */
public class LicenseAction extends DispatchAction{
    public ActionForward getLicenseDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        try{
            //ADSResourceBundle resourceBundle = Rmpi18n.getInstance().getJSBundle(I18NUtil.getDefaultLocale());
            JSONObject licenseDetails = LicenseManager.getLicenseDetails();
            JSONObject componentDetails = new JSONObject();
            //licenseDetails.put("LICENSE_TYPE", rb.getString(licenseDetails.getString("LICENSE_TYPE")));
            if(LicenseUtil.getSubscriptionType() != EditionType.Free.ordinal()){
                componentDetails.put("No. of User Objects Subscribed", new JSONObject(licenseDetails.getJSONObject("COMPONENT_DETAILS").getString("Objects")).get("NumberOfObjects"));
            }
            componentDetails.put("No. of User Objects Tracking", Integer.toString(LicenseUtil.getEnableUserCount()));
            licenseDetails.put("COMPONENT_DETAILS", componentDetails);
            CommonUtil.setResponseText(response, licenseDetails.toString());

        }catch(Exception e){
            e.printStackTrace();
            CommonUtil.setResponseText(response, e.getMessage());
        }
        return mapping.findForward("result");//No I18N
    }
    
    public ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            String licenseContent = request.getParameter("license");
            LicenseManager licenseManager = new LicenseManager("ManageEngine RecoveryManager Plus", licenseContent); // No I18N 
            boolean isUpgraded = LicenseUtil.upgradeLicense(request, licenseManager.getLicenseFileLocation());
            if(isUpgraded){
                request.setAttribute("RESPONSE", "Success");
            }
        } catch (Exception e) {
            request.setAttribute("RESPONSE", e.getMessage());
        }
        return mapping.findForward("result");//No I18N
    }

}
