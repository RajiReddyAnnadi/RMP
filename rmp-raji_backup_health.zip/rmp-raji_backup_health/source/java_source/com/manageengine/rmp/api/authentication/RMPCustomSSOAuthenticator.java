/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.api.authentication;

import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.delegation.TechnicianConstants;
import com.manageengine.ads.fw.domain.ADSDomainHandler;
import com.manageengine.ads.fw.i18n.ADSResourceBundle;
import com.manageengine.ads.fw.i18n.I18NUtil;
import com.manageengine.ads.fw.sso.CustomSSOAuthenticator;
import com.manageengine.ads.fw.sso.cookie.Ticket;
import com.manageengine.rmp.admin.authentication.RMPADAuthentication;
import com.manageengine.rmp.admin.authentication.RMPAuthConstants;
import com.manageengine.rmp.admin.authentication.RMPAuthHandler;
import com.manageengine.rmp.common.i18n.Rmpi18n;
import com.manageengine.rmp.constants.TableName;
import com.manageengine.rmp.util.SessionListener;
import java.util.Properties;
import java.util.logging.Logger;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.json.JSONObject;

/**
 *
 * @author vincy-4480
 */
public class RMPCustomSSOAuthenticator implements CustomSSOAuthenticator{
    private static Logger out = Logger.getLogger("ADSLogger");

    private Ticket ticketObj = null;
    private DataObject accountDO = null;
    private String domainName = null;
    
    public void init(Ticket ticketObj)
    {
        try
        {
            String domainName = RMPAuthConstants.RMP_AUTHENTICATION;
            if(!ticketObj.isDomainAuthentication)
            {
                this.accountDO = RMPAuthHandler.getAccountDO(ticketObj.loginName, ticketObj.serviceName, domainName);
                this.domainName = domainName;
            }
            this.ticketObj = ticketObj;
        }
        catch (Exception e)
        {
                e.printStackTrace();
        }
    }
    
    public boolean isValidAccount() throws LoginException
    {
        Boolean isValid = false;
        try
        {
            ADSResourceBundle resourceBundle = Rmpi18n.getInstance().getJSBundle(I18NUtil.getDefaultLocale());
            if (this.ticketObj.isDomainAuthentication)
            {
                String domainName = this.ticketObj.domainName;
                JSONObject domainDetails = ADSDomainHandler.getDomainDetails(domainName);
                if (domainDetails.length() != 0)
                {
                    this.domainName = domainDetails.getString("DOMAIN_NAME");
                }
                else
                {
                    throw new LoginException(resourceBundle.getString("rmp.login.common.error.no_such_user_account_configured"));
                }
                this.accountDO = RMPAuthHandler.getAccountDO(this.ticketObj.loginName, this.ticketObj.serviceName, this.domainName);
            }
            isValid = RMPAuthHandler.isValidAccount(this.accountDO);
            Row passwordRow = null,userStatusRow = null,accountStatusRow = null;
            passwordRow = this.accountDO.getFirstRow(TableName.AAAPASSWORD);
            userStatusRow = accountDO.getFirstRow(TableName.AAAUSERSTATUS);
            accountStatusRow = accountDO.getFirstRow(TableName.AAAACCOUNTSTATUS);
            String userStatus = (String) userStatusRow.get("STATUS");
            if("DISABLED".equalsIgnoreCase(userStatus))
            {
                throw new LoginException("rmp.login.common.error.user_disabled_in_rmp");// NO I18N
            }

            String accountStatus = (String) accountStatusRow.get("STATUS");
            if("DEACTIVATED".equals(accountStatus))
            {
                throw new LoginException("rmp.login.common.error.user_accnt_disabled_in_rmp");// NO I18N
            }
            else if("LOCKED".equals(accountStatus))
            {
                throw new LoginException("rmp.login.common.error.user_accnt_locked_in_rmp");// NO I18N
            }
            return isValid;
        }
        catch(Exception e)
        {
            throw new LoginException(e.getMessage());
        }
    }
    
    public boolean authenticate() throws LoginException
    {
        try
        {
                return ticketObj.isValidTicket;
        }
        catch (Exception e)
        {
                e.printStackTrace();
        }
        return false;
    }
    
    public void setSessionAttributes(HttpServletRequest request) throws LoginException{
        try{
            HttpSession session = request.getSession();
            session.setAttribute(RMPAuthConstants.IS_DOMAIN_USER,this.ticketObj.isDomainAuthentication);
            Row row = this.accountDO.getRow(TableName.AAALOGIN);
            Long loginId = (Long)row.get("LOGIN_ID");
            String aaaLoginName = (String) row.get("NAME");
            session.setAttribute(RMPAuthConstants.LOGIN_NAME, aaaLoginName);
            session.setAttribute("DOMAIN_NAME", domainName);
            session.setAttribute(TechnicianConstants.LOGIN_ID,loginId);
            RMPADAuthentication auth = new RMPADAuthentication();
            auth.setRoles(session,domainName,loginId);
            SessionListener.updateLoginIdMapping(loginId, session);
	    SessionListener.updateSessionMetadata(session.getId(), request, aaaLoginName);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    
    public DataObject getDataObject()
    {
            return this.accountDO;
    }

    public void init(Properties ntlmProperties)
    {

    }

    public boolean ntlmAuthenticate() throws LoginException
    {
            return false;
    }
}
