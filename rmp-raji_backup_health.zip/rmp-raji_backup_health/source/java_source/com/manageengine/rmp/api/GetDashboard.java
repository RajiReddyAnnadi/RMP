/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.api;

import com.adventnet.authentication.util.AuthUtil;
import com.manageengine.ads.fw.delegation.TechnicianConstants;
import com.manageengine.ads.fw.delegation.TechnicianHandler;
import com.manageengine.ads.fw.i18n.ADSResourceBundle;
import com.manageengine.ads.fw.i18n.I18N;
import com.manageengine.ads.fw.i18n.I18NUtil;
import com.manageengine.ads.fw.layout.Layout;
import com.manageengine.ads.fw.layout.LayoutAction;
import com.manageengine.ads.fw.layout.LayoutBean;
import com.manageengine.ads.fw.taglib.LayoutTag;
import com.manageengine.ads.fw.util.CommonUtil;
import com.manageengine.ads.fw.util.JSONUtil;
import com.manageengine.rmp.ad.backup.BackupInitiator;
import com.manageengine.rmp.admin.authentication.RMPAuthConstants;
import com.manageengine.rmp.admin.authentication.RMPAuthHandler;
import com.manageengine.rmp.client.SummaryHandler;
import com.manageengine.rmp.common.i18n.Rmpi18n;
import com.manageengine.rmp.dashboard.DashboardUtil;
import com.manageengine.rmp.util.RMPDomainHandler;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import com.adventnet.persistence.Row;
import com.adventnet.persistence.DataObject;
import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.manageengine.ads.fw.layout.LayoutBean;
import com.manageengine.ads.fw.layout.LayoutConstants;
import com.adventnet.ds.query.QueryConstants;
import java.util.Iterator;
import com.manageengine.ads.fw.layout.customization.TabsHandler;

/**
 *
 * @author vincy-4480
 */
public class GetDashboard extends LayoutAction {
    public ActionForward loadContainers(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        try {
            //change to I18n text
            String userName = request.getParameter("userName");
            String logonDomainName = request.getParameter("domainName");
            String domainFlatName = request.getParameter("domainFlatName");
            String isProductUser = request.getParameter("isProductUser");
            JSONObject params = new JSONObject(request.getParameter("params"));
            String domainName = params.get("domainName").toString();
            
            if("true".equalsIgnoreCase(isProductUser))
            {
                domainFlatName = RMPAuthConstants.RMP_AUTHENTICATION;
                logonDomainName = domainFlatName;
            }
            else if(domainFlatName == null){
                domainFlatName = domainName;
            }

            Long userId = null;
            String errorMsg = null;
            try{
                    userId= RMPAuthHandler.getUserId(userName,logonDomainName);
                    boolean isUserAuthorised = false;
                    JSONArray delegatedDomainRoles = TechnicianHandler.getDelegatedDomainRoles(userId);
                    if(delegatedDomainRoles.length() ==1 && delegatedDomainRoles.getJSONObject(0).getString("DOMAIN_NAME").equals("ads.fw.delegation.all_domains")){
                        isUserAuthorised = true;
                    }else{
                        for(int i=0; i<delegatedDomainRoles.length(); i++){
                            JSONObject domainRole = delegatedDomainRoles.getJSONObject(i);
                            if(domainRole.getString(TechnicianConstants.DOMAIN_NAME).equalsIgnoreCase(domainFlatName)){
                                isUserAuthorised = true;
                                break;
                            }
                        }
                    }
                    if(!isUserAuthorised){
                        errorMsg = "ads.restapi.error.user_not_authorized"; //NO I18N
                    }
            }
            catch(Exception e)
            {
                    errorMsg = "ads.restapi.error.no_user_found";	//NO I18N
            }
            
             if(errorMsg == null){
                Properties domainDetails = RMPDomainHandler.getDomainDetailsByName(domainName);
                if((int) domainDetails.get("ADMIN_STATUS")==0)
                {
                        errorMsg="ads.restapi.domain_disabled";//NO I18N
                }
            }
            if(errorMsg!=null)
            {
                    JSONObject componentModel = new JSONObject();
                    JSONObject data = new JSONObject();
                    data.put("ERROR_MESSAGE", errorMsg);
                    data.put("DOMAIN_NAME",domainName);
                    data.put("PRODUCT_NAME",CommonUtil.getProductName());
                    componentModel.put("CONTAINER_NAME", "service-unavailable");
                    componentModel.put("IS_CUSTOM", true);
                    componentModel.put("DATA",data);
                    response.getWriter().write(componentModel.toString());
                    return null;
            }

            JSONObject layoutDataModel = new Layout().getDataModel(userId,null);
            Long tabId = new LayoutBean(request).getFirstTabId(layoutDataModel.getLong("LAYOUT_ID"));// No I18N

            params.put("tabId",tabId);// No I18N


            if(params.has("isEmber") && params.getBoolean("isEmber"))   
            {    
                ADSResourceBundle resourceBundle = I18N.getInstance().getBundle(request);    
                LayoutBean layout = new LayoutBean();    
                JSONArray lhsContainers = DashboardUtil.getContainers(tabId);
                JSONObject adsLHSContainers = layout.getTabContainerDetails(tabId,resourceBundle,false,request);
                JSONArray lhsContainersData = adsLHSContainers.getJSONArray("DATA");// NO I18N
                for(int i=0;i<lhsContainersData.length();i++)
                {
                        try{
                                JSONArray containers= lhsContainersData.getJSONArray(i);
                                for(int j=0;j<containers.length();j++)
                                {
                                        JSONObject containerData = containers.getJSONObject(j);
                                        Long containerId = containerData.getLong("CONTAINER_ID");// No I18N
                                        JSONArray menus = containerData.getJSONArray("MENUS");// No I18N
                                        String containerName = JSONUtil.getJSONObject(lhsContainers,"priId",containerData.getLong("PRIORITY_ID")).getString("dispName");
                                        containerData.put("NAME",containerName);
                                        containerData.put("MENUS", menus);
                                        containerData.put("IS_CUSTOMIZABLE", false);
                                }
                        }
                        catch(Exception e)
                        {
                                e.printStackTrace();
                        }
                }


                response.getWriter().write(adsLHSContainers.toString());    
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public ActionForward loadComponent(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response){
        try{
            ADSResourceBundle resourceBundle = Rmpi18n.getInstance().getJSBundle(I18NUtil.getDefaultLocale());
            JSONObject params = new JSONObject(request.getParameter("params"));
            String userName = request.getParameter("userName");
            String logonDomainName = request.getParameter("domainName");
            String domainFlatName = request.getParameter("domainFlatName");
            String isProductUser = request.getParameter("isProductUser");
            String domainName = params.get("domainName").toString();
            
            if("true".equalsIgnoreCase(isProductUser))
            {
                domainFlatName = RMPAuthConstants.RMP_AUTHENTICATION;
                logonDomainName = domainFlatName;
            }
            else if(domainFlatName == null){
                domainFlatName = domainName;
            }

            Long userId = null;
            String errorMsg = null;
            try{
                    userId= RMPAuthHandler.getUserId(userName,logonDomainName);
                    boolean isUserAuthorised = false;
                    JSONArray delegatedDomainRoles = TechnicianHandler.getDelegatedDomainRoles(userId);
                    if(delegatedDomainRoles.length() ==1 && delegatedDomainRoles.getJSONObject(0).getString("DOMAIN_NAME").equals("ads.fw.delegation.all_domains")){
                        isUserAuthorised = true;
                    }else{
                        for(int i=0; i<delegatedDomainRoles.length(); i++){
                            JSONObject domainRole = delegatedDomainRoles.getJSONObject(i);
                            if(domainRole.getString(TechnicianConstants.DOMAIN_NAME).equalsIgnoreCase(domainFlatName)){
                                isUserAuthorised = true;
                                break;
                            }
                        }
                    }
                    if(!isUserAuthorised){
                        errorMsg = "ads.restapi.error.user_not_authorized"; //NO I18N
                    }
            }
            catch(Exception e)
            {
                    errorMsg = "ads.restapi.error.no_user_found";	//NO I18N
            }
            
             if(errorMsg == null){
                Properties domainDetails = RMPDomainHandler.getDomainDetailsByName(domainName);
                if((int) domainDetails.get("ADMIN_STATUS")==0)
                {
                        errorMsg="ads.restapi.domain_disabled";//NO I18N
                }
            }
            if(errorMsg!=null)
            {
                    JSONObject componentModel = new JSONObject();
                    JSONObject data = new JSONObject();
                    data.put("COMPONENT_ERROR_MESSAGE", errorMsg);
                    data.put("DOMAIN_NAME",domainName);
                    data.put("PRODUCT_NAME",CommonUtil.getProductName());
                    componentModel.put("NAME", "service-unavailable");
                    componentModel.put("IS_CUSTOM", true);
                    componentModel.put("DATA",data);
                    response.getWriter().write(componentModel.toString());
                    return null;
            }

            Properties domainDetails = RMPDomainHandler.getDomainDetailsByName(domainName);
            Long domainId = Long.parseLong(domainDetails.getProperty("DOMAIN_ID"));
            Long containerId = params.getLong("containerId");// No I18N
            //Long userId = AuthUtil.getUserId(userName,domainFlatName);
            //JSONObject layoutDataModel = new Layout().getDataModel(userId,null);
            //Long tabId = new LayoutBean(request).getFirstTabId(layoutDataModel.getLong("LAYOUT_ID"));// No I18N
            //Long layoutId = DashboardUtil.getLayout();
            if(containerId.compareTo(1L)==0){
                DashboardUtil.generateObjectSummaryData(domainId, response, resourceBundle);
            }else if(containerId.compareTo(3L)==0){
                DashboardUtil.generateADGraph(domainId, response, resourceBundle, params);
            }else if(containerId.compareTo(4L)==0){
                DashboardUtil.generateBMRGraph(domainId, response, resourceBundle);
            }
            return null;
        }catch(Exception e){
            e.printStackTrace();
        }
        return mapping.findForward("unavailable");// NO I18N
    }
	public ActionForward getUnusedWidgetDetails(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) 
    {
		
	    try
		{
			JSONObject params = new JSONObject(request.getParameter("params"));
			ADSResourceBundle resourceBundle = I18N.getInstance().getBundle(request);  
			JSONObject unUsedWidgets=new JSONObject();			
			JSONArray usedWidgets= new JSONArray(params.getString("USED_WIDGETS"));
			Long usedList[]=new Long[usedWidgets.length()];
			for(int i=0;i<usedWidgets.length();i++)
			{
				usedList[i]=getComponentId(usedWidgets.getLong(i));
			}
			LayoutBean layout = new LayoutBean();
			Long productId=CommonUtil.getProductId();
			Criteria crit = new Criteria(Column.getColumn(LayoutConstants.ADSMODULECOMPONENTS,LayoutConstants.PLACEHOLDER_ID),params.getLong(LayoutConstants.PLACEHOLDER_ID), QueryConstants.EQUAL);
			crit = crit.and(new Criteria(Column.getColumn(LayoutConstants.ADSMODULECOMPONENTS,LayoutConstants.COMPONENT_ID),usedList, QueryConstants.NOT_IN));
			DataObject dObj = CommonUtil.getPersistence().get(LayoutConstants.ADSMODULECOMPONENTS, crit);
			Iterator itr = dObj.getRows(LayoutConstants.ADSMODULECOMPONENTS,crit);
			while (itr.hasNext()) 
			{
				try
				{
					Row row=(Row)itr.next();
					JSONObject widgetDetails=new JSONObject();
					JSONObject componentDetails=new JSONObject();
					componentDetails.put(LayoutConstants.COMPONENT_DISPLAY_NAME, resourceBundle.getString(String.valueOf(row.get(LayoutConstants.COMPONENT_DISPLAY_NAME))));
					long cmpId=(Long)(row.get(LayoutConstants.COMPONENT_ID));
					componentDetails.put(LayoutConstants.COMPONENT_ID, cmpId);
					componentDetails.put("PRODUCT_ID", productId);
					long containerId=getContainerId(cmpId);
					Criteria cri = new Criteria(Column.getColumn(LayoutConstants.ADSLAYOUTCONTAINERS,LayoutConstants.CONTAINER_ID),containerId, QueryConstants.EQUAL);
					DataObject dataObj = CommonUtil.getPersistence().get(LayoutConstants.ADSLAYOUTCONTAINERS,cri);
					Row rowLayout = dataObj.getFirstRow(LayoutConstants.ADSLAYOUTCONTAINERS);
					JSONObject containerDetails=new JSONObject();
					List<String> columns = rowLayout.getColumns();
					for(String col : columns)
					{
						if(!col.equals("CONTAINER_NAME"))
						{
						    containerDetails.put(col,rowLayout.get(col));
						}
						else
						{
							containerDetails.put(col,resourceBundle.getString((String)rowLayout.get(col)));
						}
					}
					containerDetails.put("PRODUCT_ID",productId);
					containerDetails.put("PRODUCT_NAME",CommonUtil.getProductName());
					JSONObject conOptions=layout.getContainerOptions(containerId);
					widgetDetails.put("COMPONENTDETAILS",componentDetails);
					widgetDetails.put("CONTAINERDETAILS",containerDetails);
					widgetDetails.put("CONTAINEROPTIONS",conOptions);
					unUsedWidgets.put(String.valueOf(cmpId),widgetDetails);
				}
				catch (Exception exp) 
				{
					exp.printStackTrace();
				}
			}
			CommonUtil.setResponseText(response,unUsedWidgets.toString());
			return null;
	    }
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	//Method to get container id for the given component id
	
	public static long getContainerId(Long componentId)
	{
		long containerId=0L;
		try
		{
			Criteria crit = new Criteria(Column.getColumn(LayoutConstants.ADSCONTAINERVSCOMPONENT,LayoutConstants.COMPONENT_ID),componentId, QueryConstants.EQUAL);
			DataObject dataObj = CommonUtil.getPersistence().get(LayoutConstants.ADSCONTAINERVSCOMPONENT,crit);
			Row row = dataObj.getFirstRow(LayoutConstants.ADSCONTAINERVSCOMPONENT);
			containerId=(Long)(row.get(LayoutConstants.CONTAINER_ID));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return containerId;
	}
	
	//Method to get component id for the given container id
	public long getComponentId(long containerId)
	{
		long componentId=0L;
		try
		{
			Criteria crit = new Criteria(Column.getColumn(LayoutConstants.ADSCONTAINERVSCOMPONENT,LayoutConstants.CONTAINER_ID),containerId, QueryConstants.EQUAL);
			DataObject dataObj = CommonUtil.getPersistence().get(LayoutConstants.ADSCONTAINERVSCOMPONENT,crit);
			Row row = dataObj.getFirstRow(LayoutConstants.ADSCONTAINERVSCOMPONENT);
			componentId=(Long)(row.get(LayoutConstants.COMPONENT_ID));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return componentId;
	}

}
