/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.rmp.api;

import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.ads.fw.api.RestAPIAuthorization;
import com.manageengine.ads.fw.domain.ADSDomainHandler;
import com.manageengine.rmp.admin.authentication.RMPAuthConstants;
import com.manageengine.rmp.admin.authentication.RMPAuthHandler;
import com.manageengine.rmp.constants.TableName;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import org.json.JSONObject;

/**
 *
 * @author vincy-4480
 */
public class APIAuthorization implements RestAPIAuthorization {
    private Logger logger = Logger.getLogger("ADSLogger");
    
    public boolean isAuthorized(HttpServletRequest request) throws Exception {
        String requestAPI = request.getRequestURI();
        String userName = request.getParameter("userName");
        String domainName = request.getParameter("domainName");
        String isProductUser = request.getParameter("isProductUser");
        if ("true".equalsIgnoreCase(isProductUser)) {
            domainName = RMPAuthConstants.RMP_AUTHENTICATION;
        } else {
            JSONObject domainDetails = ADSDomainHandler.getDomainDetails(domainName);
            if (domainDetails.length() != 0) {
                domainName = domainDetails.getString("DOMAIN_NAME");
            }
        }
        logger.log(Level.INFO, "Inside RMPAPIAuthorization - isAuthorized method");
        logger.log(Level.INFO, "requestAPI " + requestAPI);
        logger.log(Level.INFO, "userName " + userName);
        logger.log(Level.INFO, "domainName " + domainName);
        if (requestAPI.contains("GetDashboard")) {
            if (request.getParameter("params") != null) {
                JSONObject params = new JSONObject(request.getParameter("params"));
                logger.log(Level.INFO, "params = " + params);

                if (!params.has("domainName")) {
                    throw new Exception("00000009");
                }
                String requestedDomain = params.getString("domainName");
                JSONObject domainDetails = ADSDomainHandler.getDomainDetails(requestedDomain);
                if (domainDetails.length() != 0) {
                    requestedDomain = domainDetails.getString("DOMAIN_NAME");
                }
                else{
                    throw new Exception("00000010");
                }
                logger.log(Level.INFO, "requestedDomain = " + requestedDomain);
                isUserAuthorized(userName.trim(), domainName.trim(), requestedDomain.trim());
            } else {
                throw new Exception("00000009");
            }
        }
        return true;
    }

    private boolean isUserAuthorized(String userName, String domainName, String requestedDomain) throws Exception {
        boolean isUserAuthorized = true;
        logger.log(Level.INFO, "Inside RMPAPIAuthorization - isUserAuthorized method");
        try {
            JSONObject domainDetails = ADSDomainHandler.getDomainDetails(domainName);
            if (domainDetails.length() != 0)
            {
              domainName = domainDetails.getString("DOMAIN_NAME");
            }
            DataObject dObj = RMPAuthHandler.getAccountDO(userName, null, domainName);
            isUserAuthorized = RMPAuthHandler.isValidAccount(dObj);
            Row passwordRow = null,userStatusRow = null,accountStatusRow = null;
            passwordRow = dObj.getFirstRow(TableName.AAAPASSWORD);
            userStatusRow = dObj.getFirstRow(TableName.AAAUSERSTATUS);
            accountStatusRow = dObj.getFirstRow(TableName.AAAACCOUNTSTATUS);
            String userStatus = (String) userStatusRow.get("STATUS");
            if("DISABLED".equalsIgnoreCase(userStatus))
            {
                throw new LoginException("rmp.login.common.error.user_disabled_in_rmp");// NO I18N
            }

            String accountStatus = (String) accountStatusRow.get("STATUS");
            if("DEACTIVATED".equals(accountStatus))
            {
                throw new LoginException("rmp.login.common.error.user_accnt_disabled_in_rmp");// NO I18N
            }
            else if("LOCKED".equals(accountStatus))
            {
                throw new LoginException("rmp.login.common.error.user_accnt_locked_in_rmp");// NO I18N
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.log(Level.INFO, "isUserAuthorized = " + isUserAuthorized);
        return isUserAuthorized;
    }

}
