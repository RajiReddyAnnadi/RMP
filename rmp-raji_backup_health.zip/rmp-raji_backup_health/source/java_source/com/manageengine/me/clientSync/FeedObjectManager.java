/**
 *
 * $Id$ : @author navarajan-1466
 */
//ignorei18n_start
package com.manageengine.me.clientSync;

import java.util.HashMap;

public class FeedObjectManager {
private HashMap<String, SyncObjectWrapper> syncObjectContainers = new HashMap<String, SyncObjectWrapper>();

        public SyncObjectWrapper get(String tenantId)
        {
            if (syncObjectContainers.containsKey(tenantId))
            {
                return syncObjectContainers.get(tenantId);
            }
            return new SyncObjectWrapper();
        }

        private void put(String containerId, SyncObjectWrapper data)
        {
            syncObjectContainers.put(containerId,data);
        }

        public Long update(String containerId, Long currentVersionId, Long objectId, Object value)
        {
            SyncObjectWrapper clientData;
            if (currentVersionId > 0)
            {
                clientData = get(containerId);
                if (clientData.syncObjects.containsKey(objectId))
                {
                    SyncObject oldObject = clientData.syncObjects.get(objectId);
                    clientData.changeLog.remove(oldObject.version);
                }
            }
            else
            {
                clientData = new SyncObjectWrapper();
            }
            SyncObject data = new SyncObject(value, ++currentVersionId);
            clientData.changeLog.put(currentVersionId, objectId);
            clientData.syncObjects.put(objectId, data);
            put(containerId, clientData);
            //ContainerVersionManager.UpdateVersionInfo(containerId, storeId, currentVersionId);
            return currentVersionId;
        }
}
//ignorei18n_end