/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
package com.manageengine.me.clientSync;

public class StoreConfiguration {

    public int maxSize;
    public Boolean isLimitedSize;

    //public static Dictionary<StoreType, StoreConfiguration> config = new Dictionary<StoreType, StoreConfiguration>();
    public StoreConfiguration(int maxSize) {
        this.maxSize = maxSize;
        this.isLimitedSize = maxSize > 0;
    }
    //static StoreConfiguration()
    //{
    //    config[StoreType.Random] = new StoreConfiguration(false, -1);
    //    config[StoreType.DomainInfo] = new StoreConfiguration(false, -1);
    //    config[StoreType.NotificationInfo] = new StoreConfiguration(true, 100);
    //    config[StoreType.AdMonitorInfo] = new StoreConfiguration(true, 90);
    //    config[StoreType.MonitorSettingsInfo] = new StoreConfiguration(false, -1);
    //}
}
