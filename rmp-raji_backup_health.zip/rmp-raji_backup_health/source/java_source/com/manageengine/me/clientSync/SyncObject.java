/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */

//here the real data resides along with its version
package com.manageengine.me.clientSync;

import com.manageengine.me.util.JSONObjectUtil;

public class SyncObject {

    public String data;
    public Long version;

    public SyncObject(Object data, Long version) {
        update(data, version);
    }

    public void update(Object data, Long version) {
        this.data = JSONObjectUtil.toJsonString(data);
        this.version = version;
    }
}
