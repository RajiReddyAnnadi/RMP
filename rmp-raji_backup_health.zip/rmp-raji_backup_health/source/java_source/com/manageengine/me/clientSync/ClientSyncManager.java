/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
//ignorei18n_start
package com.manageengine.me.clientSync;

import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.common.LogWriter;
import java.util.HashMap;

public class ClientSyncManager {

    private static HashMap<Integer, StoreManager> stores = new HashMap<Integer, StoreManager>();
    public static HashMap<Integer, StoreConfiguration> storeConfig = new HashMap<Integer, StoreConfiguration>();
    private static final Long VERSION_UPDATE_ID = 9000000009677856642L;

    //private static Integer nextStoreId = 256;// 0 to 255 reservedStoreId
    //public static Integer createStore()
    //{
    //    if (createStore(nextStoreId))
    //    {
    //        nextStoreId++;
    //        return nextStoreId;
    //    }
    //    return -1;
    //}
    public static Boolean createStore(Integer storeId, Integer maxSize) {
        if (stores.containsKey(storeId)) {
            return false;
        }
        StoreManager storeManager = new StoreManager();
        storeConfig.put(storeId, new StoreConfiguration(maxSize));
        stores.put(storeId, (StoreManager) storeManager);
        return true;
    }

    public static Boolean removeStore(Integer storeId) {
        if (stores.containsKey(storeId)) {
            storeConfig.remove(storeId);
            stores.remove(storeId);
            return true;
        }
        return false;
    }

    public static HashMap<Integer, StoreConfiguration> getStoreConfigs() {
        return storeConfig;
    }

    public static HashMap<Integer, HashMap<Long, Object>> getDiff(String containerId, HashMap<Integer, Long> clientVersionIds) {
        HashMap<Integer, HashMap<Long, Object>> diff = new HashMap<Integer, HashMap<Long, Object>>();
        HashMap<Integer, Long> versionInfo = ContainerVersionManager.get(containerId);
        try {
            for (Integer storeType : clientVersionIds.keySet()) {
                Long clientVersionId = clientVersionIds.get(storeType);
                if (versionInfo.containsKey(storeType)) {
                    Long storeVersionId = versionInfo.get(storeType);
                    if (clientVersionId == storeVersionId) {
                        continue;
                    } else {
                        if (stores.containsKey(storeType)) {
                            diff.put(storeType, new HashMap<Long, Object>());
                            SyncObjectWrapper clientData = stores.get(storeType).get(containerId);
                            for (Long versionId = clientVersionId + 1; versionId <= storeVersionId; versionId++) {
                                if (clientData.changeLog.containsKey(versionId)) {
                                    Long objId = clientData.changeLog.get(versionId);
                                    diff.get(storeType).put(objId, clientData.syncObjects.get(objId));
                                }
                            }
                            if (diff.get(storeType).size() == 0) {
                                SyncObject syncObject = new SyncObject(null, storeVersionId);
                                diff.get(storeType).put(VERSION_UPDATE_ID, syncObject);//
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            LogWriter.clientSync.severe(String.format("ClientSyncManager.GetDiff %s %s \n%s", containerId, JSONObjectUtil.toJsonString(clientVersionIds), e));
        }
        return diff;
    }

    public static HashMap<Long, HashMap<Long, SyncObject>> syncStore(String containerId, HashMap<Integer, Long> clientVersionIds) {
        HashMap<Integer, Long> versionInfo = ContainerVersionManager.get(containerId);
        HashMap<Long, HashMap<Long, SyncObject>> diff = new HashMap<Long, HashMap<Long, SyncObject>>();
        try {
            for (Integer storeType : clientVersionIds.keySet()) {
                if (versionInfo.containsKey(storeType)) {
                    Long storeVersionId = versionInfo.get(storeType);
                    if (stores.containsKey(storeType)) {
                        diff.put(storeType.longValue(), new HashMap<Long, SyncObject>());
                        SyncObjectWrapper clientData = stores.get(storeType).get(containerId);
                        //var syncStoreConfig = SyncStoreConfiguration.config[(StoreType)storeType];
                        for (Long key : clientData.syncObjects.keySet()) {
                            diff.get(storeType.longValue()).put(key, clientData.syncObjects.get(key));
                        }
                    }
                }
            }
        } catch (Exception e) {
            LogWriter.clientSync.severe(String.format("ClientSyncManager.SyncStore %s, %s \n%s", containerId, JSONObjectUtil.toJsonObject(clientVersionIds), e));
        }
        return diff;

    }

    public static Long update(String containerId, Integer storeId, Long objectId, Object value) {//ToDo: Locking the Objects
        HashMap<Integer, Long> versionInfo = ContainerVersionManager.get(containerId);
        Long versionId;

        if (stores.containsKey(storeId)) {
            versionId = versionInfo.containsKey(storeId) ? versionInfo.get(storeId) : 0L;//ToDo: Eliminate check by initializing starting versionId to 0 at the time of new container creation itself
            versionId = stores.get(storeId).update(containerId, versionId, objectId, value, storeId);
            if (versionId != -1L) {
                ContainerVersionManager.update(containerId, storeId, versionId);
            }
            return versionId;
        }
        return -1L;
    }

    public static Object get(String containerId, Integer storeId, Long objectId) {
        return stores.get(storeId).get(containerId, storeId, objectId);
    }

    public static Boolean remove(String containerId, Integer storeId, Long objectId) {
        return stores.get(storeId).remove(containerId, storeId, objectId);
    }
}
//ignorei18n_start