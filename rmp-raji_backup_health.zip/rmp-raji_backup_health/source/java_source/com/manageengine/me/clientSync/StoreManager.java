/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
//ignorei18n_start
package com.manageengine.me.clientSync;

import com.manageengine.rmp.common.LogWriter;
import java.util.HashMap;

public class StoreManager {

    private HashMap<String, SyncObjectWrapper> syncObjectWrapper = new HashMap<String, SyncObjectWrapper>();

    public StoreManager() {
    }

    public SyncObjectWrapper get(String tenantId) {
        if (syncObjectWrapper.containsKey(tenantId)) {
            return syncObjectWrapper.get(tenantId);
        }
        return new SyncObjectWrapper();
    }

    private void put(String containerId, SyncObjectWrapper data) {
        syncObjectWrapper.put(containerId, data);
    }

    public Long update(String containerId, Long currentVersionId, Long objectId, Object value, Integer storeId) {
        SyncObjectWrapper clientData;
        try {
            //var storeConfig = SyncStoreConfiguration.config[storeType];
//            if (ClientSyncManager.storeConfig.get(storeId).isLimitedSize) {
//                //objectId = currentVersionId % ClientSyncManager.storeConfig.get(storeId).maxSize;
//            }
            if (currentVersionId > 0) {
                clientData = get(containerId);
                if (clientData.syncObjects.containsKey(objectId)) {//update existing
                    SyncObject oldObject = clientData.syncObjects.get(objectId);
                    clientData.changeLog.remove(oldObject.version);
                } else {//Add new
                    if (ClientSyncManager.storeConfig.get(storeId).isLimitedSize) {//If the store has size limit then we are checking whether the maxSize limit reached
                        if (!(clientData.seqId.get(clientData.seqId.size() - 1) < objectId)) {//We treat that the new objectId is always greater than the last one. If not we need to move this as storeConfiguration later
                            return -1L;
                        }
                        if (clientData.seqId.size() == ClientSyncManager.storeConfig.get(storeId).maxSize) {

                            Long oldestObjId = clientData.seqId.remove(0);
                            remove(containerId, storeId, oldestObjId);
                        }
                        clientData.seqId.add(objectId);
                    }
                }
            } else {
                clientData = new SyncObjectWrapper();
                if (ClientSyncManager.storeConfig.get(storeId).isLimitedSize) {
                    clientData.seqId.add(objectId);
                }
            }
            SyncObject data = new SyncObject(value, ++currentVersionId);
            clientData.changeLog.put(currentVersionId, objectId);
            clientData.syncObjects.put(objectId, data);
            put(containerId, clientData);
            //ContainerVersionManager.UpdateVersionInfo(containerId, storeId, currentVersionId);
        } catch (Exception e) {
            LogWriter.clientSync.severe(String.format("SyncObjectManager.Update() %s %s %s %s ", containerId, currentVersionId, objectId, storeId));
        }
        return currentVersionId;
    }

    public Boolean remove(String containerId, Integer storeId, Long objectId) {
        SyncObjectWrapper clientData;
        try {
            clientData = get(containerId);
            if (clientData.syncObjects.containsKey(objectId)) {
                SyncObject oldObject = clientData.syncObjects.get(objectId);
                clientData.changeLog.remove(oldObject.version);
                clientData.syncObjects.remove(objectId);
                return true;
            }
        } catch (Exception e) {
            LogWriter.clientSync.severe(String.format("SyncObjectManager.remove() %s %s %s", containerId, storeId, objectId));
        }
        return false;
    }

    public Object get(String containerId, Integer storeId, Long objectId) {
        SyncObjectWrapper clientData;
        try {
            clientData = get(containerId);
            if (clientData.syncObjects.containsKey(objectId)) {
                return clientData.syncObjects.get(objectId);
            }

        } catch (Exception e) {
            LogWriter.clientSync.severe(String.format("SyncObjectManager.get() %s %s %s", containerId, storeId, objectId));
        }
        return null;
    }
}
//ignorei18n_end