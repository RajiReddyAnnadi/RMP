/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
//ignorei18n_start
package com.manageengine.me.clientSync.rest;

import com.manageengine.me.clientSync.ClientSyncManager;
import com.manageengine.me.util.JSONObjectUtil;
import com.manageengine.rmp.common.LogWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

public class ClientSync extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String path = req.getPathInfo();
            JSONObject reqParams = getPostedData(req);
            if (path.equals("/getDiff")) {
                String clientVersionIds = reqParams.get("clientVersionIds").toString();
                String result = GetDiff(clientVersionIds);
                resp.getWriter().print(result);
            } else if (path.equals("/updateData")) {
                Integer storeType = reqParams.getInt("storeType");
                Long operationId = reqParams.getLong("operationId");
                Object value = reqParams.get("value");
                Object result = updateData(storeType, operationId, value);
                resp.getWriter().print(result);
            } else if (path.equals("/sync")) {
                String clientVersionIds = reqParams.get("clientVersionIds").toString();
                String result = Sync(clientVersionIds);
                resp.getWriter().print(result);
            } else if(path.equals("/storeConfigs")){
                String result = JSONObjectUtil.toJsonString(ClientSyncManager.getStoreConfigs());
                resp.getWriter().print(result);
            }
        } catch (Exception e) {
            LogWriter.clientSync.severe(String.format("ClientSync.get req: %s \nexcep: %s", JSONObjectUtil.toJsonString(req), e));
        }
    }

    private static JSONObject getPostedData(HttpServletRequest request) {
        try {
            StringBuilder buffer = new StringBuilder();
            BufferedReader reader = request.getReader();
            String line;
            while ((line = reader.readLine()) != null) {
                buffer.append(line);
            }
            String data = buffer.toString();
            data=data.replaceAll("%", "%25").replaceAll("\\+", "%2B");
            data = java.net.URLDecoder.decode(data, "UTF-8");
            return JSONObjectUtil.parse(data);
        } catch (Exception e) {
            return new JSONObject();
        }      
    }

    public static Object updateData(Integer storeType, Long operationId, Object value) {
        return ClientSyncManager.update(GetTenantId(), storeType, operationId, value);
    }

    public static String GetDiff(String clientVersionIds) {
        return JSONObjectUtil.toJsonString(ClientSyncManager.getDiff(GetTenantId(), parse(clientVersionIds)));
    }

    public static String Sync(String clientVersionIds) {
        return JSONObjectUtil.toJsonString(ClientSyncManager.syncStore(GetTenantId(), parse(clientVersionIds)));
    }

    private static String GetTenantId() {
        return "0";
    }

    private static HashMap<Integer, Long> parse(String clientVersionIds) {
        HashMap<Integer, Long> data = new HashMap<Integer, Long>();
        try {
            JSONObject jsonData = new JSONObject(clientVersionIds);
            Iterator jsonObjectKeys = jsonData.keys();
            while (jsonObjectKeys.hasNext()) {
                String key = jsonObjectKeys.next().toString();
                Integer storeType = Integer.parseInt(key);
                Long versionId = jsonData.getLong(key);
                data.put(storeType, versionId);
}
        } catch (Exception e) {
        }
        return data;
    }
}
//ignorei18n_end
