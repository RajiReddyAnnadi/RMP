/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
//ignorei18n_start
package com.manageengine.me.clientSync;

//It will maiNtain meta data of syncObjectContainer latest version. This info will be cached locally where as SyncObjectContainer may be moved to external process (cloud) cachine system
import com.manageengine.rmp.common.LogWriter;
import java.util.HashMap;

public class ContainerVersionManager {

    private static HashMap<Object, HashMap<Integer, Long>> allContainerVersionInfo = new HashMap<Object, HashMap<Integer, Long>>(); //containerId,storeId,versionId

    //public static Long GetLatestVersionId(String tenantId, Integer storeId)
    //{
    //    if (tenantVersions.ContainsKey(tenantId))
    //        return tenantVersions[tenantId][storeId];
    //    return 0;
    //}
    public static HashMap<Integer, Long> get(String containerId) {
        if (!allContainerVersionInfo.containsKey(containerId)) {
            allContainerVersionInfo.put(containerId, new HashMap<Integer, Long>());
            allContainerVersionInfo.get(containerId).put(-1, 0L);
        }
        return allContainerVersionInfo.get(containerId);
    }

    public static  void put(String containerId, HashMap<Integer, Long> versionInfo) {
        allContainerVersionInfo.put(containerId, versionInfo);
    }

    public static  void update(String containerId, Integer storeId, Long versionId) {
        try {
            HashMap<Integer, Long> containerVersionInfo = get(containerId);
            containerVersionInfo.put(-1, containerVersionInfo.get(-1) + 1);
            containerVersionInfo.put(storeId, versionId);
        } catch (Exception e) {
            LogWriter.clientSync.severe(String.format("ContainerVerMgr.Update %s %s %s \n%s", containerId, storeId, versionId, e));
        }
    }
}
//ignorei18n_end