/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
package com.manageengine.me.clientSync;

//It contains set of syncObjects which is uniquely identified by its objectId
import java.util.ArrayList;
import java.util.HashMap;

//ChangeLog has a version pointed to the objectId. It will act as a index
public class SyncObjectWrapper {

    public HashMap<Long, SyncObject> syncObjects; //objectId,object
    public HashMap<Long, Long> changeLog; //versionId,objectId
    public ArrayList<Long> seqId;

    public SyncObjectWrapper() {
        syncObjects = new HashMap<Long, SyncObject>();
        changeLog = new HashMap<Long, Long>();
        seqId = new ArrayList<>();
    }
}
