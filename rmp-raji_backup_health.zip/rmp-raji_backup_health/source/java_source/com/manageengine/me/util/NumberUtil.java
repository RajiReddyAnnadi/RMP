/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
package com.manageengine.me.util;

import java.util.LinkedHashSet;

public class NumberUtil {

    public static Integer[] getOnePosition(Integer number, Integer maxPosition) {
        LinkedHashSet<Integer> set = new LinkedHashSet<Integer>();
        for (int i = 0; i <= maxPosition; i++) {
            if ((number & (1 << i)) >= 1) {
                set.add(i);
            }
        }
        return set.toArray(new Integer[0]);
    }
    
    public static String getHex(String hexString){//input format :  \x00af
        if(hexString!=null && hexString.length()>2){
            return hexString.substring(2);
        }
        return "";
    }
    
    public static int getMaxSetBit(int number, int maxPosition) {
        for (int i = maxPosition; i >= 0; i--) {
            if ((number & (1 << i)) >= 1) {
                return i;
            }
        }
        return 0;
    }
    
    public static int getMaxSetBitMaskValue(int number, int maxPosition) {
        for (int i = maxPosition; i >= 0; i--) {
            if ((number & (1 << i)) >= 1) {
                return 1<<i;
            }
        }
        return 0;
    }
}
