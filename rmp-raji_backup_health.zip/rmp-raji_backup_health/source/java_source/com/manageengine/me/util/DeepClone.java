/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.me.util;

import java.lang.reflect.Field;

/**
 *
 * $Id: @author navarajan-1466 $
 */
public class DeepClone {

    public static <T extends Object> T clone(T object) {
        Object clone = null;

        try {
            clone = object.getClass().newInstance();
            for (Class parentClass = object.getClass(); !parentClass.equals(Object.class); parentClass = parentClass.getSuperclass()) {
                Field[] fields = parentClass.getDeclaredFields();
                for (int i = 0; i < fields.length; i++) {
                    fields[i].setAccessible(true);
                    fields[i].set(clone, fields[i].get(object));
                }
            }
        } catch (Exception e) {
//            System.out.println(e);
            e.printStackTrace();
        }
        return (T) clone;
    }

    public static <T extends Object> T copyTo(T source, T destination) {
        try {
            for (Class parentClass = source.getClass(); !parentClass.equals(Object.class); parentClass = parentClass.getSuperclass()) {
                Field[] fields = parentClass.getDeclaredFields();
                for (int i = 0; i < fields.length; i++) {
                    fields[i].setAccessible(true);
                    fields[i].set(destination, fields[i].get(source));
                }
            }
        } catch (Exception e) {
//            System.out.println(e);
            e.printStackTrace();
        }
        return destination;
    }
}
