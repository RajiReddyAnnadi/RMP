/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
//ignoreI18n_start
package com.manageengine.me.util;

import com.manageengine.rmp.common.LogWriter;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;

public class JSONArrayUtil {

//src:http://stackoverflow.com/a/21396348    
    public static JSONArray remove(JSONArray array, int index) {
        JSONArray outputArray = new JSONArray();
        try {
            int len = array.length();
            for (int i = 0; i < len; i++) {
                if (i != index) {
                    try {
                        outputArray.put(array.get(i));
                    } catch (JSONException e) {
                        return array;
                    }
                }
            }
        } catch (Exception e) {
            LogWriter.general.severe("JSONArrayUtil.remove " + e);
            return null;
        }
        return outputArray;
    }

    public static String[] toStringArray(JSONArray array) {
        try {
            List<String> list = new ArrayList<>();
            for (int i = 0; i < array.length(); i++) {
                list.add(array.get(i).toString());
            }
            return list.toArray(new String[list.size()]);
        } catch (Exception e) {
            LogWriter.general.severe("JSONArrayUtil.toStringArray " + e);
            return null;
        }
    }

    public static int[] toIntArray(JSONArray array) {
        try {
            int[] numbers = new int[array.length()];
            for (int i = 0; i < array.length(); ++i) {
                numbers[i] = array.optInt(i);
            }
            return numbers;
        } catch (Exception e) {
            LogWriter.general.severe("JSONArrayUtil.toIntArray " + e);
            return null;
        }
    }
    
    public static Integer[] toIntegerArray(JSONArray array) {
        try {
            Integer[] numbers = new Integer[array.length()];
            for (int i = 0; i < array.length(); ++i) {
                numbers[i] = array.optInt(i);
            }
            return numbers;
        } catch (Exception e) {
            LogWriter.general.severe("JSONArrayUtil.toIntArray " + e);
            return null;
        }
    }

    public static Long[] toLongArray(JSONArray array) {
        try {
            Long[] numbers = new Long[array.length()];
            for (int i = 0; i < array.length(); ++i) {
                numbers[i] = array.optLong(i);
            }
            return numbers;
        } catch (Exception e) {
            LogWriter.general.severe("JSONArrayUtil.toLongArray " + e);
            return null;
        }
    }

    public static ArrayList toArrayList(JSONArray jsonArray) {
        try {
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < jsonArray.length(); i++) {
                arrayList.add(jsonArray.get(i));
            }
            return arrayList;
        } catch (Exception e) {
            LogWriter.general.severe("JSONArrayUtil.toArrayList " + e);
            return null;
        }
    }

    public static byte[] intArrayToByteArray(int[] data)//ToDo: move this to apt class file
    {
        try {
            byte[] bytes = new byte[data.length];
            for (int i = 0; i < data.length; ++i) {
                bytes[data.length - i - 1] = (byte) data[i];
            }
            return bytes;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static JSONArray byteToJsonArray(byte[] byteArray) {
        JSONArray jsonArray = new JSONArray();
        for (Integer i = 0; i < byteArray.length; i++) {
            jsonArray.put(byteArray[i]);
        }
        return jsonArray;
    }

    public static byte[] jsonArrayToByteArray(JSONArray jsonArray) {
        byte[] byteArray = new byte[jsonArray.length()];
        try {
            for(int i = 0; i < jsonArray.length(); i++) {
                byteArray[i] = (byte) jsonArray.getInt(i);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return byteArray;
    }

    public static JSONArray inputstreamToJsonArray(InputStream inputStream) {
        try {
            byte[] byteArray = IOUtils.toByteArray(inputStream);
            return byteToJsonArray(byteArray);
        } catch (Exception e) {
            LogWriter.general.severe("JSONArrayUtil.inputstreamToJsonArray " + e);
        }
        return new JSONArray();
    }
      public static ArrayList jsonArrayToArrayList(JSONArray jsonArray) {
        ArrayList list = new ArrayList();
        try {
            for (int i = 0; i < jsonArray.length(); i++) {
                list.add(jsonArray.get(i));
            }
        } catch (Exception e) {
            LogWriter.general.warning(String.format("JSONArrayUtil.jsonArrayToArrayList", e));
        }
        return list;
      }
      
      public static JSONArray arrayToJsonArray(Object[] array){
          JSONArray jsonArray =new JSONArray();
          try{
              for(int i=0;i<array.length;i++){
                  jsonArray.put(array[i]);
              }
          }
          catch(Exception e){
              LogWriter.general.warning(String.format("JSONArrayUtil.arrayToJsonArray", e));
          }
          return jsonArray;
      }
}
//ignoreI18n_end
