/**
 *
 * $Id$ : @author navarajan-1466
 */
//ignoreI18n_start
package com.manageengine.me.util;

import com.manageengine.rmp.common.LogWriter;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DateUtil {

    public static String DateToTimestamp(Date date) {
        Timestamp timestamp = new Timestamp(date.getTime());
        SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        timestampFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        return timestampFormat.format(timestamp);
    }
    public static Date timestampToDate(String timestamp) {
        try{
            SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            timestampFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
            return timestampFormat.parse(timestamp);
        } catch (Exception e) {
            e.printStackTrace();
            return new Date();
        }
    }
    public static String getGraphDate(String timestamp) {
        Date date = new Date(timestamp);
        return date.getDate() + " " + date.toString().split(" ")[1] + "'" + String.valueOf(date.getYear()+1900).substring(2, 4);
    }
    public static Date getClientDate(String dateString) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX", Locale.US);
            return sdf.parse(dateString);
        } catch (Exception e) {
            e.printStackTrace();
            return new Date();
        }
    }

    public static String getUtcDate(Timestamp date) {
        SimpleDateFormat timestampFormat = new SimpleDateFormat("MMM dd, yyyy hh:mm:ss a", Locale.US);
        return timestampFormat.format(date) + " UTC";
    }

    public static Timestamp getTimestampFromDate(Date date) {
        return new Timestamp(date.getTime());
    }

    public static Date addSeconds(Date date, int seconds) {
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(date.getTime());
            calendar.add(Calendar.SECOND, seconds);
            date = calendar.getTime();
        } catch (Exception e) {
            LogWriter.general.severe(String.format("DateUtil.addSeconds %s", e));
        }
        return date;
    }

    public static Date convertToUTC(Date localTime) {
        String format = "yyyy/MM/dd HH:mm:ss";
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date gmtDate = new Date(sdf.format(localTime));
        String gmtString = gmtDate.toString();
        return gmtDate;
    }
    
    public static Date convertToUTC(long time) {
        return convertToUTC(new Date(time));
    }
    
    public static String millisecondsToTime(long msec) {
    	long mins = (msec / 1000) / 60;
        long secs = (msec / 1000) % 60;
        long millisec = msec % 1000;
        String timeTaken = "";
        if ((mins >= 60 && (secs > 0 || millisec > 0)) || mins > 60) {
        	long hrs = mins / 60;
        	mins = mins % 60;
        	timeTaken = timeTaken + hrs + " " + ((hrs > 1) ? "hrs" : "hr");
        	timeTaken = timeTaken + ((mins > 0) ? (" " + mins + " " + ((mins > 1) ? "mins" : "min")) : "");
    	}
        else if (mins <= 60 && mins > 0) {
        	timeTaken = timeTaken + mins + " " + ((mins > 1) ? "mins" : "min");
    	}
        else {
            if (secs == 0) {
                secs = 1;
            }
        	timeTaken = timeTaken + secs + " " + ((secs > 1) ? "secs" : "sec");
    	}
        return timeTaken;
    }
}


//ignoreI18n_end
