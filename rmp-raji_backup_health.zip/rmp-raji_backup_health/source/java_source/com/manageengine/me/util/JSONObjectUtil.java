/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
package com.manageengine.me.util;

import com.google.gson.Gson;
import com.manageengine.rmp.common.LogWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;
//ignoreI18n_start

public class JSONObjectUtil {

    private static Gson gson = new Gson();

    public static <T extends Object> JSONObject toJsonObject(T object) {
        try {
            String jsonString = toJsonString(object);
            return new JSONObject(jsonString);
        } catch (Exception e) {
            LogWriter.general.severe(String.format("GeneralUtil.toJsonObject type:%s excep:%s", object.getClass(), e));
        }
        return new JSONObject();
    }

    public static String toJsonString(Object object) {
        return gson.toJson(object); //warning it will alter symbols to unicode characters 
    }

    public static <T extends Object> T fromJsonString(String jsonString, Type type) {
        //return (T) new Object();
        return gson.fromJson(jsonString, type);
    }

    public static <T extends Object> T getObjectFromJsonString(String jsonString, Class<T> type) {
        //return (T) new Object();
        return gson.fromJson(jsonString, type);
    }

    public static <T extends Object> T getObjectFromJsonString(JSONObject jsonObject, Class<T> type) {
        String jsonString = jsonObject.toString();
        return gson.fromJson(jsonString, type);
    }

    public static JSONObject parse(String jsonString) {
        try {
            return new JSONObject(jsonString);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public static Object getValue(JSONObject jsonObject, String key) {
        try {
            return jsonObject.get(key);
        } catch (JSONException e) {
            return null;
        }
    }

    public static UUID getUUID(JSONObject jsonObject, String key) {
        return (UUID) getValue(jsonObject, key);
    }

    public static JSONObject merge(JSONObject obj1, JSONObject obj2) {
        Iterator iterator = obj2.keys();
        try{
        JSONObject obj3=new JSONObject(obj1.toString());
        
       
        while (iterator.hasNext()) {
            String key = (String) iterator.next();
            try {
                obj3.put(key, obj2.get(key));
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return obj3;
        }
        catch(Exception e){
             e.printStackTrace();
        }
        return new JSONObject();
    }

    public static JSONObject merge(String str1, String str2) {
        // TODO Auto-generated method stub
        JSONObject obj1 = new JSONObject();
        JSONObject obj2 = new JSONObject();
        try {
            obj1 = new JSONObject(str1);
            obj2 = new JSONObject(str2);
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return JSONObjectUtil.merge(obj1, obj2);
    }

    public static List<String> getSortedKeys(JSONObject jsonObject) {
        try{
            Iterator iterator = jsonObject.keys();
            List<String> sortedKeys = new ArrayList<String>();
            Map<Integer, String> map = new HashMap<>();        
            while(iterator.hasNext()){
                String keys=(String)iterator.next();
                String[] backupIdInfo = keys.split(":");
                int backupId = Integer.parseInt(backupIdInfo[0]);
                map.put(backupId, keys);
            }
            Map<Integer, String> treeMap = new TreeMap<>(map);
            for(String value : treeMap.values()){
                sortedKeys.add(value);
            }
            return sortedKeys;
        }
        catch(Exception e){
            return new ArrayList<String>();
        }
    }
}
//ignoreI18n_end
