/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.manageengine.me.util;

import com.manageengine.rmp.common.LogWriter;
import java.net.URLDecoder;
import org.json.JSONObject;

/**
 *
 * @author suganya-1815
 */
//ignoreI18n_start
public class ClientUtil {

    public static JSONObject GetPageParamJSONObject(String queryString) {
        JSONObject jsonObject=new JSONObject();
        try {
            queryString=queryString.replaceAll("%", "%25").replaceAll("\\+", "%2B");
            queryString=URLDecoder.decode(queryString, "utf-8");//NO I18N
            queryString=queryString.replace("\\\"", "\"");//NO I18N
            queryString = queryString.replaceAll("^\"|\"$", "");//NO I18N
            jsonObject = new JSONObject(queryString);
        } catch (Exception e) {
            LogWriter.general.warning(String.format("ClientUtil.getPageParamJSONObject %s %s",queryString,e));//NO I18N
        }
        return jsonObject;
    }

    public static String htmlEscape(String input) {
        try {
            return input.replace("&", "&amp;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace(" ", "&nbsp;");
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
}
//ignoreI18n_end