/**
 *
 * $Id$ :
 *
 * @author navarajan-1466
 */
package com.manageengine.me.util;

import com.adventnet.persistence.Row;
import com.manageengine.rmp.util.BitSetUtil;
import java.io.ByteArrayInputStream;
import java.util.BitSet;
import java.util.UUID;
import org.json.JSONObject;

public class RowHelper {

    public Row row;

    public RowHelper(Row row) {
        this.row = row;
    }

    public String getString(String columnName) {
        Object obj = row.get(columnName);
        if (obj != null) {
            return (String) obj;
        }
        return null;
    }

    public UUID getUUID(String columnName) {
        Object obj = row.get(columnName);
        if (obj != null) {
            return UUID.fromString((String) obj);
        }
        return null;
    }

    public Boolean getBoolean(String columnName) {
        Object obj = row.get(columnName);
        if (obj != null) {
            return (Boolean) obj;
        }
        return null;
    }

    public Long getLong(String columnName) {
        Object obj = row.get(columnName);
        if (obj != null) {
            return (Long) obj;
        }
        return null;
    }

    public Integer getInteger(String columnName) {
        Object obj = row.get(columnName);
        if (obj != null) {
            return (Integer) obj;
        }
        return null;
    }

    public BitSet getBitSet(String columnName) {
        Object obj = row.get(columnName);
        if (obj != null) {
            try {
                ByteArrayInputStream byteStream = (ByteArrayInputStream) obj;
                byteStream.reset();//For GPO
                byte[] byteArray = new byte[byteStream.available()];
                byteStream.read(byteArray);
                return BitSetUtil.fromByteArray(byteArray);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public JSONObject getJSONObject(String columnName) {
        try {
            Object obj = row.get(columnName);
            if (obj != null) {
                String objStr = (String) obj;
                return new JSONObject(objStr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
